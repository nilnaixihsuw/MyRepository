﻿using ERPModel.ApiModel.TicketManage;
using ERPModel.Repairs.MaintainReport;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.MaintManage.MaintainReport.Contracts
{
    public interface IVehicleKindRepairCountImp
    {
        /// <summary>
        /// 车型维修统计
        /// </summary>
        Task<List<Dictionary<string, object>>> GetCountAsync(VehicleKindRepairCountQuery input);

        /// <summary>
        /// 获取表头
        /// </summary>
        /// <returns></returns>
        Task<List<RevenueSummary.RevenueTitle>> GetTile(List<decimal?> repair_states, string server_id = "60.191.59.11");
    }
}
