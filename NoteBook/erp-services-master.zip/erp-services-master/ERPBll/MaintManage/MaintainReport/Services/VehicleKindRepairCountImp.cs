﻿using AutoMapper;
using ERPBll.MaintManage.MaintainReport.Contracts;
using ERPBll.RedisManage.Dicts;
using ERPDal;
using ERPModel.ApiModel.TicketManage;
using ERPModel.DataBase;
using ERPModel.Repairs.MaintainReport;
using ERPModel.Repairs.MaintRepairOrders;
using ERPModel.Vehicleinfomanage;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.MaintManage.MaintainReport.Services
{
    public class VehicleKindRepairCountImp : IVehicleKindRepairCountImp
    {
        //public readonly IDictRedisManageImp _iDictRedisManageImp;

        //public VehicleKindRepairCountImp(IDictRedisManageImp iDictRedisManageImp)
        //{
        //    _iDictRedisManageImp = iDictRedisManageImp;
        //}

        /// <summary>
        /// 获取表头
        /// </summary>
        /// <returns></returns>
        public async Task<List<RevenueSummary.RevenueTitle>> GetTile(List<decimal?> repair_states, string server_id = "60.191.59.11")
        {
            var r = new List<RevenueSummary.RevenueTitle>();
            int index = 0;

            r.Add(new RevenueSummary.RevenueTitle
            {
                id = ++index,
                label = "车辆型号id",
                prop = "vehicle_kind_id",
                width = "110",
                align = "center",
                signIndex = index,
                sortable = true
            });

            r.Add(new RevenueSummary.RevenueTitle
            {
                id = ++index,
                label = "车辆型号",
                prop = "vehicle_kind",
                width = "150",
                align = "center",
                signIndex = index,
                sortable = true
            });

            //根据字典分组遍历数据字典
            var query = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<SysCommonDictDetail>()
                                .WhereIF(repair_states != null && repair_states.Count > 0,
                                        x => repair_states.Contains(x.i_id))
                                .Where(x => x.i_main_id == 959668)
                                .OrderBy(x => x.i_id)
                                .Select(x => new
                                {
                                    id = x.i_id,
                                    name = x.c_name
                                })
                                .ToListAsync();

            query.ForEach(x => {
                r.Add(new RevenueSummary.RevenueTitle {
                    id = Convert.ToInt32(x.id),
                    label = x.name,
                    prop = "type_" + Convert.ToInt32(x.id),
                    width = (x.name.Length * 30 > 150 ? 150 : x.name.Length * 30).ToString(),
                    align = "center",
                    signIndex = ++index,
                    sortable = true
                });
            });

            r.Add(new RevenueSummary.RevenueTitle
            {
                id = ++index,
                label = "总维修次数",
                prop = "total_repair_count",
                width = "110",
                align = "center",
                signIndex = index,
                sortable = true
            });

            return r;
        }

        /// <summary>
        /// 车型维修统计
        /// </summary>
        public async Task<List<Dictionary<string, object>>> GetCountAsync(VehicleKindRepairCountQuery input)
        {
            if (input.repair_states == null || input.repair_states.Count < 1)
            {
                input.repair_states = await SqlSugarHelper.DBClient(input.server_id)
                                .Queryable<SysCommonDictDetail, SysCommonDict>(
                                    (x, y) => new JoinQueryInfos(
                                        JoinType.Left, x.i_main_id == y.i_id
                                ))
                                .Where((x, y) => y.c_key == "repair-management")
                                .OrderBy(x => x.i_id)
                                .Select(x => x.i_id)
                                .ToListAsync();

                input.repair_states.Add(-1);
            }

            var query = await SqlSugarHelper.DBClient(input.server_id)
                                .Queryable<MaintVehicleKind, ErpVehicleInfo, MaintRepairOrder, SysCommonDictDetail>(
                                    (a, b, c, d) => new JoinQueryInfos(
                                        JoinType.Left, a.i_id == b.c_id,
                                        JoinType.Left, b.i_id == c.vehicle_id,
                                        JoinType.Left, c.type_child == d.i_id
                                    ))
                                .Where(input.ToExp())
                                .OrderBy((a, b, c, d) => a.i_id)
                                .Select((a, b, c, d) => new VehicleKindRepair
                                {
                                    vehicle_kind_id = a.i_id,
                                    vehicle_kind_name = a.c_name,
                                    type_id = d.i_id
                                })
                                .ToListAsync();

            if (query == null || query.Count < 1)
            {
                return null;
            }

            List<Dictionary<string, object>> res = new List<Dictionary<string, object>>();

            decimal vehicle_kind_id = 0;

            foreach (var item in query)
            {
                Dictionary<string, object> dic = new Dictionary<string, object>();

                if (item.vehicle_kind_id != vehicle_kind_id)
                {
                    vehicle_kind_id = item.vehicle_kind_id;
                    dic.Add("vehicle_kind_id", item.vehicle_kind_id);
                    dic.Add("vehicle_kind", item.vehicle_kind_name);

                    int total_count = 0;
                    foreach (var type in input.repair_states)
                    {
                        var count = query.Where(x => x.type_id == type && x.vehicle_kind_id == item.vehicle_kind_id).Count();
                        total_count += count;
                        dic.Add($"type_{type}", count);
                    }

                    dic.Add("total_repair_count", total_count);

                    res.Add(dic);
                }
            }

            res = res.OrderByDescending(x => Convert.ToInt32(x["total_repair_count"])).ToList();

            return res;
        }
    }
}
