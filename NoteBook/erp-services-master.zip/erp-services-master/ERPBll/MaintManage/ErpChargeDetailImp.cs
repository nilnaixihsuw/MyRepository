﻿using ERPCore.ORM;
using ERPDal.MaintManage;
using ERPModel.MaintManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using Microsoft.AspNetCore.Http;
using System.IO;
using ERPCore;
using ERPCore.Extensions;
using ERPDal.Vehicleinfomanage;
using ERPDal.SystemManage;
using ERPModel.ApiModel;
using System.Linq.Expressions;
using ERPBll.UserManage;
using ERPCore.Entity;

namespace ERPBll.MaintManage
{
    public class ErpChargeDetailImp : BusinessRespository<ErpChargeDetail, IErpChargeDetailDataImp>, IErpChargeDetailImp
    {
        private readonly IVehicleInfoDataImp _iVehicleInfoDataImp;
        private readonly IErpChargeStationDataImp _iErpChargeStationDataImp;
        private readonly IErpChargePileDataImp _iErpChargePileDataImp;
        public ErpChargeDetailImp(
            IErpChargePileDataImp iErpChargePileDataImp,
            IErpChargeStationDataImp iErpChargeStationDataImp,
            IVehicleInfoDataImp iVehicleInfoDataImp,
            IErpChargeDetailDataImp dataImp) : base(dataImp)
        {
            _iErpChargePileDataImp = iErpChargePileDataImp;
            _iVehicleInfoDataImp = iVehicleInfoDataImp;
            _iErpChargeStationDataImp = iErpChargeStationDataImp;
        }

        /// <summary>
        /// 批量删除
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task<bool> BatchDelete(string server_id, List<decimal?> context)
        {
            var list = await _dataImp.List(server_id, it => context.Contains(it.id));
            return await _dataImp.Deletetable(server_id, list);
        }

        /// <summary>
        /// 获取车辆充电汇总信息
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="begin"></param>
        /// <param name="end"></param>
        /// <param name="vehicle_id"></param>
        /// <returns></returns>
        public async Task<ChargeFeeOverview> ChargeSummary(VehicleSummaryRequest request, IClientInformation client)
        {
            //加权限
            var orgs = RoleInfoBll.GetGroupID(request.server_id, client.i_id);
            var r = new ChargeFeeOverview();
            var exp = Expressionable.Create<ErpChargeDetail>()
                                    .AndIF(request.begin != null, it => it.begin_time >= request.begin)
                                    .AndIF(request.end != null, it => it.begin_time <= request.end)
                                    .AndIF(request.vehicle_id != null && request.vehicle_id.Count > 0, it => SqlFunc.ContainsArray(request.vehicle_id, it.vehicle_id));
            if (orgs != null)
            {
                if (orgs.Count > 0)
                {
                    var cars = await _iVehicleInfoDataImp.List(request.server_id, it => SqlFunc.ContainsArray(orgs.Select(it => it.ToString()).ToList(), it.c_crews_take));
                    if (cars != null && cars.Count > 0)
                    {
                        exp.And(it => SqlFunc.ContainsArray(cars.Select(it => it.i_id).ToList(), it.vehicle_id));
                    }
                    else
                    {
                        exp.And(it => false);
                    }
                }
                else
                {
                    exp.And(it => false);
                }
            }
            else
            {
                exp.And(it => true);
            }

            //车辆充电明细
            var details = await ExtensionList(request.server_id, exp.ToExpression(), "");

            //汇总信息
            r.summary = new ChargeFeeSummary
            {
                charge_fee_total = Math.Round(details.Sum(it => it.charge_fee.GetValueOrDefault()), 2),
                charge_time_total = Math.Round(details.Sum(it => it.charge_time.GetValueOrDefault()), 2),
                electric_quantity_total = Math.Round(details.Sum(it => it.electric_quantity), 2)
            };

            //图表信息
            r.chart = details.OrderBy(it => it.begin_time).GroupBy(it => GetSimpleMonthDay(it.begin_time.GetValueOrDefault())).Select(it => new ChargeFeeChart
            {
                month_day = it.Key,
                charge_fee = Math.Round(it.ToList().Sum(it => it.charge_fee.GetValueOrDefault()), 2),
                charge_time = Math.Round(it.ToList().Sum(it => it.charge_time.GetValueOrDefault()), 2),
                electric_quantity = Math.Round(it.ToList().Sum(it => it.electric_quantity), 2),
                vehicle_number = it.ToList().Select(it => it.vehicle_id).Distinct().DefaultIfEmpty().Count()
            }).ToList();

            return r;
        }

        /// <summary>
        /// 返回转换的月-日
        /// </summary>
        /// <param name="date"></param>
        /// <returns></returns>
        private string GetSimpleMonthDay(DateTime date)
        {
            var month = date.Month;
            var day = date.Day;
            return month + "-" + day;
        }

        /// <summary>
        /// 导入
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="file"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        public async Task<bool> Import(string server_id, IFormFile file, int type)
        {
            var title = new Dictionary<string, string>()
            {
               { "车牌号", "lincense_plate_number"},
               { "订单编号", "order_code"},
               { "充电站名称", "station_name"},
               { "充电桩名称", "pile_name"},
               { "充电开始时间", "begin_time"},
               { "充电结束时间", "end_time"},
               { "充电费用(元)", "charge_fee"},
               { "充电电量(度)", "electric_quantity"},
               { "平均服务费实际单价(元)", "service_fee_avg"},
               { "充电时长(分钟)", "charge_time"},
               { "充电前SOC", "front_soc"},
               { "充电后SOC", "after_scc"},
            };

            var result = new byte[] { };
            //文件内容是否为空
            if (file.Length == 0)
                throw new Exception("文件不能为空");

            //文件后缀
            string filename = file.FileName;
            var ext = filename.Substring(filename.LastIndexOf("."), filename.Length - filename.LastIndexOf("."));

            // 判断后缀
            if (ext != ".xlsx" && ext != ".xls")
            {
                throw new Exception("请上传Excel文件！");
            }

            using (var ms = new MemoryStream())
            {
                file.CopyTo(ms);
                ms.Position = 0;
                result = ms.ToArray();
            }
            var dt = ExcelImportHelper.ReadBytesToDataTable(result, title);
            var list = dt.ToDataList<ErpChargeDetail>();
            var upList = new List<ErpChargeDetail>();

            //检查车必填项是否为空
            if (list.Exists(it => string.IsNullOrEmpty(it.lincense_plate_number)))
            {
                throw new Exception("存在车牌号为空记录！");
            }
            if (list.Exists(it => string.IsNullOrEmpty(it.order_code)))
            {
                throw new Exception("存在订单编号为空记录！");
            }
            if (list.Exists(it => string.IsNullOrEmpty(it.station_name)))
            {
                throw new Exception("存在充电站为空记录！");
            }
            if (list.Exists(it => string.IsNullOrEmpty(it.pile_name)))
            {
                throw new Exception("存在充电桩为空记录！");
            }

            //车牌号
            var plateNumbers = list.Select(it => it.lincense_plate_number).ToList();
            var cars = await _iVehicleInfoDataImp.List(server_id, it => SqlFunc.ContainsArray(plateNumbers, it.c_lincense_plate_number));
            //充电站
            var stationNames = list.Select(it => it.station_name).ToList();
            var stations = await _iErpChargeStationDataImp.List(server_id, it => SqlFunc.ContainsArray(stationNames, it.name));
            //充电桩
            var pileNames = list.Select(it => it.pile_name).ToList();
            var piles = await _iErpChargePileDataImp.List(server_id, it => SqlFunc.ContainsArray(pileNames, it.name));

            //给所有的人员赋主键值
            list.ForEach(item =>
            {
                item.id = _dataImp.GetId(server_id, "SEQ_COMMON").Result;
                if (cars.Exists(it => it.c_lincense_plate_number == item.lincense_plate_number))
                {
                    item.vehicle_id = cars.Find(it => it.c_lincense_plate_number == item.lincense_plate_number).i_id;
                }
                else throw new Exception("系统中不存在的车牌号!");
                if (stations.Exists(it => it.name == item.station_name))
                {
                    item.station_id = stations.Find(it => it.name == item.station_name).id;
                }
                else throw new Exception("系统中不存在的充电站!");
                if (piles.Exists(it => it.name == item.pile_name))
                {
                    item.pile_id = piles.Find(it => it.name == item.pile_name).id;
                }
                else throw new Exception("系统中不存在的充电桩!");
                item.created_id = 1;
                item.created_date = DateTime.Now;
            });
            //覆盖
            if (type == 1)
            {
                var eList = await _dataImp.List(server_id, it => SqlFunc.ContainsArray(list.Select(it => it.order_code).ToList(), it.order_code));
                list.ForEach(item =>
                {
                    if (eList.Exists(it => it.order_code == item.order_code))
                    {
                        var e = eList.Find(it => it.order_code == item.order_code);
                        item.id = e.id;
                        upList.Add(item);
                    }
                });
                list = list.Except(list.Where(it => eList.Select(it => it.order_code).ToList().Contains(it.order_code))).ToList();
            }
            //保持原数据
            if (type == 0)
            {

            }

            return await _dataImp.Import(server_id, list, upList);
        }

        private async Task<List<Expression<Func<ErpChargeDetail, bool>>>> GetExp(VehicleChargeSummaryRequest request)
        {
            var r = new List<Expression<Func<ErpChargeDetail, bool>>>();
            //角色部门权限
            if (request.orgs != null)
            {
                if (request.orgs.Count > 0)
                {
                    var cars = await _iVehicleInfoDataImp.List(request.server_id, it => SqlFunc.ContainsArray(request.orgs.Select(it => it.ToString()).ToList(), it.c_crews_take));
                    if (cars != null && cars.Count > 0)
                    {
                        r.Add(a => SqlFunc.ContainsArray(cars.Select(it => it.i_id).ToList(), a.vehicle_id));
                    }
                }
                else
                {
                    r.Add(a => false);
                }
            }
            else
            {
                r.Add(a => true);
            }

            return r;
        }
        public async Task<Tuple<List<VehicleChargeSoc>, int>> ChargeSummary(string server_id, VehicleChargeSummaryRequest request, int page_size, int page_index)
        {
            var exp = await GetExp(request);
            return await _dataImp.ChargeSummary(server_id, request.ToExp(exp), page_size, page_index);
        }

        public async Task<List<VehicleChargeSoc>> ChargeSummary(string server_id, VehicleChargeSummaryRequest request)
        {
            var exp = await GetExp(request);
            return await _dataImp.ChargeSummary(server_id, request.ToExp(exp));
        }

        public async Task<Tuple<List<ErpChargeDetail>, int>> QueryErpChargeDetail(string server_id, VehicleChargeDetailRequest request, string v, int page_size, int page_index, string orderby)
        {
            var exp = await GetExp(request);
            return await ExtensionList(server_id, request.ToExp(exp), v, page_size, page_index, orderby);
        }

        private async Task<List<Expression<Func<ErpChargeDetail, bool>>>> GetExp(VehicleChargeDetailRequest request)
        {
            var r = new List<Expression<Func<ErpChargeDetail, bool>>>();
            //角色部门权限
            if (request.orgs != null)
            {
                if (request.orgs.Count > 0)
                {
                    var cars = await _iVehicleInfoDataImp.List(request.server_id, it => SqlFunc.ContainsArray(request.orgs.Select(it => it.ToString()).ToList(), it.c_crews_take));
                    if (cars != null && cars.Count > 0)
                    {
                        r.Add(it => SqlFunc.ContainsArray(cars.Select(it => it.i_id).ToList(), it.vehicle_id));
                    }
                }
                else
                {
                    r.Add(it => false);
                }
            }
            else
            {
                r.Add(it => true);
            }

            return r;
        }

        public async Task<List<ErpChargeDetail>> QueryErpChargeDetail(string server_id, VehicleChargeDetailRequest request, string where, string orderby)
        {
            var exp = await GetExp(request);
            return await _dataImp.QueryErpChargeDetail(server_id, request.ToExp(exp), where, orderby);
        }

        public async Task<bool> AddOrEdit(string server_id, ErpChargeDetail context, ClientInformation client)
        {
            if (context.id > 0)
            {
                var old = await _dataImp.Get(server_id, context.id);
                context.created_id = old.created_id;
                context.created_date = old.created_date;
                return await _dataImp.Update(server_id, context);
            }
            else
            {
                context.created_date = DateTime.Now;
                context.created_id = client.i_id;
                return await _dataImp.Insert(server_id, context);
            }
        }
    }
}