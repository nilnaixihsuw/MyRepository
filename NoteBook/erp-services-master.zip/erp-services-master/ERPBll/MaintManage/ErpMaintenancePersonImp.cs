﻿using ERPCore.ORM;
using ERPDal.MaintManage;
using ERPModel.MaintManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using ERPBll.UserManage;
using ERPDal;
using ERPModel.UserManage;

namespace ERPBll.MaintManage
{
    public class ErpMaintenancePersonImp : BusinessRespository<ErpMaintenancePerson, IErpMaintenancePersonDataImp>, IBusinessRepository<ErpMaintenancePerson>, IErpMaintenancePersonImp
    {

        public ErpMaintenancePersonImp(IErpMaintenancePersonDataImp dataImp) : base(dataImp)
        {

        }

        public async Task<bool> AddMaintainEmp(string server_id, List<ErpMaintenancePerson> context)
        {
            return await _dataImp.AddMaintainEmp(server_id, context);
        }
    }
}