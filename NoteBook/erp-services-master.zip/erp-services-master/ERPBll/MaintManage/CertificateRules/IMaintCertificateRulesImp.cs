﻿using ERPModel.MaintManage.CertificateRules;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.MaintManage.CertificateRules
{
    public interface IMaintCertificateRulesImp
    {
        /// <summary>
        /// 查询
        /// </summary>
        Task<List<MaintCertificateRulesDto>> GetAsync(string server_id);

        /// <summary>
        /// 新增/编辑
        /// </summary>
        Task<MaintCertificateRulesDto> CreateOrUpdateAsync(string server_id, decimal? user_id, CreateOrUpdateMaintCertificateRules input);

        /// <summary>
        /// 更改可用状态
        /// </summary>
        Task<MaintCertificateRulesDto> UpdateStateAsync(string server_id, decimal? user_id, decimal id);

        /// <summary>
        /// 删除
        /// </summary>
        Task<bool> DeleteAsync(string server_id, List<decimal> ids);
    }
}
