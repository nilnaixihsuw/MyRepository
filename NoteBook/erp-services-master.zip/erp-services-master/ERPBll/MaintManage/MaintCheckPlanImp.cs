﻿using ERPCore.ORM;
using ERPDal.MaintManage;
using ERPModel.MaintManage;
using ERPModel.Vehicleinfomanage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ERPBll.MaintManage
{
    public class MaintCheckPlanImp : BusinessRespository<MaintCheckPlan, IMaintCheckPlanDataImp>, IBusinessRepository<MaintCheckPlan>, IMaintCheckPlanImp
    {
        private readonly IMaintCheckPlanDataImp _dataImp;

        public MaintCheckPlanImp(IMaintCheckPlanDataImp dataImp) : base(dataImp)
        {
            _dataImp = dataImp;
        }


    }
}