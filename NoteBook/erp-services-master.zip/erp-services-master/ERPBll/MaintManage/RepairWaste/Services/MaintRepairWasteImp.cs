﻿using AutoMapper;
using ERPBll.MaintManage.RepairWaste.Contracts;
using ERPDal;
using ERPModel.MaintManage.RepairWaste;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.MaintManage.RepairWaste.Services
{
    public class MaintRepairWasteImp : IMaintRepairWasteImp
    {
        private readonly IMapper _imapper;
        public MaintRepairWasteImp(
            IMapper imapper)
        {
            _imapper = imapper;
        }

        /// <summary>
        /// 分页查询
        /// </summary>
        public async Task<(List<MaintRepairWasteDto>, int)> GetByPageAsync(MaintRepairWasteQuery query)
        {
            RefAsync<int> totalCount = 0;

            var list = await SqlSugarHelper.DBClient(query.server_id)
                                .Queryable<MaintRepairWaste>()
                                .Where(query.ToExp())
                                .ToPageListAsync(query.page_index, query.page_size, totalCount);

            var data = _imapper.Map<List<MaintRepairWaste>, List<MaintRepairWasteDto>>(list);
            return (data, totalCount);
        }

        /// <summary>
        /// 新增/编辑
        /// </summary>
        public async Task<MaintRepairWasteDto> CreateOrUpdateAsync(string server_id, decimal? user_id, CreateOrUpdateMaintRepairWaste input)
        {
            if (input.type == 0 || (string.IsNullOrWhiteSpace(input.specifications) && (input.type == 1 || input.type == 3)) || 
                string.IsNullOrWhiteSpace(input.unit) || !input.recycle_date.HasValue || !input.recycle_weight.HasValue)
            {
                throw new Exception("必填项不能为空");
            }

            if (input.id.HasValue && input.id != 0)
            {
                var info = await SqlSugarHelper.DBClient(server_id)
                                   .Queryable<MaintRepairWaste>()
                                   .FirstAsync(x => x.id == input.id);

                if (info == null)
                {
                    throw new Exception($"未找到回收废料信息，id={input.id}");
                }

                _imapper.Map(input, info);
                info.SetUpdate(user_id);

                await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync();

                var data = _imapper.Map<MaintRepairWaste, MaintRepairWasteDto>(info);
                return data;
            }
            else
            {
                var info = _imapper.Map<CreateOrUpdateMaintRepairWaste, MaintRepairWaste>(input);
                info.id = Tools.GetEngineID(server_id);
                info.SetCreate(user_id);

                //添加外修信息
                await SqlSugarHelper.DBClient(server_id).Insertable(info).ExecuteCommandAsync();

                var data = _imapper.Map<MaintRepairWaste, MaintRepairWasteDto>(info);
                return data;
            }
        }

        /// <summary>
        /// 删除
        /// </summary>
        public async Task<bool> DeleteAsync(string server_id, List<decimal> ids)
        {
            var res = await SqlSugarHelper.DBClient(server_id)
                            .Deleteable<MaintRepairWaste>()
                            .Where(x => ids.Contains(x.id))
                            .ExecuteCommandAsync() > 0;

            return res;
        }
    }
}
