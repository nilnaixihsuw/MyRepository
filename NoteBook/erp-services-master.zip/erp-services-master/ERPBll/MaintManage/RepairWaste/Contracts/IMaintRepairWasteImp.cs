﻿using ERPModel.MaintManage.RepairWaste;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.MaintManage.RepairWaste.Contracts
{
    public interface IMaintRepairWasteImp
    {
        /// <summary>
        /// 分页查询
        /// </summary>
        Task<(List<MaintRepairWasteDto>, int)> GetByPageAsync(MaintRepairWasteQuery query);

        /// <summary>
        /// 新增/编辑
        /// </summary>
        Task<MaintRepairWasteDto> CreateOrUpdateAsync(string server_id, decimal? user_id, CreateOrUpdateMaintRepairWaste input);

        /// <summary>
        /// 删除
        /// </summary>
        Task<bool> DeleteAsync(string server_id, List<decimal> ids);
    }
}
