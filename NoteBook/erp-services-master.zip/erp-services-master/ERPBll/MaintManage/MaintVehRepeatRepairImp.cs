﻿using ERPDal.Repository;
using ERPModel.MaintManage;
using System;
using System.Collections.Generic;
using System.Text;

namespace ERPBll.MaintManage
{
    public class MaintVehRepeatRepairImp : BaseBusiness<MaintVehRepeatRepair>, IMaintVehRepeatRepairImp
    {

    }
}
