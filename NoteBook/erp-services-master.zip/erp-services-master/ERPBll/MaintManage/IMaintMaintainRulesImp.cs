﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPModel.ApiModel;
using ERPModel.MaintManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.MaintManage
{
    public interface IMaintMaintainRulesImp : IBusinessRepository<MaintMaintainRules>
    {
        Task<bool> AddRule(string server_id, MaintMaintainRules context, IClientInformation client);
        Task<bool> DeleteRule(string server_id, List<int> context);
        Task<bool> EnabRule(string server_id, int id, int enable);
    }
}