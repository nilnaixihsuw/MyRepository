﻿using ERPCore;
using ERPCore.Entity;
using ERPCore.Extensions;
using ERPCore.ORM;
using ERPDal.MaintManage;
using ERPDal.SystemManage;
using ERPDal.Vehicleinfomanage;
using ERPModel.MaintManage;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.MaintManage
{
    public class ErpChargeSummaryExcelImp : ExcelImportRepository<ErpChargeSummary>, IErpChargeSummaryExcelImp
    {
        private readonly IErpChargeSummaryDataImp _iErpChargeSummaryDataImp;
        private readonly IVehicleInfoDataImp _iVehicleInfoDataImp;
        private readonly IErpChargeStationDataImp _iErpChargeStationDataImp;

        public ErpChargeSummaryExcelImp(
            IErpChargeStationDataImp iErpChargeStationDataImp,
            IVehicleInfoDataImp iVehicleInfoDataImp,
            IErpChargeSummaryDataImp iErpChargeSummaryDataImp)
        {
            _iErpChargeStationDataImp = iErpChargeStationDataImp;
            _iVehicleInfoDataImp = iVehicleInfoDataImp;
            _iErpChargeSummaryDataImp = iErpChargeSummaryDataImp;
        }

        /// <summary>
        /// 导入源数据处理
        /// </summary>
        protected override Func<MemoryStream, DataTable> DisposeDTFunc => ms =>
        {
            // 去掉第一行
            var dt = ExcelImportHelper.ReadStreamToDataTable(ms, null, null, true, 0, 1);
            return dt;
        };

        /// <summary>
        /// 数据转化为LIST
        /// </summary>
        /// <returns></returns>
        protected override ExcelImportRepository<ErpChargeSummary> TranToList()
        {
            try
            {
                var list = _dt.ToDataList<VehicelElectricImportTemp>();
                var records = new List<ErpChargeSummary>();
                list.ForEach(item =>
                {
                    decimal d = 0;
                    if (!string.IsNullOrEmpty(item.tldwd))
                    {
                        var record = new ErpChargeSummary();
                        record.month = _info.month;
                        record.created_id = _client.i_id;
                        record.created_date = DateTime.Now;
                        record.remark = "手动导入";
                        record.source = 1;
                        record.ex_lincense_plate_number = item.palte_number;
                        record.ex_station_name = "特来电万达";
                        if (decimal.TryParse(item.tldwd, out d))
                            record.val = d;
                        else record.val = 0;
                        records.Add(record);
                    }

                    if (!string.IsNullOrEmpty(item.tldaj))
                    {
                        var record = new ErpChargeSummary();
                        record.month = _info.month;
                        record.created_id = _client.i_id;
                        record.created_date = DateTime.Now;
                        record.remark = "手动导入";
                        record.source = 1;
                        record.ex_lincense_plate_number = item.palte_number;
                        record.ex_station_name = "特来电鳌江";
                        if (decimal.TryParse(item.tldaj, out d))
                            record.val = d;
                        else record.val = 0;
                        records.Add(record);
                    }

                    if (!string.IsNullOrEmpty(item.hhdaj))
                    {
                        var record = new ErpChargeSummary();
                        record.month = _info.month;
                        record.created_id = _client.i_id;
                        record.created_date = DateTime.Now;
                        record.remark = "手动导入";
                        record.source = 1;
                        record.ex_lincense_plate_number = item.palte_number;
                        record.ex_station_name = "海汇德鳌江";
                        if (decimal.TryParse(item.hhdaj, out d))
                            record.val = d;
                        else record.val = 0;
                        records.Add(record);
                    }

                    if (!string.IsNullOrEmpty(item.hhdst))
                    {
                        var record = new ErpChargeSummary();
                        record.month = _info.month;
                        record.created_id = _client.i_id;
                        record.created_date = DateTime.Now;
                        record.remark = "手动导入";
                        record.source = 1;
                        record.ex_lincense_plate_number = item.palte_number;
                        record.ex_station_name = "海汇德水头";
                        if (decimal.TryParse(item.hhdst, out d))
                            record.val = d;
                        else record.val = 0;
                        records.Add(record);
                    }

                    if (!string.IsNullOrEmpty(item.hhdxj))
                    {
                        var record = new ErpChargeSummary();
                        record.month = _info.month;
                        record.created_id = _client.i_id;
                        record.created_date = DateTime.Now;
                        record.remark = "手动导入";
                        record.source = 1;
                        record.ex_lincense_plate_number = item.palte_number;
                        record.ex_station_name = "海汇德萧江";
                        if (decimal.TryParse(item.hhdxj, out d))
                            record.val = d;
                        else record.val = 0;
                        records.Add(record);
                    }

                    if (!string.IsNullOrEmpty(item.ytxt))
                    {
                        var record = new ErpChargeSummary();
                        record.month = _info.month;
                        record.created_id = _client.i_id;
                        record.created_date = DateTime.Now;
                        record.remark = "手动导入";
                        record.source = 1;
                        record.ex_lincense_plate_number = item.palte_number;
                        record.ex_station_name = "宇通系统";
                        if (decimal.TryParse(item.ytxt, out d))
                            record.val = d;
                        else record.val = 0;
                        records.Add(record);
                    }

                    if (!string.IsNullOrEmpty(item.cdw))
                    {
                        var record = new ErpChargeSummary();
                        record.month = _info.month;
                        record.created_id = _client.i_id;
                        record.created_date = DateTime.Now;
                        record.remark = "手动导入";
                        record.source = 1;
                        record.ex_lincense_plate_number = item.palte_number;
                        record.ex_station_name = "车电网";
                        if (decimal.TryParse(item.cdw, out d))
                            record.val = d;
                        else record.val = 0;
                        records.Add(record);
                    }
                });

                this._list = records;
                _task.insert_count = _list.Count;
                return this;
            }
            catch (Exception ex)
            {
                throw new Exception("转化成LIST<T>" + ex.Message);
            }

        }


        /// <summary>
        /// 单行检测
        /// </summary>
        protected override Dictionary<string, Func<ErpChargeSummary, Tuple<bool, string>>> SelfDefinedCheckFunc => new Dictionary<string, Func<ErpChargeSummary, Tuple<bool, string>>>
        {

        };

        /// <summary>
        /// 整体检测
        /// </summary>
        protected override Dictionary<string, Func<List<ErpChargeSummary>, Tuple<bool, string>>> SelfDefinedCheckFuncPlus => new Dictionary<string, Func<List<ErpChargeSummary>, Tuple<bool, string>>>
        {
            { "车辆存在性检测",e=>{
                // 检查车牌号
                var cars = _iVehicleInfoDataImp.ExtList(_info.server_id, _iVehicleInfoDataImp.List(_info.server_id
                    ,it=>SqlFunc.ContainsArray(e.Select(it=>it.ex_lincense_plate_number).ToList(),it.c_lincense_plate_number)
                    ,new string[]{"I_ID","C_LINCENSE_PLATE_NUMBER", "C_VEHICLE_NUMBER" }
                ).Result).Result;
                e.ForEach(item=>{
                    if (cars.Count > 0 && cars.Exists(it => it.c_lincense_plate_number == item.ex_lincense_plate_number)&& cars.Exists(it => it.ex_type =="纯电动" ))
                    {
                        var car=cars.Find(it => it.c_lincense_plate_number == item.ex_lincense_plate_number);
                        item.vehicle_id=car.i_id;
                        item.line_id=car.line_id;
                    }
                });
                if (e.Exists(it => it.vehicle_id == null))
                {
                    var msg= string.Join(",", e.Where(it => it.vehicle_id == null).Select(it=>it.ex_lincense_plate_number+"|"+it.ex_vehicle_number));
                    return new Tuple<bool, string>(false,msg + "系统不存在!");
                }

                return new Tuple<bool, string>(true,$"车辆检测成功!");
            }},
            { "充电站存在性检测", e =>{
                // 检查车牌号
                var stations= _iErpChargeStationDataImp.List(_info.server_id,it=>SqlFunc.ContainsArray(e.Select(it=>it.ex_station_name).ToList(),it.name),new string[]{"I_ID","C_NAME" }).Result;
                e.ForEach(item=>{
                    if (stations.Count > 0 && stations.Exists(it => it.name == item.ex_station_name))
                    {
                        item.station_id=stations.Find(it => it.name == item.ex_station_name).id;
                    }
                });
                if (e.Exists(it => it.station_id == null))
                {
                    var msg= string.Join(",", e.Where(it => it.station_id == null).Select(it=>it.ex_station_name));
                    return new Tuple<bool, string>(false,msg + "系统不存在!");
                }
                return new Tuple<bool, string>(true,$"充电站检测成功");
            }}
        };

        /// <summary>
        /// 保存数据
        /// </summary>
        protected override Func<List<ErpChargeSummary>, Task<bool>> SaveRecord => async list =>
        {
            var r = false;
            // 判断车辆,月份,充电站
            var olds = await _iErpChargeSummaryDataImp.List(_info.server_id
                , it => SqlFunc.ContainsArray(list.Select(c => c.vehicle_id).ToList(), it.vehicle_id)
                    && SqlFunc.ContainsArray(list.Select(c => c.station_id).ToList(), it.station_id)
                    && it.month == _info.month
            );

            var updates = list.Where(it => olds.Select(c => c.vehicle_id).Contains(it.vehicle_id)
                  && olds.Select(c => c.station_id).Contains(it.station_id)
                  && olds.Select(c => c.month).Contains(it.month)
            ).ToList();
            var inserts = new List<ErpChargeSummary>();
            if (updates.Count > 0)
            {
                inserts = list.Except(updates).ToList();
            }
            else
            {
                inserts = list;
            }
            _task.insert_count = inserts.Count;

            // 插入新增
            if (inserts.Count > 0)
            {
                r = await _iErpChargeSummaryDataImp.Insertable(_info.server_id, inserts);
            }

            // 更新
            updates.ForEach(item =>
            {
                if (olds.Exists(it => it.vehicle_id == item.vehicle_id && it.station_id == item.station_id && it.month == item.month))
                {
                    if (_info.type == 1)
                    {
                        item.id = olds.Find(it => it.vehicle_id == item.vehicle_id && it.station_id == item.station_id && it.month == item.month).id;
                        _task.update_count++;
                    }

                }
            });
            if (updates.Count > 0)
            {
                r = await _iErpChargeSummaryDataImp.Updatetable(_info.server_id, updates);
            }
            return r;
        };

        /// <summary>
        /// 汇总信息
        /// </summary>
        protected override Func<List<ErpChargeSummary>, string> GetSummary => list =>
        {
            string msg = string.Format("本次导入数据{0}条,覆盖{1}条", _task.insert_count, _task.update_count);
            return msg;
        };
    }
}
