﻿using AutoMapper;
using ERPBll.MaintManage.RepairOut.Contracts;
using ERPBll.RedisManage.Extension;
using ERPDal;
using ERPModel.MaintManage.RepairOut;
using ERPModel.UserManage;
using ERPModel.Vehicleinfomanage;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.MaintManage.RepairOut.Services
{
    public class MaintRepairOutImp : IMaintRepairOutImp
    {
        private readonly IMapper _imapper;
        private readonly IWarehouseRedisManageImp _iWarehouseRedisManageImp;
        public MaintRepairOutImp(
            IMapper imapper,
            IWarehouseRedisManageImp iWarehouseRedisManageImp)
        {
            _imapper = imapper;
            _iWarehouseRedisManageImp = iWarehouseRedisManageImp;
        }

        /// <summary>
        /// 查看详情
        /// </summary>
        public async Task<MaintRepairOutDto> LookAsync(string server_id, decimal? id)
        {
            if (!id.HasValue || id == 0)
            {
                throw new Exception("id为空");
            }
            var info = await SqlSugarHelper.DBClient(server_id)
                   .Queryable<MaintRepairOut>()
                   .Where(x => x.id == id)
                   .Mapper(x =>
                   {
                        x.vehicle_info = SqlSugarHelper.DBClient(server_id)
                                                .Queryable<ErpVehicleInfo>()
                                                .Where(it => it.i_id == x.vehicle_id)
                                                .First();

                        if (x.vehicle_info != null)
                        {
                            x.department = SqlSugarHelper.DBClient(server_id)
                                                .Queryable<SysDepartment>()
                                                .Where(it => it.i_id ==
                                                        Convert.ToInt32(x.vehicle_info.c_crews_take))
                                                .Select(it => it.c_name)
                                                .First();

                            x.vehicle_kind = SqlSugarHelper.DBClient(server_id)
                                                .Queryable<MaintVehicleKind>()
                                                .Where(it => it.i_id == x.vehicle_info.c_id)
                                                .Select(it => it.c_name)
                                                .First();
                        }
                   })
                   .Mapper(x => x.repair_unit_info, x => x.repair_unit)
                   .Mapper(x => x.repair_user, x => x.repair_user_id)
                   .Mapper(x => x.check_info, x => x.check_id)
                   .Mapper(x => x.update_info, x => x.update_id)
                   .FirstAsync();
            if (info == null)
            {
                throw new Exception($"未找到信息，id={id}");
            }

            var materialList = await SqlSugarHelper.DBClient(server_id)
                   .Queryable<MaintRepairOutMaterial>()
                   .Where(x => x.repair_out_id == id)
                   .ToListAsync();

            var repairOut = _imapper.Map<MaintRepairOut, MaintRepairOutDto>(info);
            repairOut.MaterialList = _imapper.Map<List<MaintRepairOutMaterial>, List<MaintRepairOutMaterialDto>>(materialList);
            return repairOut;
        }

        /// <summary>
        /// 撤销
        /// </summary>
        public async Task<bool> RevokeAsync(string server_id, decimal? user_id, decimal? id)
        {
            if (!id.HasValue || id == 0)
            {
                throw new Exception("id为空");
            }
            var info = await SqlSugarHelper.DBClient(server_id)
                   .Queryable<MaintRepairOut>()
                   .FirstAsync(x => x.id == id);
            if (info == null)
            {
                throw new Exception($"未找到信息，id={id}");
            }
            info.Revoke(user_id);

            //更新外修信息
            return await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync() > 0;
        }

        /// <summary>
        /// 新增
        /// </summary>
        public async Task<MaintRepairOutDto> AddAsync(string server_id, decimal? user_id, CreateOrUpdateMaintRepairOut input)
        {
            if (!input.vehicle_id.HasValue || input.vehicle_id == 0 || !input.repair_unit.HasValue || 
                input.repair_unit == 0 || !input.repair_user_id.HasValue || input.repair_user_id == 0 || !input.repair_time.HasValue)
            {
                throw new Exception("必填项不能为空");
            }
            input.MaterialList.ForEach(x => {
                if (string.IsNullOrWhiteSpace(x.name) || !x.count.HasValue || !x.price.HasValue || !x.total_fee.HasValue)
                {
                    throw new Exception("必填项不能为空");
                }
            });

            var info = _imapper.Map<CreateOrUpdateMaintRepairOut, MaintRepairOut>(input);
            info.id = ERPBll.Tools.GetEngineID(server_id);

            string orderCode = await _iWarehouseRedisManageImp.GetBatno(DateTime.Now, 3);
            if (string.IsNullOrWhiteSpace(orderCode))
            {
                info.order_code =  DateTime.Now.ToString("yyyyMMdd") + "0001";
                await _iWarehouseRedisManageImp.SetBatno(DateTime.Now, 1, 3);
            }
            else
            {
                info.order_code = orderCode;
            }

            var materialList = _imapper.Map<List<CreateOrUpdateMaintRepairOutMaterial>, List<MaintRepairOutMaterial>>(input.MaterialList);

            if (materialList != null && materialList.Count > 0)
            {
                materialList.ForEach(x => {
                    x.id = ERPBll.Tools.GetEngineID(server_id);
                    x.repair_out_id = info.id;
                    x.SetCreate(user_id);
                });
                //添加外修材料
                await SqlSugarHelper.DBClient(server_id).Insertable(materialList).ExecuteCommandAsync();
            }

            info.SetCreate(user_id);
            //添加外修信息
            await SqlSugarHelper.DBClient(server_id).Insertable(info).ExecuteCommandAsync();

            var repairOut = _imapper.Map<MaintRepairOut, MaintRepairOutDto>(info);
            repairOut.MaterialList = _imapper.Map<List<MaintRepairOutMaterial>, List<MaintRepairOutMaterialDto>>(materialList);
            return repairOut;
        }

        /// <summary>
        /// 删除
        /// </summary>
        public async Task<bool> DeleteAsync(string server_id, List<decimal> ids)
        {
            //删除外修信息
            var res = await SqlSugarHelper.DBClient(server_id)
                            .Deleteable<MaintRepairOut>()
                            .Where(x => ids.Contains(x.id))
                            .ExecuteCommandAsync() > 0;

            if (res)
            {
                //删除外修材料
                await SqlSugarHelper.DBClient(server_id)
                                .Deleteable<MaintRepairOutMaterial>()
                                .Where(x => ids.Contains(x.repair_out_id))
                                .ExecuteCommandAsync();
            }
            return res;
        }

        /// <summary>
        /// 分页查询
        /// </summary>
        public async Task<(List<MaintRepairOutDto>, int)> GetByPageAsync(string server_id, decimal? user_id, MaintRepairOutQuery query)
        {
            RefAsync<int> totalCount = 0;
            if (query.group_id != null && query.group_id.Count > 0)
            {
                var vehicles = await SqlSugarHelper.DBClient(server_id).Queryable<VehicleInfoNew>()
                    .Where(r => query.group_id.Contains(Convert.ToInt32(r.group))).ToListAsync();
                if (query.vehicle_ids == null || query.vehicle_ids.Count == 0)
                {
                    query.vehicle_ids = vehicles.Select(r => r.id).ToList();
                }
                else
                {
                    query.vehicle_ids.AddRange(vehicles.Select(r => r.id).ToList());
                }
            }

            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<MaintRepairOut>()
                                .Where(query.ToExp())
                                .Mapper(x => {
                                    x.vehicle_info = SqlSugarHelper.DBClient(server_id)
                                                                .Queryable<ErpVehicleInfo>()
                                                                .Where(it => it.i_id == x.vehicle_id)
                                                                .First();

                                    if (x.vehicle_info != null)
                                    {
                                        x.department = SqlSugarHelper.DBClient(server_id)
                                                                    .Queryable<SysDepartment>()
                                                                    .Where(it => it.i_id == 
                                                                        Convert.ToInt32(x.vehicle_info.c_crews_take))
                                                                    .Select(it => it.c_name)
                                                                    .First();

                                        x.vehicle_kind = SqlSugarHelper.DBClient(server_id)
                                                                    .Queryable<MaintVehicleKind>()
                                                                    .Where(it => it.i_id == x.vehicle_info.c_id)
                                                                    .Select(it => it.c_name)
                                                                    .First();
                                    }
                                    //x.MaterialList = SqlSugarHelper.DBClient(server_id)
                                    //                   .Queryable<MaintRepairOutMaterial>()
                                    //                   .Where(y => y.repair_out_id == x.id)
                                    //                   .ToList();
                                })
                                .Mapper(x => x.repair_unit_info, x => x.repair_unit)
                                .Mapper(x => x.repair_user, x => x.repair_user_id)
                                .Mapper(x => x.check_info, x => x.check_id)
                                .Mapper(x => x.update_info, x => x.update_id)
                                .OrderBy(x => x.repair_time, OrderByType.Desc)
                                .ToPageListAsync(query.page_index, query.page_size, totalCount);

            var data = _imapper.Map<List<MaintRepairOut>, List<MaintRepairOutDto>>(list);
            return (data, totalCount);
        }

        /// <summary>
        /// 编辑
        /// </summary>
        public async Task<MaintRepairOutDto> UpdateAsync(string server_id, decimal? user_id, CreateOrUpdateMaintRepairOut input)
        {
            if (!input.vehicle_id.HasValue || input.vehicle_id == 0 || !input.repair_unit.HasValue ||
                input.repair_unit == 0 || !input.repair_user_id.HasValue || input.repair_user_id == 0 || !input.repair_time.HasValue)
            {
                throw new Exception("必填项不能为空");
            }
            input.MaterialList.ForEach(x => {
                if (string.IsNullOrWhiteSpace(x.name) || !x.count.HasValue || !x.price.HasValue || !x.total_fee.HasValue)
                {
                    throw new Exception("必填项不能为空");
                }
            });

            var info = await SqlSugarHelper.DBClient(server_id)
                               .Queryable<MaintRepairOut>()
                               .FirstAsync(x => x.id == input.id);
            if (info == null)
            {
                throw new Exception($"未找到信息，id={input.id}");
            }

            //删除外修材料
            await SqlSugarHelper.DBClient(server_id)
                            .Deleteable<MaintRepairOutMaterial>()
                            .Where(x => x.repair_out_id == input.id)
                            .ExecuteCommandAsync();

            var materialList = _imapper.Map<List<CreateOrUpdateMaintRepairOutMaterial>, List<MaintRepairOutMaterial>>(input.MaterialList);

            if (input.MaterialList != null && input.MaterialList.Count > 0)
            {
                materialList.ForEach(x => {
                    x.id = ERPBll.Tools.GetEngineID(server_id);
                    x.repair_out_id = info.id;
                    x.SetCreate(user_id);
                });
                //添加外修材料
                await SqlSugarHelper.DBClient(server_id).Insertable(materialList).ExecuteCommandAsync();
            }

            _imapper.Map<CreateOrUpdateMaintRepairOut, MaintRepairOut>(input, info);
            info.SetUpdate(user_id);

            //更新外修信息
            await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync();

            var repairOut = _imapper.Map<MaintRepairOut, MaintRepairOutDto>(info);
            repairOut.MaterialList = _imapper.Map<List<MaintRepairOutMaterial>, List<MaintRepairOutMaterialDto>>(materialList);
            return repairOut;
        }

        /// <summary>
        /// 获取送修单位列表
        /// </summary>
        public async Task<List<MaintUnitDto>> GetRepairUnitAsync(string server_id)
        {
            var list = await SqlSugarHelper.DBClient(server_id)
                            .Queryable<MaintUnit>()
                            .ToListAsync();

            return _imapper.Map<List<MaintUnit>, List<MaintUnitDto>>(list);
        }

        ///// <summary>
        ///// 新增送修单位
        ///// </summary>
        //public async Task<MaintUnitDto> AddRepairUnitAsync(string server_id, decimal? user_id, CreateMaintUnit input)
        //{
        //    var info = _imapper.Map<CreateMaintUnit, MaintUnit>(input);
        //    info.id = ERPBll.Tools.GetEngineID(server_id);
        //    info.SetCreate(user_id);

        //    await SqlSugarHelper.DBClient(server_id).Insertable(info).ExecuteCommandAsync();

        //    return _imapper.Map<MaintUnit, MaintUnitDto>(info);
        //}

        ///// <summary>
        ///// 删除送修单位
        ///// </summary>
        //public async Task<bool> DeleteRepairUnitAsync(string server_id, List<decimal> ids)
        //{
        //    return await SqlSugarHelper.DBClient(server_id)
        //        .Deleteable<MaintUnit>()
        //        .Where(x => ids.Contains(x.id))
        //        .ExecuteCommandAsync() > 0;
        //}
    }
}
