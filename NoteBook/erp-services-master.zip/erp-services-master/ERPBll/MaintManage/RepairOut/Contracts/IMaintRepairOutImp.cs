﻿using ERPModel.MaintManage.RepairOut;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.MaintManage.RepairOut.Contracts
{
    public interface IMaintRepairOutImp
    {
        /// <summary>
        /// 分页查询
        /// </summary>
        Task<(List<MaintRepairOutDto>, int)> GetByPageAsync(
            string server_id, decimal? user_id, MaintRepairOutQuery query);

        /// <summary>
        /// 新增
        /// </summary>
        Task<MaintRepairOutDto> AddAsync(
            string server_id, decimal? user_id, CreateOrUpdateMaintRepairOut input);

        /// <summary>
        /// 编辑
        /// </summary>
        Task<MaintRepairOutDto> UpdateAsync(
            string server_id, decimal? user_id, CreateOrUpdateMaintRepairOut input); 

        /// <summary>
        /// 删除
        /// </summary>
        Task<bool> DeleteAsync(string server_id, List<decimal> ids);

        /// <summary>
        /// 查看详情
        /// </summary>
        Task<MaintRepairOutDto> LookAsync(string server_id, decimal? id);

        /// <summary>
        /// 撤销
        /// </summary>
        Task<bool> RevokeAsync(string server_id, decimal? user_id, decimal? id);

        /// <summary>
        /// 获取送修单位列表
        /// </summary>
        Task<List<MaintUnitDto>> GetRepairUnitAsync(string server_id);

        ///// <summary>
        ///// 新增送修单位
        ///// </summary>
        //Task<MaintUnitDto> AddRepairUnitAsync(string server_id, decimal? user_id, CreateMaintUnit input);

        ///// <summary>
        ///// 删除送修单位
        ///// </summary>
        //Task<bool> DeleteRepairUnitAsync(string server_id, List<decimal> id);
    }
}
