﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPModel.MaintManage;
using ERPModel.Vehicleinfomanage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.MaintManage
{
    public interface IMaintVehicleKindImp : IBusinessRepository<MaintVehicleKind>
    {
        Task<bool> AddMaintVehicleKind(string server_id, MaintVehicleKind context, ClientInformation client);
        Task<Tuple<List<MaintVehicleKind>,int>> QueryMaintVehicleKindPageList(string server_id, BaseRequest<MaintVehicleKind> request, string v);
        Task<List<MaintVehicleKind>> QueryMaintVehicleKindList(string server_id, BaseRequest<MaintVehicleKind> request, string v);
        Task<bool> BatchDelete(string server_id, List<decimal> context);
    }
}