﻿using ERPCore.ORM;
using ERPDal.MaintManage;
using ERPModel.MaintManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using ERPModel.CommonModel;
using System.Linq.Expressions;
using ERPDal;

namespace ERPBll.MaintManage
{
    public class ErpMaintenanceShopImp : BusinessRespository<ErpMaintenanceShop, IErpMaintenanceShopDataImp>, IBusinessRepository<ErpMaintenanceShop>, IErpMaintenanceShopImp
    {

        public ErpMaintenanceShopImp(IErpMaintenanceShopDataImp dataImp) : base(dataImp)
        {

        }

        public async Task<List<ErpMaintenanceShop>> GetShopInfo(string serverId, Expression<Func<ErpMaintenanceShop, bool>> expression)
        {
            return await SqlSugarHelper.DBClient(serverId).Queryable<ErpMaintenanceShop>()
                .WhereIF(expression != null, expression)
                .Mapper(r => r.dept_info, r => r.i_main_id)
                .ToListAsync();
        }
    }
}