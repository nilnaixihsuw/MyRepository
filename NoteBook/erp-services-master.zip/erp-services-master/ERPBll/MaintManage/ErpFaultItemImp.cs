﻿using ERPCore.ORM;
using ERPDal.MaintManage;
using ERPModel.MaintManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using Microsoft.AspNetCore.Http;
using System.IO;
using ERPCore;
using ERPCore.Extensions;

namespace ERPBll.MaintManage
{
    public class ErpFaultItemImp : BusinessRespository<ErpFaultItem, IErpFaultItemDataImp>, IBusinessRepository<ErpFaultItem>, IErpFaultItemImp
    {
        private readonly IErpFaultItemGroupDataImp _iERP_FAULT_ITEM_GROUP_DataImp;

        public ErpFaultItemImp(IErpFaultItemGroupDataImp iERP_FAULT_ITEM_GROUP_DataImp, IErpFaultItemDataImp dataImp) : base(dataImp)
        {
            _iERP_FAULT_ITEM_GROUP_DataImp = iERP_FAULT_ITEM_GROUP_DataImp;
        }

        public async Task<bool> AddMaintainDiagnosis(string server_id, ErpFaultItem context)
        {
            if (context.i_id != null && context.i_id > 0)
            {
                return await _dataImp.Update(server_id, context);
            }
            else
            {
                return await _dataImp.Insert(server_id, context);
            }
        }

        public async Task<bool> GroupSort(string server_id, List<ErpFaultItem> context)
        {
            return await _dataImp.Updatetable(server_id, context, new string[] { "I_ORDER" });
        }

        public async Task<bool> Import(string server_id, IFormFile file, int type)
        {
            var title = new Dictionary<string, string>()
            {
               { "故障项目名称", "c_name"},
               { "所属分类", "group_name"},
               { "编码", "c_code"},
               { "备注", "c_remark"}
            };

            var result = new byte[] { };
            //文件内容是否为空
            if (file.Length == 0)
                throw new Exception("文件不能为空!");

            //文件后缀
            string filename = file.FileName;
            var ext = filename.Substring(filename.LastIndexOf("."), filename.Length - filename.LastIndexOf("."));

            // 判断后缀
            if (ext != ".xlsx" && ext != ".xls")
            {
                throw new Exception("请上传Excel文件！");
            }

            using (var ms = new MemoryStream())
            {
                file.CopyTo(ms);
                ms.Position = 0;
                result = ms.ToArray();
            }
            var dt = ExcelImportHelper.ReadBytesToDataTable(result, title);
            var list = dt.ToDataList<ErpFaultItem>();
            var upList = new List<ErpFaultItem>();

            //检查必填项是否为空
            if (list.Exists(it => string.IsNullOrEmpty(it.c_name)))
                throw new Exception("故障项目名称不能为空!");
            if (list.Exists(it => string.IsNullOrEmpty(it.group_name)))
                throw new Exception("所属分类不能为空!");
            //if (list.Exists(it => it.i_hours == null))
            //    throw new Exception("工时不能为空!");

            var groups = await _iERP_FAULT_ITEM_GROUP_DataImp.List(server_id, it => true);

            list.ForEach(item =>
            {
                if (groups.Exists(it => it.c_name == item.group_name))
                {
                    item.i_group_id = groups.Find(it => it.c_name == item.group_name).i_id;
                }
                else
                {
                    throw new Exception("系统中不存在的故障项目类别!");
                }
            });

            //覆盖
            if (type == 1)
            {
                var emp = await _dataImp.List(server_id, it => SqlFunc.ContainsArray(list.Select(it => it.c_name).ToList(), it.c_name));
                if (emp != null && emp.Count > 0)
                {
                    list.ForEach(item =>
                    {
                        if (emp.Exists(it => it.c_name == item.c_name))
                        {
                            var e = emp.Find(it => it.c_name == item.c_name);
                            item.i_id = e.i_id;
                            upList.Add(item);
                        }
                    });
                    list = list.Except(list.Where(it => emp.Select(it => it.c_name).ToList().Contains(it.c_name))).ToList();
                }
            }
            //保持原数据
            if (type == 0)
            {

            }

            return await _dataImp.ImportMaintainDiagnosisData(server_id, list, upList);
        }
    }
}