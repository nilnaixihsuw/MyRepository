﻿using ERPCore.ORM;
using ERPDal.MaintManage;
using ERPModel.MaintManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using ERPCore.Intergration.VehicleCharge;
using AutoMapper;
using Microsoft.Extensions.Configuration;

namespace ERPBll.MaintManage
{
    public class IteEquipChargeStatusImp : BusinessRespository<IteEquipChargeStatus, IIteEquipChargeStatusDataImp>, IIteEquipChargeStatusImp
    {
        private readonly IMapper _iMapper;
        private readonly IntergrationConfig _config;
        private readonly IConfiguration _iConfiguration;
        public IteEquipChargeStatusImp(
            IMapper iMapper,
            IConfiguration iConfiguration,
            VehicleChargeIntergrationBase vehicleChargeIntergrationBase,
            IIteEquipChargeStatusDataImp dataImp) : base(dataImp)
        {
            _iMapper = iMapper;
            _iConfiguration = iConfiguration;
            _config = _iConfiguration.GetSection("IntergrationConfig").Get<IntergrationConfig>();
        }

        public async Task<bool> ReceiveEquipChargeStatus(EquipChargeStatus.Request equipCharges, IntergrationConfig config)
        {
            //处理接收的信息
            var ec = _iMapper.Map<EquipChargeStatus.Request, IteEquipChargeStatus>(equipCharges);
            ec.id = await _dataImp.GetId(_config.ServerID, "SEQ_COMMON");
            var details = new List<IteEquipChargeDetail>();
            if (equipCharges.ChargeDetails != null)
            {
                equipCharges.ChargeDetails.ForEach(item =>
                {
                    var detail = _iMapper.Map<EquipChargeDetail, IteEquipChargeDetail>(item);
                    detail.id = _dataImp.GetId(_config.ServerID, "SEQ_COMMON").Result;
                    detail.status_id = ec.id;
                    details.Add(detail);
                });
            }
            return await _dataImp.ReceiveEquipChargeStatus(_config.ServerID, ec, details);
        }


    }
}