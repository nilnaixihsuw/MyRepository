﻿using ERPCore.ORM;
using ERPDal.MaintManage;
using ERPModel.MaintManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ERPBll.MaintManage
{
    public class MaintHintTemplateImp : BusinessRespository<MaintHintTemplate, IMaintHintTemplateDataImp>, IBusinessRepository<MaintHintTemplate>, IMaintHintTemplateImp
    {
        private readonly IMaintHintTemplateDataImp _dataImp;

        public MaintHintTemplateImp(IMaintHintTemplateDataImp dataImp) : base(dataImp)
        {
            _dataImp = dataImp;
        }


    }
}