﻿using ERPCore.ORM;
using ERPDal.MaintManage;
using ERPModel.MaintManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using ERPDal.Vehicleinfomanage;

namespace ERPBll.MaintManage
{
    public class ErpEngineVehicleImp : BusinessRespository<ErpEngineVehicle, IErpEngineVehicleDataImp>, IBusinessRepository<ErpEngineVehicle>, IErpEngineVehicleImp
    {

        public ErpEngineVehicleImp(IVehicleInfoDataImp iVEHICLE_INFO_DataImp, IErpEngineVehicleDataImp dataImp) : base(dataImp)
        {

        }
    }
}