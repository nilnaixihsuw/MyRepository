﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPModel.ApiModel.MaintManage;
using ERPModel.MaintManage;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.MaintManage
{
    public interface IErpOilRecordImp : IBusinessRepository<ErpOilRecord>
    {
        Task<bool> AddErpOilRecord(string server_id, ErpOilRecord context, ClientInformation client);
        Task<Tuple<List<ErpOilRecord>, int>> QueryErpOilRecordPageList(string server_id, BaseRequest<ErpOilRecord> request, string v);
        Task<List<ErpOilRecord>> QueryErpOilRecordList(string server_id, BaseRequest<ErpOilRecord> request, string v);
        Task<bool> BatchDelete(string server_id, List<decimal> context);
        Task<bool> Import(string server_id, IFormFile file, int type, ClientInformation client);
        Task<Tuple<List<VehicelOilConsumeSummary>, int>> QueryPageVehicleOilSummaty(string server_id, ErpOilRecordSummaryRequest request, string v);
        Task<List<VehicelOilConsumeSummary>> QueryVehicleOilSummaty(string server_id, ErpOilRecordSummaryRequest request, string v);
    }
}