﻿using ERPCore;
using ERPCore.Entity;
using ERPCore.ORM;
using ERPDal.MaintManage;
using ERPModel.ApiModel;
using ERPModel.MaintManage;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ERPBll.MaintManage
{
    public class MaintDiscardRulesImp : BusinessRespository<MaintDiscardRules, IMaintDiscardRulesDataImp>, IBusinessRepository<MaintDiscardRules>, IMaintDiscardRulesImp
    {

        public MaintDiscardRulesImp(IMaintDiscardRulesDataImp dataImp) : base(dataImp)
        {
        }

        public async Task<bool> AddRule(string server_id, MaintDiscardRules context, IClientInformation client)
        {
            //报废条件检查
            var list = await _dataImp.List(server_id, it => true);
            list.ForEach(it =>
            {
                if ((context.i_age_condition_min < it.i_age_condition_min && it.i_age_condition_min < context.i_age_condition_max)
                    || (it.i_age_condition_max > context.i_age_condition_min && it.i_age_condition_max < context.i_age_condition_max))
                {
                    throw new Exception("年检条件与现有记录冲突！");
                }
            });

            context.d_create = DateTime.Now.ToLocalTime();
            context.i_create_user = client.i_id;
            return await _dataImp.AddRule(server_id, context);
        }

        public async Task<bool> DeleteRule(string server_id, List<int> context)
        {
            return await _dataImp.DeleteRule(server_id, context);
        }

        public async Task<bool> EnabRule(string server_id, int id, int enable)
        {
            if (enable != 1 && enable != 0)
            {
                throw new Exception("enable无效！");
            }
            var e = new MaintDiscardRules
            {
                i_id = id,
                i_valid = enable
            };
            return await _dataImp.Update(server_id, e,new string[] { "i_valid" });
        }
    }
}