﻿using ERPCore.ORM;
using ERPDal.MaintManage;
using ERPModel.MaintManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using ERPBll.UserManage;
using ERPModel.CommonModel;

namespace ERPBll.MaintManage
{
    public class ErpMaintenanceDepartmentImp : BusinessRespository<ErpMaintenanceDepartment, IErpMaintenanceDepartmentDataImp>, IBusinessRepository<ErpMaintenanceDepartment>, IErpMaintenanceDepartmentImp
    {

        public ErpMaintenanceDepartmentImp(IErpMaintenanceDepartmentDataImp dataImp) : base(dataImp)
        {

        }

        public async Task<bool> DeleteMaintainCJ(string server_id, string v)
        {
            return await _dataImp.DeleteMaintainCJ(server_id, v);
        }
    }
}