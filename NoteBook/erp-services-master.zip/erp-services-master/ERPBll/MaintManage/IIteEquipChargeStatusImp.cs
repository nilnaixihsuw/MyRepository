﻿using ERPCore.Intergration.VehicleCharge;
using ERPCore.ORM;
using ERPModel.MaintManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.MaintManage
{
    public interface IIteEquipChargeStatusImp : IBusinessRepository<IteEquipChargeStatus>
    {
        Task<bool> ReceiveEquipChargeStatus(EquipChargeStatus.Request equipCharges, IntergrationConfig config);
    }
}