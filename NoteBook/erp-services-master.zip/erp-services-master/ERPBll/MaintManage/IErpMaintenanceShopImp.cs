﻿using ERPCore.ORM;
using ERPModel.MaintManage;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.MaintManage
{
    public interface IErpMaintenanceShopImp : IBusinessRepository<ErpMaintenanceShop>
    {
        Task<List<ErpMaintenanceShop>> GetShopInfo(string serverId, Expression<Func<ErpMaintenanceShop, bool>> expression);
    }
}