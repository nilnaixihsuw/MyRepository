﻿using ERPCore.ORM;
using ERPDal.MaintManage;
using ERPModel.MaintManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;

namespace ERPBll.MaintManage
{
    public class ErpEngineLifeImp : BusinessRespository<ErpEngineLife, IErpEngineLifeDataImp>, IBusinessRepository<ErpEngineLife>, IErpEngineLifeImp
    {

        public ErpEngineLifeImp(IErpEngineLifeDataImp dataImp): base(dataImp)
        {
        }

    }
}