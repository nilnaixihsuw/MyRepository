﻿namespace ERPBll.MaintManage
{
    internal class IMaintHintTemplateDataim
    {
    }
}