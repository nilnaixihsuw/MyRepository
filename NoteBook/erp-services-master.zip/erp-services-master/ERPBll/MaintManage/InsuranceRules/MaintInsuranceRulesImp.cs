﻿using AutoMapper;
using ERPDal;
using ERPModel.MaintManage.InsuranceRules;
using ERPModel.UserManage;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.MaintManage.InsuranceRules
{
    public class MaintInsuranceRulesImp : IMaintInsuranceRulesImp
    {
        private readonly IMapper _imapper;
        public MaintInsuranceRulesImp(
            IMapper imapper)
        {
            _imapper = imapper;
        }

        /// <summary>
        /// 查询
        /// </summary>
        public async Task<List<MaintInsuranceRulesDto>> GetAsync(string server_id)
        {
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<MaintInsuranceRules>()
                                .Mapper(async x =>
                                {
                                    if (string.IsNullOrWhiteSpace(x.warn_person))
                                    {
                                        x.warn_person_list = null;
                                    }
                                    else if (x.warn_person == "-1")
                                    {
                                        x.warn_person_list = await SqlSugarHelper.DBClient(server_id)
                                                                    .Queryable<SysPerson>()
                                                                    .ToListAsync();
                                    }
                                    else
                                    {
                                        var pids = x.warn_person.Split(",").Select(p => Convert.ToDecimal(p)).ToList();
                                        x.warn_person_list = await SqlSugarHelper.DBClient(server_id)
                                                                    .Queryable<SysPerson>()
                                                                    .Where(y => pids.Contains(y.i_id.Value))
                                                                    .ToListAsync();
                                    }
                                })
                                .ToListAsync();

            return _imapper.Map<List<MaintInsuranceRules>, List<MaintInsuranceRulesDto>>(list);
        }

        /// <summary>
        /// 新增/编辑
        /// </summary>
        public async Task<MaintInsuranceRulesDto> CreateOrUpdateAsync(
            string server_id, decimal? user_id, CreateOrUpdateMaintInsuranceRules input)
        {
            if (input.id.HasValue && input.id != 0)
            {
                var info = await SqlSugarHelper.DBClient(server_id)
                   .Queryable<MaintInsuranceRules>()
                   .FirstAsync(x => x.id == input.id);

                if (info == null)
                {
                    throw new Exception($"未找到保险到期提醒规则，id={input.id}");
                }

                _imapper.Map(input, info);
                info.SetUpdate(user_id);

                await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync();

                return _imapper.Map<MaintInsuranceRules, MaintInsuranceRulesDto>(info);
            }
            else
            {
                var info = _imapper.Map<CreateOrUpdateMaintInsuranceRules, MaintInsuranceRules>(input);

                info.id = Tools.GetEngineID(server_id);
                info.SetCreate(user_id);

                await SqlSugarHelper.DBClient(server_id).Insertable(info).ExecuteCommandAsync();

                return _imapper.Map<MaintInsuranceRules, MaintInsuranceRulesDto>(info);
            }
        }

        /// <summary>
        /// 更改可用状态
        /// </summary>
        public async Task<MaintInsuranceRulesDto> UpdateStateAsync(
            string server_id, decimal? user_id, decimal id)
        {
            var info = await SqlSugarHelper.DBClient(server_id)
               .Queryable<MaintInsuranceRules>()
               .FirstAsync(x => x.id == id);

            if (info == null)
            {
                throw new Exception($"未找到保险到期提醒规则，id={id}");
            }

            info.valid = info.valid == 0 ? 1 : 0;
            info.SetUpdate(user_id);

            await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync();

            return _imapper.Map<MaintInsuranceRules, MaintInsuranceRulesDto>(info);
        }

        /// <summary>
        /// 删除
        /// </summary>
        public async Task<bool> DeleteAsync(string server_id, List<decimal> ids)
        {
            var res = await SqlSugarHelper.DBClient(server_id)
                            .Deleteable<MaintInsuranceRules>()
                            .Where(x => ids.Contains(x.id))
                            .ExecuteCommandAsync() > 0;

            return res;
        }
    }
}
