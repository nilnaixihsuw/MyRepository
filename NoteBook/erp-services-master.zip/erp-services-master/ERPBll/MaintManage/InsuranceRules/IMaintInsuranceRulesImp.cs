﻿using ERPModel.MaintManage.InsuranceRules;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.MaintManage.InsuranceRules
{
    public interface IMaintInsuranceRulesImp
    {
        /// <summary>
        /// 查询
        /// </summary>
        Task<List<MaintInsuranceRulesDto>> GetAsync(string server_id);

        /// <summary>
        /// 新增/编辑
        /// </summary>
        Task<MaintInsuranceRulesDto> CreateOrUpdateAsync(string server_id, decimal? user_id, CreateOrUpdateMaintInsuranceRules input);

        /// <summary>
        /// 更改可用状态
        /// </summary>
        Task<MaintInsuranceRulesDto> UpdateStateAsync(string server_id, decimal? user_id, decimal id);

        /// <summary>
        /// 删除
        /// </summary>
        Task<bool> DeleteAsync(string server_id, List<decimal> ids);
    }
}
