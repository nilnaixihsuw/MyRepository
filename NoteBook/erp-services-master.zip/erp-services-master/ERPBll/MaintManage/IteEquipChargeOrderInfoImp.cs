﻿using ERPCore.ORM;
using ERPDal.MaintManage;
using ERPModel.MaintManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using ERPCore.Intergration.VehicleCharge;
using AutoMapper;
using Microsoft.Extensions.Configuration;
using ERPDal.Vehicleinfomanage;
using ERPDal.SystemManage;
using ERPModel.SystemManage;

namespace ERPBll.MaintManage
{
    public class IteEquipChargeOrderInfoImp : BusinessRespository<IteEquipChargeOrderInfo, IIteEquipChargeOrderInfoDataImp>, IIteEquipChargeOrderInfoImp
    {
        private readonly IMapper _iMapper;
        private readonly IntergrationConfig _config;
        private readonly IConfiguration _iConfiguration;
        private readonly IIteEquipChargeStatusDataImp _iIteEquipChargeStatusDataImp;
        private readonly IVehicleInfoDataImp _iVehicleInfoDataImp;
        private readonly IErpChargeGunDataImp _iErpChargeGunDataImp;
        private readonly IErpChargeStationDataImp _iErpChargeStationDataImp;
        public IteEquipChargeOrderInfoImp(
            IErpChargeStationDataImp iErpChargeStationDataImp,
            IErpChargeGunDataImp iErpChargeGunDataImp,
            IIteEquipChargeStatusDataImp iIteEquipChargeStatusDataImp,
            IVehicleInfoDataImp iVehicleInfoDataImp,
            IMapper iMapper,
            IConfiguration iConfiguration,
            IIteEquipChargeOrderInfoDataImp dataImp) : base(dataImp)
        {
            _iErpChargeStationDataImp = iErpChargeStationDataImp;
            _iErpChargeGunDataImp = iErpChargeGunDataImp;
            _iMapper = iMapper;
            _iVehicleInfoDataImp = iVehicleInfoDataImp;
            _iConfiguration = iConfiguration;
            _config = _iConfiguration.GetSection("IntergrationConfig").Get<IntergrationConfig>();
            _iIteEquipChargeStatusDataImp = iIteEquipChargeStatusDataImp;
        }

        public async Task<bool> ReceiveChargeOrderInfo(ChargeOrderInfo.Request chargeOrderInfos, IntergrationConfig config)
        {
            //处理接收的信息
            var order = _iMapper.Map<ChargeOrderInfo.Request, IteEquipChargeOrderInfo>(chargeOrderInfos);
            order.id = await _dataImp.GetId(_config.ServerID, "SEQ_COMMON");
            var details = new List<IteEquipChargeDetail>();
            if (chargeOrderInfos.ChargeDetails != null)
            {
                chargeOrderInfos.ChargeDetails.ForEach(item =>
                {
                    var detail = _iMapper.Map<EquipChargeDetail, IteEquipChargeDetail>(item);
                    detail.id = _dataImp.GetId(_config.ServerID, "SEQ_COMMON").Result;
                    detail.order_id = order.id;
                    details.Add(detail);
                });
            }
            //插入车辆充电明细
            ErpChargeDetail detail = null;
            //var iteDetails = await _iIteEquipChargeStatusDataImp.List(_config.ServerID, it => it.start_charge_seq == order.start_charge_seq);
            //if (iteDetails != null && iteDetails.Count > 0)
            //{
            var id = await _dataImp.GetId(_config.ServerID, "SEQ_COMMON");
            var car = await _iVehicleInfoDataImp.List(_config.ServerID, it => it.c_lincense_plate_number == order.licenseplate);
            if (car != null && car.Count > 0)
            {
                var guns = await _iErpChargeGunDataImp.List(_config.ServerID, it => it.platform_code == order.connectorid);
                var gun = new ErpChargeGun();
                var station = new ErpChargeStation();
                if (guns != null && guns.Count > 0)
                {
                    gun = guns.Find(it => it.platform_code == order.connectorid);
                    station = await _iErpChargeStationDataImp.Get(_config.ServerID, gun.station_id);
                }
                detail = new ErpChargeDetail
                {
                    id = id,
                    vehicle_id = car.FirstOrDefault().i_id,
                    order_code = order.start_charge_seq,
                    station_id = gun.station_id,
                    pile_id = gun.pile_id,
                    begin_time = DateTime.Parse(order.start_time),
                    end_time = DateTime.Parse(order.end_time),
                    charge_fee = order.total_power * (station.service_fee == null ? 0 : station.service_fee + station.price == null ? 0 : station.price),
                    electric_quantity = order.total_power,
                    service_fee_avg = station.service_fee,
                    charge_time = (DateTime.Parse(order.end_time) - DateTime.Parse(order.start_time)).TotalMinutes,
                    front_soc = order.begin_soc,
                    after_scc = order.end_soc,
                    created_id = 2000000,
                    created_date = DateTime.Now
                };
            }
            //}
            return await _dataImp.ReceiveChargeOrderInfo(_config.ServerID, order, details, detail);
        }
    }
}