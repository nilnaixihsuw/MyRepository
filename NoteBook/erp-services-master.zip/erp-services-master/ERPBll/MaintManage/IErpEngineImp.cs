﻿using ERPCore.ORM;
using ERPModel.ApiModel;
using ERPModel.MaintManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.MaintManage
{
    public interface IErpEngineImp : IBusinessRepository<ErpEngine>
    {
        Task<bool> AddEngine(string server_id, AddEngine context);
        Task<EngineDetail> Detl(string server_id, decimal i_id);
        Task<bool> BatchDelete(string server_id, List<decimal> context);
        Task<Tuple<List<ErpEngine>, int>> QueryErpEngine(string server_id, EngineManageRequest request, string v, int page_size, int page_index, string orderby);
        Task<List<ErpEngine>> QueryErpEngine(string server_id, EngineManageRequest request, string v, string orderby);

        /// <summary>
        /// 获取车辆发动机记录
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="vehicle_ids"></param>
        /// <returns></returns>
        Task<List<EngineVehicleDto>> GetByVehId(string server_id, List<decimal?> vehicle_ids, bool current = false);

        Task<bool> BatchScrap(string server_id, List<ErpEngine> engines);
    }
}