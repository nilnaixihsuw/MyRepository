﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPDal.MaintManage;
using ERPModel.MaintManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using System.Linq.Expressions;
using ERPModel.Vehicleinfomanage;

namespace ERPBll.MaintManage
{
    public class MaintVehicleKindImp : BusinessRespository<MaintVehicleKind, IMaintVehicleKindDataImp>, IMaintVehicleKindImp
    {
        public MaintVehicleKindImp(IMaintVehicleKindDataImp dataImp): base(dataImp)
        {

        }

        public async Task<bool> AddMaintVehicleKind(string server_id, MaintVehicleKind context, ClientInformation client)
        {
            if (context.i_id > 0)
            {
                var old = await _dataImp.Get(server_id, context.i_id);
                return await _dataImp.Update(server_id, context);
            }
            else
            {
                return await _dataImp.Insert(server_id, context);
            }
        }

        public async Task<Tuple<List<MaintVehicleKind>,int>> QueryMaintVehicleKindPageList(string server_id, BaseRequest<MaintVehicleKind> request, string v)
        {
            var exp = await GetExp(request);
            return await ExtensionList(server_id, request.ToExp(exp), v, request.page_size, request.page_index, request.orderby);
        }

        public async Task<List<MaintVehicleKind>> QueryMaintVehicleKindList(string server_id, BaseRequest<MaintVehicleKind> request, string v)
        {
            var exp = await GetExp(request);
            return await ExtensionList(server_id, request.ToExp(exp), v, request.orderby);
        }

        public async Task<bool> BatchDelete(string server_id, List<decimal> context)
        {
            var list = await _dataImp.List(server_id, it => SqlFunc.ContainsArray(context, it.i_id));
            return await _dataImp.Deletetable(server_id, list);
        }

        private async Task<List<Expression<Func<MaintVehicleKind, bool>>>> GetExp(BaseRequest<MaintVehicleKind> request)
        {
            var r = new List<Expression<Func<MaintVehicleKind, bool>>>();
            
            return r;
        }
    }
}