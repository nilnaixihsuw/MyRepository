﻿using ERPCore.ORM;
using ERPDal.MaintManage;
using ERPModel.MaintManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;

namespace ERPBll.MaintManage
{
    public class IteEquipChargeDetailImp : BusinessRespository<IteEquipChargeDetail, IIteEquipChargeDetailDataImp>, IIteEquipChargeDetailImp
    {
        public IteEquipChargeDetailImp(IIteEquipChargeDetailDataImp dataImp): base(dataImp)
        {

        }
    }
}