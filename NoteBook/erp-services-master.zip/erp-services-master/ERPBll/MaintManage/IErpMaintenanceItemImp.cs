﻿using ERPCore.ORM;
using ERPModel.ApiModel;
using ERPModel.MaintManage;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.MaintManage
{
    public interface IErpMaintenanceItemImp : IBusinessRepository<ErpMaintenanceItem>
    {
        Task<bool> AddMaintainProject(string server_id, ErpMaintenanceItem context);
        Task<bool> Import(string server_id, IFormFile file, int type);
        Task<bool> GroupSort(string server_id, List<ErpMaintenanceItem> context);
    }
}