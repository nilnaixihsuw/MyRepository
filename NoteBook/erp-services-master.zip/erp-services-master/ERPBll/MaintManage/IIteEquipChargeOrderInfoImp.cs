﻿using ERPCore.Intergration.VehicleCharge;
using ERPCore.ORM;
using ERPModel.MaintManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.MaintManage
{
    public interface IIteEquipChargeOrderInfoImp : IBusinessRepository<IteEquipChargeOrderInfo>
    {
        Task<bool> ReceiveChargeOrderInfo(ChargeOrderInfo.Request orderRequest, IntergrationConfig config);
    }
}