﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPModel.MaintManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.MaintManage
{
    public interface IErpChargeSummaryImp : IBusinessRepository<ErpChargeSummary>
    {
        Task<bool> AddErpChargeSummary(string server_id, ErpChargeSummary context, ClientInformation client);
        Task<Tuple<List<ErpChargeSummary>,int>> QueryErpChargeSummaryPageList(string server_id, BaseRequest<ErpChargeSummary> request, string v);
        Task<List<ErpChargeSummary>> QueryErpChargeSummaryList(string server_id, BaseRequest<ErpChargeSummary> request, string v);
        Task<bool> BatchDelete(string server_id, List<decimal> context);
    }
}