﻿using ERPCore.ORM;
using ERPDal.MaintManage;
using ERPModel.MaintManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;

namespace ERPBll.MaintManage
{
    public class ErpMaintenanceItemGroupImp : BusinessRespository<ErpMaintenanceItemGroup, IErpMaintenanceItemGroupDataImp>, IBusinessRepository<ErpMaintenanceItemGroup>, IErpMaintenanceItemGroupImp
    {


        public ErpMaintenanceItemGroupImp(IErpMaintenanceItemGroupDataImp dataImp) : base(dataImp)
        {

        }


    }
}