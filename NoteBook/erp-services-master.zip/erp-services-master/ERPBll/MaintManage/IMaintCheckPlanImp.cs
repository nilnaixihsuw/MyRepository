﻿using ERPCore.ORM;
using ERPModel.MaintManage;
using ERPModel.Vehicleinfomanage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.MaintManage
{
    public interface IMaintCheckPlanImp : IBusinessRepository<MaintCheckPlan>
    {
    }
}