﻿using ERPCore.ORM;
using ERPDal.MaintManage;
using ERPModel.MaintManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using ERPModel.ApiModel;

namespace ERPBll.MaintManage
{
    public class ErpMaintenanceMoldImp : BusinessRespository<ErpMaintenanceMold, IErpMaintenanceMoldDataImp>, IBusinessRepository<ErpMaintenanceMold>, IErpMaintenanceMoldImp
    {

        public ErpMaintenanceMoldImp(IErpMaintenanceMoldDataImp dataImp): base(dataImp)
        {
        }

        public Task<bool> AddMold(string server_id, AddPosition context)
        {
            throw new NotImplementedException();
        }
    }
}