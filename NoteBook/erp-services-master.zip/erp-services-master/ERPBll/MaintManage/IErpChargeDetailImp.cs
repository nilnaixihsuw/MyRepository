﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPModel.ApiModel;
using ERPModel.MaintManage;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.MaintManage
{
    public interface IErpChargeDetailImp : IBusinessRepository<ErpChargeDetail>
    {
        /// <summary>
        /// 导入
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="file"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        Task<bool> Import(string server_id, IFormFile file, int type);

        /// <summary>
        /// 批量删除
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        Task<bool> BatchDelete(string server_id, List<decimal?> context);

        /// <summary>
        /// 获取车辆充电汇总统计
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="begin"></param>
        /// <param name="end"></param>
        /// <param name="vehicle_id"></param>
        /// <returns></returns>
        Task<ChargeFeeOverview> ChargeSummary(VehicleSummaryRequest request, IClientInformation client);

        /// <summary>
        /// 获取车辆充电汇总记录
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="page_size"></param>
        /// <param name="page_index"></param>
        /// <returns></returns>
        Task<Tuple<List<VehicleChargeSoc>, int>> ChargeSummary(string server_id, VehicleChargeSummaryRequest request, int page_size, int page_index);

        /// <summary>
        /// 获取车辆充电汇总记录
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="page_size"></param>
        /// <param name="page_index"></param>
        /// <returns></returns>
        Task<List<VehicleChargeSoc>> ChargeSummary(string server_id, VehicleChargeSummaryRequest request);

        /// <summary>
        /// 查询车辆充电记录
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="request"></param>
        /// <param name="v"></param>
        /// <param name="page_size"></param>
        /// <param name="page_index"></param>
        /// <param name="orderby"></param>
        /// <returns></returns>
        Task<Tuple<List<ErpChargeDetail>, int>> QueryErpChargeDetail(string server_id, VehicleChargeDetailRequest request, string v, int page_size, int page_index, string orderby);

        /// <summary>
        /// 查询车辆充电记录
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="request"></param>
        /// <param name="orderby"></param>
        /// <returns></returns>
        Task<List<ErpChargeDetail>> QueryErpChargeDetail(string server_id, VehicleChargeDetailRequest request, string where, string orderby);
        Task<bool> AddOrEdit(string server_id, ErpChargeDetail context, ClientInformation client);
    }
}