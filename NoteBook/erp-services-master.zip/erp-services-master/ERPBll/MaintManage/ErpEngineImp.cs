﻿using ERPCore.ORM;
using ERPDal.MaintManage;
using ERPModel.MaintManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using ERPDal.DataBase;
using ERPBll.DataBase;
using ERPModel.CommonModel;
using ERPModel.ApiModel;
using ERPCore;
using AutoMapper;
using ERPModel.UserManage;
using ERPDal.UserManage;
using ERPCore.Helpers;
using Microsoft.AspNetCore.Components;
using Microsoft.Extensions.Configuration;
using ERPDal.Vehicleinfomanage;
using ERPModel.Vehicleinfomanage;
using System.Linq.Expressions;
using ERPDal;

namespace ERPBll.MaintManage
{
    public class ErpEngineImp : BusinessRespository<ErpEngine, IErpEngineDataImp>, IErpEngineImp
    {
        private readonly IVehicleInfoDataImp _iVehicleInfoDataImp;
        private readonly IErpEngineVehicleDataImp _iErpEngineVehicleDataImp;
        private readonly IMapper _iMapper;
        private readonly IErpEngineLifeDataImp _iErpEngineLifeDataImp;
        private readonly IConfiguration _config;
        private readonly IErpEngineModelDataImp _iErpEngineModelDataImp;

        public ErpEngineImp(
            IErpEngineModelDataImp iErpEngineModelDataImp,
            IConfiguration iConfiguration,
            IErpEngineLifeDataImp iErpEngineLifeDataImp,
            IMapper iMapper,
            IErpEngineVehicleDataImp iErpEngineVehicleDataImp,
            IVehicleInfoDataImp iVehicleInfoDataImp,
            IErpEngineDataImp dataImp) : base(dataImp)
        {
            _iErpEngineModelDataImp = iErpEngineModelDataImp;
            _iVehicleInfoDataImp = iVehicleInfoDataImp;
            _iErpEngineVehicleDataImp = iErpEngineVehicleDataImp;
            _iMapper = iMapper;
            _iErpEngineLifeDataImp = iErpEngineLifeDataImp;
            _config = iConfiguration;
        }

        public async Task<bool> BatchScrap(string server_id, List<ErpEngine> context)
        {
            var engineLifes = new List<ErpEngineLife>();

            context.ForEach(item =>
            {
                //发动机报废
                engineLifes.Add(new ErpEngineLife
                {
                    i_id = ERPBll.Tools.GetEngineID(server_id),
                    i_engine_id = item.i_id,
                    c_content = "报废",
                    d_date = DateTime.Now
                });
            });

            return await _dataImp.BatchScrap(server_id, context, engineLifes);
        }

        public async Task<bool> AddEngine(string server_id, AddEngine context)
        {
            ErpVehicleInfo car = null;
            var engineLifes = new List<ErpEngineLife>();
            var engineDismantleVehicles = new List<ErpEngineVehicle>();
            var engineVehicles = new List<ErpEngineVehicle>();
            if (context.cars != null && context.cars.Count > 0)
            {
                car = await _iVehicleInfoDataImp.Get(server_id, context.cars[0]);
            }
            var engine = _iMapper.Map<AddEngine, ErpEngine>(context);
            if (context.orgs != null && context.orgs.Count > 0)
            {
                engine.i_department_id = context.orgs[0];
            }
            if (context.cars != null && context.cars.Count > 0)
            {
                engine.i_vehicle_id = context.cars[0];
            }

            if (context.i_id != null && context.i_id > 0)
            {
                var oldEngine = await _dataImp.Get(server_id, context.i_id);
                if (car != null)
                {
                    if (oldEngine.i_state == 3) throw new Exception("该发动机已报废!");
                    if (oldEngine.i_state == 4) throw new Exception("该发动机正在修理中!");

                    //编辑
                    //安装
                    if (oldEngine.i_state == 1 && context.type == 1) throw new Exception("该发动机已经安装!");
                    if (oldEngine.i_state == 2 && context.type == 1)
                    {
                        // 检测关联车辆是否已有发动机
                        var eCar = await _dataImp.List(server_id, it => it.i_vehicle_id == context.cars[0] && it.i_vehicle_id != oldEngine.i_vehicle_id);
                        if (eCar.Count > 0) throw new Exception("该车已安装发动机!");

                        engineLifes.Add(new ErpEngineLife
                        {
                            i_id = await _dataImp.GetId(server_id, "SEQ_COMMON"),
                            i_engine_id = engine.i_id,
                            c_content = "安装在[" + car.c_lincense_plate_number + "]",
                            d_date = context.d_mount
                        });
                        engine.i_state = 1; //使用中

                        var ev = _iMapper.Map<AddEngine, ErpEngineVehicle>(context);
                        ev.i_engine_id = engine.i_id;
                        ev.i_vehicle_id = engine.i_vehicle_id;
                        ev.c_remark = context.c_mount_remark;
                        ev.i_id = await _dataImp.GetId(server_id, "SEQ_COMMON");
                        ev.d_buy = context.d_mount;
                        //ev.n_mileage = 0;
                        engineVehicles.Add(ev);
                    }
                    //拆卸
                    if (oldEngine.i_state == 2 && context.type == 2) throw new Exception("请先安装发动机!");
                    if (oldEngine.i_state == 1 && context.type == 2)
                    {
                        if (context.d_dismantle != null)
                        {
                            var old = (await _dataImp.Get(server_id, context.i_id)).i_vehicle_id;
                            var oldCar = await _iVehicleInfoDataImp.Get(server_id, old);
                            if (oldCar == null) throw new Exception("该发动机未安装!");
                            //发动机安装
                            engineLifes.Add(new ErpEngineLife
                            {
                                i_id = await _dataImp.GetId(server_id, "SEQ_COMMON"),
                                i_engine_id = engine.i_id,
                                c_content = "从[" + oldCar.c_lincense_plate_number + "]上拆下",
                                d_date = context.d_dismantle
                            });

                            var oldList = await _iErpEngineVehicleDataImp.List(server_id, it => it.i_engine_id == engine.i_id && it.i_vehicle_id == oldCar.i_id);
                            var oldEngineVehicle = oldList.FirstOrDefault();
                            var ev = _iMapper.Map<AddEngine, ErpEngineVehicle>(context);
                            ev.i_engine_id = engine.i_id;
                            ev.i_vehicle_id = oldCar.i_id;
                            ev.c_remark = context.c_mount_remark;
                            ev.i_id = oldEngineVehicle.i_id;
                            ev.d_buy = oldEngineVehicle.d_buy;
                            ev.d_dismantle = context.d_dismantle;
                            //ev.n_mileage = UpdateMile(car.c_lincense_plate_number, oldEngine.d_buy);
                            engineDismantleVehicles.Add(ev);

                            engine.i_state = 2;
                            engine.i_vehicle_id = null;

                        }
                        else
                        {
                            engine.i_state = oldEngine.i_state;
                        }
                    }

                    //更换车辆
                    if (oldEngine.i_state == 1 && context.type == 3)
                    {
                        var eCar = await _dataImp.List(server_id, it => it.i_vehicle_id == context.cars[0] && it.i_vehicle_id != oldEngine.i_vehicle_id);
                        if (eCar.Count > 0) throw new Exception("该车已安装发动机!");

                        if (context.d_dismantle != null && context.d_mount != null)
                        {
                            var oldCar = await _iVehicleInfoDataImp.Get(server_id, oldEngine.i_vehicle_id);

                            //从老车拆卸
                            var ev = _iMapper.Map<AddEngine, ErpEngineVehicle>(context);
                            if (oldCar != null)
                            {
                                var oldEngineVehicle = (await _iErpEngineVehicleDataImp.List(server_id, it => it.i_engine_id == engine.i_id && it.i_vehicle_id == oldCar.i_id)).FirstOrDefault();
                                ev.i_engine_id = engine.i_id;
                                ev.i_vehicle_id = oldCar.i_id;
                                ev.c_remark = context.c_mount_remark;
                                ev.i_id = oldEngineVehicle.i_id;
                                ev.d_buy = oldEngineVehicle.d_buy;
                                ev.d_dismantle = context.d_dismantle;
                                //ev.n_mileage = UpdateMile(car.c_lincense_plate_number, oldEngine.d_buy);
                                engineDismantleVehicles.Add(ev);
                            }

                            //安装到新车上
                            ev = _iMapper.Map<AddEngine, ErpEngineVehicle>(context);
                            ev.i_engine_id = engine.i_id;
                            ev.i_vehicle_id = engine.i_vehicle_id;
                            ev.c_remark = context.c_mount_remark;
                            ev.i_id = await _dataImp.GetId(server_id, "SEQ_COMMON");
                            ev.d_buy = context.d_mount;
                            ev.d_dismantle = null;
                            //ev.n_mileage = UpdateMile(car.c_lincense_plate_number, oldEngine.d_buy);
                            engineVehicles.Add(ev);

                            //发动机安装
                            engineLifes.Add(new ErpEngineLife
                            {
                                i_id = await _dataImp.GetId(server_id, "SEQ_COMMON"),
                                i_engine_id = engine.i_id,
                                c_content = "从[" + oldCar.c_lincense_plate_number + "]上拆下 安装在[" + car.c_lincense_plate_number + "]",
                                d_date = context.d_dismantle
                            });

                            engine.i_state = 1;
                        }
                        else
                        {
                            engine.i_state = oldEngine.i_state;
                        }

                    }

                    if (oldEngine.i_state == 2 && context.type == 3) throw new Exception("请先安装发动机!");
                }
                else
                {
                    engine.i_state = oldEngine.i_state;
                }

                return await _dataImp.UpdateEngine(server_id, engine, engineVehicles, engineLifes, engineDismantleVehicles, context.type);
            }
            else
            {
                // 检测关联车辆是否已有发动机
                var eCar = await _dataImp.List(server_id, it => it.i_vehicle_id == context.cars[0]);
                if (eCar.Count > 0) throw new Exception("该车已安装发动机!");

                //新增
                engine.i_id = await _dataImp.GetId(server_id, "SEQ_COMMON");
                if (context.type != 1) { throw new Exception("该发动机需要先安装!"); }

                //发动机安装
                engineLifes.Add(new ErpEngineLife
                {
                    i_id = await _dataImp.GetId(server_id, "SEQ_COMMON"),
                    i_engine_id = engine.i_id,
                    c_content = "购买",
                    d_date = context.d_buy
                });
                if (car != null)
                {
                    var ev = _iMapper.Map<AddEngine, ErpEngineVehicle>(context);
                    ev.i_engine_id = engine.i_id;
                    ev.i_vehicle_id = engine.i_vehicle_id;
                    ev.c_remark = context.c_mount_remark;
                    ev.i_id = await _dataImp.GetId(server_id, "SEQ_COMMON");
                    ev.d_buy = context.d_mount;
                    engineVehicles.Add(ev);

                    engineLifes.Add(new ErpEngineLife
                    {
                        i_id = await _dataImp.GetId(server_id, "SEQ_COMMON"),
                        i_engine_id = engine.i_id,
                        c_content = "安装在[" + car.c_lincense_plate_number + "]",
                        d_date = context.d_mount
                    });
                    engine.i_state = 1; //使用中
                }
                else
                {
                    engine.i_state = 2; //闲置中
                }
                return await _dataImp.AddEngine(server_id, engine, engineVehicles, engineLifes);
            }
        }

        private decimal? UpdateMile(string plate_number, DateTime? buyDate)
        {
            decimal? r = 0;
            //需要从调度系统调用api更新erp_engine_vehicle的随车行驶里程
            var config = _config.GetSection("DispatchConfig").Get<DispatchConfig>();
            string para = new DispatchReq()
            {
                head = config,
                content = new DipatchContent
                {
                    begin_date = buyDate,
                    end_date = DateTime.Now,
                    vehicle_name = plate_number
                }
            }.ToString();
            var response = HttpHelper.HttpGet("http://" + config.server_id + ":" + config.port + "/" + config.url + "?req=" + para, null);
            return r;
        }

        public async Task<EngineDetail> Detl(string server_id, decimal i_id)
        {
            var r = new EngineDetail();
            var engine = await Get(server_id, i_id);

            //基本信息
            r.engine_base = _iMapper.Map<ErpEngine, EngineBase>(engine);
            r.engine_base.orgs = new DepartSlim[] { new DepartSlim {
                i_id=engine.i_department_id,
                c_name=engine.department_name,
                type=1
            } }.ToList();

            //安装车辆
            r.engine_vehicle = new EngineVehicle
            {
                i_state = engine.i_state,
            };

            if (engine.i_state == 1)        //使用中
            {
                var eVList = await _iErpEngineVehicleDataImp.ExtList(server_id, await _iErpEngineVehicleDataImp.List(server_id, it => it.i_engine_id == engine.i_id, ""));
                if (eVList != null && eVList.Count > 0)
                {
                    var engineVehicle = eVList.FirstOrDefault(it => it.i_id == eVList.Where(it => it.d_buy != null).Max(it => it.i_id));
                    if (engineVehicle != null)
                    {
                        r.engine_vehicle = _iMapper.Map<ErpEngineVehicle, EngineVehicle>(engineVehicle);
                        r.engine_vehicle.history = eVList.OrderBy(it => it.i_id).ToList();
                        if (engineVehicle != null)
                        {
                            r.engine_vehicle.cars = new CarTreeSlim[] {
                                new CarTreeSlim {
                                    i_id=engineVehicle.i_vehicle_id,
                                    c_name=engineVehicle.vehicle_plate_number,
                                    type=3
                                }
                            }.ToList();
                        }
                        r.engine_vehicle.i_state = engine.i_state;
                    }
                }
            }
            else           //其他状态
            {
                var eVList = await _iErpEngineVehicleDataImp.ExtList(server_id, await _iErpEngineVehicleDataImp.List(server_id, it => it.i_engine_id == engine.i_id, ""));
                if (eVList != null && eVList.Count > 0)
                {
                    var engineVehicle = eVList.FirstOrDefault(it => it.i_id == eVList.Where(it => it.d_dismantle != null).Max(it => it.i_id));
                    if (engineVehicle != null)
                    {
                        r.engine_vehicle = _iMapper.Map<ErpEngineVehicle, EngineVehicle>(engineVehicle);
                        if (r.engine_vehicle.cars == null || r.engine_vehicle.cars.Count == 0)
                        {
                            r.engine_vehicle.d_buy = null;
                            r.engine_vehicle.d_dismantle = null;
                            r.engine_vehicle.c_content = null;
                            r.engine_vehicle.c_remark = null;
                        }
                    }
                    r.engine_vehicle.i_state = engine.i_state;
                    r.engine_vehicle.history = eVList.OrderBy(it => it.i_id).ToList();
                }
            }

            //报废情况
            r.engine_scrape = new EngineScrpe
            {
                d_scrap = engine.d_scrap,
                c_scrap_reason = engine.c_scrap_reason
            };

            //生命周期
            var lifes = await _iErpEngineLifeDataImp.List(server_id, it => it.i_engine_id == engine.i_id);
            r.engine_life = new EngineLife
            {
                lifes = lifes.Select(it => new EngineLifeDetl
                {
                    c_content = it.c_content,
                    d_date = it.d_date
                }).OrderBy(it => it.d_date).ToList()
            };
            return r;
        }

        public async Task<bool> BatchDelete(string server_id, List<decimal> context)
        {
            var list = await _dataImp.List(server_id, it => SqlFunc.ContainsArray(context, it.i_id));

            var engineVehicles = await _iErpEngineVehicleDataImp.List(server_id, it => SqlFunc.ContainsArray(context, it.i_engine_id));

            var enginLifes = await _iErpEngineLifeDataImp.List(server_id, it => SqlFunc.ContainsArray(context, it.i_engine_id));

            return await _dataImp.BatchDelete(server_id, list, engineVehicles, enginLifes);
        }

        public async Task<Tuple<List<ErpEngine>, int>> QueryErpEngine(string server_id, EngineManageRequest request, string v, int page_size, int page_index, string orderby)
        {
            var exp = await GetExp(request);
            return await ExtensionList(server_id, request.ToExp(exp), v, page_size, page_index, orderby);
        }

        public async Task<List<ErpEngine>> QueryErpEngine(string server_id, EngineManageRequest request, string v, string orderby)
        {
            var exp = await GetExp(request);
            return await ExtensionList(server_id, request.ToExp(exp), v, orderby);
        }

        private async Task<List<Expression<Func<ErpEngine, bool>>>> GetExp(EngineManageRequest request)
        {
            var r = new List<Expression<Func<ErpEngine, bool>>>();
            //角色部门权限
            if (request.orgs != null)
            {
                if (request.orgs.Count > 0)
                {
                    r.Add(it => SqlFunc.ContainsArray(request.orgs, it.i_department_id));
                }
                else
                {
                    r.Add(it => false);
                }
            }
            else
            {
                r.Add(it => true);
            }
            if (!string.IsNullOrEmpty(request.engine_firm))
            {
                var engineTypes = await _iErpEngineModelDataImp.List(request.server_id, it => it.c_firm.Contains(request.engine_firm));
                if (engineTypes.Count > 0)
                {
                    r.Add(it => SqlFunc.ContainsArray(engineTypes.Select(it => it.i_id).ToList(), it.i_model_id));
                }
                else
                {
                    r.Add(it => false);
                }
            }
            //if (request.vehicle_ids != null && request.vehicle_ids.Count > 0)
            //{
            //    var engineVehicles = await _iErpEngineVehicleDataImp.List(request.server_id, it => SqlFunc.ContainsArray(request.vehicle_ids, it.i_vehicle_id));
            //    if (engineVehicles.Count > 0)
            //    {
            //        r.Add(it => SqlFunc.ContainsArray(engineVehicles.Select(it => it.i_engine_id).ToList(), it.i_id));
            //    }
            //    else
            //    {
            //        r.Add(it => false);
            //    }
            //}
            return r;
        }

        public async Task<List<EngineVehicleDto>> GetByVehId(string server_id, List<decimal?> vehicle_ids, bool current = false)
        {
            var list = await SqlSugarHelper.DBClient(server_id)
                               .Queryable<ErpEngineVehicle>()
                               .Where(x => vehicle_ids.Contains(x.i_vehicle_id))
                               .Mapper(async x =>
                               {
                                   x.engine_info = await SqlSugarHelper.DBClient(server_id)
                                                    .Queryable<ErpEngine>()
                                                    .FirstAsync(i => i.i_id == x.i_engine_id);

                                   if (x.engine_info != null)
                                   {
                                       var engine_model = await SqlSugarHelper.DBClient(server_id)
                                                        .Queryable<ErpEngineModel>()
                                                        .FirstAsync(i => i.i_id == x.engine_info.i_model_id);

                                       if (engine_model != null)
                                       {
                                           x.engine_info.engine_type = engine_model.c_name;
                                           x.engine_info.engine_band = engine_model.c_brand;
                                           x.engine_info.engine_firm = engine_model.c_firm;
                                           x.engine_info.engine_power = engine_model.i_power;
                                       }
                                   }
                               })
                               .OrderBy(x => x.d_buy, OrderByType.Desc)
                               .ToListAsync();
            if (current)
            {
                list = list.Where(it => it.d_buy == list.Max(it => it.d_buy) || it.d_dismantle == list.Max(it => it.d_dismantle)).ToList();
            }

            return _iMapper.Map<List<ErpEngineVehicle>, List<EngineVehicleDto>>(list);
        }

        public Task<bool> BatchScrap(string server_id, List<ErpEngine> engines, List<ErpEngineLife> engineLifes)
        {
            throw new NotImplementedException();
        }
    }
}