﻿using ERPCore.ORM;
using ERPModel.MaintManage;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.MaintManage
{
    public interface IErpFaultItemImp : IBusinessRepository<ErpFaultItem>
    {
        Task<bool> GroupSort(string server_id, List<ErpFaultItem> context);
        Task<bool> Import(string server_id, IFormFile file, int type);
        Task<bool> AddMaintainDiagnosis(string server_id, ErpFaultItem context);
    }
}