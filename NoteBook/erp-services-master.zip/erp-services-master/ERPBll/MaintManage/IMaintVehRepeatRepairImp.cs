﻿using ERPDal.Repository;
using ERPModel.MaintManage;
using System;
using System.Collections.Generic;
using System.Text;

namespace ERPBll.MaintManage
{
    public interface IMaintVehRepeatRepairImp : IBaseBusiness<MaintVehRepeatRepair>
    {

    }
}
