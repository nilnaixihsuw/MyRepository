﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPDal.MaintManage;
using ERPModel.MaintManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using System.Linq.Expressions;
using Microsoft.AspNetCore.Http;
using System.IO;
using ERPCore;
using ERPCore.Extensions;
using ERPDal.Vehicleinfomanage;
using ERPModel.ApiModel.MaintManage;
using ERPDal.SystemManage;

namespace ERPBll.MaintManage
{
    public class ErpOilRecordImp : BusinessRespository<ErpOilRecord, IErpOilRecordDataImp>, IErpOilRecordImp
    {
        private readonly IVehicleInfoDataImp _iVehicleInfoDataImp;
        private readonly IMaintVehicleKindDataImp _iMaintVehicleKindDataImp;
        private readonly ILineDataImp _iLineDataImp;

        public ErpOilRecordImp(
            ILineDataImp iLineDataImp,
            IMaintVehicleKindDataImp iMaintVehicleKindDataImp,
            IVehicleInfoDataImp iVehicleInfoDataImp,
            IErpOilRecordDataImp dataImp) : base(dataImp)
        {
            _iLineDataImp = iLineDataImp;
            _iVehicleInfoDataImp = iVehicleInfoDataImp;
            _iMaintVehicleKindDataImp = iMaintVehicleKindDataImp;
        }

        public async Task<bool> AddErpOilRecord(string server_id, ErpOilRecord context, ClientInformation client)
        {
            if (context.id > 0)
            {
                var old = await _dataImp.Get(server_id, context.id);
                context.created_id = old.created_id;
                context.created_date = old.created_date;
                context.update_date = DateTime.Now;
                context.update_id = client.i_id;
                return await _dataImp.Update(server_id, context);
            }
            else
            {
                context.created_date = DateTime.Now;
                context.created_id = client.i_id;
                return await _dataImp.Insert(server_id, context);
            }
        }

        public async Task<Tuple<List<ErpOilRecord>, int>> QueryErpOilRecordPageList(string server_id, BaseRequest<ErpOilRecord> request, string v)
        {
            var exp = await GetExp(request);
            return await ExtensionList(server_id, request.ToExp(exp), v, request.page_size, request.page_index, request.orderby);
        }

        public async Task<List<ErpOilRecord>> QueryErpOilRecordList(string server_id, BaseRequest<ErpOilRecord> request, string v)
        {
            var exp = await GetExp(request);
            return await ExtensionList(server_id, request.ToExp(exp), v, request.orderby);
        }

        public async Task<bool> BatchDelete(string server_id, List<decimal> context)
        {
            var list = await _dataImp.List(server_id, it => SqlFunc.ContainsArray(context, it.id));
            return await _dataImp.Deletetable(server_id, list);
        }

        private async Task<List<Expression<Func<ErpOilRecord, bool>>>> GetExp(BaseRequest<ErpOilRecord> request)
        {
            var r = new List<Expression<Func<ErpOilRecord, bool>>>();

            return r;
        }

        public async Task<bool> Import(string server_id, IFormFile file, int type, ClientInformation client)
        {
            var title = new Dictionary<string, string>()
            {
               { "车牌号", "ex_lincense_plate_number"},
               { "自编号", "ex_vehicle_number"},
               { "月份", "oil_date"},
               { "油耗", "value"},
               { "备注", "remark"}
            };

            var result = new byte[] { };
            //文件内容是否为空
            if (file.Length == 0)
                throw new Exception("文件不能为空");

            //文件后缀
            string filename = file.FileName;
            var ext = filename.Substring(filename.LastIndexOf("."), filename.Length - filename.LastIndexOf("."));

            // 判断后缀
            if (ext != ".xlsx" && ext != ".xls")
            {
                throw new Exception("请上传Excel文件！");
            }

            using (var ms = new MemoryStream())
            {
                file.CopyTo(ms);
                ms.Position = 0;
                result = ms.ToArray();
            }
            var dt = ExcelImportHelper.ReadBytesToDataTable(result, title);
            var list = dt.ToDataList<ErpOilRecord>();
            var upList = new List<ErpOilRecord>();

            //检查车必填项是否为空
            if (list.Exists(it => string.IsNullOrEmpty(it.ex_vehicle_number) && string.IsNullOrEmpty(it.ex_lincense_plate_number)))
            {
                throw new Exception("存在自编号,车牌号为空记录！");
            }
            if (list.Exists(it => it.oil_date == null))
            {
                throw new Exception("存在油耗月份为空记录！");
            }
            if (list.Exists(it => it.value == null))
            {
                throw new Exception("存在油耗为空记录！");
            }

            //车牌号
            var plateNumbers = list.Select(it => it.ex_lincense_plate_number).ToList();
            var cars = await _iVehicleInfoDataImp.ExtList(server_id, await _iVehicleInfoDataImp.List(server_id, it => SqlFunc.ContainsArray(plateNumbers, it.c_lincense_plate_number)));
            var lineNames = list.Select(it => it.ex_line_name).ToList();
            var lines = await _iLineDataImp.GetAllLines(server_id);

            list.ForEach(item =>
            {
                item.id = _dataImp.GetId(server_id, "SEQ_COMMON").Result;
                if (cars.Exists(it => it.c_lincense_plate_number == item.ex_lincense_plate_number && it.ex_type == "柴油"))
                {
                    var car = cars.Find(it => it.c_lincense_plate_number == item.ex_lincense_plate_number);
                    item.vehicle_id = car.i_id;
                    item.line_id = car.line_id;
                }
                else throw new Exception("系统中不存在的车牌号或非燃油车!");
                item.created_id = client.i_id;
                item.created_date = DateTime.Now;
            });
            //覆盖
            if (type == 1)
            {
                var eIds = new List<decimal>();
                var eList = await _dataImp.ExtList(server_id, await _dataImp.List(server_id, it => SqlFunc.ContainsArray(list.Select(it => it.vehicle_id).ToList(), it.vehicle_id)));
                list.ForEach(item =>
                {
                    if (eList.Exists(it => it.year_month == item.year_month && it.vehicle_id == item.vehicle_id))
                    {
                        var e = eList.Find(it => it.year_month == item.year_month && it.vehicle_id == item.vehicle_id);
                        item.id = e.id;
                        eIds.Add(item.id);
                        upList.Add(item);
                    }
                });
                list = list.Where(it => !eIds.Contains(it.id)).ToList();
            }
            //保持原数据
            if (type == 0)
            {
                var eList = await _dataImp.ExtList(server_id, await _dataImp.List(server_id, it => SqlFunc.ContainsArray(list.Select(it => it.vehicle_id).ToList(), it.vehicle_id)));
                list.ForEach(item =>
                {
                    if (eList.Exists(it => it.year_month == item.year_month && it.vehicle_id == item.vehicle_id))
                    {
                        var list = eList.Where(it => it.year_month == item.year_month && it.vehicle_id == item.vehicle_id).ToList();
                        throw new Exception($"{string.Join(",", list.Select(it => it.ex_lincense_plate_number).ToList())}一个月只允许一条油耗记录!");
                    }
                });
            }

            return await _dataImp.Import(server_id, list, upList);
        }

        public async Task<Tuple<List<VehicelOilConsumeSummary>, int>> QueryPageVehicleOilSummaty(string server_id, ErpOilRecordSummaryRequest request, string v)
        {
            return await _dataImp.QueryPageVehicleOilSummaty(server_id, request, v);
        }

        public async Task<List<VehicelOilConsumeSummary>> QueryVehicleOilSummaty(string server_id, ErpOilRecordSummaryRequest request, string v)
        {
            return await _dataImp.QueryVehicleOilSummaty(server_id, request, v);
        }
    }
}