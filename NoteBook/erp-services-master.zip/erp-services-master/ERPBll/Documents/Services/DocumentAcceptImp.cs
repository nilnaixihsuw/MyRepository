﻿using AutoMapper;
using DotNetCore.CAP;
using ERPBll.Caps;
using ERPBll.FlowManage.Contracts;
using ERPBll.RedisManage.Users;
using ERPBll.UserManage;
using ERPDal;
using ERPDal.Repository;
using ERPModel.Documents;
using ERPModel.Documents.DocumentAccept;
using ERPModel.Documents.DocumentFlows;
using ERPModel.Documents.DocumentMain;
using ERPModel.Documents.ErpDocumentPersons;
using ERPModel.FlowManage;
using ERPModel.FlowManage.ErpFlowChecks;
using ERPModel.FlowManage.FlowRecords;
using ERPModel.UserManage;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.Documents
{
    public class DocumentAcceptImp : IDocumentAcceptImp, ICapSubscribe
    {
        private readonly IMapper _imapper;
        private readonly IErpDocumentFlowImp _erpDocumentFlowImp;
        private readonly IDocumentFileImp _documentFileImp;
        private readonly IDocumentPersonImp _documentPersonImp;
        private readonly IErpFlowRecordImp _erpFlowRecordImp;
        private readonly IErpFlowCheckImp _erpFlowCheckImp;
        private readonly IUserRedisImp _userRedisImp;

        public DocumentAcceptImp(
           IMapper imapper,
           IErpDocumentFlowImp erpDocumentFlowImp,
           IDocumentPersonImp documentPersonImp,
           IDocumentFileImp documentFileImp,
           IErpFlowRecordImp erpFlowRecordImp,
           IErpFlowCheckImp erpFlowCheckImp,
           IUserRedisImp userRedisImp)
        {
            _imapper = imapper;
            _erpDocumentFlowImp = erpDocumentFlowImp;
            _documentFileImp = documentFileImp;
            _documentPersonImp = documentPersonImp;
            _erpFlowRecordImp = erpFlowRecordImp;
            _erpFlowCheckImp = erpFlowCheckImp;
            _userRedisImp = userRedisImp;
        }

        public async Task<(List<DocumentAcceptDto>, int)> GetAllByPageAsync(
           string server_id, decimal? user_id, DocumentAcceptQueryInput input)
        {
            RefAsync<int> totalCount = 0;

            //加权限
            input.department_ids = RoleInfoBll.GetGroupID(server_id, user_id);

            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpDocumentAccept>()
                                .Where(input.ToExp())
                                .Mapper(x => x.flow_info, x => x.flow_id)
                                .Mapper(x => x.main_department_info, x => x.main_department)
                                .Mapper(x => x.department_info, x => x.department_id)
                                .Mapper(x => x.created_info, x => x.register_id)
                                .Mapper(x => x.files, x => x.files.First().document_id)
                                .Mapper(async x =>
                                {
                                    var copy_department_info = await SqlSugarHelper.DBClient(server_id)
                                                            .Queryable<SysDepartment>()
                                                            .Where(i => x.copy_departments.Contains(i.i_id.ToString()))
                                                            .ToListAsync();

                                    x.main_person_details = await SqlSugarHelper.DBClient(server_id)
                                                           .Queryable<ErpDocumentPerson>()
                                                           .Where(it => it.document_id == x.id && it.type == 2 && it.kind == 1)
                                                           .Mapper(x => x.person_info, x => x.person_id)
                                                           .ToListAsync();

                                    x.copy_person_details = await SqlSugarHelper.DBClient(server_id)
                                                           .Queryable<ErpDocumentPerson>()
                                                           .Where(it => it.document_id == x.id && it.type == 2 && it.kind == 2)
                                                           .Mapper(x => x.person_info, x => x.person_id)
                                                           .ToListAsync();

                                    x.copy_department_names = string.Join(',', copy_department_info.Select(x => x.c_name));
                                    if (x.state == DocumentState.草稿)
                                    {
                                        x.user_ids = new List<decimal>() { x.created_id };
                                    }
                                })
                                .OrderByIF(input.order_type == 0, x => x.created_date, OrderByType.Desc)
                                .OrderByIF(input.order_type == 1, x => x.number, OrderByType.Desc)
                                .OrderByIF(input.order_type == 2, x => x.code, OrderByType.Desc)
                                .ToPageListAsync(input.page_index, input.page_size, totalCount);

            if (list == null || list.Count < 1)
            {
                return (new List<DocumentAcceptDto>(), totalCount);
            }

            var all = await _erpFlowRecordImp.GetListAsync(server_id, user_id,
                new FlowRecordQuery()
                {
                    detail_ids = list.Select(x => x.id).ToList()
                });
            foreach (var item in list)
            {
                if (item.state == DocumentState.待处理)
                {

                    var info = all.FirstOrDefault(x => x.detail_id == item.id);
                    if (info != null && info.wait_flow_step != null)
                    {
                        item.user_ids = info.state_child_id;
                        item.user_names = info.state_child_name;
                        item.step_id = info.wait_flow_step.id;
                        item.step_name = info.wait_flow_step.title;
                    }
                }
            }
            var data = _imapper.Map<List<ErpDocumentAccept>, List<DocumentAcceptDto>>(list);

            return (data, totalCount);
        }

        public async Task<(List<DocumentAcceptDto>, int)> GetByPageAsync(
           string server_id, decimal? user_id, DocumentAcceptQueryInput input)
        {
            RefAsync<int> totalCount = 0;

            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpDocumentAccept>()
                                .Where(input.ToExp())
                                .Where(x => x.created_id == user_id)
                                .Mapper(x => x.flow_info, x => x.flow_id)
                                .Mapper(x => x.main_department_info, x => x.main_department)
                                .Mapper(x => x.department_info, x => x.department_id)
                                .Mapper(x => x.created_info, x => x.register_id)
                                .Mapper(x => x.files, x => x.files.First().document_id)
                                .Mapper(async x =>
                                {
                                    var copy_department_info = await SqlSugarHelper.DBClient(server_id)
                                                            .Queryable<SysDepartment>()
                                                            .Where(i => x.copy_departments.Contains(i.i_id.ToString()))
                                                            .ToListAsync();

                                    x.main_person_details = await SqlSugarHelper.DBClient(server_id)
                                                           .Queryable<ErpDocumentPerson>()
                                                           .Where(it => it.document_id == x.id && it.type == 2 && it.kind == 1)
                                                           .Mapper(x => x.person_info, x => x.person_id)
                                                           .ToListAsync();

                                    x.copy_person_details = await SqlSugarHelper.DBClient(server_id)
                                                           .Queryable<ErpDocumentPerson>()
                                                           .Where(it => it.document_id == x.id && it.type == 2 && it.kind == 2)
                                                           .Mapper(x => x.person_info, x => x.person_id)
                                                           .ToListAsync();

                                    if (!string.IsNullOrWhiteSpace(x.copy_departments))
                                    {
                                        x._copy_department = x.copy_departments.Split(',').ToList()
                                            .ConvertAll(x => Convert.ToDecimal(x));
                                    }

                                    x.copy_department_names = string.Join(',', copy_department_info.Select(x => x.c_name));
                                    if (x.state == DocumentState.草稿)
                                    {
                                        x.user_ids = new List<decimal>() { x.created_id };
                                    }
                                })
                                .OrderByIF(input.order_type == 0, x => x.created_date, OrderByType.Desc)
                                .OrderByIF(input.order_type == 1, x => x.number, OrderByType.Desc)
                                .OrderByIF(input.order_type == 2, x => x.code, OrderByType.Desc)
                                .ToPageListAsync(input.page_index, input.page_size, totalCount);

            if (list == null || list.Count < 1)
            {
                return (new List<DocumentAcceptDto>(), totalCount);
            }

            var all = await _erpFlowRecordImp.GetListAsync(server_id, user_id,
                new FlowRecordQuery()
                {
                    detail_ids = list.Select(x => x.id).ToList()
                });
            foreach (var item in list)
            {
                if (item.state == DocumentState.待处理)
                {

                    var info = all.FirstOrDefault(x => x.detail_id == item.id);
                    if (info != null && info.wait_flow_step != null)
                    {
                        item.user_ids = info.state_child_id;
                        item.user_names = info.state_child_name;
                        item.step_id = info.wait_flow_step.id;
                        item.step_name = info.wait_flow_step.title;
                    }
                }
            }
            var data = _imapper.Map<List<ErpDocumentAccept>, List<DocumentAcceptDto>>(list);

            return (data, totalCount);
        }

        public async Task<DocumentAcceptDto> GetByIdAsync(string server_id, decimal? user_id, int id)
        {
            //查询
            var info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpDocumentAccept>()
                                .Where(x => x.id == id)
                                .Mapper(x => x.flow_info, x => x.flow_id)
                                .Mapper(x => x.main_department_info, x => x.main_department)
                                .Mapper(x => x.department_info, x => x.department_id)
                                .Mapper(x => x.created_info, x => x.register_id)
                                .Mapper(x => x.files, x => x.files.First().document_id)
                                .Mapper(async x =>
                                {
                                    var copy_department_info = await SqlSugarHelper.DBClient(server_id)
                                                            .Queryable<SysDepartment>()
                                                            .Where(i => x.copy_departments.Contains(i.i_id.ToString()))
                                                            .ToListAsync();

                                    x.main_person_details = await SqlSugarHelper.DBClient(server_id)
                                                           .Queryable<ErpDocumentPerson>()
                                                           .Where(it => it.document_id == x.id && it.type == 2 && it.kind == 1)
                                                           .Mapper(x => x.person_info, x => x.person_id)
                                                           .ToListAsync();

                                    x.copy_person_details = await SqlSugarHelper.DBClient(server_id)
                                                           .Queryable<ErpDocumentPerson>()
                                                           .Where(it => it.document_id == x.id && it.type == 2 && it.kind == 2)
                                                           .Mapper(x => x.person_info, x => x.person_id)
                                                           .ToListAsync();

                                    x.copy_department_names = string.Join(',', copy_department_info.Select(x => x.c_name));
                                    if (x.state == DocumentState.草稿)
                                    {
                                        x.user_ids = new List<decimal>() { x.created_id };
                                    }
                                })
                                .FirstAsync();

            if (info != null && info.state == DocumentState.待处理)
            {
                var all = await _erpFlowRecordImp.GetListAsync(server_id, user_id,
                   new FlowRecordQuery()
                   {
                       detail_ids = new List<int> { info.id }
                   });

                if (all != null && all.Count > 0 && all[0].wait_flow_step != null)
                {
                    info.user_ids = all[0].state_child_id;
                    info.user_names = all[0].state_child_name;
                    info.step_id = all[0].wait_flow_step.id;
                    info.step_name = all[0].wait_flow_step.title;
                }
            }

            var data = _imapper.Map<ErpDocumentAccept, DocumentAcceptDto>(info);

            return data;
        }

        public async Task<DocumentAcceptDto> AddAsync(string server_id, decimal? user_id, CreateOrUpdateDocumentAccept input)
        {
            var info = _imapper.Map<CreateOrUpdateDocumentAccept, ErpDocumentAccept>(input);
            info.font_number = !string.IsNullOrWhiteSpace(info.font) && info.year > 0 && info.number > 0 ? 
                    $"{info.font}〔{info.year}〕{info.number}号" : "";
            //验证
            var count = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpDocumentAccept>()
                                .CountAsync(x => x.font_number == info.font_number && x.id != input.id && x.state != DocumentState.已作废);
            if (count > 0)
            {
                throw new Exception("收文字号重复，请重新填写");
            }

            info.id = ERPBll.Tools.GetEngineID(server_id);
            info.SetCreate(user_id.Value);

            //附件
            if (input.files != null && input.files.Count > 0)
            {
                await _documentFileImp.AddAsync(server_id, user_id, input.files, info.id);
            }

            //主送人员
            if (input.main_persons != null && input.main_persons.Count > 0)
            {
                await _documentPersonImp.AddAsync(server_id, user_id, input.main_persons, info.id, 2, 1);
            }
            //抄送人员
            if (input.copy_persons != null && input.copy_persons.Count > 0)
            {
                await _documentPersonImp.AddAsync(server_id, user_id, input.copy_persons, info.id, 2, 2);
            }

            var user_name = await _userRedisImp.GetNameByIdAsync(info.register_id.ToString());
            //发起审核
            var flowRecord = await _erpFlowRecordImp.StartByDocAsync(server_id,
                new StartFlowInput
                {
                    content = DocumentAcceptMessage.GetContent(user_name, info),
                    type = 2,
                    object_id = (int)FlowRecordType.收文审批,
                    detail_id = info.id,
                    flow_init_id = input.flow_id,
                    user_id = info.register_id
                });
            if (flowRecord != null)
            {
                info.flow_record_id = flowRecord.id;
            }
            info.state = DocumentState.待处理;

            await SqlSugarHelper.DBClient(server_id).Insertable(info).ExecuteCommandAsync();

            return _imapper.Map<ErpDocumentAccept, DocumentAcceptDto>(info);
        }

        public async Task<DocumentAcceptDto> UpdateAsync(string server_id, decimal? user_id, CreateOrUpdateDocumentAccept input)
        {
            using (var db = SqlSugarHelper.DBClient(server_id))
            {
                var info = await db.Queryable<ErpDocumentAccept>().FirstAsync(x => x.id == input.id);
                if (info == null)
                {
                    throw new Exception($"未找到收文记录，id={input.id}");
                }

                //验证
                var count = await db.Queryable<ErpDocumentAccept>().CountAsync(x => x.font == input.font && x.year == input.year && 
                    x.number == input.number && x.id != input.id && x.state != DocumentState.已作废);
                if (count > 0)
                {
                    throw new Exception("收文编号重复，请重新填写");
                }

                //重新提交
                if (info.state == DocumentState.已驳回 && input.again.Value == 1)
                {
                    info.commit = 1;
                    await db.Updateable(info).ExecuteCommandAsync();

                    _imapper.Map<CreateOrUpdateDocumentAccept, ErpDocumentAccept>(input, info);
                    info.id = Tools.GetSeqCommonID(server_id);
                    info.state = DocumentState.待处理;
                    info.created_date = DateTime.Now;
                    info.commit = 0;

                    var user_name = await _userRedisImp.GetNameByIdAsync(info.register_id.ToString());
                    //发起审核
                    var flowRecord = await _erpFlowRecordImp.StartByDocAsync(server_id,
                        new StartFlowInput
                        {
                            content = DocumentAcceptMessage.GetContent(user_name, info),
                            type = 2,
                            object_id = (int)FlowRecordType.收文审批,
                            detail_id = info.id,
                            flow_init_id = input.flow_id,
                            user_id = info.register_id
                        });
                    if (flowRecord != null)
                    {
                        info.flow_record_id = flowRecord.id;
                    }

                    await db.Insertable(info).ExecuteCommandAsync();
                }
                else
                {
                    _imapper.Map<CreateOrUpdateDocumentAccept, ErpDocumentAccept>(input, info);
                    info.SetUpdate(user_id);
                    info.font_number = !string.IsNullOrWhiteSpace(info.font) && info.year > 0 && info.number > 0 ?
                            $"{info.font}〔{info.year}〕{info.number}号" : "";
                    await db.Updateable(info).ExecuteCommandAsync();

                    await _documentFileImp.DeleteAsync(server_id, info.id);

                    await _documentPersonImp.DeleteAsync(server_id, info.id);

                }
                //附件
                if (input.files != null && input.files.Count > 0)
                {
                    await _documentFileImp.AddAsync(server_id, user_id, input.files, info.id);
                }
                //主送人员
                if (input.main_persons != null && input.main_persons.Count > 0)
                {
                    await _documentPersonImp.AddAsync(server_id, user_id, input.main_persons, info.id, 2, 1);
                }
                //抄送人员
                if (input.copy_persons != null && input.copy_persons.Count > 0)
                {
                    await _documentPersonImp.AddAsync(server_id, user_id, input.copy_persons, info.id, 2, 2);
                }
                return _imapper.Map<ErpDocumentAccept, DocumentAcceptDto>(info);
            }
        }

        public async Task<DocumentAcceptDto> UpdateStateAsync(
            string server_id, decimal? user_id, UpdateDocumentAcceptState input)
        {
            var info = await SqlSugarHelper.DBClient(server_id)
                               .Queryable<ErpDocumentAccept>()
                               .Mapper(x => x.files, x => x.files.First().document_id)
                               .Mapper(x => x.main_person_details, x => x.main_person_details.First().document_id)
                               .FirstAsync(x => x.id == input.document_id);
            if (info == null)
            {
                throw new Exception($"未找到收文记录，id={input.document_id}");
            }

            //重新提交
            if (info.state == DocumentState.已驳回 && input.again.Value == 1)
            {
                info.commit = 1;
                await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync();

                info.id = Tools.GetSeqCommonID(server_id);
                info.code = await GetMaxCodeAsync(server_id);
                info.state = DocumentState.待处理;
                info.created_date = DateTime.Now;
                info.commit = 0;

                //附件
                if (info.files != null && info.files.Count > 0)
                {
                    info.files.ForEach(x => x.document_id = info.id);
                    await SqlSugarHelper.DBClient(server_id).Insertable(info.files).ExecuteCommandAsync();
                }
                //主送人员/抄送人员
                if (info.main_person_details != null && info.main_person_details.Count > 0)
                {
                    info.main_person_details.ForEach(x => x.document_id = info.id);
                    await SqlSugarHelper.DBClient(server_id).Insertable(info.main_person_details).ExecuteCommandAsync();
                }

                var user_name = await _userRedisImp.GetNameByIdAsync(info.register_id.ToString());
                //发起审核
                var flowRecord = await _erpFlowRecordImp.StartByDocAsync(server_id,
                    new StartFlowInput
                    {
                        content = DocumentAcceptMessage.GetContent(user_name, info),
                        type = 2,
                        object_id = (int)FlowRecordType.收文审批,
                        detail_id = info.id,
                        flow_init_id = input.flow_id,
                        user_id = info.register_id
                    });
                if (flowRecord != null)
                {
                    info.flow_record_id = flowRecord.id;
                }

                await SqlSugarHelper.DBClient(server_id).Insertable(info).ExecuteCommandAsync();
                return _imapper.Map<ErpDocumentAccept, DocumentAcceptDto>(info);
            }

            if (info.state == DocumentState.已驳回)
            {
                throw new Exception($"当前收文记录已驳回，不允许审批");
            }

            if (info.state == DocumentState.已作废)
            {
                throw new Exception($"当前收文记录已作废，不允许审批");
            }

            await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync();

            //审核
            var check = new UpdateErpFlowCheck()
            {
                flow_id = input.flow_record_id,
                step_id = input.state,
                state = input.result + 1,
                remark = input.remark,
            };
            await _erpFlowCheckImp.UpdateAsync(server_id, user_id, check);

            
            return _imapper.Map<ErpDocumentAccept, DocumentAcceptDto>(info);
        }

        public async Task<List<DocumentAcceptDto>> UpdateScrapAsync(string server_id, List<int> ids)
        {
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpDocumentAccept>() 
                                .Where(x => ids.Contains(x.id))
                                .ToListAsync();

            if (list == null || list.Count < 1)
            {
                throw new Exception($"未找到发文记录");
            }

            list.ForEach(x => x.state = DocumentState.已作废);
            await SqlSugarHelper.DBClient(server_id).Updateable(list).UpdateColumns(x => x.state).ExecuteCommandAsync();

            return _imapper.Map<List<ErpDocumentAccept>, List<DocumentAcceptDto>>(list);
        }

        public async Task<int> DeleteManyAsync(string server_id, decimal? user_id, List<decimal> ids)
        {
            using (var db = SqlSugarHelper.DBClient(server_id))
            {
                var list = await db.Queryable<ErpDocumentAccept>().Where(x => ids.Contains(x.id)).ToListAsync();
                foreach (var item in list)
                {
                    if(item.state == DocumentState.待处理)
                    {
                        await _erpFlowCheckImp.CancelAsync(server_id, user_id, Convert.ToInt32(item.flow_record_id));
                    }
                }
                return await db.Deleteable<ErpDocumentAccept>().In(ids).ExecuteCommandAsync();
            }
        }

        public async Task<string> GetMaxCodeAsync(string server_id)
        {
            //查询
            var code = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpDocumentAccept>()
                                .MaxAsync(x => x.code);

            return (Convert.ToInt32(code) + 1).ToString().PadLeft(5, '0');
        }

        public async Task<List<string>> GetFontNumberAsync(string server_id)
        {
            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpDocumentAccept>()
                                .Where(x => x.state != DocumentState.已作废)
                                .Select(x => x.font_number)
                                .ToListAsync();

            return list.Distinct().ToList();
        }

        public async Task<(List<int>, int)> GetNumberAsync(string server_id, string font, int year)
        {
            //查询
            var query = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpDocumentAccept>()
                                .Where(x => x.state != DocumentState.已作废 && x.font == font && x.year == year)
                                .Select(x => x.number)
                                .ToListAsync();

            if (query == null || query.Count < 1)
            {
                return (new List<int>(), 0);
            }

            var numberList = Enumerable.Range(1, query.Max()).ToList();
            return (numberList.Except(query).ToList(), query.Max());
        }

        //[CapSubscribe(EventMessages.DocumentAcceptFinish, Group = "DocumentAccept")]
        //public async Task UpdateStateAsync(UpdateErpFlowRecordState input)
        //{
        //    var info = await SqlSugarHelper.DBClient("60.191.59.11")
        //                        .Queryable<ErpDocumentAccept>()
        //                        .FirstAsync(x => x.flow_record_id == input.flow_id);
        //    if (info != null)
        //    {
        //        if (input.state == FlowRecordState.审核通过)
        //        {
        //            Console.WriteLine($"收文流程通过:{input.flow_id}");
        //            info.state = DocumentState.已归档;
        //            info.step_name_str = "";
        //            info.finish_date = DateTime.Now;
        //        }
        //        else if (input.state == FlowRecordState.审核拒绝)
        //        {
        //            Console.WriteLine($"收文流程拒绝:{input.flow_id}");
        //            info.step_name_str = "";
        //            info.state = DocumentState.已驳回;
        //        }
        //        await SqlSugarHelper.DBClient("60.191.59.11").Updateable(info).ExecuteCommandAsync();
        //        Console.WriteLine($"收文流程结束:{input.flow_id}");
        //    }
        //}
    }
}
