﻿using AutoMapper;
using ERPDal;
using ERPModel.Documents.DocumentAccept;
using ERPModel.Documents.DocumentMain;
using ERPModel.Documents.ErpDocumentDels;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.Documents
{
    public class ErpDocumentDelImp: IErpDocumentDelImp
    {
        private readonly IMapper _imapper;

        public ErpDocumentDelImp(
           IMapper imapper)
        {
            _imapper = imapper;
        }

        public async Task<List<int>> GetByUserAsync(string server_id, decimal? user_id)
        {
            return await SqlSugarHelper.DBClient(server_id)
                                 .Queryable<ErpDocumentDel>()
                                 .Where(x => x.user_id == user_id)
                                 .Select(x => x.document_id)
                                 .ToListAsync(); ;
        }

        public async Task AddAsync(string server_id, decimal? user_id, List<int> ids)
        {
            var list = new List<ErpDocumentDel>();
            foreach(var item in ids)
            {
                var info = new ErpDocumentDel()
                {
                    user_id = user_id,
                    document_id = item,
                    created_date = DateTime.Now
                };
                list.Add(info);
            }
            await SqlSugarHelper.DBClient(server_id).Insertable(list).ExecuteCommandAsync();
        }

        public async Task<string> GetDelTitle(DocumentDelInput request, string server_id)
        {
            using var db = SqlSugarHelper.DBClient(server_id);
            string res = string.Empty;
            if (request.document_type == 1)
            {
                var record = await db.Queryable<ErpDocumentMain>().FirstAsync(r => r.id == request.ids[0]);
                res = record?.title;
            }
            if (request.document_type == 2)
            {
                var record = await db.Queryable<ErpDocumentAccept>().FirstAsync(r => r.id == request.ids[0]);
                res = record?.title;
            }
            return res;
        }
    }
}
