﻿using AutoMapper;
using ERPDal;
using ERPModel.Documents.DocumentFile;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.Documents
{
    public class DocumentFileImp: IDocumentFileImp
    {
        private readonly IMapper _imapper;

        public DocumentFileImp(IMapper imapper)
        {
            _imapper = imapper;
        }

        public async Task AddAsync(string server_id, decimal? user_id, List<CreateOrUpdateDocumentFile> input, int document_id)
        {
            if (input == null || input.Count < 1)
            {
                return;
            }
            var list = _imapper.Map<List<CreateOrUpdateDocumentFile>, List<ErpDocumentFile>>(input);
            list.ForEach(x =>
            {
                x.document_id = document_id;
                x.created_id = user_id;
            });
            await SqlSugarHelper.DBClient(server_id).Insertable<ErpDocumentFile>(list).ExecuteCommandAsync();
        }

        public async Task<int> DeleteAsync(string server_id, decimal id)
        {
            return await SqlSugarHelper.DBClient(server_id)
                            .Deleteable<ErpDocumentFile>()
                            .Where(x => x.document_id == id)
                            .ExecuteCommandAsync();
        }
    }
}
