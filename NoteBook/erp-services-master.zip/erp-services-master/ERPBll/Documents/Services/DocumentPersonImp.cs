﻿using AutoMapper;
using ERPDal;
using ERPModel.Documents.ErpDocumentPersons;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.Documents
{
    public class DocumentPersonImp : IDocumentPersonImp
    {
        public async Task AddAsync(string server_id, decimal? user_id, List<int> persons, int document_id, int type, int kind)
        {
            if (persons == null || persons.Count < 1)
            {
                return;
            }
            var list = new List<ErpDocumentPerson>();
            foreach (var item in persons)
            {
                var info = new ErpDocumentPerson()
                {
                    document_id = document_id,
                    person_id = item,
                    type = type,
                    kind = kind,
                    created_id = user_id
                };
                list.Add(info);
            }
            await SqlSugarHelper.DBClient(server_id).Insertable<ErpDocumentPerson>(list).ExecuteCommandAsync();
        }

        public async Task<int> DeleteAsync(string server_id, decimal id)
        {
            return await SqlSugarHelper.DBClient(server_id)
                            .Deleteable<ErpDocumentPerson>()
                            .Where(x => x.document_id == id)
                            .ExecuteCommandAsync();
        }
    }
}
