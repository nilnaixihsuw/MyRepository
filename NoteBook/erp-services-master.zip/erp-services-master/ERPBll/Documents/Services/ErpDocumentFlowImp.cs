﻿using ERPCore.ORM;
using ERPModel.Documents;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using ERPBll.DataBase;
using ErpBll.FormManage;
using ERPBll.UserManage;
using ERPDal;
using ERPModel.UserManage;
using ERPModel.Documents.DocumentFlows;
using ERPBll.RedisManage.Dicts;
using ERPModel.Vehicleinfomanage;
using AutoMapper;
using ERPModel.Documents.DocumentMain;
using ERPModel.Documents.DocumentAccept;
using System.Text;
using ERPBll.RedisManage.Users;
using ERPBll.FlowManage.Contracts;
using ERPModel.FlowManage.ErpFlowChecks;
using ERPModel.FlowManage.FlowRecords;
using ERPModel.FlowManage;
using ERPModel.FlowManage.ErpFlowStepInits;
using Newtonsoft.Json;

namespace ERPBll.Documents
{
    public class ErpDocumentFlowImp : IErpDocumentFlowImp
    {
        private readonly IMapper _imapper;
        private readonly IDictRedisManageImp _iDictRedisManageImp;
        private readonly IUserRedisImp _userRedisImp;
        private readonly IErpDocumentDelImp _erpDocumentDelImp;
        private readonly IErpFlowRecordImp _erpFlowRecordImp;
        private readonly IErpFlowStepInitImp _erpFlowStepInitImp;
        private readonly IErpFlowCheckImp _erpFlowCheckImp;

        public ErpDocumentFlowImp(
            IMapper imapper,
            IDictRedisManageImp iDictRedisManageImp,
            IUserRedisImp userRedisImp,
            IErpDocumentDelImp erpDocumentDelImp,
            IErpFlowRecordImp erpFlowRecordImp,
            IErpFlowStepInitImp erpFlowStepInitImp,
            IErpFlowCheckImp erpFlowCheckImp)
        {
            _imapper = imapper;
            _iDictRedisManageImp = iDictRedisManageImp;
            _userRedisImp = userRedisImp;
            _erpDocumentDelImp = erpDocumentDelImp;
            _erpFlowRecordImp = erpFlowRecordImp;
            _erpFlowStepInitImp = erpFlowStepInitImp;
            _erpFlowCheckImp = erpFlowCheckImp;
        }

        public async Task<(List<DocumentFlowDto>, int)> GetByPageAsync(
           string server_id, decimal? user_id, DocumentMainQueryInput input)
        {
            using (var db = SqlSugarHelper.DBClient(server_id))
            {
                var list = new List<DocumentFlowDto>();
                RefAsync<int> totalCount = 0;

                if (input.document_type != 2)
                {
                    //查询审批记录
                    var checks = await db.Queryable<ErpFlowCheck, ErpFlowRecord>((x, y) => new JoinQueryInfos(JoinType.Left, x.flow_id == y.id))
                                    .Where((x, y) => x.check_id == user_id.Value && y.object_id == (int)FlowRecordType.发文审批)
                                    .Mapper(x => x.flow_record, x => x.flow_id)
                                    .ToListAsync();

                    var ids = checks.Select(x => x.flow_record.detail_id).ToList();

                    //查询发文记录
                    var postQuerys = await db.Queryable<ErpDocumentMain>()
                                        .Where(x => ids.Contains(x.id))
                                        .Mapper(x => x.main_department_info, x => x.main_department)
                                        .Where(input.ToFlowExp())
                                        .ToListAsync();

                    var posts = _imapper.Map<List<ErpDocumentMain>, List<DocumentFlowDto>>(postQuerys);
                    list = list.Union(posts).ToList();
                }
                if (input.document_type != 1)
                {
                    //查询审批记录
                    var checks = await db.Queryable<ErpFlowCheck, ErpFlowRecord>((x, y) => new JoinQueryInfos(JoinType.Left, x.flow_id == y.id))
                                    .Where((x, y) => x.check_id == user_id.Value && y.object_id == (int)FlowRecordType.收文审批)
                                    .Mapper(x => x.flow_record, x => x.flow_id)
                                    .ToListAsync();

                    var ids = checks.Select(x => x.flow_record.detail_id).ToList();
                    //查询发文记录
                    var acceptQuerys = await db.Queryable<ErpDocumentAccept>()
                                        .Where(x => ids.Contains(x.id))
                                        .Where(input.ToAcceptExp())
                                        .Mapper(x => x.main_department_info, x => x.main_department)
                                        .ToListAsync();

                    var accepts = _imapper.Map<List<ErpDocumentAccept>, List<DocumentFlowDto>>(acceptQuerys);
                    list = list.Union(accepts).ToList();
                }

                var data = new List<DocumentFlowDto>();
                if (list == null || list.Count < 1)
                {
                    return (data, totalCount);
                }

                var dels = await _erpDocumentDelImp.GetByUserAsync(server_id, user_id);
                var all = await _erpFlowRecordImp.GetListAsync(server_id, user_id,
                    new FlowRecordQuery()
                    {
                        detail_ids = list.Select(x => x.document_id).ToList()
                    });
                foreach (var item in list)
                {
                    //已删除
                    if (dels.Contains(item.document_id))
                    {
                        continue;
                    }

                    var info = all.OrderByDescending(x => x.id).FirstOrDefault(x => x.detail_id == item.document_id);
                    item.flow_title = info?.title;
                    item.created_name = (await _userRedisImp.GetByIdAsync(((int)item.created_id.Value).ToString()))?.c_name;
                    if (info != null && info.wait_flow_step != null)
                    {
                        item.person_ids = info.state_child_id;
                        item.person_name = info.state_child_name;
                        item.step_id = info.wait_flow_step.id;
                        item.step_name = info.wait_flow_step.title;
                        item.is_audit = item.person_ids.Contains(user_id.Value);

                        TimeSpan ts = DateTime.Now - info.wait_flow_step.created_date.Value;
                        item.wait_time = GetLongTime(ts);
                        item.times = ts.TotalSeconds;
                    }
                    if (!item.is_audit && item.state == DocumentState.待处理)
                    {
                        item.state = DocumentState.已处理;
                        item.state_name = DocumentState.已处理.ToString();
                        item.wait_time = "";
                        item.times = 0;
                    }
                    item.last_check_time = info?.flow_checks?.Where(x => x.check_id == user_id.Value).Max(x => x.update_date);
                    data.Add(item);
                }
                Func<DocumentFlowDto, bool> exp = x =>
                {
                    var state_exp = input.state > 0 ? x.state == (DocumentState)input.state : true;
                    return state_exp;
                };
                data = data.Where(exp)
                        .OrderByDescending(x => x.times)
                        .ThenByDescending(x => x.created_date).ToList();
                totalCount = data.Count();
                data = data.Skip((input.page_index - 1) * input.page_size).Take(input.page_size).ToList();
                return (data, totalCount);
            }
        }

        public async Task<(List<DocumentFlowDto>, int)> GetReadAsync(
           string server_id, decimal? user_id, DocumentMainQueryInput input)
        {
            using (var db = SqlSugarHelper.DBClient(server_id))
            {
                RefAsync<int> totalCount = 0;

                var list = new List<DocumentFlowDto>();
                if (input.document_type != 2)
                {
                    //查询发文记录
                    var postQuerys = await db.Queryable<ErpDocumentMain>()
                                        .Where(x => x.state == DocumentState.已归档)
                                        .Where(input.ToExp())
                                        .Mapper(x => x.post_info, x => x.post_id)
                                        .Mapper(x => x.created_info, x => x.created_id)
                                        .Mapper(x => x.department_info, x => x.department_id)
                                        .Mapper(x => x.main_department_info, x => x.main_department)
                                        .Mapper(x => x.main_person_details, x => x.main_person_details.First().document_id)
                                        .Mapper(x => x.copy_person_details, x => x.copy_person_details.First().document_id)
                                        .Mapper(x =>
                                        {
                                            x.main_person_details = x.copy_person_details.Where(it => it.type == 1 && it.kind == 1).ToList();
                                            x.copy_person_details = x.copy_person_details.Where(it => it.type == 1 && it.kind == 2).ToList();

                                            var copy_department_info = db.Queryable<SysDepartment>()
                                                                .Where(i => x.copy_departments.Contains(i.i_id.ToString()))
                                                                .ToList();
                                            x.copy_department_names = string.Join(',', copy_department_info.Select(x => x.c_name));
                                        })
                                        .ToListAsync();
                    var posts = _imapper.Map<List<ErpDocumentMain>, List<DocumentFlowDto>>(postQuerys);
                    list = list.Union(posts).ToList();
                }
                if (input.document_type != 1)
                {
                    //查询收文记录
                    var acceptQuerys = await db.Queryable<ErpDocumentAccept>()
                                    .Where(x => x.state == DocumentState.已归档)
                                    .Where(input.ToAcceptExp())
                                    .Mapper(x => x.register_info, x => x.register_id)
                                    .Mapper(x => x.created_info, x => x.created_id)
                                    .Mapper(x => x.department_info, x => x.department_id)
                                    .Mapper(x => x.main_department_info, x => x.main_department)
                                    .Mapper(x => x.main_person_details, x => x.main_person_details.First().document_id)
                                    .Mapper(x => x.copy_person_details, x => x.copy_person_details.First().document_id)
                                    .Mapper(x =>
                                    {
                                        x.main_person_details = x.copy_person_details.Where(it => it.type == 2 && it.kind == 1).ToList();
                                        x.copy_person_details = x.copy_person_details.Where(it => it.type == 2 && it.kind == 2).ToList();

                                        var copy_department_info = db.Queryable<SysDepartment>()
                                                                    .Where(i => x.copy_departments.Contains(i.i_id.ToString()))
                                                                    .ToList();
                                        x.copy_department_names = string.Join(',', copy_department_info.Select(x => x.c_name));
                                    })
                                    .ToListAsync();

                    var accepts = _imapper.Map<List<ErpDocumentAccept>, List<DocumentFlowDto>>(acceptQuerys);
                    list = list.Union(accepts).ToList();
                }

                var data = new List<DocumentFlowDto>();

                var user = await _userRedisImp.GetByIdAsync(((int)user_id.Value).ToString());
                var dels = await _erpDocumentDelImp.GetByUserAsync(server_id, user_id);
                foreach (var item in list)
                {
                    //已删除
                    if (dels.Contains(item.document_id))
                    {
                        continue;
                    }

                    //主送人查看
                    if (item.main_persons.Contains(user_id.Value))
                    {
                        if (data.Count(x => x.document_id == item.document_id) < 1)
                        {
                            data.Add(item);
                        }
                    }
                    //抄送人查看
                    if (item.copy_persons.Contains(user_id.Value))
                    {
                        if (data.Count(x => x.document_id == item.document_id) < 1)
                        {
                            data.Add(item);
                        }
                    }
                    //主送部门查看
                    if (item.main_department == user.i_department_base)
                    {
                        if (data.Count(x => x.document_id == item.document_id) < 1)
                        {
                            data.Add(item);
                        }
                    }
                    //抄送部门查看
                    if (!string.IsNullOrWhiteSpace(item.copy_departments) &&
                        item.copy_departments.Contains(user.i_department_base.Value.ToString()))
                    {
                        if (data.Count(x => x.document_id == item.document_id) < 1)
                        {
                            data.Add(item);
                        }
                    }
                }

                Func<DocumentFlowDto, bool> exp = x =>
                {
                    var state_exp = input.state > 0 ? x.state == (DocumentState)input.state : true;
                    return state_exp;
                };
                data = data.Where(exp).OrderByDescending(x => x.finish_date).ToList();
                totalCount = data.Count();
                data = data.Skip((input.page_index - 1) * input.page_size).Take(input.page_size).ToList();
                return (data, totalCount);
            }
        }    
       
        /// <summary>
        /// 获取发文流程详细
        /// </summary>
        /// <param name="flow_id"></param>
        /// <param name="server_id"></param>
        /// <returns></returns>
        public async Task<List<ReviewState>> GetFlowDataAsync(decimal user_id, int flow_id, int flow_record_id, decimal doc_id, string server_id, int type)
        {
            if (doc_id > 0)
            {
                //查询发文记录
                var query = await SqlSugarHelper.DBClient(server_id)
                                    .Queryable<ErpDocumentMain>()
                                    .FirstAsync(x => x.id == doc_id);
                if (query != null && query.state > 0)
                {
                    var data = await _erpFlowCheckImp.GetFlowStepAsync(server_id, flow_record_id);
                    return _imapper.Map<List<FlowStepDto>, List<ReviewState>>(data);
                }

                //查询收文记录
                var query2 = await SqlSugarHelper.DBClient(server_id)
                                    .Queryable<ErpDocumentAccept>()
                                    .FirstAsync(x => x.id == doc_id);
                if (query2 != null && query2.state > 0)
                {
                    var data = await _erpFlowCheckImp.GetFlowStepAsync(server_id, flow_record_id);
                    return _imapper.Map<List<FlowStepDto>, List<ReviewState>>(data);
                }
            }

            var list = await _erpFlowStepInitImp.GetByFlowId(server_id, user_id, flow_id);
            return _imapper.Map<List<ErpFlowStepInitDto>, List<ReviewState>>(list);
        }

        private string GetLongTime(TimeSpan ts)
        {
            StringBuilder str = new StringBuilder();
            if (ts.Days > 0)
            {
                str.Append($"{ts.Days}天");
            }
            if (ts.Hours > 0)
            {
                str.Append($"{ts.Hours}小时");
            }
            if (ts.Minutes > 0)
            {
                str.Append($"{ts.Minutes}分钟");
            }
            if (ts.Seconds > 0)
            {
                str.Append($"{ts.Seconds}秒");
            }
            return str.ToString();
        }
        
    }
}
