﻿using AutoMapper;
using ERPDal;
using ERPModel.Documents.DocumentMain;
using ERPModel.Documents.DocumentSeals;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.Documents
{
    public class DocumentSealImp: IDocumentSealImp
    {
        private readonly IMapper _imapper;

        public DocumentSealImp(IMapper imapper)
        {
            _imapper = imapper; ;
        }

        public async Task<List<DocumentSealDto>> GetListAsync(string server_id, decimal document_id)
        {
            var query = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpDocumentSeal>()
                                .Where(x => x.document_id == document_id)
                                .ToListAsync();
            return _imapper.Map<List<ErpDocumentSeal>, List<DocumentSealDto>>(query);
        }

        public async Task AddAsync(string server_id, decimal? user_id, List<DocumentSeal> input, int document_id)
        {
            if(input == null || input.Count < 1)
            {
                return;
            }
            await DeleteAsync(server_id, document_id);
            var list = _imapper.Map<List<DocumentSeal>, List<ErpDocumentSeal>>(input);
            foreach(var item in list)
            {
                item.id = ERPBll.Tools.GetEngineID(server_id);
                item.document_id = document_id;
                item.created_id = user_id;
            }
            await SqlSugarHelper.DBClient(server_id).Insertable<ErpDocumentSeal>(list).ExecuteCommandAsync();
        }

        public async Task<int> DeleteAsync(string server_id, decimal id)
        {
            return await SqlSugarHelper.DBClient(server_id)
                            .Deleteable<ErpDocumentSeal>()
                            .Where(x => x.document_id == id)
                            .ExecuteCommandAsync();
        }
    }
}
