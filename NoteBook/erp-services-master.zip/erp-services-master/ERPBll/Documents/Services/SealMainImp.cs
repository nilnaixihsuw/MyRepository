﻿using AutoMapper;
using ERPCore.ORM;
using ERPDal;
using ERPModel.Documents;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.Documents
{
    public class SealMainImp : ISealMainImp
    {
        private readonly IMapper _imapper;

        public SealMainImp(
            IMapper imapper)
        {
            _imapper = imapper;;
        }

        public async Task<List<SealMainDto>> GetListAsync(string server_id)
        {
            var query = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpSealMain>()
                                .ToListAsync();
            return _imapper.Map<List<ErpSealMain>, List<SealMainDto>>(query);
        }

        public Task<SealMainDto> AddAsync(string server_id, decimal? user_id, CreateOrUpdateSealMain input)
        {
            var info = _imapper.Map<CreateOrUpdateSealMain, ErpSealMain>(input);
            info.id = ERPBll.Tools.GetEngineID(server_id);
            info.created_id = user_id;

            SqlSugarHelper.DBClient(server_id).Insertable<ErpSealMain>(info).ExecuteCommand();
            return Task.FromResult(_imapper.Map<ErpSealMain, SealMainDto>(info));
        }

        public async Task<SealMainDto> UpdateAsync(string server_id, decimal? user_id, CreateOrUpdateSealMain input)
        {
            var query = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpSealMain>()
                                .FirstAsync(x => x.id == input.id);
            if (query == null)
            {
                throw new Exception("未找到电子印章");
            }

            _imapper.Map<CreateOrUpdateSealMain, ErpSealMain>(input, query);
            query.update_id = user_id;
            query.update_date = DateTime.Now;
            SqlSugarHelper.DBClient(server_id).Updateable<ErpSealMain>(query).ExecuteCommand(); ;

            return _imapper.Map<ErpSealMain, SealMainDto>(query);
        }

        public Task<int> DeleteAsync(string server_id, decimal id)
        {
            return Task.FromResult(
                        SqlSugarHelper.DBClient(server_id).Deleteable<ErpSealMain>().In(id).ExecuteCommand());
        }

        public Task<int> DeleteManyAsync(string server_id, List<decimal> ids)
        {
            return Task.FromResult(
                         SqlSugarHelper.DBClient(server_id).Deleteable<ErpSealMain>().In(ids).ExecuteCommand());
        }
    }
}
