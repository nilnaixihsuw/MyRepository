﻿using AutoMapper;
using ERPCore.Helpers;
using ERPDal;
using ERPModel.Documents;
using ERPModel.Documents.DocumentHeads;
using ERPModel.Documents.DocumentMain;
using ERPModel.Tools;
using Newtonsoft.Json;
using Spire.Doc;
using Spire.Doc.Documents;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.Documents
{
    public class DocumentHeadImp: IDocumentHeadImp
    {
        private readonly IMapper _imapper;
        private readonly IDocumentMainImp _documentMainImp;

        public DocumentHeadImp(
            IMapper imapper,
            IDocumentMainImp documentMainImp)
        {
            _imapper = imapper;
            _documentMainImp = documentMainImp;
        }

        public async Task<List<DocumentHeadDto>> GetListAsync(string server_id)
        {
            var query = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpDocumentHead>()
                                .Mapper(x => x.created_info, x => x.created_id)
                                .ToListAsync();
            return _imapper.Map<List<ErpDocumentHead>, List<DocumentHeadDto>>(query);
        }

        public Task<DocumentHeadDto> AddAsync(string server_id, decimal? user_id, CreateOrUpdateDocumentHead input)
        {
            var info = _imapper.Map<CreateOrUpdateDocumentHead, ErpDocumentHead>(input);
            info.id = ERPBll.Tools.GetEngineID(server_id);
            info.created_id = user_id;

            SqlSugarHelper.DBClient(server_id).Insertable<ErpDocumentHead>(info).ExecuteCommand();
            return Task.FromResult(_imapper.Map<ErpDocumentHead, DocumentHeadDto>(info));
        }

        public async Task<DocumentHeadDto> UpdateAsync(string server_id, decimal? user_id, CreateOrUpdateDocumentHead input)
        {
            var query = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpDocumentHead>()
                                .FirstAsync(x => x.id == input.id);
            if (query == null)
            {
                throw new Exception("未找到套红模板");
            }

            _imapper.Map<CreateOrUpdateDocumentHead, ErpDocumentHead>(input, query);
            query.update_id = user_id;
            query.update_date = DateTime.Now;
            SqlSugarHelper.DBClient(server_id).Updateable<ErpDocumentHead>(query).ExecuteCommand(); ;

            return _imapper.Map<ErpDocumentHead, DocumentHeadDto>(query);
        }

        public Task<int> DeleteAsync(string server_id, decimal id)
        {
            return Task.FromResult(
                        SqlSugarHelper.DBClient(server_id).Deleteable<ErpDocumentHead>().In(id).ExecuteCommand());
        }

        public Task<int> DeleteManyAsync(string server_id, List<decimal> ids)
        {
            return Task.FromResult(
                         SqlSugarHelper.DBClient(server_id).Deleteable<ErpDocumentHead>().In(ids).ExecuteCommand());
        }

        public async Task<(string, string)> GetDocs(string server_id, decimal? user_id, int document_id, int head_id)
        {
            var head = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpDocumentHead>()
                                .FirstAsync(x => x.id == head_id);

            if (head == null)
            {
                throw new Exception("未找到套红模板");
            }

            var doc_main = await _documentMainImp.GetByIdAsync(server_id, user_id, document_id);
            if (doc_main == null)
            {
                throw new Exception("未找到发文记录");
            }

            var data = JsonConvert.DeserializeObject<DocumentHeadContent>(System.Text.Encoding.UTF8.GetString(head.content));

            return (GetHeadDoc(data, doc_main), GetFootDoc(data, doc_main));
        }

        public string GetHeadDoc(DocumentHeadContent data, DocumentMainDto doc_main)
        {
            var path = GlobalVars.is_local ? Directory.GetCurrentDirectory() : AppDomain.CurrentDomain.SetupInformation.ApplicationBase;
            string host = GlobalVars.file_url["server_url"];
            string date = DateTime.Now.ToString("yyyy-MM-dd");

            //实例化一个Document对象,并添加section
            Spire.Doc.Document doc = new Spire.Doc.Document();
            doc.LoadFromFile(path + $"/wwwroot/Document/doc.docx", FileFormat.Docx);

            Section sec = doc.AddSection();

            if (data.secret_view == "0") //保密等级
            {
                WordExportHelper.SetParagraph(sec, HorizontalAlignment.Right,
                    new WordText() { text = doc_main.secret_name });
            }

            if (data.degree_view == "0") //缓急程度
            {
                WordExportHelper.SetParagraph(sec, HorizontalAlignment.Right,
                    new WordText() { text = doc_main.degree_name });
            }
            if (data.titleList != null && data.titleList.Count > 0)
            {
                foreach (var item in data.titleList)
                {
                    //套红标题
                    WordExportHelper.SetParagraphs(sec, HorizontalAlignment.Distribute,
                        new List<WordText>()
                        {
                            new WordText()
                            {
                                text = item.title,
                                font_name = "华文中宋",
                                font_size = 72,
                                text_color = Color.Red,
                                is_blod = true,
                                text_scale = Convert.ToInt16(item.zoom)
                            }
                        });
                }
            }

            if (doc_main.type < DocumentType.平行文函) //上行文
            {
                if(!string.IsNullOrWhiteSpace(data.userName))
                {
                    string text = "签发人：" + data.userName;
                    string qfr = doc_main.font_number.PadRight(44 - doc_main.font_number.Length - text.Length, ' ');
                   
                    //字号
                    WordExportHelper.SetParagraph(sec, HorizontalAlignment.Distribute,
                            new WordText() { text = qfr + text });
                }
                else
                {
                    //字号
                    WordExportHelper.SetParagraph(sec, HorizontalAlignment.Left,
                            new WordText() { text = doc_main.font_number });
                }
            }
            else
            {
                //字号
                WordExportHelper.SetParagraph(sec, HorizontalAlignment.Center,
                        new WordText() { text = doc_main.font_number });
            }

            if (data.fiveType == "0") //红线五角星
            {
                string text = "".PadRight(16, ' ');
                WordExportHelper.SetParagraphs(sec, HorizontalAlignment.Justify,
                    new List<WordText>()
                    {
                        new WordText()
                        {
                            text = text,
                            font_name = "Times New Roman",
                            font_size = 26,
                            text_color = Color.Red,
                            IsStrikeout = true,
                        },
                        new WordText()
                        {
                            text = "★",
                            font_name = "黑体",
                            font_size = 22,
                            text_color = Color.Red,
                        },
                        new WordText()
                        {
                            text = text,
                            font_name = "Times New Roman",
                            font_size = 26,
                            text_color = Color.Red,
                            IsStrikeout = true,
                        }
                    });
            }
            else
            {
                string text = "".PadRight(34, ' ');
                WordExportHelper.SetParagraph(sec, HorizontalAlignment.Justify,
                    new WordText()
                    {
                        text = text,
                        font_name = "Times New Roman",
                        font_size = 26,
                        text_color = Color.Red,
                        IsStrikeout = true,
                    });
           }

            var filename = WordExportHelper.SaveDoc(doc, path + $"/wwwroot/Document/{date}", "head");
          
            return $"{host}/Document/{date}/{filename}";
        }

        public string GetFootDoc(DocumentHeadContent data, DocumentMainDto doc_main)
        {
            int lineWidth = 428;
            var path = GlobalVars.is_local ? Directory.GetCurrentDirectory() : AppDomain.CurrentDomain.SetupInformation.ApplicationBase;
            string host = GlobalVars.file_url["server_url"];
            string date = DateTime.Now.ToString("yyyy-MM-dd");

            //实例化一个Document对象,并添加section
            Spire.Doc.Document doc = new Spire.Doc.Document();
            doc.LoadFromFile(path + $"/wwwroot/Document/doc.docx", FileFormat.Docx);

            Section sec = doc.AddSection();

            if (data.keyword_view == "0") //主题词
            {
                var p = WordExportHelper.SetParagraph(sec, HorizontalAlignment.Left,
                    new WordText() { text = " 主题词：" + doc_main.keyword });

                WordExportHelper.SetLine(sec, lineWidth, p);
            }

            if (data.main_department_view == "0" || data.copy_department_view == "0") 
            {
                Paragraph p = null;
                if (data.main_department_view == "0") //主送单位
                {
                    p = WordExportHelper.SetParagraph(sec, HorizontalAlignment.Left,
                        new WordText() { text = " 主送单位：" + doc_main.main_department_name });
                }
                if (data.copy_department_view == "0") //抄送单位
                {
                    p = WordExportHelper.SetParagraph(sec, HorizontalAlignment.Left,
                    new WordText() { text = " 抄送单位：" + doc_main.copy_department_names });
                }

                WordExportHelper.SetLine(sec, lineWidth, p);
            }

            if(data.posy_time_view == "0")
            {
                string yf = data.department_name_yf.PadRight(31 - data.department_name_yf.Length, ' ');
                //印发日期
                var p1 = WordExportHelper.SetParagraph(sec, HorizontalAlignment.Distribute,
                    new WordText()
                    {
                        text = " " + yf + $"{doc_main.posy_time.ToString("yyyy年MM月dd日")}印发"
                    });
                WordExportHelper.SetLine(sec, lineWidth, p1);
            }
            else
            {
                //印发部门
                WordExportHelper.SetParagraph(sec, HorizontalAlignment.Left,
                    new WordText() { text = data.department_name_yf });
            }

            if (data.post_count_view == "0")
            {
                //印发份数
                WordExportHelper.SetParagraph(sec, HorizontalAlignment.Right,
                            new WordText() { text = $"共印{doc_main.post_count}份" });
            }


            var filename = WordExportHelper.SaveDoc(doc, path + $"/wwwroot/Document/{date}", "foot");

            return $"{host}/Document/{date}/{filename}";
        }
    }
}
