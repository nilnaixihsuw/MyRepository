﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using ERPBll.Documents.Contracts;
using ERPDal;
using ERPModel.Documents.ErpDocumentHiss;
using SqlSugar;

namespace ERPBll.Documents.Services
{
    public class DocumentHisImp: IDocumentHisImp
    {
        private readonly IMapper _imapper;

        public DocumentHisImp(IMapper imapper)
        {
            _imapper = imapper;
        }

        public async Task<(List<DocumentHisDto>, int)> GetByPageAsync(string server_id, decimal? user_id, DocumentHisQueryInput input)
        {
            RefAsync<int> totalCount = 0;

            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpDocumentHis>()
                                .Where(input.ToExp())                 
                                .Mapper(x => x.created_info, x => x.created_id)
                                .OrderBy(x => x.id, OrderByType.Desc)
                                .ToPageListAsync(input.page_index, input.page_size, totalCount);

            var data = _imapper.Map<List<ErpDocumentHis>, List<DocumentHisDto>>(list);

            return (data, totalCount);
        }


        public async Task AddAsync(string server_id, decimal? user_id, List<CreateDocumentHis> input)
        {
            if (input == null || input.Count < 1)
            {
                return;
            }
            var list = _imapper.Map<List<CreateDocumentHis>, List<ErpDocumentHis>>(input);
            list.ForEach(x =>
            {
                x.created_date = DateTime.Now;
                x.created_id = user_id;
            });
            await SqlSugarHelper.DBClient(server_id).Insertable<ErpDocumentHis>(list).ExecuteCommandAsync();
        }

        public async Task<int> DeleteAsync(string server_id, List<decimal> ids)
        {
            return await SqlSugarHelper.DBClient(server_id)
                            .Deleteable<ErpDocumentHis>()
                            .Where(x => ids.Contains(x.id))
                            .ExecuteCommandAsync();
        }
    }
}
