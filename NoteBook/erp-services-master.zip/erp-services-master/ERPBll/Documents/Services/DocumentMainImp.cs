﻿using AutoMapper;
using DotNetCore.CAP;
using ERPBll.Caps;
using ERPBll.FlowManage.Contracts;
using ERPBll.UserManage;
using ERPDal;
using ERPModel.Documents;
using ERPModel.Documents.DocumentFlows;
using ERPModel.Documents.DocumentMain;
using ERPModel.Documents.DocumentSeals;
using ERPModel.Documents.ErpDocumentPersons;
using ERPModel.FlowManage;
using ERPModel.FlowManage.ErpFlowChecks;
using ERPModel.FlowManage.FlowRecords;
using ERPModel.UserManage;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.Documents
{
    public class DocumentMainImp : IDocumentMainImp, ICapSubscribe
    {
        private readonly IMapper _imapper;
        private readonly IErpDocumentFlowImp _erpDocumentFlowImp;
        private readonly IDocumentSealImp _documentSealImp;
        private readonly IDocumentPersonImp _documentPersonImp;
        private readonly IDocumentFileImp _documentFileImp;
        private readonly IErpFlowRecordImp _erpFlowRecordImp;
        private readonly IErpFlowCheckImp _erpFlowCheckImp;

        public DocumentMainImp(
           IMapper imapper,
           IErpDocumentFlowImp erpDocumentFlowImp,
           IDocumentSealImp documentSealImp,
           IDocumentPersonImp documentPersonImp,
           IDocumentFileImp documentFileImp,
           IErpFlowRecordImp erpFlowRecordImp,
           IErpFlowCheckImp erpFlowCheckImp)
        {
            _imapper = imapper;
            _erpDocumentFlowImp = erpDocumentFlowImp;
            _documentSealImp = documentSealImp;
            _documentPersonImp = documentPersonImp;
            _documentFileImp = documentFileImp;
            _erpFlowRecordImp = erpFlowRecordImp;
            _erpFlowCheckImp = erpFlowCheckImp;
        }

        public async Task<(List<DocumentMainDto>, int)> GetAllByPageAsync(
            string server_id, decimal? user_id, DocumentMainQueryInput input)
        {
            //加权限
            input.department_ids = RoleInfoBll.GetGroupID(server_id, user_id);

            RefAsync<int> totalCount = 0;

            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpDocumentMain>()
                                .Where(input.ToExp())
                                .Mapper(x => x.post_info, x => x.post_id)
                                .Mapper(x => x.head_info, x => x.head_id)
                                .Mapper(x => x.created_info, x => x.created_id)
                                .Mapper(x => x.main_department_info, x => x.main_department)
                                .Mapper(x => x.department_info, x => x.department_id)
                                .Mapper(x => x.flow_info, x => x.flow_id)
                                .Mapper(x => x.files, x => x.files.First().document_id)
                                .Mapper(async x =>
                                {
                                    x.document_seals = await SqlSugarHelper.DBClient(server_id)
                                                            .Queryable<ErpDocumentSeal>()
                                                            .Where(i => i.document_id == x.id)
                                                            .Mapper(x => x.seal_info, x => x.seal_id)
                                                            .ToListAsync();

                                    var copy_department_info = await SqlSugarHelper.DBClient(server_id)
                                                            .Queryable<SysDepartment>()
                                                            .Where(i => x.copy_departments.Contains(i.i_id.ToString()))
                                                            .ToListAsync();

                                    x.main_person_details = await SqlSugarHelper.DBClient(server_id)
                                                           .Queryable<ErpDocumentPerson>()
                                                           .Where(it => it.document_id == x.id && it.type == 1 && it.kind == 1)
                                                           .Mapper(x => x.person_info, x => x.person_id)
                                                           .ToListAsync();

                                    x.copy_person_details = await SqlSugarHelper.DBClient(server_id)
                                                           .Queryable<ErpDocumentPerson>()
                                                           .Where(it => it.document_id == x.id && it.type == 1 && it.kind == 2)
                                                           .Mapper(x => x.person_info, x => x.person_id)
                                                           .ToListAsync();

                                    x.copy_department_names = string.Join(',', copy_department_info.Select(x => x.c_name));
                                    //if (x.state == DocumentState.草稿)
                                    //{
                                    //    x.user_ids = new List<decimal>() { x.created_id.Value };
                                    //    x.user_names = x.created_info.c_name;
                                    //}
                                })
                                .OrderByIF(input.order_type == 0, x => x.created_date, OrderByType.Desc)
                                .OrderByIF(input.order_type == 1, x => x.number, OrderByType.Desc)
                                .OrderByIF(input.order_type == 2, x => x.code, OrderByType.Desc)
                                .ToPageListAsync(input.page_index, input.page_size, totalCount);

            if (list == null || list.Count < 1)
            {
                return (new List<DocumentMainDto>(), totalCount);
            }

            var all = await _erpFlowRecordImp.GetListAsync(server_id, user_id,
               new FlowRecordQuery()
               {
                   detail_ids = list.Select(x => x.id).ToList()
               });
            foreach (var item in list)
            {
                if (item.state == DocumentState.待处理)
                {

                    var info = all.FirstOrDefault(x => x.detail_id == item.id);
                    if (info != null && info.wait_flow_step != null)
                    {
                        item.user_ids = info.state_child_id;
                        item.user_names = info.state_child_name;
                        item.step_id = info.wait_flow_step.id;
                        item.step_name = info.wait_flow_step.title;
                    }
                }
            }
            var data = _imapper.Map<List<ErpDocumentMain>, List<DocumentMainDto>>(list);

            return (data, totalCount);
        }

        public async Task<(List<DocumentMainDto>, int)> GetByPageAsync(
            string server_id, decimal? user_id, DocumentMainQueryInput input)
        {
            RefAsync<int> totalCount = 0;

            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpDocumentMain>()
                                .Where(input.ToExp())
                                .Where(x => x.created_id == user_id)
                                .Mapper(x => x.post_info, x => x.post_id)
                                .Mapper(x => x.head_info, x => x.head_id)
                                .Mapper(x => x.created_info, x => x.created_id)
                                .Mapper(x => x.main_department_info, x => x.main_department)
                                .Mapper(x => x.department_info, x => x.department_id)
                                .Mapper(x => x.flow_info, x => x.flow_id)
                                .Mapper(x => x.files, x => x.files.First().document_id)
                                .Mapper(async x =>
                                {
                                    x.document_seals = await SqlSugarHelper.DBClient(server_id)
                                                            .Queryable<ErpDocumentSeal>()
                                                            .Where(i => i.document_id == x.id)
                                                            .Mapper(x => x.seal_info, x => x.seal_id)
                                                            .ToListAsync();

                                    var copy_department_info = await SqlSugarHelper.DBClient(server_id)
                                                            .Queryable<SysDepartment>()
                                                            .Where(i => x.copy_departments.Contains(i.i_id.ToString()))
                                                            .ToListAsync();

                                    x.main_person_details = await SqlSugarHelper.DBClient(server_id)
                                                           .Queryable<ErpDocumentPerson>()
                                                           .Where(it => it.document_id == x.id && it.type == 1 && it.kind == 1)
                                                           .Mapper(x => x.person_info, x => x.person_id)
                                                           .ToListAsync();

                                    x.copy_person_details = await SqlSugarHelper.DBClient(server_id)
                                                           .Queryable<ErpDocumentPerson>()
                                                           .Where(it => it.document_id == x.id && it.type == 1 && it.kind == 2)
                                                           .Mapper(x => x.person_info, x => x.person_id)
                                                           .ToListAsync();

                                    if (!string.IsNullOrWhiteSpace(x.copy_departments))
                                    {
                                        x._copy_department = x.copy_departments.Split(',').ToList()
                                            .ConvertAll(x => Convert.ToDecimal(x));
                                    }
                                    x.copy_department_names = string.Join(',', copy_department_info.Select(x => x.c_name));
                                    //if (x.state == DocumentState.草稿)
                                    //{
                                    //    x.user_ids = new List<decimal>() { x.created_id.Value };
                                    //    x.user_names = x.created_info.c_name;
                                    //}
                                })
                                .OrderByIF(input.order_type == 0, x => x.created_date, OrderByType.Desc)
                                .OrderByIF(input.order_type == 1, x => x.number, OrderByType.Desc)
                                .OrderByIF(input.order_type == 2, x => x.code, OrderByType.Desc)
                                .ToPageListAsync(input.page_index, input.page_size, totalCount);

            if (list == null || list.Count < 1)
            {
                return (new List<DocumentMainDto>(), totalCount);
            }

            var all = await _erpFlowRecordImp.GetListAsync(server_id, user_id,
                new FlowRecordQuery()
                {
                    detail_ids = list.Select(x => x.id).ToList()
                });
            foreach (var item in list)
            {
                if (item.state == DocumentState.待处理)
                {
                    var info = all.FirstOrDefault(x => x.detail_id == item.id);
                    if (info != null && info.wait_flow_step != null)
                    {
                        item.user_ids = info.state_child_id;
                        item.user_names = info.state_child_name;
                        item.step_id = info.wait_flow_step.id;
                        item.step_name = info.wait_flow_step.title;
                    }
                }
            }
            var data = _imapper.Map<List<ErpDocumentMain>, List<DocumentMainDto>>(list);

            return (data, totalCount);
        }

        public async Task<DocumentMainDto> GetByIdAsync(string server_id, decimal? user_id, int id)
        {
            //查询
            var info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpDocumentMain>()
                                .Where(x => x.id == id)
                                .Mapper(x => x.post_info, x => x.post_id)
                                .Mapper(x => x.head_info, x => x.head_id)
                                .Mapper(x => x.main_department_info, x => x.main_department)
                                .Mapper(x => x.department_info, x => x.department_id)
                                .Mapper(x => x.flow_info, x => x.flow_id)
                                .Mapper(x => x.files, x => x.files.First().document_id)
                                .Mapper(async x =>
                                {
                                    x.document_seals = await SqlSugarHelper.DBClient(server_id)
                                                            .Queryable<ErpDocumentSeal>()
                                                            .Where(i => i.document_id == x.id)
                                                            .Mapper(x => x.seal_info, x => x.seal_id)
                                                            .ToListAsync();

                                    var copy_department_info = await SqlSugarHelper.DBClient(server_id)
                                                            .Queryable<SysDepartment>()
                                                            .Where(i => x.copy_departments.Contains(i.i_id.ToString()))
                                                            .ToListAsync();

                                    x.main_person_details = await SqlSugarHelper.DBClient(server_id)
                                                           .Queryable<ErpDocumentPerson>()
                                                           .Where(it => it.document_id == x.id && it.type == 1 && it.kind == 1)
                                                           .Mapper(x => x.person_info, x => x.person_id)
                                                           .ToListAsync();

                                    x.copy_person_details = await SqlSugarHelper.DBClient(server_id)
                                                           .Queryable<ErpDocumentPerson>()
                                                           .Where(it => it.document_id == x.id && it.type == 1 && it.kind == 2)
                                                           .Mapper(x => x.person_info, x => x.person_id)
                                                           .ToListAsync();

                                    x.copy_department_names = string.Join(',', copy_department_info.Select(x => x.c_name));
                                    //if (x.state == DocumentState.草稿)
                                    //{
                                    //    x.user_ids = new List<decimal>() { x.created_id.Value };
                                    //}
                                })
                                .FirstAsync();



            if (info != null && info.state == DocumentState.待处理)
            {
                var all = await _erpFlowRecordImp.GetListAsync(server_id, user_id,
                   new FlowRecordQuery()
                   {
                       detail_ids = new List<int> { info.id }
                   });

                if (all != null && all.Count > 0 && all[0].wait_flow_step != null)
                {
                    info.user_ids = all[0].state_child_id;
                    info.user_names = all[0].state_child_name;
                    info.step_id = all[0].wait_flow_step.id;
                    info.step_name = all[0].wait_flow_step.title;
                }
            }

            var data = _imapper.Map<ErpDocumentMain, DocumentMainDto>(info);

            return data;
        }

        public async Task<List<string>> GetFontNumberAsync(string server_id)
        {
            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpDocumentMain>()
                                .Where(x => x.state != DocumentState.已作废)
                                .Select(x => x.font_number)
                                .ToListAsync();

            return list.Distinct().ToList();
        }

        public async Task<DocumentMainDto> AddAsync(string server_id, decimal? user_id, CreateOrUpdateDocumentMain input)
        {
            var info = _imapper.Map<CreateOrUpdateDocumentMain, ErpDocumentMain>(input);
            info.id = ERPBll.Tools.GetEngineID(server_id);
            info.SetCreate(user_id);

            //附件
            if (input.files != null && input.files.Count > 0)
            {
                await _documentFileImp.AddAsync(server_id, user_id, input.files, info.id);
            }
            //主送人员
            if (input.main_persons != null && input.main_persons.Count > 0)
            {
                await _documentPersonImp.AddAsync(server_id, user_id, input.main_persons, info.id, 1, 1);
            }
            //抄送人员
            if (input.copy_persons != null && input.copy_persons.Count > 0)
            {
                await _documentPersonImp.AddAsync(server_id, user_id, input.copy_persons, info.id, 1, 2);
            }
            await SqlSugarHelper.DBClient(server_id).Insertable(info).ExecuteCommandAsync();
            return _imapper.Map<ErpDocumentMain, DocumentMainDto>(info);
        }

        public async Task<DocumentMainDto> UpdateAsync(string server_id, decimal? user_id, CreateOrUpdateDocumentMain input)
        {
            var info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpDocumentMain>().FirstAsync(x => x.id == input.id);
            if (info == null)
            {
                throw new Exception($"未找到发文记录，id={input.id}");
            }
            _imapper.Map<CreateOrUpdateDocumentMain, ErpDocumentMain>(input, info);
            info.SetUpdate(user_id);

            if (info.state == DocumentState.已驳回) //重新生成记录
            {
                info.commit = 1;
                await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync();

                info.id = Tools.GetSeqCommonID(server_id);
                info.state = DocumentState.草稿;
                info.created_date = DateTime.Now;
                info.commit = 0;
                await SqlSugarHelper.DBClient(server_id).Insertable(info).ExecuteCommandAsync();
            }
            else
            {
                await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync();
                await _documentFileImp.DeleteAsync(server_id, info.id);  
                await _documentPersonImp.DeleteAsync(server_id, info.id);       
            }
            //附件
            if (input.files != null && input.files.Count > 0)
            {
                await _documentFileImp.AddAsync(server_id, user_id, input.files, info.id);
            }
            //主送人员
            if (input.main_persons != null && input.main_persons.Count > 0)
            {
                await _documentPersonImp.AddAsync(server_id, user_id, input.main_persons, info.id, 1, 1);
            }
            //抄送人员
            if (input.copy_persons != null && input.copy_persons.Count > 0)
            {
                await _documentPersonImp.AddAsync(server_id, user_id, input.copy_persons, info.id, 1, 2);
            }

            return _imapper.Map<ErpDocumentMain, DocumentMainDto>(info);
        }

        public async Task<DocumentMainDto> UpdateContentAsync(string server_id, decimal? user_id, UpdateDocumentContent input)
        {
            var info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpDocumentMain>().FirstAsync(x => x.id == input.id);
            if (info == null)
            {
                throw new Exception($"未找到发文记录，id={input.id}");
            }
            _imapper.Map<UpdateDocumentContent, ErpDocumentMain>(input, info);
            info.SetUpdate(user_id);

            await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync();

            await _documentFileImp.DeleteAsync(server_id, info.id);
            //附件
            if (input.files != null && input.files.Count > 0)
            {
                await _documentFileImp.AddAsync(server_id, user_id, input.files, info.id);
            }

            return _imapper.Map<ErpDocumentMain, DocumentMainDto>(info);
        }

        public async Task<DocumentMainDto> UpdateStateAsync(string server_id, decimal? user_id, UpdateDocumentState input)
        {
            var info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpDocumentMain>()
                                .Mapper(x => x.post_info, x => x.post_id)
                                .Mapper(x => x.files, x => x.files.First().document_id)
                                .Mapper(x => x.main_person_details, x => x.main_person_details.First().document_id)
                                .FirstAsync(x => x.id == input.document_id);
            if (info == null)
            {
                throw new Exception($"未找到发文记录，id={input.document_id}");
            }

            //重新提交
            if (info.state == DocumentState.已驳回 && input.again.Value == 1)
            {
                info.commit = 1;
                await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync();

                info.id = Tools.GetSeqCommonID(server_id);
                info.code = await GetMaxCodeAsync(server_id);
                info.state = DocumentState.待处理;
                info.created_date = DateTime.Now;
                info.commit = 0;

                //发起审核
                var flowRecord = await _erpFlowRecordImp.StartByDocAsync(server_id,
                    new StartFlowInput
                    {
                        content = DocumentMessage.GetContent(info),
                        type = 2,
                        object_id = (int)FlowRecordType.发文审批,
                        detail_id = info.id,
                        flow_init_id = input.flow_id,
                        user_id = info.post_id
                    });
                if (flowRecord != null)
                {
                    info.flow_record_id = flowRecord.id;
                }
                
                //附件
                if (info.files != null && info.files.Count > 0)
                {
                    info.files.ForEach(x => x.document_id = info.id);
                    await SqlSugarHelper.DBClient(server_id).Insertable(info.files).ExecuteCommandAsync();
                }
                //主送人员/抄送人员
                if (info.main_person_details != null && info.main_person_details.Count > 0)
                {
                    info.main_person_details.ForEach(x => x.document_id = info.id);
                    await SqlSugarHelper.DBClient(server_id).Insertable(info.main_person_details).ExecuteCommandAsync();
                }

                await SqlSugarHelper.DBClient(server_id).Insertable(info).ExecuteCommandAsync();
                return _imapper.Map<ErpDocumentMain, DocumentMainDto>(info);
            }

            if (info.state == DocumentState.已驳回)
            {
                throw new Exception($"当前发文记录已驳回，不允许审批");
            }

            if (info.state == DocumentState.已作废)
            {
                throw new Exception($"当前发文记录已作废，不允许审批");
            }

            if (input.state_name == "草稿" || string.IsNullOrWhiteSpace(input.state_name))
            {
                if (info.post_id != user_id && info.created_id != user_id)
                {
                    throw new Exception($"无操作权限");
                }

                info.code = await GetMaxCodeAsync(server_id);
                info.state = DocumentState.待处理;

                //发起审核
                var flowRecord = await _erpFlowRecordImp.StartByDocAsync(server_id,
                    new StartFlowInput
                    {
                        content = DocumentMessage.GetContent(info),
                        type = 2,
                        object_id = (int)FlowRecordType.发文审批,
                        detail_id = input.document_id,
                        flow_init_id = input.flow_id,
                        user_id = info.post_id
                    });
                if (flowRecord != null)
                {
                    info.flow_record_id = flowRecord.id;
                }
                await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync();
            }
            else
            {
                info.SetState(input);

                //当前是盖章操作
                if (input.document_seals != null && input.document_seals.Count > 0)
                {
                    await _documentSealImp.AddAsync(server_id, user_id, input.document_seals, input.document_id);
                }

                await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync();

                var check = new UpdateErpFlowCheck()
                {
                    flow_id = input.flow_record_id,
                    step_id = input.state,
                    state = input.result + 1,
                    remark = input.remark,
                };
                await _erpFlowCheckImp.UpdateAsync(server_id, user_id, check);
            }
            return _imapper.Map<ErpDocumentMain, DocumentMainDto>(info);
        }

        public async Task<List<DocumentMainDto>> UpdateScrapAsync(string server_id, List<int> ids)
        {
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpDocumentMain>()
                                .Where(x => ids.Contains(x.id))
                                .ToListAsync();

            if (list == null || list.Count < 1)
            {
                throw new Exception($"未找到发文记录");
            }

            list.ForEach(x =>
            {
                x.state = DocumentState.已作废;
                x.font_number = "";
            });
            await SqlSugarHelper.DBClient(server_id).Updateable(list).UpdateColumns(x => new { x.state, x.font_number }).ExecuteCommandAsync();
            return _imapper.Map<List<ErpDocumentMain>, List<DocumentMainDto>>(list);
        }

        public Task<int> DeleteManyAsync(string server_id, List<decimal> ids)
        {
            return Task.FromResult(SqlSugarHelper.DBClient(server_id)
                .Deleteable<ErpDocumentMain>()
                .In(ids).ExecuteCommand());
        }

        public async Task<string> GetMaxCodeAsync(string server_id)
        {
            //查询
            var code = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpDocumentMain>()
                                .MaxAsync(x => x.code);

            return (Convert.ToInt32(code) + 1).ToString().PadLeft(5, '0');
        }

        public async Task<(List<int>, int)> GetNumberAsync(string server_id, string font, int year)
        {
            //查询
            var query = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpDocumentMain>()
                                .Where(x => x.state != DocumentState.已作废 && x.font == font && x.year == year)
                                .Select(x => x.number)
                                .ToListAsync();

            if (query == null || query.Count < 1)
            {
                return (new List<int>(), 0);
            }

            var numberList = Enumerable.Range(1, query.Max()).ToList();
            return (numberList.Except(query).ToList(), query.Max());
        }
    }
}
