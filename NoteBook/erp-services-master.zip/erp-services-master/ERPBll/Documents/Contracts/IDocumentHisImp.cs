﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using ERPModel.Documents.ErpDocumentHiss;

namespace ERPBll.Documents.Contracts
{
    public interface IDocumentHisImp
    {
        /// <summary>
        /// 分页获取
        /// </summary>
        Task<(List<DocumentHisDto>, int)> GetByPageAsync(string server_id, decimal? user_id, DocumentHisQueryInput input);

        Task AddAsync(string server_id, decimal? user_id, List<CreateDocumentHis> input);

        Task<int> DeleteAsync(string server_id, List<decimal> ids);
    }
}
