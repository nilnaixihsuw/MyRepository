﻿using ERPModel.Documents.DocumentMain;
using ERPModel.Documents.DocumentSeals;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.Documents
{
    public interface IDocumentSealImp
    {
        /// <summary>
        /// 分页获取
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="document_id"></param>
        /// <returns></returns>
        Task<List<DocumentSealDto>> GetListAsync(string server_id, decimal document_id);

        /// <summary>
        /// 新增
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="user_id"></param>
        /// <param name="input"></param>
        /// <returns></returns>
        Task AddAsync(string server_id, decimal? user_id, List<DocumentSeal> input, int document_id);

        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<int> DeleteAsync(string server_id, decimal id);
    }
}
