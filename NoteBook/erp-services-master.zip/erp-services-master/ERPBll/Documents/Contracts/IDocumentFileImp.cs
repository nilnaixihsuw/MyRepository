﻿using ERPModel.Documents.DocumentFile;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.Documents
{
    public interface IDocumentFileImp
    {
        Task AddAsync(string server_id, decimal? user_id, List<CreateOrUpdateDocumentFile> input, int document_id);

        Task<int> DeleteAsync(string server_id, decimal id);
    }
}
