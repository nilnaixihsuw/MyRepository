﻿using ERPModel.Documents;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.Documents
{
    /// <summary>
    /// 电子印章
    /// </summary>
    public interface ISealMainImp
    {
        /// <summary>
        /// 获取全部电子印章
        /// </summary>
        /// <param name="server_id"></param>
        /// <returns></returns>
        Task<List<SealMainDto>> GetListAsync(string server_id);

        /// <summary>
        /// 新增
        /// </summary>
        Task<SealMainDto> AddAsync(string server_id, decimal? user_id, CreateOrUpdateSealMain input);

        /// <summary>
        /// 编辑
        /// </summary>
        Task<SealMainDto> UpdateAsync(string server_id, decimal? user_id, CreateOrUpdateSealMain input);

        /// <summary>
        /// 删除
        /// </summary>
        Task<int> DeleteAsync(string server_id, decimal id);

        /// <summary>
        /// 批量删除
        /// </summary>
        Task<int> DeleteManyAsync(string server_id, List<decimal> ids);
    }
}
