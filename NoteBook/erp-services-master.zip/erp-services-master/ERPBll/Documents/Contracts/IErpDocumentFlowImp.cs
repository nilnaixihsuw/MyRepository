﻿using ERPCore.ORM;
using ERPModel.Documents;
using ERPModel.Documents.DocumentFlows;
using ERPModel.Documents.DocumentMain;
using ERPModel.Vehicleinfomanage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.Documents
{
    public interface IErpDocumentFlowImp
    {
        /// <summary>
        /// 分页获取公文审批记录
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="user_id"></param>
        /// <param name="input"></param>
        /// <returns></returns>
        Task<(List<DocumentFlowDto>, int)> GetByPageAsync(string server_id, decimal? user_id, DocumentMainQueryInput input);

        /// <summary>
        /// 获取抄送
        /// </summary>
        Task<(List<DocumentFlowDto>, int)> GetReadAsync(string server_id, decimal? user_id, DocumentMainQueryInput input);

        Task<List<ReviewState>> GetFlowDataAsync(decimal user_id, int flow_id, int flow_record_id, decimal doc_id, string server_id, int type);
    }
}