﻿using ERPModel.Documents.DocumentFlows;
using ERPModel.Documents.DocumentMain;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.Documents
{
    public interface IDocumentMainImp
    {
        /// <summary>
        /// 分页获取
        /// </summary>
        Task<(List<DocumentMainDto>, int)> GetAllByPageAsync(string server_id, decimal? user_id, DocumentMainQueryInput input);

        /// <summary>
        /// 分页获取
        /// </summary>
        Task<(List<DocumentMainDto>, int)> GetByPageAsync(string server_id, decimal? user_id, DocumentMainQueryInput input);

        /// <summary>
        /// 获取详情
        /// </summary>
        Task<DocumentMainDto> GetByIdAsync(string server_id, decimal? user_id, int id);

        /// <summary>
        /// 新增
        /// </summary>
        Task<DocumentMainDto> AddAsync(string server_id, decimal? user_id, CreateOrUpdateDocumentMain input);

        /// <summary>
        /// 编辑
        /// </summary>
        Task<DocumentMainDto> UpdateAsync(string server_id, decimal? user_id, CreateOrUpdateDocumentMain input);

        /// <summary>
        /// 修改正文/附件
        /// </summary>
        Task<DocumentMainDto> UpdateContentAsync(string server_id, decimal? user_id, UpdateDocumentContent input);

        /// <summary>
        /// 审批
        /// </summary>
        Task<DocumentMainDto> UpdateStateAsync(string server_id, decimal? user_id, UpdateDocumentState input);

        /// <summary>
        /// 删除
        /// </summary>
        Task<int> DeleteManyAsync(string server_id, List<decimal> ids);

        /// <summary>
        /// 获取补号
        /// </summary>
        Task<(List<int>, int)> GetNumberAsync(string server_id, string font, int year);

        /// <summary>
        /// 获取所有发文字号
        /// </summary>
        Task<List<string>> GetFontNumberAsync(string server_id);

        /// <summary>
        /// 作废
        /// </summary>
        Task<List<DocumentMainDto>> UpdateScrapAsync(string server_id, List<int> ids);
    }
}
