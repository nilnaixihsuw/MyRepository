﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.Documents
{
    public interface IDocumentPersonImp
    {
        /// <summary>
        /// 新增
        /// </summary>
        /// <param name="type"> 1发文2收文</param>
        /// <param name="kind">1主送人员2抄送人员</param>
        /// <returns></returns>
        Task AddAsync(string server_id, decimal? user_id, List<int> persons, int document_id, int type, int kind);

        /// <summary>
        /// 删除
        /// </summary>
        Task<int> DeleteAsync(string server_id, decimal id);
    }
}
