﻿using ERPDal.Repository;
using ERPModel.Documents.DocumentAccept;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.Documents
{
    /// <summary>
    /// 收文管理
    /// </summary>
    public interface IDocumentAcceptImp 
    {
        /// <summary>
        /// 获取全部收文
        /// </summary>
        Task<(List<DocumentAcceptDto>, int)> GetAllByPageAsync(string server_id, decimal? user_id, DocumentAcceptQueryInput input);

        /// <summary>
        /// 分页获取
        /// </summary>
        Task<(List<DocumentAcceptDto>, int)> GetByPageAsync(string server_id, decimal? user_id, DocumentAcceptQueryInput input);

        /// <summary>
        /// 获取详情
        /// </summary>
        Task<DocumentAcceptDto> GetByIdAsync(string server_id, decimal? user_id, int id);

        /// <summary>
        /// 新增
        /// </summary>
        Task<DocumentAcceptDto> AddAsync(string server_id, decimal? user_id, CreateOrUpdateDocumentAccept input);

        /// <summary>
        /// 编辑
        /// </summary>
        Task<DocumentAcceptDto> UpdateAsync(string server_id, decimal? user_id, CreateOrUpdateDocumentAccept input);

        /// <summary>
        /// 审批
        /// </summary>
        Task<DocumentAcceptDto> UpdateStateAsync(string server_id, decimal? user_id, UpdateDocumentAcceptState input);

        /// <summary>
        /// 批量删除
        /// </summary>
        Task<int> DeleteManyAsync(string server_id, decimal? user_id, List<decimal> ids);

        /// <summary>
        /// 获取收文补号
        /// </summary>
        Task<(List<int>, int)> GetNumberAsync(string server_id, string font, int year);

        /// <summary>
        /// 获取所有收文字号
        /// </summary>
        Task<List<string>> GetFontNumberAsync(string server_id);

        /// <summary>
        /// 作废
        /// </summary>
        Task<List<DocumentAcceptDto>> UpdateScrapAsync(string server_id, List<int> ids);
    }
}
