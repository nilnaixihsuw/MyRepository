﻿using ERPModel.Documents.DocumentMain;
using ERPModel.Documents.ErpDocumentDels;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.Documents
{
    public interface IErpDocumentDelImp
    {
        /// <summary>
        /// 获取用户删除记录
        /// </summary>
        Task<List<int>> GetByUserAsync(string server_id, decimal? user_id);

        /// <summary>
        /// 删除公文记录
        /// </summary>
        Task AddAsync(string server_id, decimal? user_id, List<int> ids);

        /// <summary>
        /// 获取删除公文标题
        /// </summary>
        /// <param name="request"></param>
        /// <param name="server_id"></param>
        /// <returns></returns>
        Task<string> GetDelTitle(DocumentDelInput request, string server_id);
    }
}
