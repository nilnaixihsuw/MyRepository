﻿using ERPModel.Documents.DocumentHeads;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.Documents
{
    /// <summary>
    /// 套红模板
    /// </summary>
    public interface IDocumentHeadImp
    {
        /// <summary>
        /// 获取全部电子印章
        /// </summary>
        /// <param name="server_id"></param>
        /// <returns></returns>
        Task<List<DocumentHeadDto>> GetListAsync(string server_id);

        /// <summary>
        /// 新增
        /// </summary>
        Task<DocumentHeadDto> AddAsync(string server_id, decimal? user_id, CreateOrUpdateDocumentHead input);

        /// <summary>
        /// 编辑
        /// </summary>
        Task<DocumentHeadDto> UpdateAsync(string server_id, decimal? user_id, CreateOrUpdateDocumentHead input);

        /// <summary>
        /// 删除
        /// </summary>
        Task<int> DeleteAsync(string server_id, decimal id);

        /// <summary>
        /// 批量删除
        /// </summary>
        Task<int> DeleteManyAsync(string server_id, List<decimal> ids);

        /// <summary>
        /// 获取套红文档
        /// </summary>
        Task<(string, string)> GetDocs(string server_id, decimal? user_id, int document_id, int head_id);
    }
}
