﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPModel.ApiModel;
using ERPModel.DataBase;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.DataBase
{
    public interface ISysCommonDictImp : IBusinessRepository<SysCommonDict>
    {
        Task<List<DictionaryTree>> GetClassyfyTree(string server_id);
        Task<bool> AddDictClassify(string server_id, AddDic context, IClientInformation client);
        Task<bool> BatchDeleteClassify(string server_id, List<decimal> context);

        void SetDicTree(string server_id, List<SysCommonDict> dics, List<DictionaryTree> dictionaryTrees);
    }
}