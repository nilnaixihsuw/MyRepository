﻿using ERPCore.ORM;
using ERPDal.DataBase;
using ERPModel.DataBase;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using ERPModel.ApiModel;
using ERPCore.Entity;
using ERPCore;

namespace ERPBll.DataBase
{
    public class SysCommonDictDetailImp : BusinessRespository<SysCommonDictDetail, ISysCommonDictDetailDataImp>, IBusinessRepository<SysCommonDictDetail>, ISysCommonDictDetailImp
    {
        private readonly ISysCommonDictDataImp _iSYS_COMMON_DICT_DataImp;

        public SysCommonDictDetailImp(ISysCommonDictDataImp iSYS_COMMON_DICT_DataImp, ISysCommonDictDetailDataImp dataImp) : base(dataImp)
        {
            _iSYS_COMMON_DICT_DataImp = iSYS_COMMON_DICT_DataImp;
        }

        public async Task<bool> AddDictDetail(string server_id, AddDicDetail context, IClientInformation client)
        {
            if (context.i_id != null && context.i_id > 0)
            {
                //编辑
                return await _dataImp.Update(server_id, new SysCommonDictDetail
                {
                    i_id = context.i_id,
                    c_name = context.c_name,
                    c_remark = context.c_remark,
                    i_is_default = context.i_is_default
                },new string[] { "c_name", "c_remark", "i_is_default" });
            }
            else
            {
                var code = 1;
                var e = await _dataImp.List(server_id, it => it.i_main_id == context.i_main_id);
                if (e != null && e.Count > 0)
                {
                    code = e.Max(it => int.Parse(it.c_code)) + 1;
                }
                //新增
                var dicClassif = await _iSYS_COMMON_DICT_DataImp.Get(server_id, context.i_main_id);
                return await _dataImp.Insert(server_id, new SysCommonDictDetail
                {
                    i_id = await _dataImp.GetId(server_id, "SEQ_COMMON"),
                    i_main_id = context.i_main_id,
                    c_name = context.c_name,
                    c_code = code.ToString(),
                    i_seq = code,
                    i_is_default = context.i_is_default,
                    c_key_code = dicClassif.c_key + "_" + code.ToString(),
                    i_created = client.i_id,
                    d_created = DateTime.Now,
                    c_remark = context.c_remark
                });
            }
        }

        public async Task<bool> DicSort(string server_id, List<DicSort> context, IClientInformation client)
        {
            var list = await _dataImp.List(server_id, it => SqlFunc.ContainsArray(context.Select(it => it.i_id).ToList(), it.i_id));
            list.ForEach(item =>
            {
                if (context.Exists(it => it.i_id == item.i_id))
                {
                    var c = context.Find(it => it.i_id == item.i_id);
                    item.i_seq = c.i_seq;
                    item.i_update = client.i_id;
                    item.d_update = DateTime.Now;
                }
            });
            return await _dataImp.Updatetable(server_id, list);
        }
    }
}