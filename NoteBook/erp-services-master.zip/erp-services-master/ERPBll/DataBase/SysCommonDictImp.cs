﻿using ERPCore.ORM;
using ERPDal.DataBase;
using ERPModel.DataBase;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using ERPModel.ApiModel;
using ERPCore.Entity;
using ERPCore;

namespace ERPBll.DataBase
{
    public class SysCommonDictImp : BusinessRespository<SysCommonDict, ISysCommonDictDataImp>, IBusinessRepository<SysCommonDict>, ISysCommonDictImp
    {
        private readonly ISysCommonDictDetailDataImp _iSYS_COMMON_DICT_DETAIL_DataImp;

        public SysCommonDictImp(ISysCommonDictDetailDataImp iSYS_COMMON_DICT_DETAIL_DataImp, ISysCommonDictDataImp dataImp) : base(dataImp)
        {
            _iSYS_COMMON_DICT_DETAIL_DataImp = iSYS_COMMON_DICT_DETAIL_DataImp;
        }

        public async Task<bool> AddDictClassify(string server_id, AddDic context, IClientInformation client)
        {
            if (context.i_id != null && context.i_id > 0)
            {
                //编辑
                return await _dataImp.Update(server_id, new SysCommonDict
                {
                    i_id = context.i_id,
                    c_name = context.c_name,
                    i_p_id = context.i_p_id,
                    i_update = client.i_id,
                    d_update = DateTime.Now,
                    c_key = context.c_key
                },new string[] { "c_name", "i_p_id", "i_update", "d_update", "c_key" });
            }
            else
            {
                //新增
                return await _dataImp.Insert(server_id, new SysCommonDict
                {
                    i_id = await _dataImp.GetId(server_id, "SEQ_COMMON"),
                    c_name = context.c_name,
                    i_p_id = context.i_p_id,
                    i_type = context.i_type,
                    i_created = client.i_id,
                    d_created = DateTime.Now,
                    c_key = context.c_key
                });
            }
        }

        public async Task<bool> BatchDeleteClassify(string server_id, List<decimal> context)
        {
            var list = await _dataImp.List(server_id, it => SqlFunc.ContainsArray(context, it.i_id));
            var details = await _iSYS_COMMON_DICT_DETAIL_DataImp.List(server_id, it => SqlFunc.ContainsArray(context, it.i_main_id));
            return await _dataImp.BatchDeleteClassify(server_id, list, details);
        }

        public async Task<List<DictionaryTree>> GetClassyfyTree(string server_id)
        {
            var list = await _dataImp.List(server_id, it => it.i_type == 1);
            return await _dataImp.GetClassyfyTree(server_id, list);
        }

        public void SetDicTree(string server_id, List<SysCommonDict> dics, List<DictionaryTree> dictionaryTrees)
        {
            for (var i = 0; i < dictionaryTrees.Count; i++)
            {
                if (dics.Exists(it => it.i_p_id == dictionaryTrees[i].i_id))
                {
                    dictionaryTrees[i].children.AddRange(dics.Where(it => it.i_p_id == dictionaryTrees[i].i_id).Select(it => new DictionaryTree
                    {
                        i_id = it.i_id,
                        c_name = it.c_name,
                        c_key = it.c_key,
                        type = 2
                    }).ToList());
                }

                if (dictionaryTrees[i].children != null && dictionaryTrees[i].children.Count > 0)
                {
                    SetDicTree(server_id, dics, dictionaryTrees[i].children);
                }
                else
                {
                    SetDictChildren(server_id, dics, dictionaryTrees, i);
                }
            }
        }

        private void SetDictChildren(string serverId, List<SysCommonDict> dics, List<DictionaryTree> dictionaryTrees, int i)
        {
            dictionaryTrees[i].children = dics.Where(it => it.i_p_id == dictionaryTrees[i].i_id).Select(it => new DictionaryTree
            {
                i_id = it.i_id,
                c_name = it.c_name,
                c_key = it.c_key,
                type = 2
            }).ToList();
        }
    }
}