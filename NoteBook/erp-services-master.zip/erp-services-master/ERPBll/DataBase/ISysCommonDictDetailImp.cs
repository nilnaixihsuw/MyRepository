﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPModel.ApiModel;
using ERPModel.DataBase;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.DataBase
{
    public interface ISysCommonDictDetailImp : IBusinessRepository<SysCommonDictDetail>
    {
        Task<bool> AddDictDetail(string server_id, AddDicDetail context, IClientInformation client);
        Task<bool> DicSort(string server_id, List<DicSort> context, IClientInformation client);
    }
}