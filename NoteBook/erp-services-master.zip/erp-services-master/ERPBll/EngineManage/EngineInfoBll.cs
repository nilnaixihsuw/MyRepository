using System.Collections.Generic;
using System.Threading.Tasks;
using ERPDal;
using ERPModel.EngineManage;
using ERPModel.MaintManage;
using ERPModel.Vehicleinfomanage;
using SqlSugar;

namespace ERPBll.EngineManage
{
    /// <summary>
    /// 发动机
    /// </summary>
    public class EngineInfoBll
    {
        /// <summary>
        /// 分页查询
        /// </summary>
        /// <param name="serverID"></param>
        /// <returns></returns>
        public static Task<(List<ErpEngineModel>, int)> GetByPageAsync(string serverID, EngineQueryInput input)
        {
            int totalCount = 0;
            //return Task.FromResult((SqlSugarHelper.DBClient(serverID).Queryable<ErpEngineModel>()
            //    .WhereIF(!string.IsNullOrWhiteSpace(input.name), x => x.c_name.ToLower().Contains(input.name.ToLower()))
            //    .OrderBy(x=>x.d_created_time,OrderByType.Desc)
            //    .ToPageList(input.page_index, input.page_size, ref totalCount), totalCount));
            return Task.FromResult((SqlSugarHelper.DBClient(serverID)
                        .Queryable<ErpEngineModel>()
                        .WhereIF(!string.IsNullOrWhiteSpace(input.name), x => x.c_name.ToLower().Contains(input.name.ToLower()))
                        .OrderBy(x => x.d_created_time, OrderByType.Desc)
                        .Mapper(x => {
                            x.vehicle_count = SqlSugarHelper.DBClient(serverID)
                                                .Queryable<ErpEngine>()
                                                .Where(y => y.i_model_id == x.i_id)
                                                .Select(y => SqlFunc.AggregateDistinctCount(y.i_vehicle_id))
                                                .First();
                        })
                        .ToPageList(input.page_index, input.page_size, ref totalCount), totalCount));
        }

        public static Task<int> AddAsync(string serverID, ErpEngineModel info)
        {
            info.i_id = ERPBll.Tools.GetEngineID(serverID);
            return Task.FromResult(SqlSugarHelper.DBClient(serverID).Insertable(info).ExecuteCommand());
        }

        public static int UpdateAsync(string serverID, ErpEngineModel info)
        {
            return SqlSugarHelper.DBClient(serverID).Updateable(info).ExecuteCommand();
        }

        public static int DeleteAsync(string serverID, decimal id)
        {
            return SqlSugarHelper.DBClient(serverID)
                .Deleteable<ErpEngineModel>()
                .Where(r => r.i_id == id).ExecuteCommand();
        }
    }
}