﻿using AutoMapper;
using ERPBll.RedisManage;
using ERPBll.RedisManage.Dicts;
using ERPBll.UserManage;
using ERPCore;
using ERPCore.Extensions;
using ERPCore.Helpers;
using ERPDal;
using ERPModel.DataBase;
using ERPModel.InsuranceManage;
using ERPModel.Vehicleinfomanage;
using Microsoft.AspNetCore.Http;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.InsuranceManage
{
    public class ErpInsuranceMainImp : IErpInsuranceMainImp
    {
        private readonly IMapper _imapper;
        private readonly IVehicleRedisManageImp _vehicleRedisManageImp;
        private readonly IDictRedisManageImp _dictRedisManageImp;

        public ErpInsuranceMainImp(
           IMapper imapper,
           IVehicleRedisManageImp vehicleRedisManageImp,
           IDictRedisManageImp dictRedisManageImp)
        {
            _imapper = imapper;
            _vehicleRedisManageImp = vehicleRedisManageImp;
            _dictRedisManageImp = dictRedisManageImp;
        }

        public async Task<(List<ErpInsuranceMainDto>, int)> GetByPageAsync(
            string server_id, decimal? user_id, ErpInsuranceMainQueryInput input)
        {
            RefAsync<int> totalCount = 0;

            //用户管理的车辆
            if (input.vehicle_id < 1 && (input.vehicle_ids == null || input.vehicle_ids.Count < 1))
            {
                input.vehicle_ids = RoleInfoBll.GetVehicleID(server_id, user_id);
            }

            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpInsuranceMain, ErpVehicleInfo>((x, y) => new JoinQueryInfos(JoinType.Left, x.vehicle_id == y.i_id))
                                .Where(input.ToExp())
                                .OrderBy((x, y) => y.c_lincense_plate_number)
                                .OrderBy((x, y) => x.insurance_start)
                                .Mapper(async x =>
                                {
                                    x.vehicle_info = await SqlSugarHelper.DBClient(server_id)
                                                            .Queryable<ErpVehicleInfo>()
                                                            .Mapper(x => x.department_info, x => x.c_crews_take)
                                                            .FirstAsync(t => t.i_id == x.vehicle_id);
                                })
                                .Mapper(x =>
                                {
                                    x.type_name = string.Join(",", SqlSugarHelper.DBClient(server_id)
                                                            .Queryable<SysCommonDictDetail>()
                                                            .Where(i => x.types.ToList().Contains(i.i_id.Value))
                                                            .Select(x => x.c_name)
                                                            .ToList());
                                })
                                .Mapper(x => x.company_info, x => x.company)
                                .ToPageListAsync(input.page_index, input.page_size, totalCount);

            var data = _imapper.Map<List<ErpInsuranceMain>, List<ErpInsuranceMainDto>>(list);
            return (data, totalCount);
        }

        public async Task<int> AddAsync(string server_id, string user_id, CreateOrUpdateErpInsuranceMain input)
        {
            var info = _imapper.Map<CreateOrUpdateErpInsuranceMain, ErpInsuranceMain>(input);
            info.id = ERPBll.Tools.GetEngineID(server_id);
            int.TryParse(user_id, out int usered);
            info.SetCreate(usered);

            return await SqlSugarHelper.DBClient(server_id).Insertable(info).ExecuteCommandAsync();
        }

        public async Task<int> UpdateAsync(string server_id, string user_id, CreateOrUpdateErpInsuranceMain input)
        {
            var info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpInsuranceMain>().FirstAsync(x => x.id == input.id);
            if (info == null)
            {
                throw new Exception($"未找到保险记录，id={input.id}");
            }
            _imapper.Map<CreateOrUpdateErpInsuranceMain, ErpInsuranceMain>(input, info);
            int.TryParse(user_id, out int usered);
            info.SetUpdate(usered);

            return SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommand();
        }

        public Task<int> DeleteManyAsync(string server_id, List<decimal> ids)
        {
            return Task.FromResult(SqlSugarHelper.DBClient(server_id)
                .Deleteable<ErpInsuranceMain>()
                .In(ids).ExecuteCommand());
        }

        public async Task<List<ErpInsuranceEndDto>> GetInsuranceEndVehicle(string server_id, decimal? user_id, int day)
        {
            RefAsync<int> totalCount = 0;

            //当前用户管理的车辆
            var vehicle_ids = RoleInfoBll.GetVehicleID(server_id, user_id);

            var list = await SqlSugarHelper.DBClient(server_id)
                               .Queryable<ErpInsuranceMain>()
                               .PartitionBy(x => new { x.vehicle_id, x.type })
                               .OrderBy(x => x.insurance_end, OrderByType.Desc)
                               .Take(1)
                               //.Mapper(async x =>
                               //{
                               //    x.vehicle_info = await SqlSugarHelper.DBClient(server_id)
                               //                            .Queryable<ErpVehicleInfo>()
                               //                            .WhereIF(vehicle_ids != null, x => vehicle_ids.Contains(x.i_id.Value))
                               //                            .Mapper(x => x.department_info, x => x.c_crews_take)
                               //                            .FirstAsync(t => t.i_id == x.vehicle_id);

                               //    x.type_name = string.Join(",", SqlSugarHelper.DBClient(server_id)
                               //                          .Queryable<SysCommonDictDetail>()
                               //                          .Where(i => x.types.ToList().Contains(i.i_id.Value))
                               //                          .Select(x => x.c_name)
                               //                          .ToList());
                               //})
                                .Mapper(x => x.company_info, x => x.company)
                               .ToListAsync();

            list = list.Where(x => x.insurance_end <= DateTime.Now.AddDays(day)).OrderBy(x => x.insurance_end).ToList();
            var vehs = await _vehicleRedisManageImp.GetAll1Async();
            var dics = await _dictRedisManageImp.GetAllAsync();

            var data = _imapper.Map<List<ErpInsuranceMain>, List<ErpInsuranceEndDto>>(list);

            data.ForEach(async x =>
            {
                var veh = vehs.FirstOrDefault(it => it.id == x.vehicle_id);
                x.vehicle_name = veh?.lp_num;
                x.vehicle_code= veh?.v_num;
                x.department_id = Convert.ToInt32(veh?.group_info?.i_id);
                x.department_name = veh?.group_info?.c_name;

                var dic = dics.Where(it => x.types.ToList().Contains(it.i_id.Value)).Select(x => x.c_name);
                x.type_name = String.Join(',', dic);
                x.state = (x.insurance_end - DateTime.Now).Days;
                x.state_name = x.state >= 0 ? $"还剩{x.state}天" : $"已超期{-x.state}天";
            });
            return data;
        }

        public async Task<bool> ImportErpInsuranceMainData(string server_id, List<ErpInsuranceMain> list, List<ErpInsuranceMain> upList)
        {
            return await Task.Run(() =>
            {
                var result = false;
                using (var db = SqlSugarHelper.DBClient(server_id))
                {
                    db.BeginTran();
                    if (list != null && list.Count > 0)
                    {
                        ListHelper.ListSplit(100, list, split =>
                        {
                            result = db.Insertable(split).ExecuteCommand() > 0;
                            return split;
                        });
                    }
                    if (upList != null && upList.Count > 0)
                    {
                        ListHelper.ListSplit(100, upList, split =>
                        {
                            result = db.Updateable(upList).ExecuteCommand() > 0;
                            return split;
                        });
                    }
                    db.CommitTran();
                }
                return result;
            });
        }

        public async Task<(bool, List<string>)> Import(ImportErpInsuranceMain input)
        {
            var title = new Dictionary<string, string>()
            {
               { "自编号","vehicle_number" },
               { "车牌号","vehicle_name" },
               { "所属组织","department_name" },
               { "投保日期","string_insurance_start" },
               { "到期日期","string_insurance_end" },
               { "保险种类","type_name" },
               { "投保金额","insure_fee" },
               { "实付金额","actual_fee" },
               { "保险公司","company_name" },
               { "保险单号","insurance_code" }
            };

            var result = new byte[] { };
            using (var ms = new MemoryStream())
            {
                input.file.CopyTo(ms);
                ms.Position = 0;
                result = ms.ToArray();
            }
            var dt = ExcelImportHelper.ReadBytesToDataTable(result, title);
            var impotList = dt.ToImportDataList<ImportData>();

            int index = 2;
            var errlist = new List<string>();
            foreach (var item in impotList)
            {
                //检查必填项是否为空
                if (string.IsNullOrEmpty(item.vehicle_name))
                    errlist.Add("第" + index + "行车牌号未填写，无法导入");

                var vehicle_id = await SqlSugarHelper.DBClient(input.server_id)
                                                            .Queryable<ErpVehicleInfo>()
                                                            .Where(t => t.c_lincense_plate_number == item.vehicle_name)
                                                            .Select(t => t.i_id)
                                                            .FirstAsync();
                if (vehicle_id == null || vehicle_id == 0)
                {
                    errlist.Add("第" + index + "行车牌号" + item.vehicle_name + "不存在，无法导入");
                }
                item.vehicle_id = Convert.ToInt32(vehicle_id);

                if (string.IsNullOrEmpty(item.string_insurance_start))
                    errlist.Add("第" + index + "行投保日期未填写，无法导入");

                string string_insurance_start = item.string_insurance_start;
                string string_insurance_end = item.string_insurance_end;

                item.string_insurance_start = item.string_insurance_start.Replace("/", "-")
                    .Replace(".", "").Replace("年", "-").Replace("月", "-").Replace("日", "");
                item.string_insurance_end = item.string_insurance_end.Replace("/", "-")
                    .Replace(".", "").Replace("年", "-").Replace("月", "-").Replace("日", "");

                DateTime time;
                if(!DateTime.TryParse(item.string_insurance_start, out time))
                {
                    errlist.Add("第" + index + "行投保日期" + string_insurance_start + "格式不正确，无法导入");
                }
                if (!string.IsNullOrWhiteSpace(item.string_insurance_end) && !DateTime.TryParse(item.string_insurance_end, out time))
                {
                    errlist.Add("第" + index + "行保险到期日期" + string_insurance_end + "格式不正确，无法导入");
                }

                if (string.IsNullOrEmpty(item.type_name))
                    errlist.Add("第" + index + "行保险种类未填写，无法导入");

                var type_id = await SqlSugarHelper.DBClient(input.server_id)
                                                            .Queryable<SysCommonDictDetail>()
                                                            .Where(i => i.c_name == item.type_name)
                                                            .Select(x => x.i_id)
                                                            .FirstAsync();
                if (type_id == null || type_id == 0)
                {
                    errlist.Add("第" + index + "行保险种类" + item.type_name + "不存在，无法导入");
                }
                item.type = Convert.ToString(Convert.ToInt32(type_id));

                var company_id = await SqlSugarHelper.DBClient(input.server_id)
                                                            .Queryable<SysCommonDictDetail>()
                                                            .Where(i => i.c_name == item.company_name)
                                                            .Select(x => x.i_id)
                                                            .FirstAsync();
                if (company_id == null || company_id == 0)
                {
                    errlist.Add("第" + index + "行保险公司" + item.company_name + "不存在，无法导入");
                }
                item.company = Convert.ToInt32(company_id);

                index ++;
            }

            //如果有错误
            if (errlist.Count > 0)
            {
                return (false, errlist);
            }

            var list = _imapper.Map<List<ImportData>, List<ErpInsuranceMain>>(impotList);

            if (list == null || list.Count < 1)
            {
                throw new Exception("导入内容不能为空");
            }

            var upList = new List<ErpInsuranceMain>();
            var inList = new List<ErpInsuranceMain>();

            list.ForEach(async item =>
            {
                item.id = ERPBll.Tools.GetEngineID(input.server_id);

                var info = await SqlSugarHelper.DBClient(input.server_id)
                            .Queryable<ErpInsuranceMain>()
                            .FirstAsync(x => x.vehicle_id == item.vehicle_id && 
                                x.type == item.type && x.insurance_start == item.insurance_start);

                //覆盖
                if (input.type == 1)
                {
                    if (info != null)
                    {
                        item.id = info.id;
                        upList.Add(item);
                    }
                    else
                    {
                        inList.Add(item);
                    }
                }
                else
                {
                    if (info == null)
                    {
                        inList.Add(item);
                    }
                }
            });
            return (await ImportErpInsuranceMainData(input.server_id, inList, upList), errlist);
        }
    }
}
