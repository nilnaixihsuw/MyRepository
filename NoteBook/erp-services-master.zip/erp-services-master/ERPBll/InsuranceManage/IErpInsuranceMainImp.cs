﻿using ERPModel.InsuranceManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.InsuranceManage
{
    public interface IErpInsuranceMainImp
    {
        /// <summary>
        /// 分页查询
        /// </summary>
        Task<(List<ErpInsuranceMainDto>, int)> GetByPageAsync(
            string server_id, decimal? user_id, ErpInsuranceMainQueryInput input);

        /// <summary>
        /// 新增
        /// </summary>
        Task<int> AddAsync(string server_id, string user_id, CreateOrUpdateErpInsuranceMain input);

        /// <summary>
        /// 修改
        /// </summary>
        Task<int> UpdateAsync(string server_id, string user_id, CreateOrUpdateErpInsuranceMain input);

        /// <summary>
        /// 批量删除
        /// </summary>
        Task<int> DeleteManyAsync(string server_id, List<decimal> ids);

        /// <summary>
        /// 获取保险到期车辆信息
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="day">提醒天数</param>
        /// <returns></returns>
        Task<List<ErpInsuranceEndDto>> GetInsuranceEndVehicle(string server_id, decimal? user_id, int day);

        /// <summary>
        /// 导入车辆保险记录
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        Task<(bool, List<string>)> Import(ImportErpInsuranceMain input);
    }
}
