﻿using ERPModel.ContainerManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.ContainerManage
{
    public interface IErpContainerVehicleImp
    {
        /// <summary>
        /// 获取绑定车辆记录
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="container_id"></param>
        /// <returns></returns>
        Task<List<ErpContainerVehicleDto>> GetListByContainerId(string serverID, decimal container_id);

        /// <summary>
        /// 获取当前绑定车辆
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="container_id"></param>
        /// <returns></returns>
        Task<ContainerVehicleDto> GetByContainerId(string serverID, decimal container_id);

        /// <summary>
        /// 安装
        /// </summary>
        public Task<int> AddAsync(string serverID, ErpContainerVehicleInstall input);

        /// <summary>
        /// 拆除
        /// </summary>
        public Task<int> UpdateAsync(string serverID, ErpContainerVehicleDismantle input);
    }
}
