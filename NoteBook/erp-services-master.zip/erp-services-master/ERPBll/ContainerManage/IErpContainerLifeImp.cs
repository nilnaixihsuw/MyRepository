﻿using ERPModel.ContainerManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.ContainerManage
{
    public interface IErpContainerLifeImp
    {
        Task<List<ERPContainerLifeDto>> GetByContainerId(string serverID, decimal container_id);

        Task<int> AddAsync(string serverID, CreateContainerLifeInput input);
    }
}
