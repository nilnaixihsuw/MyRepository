﻿using AutoMapper;
using ERPDal;
using ERPModel.ContainerManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.ContainerManage
{
    public class ErpContainerLifeImp : IErpContainerLifeImp
    {
        private readonly IMapper _imapper;

        public ErpContainerLifeImp(
            IMapper imapper)
        {
            _imapper = imapper;
        }

        public async Task<List<ERPContainerLifeDto>> GetByContainerId(string serverID, decimal container_id)
        {
            var query = await SqlSugarHelper.DBClient(serverID).Queryable<ERPContainerLife>()
                            .Where(x => x.container_id == container_id)
                            .OrderBy(x => x.date, SqlSugar.OrderByType.Asc)
                            .OrderBy(x => x.id, SqlSugar.OrderByType.Asc)
                            .ToListAsync();

            return _imapper.Map<List<ERPContainerLife>, List<ERPContainerLifeDto>>(query);
        }

        public Task<int> AddAsync(string serverID, CreateContainerLifeInput input)
        {
            var info = _imapper.Map<CreateContainerLifeInput, ERPContainerLife>(input);

            info.id = ERPBll.Tools.GetEngineID(serverID);

            return Task.FromResult(SqlSugarHelper.DBClient(serverID).Insertable(info).ExecuteCommand());
        }
    }
}
