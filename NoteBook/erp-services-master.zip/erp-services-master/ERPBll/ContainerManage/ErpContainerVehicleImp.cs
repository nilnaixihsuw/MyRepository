﻿using AutoMapper;
using ERPDal;
using ERPModel.ContainerManage;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.ContainerManage
{
    public class ErpContainerVehicleImp : IErpContainerVehicleImp
    {
        private readonly IMapper _imapper;

        public ErpContainerVehicleImp(
            IMapper imapper)
        {
            _imapper = imapper;
        }

        public async Task<List<ErpContainerVehicleDto>> GetListByContainerId(string serverID, decimal container_id)
        {
            var query = await SqlSugarHelper.DBClient(serverID).Queryable<ErpContainerVehicle>()
                            .Where(x => x.container_id == container_id)
                            .Mapper(x => x.vehicle_info, x => x.vehicle_id)
                            .OrderBy(x => x.id, SqlSugar.OrderByType.Desc)
                            .ToListAsync();

            return _imapper.Map<List<ErpContainerVehicle>, List<ErpContainerVehicleDto>>(query);
        }

        public async Task<ContainerVehicleDto> GetByContainerId(string serverID, decimal container_id)
        {
            var query = await SqlSugarHelper.DBClient(serverID).Queryable<ErpContainerVehicle>()
                            .Where(x => x.container_id == container_id)
                            .Mapper(x => x.vehicle_info, x => x.vehicle_id)
                            .OrderBy(x => x.id, SqlSugar.OrderByType.Desc)
                            .FirstAsync();

            if(query == null || query.dismantle != null)
            {
                return new ContainerVehicleDto();
            }
            return _imapper.Map<ErpContainerVehicle, ContainerVehicleDto>(query);
        }

        public async Task<ErpContainerDto> GetContainerAsync(string serverID, ErpContainerQueryInput input)
        {
            Expression<Func<ErpContainer, bool>> express = x => true;
            if (input.id > 0)
            {
                express = x => x.id == input.id;
            }
            if (input.vehicle_id > 0)
            {
                express = x => x.vehicle_id == input.vehicle_id;
            }
            if (!string.IsNullOrWhiteSpace(input.state))
            {
                express = x => x.state == input.state;
            }

            var query = await SqlSugarHelper.DBClient(serverID).Queryable<ErpContainer>().FirstAsync(express);

            return _imapper.Map<ErpContainer, ErpContainerDto>(query);
        }

        public async Task<int> AddAsync(string serverID, ErpContainerVehicleInstall input)
        {
            var info = _imapper.Map<ErpContainerVehicleInstall, ErpContainerVehicle>(input);

            var query = await GetContainerAsync(serverID,
                new ErpContainerQueryInput()
                {
                    vehicle_id = input.vehicle_id
                });
            if (query != null)
            {
                throw new Exception("该车辆当前位置已经压力容器，如要安装请先拆除");
            }

            info.id = ERPBll.Tools.GetEngineID(serverID);

            return SqlSugarHelper.DBClient(serverID).Insertable(info).ExecuteCommand();
        }

        public async Task<int> UpdateAsync(string serverID, ErpContainerVehicleDismantle input)
        {
            var query = await GetContainerAsync(serverID,
               new ErpContainerQueryInput()
               {
                   id = input.container_id,
                   vehicle_id = input.vehicle_id,
                   state = "container_1"
               });
            if (query == null)
            {
                throw new Exception("未找到可拆除的压力容器");
            }

            var info = await SqlSugarHelper.DBClient(serverID).Queryable<ErpContainerVehicle>()
                                .OrderBy(x => x.id, SqlSugar.OrderByType.Desc)
                                .FirstAsync(x => x.container_id == input.container_id &&
                                    x.vehicle_id == input.vehicle_id);

            _imapper.Map<ErpContainerVehicleDismantle, ErpContainerVehicle>(input, info);

            //计算里程
            info.mileage = 0;

            return SqlSugarHelper.DBClient(serverID).Updateable(info).ExecuteCommand();
        }
    }
}
