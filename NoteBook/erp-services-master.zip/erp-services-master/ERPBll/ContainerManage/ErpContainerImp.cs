﻿using AutoMapper;
using ERPBll.UserManage;
using ERPDal;
using ERPDal.Vehicleinfomanage;
using ERPModel.ContainerManage;
using ERPModel.UserManage;
using ERPModel.Vehicleinfomanage;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using VehicleInfo = ERPModel.Vehicleinfomanage.ErpVehicleInfo;

namespace ERPBll.ContainerManage
{
    public class ErpContainerImp : IErpContainerImp
    {
        private readonly IMapper _imapper;
        private readonly IErpContainerVehicleImp _containerVehicleImp;
        private readonly IErpContainerLifeImp _containerLifeImp;
        private readonly IVehicleInfoDataImp _iVEHICLE_INFO_DataImp;

        public ErpContainerImp(
            IMapper imapper,
            IErpContainerVehicleImp containerVehicleIm,
            IErpContainerLifeImp containerLifeImp,
            IVehicleInfoDataImp iVEHICLE_INFO_DataImp)
        {
            _imapper = imapper;
            _containerVehicleImp = containerVehicleIm;
            _containerLifeImp = containerLifeImp;
            _iVEHICLE_INFO_DataImp = iVEHICLE_INFO_DataImp;
        }

        public async Task<(List<ErpContainerDto>, int)> GetByPageAsync(string server_id,decimal? user_id, ContainerQueryInput input)
        {
            RefAsync<int> totalCount = 0;

            //用户管理的车辆
            if (input.vehicle_ids == null || input.vehicle_ids.Count < 1)
            {
                input.vehicle_ids = RoleInfoBll.GetVehicleID(server_id, user_id);
            }

            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpContainer>()
                                .Where(input.ToExp())
                                .Mapper(x => x.vehicle_info, x => x.vehicle_id)
                                .Mapper(x => x.department_info, x => x.department_id)
                                .Mapper(x => x.container_vehicles, x => x.container_vehicles.First().container_id)
                                .Mapper((x, cache) =>
                                {
                                    foreach (var t in x.container_vehicles)
                                    {
                                        t.vehicle_info = SqlSugarHelper.DBClient(server_id).Queryable<ErpVehicleInfo>()
                                           .Where(o => o.i_id == t.vehicle_id)
                                           .First();//给第三层赋值
                                    }
                                })
                                .ToPageListAsync(input.page_index, input.page_size, totalCount);

            var data = _imapper.Map<List<ErpContainer>, List<ErpContainerDto>>(list);
            foreach (var item in data)
            {
                item.install_vehicle = await _containerVehicleImp.GetByContainerId(server_id, item.id);
            }
            return (data, totalCount);
        }

        public async Task<int> AddAsync(string server_id, CreateOrUpdateErpContainer input)
        {
            var info = _imapper.Map<CreateOrUpdateErpContainer, ErpContainer>(input);
            info.id = ERPBll.Tools.GetEngineID(server_id);
            info.state = "container_2";
            info.vehicle_id = input.container_vehicle.install_vehicle_id;

            var containerLife = new CreateContainerLifeInput();
            if (input.made_date.HasValue)
            {
                //记录生命周期
                containerLife = new CreateContainerLifeInput
                {
                    container_id = info.id,
                    date = input.made_date,
                    content = "生产"
                };
                await _containerLifeImp.AddAsync(server_id, containerLife);
            }

            if (input.buy_date.HasValue)
            {
                //记录生命周期
                containerLife = new CreateContainerLifeInput
                {
                    container_id = info.id,
                    date = input.buy_date,
                    content = "购买"
                };
                await _containerLifeImp.AddAsync(server_id, containerLife);
            }


            //安装车辆
            if (input.container_vehicle != null)
            {
                input.container_vehicle.container_id = info.id;

                if (input.container_vehicle.install_date.HasValue &&
                    input.container_vehicle.install_vehicle_id > 0) //安装
                {
                    info.UpdateState("container_1", input.container_vehicle.install_vehicle_id);

                    //插入安装记录
                    var containerVehicle = _imapper.Map<CreateOrUpdateErpContainerVehicle,
                                        ErpContainerVehicleInstall>(input.container_vehicle);
                    await _containerVehicleImp.AddAsync(server_id, containerVehicle);

                    var car = await _iVEHICLE_INFO_DataImp.Get(server_id, input.container_vehicle.install_vehicle_id);
                    //记录生命周期
                    containerLife = new CreateContainerLifeInput
                    {
                        container_id = info.id,
                        date = input.container_vehicle.install_date,
                        content = $"安装在[{car.c_lincense_plate_number}]"
                    };
                    await _containerLifeImp.AddAsync(server_id, containerLife);
                }
            }

            return SqlSugarHelper.DBClient(server_id).Insertable(info).ExecuteCommand();
        }

        public async Task<int> UpdateAsync(string server_id, CreateOrUpdateErpContainer input)
        {
            var info = await SqlSugarHelper.DBClient(server_id).Queryable<ErpContainer>().FirstAsync(x => x.id == input.id);
            info = _imapper.Map<CreateOrUpdateErpContainer, ErpContainer>(input, info);

            //安装车辆
            if (input.container_vehicle != null)
            {
                if (input.container_vehicle.install_date.HasValue &&
                    input.container_vehicle.install_vehicle_id > 0) //安装
                {
                    info.UpdateState("container_1", input.container_vehicle.install_vehicle_id);

                    //插入安装记录
                    var tyreVehicle = _imapper.Map<CreateOrUpdateErpContainerVehicle,
                                        ErpContainerVehicleInstall>(input.container_vehicle);
                    await _containerVehicleImp.AddAsync(server_id, tyreVehicle);

                    if (input.container_vehicle.type != 3)
                    {
                        var car = await _iVEHICLE_INFO_DataImp.Get(server_id, input.container_vehicle.install_vehicle_id);
                        //记录生命周期
                        var tyreLife = new CreateContainerLifeInput
                        {
                            container_id = info.id,
                            date = input.container_vehicle.install_date,
                            content = $"安装在[{car.c_lincense_plate_number}]"
                        };
                        await _containerLifeImp.AddAsync(server_id, tyreLife);
                    }
                }

                if (input.container_vehicle.dismantle_date.HasValue &&
                    input.container_vehicle.dismantle_vehicle_id > 0) //拆除
                {
                    info.UpdateState("container_2");

                    //更新拆除记录
                    var tyreVehicle = _imapper.Map<CreateOrUpdateErpContainerVehicle,
                                        ErpContainerVehicleDismantle>(input.container_vehicle);
                    await _containerVehicleImp.UpdateAsync(server_id, tyreVehicle);

                    var car = await _iVEHICLE_INFO_DataImp.Get(server_id, input.container_vehicle.install_vehicle_id);
                    string content = $"从[{car.c_lincense_plate_number}]上拆下";
                    if (input.container_vehicle.type == 3)
                    {
                        content += $",安装在{car.c_lincense_plate_number}";
                    }

                    //记录生命周期
                    var tyreLife = new CreateContainerLifeInput
                    {
                        container_id = info.id,
                        date = input.container_vehicle.install_date,
                        content = content
                    };
                    await _containerLifeImp.AddAsync(server_id, tyreLife);
                }
            }
            return SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommand();
        }

        public Task<int> DeleteAsync(string server_id, decimal id)
        {
            return Task.FromResult(SqlSugarHelper.DBClient(server_id)
                .Deleteable<ErpContainer>()
                .Where(r => r.id == id).ExecuteCommand());
        }

        public Task<int> DeleteManyAsync(string server_id, List<decimal> ids)
        {
            return Task.FromResult(SqlSugarHelper.DBClient(server_id)
                .Deleteable<ErpContainer>()
                .In(ids).ExecuteCommand());
        }

        public async Task UpdateScrapAsync(string server_id, List<ErpContainerScrapInput> inputs)
        {
            foreach (var item in inputs)
            {
                var info = await SqlSugarHelper.DBClient(server_id).Queryable<ErpContainer>()
                            .FirstAsync(x => x.id == item.id);

                info.state = "container_3";
                info.vehicle_id = null;
                info.scrap = Convert.ToDateTime(item.scrap_date);
                info.scrap_reason = item.scrap_reason;

                SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommand();
            }
        }
    }
}
