﻿using ERPModel.ContainerManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.ContainerManage
{
    public interface IErpContainerImp
    {
        Task<(List<ErpContainerDto>, int)> GetByPageAsync(string server_id, decimal? user_id, ContainerQueryInput input);

        Task<int> AddAsync(string serverID, CreateOrUpdateErpContainer input);

        Task<int> UpdateAsync(string serverID, CreateOrUpdateErpContainer input);

        Task<int> DeleteAsync(string serverID, decimal id);

        Task<int> DeleteManyAsync(string serverID, List<decimal> ids);

        Task UpdateScrapAsync(string serverID, List<ErpContainerScrapInput> inputs);
    }
}
