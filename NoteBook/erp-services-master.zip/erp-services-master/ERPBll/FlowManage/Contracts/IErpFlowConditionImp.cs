﻿using ERPModel.FlowManage.ErpFlowInits;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.FlowManage.Contracts
{
    public interface IErpFlowConditionImp
    {
        /// <summary>
        /// 是否符合条件
        /// </summary>
        Task<bool> IsPassAsync(string server_id, decimal? user_id, int id, object form_data);

        /// <summary>
        /// 新建审核条件
        /// </summary>
        Task AddAsync(string server_id, decimal? user_id, int step_init_id, FlowJson input);

        /// <summary>
        /// 删除
        /// </summary>
        Task<int> DeleteAsync(string server_id, List<int> ids);
    }
}
