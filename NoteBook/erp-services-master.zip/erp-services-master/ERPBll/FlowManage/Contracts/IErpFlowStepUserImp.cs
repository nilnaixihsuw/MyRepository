﻿using ERPModel.FlowManage.ErpFlowStepUsers;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.FlowManage.Contracts
{
    public interface IErpFlowStepUserImp
    {
        /// <summary>
        /// 新增
        /// </summary>
        Task<List<ErpFlowStepUserDto>> AddAsync(string server_id, int check_id, int step_id, List<decimal> user_ids, SqlSugarClient db);

        /// <summary>
        /// 获取节点审批人员
        /// </summary>
        Task<List<ErpFlowStepUserDto>> GetFlowStepByRecordId(string server_id, int step_id);
    }
}
