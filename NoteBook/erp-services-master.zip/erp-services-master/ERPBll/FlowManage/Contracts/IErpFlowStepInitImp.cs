﻿using ERPModel.FlowManage;
using ERPModel.FlowManage.ErpFlowInits;
using ERPModel.FlowManage.ErpFlowStepInits;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.FlowManage.Contracts
{
    public interface IErpFlowStepInitImp
    {
        /// <summary>
        /// 获取流程设计所有节点
        /// </summary>
        Task<List<ErpFlowStepInitDto>> GetByFlowId(string server_id, decimal? user_id, int flow_init_id);

        /// <summary>
        /// 根据表单数据获取流程设计所有节点
        /// </summary>
        Task<List<ErpFlowStepInitDto>> GetByFormData(string server_id, decimal? user_id, int flow_init_id, object form_data);

        /// <summary>
        /// 获取节点的审核人员
        /// </summary>
        /// <returns></returns>
        Task<List<FlowStepUserDto>> GetStepUserAsync(string server_id, decimal user_id, int step_init_id, ErpFlowStepInit info = null);

        /// <summary>
        /// 新增节点
        /// </summary>
        Task AddAsync(string server_id, decimal? user_id, int flow_init_id, FlowJson input);

        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="ids"></param>
        /// <returns></returns>
        Task<int> DeleteAsync(string server_id, List<int> ids);
    }
}
