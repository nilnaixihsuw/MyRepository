﻿using ERPModel.FlowManage.ErpFlowInits;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.FlowManage.Contracts
{
    public interface IErpFlowInitImp
    {
        /// <summary>
        /// 获取流程列表
        /// </summary>
        Task<(List<ErpFlowInitDto>, int)> GetByPageAsync(string server_id, decimal? user_id, ErpFlowInitQuery query);

        /// <summary>
        /// 获取流程
        /// </summary>
        Task<ErpFlowInitDto> GetByIdAsync(string server_id, decimal? user_id, int id);

        /// <summary>
        /// 保存流程json
        /// </summary>
        Task AddAsync(string server_id, decimal? user_id, CreateOrUpdateFlowInit input);

        /// <summary>
        /// 编辑
        /// </summary>
        Task UpdateAsync(string server_id, decimal? user_id, CreateOrUpdateFlowInit input);

        /// <summary>
        /// 删除
        /// </summary>
        Task<int> DeleteAsync(string server_id, List<int> ids);

        /// <summary>
        /// 作废
        /// </summary>
        Task UpdateScrapAsync(string server_id, decimal? user_id, List<int> ids);
    }
}
