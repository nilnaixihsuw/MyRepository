﻿using ERPModel.FlowManage;
using ERPModel.FlowManage.ErpFlowInits;
using ERPModel.FlowManage.ErpFlowStepUserInits;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.FlowManage.Contracts
{
    public interface IErpFlowStepUserInitImp
    {
        /// <summary>
        /// 获取节点审批用户
        /// </summary>
        Task<List<FlowStepUserDto>> GetByStepAsync(string server_id, int step_init_id);

        /// <summary>
        /// 新增审批节点用户
        /// </summary>
        Task AddAsync(string server_id, decimal? user_id, int step_init_id, FlowJson input);

        /// <summary>
        /// 删除
        /// </summary>
        Task<int> DeleteAsync(string server_id, List<int> ids);
    }
}
