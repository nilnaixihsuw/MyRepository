﻿using ERPModel.FlowManage;
using ERPModel.FlowManage.ErpFlowChecks;
using ERPModel.FlowManage.FlowRecords;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.FlowManage.Contracts
{
    /// <summary>
    /// 流程审批记录
    /// </summary>
    public interface IErpFlowCheckImp
    {
        /// <summary>
        /// 获取流程待处理节点
        /// </summary>
        Task<List<ErpFlowCheckDto>> GetWaitByFlowAsync(string server_id, int flow_id);

        /// <summary>
        /// 获取审批进度
        /// </summary>
        Task<List<FlowStepDto>> GetFlowStepAsync(string server_id, int flow_id);

        /// <summary>
        /// 获取用户待处理节点
        /// </summary>
        Task<List<ErpFlowCheckDto>> GetWaitByUserAsync(string server_id, decimal? user_id);

        /// <summary>
        /// 新增待审批人员
        /// </summary>
        Task<List<ErpFlowCheckDto>> AddAsync(
            string server_id, decimal? user_id, int flow_id, List<CreateErpFlowCheck> input, ErpFlowRecord flow_info, SqlSugarClient db = null);

        /// <summary>
        /// 审批记录
        /// </summary>
        Task<List<ErpFlowCheckDto>> GetByRecordId(string server_id, int flow_id);

        /// <summary>
        /// 审核
        /// </summary>
        Task<ErpFlowCheckDto> UpdateAsync(string server_id, decimal? user_id, UpdateErpFlowCheck input);

        /// <summary>
        /// 撤销
        /// </summary>
        Task CancelAsync(string server_id, decimal? user_id, int flow_id);

        /// <summary>
        /// 发送消息
        /// </summary>
        Task SendMessageAsync(string server_id, int flow_id, List<ErpFlowCheck> checks, SqlSugarClient db = null);

        /// <summary>
        /// 推送待处理数量
        /// </summary>
        /// <returns></returns>
        Task<int> PushWaitCount(string server_id, int user_id);
    }
}
