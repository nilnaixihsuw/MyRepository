﻿using ERPModel.FlowManage.ErpFlowCopys;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.FlowManage.Contracts
{
    public interface IErpFlowCopyImp
    {
        /// <summary>
        /// 获取用户抄送记录
        /// </summary>
        Task<List<ErpFlowCopyDto>> GetListByUserAsync(string server_id, decimal user_id);

        /// <summary>
        /// 新增抄送人
        /// </summary>
        Task AddAsync(string server_id, int flow_id, List<decimal> user_ids, SqlSugarClient db = null);

        /// <summary>
        /// 更新抄送状态
        /// </summary>
        Task UpdateStateAsync(string server_id, int flow_id);
    }
}
