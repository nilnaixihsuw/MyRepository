﻿using ERPModel.FlowManage.ErpFlowStepInits;
using ERPModel.FlowManage.FlowRecords;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.FlowManage.Contracts
{
    public interface IErpFlowRecordImp
    {
        /// <summary>
        /// 发起流程（不包含流程设计id）
        /// </summary>
        Task<ErpFlowRecordDto> AddAsync(string server_id, decimal? user_id, CreateErpFlowRecord input);

        /// <summary>
        /// 发起流程（包含流程设计id）
        /// </summary>
        Task<ErpFlowRecordDto> StartAsync(string server_id, decimal? user_id, List<ErpFlowStepInitDto> input, SqlSugarClient db = null);

        /// <summary>
        /// 公文发起流程（包含流程设计id）
        /// </summary>
        Task<ErpFlowRecordDto> StartByDocAsync(string server_id, StartFlowInput input);

        /// <summary>
        /// 催办
        /// </summary>
        Task<bool> RushAsync(string server_id, decimal? user_id, string user_name, decimal? flow_id, List<decimal?> send_users, string content, int is_sms = 0);

        /// <summary>
        /// 更新
        /// </summary>
        Task<ErpFlowRecordDto> UpdateAsync(string server_id, int flow_id, int detail_id, string content, string detail_ids = "", SqlSugarClient db = null);

        /// <summary>
        /// 分页获取全部
        /// </summary>
        Task<(List<ErpFlowRecordDto>, int)> GetListByPageAsync(string server_id, FlowRecordQuery query);

        /// <summary>
        /// 全部
        /// </summary>
        Task<List<ErpFlowRecordDto>> GetListAsync(string server_id, decimal? user_id, FlowRecordQuery query);

        /// <summary>
        /// 待处理
        /// </summary>
        /// <returns></returns>
        Task<(List<ErpFlowRecordDto>, int)> GetWaitAsync(string server_id, decimal? user_id, FlowRecordQuery query);

        /// <summary>
        /// 全部待处理
        /// </summary>
        Task<List<ErpFlowRecordDto>> GetAllWaitAsync(string server_id, decimal? user_id, FlowRecordQuery query);

        /// <summary>
        /// 全部已处理
        /// </summary>
        /// <returns></returns>
        Task<List<ErpFlowRecordDto>> GetAllFinishAsync(string server_id, decimal? user_id, FlowRecordQuery query);

        /// <summary>
        /// 已处理
        /// </summary>
        /// <returns></returns>
        Task<(List<ErpFlowRecordDto>, int)> GetFinishAsync(string server_id, decimal? user_id, FlowRecordQuery query);

        /// <summary>
        /// 已发起
        /// </summary>
        /// <returns></returns>
        Task<(List<ErpFlowRecordDto>, int)> GetSubmitAsync(string server_id, decimal? user_id, FlowRecordQuery query);

        /// <summary>
        /// 已抄送
        /// </summary>
        /// <returns></returns>
        Task<(List<ErpFlowRecordDto>, int)> GetCopyAsync(string server_id, decimal? user_id, FlowRecordQuery query);
    }
}
