﻿using ERPModel.FlowManage.FlowSteps;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.FlowManage.Contracts
{
    public interface IErpFlowStepImp
    {
        /// <summary>
        /// 获取流程全部审批节点
        /// </summary>
        Task<List<ErpFlowStepDto>> GetByRecordIdAsync(string server_id, int flow_id);

        /// <summary>
        /// 获取审批节点信息
        /// </summary>
        Task<ErpFlowStepDto> GetFlowStepById(string server_id, int step_id);

        /// <summary>
        /// 获取多个审批节点信息
        /// </summary>
        Task<List<ErpFlowStepDto>> GetFlowStepByIds(string server_id, List<int> step_ids);

        Task<List<ErpFlowStepDto>> AddAsync(
           string server_id, decimal? user_id, int flow_id, List<CreateErpFlowStep> input, SqlSugarClient db = null);

        /// <summary>
        /// 更改节点状态
        /// <param name="state">0未处理1通过2拒绝</param>
        /// </summary>
        Task<ErpFlowStepDto> UpdateStateAsync(string server_id, int id, int state);

        /// <summary>
        /// 更改多个节点状态
        /// </summary>
        /// <param name="state">0未处理1通过2拒绝</param>
        /// <returns></returns>
        Task<List<ErpFlowStepDto>> UpdateStateByIdsAsync(string server_id, List<int> ids, int state);

        /// <summary>
        /// 节点是否审核完成
        /// </summary>
        Task<bool> GetCheckStepAsync(string server_id, int step_id);

        /// <summary>
        /// 获取下一审核节点
        /// </summary>
        Task<ErpFlowStepDto> GetNextStepAsync(string server_id, int flow_id, int step_id);

        /// <summary>
        /// 获取节点原始审核人员
        /// </summary>
        Task<ErpFlowStepDto> GetStepUserInitAsync(string server_id, int step_id);

        /// <summary>
        /// 用户是否可以审批
        /// </summary>
        /// <returns></returns>
        Task<bool> CheckUserAsync(string server_id, decimal? user_id, int step_id);

        /// <summary>
        /// 获取退回节点
        /// </summary>
        Task<List<ErpFlowStepDto>> GetBackStepAsync(string server_id, int flow_id, int step_id);
    }
}
