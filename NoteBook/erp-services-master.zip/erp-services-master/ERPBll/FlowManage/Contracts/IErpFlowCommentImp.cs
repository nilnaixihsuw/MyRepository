﻿using ERPModel.FlowManage.ErpFlowComments;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.FlowManage.Contracts
{
    ///<summary>
    ///流程评论
    ///</summary>
    public interface IErpFlowCommentImp
    {
        /// <summary>
        /// 获取流程评论
        /// </summary>
        Task<List<ErpFlowCommentDto>> GetByFlowId(string server_id, decimal flow_id);

        /// <summary>
        /// 获取流程节点下的评论
        /// </summary>
        Task<List<ErpFlowCommentDto>> GetByStepId(string server_id, decimal step_id);

        /// <summary>
        /// 添加评论
        /// </summary>
        Task<ErpFlowCommentDto> AddAsync(string server_id, decimal? user_id, string user_name, ErpFlowCommentInput input);

        /// <summary>
        /// 删除评论
        /// </summary>
        Task<bool> DeleteAsync(string server_id, decimal id, DateTime? time);
    }
}
