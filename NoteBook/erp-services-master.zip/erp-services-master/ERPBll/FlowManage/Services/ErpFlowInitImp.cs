﻿using AutoMapper;
using ERPBll.FlowManage.Contracts;
using ERPDal;
using ERPModel.FlowManage.ErpFlowInits;
using ERPModel.FormManage;
using Newtonsoft.Json;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.FlowManage.Services
{
    /// <summary>
    /// 流程管理
    /// </summary>
    public class ErpFlowInitImp: IErpFlowInitImp
    {
        private readonly IMapper _imapper;
        private readonly IErpFlowStepInitImp _erpFlowStepInitImp;

        public ErpFlowInitImp(
            IMapper imapper,
            IErpFlowStepInitImp erpFlowStepInitImp)
        {
            _imapper = imapper;
            _erpFlowStepInitImp = erpFlowStepInitImp;
        }

        public async Task<(List<ErpFlowInitDto>,int)> GetByPageAsync(string server_id, decimal? user_id, ErpFlowInitQuery query)
        {
            RefAsync<int> totalCount = 0;

            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpFlowInit>()
                                .Where(x => x.user > 0)
                                .Where(query.ToExp())
                                .OrderBy(x => x.id, OrderByType.Desc)
                                .ToPageListAsync(query.page_index, query.page_size, totalCount);

            var data = _imapper.Map<List<ErpFlowInit>, List<ErpFlowInitDto>>(list);
            return (data, totalCount);
        }

        public async Task<ErpFlowInitDto> GetByIdAsync(string server_id, decimal? user_id, int id)
        {
            //查询
            var info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpFlowInit>()
                                .FirstAsync(x => x.id == id);

            return _imapper.Map<ErpFlowInit, ErpFlowInitDto>(info);
        }

        public async Task AddAsync(string server_id, decimal? user_id, CreateOrUpdateFlowInit input)
        {
            var info = _imapper.Map<CreateOrUpdateFlowInit, ErpFlowInit>(input);
            info.id = ERPBll.Tools.GetEngineID(server_id);
            info.SetCreate(user_id);

            //添加节点
            var json = JsonConvert.DeserializeObject<FlowJson>(input.json_origin);
            await _erpFlowStepInitImp.AddAsync(server_id, user_id, info.id, json);

            await SqlSugarHelper.DBClient(server_id).Insertable(info).ExecuteCommandAsync();
        }

        public async Task UpdateAsync(string server_id, decimal? user_id, CreateOrUpdateFlowInit input)
        {
            var info = await SqlSugarHelper.DBClient(server_id)
                           .Queryable<ErpFlowInit>()
                           .FirstAsync(x => x.id == input.id);

            if(info == null)
            {
                throw new Exception($"未找到记录：id={input.id}");
            }

            info.user = 0;
            await SqlSugarHelper.DBClient(server_id).Updateable<ErpFlowInit>(info).ExecuteCommandAsync();

            await AddAsync(server_id, user_id, input);
        }

        public async Task UpdateScrapAsync(string server_id, decimal? user_id, List<int> ids)
        {
            using (var db=SqlSugarHelper.DBClient(server_id))
            {
                await db.Updateable<ErpFlowInit>().SetColumns(x => x.user == 0).Where(x => ids.Contains(x.id)).ExecuteCommandAsync();
            }
        }

        public async Task<int> DeleteAsync(string server_id, List<int> ids)
        {
             var list = await SqlSugarHelper.DBClient(server_id)
                            .Queryable<ErpFlowInit>()
                            .Where(x => ids.Contains(x.id))
                            .ToListAsync();

            var res = await SqlSugarHelper.DBClient(server_id).Deleteable<ErpFlowInit>(list).ExecuteCommandAsync();

            await _erpFlowStepInitImp.DeleteAsync(server_id, list.Select(x => x.id).ToList());

            return res;
        }
    }
}
