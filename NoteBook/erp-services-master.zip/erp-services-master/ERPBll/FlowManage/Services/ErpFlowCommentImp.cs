﻿using AutoMapper;
using BusTools.JiGuang.Contracts;
using ERPBll.FlowManage.Contracts;
using ERPBll.WorkPlace;
using ERPCore;
using ERPCore.Entity;
using ERPDal;
using ERPModel.FlowManage.ErpFlowComments;
using ERPModel.FlowManage.FlowRecords;
using ERPModel.UserManage;
using ERPModel.Workplace;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.FlowManage.Services
{
    public class ErpFlowCommentImp : IErpFlowCommentImp
    {
        private readonly IMapper _imapper;
        private readonly IErpMessageMainImp _iErpMessageMainImp;
        private readonly IJSMSService _iJSMSService;
        private readonly JiGuangMessageConfig _jiGuangMessageConfig;

        public ErpFlowCommentImp(
            IMapper imapper,
            IJSMSService iJSMSService,
            IConfiguration iConfiguration,
            IErpMessageMainImp iErpMessageMainImp)
        {
            _imapper = imapper;
            _iErpMessageMainImp = iErpMessageMainImp;
            _iJSMSService = iJSMSService;
            _jiGuangMessageConfig = iConfiguration.GetSection("JiGuangMessageConfig").Get<JiGuangMessageConfig>();
        }

        /// <summary>
        /// 获取流程评论
        /// </summary>
        public async Task<List<ErpFlowCommentDto>> GetByFlowId(string server_id, decimal flow_id)
        {
            using (var db = SqlSugarHelper.DBClient(server_id))
            {
                //查询
                var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpFlowComment>()
                                .Where(x => x.flow_id == flow_id)
                                .Includes(x => x.user_info)
                                .OrderBy(x => x.comment_date)
                                .ToListAsync();

                return _imapper.Map<List<ErpFlowComment>, List<ErpFlowCommentDto>>(list);
            }
        }

        /// <summary>
        /// 获取流程节点下的评论
        /// </summary>
        public async Task<List<ErpFlowCommentDto>> GetByStepId(string server_id, decimal step_id)
        {
            using (var db = SqlSugarHelper.DBClient(server_id))
            {
                //查询
                var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpFlowComment>()
                                .Where(x => x.step_id == step_id)
                                .Includes(x => x.user_info)
                                .OrderBy(x => x.comment_date)
                                .ToListAsync();

                return _imapper.Map<List<ErpFlowComment>, List<ErpFlowCommentDto>>(list);
            }
        }

        /// <summary>
        /// 添加评论
        /// </summary>
        public async Task<ErpFlowCommentDto> AddAsync(string server_id, decimal? user_id, string user_name, ErpFlowCommentInput input)
        {
            if (input.file_urls?.Count > 5 || input.img_urls?.Count > 5)
            {
                throw new Exception("文件或图片的数量不能大于5");
            }
            using (var db = SqlSugarHelper.DBClient(server_id))
            {
                var info = _imapper.Map<ErpFlowCommentInput, ErpFlowComment>(input);
                info.user_id = user_id;
                info.id = Tools.GetSeqCommonID(server_id);

                var res = await db.Insertable(info).ExecuteCommandAsync() > 0;
                if (res)
                {
                    #region 异步发送通知
                    Task.Run(async () =>
                    {
                        var user_list = await db.Queryable<SysPerson>().Where(x => input.user_ids.Contains(x.i_id)).ToListAsync();
                        var flow_record = await db.Queryable<ErpFlowRecord>().FirstAsync(x => x.id == input.flow_id);

                        if (user_list.Count > 0 && flow_record != null)
                        {
                            foreach (var item in user_list)
                            {
                                //添加消息
                                await _iErpMessageMainImp.AddErpMessageMain(server_id, new ErpMessageMain
                                {
                                    title = $"{user_name}在{flow_record.title}里添加了评论 \"{input.content}\"",
                                    content = $"{user_name}在{flow_record.title}里添加了评论 \"{input.content}\"",
                                    type = 3,
                                    model = (int)MessageModelDic.流程评论,
                                    object_id = input.flow_id.ToString(),
                                    state = 1,
                                    created_id = item.i_id,
                                    warn = 1
                                }, new ClientInformation() { i_id = user_id }, db);

                                if (input.is_sms == 1 && !string.IsNullOrWhiteSpace(item.c_phone))
                                {
                                    var dic = new Dictionary<string, string>();
                                    dic.Add("user_name", user_name);
                                    dic.Add("flow_title", flow_record.title);
                                    dic.Add("content", input.content);

                                    //发送短信
                                    await _iJSMSService.SendMessage(item.c_phone, _jiGuangMessageConfig.SignId, _jiGuangMessageConfig.TempId["FlowCommentTemp"], dic);
                                }
                            }
                        }
                    });
                    #endregion

                    return _imapper.Map<ErpFlowComment, ErpFlowCommentDto>(info);
                }
                else
                {
                    return null;
                }
            }
        }

        /// <summary>
        /// 删除评论
        /// </summary>
        public async Task<bool> DeleteAsync(string server_id, decimal id, DateTime? time)
        {
            using (var db = SqlSugarHelper.DBClient(server_id))
            {
                var info = await db.Queryable<ErpFlowComment>().Where(x => x.id == id).FirstAsync();

                if (info == null)
                {
                    throw new Exception($"未找到此评论,id={id}");
                }

                time = time.HasValue ? time : DateTime.Now;

                if (info.comment_date.Value.AddMinutes(5) < time)
                {
                    throw new Exception($"评论时间超过5分钟,不能删除!");
                }

                info.is_delete = 1;
                info.delete_date = time;
                info.content = $"原评论已删除（{time.Value.ToString("MM-dd HH:mm")}）";

                return await db.Updateable(info).ExecuteCommandAsync() > 0;
            }
        }
    }
}
