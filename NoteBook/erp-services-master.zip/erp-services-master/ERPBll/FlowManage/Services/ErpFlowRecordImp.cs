﻿using AutoMapper;
using BusTools.JiGuang.Contracts;
using DotNetCore.CAP;
using ERPBll.Caps;
using ERPBll.FlowManage.Contracts;
using ERPBll.RedisManage.Users;
using ERPBll.SignalRs;
using ERPBll.WorkPlace;
using ERPCore.Entity;
using ERPDal;
using ERPModel.Documents.DocumentAccept;
using ERPModel.Documents.DocumentMain;
using ERPModel.FlowManage;
using ERPModel.FlowManage.ErpFlowChecks;
using ERPModel.FlowManage.ErpFlowCopys;
using ERPModel.FlowManage.ErpFlowStepInits;
using ERPModel.FlowManage.ErpFlowStepUsers;
using ERPModel.FlowManage.FlowRecords;
using ERPModel.FlowManage.FlowSteps;
using ERPModel.UserManage;
using ERPModel.Workplace;
using ERPModel.Workplace;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.FlowManage.Services
{
    /// <summary>
    /// 流程提交记录
    /// </summary>
    public class ErpFlowRecordImp : IErpFlowRecordImp, ICapSubscribe
    {
        private readonly IMapper _imapper;
        private readonly IErpFlowStepImp _erpFlowStepImp;
        private readonly IErpFlowCheckImp _erpFlowCheckImp;
        private readonly IErpFlowInitImp _erpFlowInitImp;
        private readonly IErpFlowStepInitImp _erpFlowStepInitImp;
        private readonly IUserRedisImp _userRedisImp;
        private readonly IErpFlowCopyImp _erpFlowCopyImp;
        private readonly IErpMessageMainImp _iErpMessageMainImp;
        private readonly IJSMSService _iJSMSService;
        private readonly JiGuangMessageConfig _jiGuangMessageConfig;
        private readonly IConfiguration _iConfiguration;

        public ErpFlowRecordImp(
            IMapper imapper,
            IErpFlowStepImp erpFlowStepImp,
            IErpFlowCheckImp erpFlowCheckImp,
            IErpFlowInitImp erpFlowInitImp,
            IErpFlowStepInitImp erpFlowStepInitImp,
            IUserRedisImp userRedisImp,
            IErpMessageMainImp erpMessageMainImp,
            IErpFlowCopyImp erpFlowCopyImp,
            IServerHubImp iServerHubImp,
            IJSMSService iJSMSService,
            IConfiguration iConfiguration,
            IErpMessageMainImp iErpMessageMainImp)
        {
            _imapper = imapper;
            _erpFlowStepImp = erpFlowStepImp;
            _erpFlowCheckImp = erpFlowCheckImp;
            _erpFlowInitImp = erpFlowInitImp;
            _erpFlowStepInitImp = erpFlowStepInitImp;
            _userRedisImp = userRedisImp;
            _erpFlowCopyImp = erpFlowCopyImp;
            _iErpMessageMainImp = iErpMessageMainImp;
            _iJSMSService = iJSMSService;
            _iConfiguration = iConfiguration;
            _jiGuangMessageConfig = iConfiguration.GetSection("JiGuangMessageConfig").Get<JiGuangMessageConfig>();
        }

        /// <summary>
        /// 发起流程（不包含流程设计id）
        /// </summary>
        public async Task<ErpFlowRecordDto> AddAsync(
           string server_id, decimal? user_id, CreateErpFlowRecord input)
        {
            var info = _imapper.Map<CreateErpFlowRecord, ErpFlowRecord>(input);
            info.id = ERPBll.Tools.GetEngineID(server_id);
            info.code = Tools.GetBusinessCode();
            info.SetCreate(input.user_id);

            //审批步骤
            if (input.flow_steps != null && input.flow_steps.Count > 0)
            {
                var step = await _erpFlowStepImp.AddAsync(server_id, user_id, info.id, input.flow_steps);
                if (step != null && step.Count > 0)
                {
                    info.state_child = step[0].id;

                    var users = _imapper.Map<List<ErpFlowStepUserDto>, List<CreateErpFlowCheck>>(step[0].step_users);
                    await _erpFlowCheckImp.AddAsync(server_id, user_id, info.id, users, info);
                }
            }

            await SqlSugarHelper.DBClient(server_id).Insertable(info).ExecuteCommandAsync();

            return _imapper.Map<ErpFlowRecord, ErpFlowRecordDto>(info);
        }

        /// <summary>
        /// 发起流程
        /// </summary>
        public async Task<ErpFlowRecordDto> StartAsync(string server_id, decimal? user_id, List<ErpFlowStepInitDto> input, SqlSugarClient db)
        {
            if (db == null)
            {
                db = SqlSugarHelper.DBClient(server_id);
            }
            var info = new ErpFlowRecord();
            if (input != null && input.Count > 0)
            {
                input.Where(x => x.oper_type == 1).ToList().ForEach(x =>
                {
                    if (x.users.Count < 1)
                    {
                        throw new Exception("审批节点人员不能为空");
                    }
                    if (x.users.Count > 15)
                    {
                        throw new Exception("审批节点人员最多15人");
                    }
                });
                var flow = await _erpFlowInitImp.GetByIdAsync(server_id, user_id, input[0].flow_init_id);
                if (flow == null)
                {
                    throw new Exception($"未找到流程：id={input[0].flow_init_id}");
                }

                var user = await _userRedisImp.GetByIdAsync(((int)user_id.Value).ToString());
                if (user == null)
                {
                    throw new Exception($"未找到用户：id={user_id}");
                }

                //添加审批记录
                info.id = ERPBll.Tools.GetEngineID(server_id);
                info.code = Tools.GetBusinessCode();
                info.type = flow.type;
                string flowName = flow.type == 1 ? ((FormType)flow.object_id).ToString() : ((FlowRecordType)flow.object_id).ToString();
                info.title = $"{user.c_name}提交的{flowName}";
                info.object_id = flow.object_id;
                info.SetCreate(user_id);

                //只添加审批节点
                var check = input.Where(x => x.oper_type == 1).ToList();
                var steps = _imapper.Map<List<ErpFlowStepInitDto>, List<CreateErpFlowStep>>(check);
                var step = await _erpFlowStepImp.AddAsync(server_id, user_id, info.id, steps, db);
                if (step == null || step.Count < 1)
                {
                    throw new Exception($"审批节点新增失败");
                }

                //添加第一节点的审批人
                var users = _imapper.Map<List<ErpFlowStepUserDto>, List<CreateErpFlowCheck>>(step[0].step_users);
                await _erpFlowCheckImp.AddAsync(server_id, user_id, info.id, users, info, db);

                info.state_child = (step?[0].id).Value;

                //添加抄送人
                var copys = input.FirstOrDefault(x => x.oper_type == 3);
                if (copys != null && copys.users != null && copys.users.Count > 0)
                {
                    await _erpFlowCopyImp.AddAsync(server_id, info.id, copys.users.Select(x => x.id).Distinct().ToList(), db);
                }
                await db.Insertable(info).ExecuteCommandAsync();
            }
            return _imapper.Map<ErpFlowRecord, ErpFlowRecordDto>(info);
        }

        /// <summary>
        /// 公文发起流程(只用公文)
        /// </summary>
        public async Task<ErpFlowRecordDto> StartByDocAsync(string server_id, StartFlowInput input)
        {
            var flow = await _erpFlowInitImp.GetByIdAsync(server_id, input.user_id, input.flow_init_id);
            if (flow == null)
            {
                throw new Exception($"未找到流程：id={input.flow_init_id}");
            }

            var user = await _userRedisImp.GetByIdAsync(input.user_id.Value.ToString());
            if (user == null)
            {
                throw new Exception($"未找到用户：id={input.user_id}");
            }
            string flowName = flow.type == 1 ? ((FormType)flow.object_id).ToString() : ((FlowRecordType)flow.object_id).ToString();
            var info = _imapper.Map<StartFlowInput, ErpFlowRecord>(input);
            info.id = ERPBll.Tools.GetEngineID(server_id);
            info.code = Tools.GetBusinessCode();
            info.title = $"{user.c_name}提交的{flowName}";
            info.content = Encoding.UTF8.GetBytes(input.content);
            info.SetCreate(input.user_id);

            var steps = await GetFlowStepAsync(server_id, input.user_id, input.flow_init_id);
            //审批步骤
            if (steps != null && steps.Count > 0)
            {
                steps = steps.Where(x => x.oper_type == 1).ToList();
                var step = await _erpFlowStepImp.AddAsync(server_id, input.user_id, info.id, steps);
                if (step != null && step.Count > 0)
                {
                    info.state_child = step[0].id;

                    var users = _imapper.Map<List<ErpFlowStepUserDto>, List<CreateErpFlowCheck>>(step[0].step_users);
                    await _erpFlowCheckImp.AddAsync(server_id, input.user_id, info.id, users, info);
                }
            }

            await SqlSugarHelper.DBClient(server_id).Insertable(info).ExecuteCommandAsync();

            //发送消息通知
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpFlowCheck>()
                                .Where(x => x.flow_id == info.id)
                                .ToListAsync();
            await _erpFlowCheckImp.SendMessageAsync(server_id, info.id, list);

            return _imapper.Map<ErpFlowRecord, ErpFlowRecordDto>(info);
        }

        /// <summary>
        /// 催办
        /// </summary>
        public async Task<bool> RushAsync(string server_id, decimal? user_id, string user_name, decimal? flow_id, List<decimal?> send_users, string content, int is_sms = 0)
        {
            using (var db = SqlSugarHelper.DBClient(server_id))
            {
                var info = await db.Queryable<ErpFlowRecord>().FirstAsync(x => x.id == flow_id);
                if (info == null || info.id < 1)
                {
                    throw new Exception("未找到流程记录");
                }
                if (info.created_id != user_id)
                {
                    throw new Exception("只能催办本人发起的流程");
                }
                if (info.state != 1)
                {
                    throw new Exception("只能催办审批状态流程");
                }
                var rush_interval = Convert.ToInt32(_iConfiguration.GetSection("RushInterval").Value);
                if (info.send_time.HasValue && info.send_time.Value.AddMinutes(rush_interval) > DateTime.Now)
                {
                    throw new Exception($"您于{info.send_time.Value.ToString("MM-dd HH:mm")}已催办，请稍后再试");
                }

                #region 异步发送消息
                Task.Run(async () => {
                    var user_list = await db.Queryable<SysPerson>().Where(x => send_users.Contains(x.i_id)).ToListAsync();
                    foreach (var item in user_list)
                    {
                        //添加消息
                        await _iErpMessageMainImp.AddErpMessageMain(server_id, new ErpMessageMain
                        {
                            title = content,
                            content = content,
                            type = 7,
                            model = (int)MessageModelDic.流程催办,
                            object_id = flow_id.ToString(),
                            state = 1,
                            created_id = item.i_id,
                            warn = 1
                        }, new ClientInformation() { i_id = user_id }, db);

                        if (is_sms == 1 && !string.IsNullOrWhiteSpace(item.c_phone))
                        {
                            var dic = new Dictionary<string, string>();
                            dic.Add("user_name", user_name);
                            if (info.type == 1)
                            {
                                dic.Add("type_name", ((FormType)info.object_id).ToString());
                            }
                            else
                            {
                                dic.Add("type_name", ((FlowRecordType)info.object_id).ToString());
                            }
                            
                            //发送短信
                            await _iJSMSService.SendMessage(item.c_phone, _jiGuangMessageConfig.SignId, _jiGuangMessageConfig.TempId["FlowRushTemp"], dic);
                        }
                    }
                });
                #endregion

                //更新流程状态
                info.send_time = DateTime.Now;
                return await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync() > 0; 
            }
        }

        /// <summary>
        /// 获取流程设计节点
        /// </summary>
        public async Task<List<CreateErpFlowStep>> GetFlowStepAsync(string server_id, decimal? user_id, int flow_init_id)
        {
            //获取流程所有审批节点
            var steps = await _erpFlowStepInitImp.GetByFlowId(server_id, user_id, flow_init_id);

            return _imapper.Map<List<ErpFlowStepInitDto>, List<CreateErpFlowStep>>(steps);
        }

        public async Task<ErpFlowRecordDto> UpdateAsync(
            string server_id, int flow_id, int detail_id, string content, string detail_ids = "", SqlSugarClient db = null)
        {
            if (db == null)
            {
                db = SqlSugarHelper.DBClient(server_id);
            }

            var info = await db.Queryable<ErpFlowRecord>().FirstAsync(x => x.id == flow_id);
            if (info == null)
            {
                throw new Exception($"未找到流程记录，id={flow_id}");
            }
            info.detail_id = detail_id;
            info.detail_ids = detail_ids;
            info.content = Encoding.UTF8.GetBytes(content);
            await db.Updateable(info).Where(x => x.id == flow_id).ExecuteCommandAsync();

            //消息通知
            var list = await db.Queryable<ErpFlowCheck>().Where(x => x.flow_id == flow_id).ToListAsync();
            await _erpFlowCheckImp.SendMessageAsync(server_id, flow_id, list, db);

            return _imapper.Map<ErpFlowRecord, ErpFlowRecordDto>(info);
        }

        /// <summary>
        /// 分页获取全部
        /// </summary>
        public async Task<(List<ErpFlowRecordDto>, int)> GetListByPageAsync(string server_id, FlowRecordQuery query)
        {
            RefAsync<int> totalCount = 0;
            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpFlowRecord>()
                                .Where(query.ToExp())
                                .Mapper(x => x.created_info, x => x.created_id)
                                .Mapper(x => x.wait_checks, x => x.wait_checks.First().flow_id)
                                .OrderBy(x => x.id, OrderByType.Desc)
                                .ToPageListAsync(query.page_index, query.page_size, totalCount);

            var data = _imapper.Map<List<ErpFlowRecord>, List<ErpFlowRecordDto>>(list);

            var users = await _userRedisImp.GetAllAsync();
            foreach (var info in data)
            {
                if (info.state_child_id == null || info.state_child_id.Count < 1)
                {
                    continue;
                }
                info.state_child_name = String.Join(',', users.Where(x => info.state_child_id.Contains(x.i_id.Value)).Select(x => x.c_name)) + "审批中";
                info.state_child_name_one = users.FirstOrDefault(x => x.i_id == info.state_child_id[0])?.c_name + "审批中";
            }
            return (data, totalCount);
        }

        /// <summary>
        /// 获取全部
        /// </summary>
        public async Task<List<ErpFlowRecordDto>> GetListAsync(string server_id, decimal? user_id, FlowRecordQuery query)
        {
            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpFlowRecord>()
                                .Where(query.ToExp())
                                .Mapper(x => x.created_info, x => x.created_id)
                                .Mapper(x => x.wait_flow_step, x => x.state_child)
                                .Mapper(x => x.wait_checks, x => x.wait_checks.First().flow_id)
                                .OrderBy(x => x.id, OrderByType.Desc)
                                .ToListAsync();

            var data = _imapper.Map<List<ErpFlowRecord>, List<ErpFlowRecordDto>>(list);

            var users = await _userRedisImp.GetAllAsync();
            foreach (var info in data)
            {
                if (info.state_child_id == null || info.state_child_id.Count < 1)
                {
                    continue;
                }
                if (info.state_child_id.Count > 3)
                {
                    info.state_child_name = String.Join(',', users.Where(x => info.state_child_id.Take(2).Contains(x.i_id.Value))
                                                                    .Select(x => x.c_name)) + $"等{info.state_child_id.Count}人审批中";
                }
                else
                {
                    info.state_child_name = String.Join(',', users.Where(x => info.state_child_id.Contains(x.i_id.Value))
                                                                    .Select(x => x.c_name)) + "审批中";
                }
                info.state_child_name_one = users.FirstOrDefault(x => x.i_id == info.state_child_id[0])?.c_name + "审批中";
            }

            return data;
        }

        /// <summary>
        /// 待处理
        /// </summary>
        /// <returns></returns>
        public async Task<(List<ErpFlowRecordDto>, int)> GetWaitAsync(string server_id, decimal? user_id, FlowRecordQuery query)
        {
            RefAsync<int> totalCount = 0;

            //查询
            var ids = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpFlowCheck>()
                                .Where(x => x.check_id == user_id.Value && x.state == 0)
                                .OrderBy(x => x.id, OrderByType.Desc)
                                .Select(x => x.flow_id)
                                .ToListAsync();
            if (ids == null || ids.Count < 1)
            {
                return (new List<ErpFlowRecordDto>(), 0);
            }

            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpFlowRecord>()
                                .Mapper(x => x.wait_checks, x => x.wait_checks.First().flow_id)
                                .Where(query.ToExp())
                                .Where(x => x.state == 1 && ids.Contains(x.id))
                                .Mapper(x => x.created_info, x => x.created_id)
                                .OrderBy(x => x.id, OrderByType.Desc)
                                .ToPageListAsync(query.page_index, query.page_size, totalCount);

            var data = _imapper.Map<List<ErpFlowRecord>, List<ErpFlowRecordDto>>(list);
            var users = await _userRedisImp.GetAllAsync();
            foreach (var info in data)
            {
                if (info.state_child_id == null || info.state_child_id.Count < 1)
                {
                    continue;
                }
                info.state_child_name = String.Join(',', users.Where(x => info.state_child_id.Contains(x.i_id.Value))
                                                                .Select(x => x.c_name)) + "审批中";
                info.state_child_name_one = users.FirstOrDefault(x => x.i_id == info.state_child_id[0])?.c_name + "审批中";
            }

            return (data, totalCount);
        }

        /// <summary>
        /// 全部待处理
        /// </summary>
        /// <returns></returns>
        public async Task<List<ErpFlowRecordDto>> GetAllWaitAsync(string server_id, decimal? user_id, FlowRecordQuery query)
        {
            //查询
            var ids = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpFlowCheck>()
                                .Where(x => x.check_id == user_id.Value && x.state == 0)
                                .OrderBy(x => x.id, OrderByType.Desc)
                                .Select(x => x.flow_id)
                                .ToListAsync();

            if (ids == null || ids.Count < 1)
            {
                return new List<ErpFlowRecordDto>();
            }

            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpFlowRecord>()
                                .Mapper(x => x.wait_checks, x => x.wait_checks.First().flow_id)
                                .Where(query.ToExp())
                                .Where(x => x.state == 1 && ids.Contains(x.id))
                                .Mapper(x => x.created_info, x => x.created_id)
                                .OrderBy(x => x.id, OrderByType.Desc)
                                .ToListAsync();

            var data = _imapper.Map<List<ErpFlowRecord>, List<ErpFlowRecordDto>>(list);
            var users = await _userRedisImp.GetAllAsync();
            foreach (var info in data)
            {
                if (info.state_child_id == null || info.state_child_id.Count < 1)
                {
                    continue;
                }
                info.state_child_name = String.Join(',', users.Where(x => info.state_child_id.Contains(x.i_id.Value)).Select(x => x.c_name)) + "审批中";
                info.state_child_name_one = users.FirstOrDefault(x => x.i_id == info.state_child_id[0])?.c_name + "审批中";
            }

            return data;
        }

        /// <summary>
        /// 全部已处理
        /// </summary>
        /// <returns></returns>
        public async Task<List<ErpFlowRecordDto>> GetAllFinishAsync(string server_id, decimal? user_id, FlowRecordQuery query)
        {
            //查询
            var ids = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpFlowCheck>()
                                .Where(x => x.check_id == user_id.Value && x.state != 0)
                                .OrderBy(x => x.id, OrderByType.Desc)
                                .Select(x => x.flow_id)
                                .ToListAsync();

            if (ids == null || ids.Count < 1)
            {
                return new List<ErpFlowRecordDto>();
            }

            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpFlowRecord>()
                                .Mapper(x => x.wait_checks, x => x.wait_checks.First().flow_id)
                                .Where(query.ToExp())
                                .Where(x => x.state == 1 && ids.Contains(x.id))
                                .Mapper(x => x.created_info, x => x.created_id)
                                .OrderBy(x => x.id, OrderByType.Desc)
                                .ToListAsync();

            var data = _imapper.Map<List<ErpFlowRecord>, List<ErpFlowRecordDto>>(list);
            var users = await _userRedisImp.GetAllAsync();
            foreach (var info in data)
            {
                if (info.state_child_id == null || info.state_child_id.Count < 1)
                {
                    continue;
                }
                info.state_child_name = String.Join(',', users.Where(x => info.state_child_id.Contains(x.i_id.Value)).Select(x => x.c_name)) + "审批中";
                info.state_child_name_one = users.FirstOrDefault(x => x.i_id == info.state_child_id[0])?.c_name + "审批中";
            }

            return data;
        }

        /// <summary>
        /// 已处理
        /// </summary>
        /// <returns></returns>
        public async Task<(List<ErpFlowRecordDto>, int)> GetFinishAsync(string server_id, decimal? user_id, FlowRecordQuery query)
        {
            using (var db = SqlSugarHelper.DBClient(server_id))
            {
                RefAsync<int> totalCount = 0;

                //查询
                var checks = await db.Queryable<ErpFlowCheck>().Includes(x => x.record)
                                    .Where(x => x.check_id == user_id.Value && x.state != 0)
                                    .Where(query.ToCheckExp())
                                    .OrderBy(x => x.update_date, OrderByType.Desc)
                                    .ToPageListAsync(query.page_index, query.page_size, totalCount);
                
                var ids = checks.Select(x => x.flow_id).ToList();
                var wait_check = await db.Queryable<ErpFlowCheck>().Where(x => ids.Contains(x.flow_id) && x.state == 0).ToListAsync();
                var users = await _userRedisImp.GetAllAsync();
                List<ErpFlowRecordDto> list = new List<ErpFlowRecordDto>();
                foreach (var check in checks)
                {
                    check.record.created_info = users.FirstOrDefault(x => x.i_id == check.record.created_id);
                    var info = _imapper.Map<ErpFlowRecord, ErpFlowRecordDto>(check.record);
                    info.state_child_id = wait_check.Where(x => x.flow_id == check.flow_id).Select(x => x.check_id).ToList();
                    if (info.state_child_id != null && info.state_child_id.Count > 0)
                    {
                        info.state_child_name = String.Join(',', users.Where(x => info.state_child_id.Contains(x.i_id.Value)).Select(x => x.c_name)) + "审批中";
                        info.state_child_name_one = users.FirstOrDefault(x => x.i_id == info.state_child_id[0])?.c_name + "审批中";
                    }
                    list.Add(info);
                }
                return (list, totalCount);
            }
        }

        /// <summary>
        /// 已发起
        /// </summary>
        /// <returns></returns>
        public async Task<(List<ErpFlowRecordDto>, int)> GetSubmitAsync(string server_id, decimal? user_id, FlowRecordQuery query)
        {
            RefAsync<int> totalCount = 0;

            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpFlowRecord>()
                                .Where(query.ToExp())
                                .Where(x => x.created_id == user_id)
                                .Mapper(x => x.created_info, x => x.created_id)
                                .Mapper(x => x.wait_checks, x => x.wait_checks.First().flow_id)
                                .OrderBy(x => x.id, OrderByType.Desc)
                                .ToPageListAsync(query.page_index, query.page_size, totalCount);

            var data = _imapper.Map<List<ErpFlowRecord>, List<ErpFlowRecordDto>>(list);

            var users = await _userRedisImp.GetAllAsync();
            foreach (var info in data)
            {
                if (info.state_child_id == null || info.state_child_id.Count < 1)
                {
                    continue;
                }
                info.state_child_name = String.Join(',', users.Where(x => info.state_child_id.Contains(x.i_id.Value)).Select(x => x.c_name)) + "审批中";
                info.state_child_name_one = users.FirstOrDefault(x => x.i_id == info.state_child_id[0])?.c_name + "审批中";
            }
            return (data, totalCount);
        }

        /// <summary>
        /// 已抄送
        /// </summary>
        /// <returns></returns>
        public async Task<(List<ErpFlowRecordDto>, int)> GetCopyAsync(string server_id, decimal? user_id, FlowRecordQuery query)
        {
            RefAsync<int> totalCount = 0;

            //查询
            var ids = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpFlowCopy>()
                                .Where(x => x.user_id == user_id.Value && x.state != 0)
                                .OrderBy(x => x.id, OrderByType.Desc)
                                .Select(x => x.flow_id)
                                .ToListAsync();

            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpFlowRecord>()
                                .Where(query.ToExp())
                                .Where(x => ids.Contains(x.id))
                                .Mapper(async x =>
                                {
                                    if (x.created_id != null)
                                        x.created_info = await _userRedisImp.GetByIdAsync(((int)x.created_id.Value).ToString());
                                })
                                .OrderBy(x => x.id, OrderByType.Desc)
                                .ToPageListAsync(query.page_index, query.page_size, totalCount);

            var data = _imapper.Map<List<ErpFlowRecord>, List<ErpFlowRecordDto>>(list);
            return (data, totalCount);
        }
    }
}
