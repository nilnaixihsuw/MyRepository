﻿using AutoMapper;
using ERPBll.FlowManage.Contracts;
using ERPBll.WorkPlace;
using ERPCore.Entity;
using ERPDal;
using ERPModel.FlowManage;
using ERPModel.FlowManage.ErpFlowCopys;
using ERPModel.FlowManage.FlowRecords;
using ERPModel.UserManage;
using ERPModel.Workplace;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.FlowManage.Services
{
    public class ErpFlowCopyImp: IErpFlowCopyImp
    {
        private readonly IMapper _imapper;
        private readonly IErpMessageMainImp _erpMessageMainImp;

        public ErpFlowCopyImp(
            IMapper imapper,
            IErpMessageMainImp erpMessageMainImp)
        {
            _erpMessageMainImp = erpMessageMainImp;
            _imapper = imapper;
        }

        public async Task<List<ErpFlowCopyDto>> GetListByUserAsync(string server_id, decimal user_id)
        {
            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpFlowCopy>()
                                .Where(x => x.user_id == user_id)
                                .ToListAsync();

            return _imapper.Map<List<ErpFlowCopy>, List<ErpFlowCopyDto>>(list);
        }

        public async Task AddAsync(string server_id, int flow_id, List<decimal> user_ids, SqlSugarClient db)
        {
            if (db == null)
            {
                db = SqlSugarHelper.DBClient(server_id);
            }

            var list = new List<ErpFlowCopy>();
            foreach (var item in user_ids)
            {
                var info = new ErpFlowCopy();
                info.id = ERPBll.Tools.GetEngineID(server_id);
                info.flow_id = flow_id;
                info.user_id = item;
                info.created_date = DateTime.Now;
                list.Add(info);
            }
            await db.Insertable(list).ExecuteCommandAsync();
        }

        public async Task UpdateStateAsync(string server_id, int flow_id)
        {
            //流程
            var info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpFlowRecord>()
                                .FirstAsync(x => x.id == flow_id);
            //抄送记录
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpFlowCopy>()
                                .Where(x => x.flow_id == flow_id)
                                .ToListAsync();

            if (list != null && list.Count > 0)
            {
                var created_user = await SqlSugarHelper.DBClient(server_id).Queryable<SysPerson>()
                                .Where(x => x.i_id == info.created_id)
                                .FirstAsync();

                list.ForEach(x =>
                {
                    x.state = 1;
                    x.updated_date = DateTime.Now;

                    #region 流程完成推送消息给抄送人
                    if (info != null)
                    {
                        //流程类型
                        string flow_type = info.type == 1 ? ((FormType)info.object_id).ToString() : ((FlowRecordType)info.object_id).ToString();
                        //添加未读消息
                        ErpMessageMain context = new ErpMessageMain()
                        {
                            title = $"{created_user?.c_name}在{info.created_date.ToString("yyyy-MM-dd HH:mm")}提交的{flow_type}审批通过，抄送给你，请及时查看！",
                            type = 1,
                            model = info.object_id,
                            object_id = string.IsNullOrEmpty(info.detail_ids) ? info.detail_id.ToString() : info.detail_ids,
                            state = 1,
                            created_id = x.user_id,
                            warn = 1
                        };
                        _erpMessageMainImp.AddErpMessageMain(server_id, context, new ClientInformation() { i_id = 0 }, null);
                    }
                    #endregion
                });
                await SqlSugarHelper.DBClient(server_id).Updateable(list).ExecuteCommandAsync();
            }
        }
    }
}
