﻿using AutoMapper;
using DotNetCore.CAP;
using ERPBll.FlowManage.Contracts;
using ERPBll.RedisManage.Users;
using ERPBll.SignalRs;
using ERPBll.WorkPlace;
using ERPCore.DI;
using ERPCore.Entity;
using ERPCore.Helpers;
using ERPDal;
using ERPDal.UserManage;
using ERPModel.AccidentManage;
using ERPModel.ApprovalForm;
using ERPModel.Documents;
using ERPModel.Documents.DocumentAccept;
using ERPModel.Documents.DocumentMain;
using ERPModel.EnterpriseManage;
using ERPModel.EnterpriseManage.ErpPurchaseReqs;
using ERPModel.FlowManage;
using ERPModel.FlowManage.ErpFlowChecks;
using ERPModel.FlowManage.ErpFlowCopys;
using ERPModel.FlowManage.FlowRecords;
using ERPModel.FlowManage.FlowSteps;
using ERPModel.MaterialManage.PurchaseOrder;
using ERPModel.Oamanage.OaGoodReceives;
using ERPModel.OAManage;
using ERPModel.PartyConstructionManage;
using ERPModel.PartyConstructionManage.ErpTradeMains;
using ERPModel.PersonalManage;
using ERPModel.SafeManage;
using ERPModel.ServiceManage;
using ERPModel.UserManage;
using ERPModel.Vehicleinfomanage;
using ERPModel.Workplace;
using NPinyin;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using ERPBll.RedisManage;
using ERPModel.Oamanage.SysVehicleChecks;
using ERPBll.PersonalManage;
using ERPModel.Oamanage.OaLeaveBalances;
using ERPBll.OAManage;
using Yitter.IdGenerator;
using ERPModel.PersonalManage.Rewards;
using ERPModel.ApiModel.OAManage;
using ERPModel.Oamanage;
using ERPBll.ApprovalForm.Contracts;
using ERPModel.FlowManage.ErpFlowComments;

namespace ERPBll.FlowManage.Services
{
    /// <summary>
    /// 流程审批记录
    /// </summary>
    public class ErpFlowCheckImp : IErpFlowCheckImp
    {
        private readonly IMapper _imapper;
        private readonly ICapPublisher _publisher;
        private readonly IErpFlowStepImp _erpFlowStepImp;
        private readonly IUserRedisImp _userRedisImp;
        private readonly IErpFlowCopyImp _erpFlowCopyImp;
        private readonly IErpMessageMainImp _erpMessageMainImp;
        private readonly ISysPersonDataImp _iSysPersonDataImp;
        private readonly IServerHubImp _iServerHubImp;
        private readonly IOaAttendanceRecordImp _oaAttendanceRecordImp;
        private readonly IOaLeaveBalanceImp _oaLeaveBalanceImp;
        private readonly IErpFlowCommentImp _erpFlowCommentImp;
        private IServiceProvider _serviceProvider;

        public ErpFlowCheckImp(
            ISysPersonDataImp iSysPersonDataImp,
            IMapper imapper,
            ICapPublisher publisher,
            IErpFlowStepImp erpFlowStepImp,
            IUserRedisImp userRedisImp,
            IErpFlowCopyImp erpFlowCopyImp,
            IErpMessageMainImp erpMessageMainImp,
            IServerHubImp iServerHubImp,
            IOaAttendanceRecordImp oaAttendanceRecordImp,
            IOaLeaveBalanceImp oaLeaveBalanceImp,
            IErpFlowCommentImp erpFlowCommentImp,
            IServiceProvider serviceProvider)
        {
            _iSysPersonDataImp = iSysPersonDataImp;
            _imapper = imapper;
            _publisher = publisher;
            _erpFlowStepImp = erpFlowStepImp;
            _userRedisImp = userRedisImp;
            _erpFlowCopyImp = erpFlowCopyImp;
            _erpMessageMainImp = erpMessageMainImp;
            _iServerHubImp = iServerHubImp;
            _oaAttendanceRecordImp = oaAttendanceRecordImp;
            _oaLeaveBalanceImp = oaLeaveBalanceImp;
            _erpFlowCommentImp = erpFlowCommentImp;
            _serviceProvider = serviceProvider;
        }

        /// <summary>
        /// 流程待处理
        /// </summary>
        /// <returns></returns>
        public async Task<List<ErpFlowCheckDto>> GetWaitByFlowAsync(string server_id, int flow_id)
        {
            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpFlowCheck>()
                                .Where(x => x.flow_id == flow_id && x.state == 0)
                                .OrderBy(x => x.id, OrderByType.Desc)
                                .ToListAsync();

            return _imapper.Map<List<ErpFlowCheck>, List<ErpFlowCheckDto>>(list);
        }

        /// <summary>
        /// 用户待处理
        /// </summary>
        /// <returns></returns>
        public async Task<List<ErpFlowCheckDto>> GetWaitByUserAsync(string server_id, decimal? user_id)
        {
            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpFlowCheck>()
                                .Where(x => x.check_id == user_id.Value && x.state == 0)
                                .OrderBy(x => x.id, OrderByType.Desc)
                                .ToListAsync();

            return _imapper.Map<List<ErpFlowCheck>, List<ErpFlowCheckDto>>(list);
        }

        public async Task<List<ErpFlowCheckDto>> AddAsync(
           string server_id, decimal? user_id, int flow_id, List<CreateErpFlowCheck> input, ErpFlowRecord flow_info, SqlSugarClient db = null)
        {
            if (db == null)
            {
                db = SqlSugarHelper.DBClient(server_id);
            }
            var list = _imapper.Map<List<CreateErpFlowCheck>, List<ErpFlowCheck>>(input);
            list.ForEach(x =>
            {
                x.flow_id = flow_id;
                x.created_date = DateTime.Now;
            });
            await db.Insertable(list).ExecuteCommandAsync();

            //消息通知
            await SendMessageAsync(server_id, flow_id, list);
            return _imapper.Map<List<ErpFlowCheck>, List<ErpFlowCheckDto>>(list);
        }

        /// <summary>
        /// 用户是否可以审核
        /// </summary>
        public async Task<bool> IsCheckAsync(string server_id, decimal? user_id, int flow_id, int step_id)
        {
            return await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpFlowCheck>()
                                .Where(x => x.flow_id == flow_id &&
                                            x.step_id == step_id &&
                                            x.check_id == user_id.Value &&
                                            x.state == 0)
                                .CountAsync() > 0;
        }

        /// <summary>
        /// 撤销
        /// </summary>
        public async Task CancelAsync(string server_id, decimal? user_id, int flow_id)
        {
            using (var db = SqlSugarHelper.DBClient(server_id))
            {
                var info = await db.Queryable<ErpFlowRecord>().FirstAsync(x => x.id == flow_id);
                if (info == null || info.id < 1)
                {
                    throw new Exception("未找到流程记录");
                }
                if (info.created_id != user_id)
                {
                    throw new Exception("只能撤销本人发起的流程");
                }
                if (info.state != 1)
                {
                    throw new Exception("只能撤销审批状态流程");
                }

                //更改所有未审批状态
                var list = await db.Queryable<ErpFlowCheck>().Where(x => x.flow_id == flow_id && x.state == 0).ToListAsync();
                if (list != null && list.Count > 0)
                {
                    list.ForEach(x =>
                    {
                        x.state = 6;
                        x.update_date = DateTime.Now;
                    });
                    await db.Updateable(list).UpdateColumns(x => new { x.state, x.update_date }).ExecuteCommandAsync();
                }

                //更新流程状态
                await PushFlowFinishAsync(server_id, flow_id, FlowRecordState.已撤销);
                //推送待办数量
                await PushWaitCount(server_id, Convert.ToInt32(user_id));
            }
        }

        /// <summary>
        /// 审核
        /// </summary>
        public async Task<ErpFlowCheckDto> UpdateAsync(string server_id, decimal? user_id, UpdateErpFlowCheck input)
        {
            using (var db = SqlSugarHelper.DBClient(server_id))
            {
                if (input.state == 2 && string.IsNullOrWhiteSpace(input.remark))
                {
                    throw new Exception("驳回理由不能为空");
                }
                var isCheck = await IsCheckAsync(server_id, user_id, input.flow_id, input.step_id);
                if (!isCheck)
                {
                    throw new Exception("无审核权限");
                }
                if (input.state == 3 && !input.object_id.HasValue)
                {
                    throw new Exception("退回节点不能为空");
                }
                if (input.state == 4 && !input.object_id.HasValue)
                {
                    throw new Exception("转交人不能为空");
                }

                var info = await db.Queryable<ErpFlowCheck>()
                                    .FirstAsync(x => x.flow_id == input.flow_id &&
                                                x.step_id == input.step_id &&
                                                x.check_id == user_id.Value &&
                                                x.state == 0);
                if (info == null)
                {
                    throw new Exception($"未找到待处理记录，id={input.flow_id}");
                }
                info.state = input.state;
                info.remark = input.remark;
                info.SetUpdate(user_id);

                await db.Updateable(info).ExecuteCommandAsync();

                switch ((FlowStepCheckState)input.state)
                {
                    case FlowStepCheckState.通过:
                        await UpdateSucAsync(server_id, user_id, input);
                        break;
                    case FlowStepCheckState.拒绝:
                        await UpdateFailAsync(server_id, user_id, input);
                        break;
                    case FlowStepCheckState.退回:
                        await UpdateBackAsync(server_id, user_id, input);
                        break;
                    case FlowStepCheckState.转交:
                        await UpdateTurnAsync(server_id, user_id, input);
                        break;
                }

                //发送消息数量变更通知
                await _erpMessageMainImp.PushNoReadCount(server_id, Convert.ToInt32(user_id));
                await PushWaitCount(server_id, Convert.ToInt32(user_id));

                return _imapper.Map<ErpFlowCheck, ErpFlowCheckDto>(info);
            }
        }

        /// <summary>
        /// 同意
        /// </summary>
        public async Task UpdateSucAsync(
            string server_id, decimal? user_id, UpdateErpFlowCheck input)
        {
            //节点是否审核完成
            var res = await _erpFlowStepImp.GetCheckStepAsync(server_id, input.step_id);
            if (res)
            {
                //更改节点状态
                await _erpFlowStepImp.UpdateStateAsync(server_id, input.step_id, (int)FlowStepCheckState.通过);
                //或签时更改其他审核人状态
                await UpdateStepAsync(server_id, input.flow_id, input.step_id);

                //获取下一个审批节点
                var next = await _erpFlowStepImp.GetNextStepAsync(server_id, input.flow_id, input.step_id);
                if (next == null) //流程全部完成
                {
                    //更新流程状态
                    await PushFlowFinishAsync(server_id, input.flow_id, FlowRecordState.审核通过);

                    //更新抄送状态
                    await _erpFlowCopyImp.UpdateStateAsync(server_id, input.flow_id);
                }
                else
                {
                    var users = _imapper.Map<List<ErpFlowCheckDto>, List<CreateErpFlowCheck>>(next.wait_users);

                    //新增待审批人员
                    await AddAsync(server_id, user_id, input.flow_id, users, null);

                    //更新流程审批节点
                    await UpdateRecordStepAsync(server_id, input.flow_id, next.id);
                }
            }
        }

        /// <summary>
        /// 拒绝
        /// </summary>
        public async Task UpdateFailAsync(string server_id, decimal? user_id, UpdateErpFlowCheck input)
        {
            //更新流程状态
            await PushFlowFinishAsync(server_id, input.flow_id, FlowRecordState.审核拒绝);

            //更改节点状态
            await _erpFlowStepImp.UpdateStateAsync(server_id, input.step_id, (int)FlowStepCheckState.拒绝);
            //更改其他审核人状态
            await UpdateStepAsync(server_id, input.flow_id, input.step_id);
        }

        /// <summary>
        /// 退回
        /// </summary>
        public async Task UpdateBackAsync(string server_id, decimal? user_id, UpdateErpFlowCheck input)
        {
            if (!input.object_id.HasValue)
            {
                throw new Exception("退回节点不能为空");
            }

            //更改其他审核人状态
            await UpdateStepAsync(server_id, input.flow_id, input.step_id);

            var list = await _erpFlowStepImp.GetByRecordIdAsync(server_id, input.flow_id);
            var ids = list.Where(x => x.id >= input.object_id && x.id <= input.step_id)
                            .Select(x => x.id)
                            .ToList();

            await _erpFlowStepImp.UpdateStateByIdsAsync(server_id, ids, (int)FlowStepState.待处理);

            //获取退回节点信息
            var next = await _erpFlowStepImp.GetStepUserInitAsync(server_id, input.object_id.Value);
            var users = _imapper.Map<List<ErpFlowCheckDto>, List<CreateErpFlowCheck>>(next.wait_users);
            //新增待审批人员
            await AddAsync(server_id, user_id, input.flow_id, users, null);

            //更新流程审批节点
            await UpdateRecordStepAsync(server_id, input.flow_id, input.object_id.Value);
        }

        /// <summary>
        /// 转交
        /// </summary>
        public async Task UpdateTurnAsync(string server_id, decimal? user_id, UpdateErpFlowCheck input)
        {
            if (!input.object_id.HasValue)
            {
                throw new Exception("转交用户不能为空");
            }

            //新增审批人
            input.state = 0;
            var users = new List<CreateErpFlowCheck>()
            {
                new CreateErpFlowCheck()
                {
                    step_id = input.step_id,
                    check_id = input.object_id.Value
                }
            };
            await AddAsync(server_id, user_id, input.flow_id, users, null);

            //更新流程状态
            var info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpFlowRecord>()
                                .FirstAsync(x => x.id == input.flow_id);
            info.send_time = null;
            await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync();
        }

        /// <summary>
        /// 获取审批记录
        /// </summary>
        public async Task<List<ErpFlowCheckDto>> GetByRecordId(string server_id, int flow_id)
        {
            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpFlowCheck>()
                                .Where(x => x.flow_id == flow_id)
                                .Mapper(x => x.check_info, x => x.check_id)
                                .OrderBy(x => x.id, OrderByType.Desc)
                                .ToListAsync();

            return _imapper.Map<List<ErpFlowCheck>, List<ErpFlowCheckDto>>(list);
        }

        /// <summary>
        /// 获取审批进度
        /// </summary>
        public async Task<List<FlowStepDto>> GetFlowStepAsync(string server_id, int flow_id)
        {
            var list = new List<FlowStepDto>();

            #region 发起节点
            //查询发起节点
            var post = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpFlowRecord>()
                                .FirstAsync(x => x.id == flow_id);
            if (post == null)
            {
                throw new Exception($"未找到记录:flow_id={flow_id}");
            }

            var user = await _userRedisImp.GetByIdAsync(post.created_id.Value.ToString());
            list.Add(new FlowStepDto()
            {
                id = post.id,
                date = post.created_date,
                state = 3,
                oper_type = 4,
                title = "发起人",
                dept = user?.department_name,
                users = new List<FlowStepUserDto>()
                {
                    new FlowStepUserDto()
                    {
                        id = post.created_id.Value,
                        name = user?.c_name,
                        state = 3,
                    }
                }
            });
            #endregion

            #region 审批节点
            //查询已处理节点
            var finish = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpFlowCheck>()
                                .Where(x => x.flow_id == flow_id && x.state != 5)
                                .Mapper(x => x.check_info, x => x.check_id)
                                .Mapper(x => x.flow_step, x => x.step_id)
                                .OrderBy(x => new { x.update_date, x.id })
                                .ToListAsync();
            if (finish != null && finish.Count > 0)
            {
                foreach (var item in finish)
                {
                    user = await _userRedisImp.GetByIdAsync(item.check_id.ToString());
                    if (item.state == 0 && list.Exists(x => x.id == item.step_id && x.state == 1)) //未审核节点合并一个
                    {
                        var step = list.FirstOrDefault(x => x.id == item.step_id && x.state == 1);
                        step.users.Add(
                            new FlowStepUserDto()
                            {
                                id = item.check_id,
                                name = user?.c_name,
                                date = item.update_date,
                                state = item.state > 0 ? item.state + 2 : 1,
                                remark = item.remark,
                            });
                        continue;
                    }

                    var info = _imapper.Map<ErpFlowCheck, FlowStepDto>(item);
                    info.id = item.step_id;
                    info.state = item.state > 0 ? item.state + 2 : 1;
                    info.dept = user?.department_name;
                    if (info.state != 8)
                    {
                        info.title = info.title;
                        info.users = new List<FlowStepUserDto>()
                        {
                            new FlowStepUserDto()
                            {
                                id = item.check_id,
                                name = user?.c_name,
                                date = item.update_date,
                                state = item.state > 0 ? item.state + 2 : 1,
                                remark = item.remark,
                            }
                        };
                    }
                    else
                    {
                        info.title = "发起人";
                        user = await _userRedisImp.GetByIdAsync(post.created_id.Value.ToString());
                        info.users = new List<FlowStepUserDto>()
                        {
                            new FlowStepUserDto()
                            {
                                id = post.created_id.Value,
                                name = user?.c_name,
                                date = item.update_date,
                                state = item.state > 0 ? item.state + 2 : 1
                            }
                        };
                    }
                    list.Add(info);
                    if (info.state == 4 || info.state == 8)
                    {
                        return list;
                    }
                }
            }

            //查询未处理节点
            var wait = await _erpFlowStepImp.GetByRecordIdAsync(server_id, flow_id);
            if (finish != null && finish.Count > 0)
            {
                wait = wait.Where(x => x.id > finish.Last().step_id).ToList();
            }
            list.AddRange(_imapper.Map<List<ErpFlowStepDto>, List<FlowStepDto>>(wait));
            #endregion

            #region 抄送节点
            //查询发起节点
            var copys = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpFlowCopy>()
                                .Where(x => x.flow_id == flow_id)
                                .ToListAsync();
            if (copys != null && copys.Count > 0)
            {
                var copyStep = new FlowStepDto()
                {
                    date = post.created_date,
                    state = 2,
                    oper_type = 3,
                    title = "抄送人",
                    users = new List<FlowStepUserDto>()
                };
                foreach (var item in copys)
                {
                    user = await _userRedisImp.GetByIdAsync(item.user_id.ToString());
                    copyStep.users.Add(
                        new FlowStepUserDto()
                        {
                            id = item.user_id,
                            name = user?.c_name,
                            state = 3,
                        });
                }
                list.Add(copyStep);
            }
            #endregion

            //获取评论
            var comments = await _erpFlowCommentImp.GetByFlowId(server_id, flow_id);

            if (comments.Count == 0)
            {
                return list;
            }
            else
            {
                var new_list = new List<FlowStepDto>();

                foreach (var item in list)
                {
                    new_list.Add(item);
                    var step_comments = comments.Where(x => x.step_id == item.id).ToList();
                    new_list.AddRange(_imapper.Map<List<ErpFlowCommentDto>, List<FlowStepDto>>(step_comments));
                }

                return new_list;
            }
        }

        /// <summary>
        /// 或签流程完成更改其他审核人状态
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public async Task UpdateStepAsync(string server_id, int flow_id, int step_id)
        {
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpFlowCheck>()
                                .Where(x => x.flow_id == flow_id &&
                                            x.step_id == step_id &&
                                            x.state == 0)
                                .ToListAsync();
            if (list != null && list.Count > 0)
            {
                list.ForEach(x =>
                {
                    x.state = 5;
                    x.update_date = DateTime.Now;
                });
                await SqlSugarHelper.DBClient(server_id).Updateable(list).ExecuteCommandAsync();
            }
        }

        public async Task<ErpFlowRecordDto> UpdateRecordStepAsync(string server_id, int flow_id, int step_id)
        {
            var info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpFlowRecord>()
                                .FirstAsync(x => x.id == flow_id);
            if (info == null)
            {
                throw new Exception($"未找到流程记录，id={flow_id}");
            }
            info.state_child = step_id;
            info.send_time = null;
            await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync();

            return _imapper.Map<ErpFlowRecord, ErpFlowRecordDto>(info);
        }

        #region 审批流程完成处理
        /// <summary>
        /// 发布流程审批完成事件
        /// </summary>
        /// <returns></returns>
        public async Task PushFlowFinishAsync(string server_id, int flow_id, FlowRecordState state)
        {
            //更新流程状态
            var info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpFlowRecord>()
                                .FirstAsync(x => x.id == flow_id);
            info.state = (int)state;
            info.state_child = 0;
            info.finish_date = DateTime.Now;
            info.send_time = null;
            await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync();

            var created_user = await SqlSugarHelper.DBClient(server_id).Queryable<SysPerson>()
                                .Where(x => x.i_id == info.created_id)
                                .FirstAsync();

            #region 流程完成推送消息给发起人
            //流程类型
            string flow_type = info.type == 1 ? ((FormType)info.object_id).ToString() : ((FlowRecordType)info.object_id).ToString();
            //添加未读消息
            ErpMessageMain context = new ErpMessageMain()
            {
                title = $"{created_user?.c_name}在{info.created_date.ToString("yyyy-MM-dd HH:mm")}提交的{flow_type}{state.ToString()}，请及时查看！",
                type = 1,
                model = info.object_id,
                object_id = string.IsNullOrEmpty(info.detail_ids) ? info.detail_id.ToString() : info.detail_ids,
                state = 1,
                created_id = info.created_id,
                warn = 1
            };
            await _erpMessageMainImp.AddErpMessageMain(server_id, context, new ClientInformation() { i_id = 0 }, null);
            #endregion

            switch (info.object_id)
            {
                case (int)FlowRecordType.会议室申请:
                    await UpdateMeetingStateAsync(server_id, flow_id, state);
                    break;
                case (int)FlowRecordType.公车申请:
                    await UpdateBorrowStateAsync(server_id, flow_id, state);
                    break;
                case (int)FlowRecordType.还车申请:
                    await UpdateReturnStateAsync(server_id, flow_id, state);
                    break;
                case (int)FlowRecordType.发文审批:
                    await UpdateDocumentMainStateAsync(server_id, flow_id, state);
                    break;
                case (int)FlowRecordType.收文审批:
                    await UpdateDocumentAcceptStateAsync(server_id, flow_id, state);
                    break;
                case (int)FlowRecordType.工会会员申请:
                    await UpdateTradeReqStateAsync(server_id, flow_id, state);
                    break;
                case (int)FlowRecordType.事故处理:
                    await UpdateStateAsync(server_id, flow_id, state);
                    break;
                case (int)FlowRecordType.投诉处理:
                    await UpdatePassengerStateAsync(server_id, flow_id, state);
                    break;
                case (int)FlowRecordType.党组织活动申请:
                    await UpdatePartyActivityStateAsync(server_id, flow_id, state);
                    break;
                case (int)FlowRecordType.稽查处理:
                    await UpdateDriverViolationStateAsync(server_id, flow_id, state);
                    break;
                case (int)FlowRecordType.驾驶员入职申请:
                    await UpdateDriverJoinInfoStateAsync(server_id, flow_id, state);
                    break;
                case (int)FlowRecordType.车辆报废:
                    await UpdateDiscardPlanStateAsync(server_id, flow_id, state);
                    break;
                case (int)FlowRecordType.员工奖惩:
                    await UpdateRewardRecordStateAsync(server_id, flow_id, state);
                    break;

                case (int)FormType.请假单:
                    await UpdateRestStateAsync(server_id, flow_id, state);
                    break;
                case (int)FormType.加班单:
                    await UpdateWorkOvertimeStateAsync(server_id, flow_id, state);
                    break;
                case (int)FormType.采购申请单:
                    await UpdatePurchaseReqStateAsync(server_id, flow_id, state);
                    break;
                case (int)FormType.物品领用:
                    await UpdateGoodReceiveStateAsync(server_id, flow_id, state);
                    break;
                case (int)FormType.采购订单:
                    await UpdatePurchaseOrderReqStateAsync(server_id, flow_id, state);
                    break;
                case (int)FormType.车辆例检:
                    await UpdateVehicleCheckStateAsync(server_id, flow_id, state);
                    break;
                case (int)FormType.出差单:
                    await UpdateTripRecordStateAsync(server_id, flow_id, state);
                    break;

            }
        }

        /// <summary>
        /// 会议室流程完成
        /// </summary>
        public async Task UpdateMeetingStateAsync(string server_id, int flow_id, FlowRecordState state)
        {
            var info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpMeetingRecord>()
                                .FirstAsync(x => x.flow_id == flow_id);
            if (info != null)
            {
                // 2未审核(预定中)3通过4拒绝5取消）
                if (state == FlowRecordState.审核通过)
                {
                    info.state = 3;
                }
                else if (state == FlowRecordState.审核拒绝)
                {
                    info.state = 4;
                }
                else if (state == FlowRecordState.已撤销)
                {
                    info.state = 5;
                }

                await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync();
            }
        }

        /// <summary>
        /// 公车申请完成
        /// </summary>
        public async Task UpdateBorrowStateAsync(string server_id, int flow_id, FlowRecordState state)
        {
            //借车流程
            var borrowFlow = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpBusRecord>()
                                .FirstAsync(x => x.borrow_flow_id == flow_id);
            if (borrowFlow != null)
            {
                if (state == FlowRecordState.审核通过)
                {
                    borrowFlow.state_child = 2;
                    await SqlSugarHelper.DBClient(server_id).Updateable(borrowFlow).ExecuteCommandAsync();

                    var bus = await SqlSugarHelper.DBClient(server_id)
                                    .Queryable<ErpBusMain>()
                                    .FirstAsync(x => x.id == borrowFlow.bus_id);
                    if (bus != null)
                    {
                        bus.state = 1;
                        await SqlSugarHelper.DBClient(server_id).Updateable(bus).ExecuteCommandAsync();
                    }
                }
                else if (state == FlowRecordState.审核拒绝)
                {
                    borrowFlow.state = 2;
                    borrowFlow.state_child = 3;
                    await SqlSugarHelper.DBClient(server_id).Updateable(borrowFlow).ExecuteCommandAsync();

                    var bus = await SqlSugarHelper.DBClient(server_id)
                                   .Queryable<ErpBusMain>()
                                   .FirstAsync(x => x.id == borrowFlow.bus_id);
                    if (bus != null)
                    {
                        bus.state = 0;
                        await SqlSugarHelper.DBClient(server_id).Updateable(bus).ExecuteCommandAsync();
                    }
                }
                else if (state == FlowRecordState.已撤销)
                {
                    borrowFlow.state = 2;
                    borrowFlow.state_child = 7;
                    await SqlSugarHelper.DBClient(server_id).Updateable(borrowFlow).ExecuteCommandAsync();

                    var bus = await SqlSugarHelper.DBClient(server_id)
                                   .Queryable<ErpBusMain>()
                                   .FirstAsync(x => x.id == borrowFlow.bus_id);
                    if (bus != null)
                    {
                        bus.state = 0;
                        await SqlSugarHelper.DBClient(server_id).Updateable(bus).ExecuteCommandAsync();
                    }
                }
            }
        }

        /// <summary>
        /// 还车申请完成
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public async Task UpdateReturnStateAsync(string server_id, int flow_id, FlowRecordState state)
        {
            //还车流程
            var backFlow = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpBusRecord>()
                                .FirstAsync(x => x.back_flow_id == flow_id);
            if (backFlow != null)
            {
                if (state == FlowRecordState.审核通过)
                {
                    backFlow.state = 2;
                    backFlow.state_child = 5;
                    await SqlSugarHelper.DBClient(server_id).Updateable(backFlow).ExecuteCommandAsync();

                    var bus = await SqlSugarHelper.DBClient(server_id)
                                    .Queryable<ErpBusMain>()
                                    .FirstAsync(x => x.id == backFlow.bus_id);
                    if (bus != null)
                    {
                        bus.state = 0;
                        bus.last_position = backFlow.back_position;
                        bus.last_mile = backFlow.back_mile;
                        await SqlSugarHelper.DBClient(server_id).Updateable(bus).ExecuteCommandAsync();
                    }
                }
                else if (state == FlowRecordState.审核拒绝)
                {
                    backFlow.state = 1;
                    backFlow.state_child = 6;
                    await SqlSugarHelper.DBClient(server_id).Updateable(backFlow).ExecuteCommandAsync();
                }
                else if (state == FlowRecordState.已撤销)
                {
                    backFlow.state = 1;
                    backFlow.state_child = 2;
                    await SqlSugarHelper.DBClient(server_id).Updateable(backFlow).ExecuteCommandAsync();
                }
            }
        }

        /// <summary>
        /// 发文完成
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public async Task UpdateDocumentMainStateAsync(string server_id, int flow_id, FlowRecordState state)
        {
            var info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpDocumentMain>()
                                .FirstAsync(x => x.flow_record_id == flow_id);
            if (info != null)
            {
                if (state == FlowRecordState.审核通过)
                {
                    info.state = DocumentState.已归档;
                    info.step_name_str = "";
                    info.finish_date = DateTime.Now;
                }
                else if (state == FlowRecordState.审核拒绝)
                {
                    info.step_name_str = "";
                    info.state = DocumentState.已驳回;
                }
                await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync();
            }
        }

        /// <summary>
        /// 收文完成
        /// </summary>
        public async Task UpdateDocumentAcceptStateAsync(string server_id, int flow_id, FlowRecordState state)
        {
            var info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpDocumentAccept>()
                                .FirstAsync(x => x.flow_record_id == flow_id);
            if (info != null)
            {
                if (state == FlowRecordState.审核通过)
                {
                    info.state = DocumentState.已归档;
                    info.step_name_str = "";
                    info.finish_date = DateTime.Now;
                }
                else if (state == FlowRecordState.审核拒绝)
                {
                    info.step_name_str = "";
                    info.state = DocumentState.已驳回;
                }
                await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync();
            }
        }

        /// <summary>
        /// 工会会员申请完成
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public async Task UpdateTradeReqStateAsync(string server_id, int flow_id, FlowRecordState state)
        {
            var info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpTradeReq>()
                                .FirstAsync(x => x.flow_id == flow_id);
            if (info != null)
            {
                if (state == FlowRecordState.审核通过)
                {
                    info.state = 3;
                }
                else if (state == FlowRecordState.审核拒绝)
                {
                    info.state = 4;
                }
                else if (state == FlowRecordState.已撤销)
                {
                    info.state = 5;
                }
                await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync();
            }
        }

        /// <summary>
        /// 乘客服务流程完成
        /// </summary>
        public async Task UpdatePassengerStateAsync(string server_id, int flow_id, FlowRecordState state)
        {
            var info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpPassengerService>()
                                .FirstAsync(x => x.flow_id == flow_id);
            if (info != null)
            {
                if (state == FlowRecordState.审核通过)
                {
                    info.state = 3;
                }
                else if (state == FlowRecordState.审核拒绝)
                {
                    info.state = 4;
                }
                else if (state == FlowRecordState.已撤销)
                {
                    info.state = 5;
                }

                await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync();
            }
        }


        /// <summary>
        /// 党组织活动流程完成
        /// </summary>
        public async Task UpdatePartyActivityStateAsync(string server_id, int flow_id, FlowRecordState state)
        {
            var info = await SqlSugarHelper.DBClient(server_id)
                                           .Queryable<ErpPartyActivity>()
                                           .FirstAsync(x => x.flow_id == flow_id);
            if (info != null)
            {
                if (state == FlowRecordState.审核通过)
                {
                    info.state = 2;
                }
                else if (state == FlowRecordState.审核拒绝)
                {
                    info.state = 3;
                }
                else if (state == FlowRecordState.已撤销)
                {
                    info.state = 4;
                }

                await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync();
            }
        }

        /// <summary>
        /// 驾驶员入职申请通过
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="flow_id"></param>
        /// <param name="state"></param>
        /// <returns></returns>
        public async Task UpdateDriverJoinInfoStateAsync(string server_id, int flow_id, FlowRecordState state)
        {
            var db = SqlSugarHelper.DBClient(server_id);
            var info = await db.Queryable<SysPersonRequest>().FirstAsync(x => x.i_flow_id == flow_id);
            if (info != null)
            {
                if (state == FlowRecordState.审核通过)
                {
                    info.i_state = 3;
                    //写入驾驶员档案
                    var depPersons = new List<SysDepPerson>();
                    var rolePersons = new List<SysRolePerson>();
                    var person = _imapper.Map<SysPersonRequest, SysPerson>(info);

                    person.i_id = await _iSysPersonDataImp.GetId(server_id, "SEQ_SYS_PERSON");
                    if (person.i_department_base != null && person.i_department_base > 0)
                    {
                        depPersons.Add(new SysDepPerson
                        {
                            i_group_id = person.i_department_base,
                            i_child_id = person.i_id,
                            sign = 1
                        });
                    }
                    person.c_login_id = Pinyin.GetInitials(person.c_name).ToLower() + person.c_worker_id;
                    person.c_password = AESCrypto.AESEncrypt("1234");
                    person.c_not_employee = "0";
                    person.c_state = "1";
                    person.i_is_driver = 1;
                    person.i_emp_state = 1;
                    person.i_black = 0;
                    info.d_finish_date = DateTime.Now;
                    await _iSysPersonDataImp.AddUser(server_id, person, depPersons, rolePersons);

                }
                else if (state == FlowRecordState.审核拒绝)
                {
                    info.i_state = 4;
                    info.d_finish_date = DateTime.Now;
                }
                else if (state == FlowRecordState.已撤销)
                {
                    info.i_state = 5;
                    info.d_finish_date = DateTime.Now;
                }

                await db.Updateable(info).ExecuteCommandAsync();
            }
        }

        /// <summary>
        /// 驾驶员违规记录流程完成
        /// </summary>
        public async Task UpdateDriverViolationStateAsync(string server_id, int flow_id, FlowRecordState state)
        {
            var info = await SqlSugarHelper.DBClient(server_id)
                                           .Queryable<ErpDriverViolation>()
                                           .FirstAsync(x => x.flow_id == flow_id);
            if (info != null)
            {
                if (state == FlowRecordState.审核通过)
                {
                    info.state = 3;
                }
                else if (state == FlowRecordState.审核拒绝)
                {
                    info.state = 4;
                }
                else if (state == FlowRecordState.已撤销)
                {
                    info.state = 5;
                }

                await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync();
            }
        }

        /// <summary>
        /// 车辆报废流程完成
        /// </summary>
        public async Task UpdateDiscardPlanStateAsync(string server_id, int flow_id, FlowRecordState state)
        {
            var infos = await SqlSugarHelper.DBClient(server_id)
                                           .Queryable<MaintDiscardPlan>()
                                           .Where(x => x.flow_id == flow_id)
                                           .ToListAsync();
            if (infos != null && infos.Count > 0)
            {
                if (state == FlowRecordState.审核通过)
                {
                    infos.ForEach(r =>
                    {
                        r.state = 3;
                        r.check_state = 1;
                    });

                    var vehicles = await SqlSugarHelper.DBClient(server_id).Queryable<VehicleInfoNew>()
                        .Where(r => infos.Select(m => m.vehicle_id).Contains(r.id))
                        .ToListAsync();
                    vehicles.ForEach(r =>
                    {
                        r.scrap = 1;
                        r.v_num = $"{r.v_num}(报废)";
                    });
                    await SqlSugarHelper.DBClient(server_id).Updateable(vehicles).ExecuteCommandAsync();
                    var _iVehicleRedisManageImp = DIContainer.ServiceLocator.Instance.GetService<IVehicleRedisManageImp>();
                    await _iVehicleRedisManageImp.Clear();

                    await SqlSugarHelper.DBClient(server_id).Deleteable<ErpVehicleStateWarn>()
                        .Where(r => infos.Select(m => m.vehicle_id).Contains(r.vehicle_id))
                        .ExecuteCommandAsync();
                }
                else if (state == FlowRecordState.审核拒绝)
                {
                    infos.ForEach(r => r.state = 4);
                }
                else if (state == FlowRecordState.已撤销)
                {
                    infos.ForEach(r => r.state = 5);
                }

                await SqlSugarHelper.DBClient(server_id).Updateable(infos).ExecuteCommandAsync();
            }
        }

        /// <summary>
        /// 员工奖惩流程完成
        /// </summary>
        public async Task UpdateRewardRecordStateAsync(string server_id, int flow_id, FlowRecordState state)
        {
            var info = await SqlSugarHelper.DBClient(server_id)
                                           .Queryable<ErpRewardRecord>()
                                           .Where(x => x.flow_id == flow_id)
                                           .FirstAsync();
            if (info != null)
            {
                if (state == FlowRecordState.审核通过)
                {
                    info.state = 3;
                    info.finish_date = DateTime.Now;
                }
                else if (state == FlowRecordState.审核拒绝)
                {
                    info.state = 4;
                    info.finish_date = DateTime.Now;
                }
                else if (state == FlowRecordState.已撤销)
                {
                    info.state = 5;
                    info.finish_date = DateTime.Now;
                }

                await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync();
            }
        }

        /// <summary>
        /// 事故处理完成
        /// </summary>
        public async Task UpdateStateAsync(string server_id, int flow_id, FlowRecordState state)
        {
            var info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpAccidentMain>()
                                .FirstAsync(x => x.flow_id == flow_id);
            if (info != null)
            {
                if (state == FlowRecordState.审核通过)
                {
                    info.state = 3;
                }
                else if (state == FlowRecordState.审核拒绝)
                {
                    info.state = 4;
                }
                else if (state == FlowRecordState.已撤销)
                {
                    info.state = 5;
                }

                await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync();
            }
        }

        /// <summary>
        /// 请假单完成
        /// </summary>
        public async Task UpdateRestStateAsync(string server_id, int flow_id, FlowRecordState state)
        {
            using var db = SqlSugarHelper.DBClient(server_id);
            var info = await db.Queryable<OaRestMain>().FirstAsync(x => x.flow_id == flow_id);
            if (info != null)
            {
                if (state == FlowRecordState.审核通过)
                {
                    info.state = 2;
                }
                else if (state == FlowRecordState.审核拒绝)
                {
                    info.state = 3;
                }
                else if (state == FlowRecordState.已撤销)
                {
                    info.state = 4;
                }
                await db.Updateable(info).ExecuteCommandAsync();

                if (state == FlowRecordState.审核通过)
                {
                    List<OaAttendanceRecord> list = new List<OaAttendanceRecord>();
                    var request = new GetHourRequest()
                    {
                        user_id = (int)info.created_id,
                        start_time = info.start_time,
                        end_time = info.end_time,
                        start_date = info.start_date,
                        end_date = info.end_date,
                        type= (ERPCore.Enums.QJJBEnums)info.type
                    };
                    OAManage.IOaRestMainImp _oaRestMainImp = _serviceProvider.GetService<OAManage.IOaRestMainImp>();
                    var hour_details = await _oaRestMainImp.GetTimeDetail(server_id, request);
                    if (hour_details != null)
                    {
                        foreach (var hourDetail in hour_details.day_details)
                        {
                            if (hourDetail.day_hour == 0) break;
                            var data = new OaAttendanceRecord()
                            {
                                id = Tools.GetSeqCommonID(server_id),
                                user_id = info.created_id.Value,
                                date = hourDetail.day,
                                type = 1,
                                type_child = info.type,
                                main_id = info.id,
                                duration = (decimal?)hourDetail.day_hour
                            };
                            list.Add(data);
                        }
                    }
                    await _oaAttendanceRecordImp.AddOaAttendanceRecord(server_id, list, null);
                    if ((RestType)info.type==RestType.年假)
                    {
                        var user = await db.Queryable<SysPerson>().FirstAsync(x => x.i_id == info.created_id);
                        var user_balance = await db.Queryable<OaLeaveBalance>().OrderBy(x => x.created_date, OrderByType.Desc).FirstAsync(x => x.user_id == info.created_id);
                        user_balance.year_balance -= info.day;
                        await SqlSugarHelper.DBClient(server_id).Updateable(user_balance).ExecuteCommandAsync();
                        var year_balance = await db.Queryable<OaLeaveBalanceDetail>().OrderBy(x => x.created_date, OrderByType.Desc).FirstAsync(x => x.user_id == info.created_id);
                        var detail = new OaLeaveBalanceDetail();
                        detail.id = YitIdHelper.NextId();
                        detail.user_id = info.created_id;
                        detail.model = 2;
                        detail.content = $"{user.c_name}使用了{info.day}天年假，余额{user_balance.year_balance}天";
                        detail.value = info.day;
                        detail.created_date = DateTime.Now;
                        detail.start_time = year_balance.start_time;
                        detail.end_time = year_balance.end_time;
                        await db.Insertable(detail).ExecuteCommandAsync();
                    }
                }
            }
        }

        /// <summary>
        /// 加班单完成
        /// </summary>
        public async Task UpdateWorkOvertimeStateAsync(string server_id, int flow_id, FlowRecordState state)
        {
            using (var db = SqlSugarHelper.DBClient(server_id))
            {
                var info = await db.Queryable<OaWorkOvertime>().FirstAsync(x => x.flow_id == flow_id);
                if (info != null)
                {
                    if (state == FlowRecordState.审核通过)
                    {
                        info.state = 2;
                    }
                    else if (state == FlowRecordState.审核拒绝)
                    {
                        info.state = 3;
                    }
                    else if (state == FlowRecordState.已撤销)
                    {
                        info.state = 4;
                    }
                    await db.Updateable(info).ExecuteCommandAsync();
                    if (state == FlowRecordState.审核通过)
                    {
                        List<OaAttendanceRecord> list = new List<OaAttendanceRecord>();
                        //是否超过1天
                        if (info.start_time.Date == info.end_time.Date)
                        {
                            var data = new OaAttendanceRecord()
                            {
                                id = Tools.GetSeqCommonID(server_id),
                                user_id = info.user_id,
                                date = info.start_time.Date,
                                type = 2,
                                type_child = info.type,
                                main_id = info.id,
                                duration = info.hour,
                            };
                            list.Add(data);
                        }
                        else
                        {
                            DateTime nextDay = new DateTime(info.start_time.Year, info.start_time.Month, info.start_time.Day + 1);
                            var data = new OaAttendanceRecord()
                            {
                                id = Tools.GetSeqCommonID(server_id),
                                user_id = info.user_id,
                                date = info.start_time.Date,
                                type = 2,
                                type_child = info.type,
                                main_id = info.id,
                                duration = Convert.ToDecimal((nextDay - info.start_time).TotalHours),
                            };
                            list.Add(data);
                            for (var item = nextDay; item <= info.end_time; item = item.AddDays(1))
                            {
                                data = new OaAttendanceRecord()
                                {
                                    id = Tools.GetSeqCommonID(server_id),
                                    user_id = info.created_id.Value,
                                    date = item,
                                    type = 2,
                                    type_child = info.type,
                                    main_id = info.id,
                                    duration = 24,
                                };
                                if (item.Date == info.end_time.Date)
                                {
                                    data.duration = info.end_time.Hour + Math.Round((decimal)(info.end_time.Minute / 60.0), 2);
                                }
                                list.Add(data);
                            }
                        }
                        await _oaAttendanceRecordImp.AddOaAttendanceRecord(server_id, list, null);
                    }
                }
            }
        }

        /// <summary>
        /// 出差单完成
        /// </summary>
        public async Task UpdateTripRecordStateAsync(string server_id, int flow_id, FlowRecordState state)
        {
            var info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<OaTripRecord>()
                                .FirstAsync(x => x.flow_id == flow_id);
            if (info != null)
            {
                if (state == FlowRecordState.审核通过)
                {
                    info.state = 2;
                }
                else if (state == FlowRecordState.审核拒绝)
                {
                    info.state = 3;
                }
                else if (state == FlowRecordState.已撤销)
                {
                    info.state = 4;
                }
                await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync();

                if (state == FlowRecordState.审核通过)
                {
                    IOaTripRecordImp _oaTripRecordImp = _serviceProvider.GetService<IOaTripRecordImp>();
                    //获取时间段内每天出差时长
                    var durations = await _oaTripRecordImp.GetTripDays(new GetTimeRequest
                    {
                        server_id = server_id,
                        user_id = (int)info.user_id,
                        start_date = info.start_date.Date,
                        end_date = info.end_date.Date,
                        start_time = info.start_time,
                        end_time = info.end_time
                    });

                    if (durations != null && durations?.day_details?.Count > 0)
                    {
                        List<OaAttendanceRecord> list = new List<OaAttendanceRecord>();
                        durations.day_details.ForEach(x => {
                            list.Add(new OaAttendanceRecord
                            {
                                id = Tools.GetSeqCommonID(server_id),
                                user_id = info.user_id,
                                date = x.day.Date,
                                type = 3,
                                type_child = 0,//出差无子类型
                                main_id = info.id,
                                duration = (decimal)x.day_duration
                            });
                        });
                        //插入考勤记录
                        await _oaAttendanceRecordImp.AddOaAttendanceRecord(server_id, list, null);
                    }
                }
            }
        }

        /// <summary>
        /// 采购单完成
        /// </summary>
        public async Task UpdatePurchaseReqStateAsync(string server_id, int flow_id, FlowRecordState state)
        {
            var info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpPurchaseReq>()
                                .FirstAsync(x => x.flow_id == flow_id);
            if (info != null)
            {
                if (state == FlowRecordState.审核通过)
                {
                    info.state = 2;
                }
                else if (state == FlowRecordState.审核拒绝)
                {
                    info.state = 3;
                }
                else if (state == FlowRecordState.已撤销)
                {
                    info.state = 4;
                }
                await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync();
            }
        }

        /// <summary>
        /// 物品领用完成
        /// </summary>
        public async Task UpdateGoodReceiveStateAsync(string server_id, int flow_id, FlowRecordState state)
        {
            var info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<OaGoodReceive>()
                                .FirstAsync(x => x.flow_id == flow_id);
            if (info != null)
            {
                if (state == FlowRecordState.审核通过)
                {
                    info.state = 2;
                }
                else if (state == FlowRecordState.审核拒绝)
                {
                    info.state = 3;
                }
                else if (state == FlowRecordState.已撤销)
                {
                    info.state = 4;
                }
                await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync();
            }
        }

        /// <summary>
        /// 采购订单完成
        /// </summary>
        public async Task UpdatePurchaseOrderReqStateAsync(string server_id, int flow_id, FlowRecordState state)
        {
            var info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpPurchaseOrder>()
                                .FirstAsync(x => x.flow_id == flow_id);
            if (info != null)
            {
                if (state == FlowRecordState.审核通过)
                {
                    info.state = 3;
                }
                else if (state == FlowRecordState.审核拒绝)
                {
                    info.state = 4;
                }
                else if (state == FlowRecordState.已撤销)
                {
                    info.state = 5;
                }
                await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync();
            }
        }

        /// <summary>
        /// 车辆例检完成
        /// </summary>
        public async Task UpdateVehicleCheckStateAsync(string server_id, int flow_id, FlowRecordState state)
        {
            using (var db = SqlSugarHelper.DBClient(server_id))
            {
                var info = await db.Queryable<SysVehicleCheck>().FirstAsync(x => x.flow_id == flow_id);
                if (info != null)
                {
                    if (state == FlowRecordState.审核通过)
                    {
                        info.state = 2;
                    }
                    else if (state == FlowRecordState.审核拒绝)
                    {
                        info.state = 3;
                    }
                    else if (state == FlowRecordState.已撤销)
                    {
                        info.state = 4;
                    }
                    await db.Updateable(info).ExecuteCommandAsync();
                }
            }
        }
        #endregion


        #region 审批消息通知

        /// <summary>
        /// 生成消息通知
        /// </summary>
        public async Task SendMessageAsync(string server_id, int flow_id, List<ErpFlowCheck> checks, SqlSugarClient db = null)
        {
            if (checks == null || checks.Count < 1)
            {
                return;
            }
            if (db == null)
            {
                db = SqlSugarHelper.DBClient(server_id);
            }

            foreach (var check in checks)
            {
                var info = await db.Queryable<ErpFlowRecord>().FirstAsync(x => x.id == flow_id);

                if (info != null && (info.detail_id > 0 || !string.IsNullOrEmpty(info.detail_ids)))
                {
                    //流程类型
                    string flow_type = info.type == 1 ? ((FormType)info.object_id).ToString() : ((FlowRecordType)info.object_id).ToString();

                    //添加未读消息
                    ErpMessageMain context = new ErpMessageMain()
                    {
                        title = $"您有一份{flow_type}待审批，请及时处理",
                        type = 1,
                        model = info.object_id,
                        object_id = string.IsNullOrEmpty(info.detail_ids) ? info.detail_id.ToString() : info.detail_ids,
                        state = 1,
                        send_id = info.created_id,
                        created_id = check.check_id,
                        warn = 1,
                        approval = 1
                    };

                    switch ((FlowRecordType)info.object_id)
                    {
                        case FlowRecordType.发文审批:
                            var main = await db.Queryable<ErpDocumentMain>().FirstAsync(x => x.id == info.detail_id);
                            if (main != null)
                            {
                                context.title = string.Format("您有一份公文待审批，请及时处理!【{0}】", main.title);
                            }
                            break;
                        case FlowRecordType.收文审批:
                            var accept = await db.Queryable<ErpDocumentAccept>().FirstAsync(x => x.id == info.detail_id);
                            if (accept != null)
                            {
                                context.title = string.Format("您有一份公文待审批，请及时处理!【{0}】", accept.title);
                            }
                            break;
                    }

                    await _erpMessageMainImp.AddErpMessageMain(server_id, context, new ClientInformation() { i_id = check.check_id }, db);
                    await PushWaitCount(server_id, (int)check.check_id);
                }
            }
        }

        /// <summary>
        /// 待处理数量
        /// </summary>
        /// <returns></returns>
        public async Task<int> PushWaitCount(string server_id, int user_id)
        {
            using (var db = SqlSugarHelper.DBClient(server_id))
            {
                var appModels = new List<decimal?> { 30, 40, 1000, 1010, 1050, 2000, 10000 };

                //查询
                var checkIds = await db.Queryable<ErpFlowCheck>().Where(x => x.check_id == user_id && x.state == 0).Select(x => x.flow_id)
                                        .ToListAsync();
                //查询
                var waits = await db.Queryable<ErpFlowRecord>().Where(x => checkIds.Contains(x.id) && appModels.Contains(x.object_id))
                                    .ToListAsync();

                await _iServerHubImp.SendMessageByUserAsync(MessageType.AppWaitCount, user_id.ToString(), waits.Count);
                return waits.Count;
            }
        }
        #endregion
    }
}
