﻿using AutoMapper;
using ERPBll.FlowManage.Contracts;
using ERPDal;
using ERPModel.FlowManage;
using ERPModel.FlowManage.ErpFlowInits;
using ERPModel.FlowManage.ErpFlowStepUserInits;
using ERPModel.UserManage;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.FlowManage.Services
{
    /// <summary>
    /// 流程设计节点人员
    /// </summary>
    public class ErpFlowStepUserInitImp: IErpFlowStepUserInitImp
    {
        private readonly IMapper _imapper;

        public ErpFlowStepUserInitImp(
            IMapper imapper)
        {
            _imapper = imapper;
        }

        public async Task<List<FlowStepUserDto>> GetByStepAsync(string server_id, int step_init_id)
        {
            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpFlowStepUserInit>()
                                .Where(x => x.step_init_id == step_init_id)
                                .Mapper(x =>
                                {
                                    var users =  SqlSugarHelper.DBClient(server_id)
                                                        .Queryable<SysPerson>()
                                                        .Where(i => x.type == 1 && i.i_id == x.object_id)
                                                        .ToList();

                                    var roles =  SqlSugarHelper.DBClient(server_id)
                                                        .Queryable<SysRolePerson>()
                                                        .Mapper(i => i.user_info, i => i.i_operator_id)
                                                        .Where(i => x.type == 2 && i.i_role_id == x.object_id)
                                                        .ToList();

                                    x.users = users.Union(roles.Select(t => t.user_info).ToList()).Distinct().ToList();
                                })
                                .ToListAsync();

            var data = new List<SysPerson>();
            if (list != null && list.Count > 0)
            {
                foreach (var item in list)
                {
                    if (item.users != null && item.users.Count > 0)
                    {
                        data.AddRange(item.users);
                    }
                }
            }

            return _imapper.Map<List<SysPerson>, List<FlowStepUserDto>>(data);
        }

        public async Task AddAsync(string server_id, decimal? user_id, int step_init_id, FlowJson input)
        {
            var list = GetDataAsync(server_id, user_id, step_init_id, input);

            await SqlSugarHelper.DBClient(server_id).Insertable(list).ExecuteCommandAsync();
        }

        public async Task<int> DeleteAsync(string server_id, List<int> ids)
        {
            return await SqlSugarHelper.DBClient(server_id)
                           .Deleteable<ErpFlowStepUserInit>()
                           .Where(x => ids.Contains(x.step_init_id))
                           .ExecuteCommandAsync();
        }

        /// <summary>
        /// 解析流程json
        /// </summary>
        public List<ErpFlowStepUserInit> GetDataAsync(string server_id, decimal? user_id, int step_init_id, FlowJson input)
        {
            List<ErpFlowStepUserInit> list = new List<ErpFlowStepUserInit>();
            if (input != null)
            {
                //解析选择列表
                if (input.properties.approvers != null && input.properties.approvers.Count > 0)
                {
                    foreach (var item in input.properties.approvers)
                    {
                        list.Add(new ErpFlowStepUserInit()
                        {
                            id = Tools.GetSeqCommonID(server_id),
                            step_init_id = step_init_id,
                            object_id = item.nodeId,
                            created_id = user_id,
                            created_date = DateTime.Now
                        });
                    }
                }

                //指定成员
                if (input.properties.assigneeType == FlowStepUserType.user)
                {
                    list.ForEach(item => item.type = 1);
                }
                //角色
                else if (input.properties.assigneeType == FlowStepUserType.role)
                {
                    list.ForEach(item => item.type = 2);
                }
                //岗位
                else if (input.properties.assigneeType == FlowStepUserType.position)
                {
                    list.ForEach(item => item.type = 3);
                }

                //解析抄送人员
                if (input.properties.menbers != null && 
                    input.properties.menbers.user != null && 
                    input.properties.menbers.user.Count > 0)
                {
                    foreach (var item in input.properties.menbers.user)
                    {
                        list.Add(new ErpFlowStepUserInit()
                        {
                            id = Tools.GetSeqCommonID(server_id),
                            step_init_id = step_init_id,
                            object_id = item.nodeId,
                            created_id = user_id,
                            created_date = DateTime.Now,
                            type = 1
                        });
                    }
                }
            }
            return list;
        }
    }
}
