﻿using AutoMapper;
using ERPBll.FlowManage.Contracts;
using ERPDal;
using ERPModel.FlowManage.ErpFlowStepUsers;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.FlowManage.Services
{
    /// <summary>
    /// 流程审批步骤人员
    /// </summary>
    public class ErpFlowStepUserImp: IErpFlowStepUserImp
    {
        private readonly IMapper _imapper;

        public ErpFlowStepUserImp(IMapper imapper)
        {
            _imapper = imapper;
        }

        public async Task<List<ErpFlowStepUserDto>> AddAsync(string server_id, int flow_id, int step_id, List<decimal> user_ids, SqlSugarClient db)
        {
            if (db == null)
            {
                db = SqlSugarHelper.DBClient(server_id);
            }
            var list = new List<ErpFlowStepUser>();
            user_ids = user_ids.Distinct().ToList();
            foreach (var item in user_ids)
            {
                var info = new ErpFlowStepUser();
                info.id = ERPBll.Tools.GetEngineID(server_id);
                info.flow_id = flow_id;
                info.step_id = step_id;
                info.check_id = item;
                list.Add(info);
            }

            await db.Insertable(list).ExecuteCommandAsync();

            var data = _imapper.Map<List<ErpFlowStepUser>, List<ErpFlowStepUserDto>>(list);
            return data;
        }

        /// <summary>
        /// 获取节点审批人员
        /// </summary>
        public async Task<List<ErpFlowStepUserDto>> GetFlowStepByRecordId(string server_id, int step_id)
        {
            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpFlowStepUser>()
                                .Where(x => x.step_id == step_id)
                                .Mapper(x => x.check_info, x => x.check_id)
                                .ToListAsync();

            var data = _imapper.Map<List<ErpFlowStepUser>, List<ErpFlowStepUserDto>>(list);
            return data;
        }
    }
}
