﻿using AutoMapper;
using ERPBll.FlowManage.Contracts;
using ERPDal;
using ERPModel.FlowManage.ErpFlowChecks;
using ERPModel.FlowManage.ErpFlowStepUsers;
using ERPModel.FlowManage.FlowSteps;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.FlowManage.Services
{
    /// <summary>
    /// 流程审批步骤
    /// </summary>
    public class ErpFlowStepImp: IErpFlowStepImp
    {
        private readonly IMapper _imapper;
        private readonly IErpFlowStepUserImp _erpFlowStepUserImp;

        public ErpFlowStepImp(
            IMapper imapper,
            IErpFlowStepUserImp erpFlowStepUserImp)
        {
            _imapper = imapper;
            _erpFlowStepUserImp = erpFlowStepUserImp;
        }


        /// <summary>
        /// 获取全部流程审批节点
        /// </summary>
        public async Task<List<ErpFlowStepDto>> GetByRecordIdAsync(string server_id, int flow_id)
        {
            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpFlowStep>()
                                .Where(x => x.flow_id == flow_id)
                                .Mapper(async x =>
                                {
                                    x.step_users = await _erpFlowStepUserImp.GetFlowStepByRecordId(server_id, x.id);
                                })
                                .OrderBy(x => x.seq)
                                .ToListAsync();

            return _imapper.Map<List<ErpFlowStep>, List<ErpFlowStepDto>>(list);
        }

        /// <summary>
        /// 获取节点信息
        /// </summary>
        public async Task<ErpFlowStepDto> GetFlowStepById(string server_id, int step_id)
        {
            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpFlowStep>()
                                .Where(x => x.id == step_id)
                                .Mapper(async x =>
                                {
                                    x.flow_checks = await GetFlowCheckAsync(server_id, x.flow_id, x.id);
                                })
                                .FirstAsync();

            return _imapper.Map<ErpFlowStep, ErpFlowStepDto>(list);
        }

        /// <summary>
        /// 获取多个节点信息
        /// </summary>
        public async Task<List<ErpFlowStepDto>> GetFlowStepByIds(string server_id, List<int> step_ids)
        {
            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpFlowStep>()
                                .Where(x => step_ids.Contains(x.id))
                                .Mapper(async x =>
                                {
                                    x.flow_checks = await GetFlowCheckAsync(server_id, x.flow_id, x.id);
                                })
                                .ToListAsync();

            return _imapper.Map<List<ErpFlowStep>, List<ErpFlowStepDto>>(list);
        }

        /// <summary>
        /// 获取节点审核人
        /// </summary>
        /// <returns></returns>
        public async Task<List<ErpFlowCheckDto>> GetFlowCheckAsync(string server_id, int flow_id, int step_id)
        {
            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpFlowCheck>()
                                .Where(x => x.flow_id == flow_id && x.step_id == step_id)
                                .Mapper(x => x.check_info, x => x.check_id)
                                .OrderBy(x => x.id, OrderByType.Desc)
                                .ToListAsync();

            return _imapper.Map<List<ErpFlowCheck>, List<ErpFlowCheckDto>>(list);
        }

        public async Task<List<ErpFlowStepDto>> AddAsync(
           string server_id, decimal? user_id, int flow_id, List<CreateErpFlowStep> input, SqlSugarClient db)
        {
            if (db == null)
            {
                db = SqlSugarHelper.DBClient(server_id);
            }
            var list = new List<ErpFlowStep>();
            int seq = 1;
            foreach (var item in input)
            {
                var info = new ErpFlowStep();
                info.id = ERPBll.Tools.GetEngineID(server_id);
                info.flow_id = flow_id;
                info.type = item.type;
                info.seq = seq;
                info.title = item.title;
                info.state = 1;
                info.SetCreate(user_id);

                //节点审批人员
                if (item.user_ids != null && item.user_ids.Count > 0)
                {
                    info.step_users = await _erpFlowStepUserImp.AddAsync(server_id, flow_id, info.id, item.user_ids, db);
                }

                list.Add(info);
                seq++;
            }

            await db.Insertable(list).ExecuteCommandAsync();

            return _imapper.Map<List<ErpFlowStep>, List<ErpFlowStepDto>>(list);
        }

        public async Task<ErpFlowStepDto> UpdateStateAsync(string server_id, int id, int state)
        {
            var info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpFlowStep>()
                                .FirstAsync(x => x.id == id);
            if (info == null)
            {
                throw new Exception($"未找到流程节点，id={id}");
            }
            info.state = state;
            await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync();

            return _imapper.Map<ErpFlowStep, ErpFlowStepDto>(info);
        }

        public async Task<List<ErpFlowStepDto>> UpdateStateByIdsAsync(string server_id, List<int> ids, int state)
        {
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpFlowStep>()
                                .Where(x => ids.Contains(x.id))
                                .ToListAsync();
            if (list == null || list.Count < 1)
            {
                throw new Exception($"未找到流程节点");
            }
            list.ForEach(x => x.state = state);
            await SqlSugarHelper.DBClient(server_id).Updateable(list).ExecuteCommandAsync();

            return _imapper.Map<List<ErpFlowStep>, List<ErpFlowStepDto>>(list);
        }

        /// <summary>
        /// 节点是否审核完成
        /// </summary>
        public async Task<bool> GetCheckStepAsync(string server_id, int step_id)
        {
            //查询
            var info = await GetFlowStepById(server_id, step_id);
            if (info.type == 1)
            {
                return info.wait_users.Count == 0;
            }
            else
            {
                return info.finish_users.Count() > 0;
            }
        }

        /// <summary>
        /// 获取下一审核节点
        /// </summary>
        public async Task<ErpFlowStepDto> GetNextStepAsync(string server_id, int flow_id , int step_id)
        {
            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpFlowStep>()
                                .Where(x => x.flow_id == flow_id && x.id > step_id)
                                .OrderBy(x => x.id)
                                .Mapper(async x =>
                                {
                                    var users = await _erpFlowStepUserImp.GetFlowStepByRecordId(server_id, x.id);
                                    x.flow_checks = _imapper.Map<List<ErpFlowStepUserDto>, List<ErpFlowCheckDto>>(users);
                                })
                                .FirstAsync();

            return _imapper.Map<ErpFlowStep, ErpFlowStepDto>(list);
        }

        /// <summary>
        /// 获取节点原始审核人员
        /// </summary>
        public async Task<ErpFlowStepDto> GetStepUserInitAsync(string server_id, int step_id)
        {
            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpFlowStep>()
                                .Where(x => x.id == step_id)
                                .OrderBy(x => x.id)
                                .Mapper(async x =>
                                {
                                    var users = await _erpFlowStepUserImp.GetFlowStepByRecordId(server_id, x.id);
                                    x.flow_checks = _imapper.Map<List<ErpFlowStepUserDto>, List<ErpFlowCheckDto>>(users);
                                })
                                .FirstAsync();

            return _imapper.Map<ErpFlowStep, ErpFlowStepDto>(list);
        }

        /// <summary>
        /// 获取退回节点
        /// </summary>
        public async Task<List<ErpFlowStepDto>> GetBackStepAsync(string server_id, int flow_id, int step_id)
        {
            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpFlowStep>()
                                .Where(x => x.flow_id == flow_id && x.id < step_id)
                                .OrderBy(x => x.id)
                                .Mapper(async x =>
                                {
                                    var users = await _erpFlowStepUserImp.GetFlowStepByRecordId(server_id, x.id);
                                    x.flow_checks = _imapper.Map<List<ErpFlowStepUserDto>, List<ErpFlowCheckDto>>(users);
                                })
                                .ToListAsync();

            var data = list.Select(x =>
                new ErpFlowStep
                {
                    id = x.id,
                    title = x.title + "(" + string.Join(',', x.flow_checks.Select(t => t.check_name)) + ")"
                }).ToList();
            return _imapper.Map<List<ErpFlowStep>, List<ErpFlowStepDto>>(data);
        }

        /// <summary>
        /// 用户是否可以审批
        /// </summary>
        /// <returns></returns>
        public async Task<bool> CheckUserAsync (string server_id, decimal? user_id, int step_id)
        {
            //查询
            var info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpFlowStep>()
                                .Where(x => x.id == step_id)
                                .Mapper(x => x.flow_checks, x => x.flow_checks.First().step_id)
                                .FirstAsync();
             
            return info.flow_checks.Count(x => x.check_id == user_id.Value) > 0;
        }
    }
}
