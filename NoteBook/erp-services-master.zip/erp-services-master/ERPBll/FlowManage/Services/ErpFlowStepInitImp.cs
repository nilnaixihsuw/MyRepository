﻿using AutoMapper;
using ERPBll.FlowManage.Contracts;
using ERPBll.RedisManage.Users;
using ERPBll.UserManage;
using ERPDal;
using ERPModel.FlowManage;
using ERPModel.FlowManage.ErpFlowInits;
using ERPModel.FlowManage.ErpFlowStepInits;
using ERPModel.FlowManage.ErpFlowStepUserInits;
using ERPModel.UserManage;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.FlowManage.Services
{
    /// <summary>
    /// 流程设计节点
    /// </summary>
    public class ErpFlowStepInitImp : IErpFlowStepInitImp
    {
        private readonly IMapper _imapper;
        private readonly IErpFlowStepUserInitImp _erpFlowStepUserInitImp;
        private readonly IErpFlowConditionImp _erpFlowConditionImp;
        private readonly IUserRedisImp _userRedisImp;

        public ErpFlowStepInitImp(
            IMapper imapper,
            IErpFlowStepUserInitImp erpFlowStepUserInitImp,
            IErpFlowConditionImp erpFlowConditionImp,
            IUserRedisImp userRedisImp)
        {
            _imapper = imapper;
            _erpFlowStepUserInitImp = erpFlowStepUserInitImp;
            _erpFlowConditionImp = erpFlowConditionImp;
            _userRedisImp = userRedisImp;
        }

        /// <summary>
        /// 获取流程设计节点
        /// </summary>
        public async Task<List<ErpFlowStepInitDto>> GetByFlowId(string server_id, decimal? user_id, int flow_init_id)
        {
            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpFlowStepInit>()
                                .Where(x => x.flow_init_id == flow_init_id)
                                .ToListAsync();
            if (list == null || list.Count < 1)
            {
                return new List<ErpFlowStepInitDto>();
            }

            var info = list.First(x => x.parent_id == 0);

            var data = await GetStepAsync(server_id, user_id, list, info, info.id, null);
            return _imapper.Map<List<ErpFlowStepInit>, List<ErpFlowStepInitDto>>(data);
        }

        /// <summary>
        /// 根据表单数据获取流程设计所有节点
        /// </summary>
        public async Task<List<ErpFlowStepInitDto>> GetByFormData(string server_id, decimal? user_id, int object_id, object form_data)
        {
            //查询
            var flowInit = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpFlowInit>()
                                .Where(x => x.object_id == object_id && x.user > 0)
                                .OrderBy(x => x.id, SqlSugar.OrderByType.Desc)
                                .FirstAsync();
            if (flowInit == null)
            {
                throw new Exception($"未找到{((FormType)object_id).ToString()}流程设计");
            }

            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpFlowStepInit>()
                                .Where(x => x.flow_init_id == flowInit.id)
                                .ToListAsync();
            if (list == null || list.Count < 1)
            {
                return new List<ErpFlowStepInitDto>();
            }

            var info = list.First(x => x.parent_id == 0);

            var data = await GetStepAsync(server_id, user_id, list, info, info.id, form_data);
            return _imapper.Map<List<ErpFlowStepInit>, List<ErpFlowStepInitDto>>(data);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="user_id"></param>
        /// <param name="list">所有节点</param>
        /// <param name="info">当前执行到的节点</param>
        /// <param name="parent_id">上一次循环的节点id</param>
        /// <param name="childs">有子条件时暂存的审核节点</param>
        /// <param name="data">顺序返回审批节点</param>
        /// <returns></returns>
        public async Task<List<ErpFlowStepInit>> GetStepAsync(string server_id, decimal? user_id, List<ErpFlowStepInit> list, ErpFlowStepInit info,
            int parent_id, object form_data, List<ErpFlowStepInit> childs = null, List<ErpFlowStepInit> data = null)
        {
            if (data == null)
            {
                if (info.seq_type == 4)
                {
                    info.users = new List<FlowStepUserDto>()
                    {
                        new FlowStepUserDto()
                        {
                            id = user_id.Value,
                            name =(await _userRedisImp.GetByIdAsync(((int)user_id.Value).ToString()))?.c_name
                        }
                    };
                }
                else
                {
                    info.users = await GetStepUserAsync(server_id, user_id.Value, info.id, info);
                }
                data = new List<ErpFlowStepInit> { info };
            }

            //获取当前审核节点
            var step = list.FirstOrDefault(x => x.parent_id == parent_id && x.seq_type != 2);

            //获取当前条件节点
            var conditions = list.Where(x => x.parent_id == parent_id && x.seq_type == 2).ToList();
            if (conditions != null && conditions.Count > 0) //条件节点
            {
                foreach (var condition in conditions)
                {
                    //是否符合当前条件
                    var res = await _erpFlowConditionImp.IsPassAsync(server_id, user_id, condition.id, form_data);
                    if (res)
                    {
                        if (childs == null)
                        {
                            childs = new List<ErpFlowStepInit>();
                        }
                        if (step != null)
                        {
                            //符合条件时把当前审核节点暂存
                            childs.Add(step);
                        }
                        //遍历条件下的子节点
                        await GetStepAsync(server_id, user_id, list, info, condition.id, form_data, childs, data);
                        break;
                    }
                }
            }

            //找到子节点
            if (step != null && info.child == null)
            {
                step.users = await GetStepUserAsync(server_id, user_id.Value, step.id, step);
                info.child = step;
                data.Add(info.child);

                await GetStepAsync(server_id, user_id, list, step, step.id, form_data, childs, data);
            }

            //没有找到子节点但有缓存节点，说明是条件节点已遍历完成
            if (childs != null && childs.Count > 0)
            {
                var child = childs.Last();
                child.users = await GetStepUserAsync(server_id, user_id.Value, child.id, child);
                info.child = child;
                data.Add(info.child);
                childs.Remove(child);

                await GetStepAsync(server_id, user_id, list, child, child.id, form_data, childs, data);
            }
            return data;
        }

        /// <summary>
        /// 获取节点审核人员
        /// </summary>
        /// <returns></returns>
        public async Task<List<FlowStepUserDto>> GetStepUserAsync(string server_id, decimal user_id, int step_init_id, ErpFlowStepInit info = null)
        {
            //查询
            if (info == null)
            {
                info = await SqlSugarHelper.DBClient(server_id)
                                    .Queryable<ErpFlowStepInit>()
                                    .FirstAsync(x => x.id == step_init_id);
            }

            var data = new List<FlowStepUserDto>();

            switch ((FlowStepUserType)info.user_type)
            {
                case FlowStepUserType.no:
                case FlowStepUserType.user:
                case FlowStepUserType.role:
                case FlowStepUserType.optional:
                    data = await _erpFlowStepUserInitImp.GetByStepAsync(server_id, step_init_id);
                    break;

                case FlowStepUserType.director:
                    var manage_id = GetDeptManage(server_id, user_id);
                    var manage_info = await _userRedisImp.GetByIdAsync(manage_id);
                    data = _imapper.Map<List<SysPerson>, List<FlowStepUserDto>>(new List<SysPerson> { manage_info });
                    break;

                case FlowStepUserType.myself:
                    var user_info = await _userRedisImp.GetByIdAsync(user_id.ToString());
                    data = _imapper.Map<List<SysPerson>, List<FlowStepUserDto>>(new List<SysPerson> { user_info });
                    break;
            }

            return data;
        }

        /// <summary>
        /// 获取部门主管id
        /// </summary>
        /// <returns></returns>
        public string GetDeptManage(string server_id, decimal user_id)
        {
            decimal dept_id = (decimal)DeptInfoBll.GetPersonById(server_id, user_id).i_department_base;
            var manager_id = DeptInfoBll.GetDeptInfo(server_id, dept_id).manager_id;
            if (manager_id == "0")
            {
                return user_id.ToString();
            }
            return manager_id;
        }

        public async Task AddAsync(string server_id, decimal? user_id, int flow_init_id, FlowJson input)
        {
            var list = await GetDataAsync(server_id, user_id, flow_init_id, 0, input);

            await SqlSugarHelper.DBClient(server_id).Insertable(list).ExecuteCommandAsync();
        }

        public async Task<int> DeleteAsync(string server_id, List<int> ids)
        {
            var list = await SqlSugarHelper.DBClient(server_id)
                           .Queryable<ErpFlowStepInit>()
                           .Where(x => ids.Contains(x.flow_init_id))
                           .ToListAsync();

            var res = await SqlSugarHelper.DBClient(server_id).Deleteable(list).ExecuteCommandAsync();

            var step_ids = list.Select(x => x.id).ToList();
            //删除节点条件
            await _erpFlowConditionImp.DeleteAsync(server_id, step_ids);
            //删除节点人员
            await _erpFlowStepUserInitImp.DeleteAsync(server_id, step_ids);

            return res;
        }

        /// <summary>
        /// 解析流程json
        /// </summary>
        public async Task<List<ErpFlowStepInit>> GetDataAsync(
            string server_id, decimal? user_id, int flow_init_id, int parent_id, FlowJson input, List<ErpFlowStepInit> list = null)
        {
            if (input != null)
            {
                if (list == null)
                {
                    list = new List<ErpFlowStepInit>();
                }

                var info = _imapper.Map<FlowJson, ErpFlowStepInit>(input);
                info.id = ERPBll.Tools.GetEngineID(server_id);
                info.SetCreate(user_id, flow_init_id, parent_id);
                if (info.seq_type == 3 && input.properties.userOptional) //抄送允许自选
                {
                    info.user_type = 6;
                }
                list.Add(info);

                if (info.seq_type == 2) //添加条件
                {
                    //保存条件
                    await _erpFlowConditionImp.AddAsync(server_id, user_id, info.id, input);
                }

                //添加条件子节点
                if (input.conditionNodes != null && input.conditionNodes.Count > 0)
                {
                    foreach (var item in input.conditionNodes)
                    {
                        list = await GetDataAsync(server_id, user_id, flow_init_id, info.id, item, list);
                    }
                }
                //添加子节点
                if (input.childNode != null)
                {
                    list = await GetDataAsync(server_id, user_id, flow_init_id, info.id, input.childNode, list);
                }

                //保存节点审核人员
                await _erpFlowStepUserInitImp.AddAsync(server_id, user_id, info.id, input);

            }
            return list;
        }
    }
}
