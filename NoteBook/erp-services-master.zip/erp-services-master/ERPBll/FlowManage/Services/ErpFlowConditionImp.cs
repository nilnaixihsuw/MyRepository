﻿using AutoMapper;
using ERPBll.FlowManage.Contracts;
using ERPDal;
using ERPModel.ApiModel.OAManage;
using ERPModel.ApprovalForm;
using ERPModel.EnterpriseManage.ErpPurchaseReqs;
using ERPModel.FlowManage;
using ERPModel.FlowManage.ErpFlowConditions;
using ERPModel.FlowManage.ErpFlowInits;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.FlowManage.Services
{
    /// <summary>
    /// 流程条件
    /// </summary>
    public class ErpFlowConditionImp: IErpFlowConditionImp
    {
        private readonly IMapper _imapper;

        public ErpFlowConditionImp(
            IMapper imapper)
        {
            _imapper = imapper;
        } 

        public async Task AddAsync(string server_id, decimal? user_id, int step_init_id, FlowJson input)
        {
            var list = GetDataAsync(server_id, user_id, step_init_id, input);

            await SqlSugarHelper.DBClient(server_id).Insertable(list).ExecuteCommandAsync();
        }

        public async Task<int> DeleteAsync(string server_id, List<int> ids)
        {
            return await SqlSugarHelper.DBClient(server_id)
                           .Deleteable<ErpFlowCondition>()
                           .Where(x => ids.Contains(x.step_init_id))
                           .ExecuteCommandAsync();
        }

        public async Task<bool> IsPassAsync(string server_id, decimal? user_id, int id, object form_data)
        {
            if(form_data == null)
            {
                return true;
            }

            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpFlowCondition>()
                                .Where(x => x.step_init_id == id)
                                .ToListAsync();

            foreach (var item in list)
            {
                switch(item.form_id)
                {
                    case ConditionType.请假天数:
                        var rest = JsonConvert.DeserializeObject<OaRestDto>(form_data.ToString());
                        if (!NumberCondition(item.type_child, item.value, rest.day / 24))
                        {
                            return false;
                        }
                        break;
                    case ConditionType.请假类型:
                        rest = JsonConvert.DeserializeObject<OaRestDto>(form_data.ToString());
                        if (rest.type.ToString() != item.value)
                        {
                            return false;
                        }
                        break;
                    case ConditionType.加班时长:
                        var overtime = JsonConvert.DeserializeObject<CreateOrUpdateOaWorkOvertime>(form_data.ToString());
                        if (!NumberCondition(item.type_child, item.value, overtime.hour))
                        {
                            return false;
                        }
                        break ;
                    case ConditionType.采购金额:
                        var purchase = JsonConvert.DeserializeObject<CreateErpPurchaseReq>(form_data.ToString());
                        if (!NumberCondition(item.type_child, item.value, purchase.details.Sum(x => x.price * x.count)))
                        {
                            return false;
                        }
                        break;
                }
            }
            return true;
        }

        /// <summary>
        /// 数值比较
        /// </summary>
        /// <param name="type"></param>
        /// <param name="old_value"></param>
        /// <param name="new_value"></param>
        /// <returns></returns>
        private bool NumberCondition(FlowConditionTypeDetail type, string old_value, decimal new_value)
        {
            switch (type)
            {
                case FlowConditionTypeDetail.lt:
                    if (Convert.ToInt32(new_value) >= Convert.ToInt32(old_value))
                    {
                        return false;
                    }
                    break;
                case FlowConditionTypeDetail.lte:
                    if (Convert.ToInt32(new_value) > Convert.ToInt32(old_value))
                    {
                        return false;
                    }
                    break;
                case FlowConditionTypeDetail.eq:
                    if (Convert.ToInt32(new_value) != Convert.ToInt32(old_value))
                    {
                        return false;
                    }
                    break;
                case FlowConditionTypeDetail.gte:
                    if (Convert.ToInt32(new_value) < Convert.ToInt32(old_value))
                    {
                        return false;
                    }
                    break;
                case FlowConditionTypeDetail.gt:
                    if (Convert.ToInt32(new_value) <= Convert.ToInt32(old_value))
                    {
                        return false;
                    }
                    break;
                case FlowConditionTypeDetail.bet:
                    string[] vals = old_value.Split(',');
                    if (Convert.ToInt32(new_value) < Convert.ToInt32(vals[0]) || Convert.ToInt32(new_value) > Convert.ToInt32(vals[1]))
                    {
                        return false;
                    }
                    break;
            }

            return true;
        }

        /// <summary>
        /// 解析流程条件json
        /// </summary>
        public List<ErpFlowCondition> GetDataAsync(string server_id, decimal? user_id, int step_init_id, FlowJson input)
        {
            List<ErpFlowCondition> list = new List<ErpFlowCondition>();
            if (input != null && input.properties.conditions != null && input.properties.conditions.Count > 0)
            {
                foreach(var item in input.properties.conditions)
                {
                    var info = new ErpFlowCondition()
                    {
                        id = Tools.GetSeqCommonID(server_id),
                        step_init_id = step_init_id,
                        form_id = item.formId,
                        created_id = user_id,
                        created_date = DateTime.Now
                    };

                    if (item.formId == ConditionType.请假类型)
                    {
                        info.value = item.conditionValue.ToString();
                    }
                    if(item.formId == ConditionType.请假天数)
                    {
                        var val = JsonConvert.DeserializeObject<FlowConditionValue>(item.conditionValue.ToString());
                        info.type_child = val.type;
                        info.value = val.value.ToString();
                    }
                    if(item.formId == ConditionType.加班时长)
                    {
                        var val = JsonConvert.DeserializeObject<FlowConditionValue>(item.conditionValue.ToString());
                        info.type_child = val.type;
                        info.value = val.value.ToString();
                    }
                    if (item.formId == ConditionType.采购金额)
                    {
                        var val = JsonConvert.DeserializeObject<FlowConditionValue>(item.conditionValue.ToString());
                        info.type_child = val.type;
                        info.value = val.value.ToString();
                    }
                    list.Add(info);
                }
            }
            return list;
        }
    }
}
