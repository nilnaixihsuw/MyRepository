﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ERPDal;
using ErpModel;

namespace ErpBll
{
    public class OperateLogBll
    {
        public static void OpRecord(string strsvr, OperateLog operatelog)
        {
            OperateLogDal.OpRecord(strsvr, operatelog);
        }
    }
}
