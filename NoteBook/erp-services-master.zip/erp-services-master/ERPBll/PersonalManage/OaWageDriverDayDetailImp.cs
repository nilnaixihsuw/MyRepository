﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPDal.PersonalManage;
using ERPModel.PersonalManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using System.Linq.Expressions;
using ERPDal;
using ERPModel.ApiModel.PersonalManage;
using ERPModel.UserManage;
using ERPDal.UserManage;
using ERPBll.RedisManage.Trees;
using ERPBll.RedisManage.Lines;
using ERPModel.SystemManage;
using ERPModel.CommonModel;
using AutoMapper;
using ERPCore.Helpers;
using ERPBll.RedisManage.Users;

namespace ERPBll.PersonalManage
{
    public class OaWageDriverDayDetailImp : BusinessRespository<OaWageDriverDayDetail, IOaWageDriverDayDetailDataImp>, IOaWageDriverDayDetailImp
    {
        private readonly IOaWageDriverDayDataImp _iOaWageDriverDayDataImp;
        private readonly ISysPersonDataImp _iSysPersonDataImp;
        private readonly IOaWageSettingDataImp _iOaWageSettingDataImp;
        private readonly ISysDepartmentDataImp _iSysDepartmentDataImp;
        private readonly IUserRedisImp _userRedisImp;

        public OaWageDriverDayDetailImp(
            ISysDepartmentDataImp iSysDepartmentDataImp,
            IOaWageSettingDataImp iOaWageSettingDataImp,
            ISysPersonDataImp iSysPersonDataImp,
            IOaWageDriverDayDataImp iOaWageDriverDayDataImp,
            IOaWageDriverDayDetailDataImp dataImp,
            IUserRedisImp userRedisImp) : base(dataImp)
        {
            _iSysDepartmentDataImp = iSysDepartmentDataImp;
            _iOaWageSettingDataImp = iOaWageSettingDataImp;
            _iSysPersonDataImp = iSysPersonDataImp;
            _iOaWageDriverDayDataImp = iOaWageDriverDayDataImp;
            _dataImp = dataImp;
            _userRedisImp = userRedisImp;
        }

        public async Task<bool> AddOaWageDriverDayDetail(string server_id, OaWageDriverDayDetail context, ClientInformation client)
        {
            if (context.id > 0)
            {
                var old = await _dataImp.Get(server_id, context.id);
                context.created_id = old.created_id;
                context.created_date = old.created_date;
                return await _dataImp.Update(server_id, context);
            }
            else
            {
                context.created_date = DateTime.Now;
                context.created_id = client.i_id;
                return await _dataImp.Insert(server_id, context);
            }
        }

        public async Task<Tuple<List<OaWageDriverDayDetail>, int>> QueryOaWageDriverDayDetailPageList(string server_id, SalaryListRequest request, string v)
        {
            var exp = await GetExp(request);
            return await ExtensionList(server_id, request.ToExp(exp), v, request.page_size, request.page_index, request.orderby);
        }

        public async Task<List<OaWageDriverDayDetail>> QueryOaWageDriverDayDetailList(string server_id, SalaryListRequest request, string v)
        {
            var exp = await GetExp(request);
            return await ExtensionList(server_id, request.ToExp(exp), v, request.orderby);
        }

        public async Task<bool> BatchDelete(string server_id, List<decimal> context)
        {
            var list = await _dataImp.List(server_id, it => SqlFunc.ContainsArray(context, it.id));
            return await _dataImp.Deletetable(server_id, list);
        }

        private async Task<List<Expression<Func<OaWageDriverDayDetail, bool>>>> GetExp(SalaryListRequest request)
        {
            var r = new List<Expression<Func<OaWageDriverDayDetail, bool>>>();
            if (request.driver_id != null && request.driver_id.Count > 0)
            {
                var dayinfos = await _iOaWageDriverDayDataImp.List(request.server_id, it => SqlFunc.ContainsArray(request.driver_id, it.driver_id), new string[] { "I_ID" });
                if (dayinfos.Count > 0)
                {
                    r.Add(it => SqlFunc.ContainsArray(dayinfos.Select(it => it.id).ToList(), it.main_id));
                }
                else
                {
                    r.Add(it => false);
                }
            }
            if (!string.IsNullOrEmpty(request.date))
            {
                var begin = Convert.ToDateTime(request.date + "-01");
                var end = begin.AddMonths(1);
                var dayinfos = await _iOaWageDriverDayDataImp.List(request.server_id, it => it.wage_date >= begin && it.wage_date < end, new string[] { "I_ID" });
                if (dayinfos.Count > 0)
                {
                    r.Add(it => SqlFunc.ContainsArray(dayinfos.Select(it => it.id).ToList(), it.main_id));
                }
                else
                {
                    r.Add(it => false);
                }
            }
            // 线路树节点id(部门id/线路id)
            if (request.tree_id != null)
            {
                if (await _iSysDepartmentDataImp.IsExist(request.server_id, it => it.i_id == request.tree_id))
                {
                    // 查找部门下的所有线路
                    using (var db = SqlSugarHelper.DBClient(request.server_id))
                    {
                        var orgs = db.Ado.SqlQuery<SysDepPerson>($@"
                            select * 
                            from sys_dep_person 
                            where i_child_id <= 2000000 
                            start with i_child_id = @i_child_id 
                            connect by prior i_child_id = i_group_id", new { i_child_id = request.tree_id });
                        if (orgs.Count > 0)
                        {
                            var orgIds = orgs.Select(it => it.i_child_id).ToList();
                            var depLines = db.Queryable<SysDepLine>().Where(it => SqlFunc.ContainsArray(orgIds, it.i_department_id)).ToList();
                            if (depLines.Count > 0)
                            {
                                var lineIds = depLines.Select(it => it.i_line_id).Distinct().ToList();
                                r.Add(it => SqlFunc.ContainsArray(lineIds, it.line_id));
                            }
                            else
                            {
                                r.Add(it => false);
                            }

                        }
                        else
                        {
                            r.Add(it => false);
                        }

                    }
                }
                else
                {
                    r.Add(it => it.line_id == request.tree_id);
                }
            }
            return r;
        }

        /// <summary>
        /// 分页查询工资详情
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="request"></param>
        /// <param name="v"></param>
        /// <returns></returns>
        public async Task<(List<OaWageDriverDayDetail>, int, Dictionary<string, object>)> QuerySalaryDetailPage(string server_id, SalaryListRequest request, string where)
        {
            var exp = await GetExp(request);
            var list = await ExtensionList(request.server_id, request.ToExp(exp), "", request.orderby);
            list = list.OrderBy(x => x.ex_wage_date).ToList();
            var dics = new Dictionary<string, object>();
            dics.Add("ex_day_base", list.Sum(it => it.ex_day_base));
            dics.Add("ex_synthesize", list.Sum(it => it.ex_synthesize));
            dics.Add("ex_meals", list.Sum(it => it.ex_meals));
            dics.Add("ex_overtime", list.Sum(it => it.ex_overtime));
            dics.Add("ex_quality_check", list.Sum(it => it.ex_quality_check));
            dics.Add("ex_safe_mile", list.Sum(it => it.ex_safe_mile));
            dics.Add("ex_line_check", list.Sum(it => it.ex_line_check));
            dics.Add("ex_leave", list.Sum(it => it.ex_leave));
            dics.Add("ex_ls_leave", list.Sum(it => it.ex_ls_leave));
            dics.Add("ex_actual", list.Sum(it => it.ex_actual));
            dics.Add("ex_total", list.Sum(it => it.ex_total));
            return (list.Skip((request.page_index - 1) * request.page_size).Take(request.page_size).ToList(), list.Count, dics);
        }

        public async Task<(List<OaWageDriverDayDetail>, Dictionary<string, object>)> QuerySalaryDetail(string server_id, SalaryListRequest request, string v)
        {
            var exp = await GetExp(request);
            var list = await ExtensionList(request.server_id, request.ToExp(exp), "", request.orderby);
            list = list.OrderBy(x => x.ex_wage_date).ToList();
            var dics = new Dictionary<string, object>();
            dics.Add("ex_day_base", list.Sum(it => it.ex_day_base));
            dics.Add("ex_synthesize", list.Sum(it => it.ex_synthesize));
            dics.Add("ex_meals", list.Sum(it => it.ex_meals));
            dics.Add("ex_overtime", list.Sum(it => it.ex_overtime));
            dics.Add("ex_quality_check", list.Sum(it => it.ex_quality_check));
            dics.Add("ex_safe_mile", list.Sum(it => it.ex_safe_mile));
            dics.Add("ex_line_check", list.Sum(it => it.ex_line_check));
            dics.Add("ex_leave", list.Sum(it => it.ex_leave));
            dics.Add("ex_ls_leave", list.Sum(it => it.ex_ls_leave));
            dics.Add("ex_actual", list.Sum(it => it.ex_actual));
            dics.Add("ex_total", list.Sum(it => it.ex_total));
            return (list, dics);
        }

        public async Task<(List<SalayDailyQueryByEmpDto>, int, Dictionary<string, object>)> QuerySalaryByEmpPage(string server_id, SalaryListRequest request, string v)
        {
            var list = new List<SalayDailyQueryByEmpDto>();
            var dics = new Dictionary<string, object>();
            RefAsync<int> total = 0;
            GetExp(server_id, request);

            using (var db = SqlSugarHelper.DBClient(server_id))
            {
                list = await db.Queryable<OaWageDriverDay>()
                                .LeftJoin<OaWageDriverDayDetail>((x, y) => x.id == y.main_id)
                               .Where(request.ToExp())
                               .WhereIF(request.line_ids != null && request.line_ids.Count > 0, (x, y) => request.line_ids.Contains(y.line_id.Value))
                               .GroupBy(x => x.driver_id)
                               .OrderBy(x => x.driver_id)
                               .Select(x => new SalayDailyQueryByEmpDto
                               {
                                   driver_id = x.driver_id,
                                   totla_day = SqlFunc.AggregateCount(x.driver_id),
                                   total_day_base = SqlFunc.AggregateSum(x.day_base),
                                   total_synthesize = SqlFunc.AggregateSum(x.synthesize),
                                   total_meals = SqlFunc.AggregateSum(x.meals),
                                   total_overtime = SqlFunc.AggregateSum(x.overtime),
                                   total_quality_check = SqlFunc.AggregateSum(x.quality_check),
                                   total_safe_mile = SqlFunc.AggregateSum(x.safe_mile),
                                   total_line_check = SqlFunc.AggregateSum(x.line_check),
                                   total_leave = SqlFunc.AggregateSum(x.leave),
                                   ls_leave = SqlFunc.AggregateSum(x.ls_leave),
                                   deducted_fee = SqlFunc.AggregateSum(x.deducted_fee),
                                   top_day = SqlFunc.AggregateSum(x.big_class),
                                   small_day = SqlFunc.AggregateSum(x.small_class),
                               }).ToPageListAsync(request.page_index, request.page_size, total);

                foreach (var info in list)
                {
                    info.driver_name = await _userRedisImp.GetNameByIdAsync(info.driver_id.ToString());
                }
            }
            dics = await GetTotal(server_id, request, v);
            return (list, total, dics);
        }

        public async Task<Dictionary<string, object>> GetTotal(string server_id, SalaryListRequest request, string v)
        {
            var dics = new Dictionary<string, object>();
            using (var db = SqlSugarHelper.DBClient(server_id))
            {
                var list = await db.Queryable<OaWageDriverDay>()
                         .Where(request.ToExp())
                         .Select(it => new SalayDailyQueryByEmpDto
                         {
                             totla_day = SqlFunc.AggregateCount(it.driver_id),
                             total_day_base = SqlFunc.AggregateSum(it.day_base),
                             total_synthesize = SqlFunc.AggregateSum(it.synthesize),
                             total_meals = SqlFunc.AggregateSum(it.meals),
                             total_overtime = SqlFunc.AggregateSum(it.overtime),
                             total_quality_check = SqlFunc.AggregateSum(it.quality_check),
                             total_safe_mile = SqlFunc.AggregateSum(it.safe_mile),
                             total_line_check = SqlFunc.AggregateSum(it.line_check),
                             total_leave = SqlFunc.AggregateSum(it.leave),
                             ls_leave = SqlFunc.AggregateSum(it.ls_leave),
                             deducted_fee = SqlFunc.AggregateSum(it.deducted_fee)
                         })
                         .ToDictionaryListAsync();
                if (list.Count > 0)
                {
                    dics = list.FirstOrDefault();
                }
            }
            return dics;
        }

        public async Task<(List<SalayDailyQueryByEmpDto>, Dictionary<string, object>)> QuerySalaryByEmp(string server_id, SalaryListRequest request, string v)
        {
            var exp = await GetExp(request);
            var originList = await ExtensionList(request.server_id, request.ToExp(exp), "", request.orderby);

            // 获取所有线路的请假班次规则
            var settings = await _iOaWageSettingDataImp.List(request.server_id, it => it.type == 5);

            var list = originList.GroupBy(it => new { it.ex_driver_id, it.ex_driver_name, it.type }).Select(it => new SalayDailyQueryByEmpDto
            {
                driver_id = it.Key.ex_driver_id,
                driver_name = it.Key.ex_driver_name,
                totla_day = it.Count(),
                total_day_base = it.Sum(c => c.ex_day_base),
                total_synthesize = it.Sum(c => c.ex_synthesize),
                total_meals = it.Sum(c => c.ex_meals),
                total_overtime = it.Sum(c => c.ex_overtime),
                total_quality_check = it.Sum(c => c.ex_quality_check),
                total_safe_mile = it.Sum(c => c.ex_safe_mile),
                total_line_check = it.Sum(c => c.ex_line_check),
                total_leave = it.Sum(c => c.ex_leave),
                ls_leave = it.Sum(c => c.ex_ls_leave),
                deducted_fee = it.Sum(c => c.ex_deducted_fee),
                type_count = it.Count(),
                type_sum = it.Sum(it => it.type),

            }).ToList();
            var dics = new Dictionary<string, object>();
            dics.Add("totla_day", list.Sum(it => it.totla_day));
            dics.Add("total_day_base", list.Sum(it => it.total_day_base));
            dics.Add("total_synthesize", list.Sum(it => it.total_synthesize));
            dics.Add("total_meals", list.Sum(it => it.total_meals));
            dics.Add("total_overtime", list.Sum(it => it.total_overtime));
            dics.Add("total_quality_check", list.Sum(it => it.total_quality_check));
            dics.Add("total_safe_mile", list.Sum(it => it.total_safe_mile));
            dics.Add("total_line_check", list.Sum(it => it.total_line_check));
            dics.Add("total_leave", list.Sum(it => it.total_leave));
            dics.Add("ls_leave", list.Sum(it => it.ls_leave));
            dics.Add("deducted_fee", list.Sum(it => it.deducted_fee));
            dics.Add("top_day", list.Sum(it => it.top_day));
            dics.Add("small_day", list.Sum(it => it.small_day));
            dics.Add("total_actual", list.Sum(it => it.total_actual));
            dics.Add("total_total", list.Sum(it => it.total));
            return (list, dics);
        }

        private void GetExp(string server_id, SalaryListRequest request)
        {
            using (var db = SqlSugarHelper.DBClient(server_id))
            {
                // 线路树节点id(部门id/线路id)
                if (request.tree_id != null)
                {
                    // 查找部门下的所有线路
                    var orgs = db.Ado.SqlQuery<SysDepPerson>($@"
                        select * from sys_dep_person where i_child_id <= 2000000 
                            start with i_child_id = @i_child_id 
                            connect by prior i_child_id = i_group_id", new { i_child_id = request.tree_id });
                    if (orgs != null && orgs.Count > 0) //部门节点
                    {
                        var orgIds = orgs.Select(it => it.i_child_id).ToList();
                        var lineIds = db.Queryable<SysDepLine>().
                                        Where(it => SqlFunc.ContainsArray(orgIds, it.i_department_id))
                                        .Select(x => x.i_line_id).Distinct()
                                        .ToList();
                        request.line_ids.AddRange(lineIds);
                    }
                    else
                    {
                        request.line_ids.Add(request.tree_id.Value);
                    }
                }
                //if (request.line_ids != null && request.line_ids.Count > 0)
                //{
                //    var ids = db.Queryable<OaWageDriverDayDetail>()
                //                        .Where(x => request.line_ids.Contains(x.line_id.Value))
                //                        .Select(x => x.main_id)
                //                        .Distinct()
                //                        .ToList();
                //    request.ids = ids.Skip((request.page_index - 1) * request.page_size).Take(request.page_size).ToList();
                //    return ids.Count;
                //}
            }
        }
    }
}