﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPModel.ApiModel.PersonalManage;
using ERPModel.PersonalManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.PersonalManage
{
    public interface IOaAttendanceRecordImp : IBusinessRepository<OaAttendanceRecord>
    {
        Task<bool> AddOaAttendanceRecord(string server_id, List<OaAttendanceRecord> context, ClientInformation client);
        Task<Tuple<List<OaAttendanceRecord>, int>> QueryOaAttendanceRecordPageList(string server_id, BaseRequest<OaAttendanceRecord> request, string v);
        Task<List<OaAttendanceRecord>> QueryOaAttendanceRecordList(string server_id, BaseRequest<OaAttendanceRecord> request, string v);
        Task<bool> BatchDelete(string server_id, List<decimal> context);
        Task<Tuple<List<AttendanceStatisticsResponse>, int>> AttendanceStatistics(AttendanceStatisticsRequest request);
        Task<List<AttendanceStatisticsDetailResponse>> AttendanceStatisticsDetail(string server_id, decimal user_id, List<DateTime> date, int? type, int? type_child);
        Task<AttendanceStatisticsSummaryDetailResponse> AttendanceDetail(AttendanceStatisticsRequest request);

        Task<List<AttendanceDetailResponse>> AttendanceDetailById(string server_id, decimal id);
    }
}