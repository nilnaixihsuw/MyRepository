﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPDal.PersonalManage;
using ERPModel.PersonalManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using System.Linq.Expressions;
using ERPModel.OAManage;

namespace ERPBll.PersonalManage
{
    public class OaRestMainImp : BusinessRespository<OaRestMain, IOaRestMainDataImp>, IOaRestMainImp
    {
        public OaRestMainImp(IOaRestMainDataImp dataImp): base(dataImp)
        {

        }

        public async Task<bool> AddOaRestMain(string server_id, OaRestMain context, ClientInformation client)
        {
            if (context.id > 0)
            {
                var old = await _dataImp.Get(server_id, context.id);
                context.created_id = old.created_id;
                context.created_date = old.created_date;
                context.update_date = DateTime.Now;
                context.update_id = client.i_id;
                return await _dataImp.Update(server_id, context);
            }
            else
            {
                context.created_date = DateTime.Now;
                context.created_id = client.i_id;
                return await _dataImp.Insert(server_id, context);
            }
        }

        public async Task<Tuple<List<OaRestMain>,int>> QueryOaRestMainPageList(string server_id, BaseRequest<OaRestMain> request, string v)
        {
            var exp = await GetExp(request);
            return await ExtensionList(server_id, request.ToExp(exp), v, request.page_size, request.page_index, request.orderby);
        }

        public async Task<List<OaRestMain>> QueryOaRestMainList(string server_id, BaseRequest<OaRestMain> request, string v)
        {
            var exp = await GetExp(request);
            return await ExtensionList(server_id, request.ToExp(exp), v, request.orderby);
        }

        public async Task<bool> BatchDelete(string server_id, List<decimal> context)
        {
            var list = await _dataImp.List(server_id, it => SqlFunc.ContainsArray(context, it.id));
            return await _dataImp.Deletetable(server_id, list);
        }

        private async Task<List<Expression<Func<OaRestMain, bool>>>> GetExp(BaseRequest<OaRestMain> request)
        {
            var r = new List<Expression<Func<OaRestMain, bool>>>();
            
            return r;
        }
    }
}