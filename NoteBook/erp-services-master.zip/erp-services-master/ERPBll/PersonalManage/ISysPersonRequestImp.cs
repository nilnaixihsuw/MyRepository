﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPModel.ApiModel;
using ERPModel.ApiModel.SafeManage;
using ERPModel.PersonalManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.PersonalManage
{
    public interface ISysPersonRequestImp : IBusinessRepository<SysPersonRequest>
    {
        Task<bool> AddSysPersonRequest(string server_id, SysPersonRequest context, ClientInformation client);
        Task<Tuple<List<SysPersonRequest>,int>> QuerySysPersonRequestPageList(string server_id, SysPersonRequestRequest request, string v, ClientInformation client);
        Task<List<SysPersonRequest>> QuerySysPersonRequestList(string server_id, SysPersonRequestRequest request, string v, ClientInformation client);
        Task<bool> BatchDelete(string server_id, List<decimal> context);
        Task<SysPersonRequest> Detail(string server_id, decimal id, ClientInformation client);
        Task<bool> BatchDisabled(string server_id, List<decimal> context);
    }
}