﻿using ERPDal.Repository;
using ERPModel.PersonalManage.AttentSetting;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.PersonalManage.AttentSetting
{
    public interface IOaJbgzImp : IBaseBusiness<OaJbgz>
    {
        /// <summary>
        /// 获取加班规则
        /// </summary>
        /// <param name="server_id"></param>
        /// <returns></returns>
        Task<List<OaJbgz>> GetRules(string server_id);
        /// <summary>
        /// 获取指定人员加班规则
        /// </summary>
        /// <param name="user_id"></param>
        /// <param name="server_id"></param>
        /// <returns></returns>
        Task<OaJbgz> GetUserRule(decimal user_id, string server_id);
    }
}
