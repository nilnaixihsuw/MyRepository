﻿using ERPDal.Repository;
using ERPModel.PersonalManage.AttentSetting;
using System;
using System.Collections.Generic;
using System.Text;

namespace ERPBll.PersonalManage.AttentSetting
{
    public interface IOaJbgzTypeImp : IBaseBusiness<OaJbgzType>
    {

    }
}
