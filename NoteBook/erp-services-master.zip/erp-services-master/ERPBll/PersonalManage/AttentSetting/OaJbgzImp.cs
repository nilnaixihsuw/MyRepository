﻿using ERPDal;
using ERPDal.Repository;
using ERPModel.ApprovalForm;
using ERPModel.Oamanage.OaKqbcs;
using ERPModel.Oamanage.OaKqzs;
using ERPModel.PersonalManage.AttentSetting;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.PersonalManage.AttentSetting
{
    public class OaJbgzImp : BaseBusiness<OaJbgz>, IOaJbgzImp
    {
        public async Task<List<OaJbgz>> GetRules(string server_id)
        {
            var DB = SqlSugarHelper.DBClient(server_id);
            var rules = await DB.Queryable<OaJbgz>()
                .Mapper(async r => r.groups = await DB.Queryable<OaKqz>()
                    .Where(m => m.overtime_id == r.id && m.is_delete == 0).ToListAsync())
                .Includes(r => r.types, r => r.fees)
                .ToListAsync();
            rules.ForEach(r =>
            {
                r.types = r.types.OrderBy(m => m.type).ToList();
                r.types.ForEach(m => m.fees = m.fees.OrderBy(n => n.id).ToList());
            });
            return rules;
        }

        public async Task<OaJbgz> GetUserRule(decimal user_id, string server_id)
        {
            using var DB = SqlSugarHelper.DBClient(server_id);
            var group = await DB.Queryable<OaKqz, OaKqzUser>((a, b) => new JoinQueryInfos(JoinType.Left, a.id == b.kqz_id))
                .Where((a, b) => b.user_id == user_id && a.is_delete == 0).FirstAsync();
            if (group != null)
            {
                var rule = await DB.Queryable<OaJbgz>()
                    .Where(r => r.id == group.overtime_id)
                    .Mapper(async r => r.groups = await DB.Queryable<OaKqz>()
                        .Where(m => m.overtime_id == r.id && m.is_delete == 0).ToListAsync())
                    .Includes(r => r.types, r => r.fees)
                    .FirstAsync();

                if (rule != null)
                {
                    rule.types = rule.types.OrderBy(m => m.type).ToList();
                    rule.types.ForEach(m => m.fees = m.fees.OrderBy(n => n.id).ToList());

                    var records = await DB.Queryable<OaWorkOvertime>().Where(r => r.user_id == user_id).ToListAsync();
                    rule.jb_fee = Math.Round(records.Sum(r => r.fee.Value), 2);
                }
                return rule;
            }
            else
            {
                return default;
            }
        }
    }
}
