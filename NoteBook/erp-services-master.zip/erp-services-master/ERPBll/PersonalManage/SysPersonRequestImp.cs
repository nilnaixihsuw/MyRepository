﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPDal.PersonalManage;
using ERPModel.PersonalManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using System.Linq.Expressions;
using ERPModel.ApiModel;
using AutoMapper;
using ERPCore.Attributes;
using System.Reflection;
using ERPDal;
using ERPModel.UserManage;
using ERPBll.FlowManage.Contracts;
using ERPModel.FlowManage.FlowRecords;
using ERPModel.ApiModel.SafeManage;
using ERPModel.FlowManage.ErpFlowChecks;
using ERPModel.FlowManage;
using ERPBll.SystemManage;
using ERPModel.SystemManage;
using ERPCore.Enums;

namespace ERPBll.PersonalManage
{
    public class SysPersonRequestImp : BusinessRespository<SysPersonRequest, ISysPersonRequestDataImp>, ISysPersonRequestImp
    {
        private readonly IMapper _imapper;
        private readonly IErpFlowRecordImp _iErpFlowRecordImp;
        private readonly ISysFileRecordImp _iSysFileRecordImp;

        public SysPersonRequestImp(
            ISysFileRecordImp iSysFileRecordImp,
            IErpFlowRecordImp iErpFlowRecordImp,
            IMapper iMapper,
            ISysPersonRequestDataImp dataImp) : base(dataImp)
        {
            _iSysFileRecordImp = iSysFileRecordImp;
            _imapper = iMapper;
            _iErpFlowRecordImp = iErpFlowRecordImp;
        }

        public async Task<bool> AddSysPersonRequest(string server_id, SysPersonRequest context, ClientInformation client)
        {
            context.i_position_id = 0;
            context.i_is_driver = 1;
            var datas = new List<SysFileRecord>();
            if (context.i_id != null && context.i_id > 0)
            {
                var old = await _dataImp.Get(server_id, context.i_id);
                context.i_created_id = old.i_created_id;
                context.d_created_date = old.d_created_date;
                context.i_state = old.i_state;

                //体检单
                if (context.tjd_data != null && context.tjd_data.Count() > 0)
                {
                    datas.AddRange(context.tjd_data.Select(it => new SysFileRecord
                    {
                        model = (int)FileRecordType.HEALTHREPORT,
                        object_id = context.i_id,
                        type = 1,
                        url = it,
                        created_id = client.i_id,
                        created_date = DateTime.Now
                    }).ToList());
                }
                //核酸检测
                if (context.hsbg_data != null && context.hsbg_data.Count() > 0)
                {
                    datas.AddRange(context.hsbg_data.Select(it => new SysFileRecord
                    {
                        model = (int)FileRecordType.ACIDTEST,
                        object_id = context.i_id,
                        type = 1,
                        url = it,
                        created_id = client.i_id,
                        created_date = DateTime.Now
                    }).ToList());
                }
                //派出所证明
                if (context.pcszm_data != null && context.pcszm_data.Count() > 0)
                {
                    datas.AddRange(context.pcszm_data.Select(it => new SysFileRecord
                    {
                        model = (int)FileRecordType.PCSEVIDENCE,
                        object_id = context.i_id,
                        type = 1,
                        url = it,
                        created_id = client.i_id,
                        created_date = DateTime.Now
                    }).ToList());
                }
                //毛发检测
                if (context.mfjc_data != null && context.mfjc_data.Count() > 0)
                {
                    datas.AddRange(context.mfjc_data.Select(it => new SysFileRecord
                    {
                        model = (int)FileRecordType.CURLTEST,
                        object_id = context.i_id,
                        type = 1,
                        url = it,
                        created_id = client.i_id,
                        created_date = DateTime.Now
                    }).ToList());
                }

                if (context.i_flow_id != null && context.is_start_flow && (context.i_state == 1 || context.i_state == 4 || context.i_state == 5))
                {
                    context.i_created_id = client.i_id;
                    context.d_created_date = DateTime.Now;

                    context.i_state = 2;
                    await _iErpFlowRecordImp.UpdateAsync(server_id, Convert.ToInt32(context.i_flow_id), Convert.ToInt32(context.i_id), "");
                }

                var res = await _dataImp.UpdateSysPersonRequest(server_id, context, datas);
                return res;
            }
            else
            {
                //新增
                context.i_id = await _dataImp.GetId(server_id, "SEQ_COMMON");
                context.i_state = 1;
                context.i_created_id = client.i_id;
                context.d_created_date = DateTime.Now;

                if (context.i_flow_id != null && context.is_start_flow && (context.i_state == 1 || context.i_state == 4 || context.i_state == 5))
                {
                    context.i_state = 2;
                    await _iErpFlowRecordImp.UpdateAsync(server_id, Convert.ToInt32(context.i_flow_id), Convert.ToInt32(context.i_id), "");
                }

                //体检单
                if (context.tjd_data != null && context.tjd_data.Count() > 0)
                {
                    datas.AddRange(context.tjd_data.Select(it => new SysFileRecord
                    {
                        model = (int)FileRecordType.HEALTHREPORT,
                        object_id = context.i_id,
                        type = 1,
                        url = it,
                        created_id = client.i_id,
                        created_date = DateTime.Now
                    }).ToList());
                }
                //核酸检测
                if (context.hsbg_data != null && context.hsbg_data.Count() > 0)
                {
                    datas.AddRange(context.hsbg_data.Select(it => new SysFileRecord
                    {
                        model = (int)FileRecordType.ACIDTEST,
                        object_id = context.i_id,
                        type = 1,
                        url = it,
                        created_id = client.i_id,
                        created_date = DateTime.Now
                    }).ToList());
                }
                //派出所证明
                if (context.pcszm_data != null && context.pcszm_data.Count() > 0)
                {
                    datas.AddRange(context.pcszm_data.Select(it => new SysFileRecord
                    {
                        model = (int)FileRecordType.PCSEVIDENCE,
                        object_id = context.i_id,
                        type = 1,
                        url = it,
                        created_id = client.i_id,
                        created_date = DateTime.Now
                    }).ToList());
                }
                //毛发检测
                if (context.mfjc_data != null && context.mfjc_data.Count() > 0)
                {
                    datas.AddRange(context.mfjc_data.Select(it => new SysFileRecord
                    {
                        model = (int)FileRecordType.CURLTEST,
                        object_id = context.i_id,
                        type = 1,
                        url = it,
                        created_id = client.i_id,
                        created_date = DateTime.Now
                    }).ToList());
                }

                return await _dataImp.InsertSysPersonRequest(server_id, context, datas);
            }
        }

        public async Task<Tuple<List<SysPersonRequest>, int>> QuerySysPersonRequestPageList(string server_id, SysPersonRequestRequest request, string v, ClientInformation client)
        {
            var exp = await GetExp(request, client);
            RefAsync<int> total = 0;
            var q = await SqlSugarHelper.DBClient(server_id).Queryable<SysPersonRequest>()
                                                            .WhereIF(request.ToExp(exp) != null, request.ToExp(exp))
                                                            .WhereIF(!string.IsNullOrEmpty(v), v)
                                                            .OrderByIF(!string.IsNullOrEmpty(request.orderby), request.orderby)
                                                            .ToPageListAsync(request.page_index, request.page_size, total);
            var list = await _dataImp.ExtList(server_id, q);
            if (list.Count > 0)
            {
                var all = await _iErpFlowRecordImp.GetListAsync(server_id, client.i_id,
                   new FlowRecordQuery()
                   {
                       detail_ids = list.Select(x => (int)x.i_id).ToList()
                   }
                );
                foreach (var item in list)
                {
                    if (item.i_state == 2)//处理中
                    {
                        var info = all.FirstOrDefault(x => x.detail_id == item.i_id);
                        if (info != null)
                        {
                            item.user_ids = info.state_child_id;
                            item.user_names = info.state_child_name;
                            if (item.i_flow_id != null && item.user_ids.Contains(client.i_id.Value))
                            {
                                item.ex_can_dispose = 1;
                            }
                            if (item.i_flow_id != null && info.created_id == client.i_id)
                            {
                                item.ex_can_cancel = 1;
                            }
                        }

                    }
                }
            }
            return new Tuple<List<SysPersonRequest>, int>(list, total);
        }

        public async Task<List<SysPersonRequest>> QuerySysPersonRequestList(string server_id, SysPersonRequestRequest request, string v, ClientInformation client)
        {
            var exp = await GetExp(request, client);
            var q = await SqlSugarHelper.DBClient(server_id).Queryable<SysPersonRequest>()
                                                          .WhereIF(request.ToExp(exp) != null, request.ToExp(exp))
                                                          .WhereIF(!string.IsNullOrEmpty(v), v)
                                                          .OrderByIF(!string.IsNullOrEmpty(request.orderby), request.orderby)
                                                          .ToListAsync();
            var list = await _dataImp.ExtList(server_id, q);
            if (list.Count > 0)
            {
                var all = await _iErpFlowRecordImp.GetListAsync(server_id, client.i_id,
                    new FlowRecordQuery()
                    {
                        detail_ids = list.Select(x => (int)x.i_id).ToList()
                    }
                );
                foreach (var item in list)
                {
                    if (item.i_state == 2)//处理中
                    {
                        var info = all.FirstOrDefault(x => x.detail_id == item.i_id);
                        if (info != null)
                        {
                            item.user_ids = info.state_child_id;
                            item.user_names = info.state_child_name;
                            if (item.i_flow_id != null && item.user_ids.Contains(client.i_id.Value))
                            {
                                item.ex_can_dispose = 1;
                                item.ex_can_cancel = 1;
                            }
                        }
                    }
                }
            }

            return list;
        }

        public async Task<bool> BatchDelete(string server_id, List<decimal> context)
        {
            var list = await _dataImp.List(server_id, it => SqlFunc.ContainsArray(context, it.i_id));
            return await _dataImp.Deletetable(server_id, list);
        }

        private async Task<List<Expression<Func<SysPersonRequest, bool>>>> GetExp(SysPersonRequestRequest request, ClientInformation client)
        {
            var r = new List<Expression<Func<SysPersonRequest, bool>>>();
            //全部1， 待我处理2， 我已处理3， 我发起的4
            if (request.state != null)
            {
                if (request.state == 2)
                {
                    var db = SqlSugarHelper.DBClient(request.server_id);
                    var todoIds = db.Queryable<ErpFlowCheck, ErpFlowRecord>((a, b) => new JoinQueryInfos(JoinType.Left, a.flow_id == b.id))
                                   .Where((a, b) => a.state == 0 && a.check_id == client.i_id && b.object_id == (int)FlowRecordType.驾驶员入职申请)
                                   .Select((a, b) => b.detail_id)
                                   .ToList();
                    r.Add(it => SqlFunc.ContainsArray(todoIds, it.i_id));
                }
                if (request.state == 3)
                {
                    var db = SqlSugarHelper.DBClient(request.server_id);
                    var todoIds = db.Queryable<ErpFlowCheck, ErpFlowRecord>((a, b) => new JoinQueryInfos(JoinType.Left, a.flow_id == b.id))
                                   .Where((a, b) => a.state != 0 && a.check_id == client.i_id && b.object_id == (int)FlowRecordType.驾驶员入职申请)
                                   .Select((a, b) => b.detail_id)
                                   .ToList();
                    r.Add(it => SqlFunc.ContainsArray(todoIds, it.i_id));
                }
                if (request.state == 4)
                {
                    var db = SqlSugarHelper.DBClient(request.server_id);
                    var todoIds = db.Queryable<ErpFlowCheck, ErpFlowRecord>((a, b) => new JoinQueryInfos(JoinType.Left, a.flow_id == b.id))
                                   .Where((a, b) => b.created_id == client.i_id && b.object_id == (int)FlowRecordType.驾驶员入职申请)
                                   .Select((a, b) => b.detail_id)
                                   .ToList();
                    r.Add(it => SqlFunc.ContainsArray(todoIds, it.i_id) && it.i_created_id == client.i_id);
                }
            }

            //1未发起处理2处理中3处理完成4已驳回5已作废 6待我处理 7.我已处理
            if (request.dispose_condition != null)
            {
                if (request.dispose_condition >= 6)
                {
                    // 待我处理
                    if (request.dispose_condition == 6)
                    {
                        var db = SqlSugarHelper.DBClient(request.server_id);
                        var todoIds = db.Queryable<ErpFlowCheck, ErpFlowRecord>((a, b) => new JoinQueryInfos(JoinType.Left, a.flow_id == b.id))
                                       .Where((a, b) => a.state == 0 && a.check_id == client.i_id && b.object_id == (int)FlowRecordType.驾驶员入职申请)
                                       .Select((a, b) => b.detail_id)
                                       .ToList();
                        r.Add(it => it.i_state == 2 && SqlFunc.ContainsArray(todoIds, it.i_id));
                    }
                    // 我已处理
                    if (request.dispose_condition == 7)
                    {
                        var db = SqlSugarHelper.DBClient(request.server_id);
                        var todoIds = db.Queryable<ErpFlowCheck, ErpFlowRecord>((a, b) => new JoinQueryInfos(JoinType.Left, a.flow_id == b.id))
                                       .Where((a, b) => a.state != 0 && a.check_id == client.i_id && b.object_id == (int)FlowRecordType.驾驶员入职申请)
                                       .Select((a, b) => b.detail_id)
                                       .ToList();
                        r.Add(it => it.i_state != 1 && it.i_state != 2 && SqlFunc.ContainsArray(todoIds, it.i_id));
                    }
                }
                else
                {
                    r.Add(it => it.i_state == request.dispose_condition);
                }

            }

            return r;
        }

        public async Task<SysPersonRequest> Detail(string server_id, decimal id, ClientInformation client)
        {
            var r = new SysPersonRequest();
            var list = await List(server_id, it => it.i_id == id);
            if (list.Count > 0)
            {
                var all = await _iErpFlowRecordImp.GetListAsync(server_id, client.i_id,
                   new FlowRecordQuery()
                   {
                       detail_ids = list.Select(x => (int)x.i_id).ToList()
                   }
                );
                foreach (var item in list)
                {
                    if (item.i_state == 2)//处理中
                    {
                        var info = all.FirstOrDefault(x => x.detail_id == item.i_id);
                        if (info != null)
                        {
                            item.user_ids = info.state_child_id;
                            item.user_names = info.state_child_name;
                            if (item.i_flow_id != null && item.user_ids.Contains(client.i_id.Value))
                            {
                                item.ex_can_dispose = 1;
                            }
                            if (item.i_flow_id != null && info.created_id == client.i_id)
                            {
                                item.ex_can_cancel = 1;
                            }
                        }

                    }
                }
            }
            if (list.Count > 0)
            {
                r = list.FirstOrDefault();
            }
            return r;
        }

        public async Task<bool> BatchDisabled(string server_id, List<decimal> context)
        {
            var list = await _dataImp.List(server_id, it => SqlFunc.ContainsArray(context, it.i_id));
            list.ForEach(x =>
            {
                x.i_state = 5;
            });
            return await _dataImp.Updatetable(server_id, list);
        }
    }
}