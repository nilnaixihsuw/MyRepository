﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPDal.PersonalManage;
using ERPModel.PersonalManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using System.Linq.Expressions;
using ERPModel.ApiModel.PersonalManage;
using ERPDal;
using ERPModel.UserManage;
using ERPBll.RedisManage.Users;

namespace ERPBll.PersonalManage
{
    public class OaWageDriverDayImp : BusinessRespository<OaWageDriverDay, IOaWageDriverDayDataImp>, IOaWageDriverDayImp
    {
        private readonly IUserRedisImp _iUserRedisImp;
        public OaWageDriverDayImp(
            IUserRedisImp iUserRedisImp,
            IOaWageDriverDayDataImp dataImp) : base(dataImp)
        {
            _iUserRedisImp = iUserRedisImp;
        }

        public async Task<bool> AddOaWageDriverDay(string server_id, OaWageDriverDay context, ClientInformation client)
        {
            if (context.id > 0)
            {
                var old = await _dataImp.Get(server_id, context.id);
                context.created_id = old.created_id;
                context.created_date = old.created_date;
                context.update_date = DateTime.Now;
                context.update_id = client.i_id;
                return await _dataImp.Update(server_id, context);
            }
            else
            {
                context.created_date = DateTime.Now;
                context.created_id = client.i_id;
                return await _dataImp.Insert(server_id, context);
            }
        }

        public async Task<Tuple<List<OaWageDriverDay>, int>> QueryOaWageDriverDayPageList(string server_id, BaseRequest<OaWageDriverDay> request, string v)
        {
            var exp = await GetExp(request);
            return await ExtensionList(server_id, request.ToExp(exp), v, request.page_size, request.page_index, request.orderby);
        }

        public async Task<List<OaWageDriverDay>> QueryOaWageDriverDayList(string server_id, BaseRequest<OaWageDriverDay> request, string v)
        {
            var exp = await GetExp(request);
            return await ExtensionList(server_id, request.ToExp(exp), v, request.orderby);
        }

        public async Task<bool> BatchDelete(string server_id, List<decimal> context)
        {
            var list = await _dataImp.List(server_id, it => SqlFunc.ContainsArray(context, it.id));
            return await _dataImp.Deletetable(server_id, list);
        }

        private async Task<List<Expression<Func<OaWageDriverDay, bool>>>> GetExp(BaseRequest<OaWageDriverDay> request)
        {
            var r = new List<Expression<Func<OaWageDriverDay, bool>>>();

            return r;
        }

        //// <summary>
        /// 取得某月的最后一天
        /// </summary>
        /// <param name="datetime">要取得月份最后一天的时间</param>
        /// <returns></returns>
        private DateTime LastDayOfMonth(DateTime datetime)
        {
            return datetime.AddDays(1 - datetime.Day).AddMonths(1).AddDays(-1);
        }

        /// <summary>
        /// 添加奖金
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="context"></param>
        /// <param name="client"></param>
        /// <returns></returns>
        public async Task<bool> AddSalary(string server_id, AddSalaryInput context, ClientInformation client)
        {
            var ens = new List<OaWageDriverDay>();
            if (context.fee_details != null && context.fee_details.Count > 0)
            {
                // 当月记录
                var monthlyList = await _dataImp.List(server_id, it => SqlFunc.ContainsArray(context.fee_details.Select(it => it.driver_id).ToList(), it.driver_id) && SqlFunc.Oracle_ToChar(it.wage_date.Value, "yyyy-MM") == context.salary_month);
                foreach (var detail in context.fee_details)
                {
                    // 当月司机记录
                    var driverMonthlyList = monthlyList.Where(it => it.driver_id == detail.driver_id).ToList();
                    if (driverMonthlyList.Count > 0)
                    {
                        // 清除该月原奖金记录
                        context.type.ForEach(t =>
                        {
                            if (t == 1)
                            {
                                var list = driverMonthlyList.Where(it => it.overtime > 0).ToList();
                                list.ForEach(e =>
                                {
                                    e.overtime = 0;
                                });
                                ens.AddRange(list);
                            }
                            if (t == 2)
                            {
                                var list = driverMonthlyList.Where(it => it.quality_check > 0).ToList();
                                list.ForEach(e =>
                                {
                                    e.quality_check = 0;
                                });
                                ens.AddRange(list);
                            }
                            if (t == 3)
                            {
                                var list = driverMonthlyList.Where(it => it.safe_mile > 0).ToList();
                                list.ForEach(e =>
                                {
                                    e.safe_mile = 0;
                                });
                                ens.AddRange(list);
                            }
                            if (t == 4)
                            {
                                var list = driverMonthlyList.Where(it => it.safe_mile > 0).ToList();
                                list.ForEach(e =>
                                {
                                    e.line_check = 0;
                                });
                                ens.AddRange(list);
                            }
                        });

                        // 插入新的奖金记录
                        var e = driverMonthlyList.Find(it => it.wage_date == driverMonthlyList.Max(it => it.wage_date));
                        context.type.ForEach(t =>
                        {
                            if (t == 1)
                            {
                                e.overtime = detail.overtime;
                            }
                            if (t == 2)
                            {
                                e.quality_check = detail.quality_check;
                            }
                            if (t == 3)
                            {
                                e.safe_mile = detail.safe_mile;
                            }
                            if (t == 4)
                            {
                                e.line_check = detail.line_check;
                            }
                        });
                        e.update_date = DateTime.Now;
                        e.update_id = client.i_id;
                        e.remark = context.remark;
                        ens.Add(e);
                    }
                    else
                    {
                        throw new Exception($"该人员{_iUserRedisImp.GetByIdAsync(detail.driver_id.ToString()).Result.c_name}该月系统暂无数据!请勿添加!");
                    }
                }
            }
            else
            {
                throw new Exception("费用详情不能为空!");
            }
            return await _dataImp.Updatetable(server_id, ens);
        }

        /// <summary>
        /// 添加奖金
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="context"></param>
        /// <param name="client"></param>
        /// <returns></returns>
        public async Task<(bool, List<string>)> AddSalaryPre(string server_id, AddSalaryInput context, ClientInformation client)
        {
            var r = false;
            var msgs = new List<string>();
            if (context.fee_details != null && context.fee_details.Count > 0)
            {
                // 当月记录
                var monthlyList = await _dataImp.List(server_id, it => SqlFunc.ContainsArray(context.fee_details.Select(it => it.driver_id).ToList(), it.driver_id) && SqlFunc.Oracle_ToChar(it.wage_date.Value, "yyyy-MM") == context.salary_month);
                foreach (var detail in context.fee_details)
                {
                    var person = await _iUserRedisImp.GetByIdAsync(detail.driver_id.ToString());
                    var driverMonthlyList = monthlyList.Where(it => it.driver_id == detail.driver_id).ToList();
                    if (driverMonthlyList.Count > 0)
                    {
                        context.type.ForEach(t =>
                        {
                            if (t == 1 && driverMonthlyList.Exists(it => it.overtime > 0))
                            {
                                msgs.Add($"{person.c_name}该月份已添加过加班费");
                                r = true;
                            }
                            if (t == 2 && driverMonthlyList.Exists(it => it.quality_check > 0))
                            {
                                msgs.Add($"{person.c_name}该月份已添加过质量考核奖");
                                r = true;
                            }
                            if (t == 3 && driverMonthlyList.Exists(it => it.safe_mile > 0))
                            {
                                msgs.Add($"{person.c_name}该月份已添加过安全里程奖");
                                r = true;
                            }
                            if (t == 4 && driverMonthlyList.Exists(it => it.line_check > 0))
                            {
                                msgs.Add($"{person.c_name}该月份已添加过精品线路考核奖");
                                r = true;
                            }
                        });
                    }
                    else
                    {
                        throw new Exception($"该人员{_iUserRedisImp.GetByIdAsync(detail.driver_id.ToString()).Result.c_name}该月系统暂无数据!请勿添加!");
                    }
                }
            }
            else
            {
                throw new Exception("费用详情不能为空!");
            }
            return await Task.Run(() => (r, msgs));
        }
    }
}