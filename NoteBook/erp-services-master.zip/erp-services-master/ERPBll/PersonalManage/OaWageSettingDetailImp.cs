﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPDal.PersonalManage;
using ERPModel.PersonalManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using System.Linq.Expressions;

namespace ERPBll.PersonalManage
{
    public class OaWageSettingDetailImp : BusinessRespository<OaWageSettingDetail, IOaWageSettingDetailDataImp>, IOaWageSettingDetailImp
    {
        public OaWageSettingDetailImp(IOaWageSettingDetailDataImp dataImp): base(dataImp)
        {

        }

        public async Task<bool> AddOaWageSettingDetail(string server_id, OaWageSettingDetail context, ClientInformation client)
        {
            if (context.id > 0)
            {
                var old = await _dataImp.Get(server_id, context.id);
                return await _dataImp.Update(server_id, context);
            }
            else
            {
                return await _dataImp.Insert(server_id, context);
            }
        }

        public async Task<Tuple<List<OaWageSettingDetail>,int>> QueryOaWageSettingDetailPageList(string server_id, BaseRequest<OaWageSettingDetail> request, string v)
        {
            var exp = await GetExp(request);
            return await ExtensionList(server_id, request.ToExp(exp), v, request.page_size, request.page_index, request.orderby);
        }

        public async Task<List<OaWageSettingDetail>> QueryOaWageSettingDetailList(string server_id, BaseRequest<OaWageSettingDetail> request, string v)
        {
            var exp = await GetExp(request);
            return await ExtensionList(server_id, request.ToExp(exp), v, request.orderby);
        }

        public async Task<bool> BatchDelete(string server_id, List<decimal> context)
        {
            var list = await _dataImp.List(server_id, it => SqlFunc.ContainsArray(context, it.id));
            return await _dataImp.Deletetable(server_id, list);
        }

        private async Task<List<Expression<Func<OaWageSettingDetail, bool>>>> GetExp(BaseRequest<OaWageSettingDetail> request)
        {
            var r = new List<Expression<Func<OaWageSettingDetail, bool>>>();
            
            return r;
        }
    }
}