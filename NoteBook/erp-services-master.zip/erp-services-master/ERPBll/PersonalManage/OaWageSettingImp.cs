﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPDal.PersonalManage;
using ERPModel.PersonalManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using System.Linq.Expressions;
using ERPModel.ApiModel.PersonalManage;
using ERPDal.SystemManage;

namespace ERPBll.PersonalManage
{
    public class OaWageSettingImp : BusinessRespository<OaWageSetting, IOaWageSettingDataImp>, IOaWageSettingImp
    {
        private readonly ILineDataImp _iLineDataImp;
        public OaWageSettingImp(
            ILineDataImp iLineDataImp,
            IOaWageSettingDataImp dataImp) : base(dataImp)
        {
            _iLineDataImp = iLineDataImp;
        }

        public async Task<bool> AddOaWageSetting(string server_id, OaWageSetting context, ClientInformation client)
        {
            var updates = new List<OaWageSetting>();
            var inserts = new List<OaWageSetting>();
            var details = new List<OaWageSettingDetail>();
            var error_lines = new List<string>();
            var lines = await _iLineDataImp.GetAllLines(server_id);
            if (context.line_id != null && context.line_id.Count > 0)
            {
                context.line_ids = string.Join(",", context.line_id);
            }
            if (context.id > 0)
            {
                // 编辑
                // 重复线路检查
                var old = await Get(server_id, context.id);
                var unExistLineIds = context.line_id.Except(old.line_id).ToList();
                foreach (var line in unExistLineIds)
                {
                    if (await _dataImp.IsExist(server_id, it => it.line_ids.Contains(line.ToString()) && it.type == context.type))
                    {
                        if (lines.Exists(it => it.id == line))
                            error_lines.Add(lines.Find(it => it.id == line).name);
                    }
                }

                context.created_id = old.created_id;
                context.created_date = old.created_date;
                context.update_date = DateTime.Now;
                context.update_id = client.i_id;

                if (error_lines.Count > 0)
                {
                    throw new Exception($"{string.Join(",", error_lines.Distinct())}已设置薪资规则!");
                }

                if (context.detail_items != null && context.detail_items.Count() > 0)
                {
                    foreach (var item in context.detail_items)
                    {
                        item.main_id = context.id;
                        details.Add(item);
                    }
                }
                updates.Add(context);
            }
            else
            {
                // 新增
                // 重复线路检查
                foreach (var line in context.line_id)
                {
                    if (await _dataImp.IsExist(server_id, it => it.line_id.Contains(line) && it.type == context.type))
                    {
                        if (lines.Exists(it => it.id == line))
                            error_lines.Add(lines.Find(it => it.id == line).name);
                    }
                }

                context.id = await _dataImp.GetId(server_id, "SEQ_COMMON");
                context.created_date = DateTime.Now;
                context.created_id = client.i_id;

                if (error_lines.Count > 0)
                {
                    throw new Exception($"{string.Join(",", error_lines.Distinct())}已设置薪资规则!");
                }

                if (context.detail_items != null && context.detail_items.Count() > 0)
                {
                    foreach (var item in context.detail_items)
                    {
                        item.main_id = context.id;
                        details.Add(item);
                    }
                }
                inserts.Add(context);
            }
            return await _dataImp.AddOaWageSettingBatch(server_id, inserts, updates, details);
        }

        public async Task<Tuple<List<OaWageSetting>, int>> QueryOaWageSettingPageList(string server_id, BaseRequest<OaWageSetting> request, string v)
        {
            var exp = await GetExp(request);
            return await ExtensionList(server_id, request.ToExp(exp), v, request.page_size, request.page_index, request.orderby);
        }

        public async Task<List<OaWageSetting>> QueryOaWageSettingList(string server_id, BaseRequest<OaWageSetting> request, string v)
        {
            var exp = await GetExp(request);
            return await ExtensionList(server_id, request.ToExp(exp), v, request.orderby);
        }

        public async Task<bool> BatchDelete(string server_id, List<decimal> context)
        {
            var list = await _dataImp.List(server_id, it => SqlFunc.ContainsArray(context, it.id));
            return await _dataImp.Deletetable(server_id, list);
        }

        private async Task<List<Expression<Func<OaWageSetting, bool>>>> GetExp(BaseRequest<OaWageSetting> request)
        {
            var r = new List<Expression<Func<OaWageSetting, bool>>>();

            return r;
        }

        public async Task<bool> AddOaWageSettingBatch(string server_id, List<OaWageSetting> contexts, ClientInformation client)
        {
            var updates = new List<OaWageSetting>();
            var inserts = new List<OaWageSetting>();
            var details = new List<OaWageSettingDetail>();
            var error_lines = new List<string>();
            var lines = await _iLineDataImp.GetAllLines(server_id);

            foreach (var context in contexts)
            {
                if (context.line_id != null && context.line_id.Count > 0)
                {
                    context.line_ids = string.Join(",", context.line_id);
                }
                if (context.id > 0)
                {
                    // 编辑
                    // 重复线路检查
                    var old = await Get(server_id, context.id);
                    var unExistLineIds = context.line_id.Except(old.line_id).ToList();

                    foreach (var line in unExistLineIds)
                    {
                        if (await _dataImp.IsExist(server_id, it => it.line_ids.Contains(line.ToString()) && it.type == context.type))
                        {
                            if (lines.Exists(it => it.id == line))
                                error_lines.Add(lines.Find(it => it.id == line).name);
                        }
                    }

                    context.created_id = old.created_id;
                    context.created_date = old.created_date;
                    context.update_date = DateTime.Now;
                    context.update_id = client.i_id;
                    updates.Add(context);
                }
                else
                {
                    // 新增
                    // 重复线路检查
                    foreach (var line in context.line_id)
                    {
                        if (await _dataImp.IsExist(server_id, it => it.line_ids.Contains(line.ToString()) && it.type == context.type))
                        {
                            if (lines.Exists(it => it.id == line))
                                error_lines.Add(lines.Find(it => it.id == line).name);
                        }
                    }
                    context.id = await _dataImp.GetId(server_id, "SEQ_COMMON");
                    context.created_date = DateTime.Now;
                    context.created_id = client.i_id;
                    inserts.Add(context);
                }
                if (context.detail_items != null && context.detail_items.Count() > 0)
                {
                    foreach (var item in context.detail_items)
                    {
                        item.main_id = context.id;
                        details.Add(item);
                    }
                }

            }
            if (error_lines.Count > 0)
            {
                throw new Exception($"{string.Join(",", error_lines.Distinct())}已设置薪资规则!");
            }
            return await _dataImp.AddOaWageSettingBatch(server_id, inserts, updates, details);
        }
    }
}