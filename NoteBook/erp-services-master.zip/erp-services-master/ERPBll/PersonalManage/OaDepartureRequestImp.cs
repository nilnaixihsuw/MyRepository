﻿using ERPCore.ORM;
using ERPDal.PersonalManage;
using ERPModel.PersonalManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using ERPModel.ApiModel.PersonalManage;
using System.Linq.Expressions;
using ERPDal.UserManage;
using ERPCore.Entity;
using DotNetCore.CAP;
using ERPBll.Caps;
using ERPModel.CommonModel;
using ERPCore.Redis;
using BusTools.Redis;

namespace ERPBll.PersonalManage
{
    public class OaDepartureRequestImp : BusinessRespository<OaDepartureRequest, IOaDepartureRequestDataImp>, IOaDepartureRequestImp, ICapSubscribe
    {
        private readonly ISysPersonDataImp _iSysPersonDataImp;
        private readonly ICapPublisher _publisher;
        private readonly ISysPersonLifeDataImp _iSysPersonLifeDataImp;
        public OaDepartureRequestImp(
            ISysPersonLifeDataImp iSysPersonLifeDataImp,
            ICapPublisher iCapPublisher,
            ISysPersonDataImp iSysPersonDataImp,
            IOaDepartureRequestDataImp dataImp) : base(dataImp)
        {
            _iSysPersonLifeDataImp = iSysPersonLifeDataImp;
            _publisher = iCapPublisher;
            _iSysPersonDataImp = iSysPersonDataImp;
        }

        public async Task<bool> CancelDimission(string server_id, List<decimal> context, ClientInformation client)
        {
            var list = await _dataImp.List(server_id, it => SqlFunc.ContainsArray(context, it.id));
            list.ForEach(item =>
            {
                //插入成长记录
                _publisher.Publish(EventMessages.GrowthRecord, new RabbitMqRequest<SysPersonLife>()
                {
                    server_id = server_id,
                    context = new SysPersonLife
                    {
                        user_id = item.person_id,
                        content = "管理员办理离职撤销",
                        date = DateTime.Now,
                        created_date = DateTime.Now,
                        created_id = client.i_id,
                    }
                });
            });

            return await _dataImp.Deletetable(server_id, list);
        }

        public async Task<bool> Confirm(string server_id, List<decimal> context, ClientInformation client)
        {
            var personLifes = new List<SysPersonLife>();
            var list = await _dataImp.List(server_id, it => SqlFunc.ContainsArray(context, it.id));
            list.ForEach(item =>
            {
                item.deal = 1;
                personLifes.Add(new SysPersonLife
                {
                    user_id = item.person_id,
                    content = "离职成功",
                    date = DateTime.Now,
                    created_date = DateTime.Now,
                    created_id = client.i_id,
                });
            });
            //更新人员记录表
            var persons = await _iSysPersonDataImp.List(server_id, it => SqlFunc.ContainsArray(list.Select(it => it.person_id).ToList(), it.i_id));
            persons.ForEach(emp =>
            {
                emp.i_emp_state = 0;
                emp.c_state = "3";
                emp.i_dimission_reason = list.Find(it => it.person_id == emp.i_id).reason;
                emp.d_dimission_date = list.Find(it => it.person_id == emp.i_id).hope_date;
                emp.c_dimission_remark = list.Find(it => it.person_id == emp.i_id).remark;
            });
            return await _dataImp.Confirm(server_id, list, persons, personLifes);
        }

        [CapSubscribe(EventMessages.GrowthRecord, Group = "Personnel")]
        public void AddGrowthRecordMessage(RabbitMqRequest<SysPersonLife> input)
        {
            try
            {
                var r = _iSysPersonLifeDataImp.Insert(input.server_id, input.context).Result;
                if (!r) throw new Exception();
            }
            catch (Exception ex)
            {
                Console.WriteLine("生成成长记录失败!" + ex.Message);
            }
        }

        public async Task<bool> Dimission(string server_id, OaDepartureRequest context, ClientInformation client)
        {
            context.created_id = client.i_id;
            context.created_date = DateTime.Now;
            context.source = 1;
            context.deal = 0;
            var eList = await _dataImp.List(server_id, it => it.person_id == context.person_id);
            if (eList.Count > 0) throw new Exception("该人员已提交离职申请,请勿重复提交数据!");
            if (context.handover_id != null)
            {
                var emp = await _iSysPersonDataImp.Get(server_id, context.handover_id);
                if (emp != null && emp.i_emp_state == 0) throw new Exception("交接人已离职!请选择在职人员!");
            }

            var personLife = new SysPersonLife
            {
                user_id = context.person_id,
                content = "管理员办理离职申请",
                date = DateTime.Now,
                created_date = DateTime.Now,
                created_id = client.i_id,
            };

            //更新人员记录表
            var person = await _iSysPersonDataImp.Get(server_id, context.person_id);
            person.i_emp_state = 2;

            return await _dataImp.Dimission(server_id, context, personLife, person);
        }

        public async Task<List<OaDepartureRequest>> QueryDimissionList(string server_id, OaDepartureManageRequest request, string where)
        {
            var exp = await GetExp(request);
            return await ExtensionList(server_id, request.ToExp(exp), where, request.orderby);
        }

        public async Task<Tuple<List<OaDepartureRequest>, int>> QueryDimissionPageList(string server_id, OaDepartureManageRequest request, string where)
        {
            var exp = await GetExp(request);
            return await ExtensionList(server_id, request.ToExp(exp), where, request.page_size, request.page_index, request.orderby);
        }

        private async Task<List<Expression<Func<OaDepartureRequest, bool>>>> GetExp(OaDepartureManageRequest request)
        {
            var r = new List<Expression<Func<OaDepartureRequest, bool>>>();
            if (!string.IsNullOrEmpty(request.name))
            {
                var emps = await _iSysPersonDataImp.List(request.server_id, it => it.c_name.Contains(request.name));
                r.Add(it => SqlFunc.ContainsArray(emps.Select(it => it.i_id).ToList(), it.person_id));
            }
            if (request.org_ids != null && request.org_ids.Count > 0)
            {
                var emps = await _iSysPersonDataImp.List(request.server_id, it => SqlFunc.ContainsArray(request.org_ids, it.i_department_base));
                r.Add(it => SqlFunc.ContainsArray(emps.Select(it => it.i_id).ToList(), it.person_id));
            }
            return r;
        }
    }
}