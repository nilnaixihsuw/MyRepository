﻿using ERPBll.FlowManage.Contracts;
using ERPBll.RedisManage.Dicts;
using ERPBll.RedisManage.Users;
using ERPCore.Enums;
using ERPDal;
using ERPDal.Repository;
using ERPModel.FlowManage.FlowRecords;
using ERPModel.PersonalManage.Rewards;
using ERPModel.SystemManage;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.PersonalManage.Rewards
{
    public class ErpRewardRecordImp : BaseBusiness<ErpRewardRecord>, IErpRewardRecordImp
    {
        private readonly IErpFlowRecordImp _iErpFlowRecordImp;
        private readonly IUserRedisImp _iUserRedisImp;
        private readonly IDictRedisManageImp _iDictRedisManageImp;
        public ErpRewardRecordImp(IErpFlowRecordImp iErpFlowRecordImp,
            IDictRedisManageImp iDictRedisManageImp,
            IUserRedisImp iUserRedisImp)
        {
            _iErpFlowRecordImp = iErpFlowRecordImp;
            _iUserRedisImp = iUserRedisImp;
            _iDictRedisManageImp = iDictRedisManageImp;
        }

        public async Task<Tuple<List<RewardRecordDto>, int>> GetData(RewardRecordRequest request)
        {
            var persons = await _iUserRedisImp.GetAllAsync();
            if (!string.IsNullOrEmpty(request.user_name))
            {
                persons = persons.Where(r => r.c_name.Contains(request.user_name)).ToList();
            }
            if (request.dept_ids != null && request.dept_ids.Count > 0)
            {
                persons = persons.Where(r => r.i_department_base != null && request.dept_ids.Contains(r.i_department_base.Value)).ToList();
            }
            var dic = await _iDictRedisManageImp.GetAllAsync();
            var list = new List<RewardRecordDto>();
            using (var DB = SqlSugarHelper.DBClient(request.server_id))
            {
                RefAsync<int> totalNumber = 0;
                var records = await DB.Queryable<ErpRewardRecord>()
                    .Where(request.ToExp())
                    .Where(r => persons.Select(m => m.i_id).Contains(r.user_id))
                    .Includes(r => r.created_info)
                    .OrderBy(r => r.created_date, OrderByType.Desc)
                    .ToPageListAsync(request.page_index, request.page_size, totalNumber);
                var kinds = await DB.Queryable<ErpRewardKind>().ToListAsync();
                var cases = await DB.Queryable<ErpRewardCase>().ToListAsync();
                var files = await DB.Queryable<SysFileRecord>().ToListAsync();
                foreach (var item in records)
                {
                    var temp = new RewardRecordDto();
                    temp.id = item.id;
                    temp.user_id = item.user_id;
                    temp.user_name = persons.Find(r => r.i_id == item.user_id).c_name;
                    temp.user_dept = persons.Find(r => r.i_id == item.user_id).department_name;
                    temp.user_position = dic.Find(r => r.i_id == persons.Find(r => r.i_id == item.user_id).i_job_level)?.c_name;

                    temp.created_id = item.created_id;
                    temp.created_date = item.created_date;
                    temp.created_name = item.created_info?.c_name;
                    temp.remark = item.remark;
                    temp.type = item.type;
                    temp.flow_id = item.flow_id;
                    temp.img_path = item.img_path;
                    //temp.finish_date = item.finish_date;

                    temp.case_ids = new List<decimal>();
                    item.case_ids.Split(',').ToList().ForEach(r => temp.case_ids.Add(Convert.ToDecimal(r)));
                    temp.case_names = string.Join("<br/>", cases.Where(r => temp.case_ids.Contains(r.id)).Select(r => r.title));

                    temp.kind_ids = new List<decimal>();
                    item.kind_ids.Split(',').ToList().ForEach(r => temp.kind_ids.Add(Convert.ToDecimal(r)));
                    temp.content = string.Join("<br/>", kinds.Where(r => temp.kind_ids.Contains(r.id)).Select(r => r.content));
                    temp.patch = string.Join("<br/>", kinds.Where(r => temp.kind_ids.Contains(r.id)).Select(r => r.pact));
                    //temp.kind_names = string.Join(',', kinds.Where(r => temp.kind_ids.Contains(r.id)).Select(r => type_child_dic[Convert.ToInt32(r.type_child)]).ToList());
                    temp.kind_names = string.Join(',', kinds.Where(r => temp.kind_ids.Contains(r.id)).Select(r => dic.Find(m => m.i_id == r.type_child).c_name).ToList());

                    temp.files = files.Where(r => r.model == (int)FileRecordType.Reward && r.object_id == temp.id).ToList();
                    list.Add(temp);
                }

                if (list.Count > 0)
                {
                    var all = await _iErpFlowRecordImp.GetListAsync(request.server_id, null, new FlowRecordQuery()
                    {
                        detail_ids = list.Select(x => (int)x.id).ToList()
                    });

                    list.ForEach(r =>
                    {
                        if (r.state == 2)//处理中
                        {
                            var info = all.FirstOrDefault(x => x.detail_id == r.id);
                            if (info != null)
                            {
                                r.flow_code = info.code;
                            }
                        }
                    });
                }

                return new Tuple<List<RewardRecordDto>, int>(list, totalNumber);
            }
        }

        private Dictionary<int, string> type_child_dic = new Dictionary<int, string>()
        {
            { 1,"通报表扬" },
            { 2,"嘉奖" },
            { 3,"记功" },
            { 4,"警告" },
            { 5,"记过" },
            { 6,"降级" },
            { 7,"留岗察看" },
            { 8,"开除" },
        };
    }
}
