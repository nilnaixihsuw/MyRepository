﻿using AutoMapper;
using ERPDal;
using ERPModel.DataBase;
using ERPModel.PersonalManage.Rewards;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.PersonalManage.Rewards
{
    public class ErpRewardCaseImp : IErpRewardCaseImp
    {
        private readonly IMapper _imapper;
        public ErpRewardCaseImp(
            IMapper imapper)
        {
            _imapper = imapper;
        }

        /// <summary>
        /// 分页查询
        /// </summary>
        public async Task<(List<RewardCaseDto>, int)> GetByPageAsync(string server_id, int page_index, int page_size)
        {
            RefAsync<int> totalCount = 0;

            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpRewardCase>()
                                .Mapper(x => x.dict_detail, x => x.type_child)
                                .Mapper(x => {
                                    var rel_list = SqlSugarHelper.DBClient(server_id)
                                                    .Queryable<ErpRewardRel>()
                                                    .Where(y => y.case_id == x.id)
                                                    .ToList();
                                    x.kinds = SqlSugarHelper.DBClient(server_id)
                                                    .Queryable<ErpRewardKind>()
                                                    .Mapper(r => r.dict_detail, r => r.type_child)
                                                    .Where(y => SqlFunc.ContainsArray(rel_list.Select(z => z.kind_id).ToList(), y.id))
                                                    .ToList();
                                    var dict_details = SqlSugarHelper.DBClient(server_id)
                                                    .Queryable<SysCommonDictDetail>()
                                                    .Where(y => SqlFunc.ContainsArray(x.kinds.Select(z => z.type_child).ToList(), y.i_id))
                                                    .ToList();
                                    x.str_kinds = string.Join(",", dict_details.Select(y => y.c_name).ToList());
                                })
                                .OrderBy(x => new { x.sort, created_date = SqlFunc.Desc(x.created_date) })
                                .ToPageListAsync(page_index, page_size, totalCount);

            var data = _imapper.Map<List<ErpRewardCase>, List<RewardCaseDto>>(list);

            return (data, totalCount);
        }

        /// <summary>
        /// 查询全部
        /// </summary>
        public async Task<List<RewardCaseDto>> GetAllAsync(string server_id)
        {
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpRewardCase>()
                                .Mapper(x => x.dict_detail, x => x.type_child)
                                .Mapper(x => {
                                    var rel_list = SqlSugarHelper.DBClient(server_id)
                                                    .Queryable<ErpRewardRel>()
                                                    .Where(y => y.case_id == x.id)
                                                    .ToList();
                                    x.kinds = SqlSugarHelper.DBClient(server_id)
                                                    .Queryable<ErpRewardKind>()
                                                    .Mapper(r => r.dict_detail, r => r.type_child)
                                                    .Where(y => SqlFunc.ContainsArray(rel_list.Select(z => z.kind_id).ToList(), y.id))
                                                    .ToList();
                                    var dict_details = SqlSugarHelper.DBClient(server_id)
                                                    .Queryable<SysCommonDictDetail>()
                                                    .Where(y => SqlFunc.ContainsArray(x.kinds.Select(z => z.type_child).ToList(), y.i_id))
                                                    .ToList();
                                    x.str_kinds = string.Join(",", dict_details.Select(y => y.c_name).ToList());
                                })
                                .OrderBy(x => new { x.sort, created_date = SqlFunc.Desc(x.created_date) })
                                .ToListAsync();

            var data = _imapper.Map<List<ErpRewardCase>, List<RewardCaseDto>>(list);

            return data;
        }

        /// <summary>
        /// 根据类别获取
        /// </summary>
        public async Task<List<RewardCaseDto>> GetByTypeAsync(string server_id, int type)
        {
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpRewardCase>()
                                .Where(x => x.type == type)
                                .Mapper(x => x.dict_detail, x => x.type_child)
                                .Mapper(x => {
                                    var rel_list = SqlSugarHelper.DBClient(server_id)
                                                    .Queryable<ErpRewardRel>()
                                                    .Where(y => y.case_id == x.id)
                                                    .ToList();
                                    x.kinds = SqlSugarHelper.DBClient(server_id)
                                                    .Queryable<ErpRewardKind>()
                                                    .Mapper(r => r.dict_detail, r => r.type_child)
                                                    .Where(y => SqlFunc.ContainsArray(rel_list.Select(z => z.kind_id).ToList(), y.id))
                                                    .ToList();
                                    var dict_details = SqlSugarHelper.DBClient(server_id)
                                                    .Queryable<SysCommonDictDetail>()
                                                    .Where(y => SqlFunc.ContainsArray(x.kinds.Select(z => z.type_child).ToList(), y.i_id))
                                                    .ToList();
                                    x.str_kinds = string.Join(",", dict_details.Select(y => y.c_name).ToList());
                                })
                                .OrderBy(x => new { x.sort, created_date = SqlFunc.Desc(x.created_date) })
                                .ToListAsync();

            var data = _imapper.Map<List<ErpRewardCase>, List<RewardCaseDto>>(list);

            return data;
        }

        /// <summary>
        /// 新增
        /// </summary>
        public async Task<RewardCaseDto> CreateAsync(
            string server_id, decimal? user_id, RewardCaseInput input)
        {
            var info = _imapper.Map<RewardCaseInput, ErpRewardCase>(input);

            info.id = Tools.GetEngineID(server_id);
            info.SetCreate(user_id);

            //添加情形种类关联
            if (input.kind_ids != null && input.kind_ids.Count > 0)
            {
                var rel_list = new List<ErpRewardRel>();

                input.kind_ids.ForEach(x => {
                    rel_list.Add(new ErpRewardRel() {
                        case_id = info.id,
                        kind_id = x
                    });
                });

                await SqlSugarHelper.DBClient(server_id).Insertable(rel_list).ExecuteCommandAsync();
            }

            var res = await SqlSugarHelper.DBClient(server_id).Insertable(info).ExecuteCommandAsync() > 0;

            if (res)
            {
                return _imapper.Map<ErpRewardCase, RewardCaseDto>(info);
            }
            return null;
        }

        /// <summary>
        /// 编辑
        /// </summary>
        public async Task<RewardCaseDto> UpdateAsync(
            string server_id, decimal? user_id, RewardCaseInput input)
        {
            var info = await SqlSugarHelper.DBClient(server_id)
                       .Queryable<ErpRewardCase>()
                       .FirstAsync(x => x.id == input.id);

            if (info == null)
            {
                throw new Exception($"未找到奖惩种类信息，id={input.id}");
            }

            input.id = info.id;
            _imapper.Map(input, info);
            info.SetUpdate(user_id);

            //删除旧关联
            await SqlSugarHelper.DBClient(server_id).Deleteable<ErpRewardRel>()
                    .Where(x => x.case_id == info.id).ExecuteCommandAsync();

            //添加情形种类关联
            if (input.kind_ids != null && input.kind_ids.Count > 0)
            {
                var rel_list = new List<ErpRewardRel>();

                input.kind_ids.ForEach(x => {
                    rel_list.Add(new ErpRewardRel()
                    {
                        case_id = info.id,
                        kind_id = x
                    });
                });

                await SqlSugarHelper.DBClient(server_id).Insertable(rel_list).ExecuteCommandAsync();
            }

            var res = await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync() > 0;

            if (res)
            {
                return _imapper.Map<ErpRewardCase, RewardCaseDto>(info);
            }
            return null;
        }

        /// <summary>
        /// 删除
        /// </summary>
        public async Task<bool> DeleteAsync(string server_id, List<decimal> ids)
        {
            var res = await SqlSugarHelper.DBClient(server_id)
                        .Deleteable<ErpRewardCase>()
                        .Where(x => ids.Contains(x.id))
                        .ExecuteCommandAsync() > 0;

            if (res)
            {
                //删除关联
                await SqlSugarHelper.DBClient(server_id).Deleteable<ErpRewardRel>()
                        .Where(x => ids.Contains(x.case_id)).ExecuteCommandAsync();
            }

            return res;
        }

        /// <summary>
        /// 排序
        /// </summary>
        public async Task<bool> ChangeSortAsync(string server_id, List<ChangeSort> change_sort)
        {
            var ids = change_sort.Select(x => x.id).ToList();

            var list = await SqlSugarHelper.DBClient(server_id)
                        .Queryable<ErpRewardCase>()
                        .Where(x => ids.Contains(x.id))
                        .ToListAsync();

            var new_list = new List<ErpRewardCase>();

            change_sort.ForEach(x => {
                var info = list.Where(y => y.id == x.id).First();
                if (info != null)
                {
                    info.sort = x.sort;
                    new_list.Add(info);
                }
            });

            return await SqlSugarHelper.DBClient(server_id).Updateable(new_list).ExecuteCommandAsync() > 0;
        }
    }
}
