﻿using ERPModel.PersonalManage.Rewards;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.PersonalManage.Rewards
{
    /// <summary>
    /// 奖励情形
    /// </summary>
    public interface IErpRewardCaseImp
    {
        /// <summary>
        /// 分页查询
        /// </summary>
        Task<(List<RewardCaseDto>, int)> GetByPageAsync(string server_id, int page_index, int page_size);

        /// <summary>
        /// 查询全部
        /// </summary>
        Task<List<RewardCaseDto>> GetAllAsync(string server_id);

        /// <summary>
        /// 根据类别获取
        /// </summary>
        Task<List<RewardCaseDto>> GetByTypeAsync(string server_id, int type);

        /// <summary>
        /// 新增
        /// </summary>
        Task<RewardCaseDto> CreateAsync(string server_id, decimal? user_id, RewardCaseInput input);

        /// <summary>
        /// 编辑
        /// </summary>
        Task<RewardCaseDto> UpdateAsync(string server_id, decimal? user_id, RewardCaseInput input);

        /// <summary>
        /// 删除
        /// </summary>
        Task<bool> DeleteAsync(string server_id, List<decimal> ids);

        /// <summary>
        /// 排序
        /// </summary>
        Task<bool> ChangeSortAsync(string server_id, List<ChangeSort> change_sort);
    }
}
