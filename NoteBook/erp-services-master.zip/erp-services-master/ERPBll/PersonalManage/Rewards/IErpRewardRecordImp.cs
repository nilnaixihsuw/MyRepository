﻿using ERPDal.Repository;
using ERPModel.PersonalManage.Rewards;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.PersonalManage.Rewards
{
    public interface IErpRewardRecordImp : IBaseBusiness<ErpRewardRecord>
    {
        Task<Tuple<List<RewardRecordDto>, int>> GetData(RewardRecordRequest request);
    }
}
