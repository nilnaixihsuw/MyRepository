﻿using AutoMapper;
using ERPDal;
using ERPModel.PersonalManage.Rewards;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.PersonalManage.Rewards
{
    /// <summary>
    /// 奖惩种类
    /// </summary>
    public class ErpRewardKindImp : IErpRewardKindImp
    {
        private readonly IMapper _imapper;
        public ErpRewardKindImp(
            IMapper imapper)
        {
            _imapper = imapper;
        }

        /// <summary>
        /// 分页查询
        /// </summary>
        public async Task<(List<RewardKindDto>, int)> GetByPageAsync(string server_id, int page_index, int page_size)
        {
            RefAsync<int> totalCount = 0;

            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpRewardKind>()
                                .Mapper(x => x.dict_detail, x => x.type_child)
                                .OrderBy(x => new { x.sort, created_date = SqlFunc.Desc(x.created_date) })
                                .ToPageListAsync(page_index, page_size, totalCount);

            var data = _imapper.Map<List<ErpRewardKind>, List<RewardKindDto>>(list);

            return (data, totalCount);
        }

        /// <summary>
        /// 查询全部
        /// </summary>
        public async Task<List<RewardKindDto>> GetAllAsync(string server_id)
        {
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpRewardKind>()
                                .Mapper(x => x.dict_detail, x => x.type_child)
                                .OrderBy(x => new { x.sort, created_date = SqlFunc.Desc(x.created_date) })
                                .ToListAsync();

            var data = _imapper.Map<List<ErpRewardKind>, List<RewardKindDto>>(list);

            return data;
        }

        /// <summary>
        /// 根据类别获取
        /// </summary>
        public async Task<List<RewardKindDto>> GetByTypeAsync(string server_id, int type)
        {
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpRewardKind>()
                                .Where(x => x.type == type)
                                .Mapper(x => x.dict_detail, x => x.type_child)
                                .OrderBy(x => new { x.sort, created_date = SqlFunc.Desc(x.created_date) })
                                .ToListAsync();

            var data = _imapper.Map<List<ErpRewardKind>, List<RewardKindDto>>(list);

            return data;
        }

        /// <summary>
        /// 新增
        /// </summary>
        public async Task<RewardKindDto> CreateAsync(
            string server_id, decimal? user_id, RewardKindInput input)
        {
            var info = await SqlSugarHelper.DBClient(server_id)
                       .Queryable<ErpRewardKind>()
                       .FirstAsync(x => x.type_child == input.type_child);

            if (info != null)
            {
                throw new Exception($"此奖惩种类已存在");
            }

            info = _imapper.Map<RewardKindInput, ErpRewardKind>(input);

            info.id = Tools.GetEngineID(server_id);
            info.SetCreate(user_id);

            var res = await SqlSugarHelper.DBClient(server_id).Insertable(info).ExecuteCommandAsync() > 0;

            if (res)
            {
                return _imapper.Map<ErpRewardKind, RewardKindDto>(info);
            }
            return null;
        }

        /// <summary>
        /// 编辑
        /// </summary>
        public async Task<RewardKindDto> UpdateAsync(
            string server_id, decimal? user_id, RewardKindInput input)
        {
            var info = await SqlSugarHelper.DBClient(server_id)
                       .Queryable<ErpRewardKind>()
                       .FirstAsync(x => x.id == input.id);

            if (info == null)
            {
                throw new Exception($"未找到奖惩种类信息，id={input.id}");
            }

            input.id = info.id;
            _imapper.Map(input, info);
            info.SetUpdate(user_id);

            var res = await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync() > 0;

            if (res)
            {
                return _imapper.Map<ErpRewardKind, RewardKindDto>(info);
            }
            return null;
        }

        /// <summary>
        /// 删除
        /// </summary>
        public async Task<bool> DeleteAsync(string server_id, List<decimal> ids)
        {
            return await SqlSugarHelper.DBClient(server_id)
                        .Deleteable<ErpRewardKind>()
                        .Where(x => ids.Contains(x.id))
                        .ExecuteCommandAsync() > 0;
        }

        /// <summary>
        /// 排序
        /// </summary>
        public async Task<bool> ChangeSortAsync(string server_id, List<ChangeSort> change_sort)
        {
            var ids = change_sort.Select(x => x.id).ToList();

            var list = await SqlSugarHelper.DBClient(server_id)
                        .Queryable<ErpRewardKind>()
                        .Where(x => ids.Contains(x.id))
                        .ToListAsync();

            var new_list = new List<ErpRewardKind>();

            change_sort.ForEach(x => {
                var info = list.Where(y => y.id == x.id).First();
                if (info != null)
                {
                    info.sort = x.sort;
                    new_list.Add(info);
                }
            });

            return await SqlSugarHelper.DBClient(server_id).Updateable(new_list).ExecuteCommandAsync() > 0;
        }
    }
}
