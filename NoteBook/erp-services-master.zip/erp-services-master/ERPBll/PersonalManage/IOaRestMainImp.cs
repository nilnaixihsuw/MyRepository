﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPModel.OAManage;
using ERPModel.PersonalManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.PersonalManage
{
    public interface IOaRestMainImp : IBusinessRepository<OaRestMain>
    {
        Task<bool> AddOaRestMain(string server_id, OaRestMain context, ClientInformation client);
        Task<Tuple<List<OaRestMain>,int>> QueryOaRestMainPageList(string server_id, BaseRequest<OaRestMain> request, string v);
        Task<List<OaRestMain>> QueryOaRestMainList(string server_id, BaseRequest<OaRestMain> request, string v);
        Task<bool> BatchDelete(string server_id, List<decimal> context);
    }
}