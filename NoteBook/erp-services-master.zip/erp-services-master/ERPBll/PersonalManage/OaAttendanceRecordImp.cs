﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPDal.PersonalManage;
using ERPModel.PersonalManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using System.Linq.Expressions;
using ERPModel.ApiModel.PersonalManage;
using ERPDal.UserManage;
using ERPCore.Enums;
using System.Dynamic;
using ERPDal;
using ERPBll.OAManage;
using ERPModel.Oamanage.OaKqbcs;
using ERPModel.OAManage;

namespace ERPBll.PersonalManage
{
    public class OaAttendanceRecordImp : BusinessRespository<OaAttendanceRecord, IOaAttendanceRecordDataImp>, IOaAttendanceRecordImp
    {
        private readonly ISysPersonDataImp _iSysPersonDataImp;
        private readonly IOaRestMainDataImp _iOaRestMainDataImp;
        private readonly IOaWorkOvertimeDataImp _iOaWorkOvertimeDataImp;
        private readonly IOaKqzImp _oaKqzImp;
        public OaAttendanceRecordImp(
            IOaWorkOvertimeDataImp iOaWorkOvertimeDataImp,
            IOaRestMainDataImp iOaRestMainDataImp,
            ISysPersonDataImp iSysPersonDataImp,
            IOaAttendanceRecordDataImp dataImp,
            IOaKqzImp oaKqzImp) : base(dataImp)
        {
            _iSysPersonDataImp = iSysPersonDataImp;
            _iOaRestMainDataImp = iOaRestMainDataImp;
            _iOaWorkOvertimeDataImp = iOaWorkOvertimeDataImp;
            _oaKqzImp = oaKqzImp;
        }

        public async Task<bool> AddOaAttendanceRecord(string server_id, List<OaAttendanceRecord> context, ClientInformation client)
        {
            return await _dataImp.Insertable(server_id, context);
        }

        public async Task<Tuple<List<OaAttendanceRecord>, int>> QueryOaAttendanceRecordPageList(string server_id, BaseRequest<OaAttendanceRecord> request, string v)
        {
            var exp = await GetExp(request);
            return await ExtensionList(server_id, request.ToExp(exp), v, request.page_size, request.page_index, request.orderby);
        }

        public async Task<List<OaAttendanceRecord>> QueryOaAttendanceRecordList(string server_id, BaseRequest<OaAttendanceRecord> request, string v)
        {
            var exp = await GetExp(request);
            return await ExtensionList(server_id, request.ToExp(exp), v, request.orderby);
        }

        public async Task<bool> BatchDelete(string server_id, List<decimal> context)
        {
            var list = await _dataImp.List(server_id, it => SqlFunc.ContainsArray(context, it.id));
            return await _dataImp.Deletetable(server_id, list);
        }

        private async Task<List<Expression<Func<OaAttendanceRecord, bool>>>> GetExp(BaseRequest<OaAttendanceRecord> request)
        {
            var r = new List<Expression<Func<OaAttendanceRecord, bool>>>();

            return r;
        }

        public async Task<Tuple<List<AttendanceStatisticsResponse>, int>> AttendanceStatistics(AttendanceStatisticsRequest request)
        {
            var exp = Expressionable.Create<OaAttendanceRecord>()
                                    .AndIF(request.date != null && request.date.Count == 2, it => it.date >= request.date[0] && it.date <= request.date[1])
                                    .AndIF(request.user_ids != null && request.user_ids.Count > 0, it => SqlFunc.ContainsArray(request.user_ids, it.user_id));
            if (request.org_ids != null && request.org_ids.Count > 0)
            {
                var emps = await _iSysPersonDataImp.List(request.server_id, it => SqlFunc.ContainsArray(request.org_ids, it.i_department_base));
                if (emps.Count > 0)
                {
                    var ids = emps.Select(it => it.i_id).ToList();
                    exp.And(it => SqlFunc.ContainsArray(ids, it.user_id));
                }
                else
                {
                    exp.And(it => false);
                }
            }
            if (request.contain_dimission != null && !request.contain_dimission.Value)
            {
                var emps = await _iSysPersonDataImp.List(request.server_id, it => it.i_emp_state == 1 || it.i_emp_state == null);
                if (emps.Count > 0)
                {
                    var ids = emps.Select(it => it.i_id).ToList();
                    exp.And(it => SqlFunc.ContainsArray(ids, it.user_id));
                }
                else
                {
                    exp.And(it => false);
                }
            }

            var list = await _dataImp.List(request.server_id, exp.ToExpression());
            list = await _dataImp.ExtList(request.server_id, list);

            var r = list.GroupBy(it => new { it.user_id, it.dept_name, it.user_name }).Select(it => new AttendanceStatisticsResponse
            {
                user_id = it.Key.user_id,
                dept_name = it.Key.dept_name,
                user_name = it.Key.user_name,
                annual_holiday = it.Where(c => c.type == 1 && c.type_child == 5).Sum(c => (c.duration.HasValue ? c.duration.Value : 0)) / 8,
                bs_hour = it.Where(c => c.type == 1 && c.type_child == 1).Sum(c => (c.duration.HasValue ? c.duration.Value : 0)),
                kh_hour = it.Where(c => c.type == 1 && c.type_child == 2).Sum(c => (c.duration.HasValue ? c.duration.Value : 0)),
                sj_hour = it.Where(c => c.type == 1 && c.type_child == 3).Sum(c => (c.duration.HasValue ? c.duration.Value : 0)),
                bj_hour = it.Where(c => c.type == 1 && c.type_child == 4).Sum(c => (c.duration.HasValue ? c.duration.Value : 0)),
                qj_count = it.Where(c => c.type == 1).GroupBy(c => c.main_id).Count(),
                qj_total_hour = it.Where(c => c.type == 1).Sum(c => (c.duration.HasValue ? c.duration.Value : 0)),
                jjrjb_hour = it.Where(c => c.type == 2 && c.type_child == 10).Sum(c => (c.duration.HasValue ? c.duration.Value : 0)),
                sxrjb_hour = it.Where(c => c.type == 2 && c.type_child == 11).Sum(c => (c.duration.HasValue ? c.duration.Value : 0)),
                ysjb_hour = it.Where(c => c.type == 2 && c.type_child == 12).Sum(c => (c.duration.HasValue ? c.duration.Value : 0)),
                jb_count = it.Where(c => c.type == 2).GroupBy(c => c.main_id).Count(),
                jb_total_hour = it.Where(c => c.type == 2).Sum(c => (c.duration.HasValue ? c.duration.Value : 0)),
            }).ToList();

            if (request.page_index > 0 && request.page_size > 0)
            {
                return new Tuple<List<AttendanceStatisticsResponse>, int>(r.Skip((request.page_index - 1) * request.page_size).Take(request.page_size).ToList(), r.Count);
            }
            else
            {
                return new Tuple<List<AttendanceStatisticsResponse>, int>(r, r.Count);
            }


        }

        public async Task<List<AttendanceStatisticsDetailResponse>> AttendanceStatisticsDetail(string server_id, decimal user_id, List<DateTime> date, int? type, int? type_child)
        {
            var r = new List<AttendanceStatisticsDetailResponse>();
            var exp = Expressionable.Create<OaAttendanceRecord>()
                                    .And(it => it.user_id == user_id)
                                    .AndIF(date != null && date.Count == 2, it => it.date >= date[0] && it.date <= date[1])
                                    .AndIF(type_child != null, it => it.type_child == type_child)
                                    .AndIF(type != null, it => it.type == type);
            var record = await _dataImp.List(server_id, exp.ToExpression());

            //请假
            var qjs = await _iOaRestMainDataImp.List(server_id, it => SqlFunc.ContainsArray(record.Where(it => it.type == 1).Select(it => it.main_id).ToList(), it.id));
            qjs= qjs.OrderByDescending(x=>x.start_date).ToList(); 
            if (qjs.Count > 0)
            {
                r.AddRange(qjs.Select(it => new AttendanceStatisticsDetailResponse
                {
                    spd = it.type_name,
                    date = it.created_date.Value.ToString("yyyy-MM-dd") + ((DayOfWeekEnums)it.created_date.Value.DayOfWeek).ToString(),
                    hour = it.day,
                    start_end = (it.type == 1 || it.type == 2) ? it.start_date.ToString("yyyy-MM-dd HH:mm") + "-" + it.end_date.ToString("yyyy-MM-dd HH:mm") : it.start_date.ToString("yyyy-MM-dd") + (it.start_time < 2 ? "上午" : "下午") + "-" + it.end_date.ToString("yyyy-MM-dd") + (it.end_time < 2 ? "上午" : "下午")
                }).ToList());
            }

            //加班
            var jbs = await _iOaWorkOvertimeDataImp.List(server_id, it => SqlFunc.ContainsArray(record.Where(it => it.type == 2).Select(it => it.main_id).ToList(), it.id));
            if (jbs.Count > 0)
            {
                r.AddRange(jbs.Select(it => new AttendanceStatisticsDetailResponse
                {
                    spd = it.type_name,
                    date = it.created_date.Value.ToString("yyyy-MM-dd") + ((DayOfWeekEnums)it.created_date.Value.DayOfWeek).ToString(),
                    hour = it.hour,
                    start_end = it.start_time.ToString("yyyy-MM-dd HH:mm") + "-" + it.end_time.ToString("yyyy-MM-dd HH:mm"),
                    fee = it.fee
                }).ToList());
            }
            return r;
        }

        public async Task<AttendanceStatisticsSummaryDetailResponse> AttendanceDetail(AttendanceStatisticsRequest request)
        {
            var r = new AttendanceStatisticsSummaryDetailResponse();
            var exp = Expressionable.Create<OaAttendanceRecord>()
                                    .AndIF(request.date != null && request.date.Count == 2, it => it.date >= request.date[0] && it.date <= request.date[1])
                                    .AndIF(request.user_ids != null && request.user_ids.Count > 0, it => SqlFunc.ContainsArray(request.user_ids, it.user_id));
            if (request.org_ids != null && request.org_ids.Count > 0)
            {
                var emps = await _iSysPersonDataImp.List(request.server_id, it => SqlFunc.ContainsArray(request.org_ids, it.i_department_base));
                if (emps.Count > 0)
                {
                    var ids = emps.Select(it => it.i_id).ToList();
                    exp.And(it => SqlFunc.ContainsArray(ids, it.user_id));
                }
                else
                {
                    exp.And(it => false);
                }
            }
            if (request.contain_dimission != null && request.contain_dimission.Value)
            {
                //排除离职90天以外的记录
                var emps = await _iSysPersonDataImp.List(request.server_id, it => it.i_emp_state == 0 && SqlFunc.DateAdd(it.d_dimission_date.Value, 90) < DateTime.Now);
                if (emps.Count > 0)
                {
                    var ids = emps.Select(it => it.i_id).ToList();
                    exp.And(it => !SqlFunc.ContainsArray(ids, it.user_id));
                }
                else
                {
                    exp.And(it => false);
                }
            }

            var records = await _dataImp.List(request.server_id, exp.ToExpression());
            records = await _dataImp.ExtList(request.server_id, records);

            //获取表头
            r.titles.Add("dept_name", "部门");
            r.titles.Add("user_name", "姓名");
            r.titles.Add("user_id", "司机id");
            if (request.date != null && request.date.Count == 2 && request.date[0] <= request.date[1])
            {
                for (var i = request.date[0]; i <= request.date[1]; i = i.AddDays(1))
                {
                    r.titles.Add(i.ToString("yyyyMMdd"), i.Day + "(" + (DayOfWeekEnumsSimple)i.DayOfWeek + ")");
                }
            }

            records.GroupBy(it => new { it.user_id, it.dept_name, it.user_name }).ToList().ForEach(item =>
            {
                var obj = new Dictionary<string, object>();
                obj.Add("dept_name", item.Key.dept_name);
                obj.Add("user_name", item.Key.user_name);
                obj.Add("user_id", item.Key.user_id);

                //每天详细情况
                if (request.date != null && request.date.Count == 2 && request.date[0] <= request.date[1])
                {
                    for (var i = request.date[0]; i <= request.date[1]; i = i.AddDays(1))
                    {
                        //每天的详细情况 正常,加班,请假
                        var detail = "";
                        if (records.Exists(it => it.date.ToString("yyyy-MM-dd") == i.ToString("yyyy-MM-dd") && it.user_id == item.Key.user_id))
                        {
                            var record = records.Where(it => it.date.ToString("yyyy-MM-dd") == i.ToString("yyyy-MM-dd") && it.user_id == item.Key.user_id).ToList();
                            record.ForEach(item =>
                            {
                                detail += " " + ((QJJBEnums)item.type_child);
                            });

                        }
                        else
                        {
                            if (i.DayOfWeek == DayOfWeek.Saturday || i.DayOfWeek == DayOfWeek.Sunday)
                            {
                                detail = "休息";
                            }
                            else
                            {
                                detail = "正常";
                            }
                        }
                        obj.Add(i.ToString("yyyyMMdd"), detail);
                    }
                }
                r.datas.Add(obj);
            });

            if (request.page_index > 0 && request.page_size > 0)
            {
                r.datas = r.datas.Skip((request.page_index - 1) * request.page_size).Take(request.page_size).ToList();
            }

            r.page_index = request.page_index;
            r.page_size = request.page_size;
            r.total = r.datas.Count;

            return r;
        }

        public async Task<List<AttendanceDetailResponse>> AttendanceDetailById(string server_id, decimal id)
        {
            using var db = SqlSugarHelper.DBClient(server_id);
            var detail = await db.Queryable<OaAttendanceRecord>().Where(x => x.main_id == id).OrderBy(x => x.date).ToListAsync();
            var data = detail.Select(async x => new AttendanceDetailResponse
            {
                date = x.date,
                day = x.duration + ((x.type_child == 1 || x.type_child == 2) ? "小时" : "天"),
                bc = await GetKqbc(x.user_id, x.date.Date, server_id)
            }).ToList();
            var datas = new List<AttendanceDetailResponse>();
            var restmain = await db.Queryable<OaRestMain>().FirstAsync(x => x.id == id);
            foreach (var item in data)
            {
                var info = await item;
                ///第一天也是最后一天
                if(info.date==restmain.start_date.Date&&info.date==restmain.end_date.Date)
                {
                    info.start_end = restmain.type == 1 && restmain.type == 2 ? restmain.start_date.ToString("HH:mm") + "-" + restmain.end_date.ToString("HH:mm") : (restmain.start_time == 1 ? "上午" : "下午") + "-" + (restmain.end_time == 1 ? "上午" : "下午");
                }
                else if (info.date==restmain.start_date.Date)
                {
                    info.start_end = restmain.type == 1 && restmain.type == 2 ? restmain.start_date.ToString("HH:mm") + "-" + info.bc.Substring(info.bc.Length - 5): (restmain.start_time == 1 ? "上午" : "下午") + "-" + "下午";
                }
                else if (info.date==restmain.end_date.Date)
                {
                    info.start_end = restmain.type == 1 && restmain.type == 2 ? info.bc.Substring(0, 5) + "-" + restmain.end_date.ToString("HH:mm") : "上午" + "-" + (restmain.start_time == 1 ? "上午" : "下午");
                }
                else 
                {
                    info.start_end = info.bc;
                }
                datas.Add(info);
            }
            return datas;
        }
        public async Task<string> GetKqbc(decimal user_id,DateTime date, string server_id)
        {
            using var db = SqlSugarHelper.DBClient(server_id);
            var bc_list =await _oaKqzImp.GetKqbcAsync(server_id, (int)user_id, date);
            if (bc_list.Count==0)
            {
                return null;
            }
            var bc =await db.Queryable<OaKqbc>().Includes(x => x.child).FirstAsync(x => x.id == bc_list.First().main_id);
            if (bc == null)
            {
                return null;
            }
            string kqbc = "";
            foreach (var item in bc.child)
            {
                kqbc += item.up_time.Value.ToString("HH:mm") + "-" + item.down_time.Value.ToString("HH:mm") +"<br/>"+ " ";
            }
            kqbc = kqbc.Remove(kqbc.Length - 6, 6);
            return kqbc;
        }
    }
}