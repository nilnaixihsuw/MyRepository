﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPDal.PersonalManage;
using ERPModel.PersonalManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using System.Linq.Expressions;

namespace ERPBll.PersonalManage
{
    public class SysPersonDeptChangeImp : BusinessRespository<SysPersonDeptChange, ISysPersonDeptChangeDataImp>, ISysPersonDeptChangeImp
    {
        public SysPersonDeptChangeImp(ISysPersonDeptChangeDataImp dataImp): base(dataImp)
        {

        }

        public async Task<bool> AddSysPersonDeptChange(string server_id, SysPersonDeptChange context, ClientInformation client)
        {
            if (context.id > 0)
            {
                var old = await _dataImp.Get(server_id, context.id);
                context.created_id = old.created_id;
                context.created_date = old.created_date;
                context.update_date = DateTime.Now;
                context.update_id = client.i_id;
                return await _dataImp.UpdateSysPersonDeptChange(server_id, context);
            }
            else
            {
                context.created_date = DateTime.Now;
                context.created_id = client.i_id;
                return await _dataImp.AddSysPersonDeptChange(server_id, context);
            }
        }

        public async Task<Tuple<List<SysPersonDeptChange>,int>> QuerySysPersonDeptChangePageList(string server_id, BaseRequest<SysPersonDeptChange> request, string v)
        {
            var exp = await GetExp(request);
            return await ExtensionList(server_id, request.ToExp(exp), v, request.page_size, request.page_index, request.orderby);
        }

        public async Task<List<SysPersonDeptChange>> QuerySysPersonDeptChangeList(string server_id, BaseRequest<SysPersonDeptChange> request, string v)
        {
            var exp = await GetExp(request);
            return await ExtensionList(server_id, request.ToExp(exp), v, request.orderby);
        }

        public async Task<bool> BatchDelete(string server_id, List<decimal> context)
        {
            var list = await _dataImp.List(server_id, it => SqlFunc.ContainsArray(context, it.id));
            return await _dataImp.Deletetable(server_id, list);
        }

        private async Task<List<Expression<Func<SysPersonDeptChange, bool>>>> GetExp(BaseRequest<SysPersonDeptChange> request)
        {
            var r = new List<Expression<Func<SysPersonDeptChange, bool>>>();
            
            return r;
        }
    }
}