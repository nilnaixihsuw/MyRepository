﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPModel.ApiModel.PersonalManage;
using ERPModel.PersonalManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.PersonalManage
{
    public interface IOaDepartureRequestImp : IBusinessRepository<OaDepartureRequest>
    {
        Task<Tuple<List<OaDepartureRequest>, int>> QueryDimissionPageList(string server_id, OaDepartureManageRequest request, string where);
        Task<List<OaDepartureRequest>> QueryDimissionList(string server_id, OaDepartureManageRequest request, string where);
        Task<bool> CancelDimission(string server_id, List<decimal> context, ClientInformation client);
        Task<bool> Confirm(string server_id, List<decimal> context, ClientInformation client);
        Task<bool> Dimission(string server_id, OaDepartureRequest context, ClientInformation client);
    }
}