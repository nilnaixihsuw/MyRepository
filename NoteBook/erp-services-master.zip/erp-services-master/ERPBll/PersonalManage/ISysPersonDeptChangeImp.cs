﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPModel.PersonalManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.PersonalManage
{
    public interface ISysPersonDeptChangeImp : IBusinessRepository<SysPersonDeptChange>
    {
        Task<bool> AddSysPersonDeptChange(string server_id, SysPersonDeptChange context, ClientInformation client);
        Task<Tuple<List<SysPersonDeptChange>,int>> QuerySysPersonDeptChangePageList(string server_id, BaseRequest<SysPersonDeptChange> request, string v);
        Task<List<SysPersonDeptChange>> QuerySysPersonDeptChangeList(string server_id, BaseRequest<SysPersonDeptChange> request, string v);
        Task<bool> BatchDelete(string server_id, List<decimal> context);
    }
}