﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPModel.ApiModel.PersonalManage;
using ERPModel.PersonalManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.PersonalManage
{
    public interface IOaWageDriverDayImp : IBusinessRepository<OaWageDriverDay>
    {
        Task<bool> AddOaWageDriverDay(string server_id, OaWageDriverDay context, ClientInformation client);
        Task<Tuple<List<OaWageDriverDay>, int>> QueryOaWageDriverDayPageList(string server_id, BaseRequest<OaWageDriverDay> request, string v);
        Task<List<OaWageDriverDay>> QueryOaWageDriverDayList(string server_id, BaseRequest<OaWageDriverDay> request, string v);
        Task<bool> BatchDelete(string server_id, List<decimal> context);
        Task<bool> AddSalary(string server_id, AddSalaryInput context, ClientInformation client);
        Task<(bool, List<string>)> AddSalaryPre(string server_id, AddSalaryInput context, ClientInformation client);
    }
}