﻿using AutoMapper;
using ERPBll.UserManage;
using ERPCore.Enums;
using ERPDal;
using ERPModel.ApiModel;
using ERPModel.EnterpriseManage.SysTalentPools;
using ERPModel.SystemManage;
using ERPModel.UserManage;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.EnterpriseManage.SysTalentPools
{
    public class SysTalentPoolImp : ISysTalentPoolImp
    {
        private readonly IMapper _imapper;
        private readonly ISysPersonImp _iSysPersonImp;
        public SysTalentPoolImp(
            IMapper imapper,
            ISysPersonImp iSysPersonImp)
        {
            _imapper = imapper;
            _iSysPersonImp = iSysPersonImp;
        }

        /// <summary>
        /// 分页查询
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        public async Task<(List<TalentPoolDto>, int)> GetByPageAsync(TalentPoolQuery query)
        {
            RefAsync<int> totalCount = 0;

            var list = await SqlSugarHelper.DBClient(query.server_id)
                                .Queryable<SysTalentPool, SysPerson>(
                                    (x, y) => new JoinQueryInfos(
                                        JoinType.Left, x.user_id == y.i_id
                                    ))
                                .Where(query.ToExp())
                                .Mapper(x => x.user_info, x => x.user_id)
                                .Mapper(x => x.department_info, x => x.department_base)
                                .Mapper(x => x.position_info, x => x.position_id)
                                .Mapper(x => {
                                    x.files = SqlSugarHelper.DBClient(query.server_id)
                                                .Queryable<SysFileRecord>()
                                                .Where(f => f.object_id == x.id)
                                                .ToList();
                                    x.file_paths = x.files.Select(f => new file_path()
                                                {
                                                    file_name = f.file_name,
                                                    url = f.url
                                                })
                                                .ToList();
                                })
                                .OrderBy(x => x.created_date, OrderByType.Desc)
                                .ToPageListAsync(query.page_index, query.page_size, totalCount);

            var data = _imapper.Map<List<SysTalentPool>, List<TalentPoolDto>>(list);

            return (data, totalCount);
        }

        /// <summary>
        /// 新增
        /// </summary>
        public async Task<TalentPoolDto> CreateAsync(
            string server_id, decimal? user_id, TalentPoolInput input)
        {
            var info = _imapper.Map<TalentPoolInput, SysTalentPool>(input);

            info.id = Tools.GetEngineID(server_id);
            info.SetCreate(user_id);

            //添加相关文件
            if (input.file_paths != null && input.file_paths.Count > 0)
            {
                var file_list = new List<SysFileRecord>();

                input.file_paths.ForEach(x => {
                    var file = new SysFileRecord()
                    {
                        model = (int)FileRecordType.TALENTPOOL,
                        object_id = info.id,
                        type = 2,
                        file_name = x.file_name,
                        url = x.url,
                        created_id = user_id,
                        created_date = DateTime.Now
                    };
                    file_list.Add(file);
                });

                await SqlSugarHelper.DBClient(server_id).Insertable(file_list).ExecuteCommandAsync();
            }

            var res = await SqlSugarHelper.DBClient(server_id).Insertable(info).ExecuteCommandAsync() > 0;

            //同步人员信息
            if (res && info.is_update == 1)
            {
                var person = await SqlSugarHelper.DBClient(server_id)
                               .Queryable<SysPerson>()
                               .FirstAsync(x => x.i_id == info.user_id);

                if (person != null)
                {
                    var orgs = new List<OrgSlim>();
                    orgs.Add(new OrgSlim() {
                        is_main_org = true,
                        i_org_id = info.department_base
                    });

                    //从属部门
                    var dpList = await SqlSugarHelper.DBClient(server_id)
                                    .Queryable<SysDepPerson>()
                                    .Where(it => it.i_child_id == info.user_id)
                                    .ToListAsync();

                    dpList.ForEach(x => {
                        if (x.i_group_id != info.department_base && x.sign != 1)
                        {
                            orgs.Add(new OrgSlim()
                            {
                                is_main_org = x.sign == 1 ? true : false,
                                i_org_id = x.i_group_id
                            });
                        }
                    });

                    //关联角色
                    var rpList = await SqlSugarHelper.DBClient(server_id)
                                    .Queryable<SysRolePerson, SysRole>(
                                        (a, b) => new JoinQueryInfos(
                                            JoinType.Left, a.i_role_id == b.i_id
                                            ))
                                    .Where((a, b) => a.i_operator_id == info.user_id)
                                    .Where((a, b) => b.type != 3 && b.type != 2)
                                    .ToListAsync();

                    var add_user = new AddUser() {
                        i_id = Convert.ToDecimal(person.i_id),
                        c_login_id = person.c_login_id,
                        c_password = person.c_password,
                        c_name = person.c_name,
                        c_worker_id = person.c_worker_id,
                        i_position_id = info.position_id,
                        c_not_employee = person.c_not_employee,
                        c_state = person.c_state,
                        d_expired = person.d_expired,
                        c_remark = person.c_remark,
                        orgs = orgs,
                        role_ids = rpList.Select(x => Convert.ToDecimal(x.i_role_id)).ToList(),
                        platform = string.IsNullOrWhiteSpace(person.c_platform) ? new List<int>() : 
                            Array.ConvertAll(person.c_platform.Split(","), s => int.Parse(s)).ToList()
                    };

                    await _iSysPersonImp.EditUser(server_id, add_user);
                }
            }

            if (res)
            {
                return _imapper.Map<SysTalentPool, TalentPoolDto>(info);
            }
            return null;
        }

        /// <summary>
        /// 编辑
        /// </summary>
        public async Task<TalentPoolDto> UpdateAsync(
            string server_id, decimal? user_id, TalentPoolInput input)
        {
            var info = await SqlSugarHelper.DBClient(server_id)
                       .Queryable<SysTalentPool>()
                       .FirstAsync(x => x.id == input.id);

            if (info == null)
            {
                throw new Exception($"未找到人才信息，id={input.id}");
            }

            input.id = info.id;
            info.SetUpdate(user_id);
            _imapper.Map(input, info);

            var res = await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync() > 0;

            if (res)
            {
                //删除旧文件
                await SqlSugarHelper.DBClient(server_id)
                    .Deleteable<SysFileRecord>()
                    .Where(x => x.object_id == info.id)
                    .ExecuteCommandAsync();

                //添加相关文件
                if (input.file_paths != null && input.file_paths.Count > 0)
                {
                    var file_list = new List<SysFileRecord>();

                    input.file_paths.ForEach(x => {
                        var file = new SysFileRecord()
                        {
                            model = (int)FileRecordType.TALENTPOOL,
                            object_id = info.id,
                            type = 2,
                            file_name = x.file_name,
                            url = x.url,
                            created_id = user_id,
                            created_date = DateTime.Now
                        };
                        file_list.Add(file);
                    });

                    await SqlSugarHelper.DBClient(server_id).Insertable(file_list).ExecuteCommandAsync();
                }
            }

            //同步人员信息
            if (res && info.is_update == 1)
            {
                var person = await SqlSugarHelper.DBClient(server_id)
                               .Queryable<SysPerson>()
                               .FirstAsync(x => x.i_id == info.user_id);

                if (person != null)
                {
                    var orgs = new List<OrgSlim>();
                    orgs.Add(new OrgSlim()
                    {
                        is_main_org = true,
                        i_org_id = info.department_base
                    });

                    //从属部门
                    var dpList = await SqlSugarHelper.DBClient(server_id)
                                    .Queryable<SysDepPerson>()
                                    .Where(it => it.i_child_id == info.user_id)
                                    .ToListAsync();

                    dpList.ForEach(x => {
                        if (x.i_group_id != info.department_base && x.sign != 1)
                        {
                            orgs.Add(new OrgSlim()
                            {
                                is_main_org = x.sign == 1 ? true : false,
                                i_org_id = x.i_group_id
                            });
                        }
                    });

                    //关联角色
                    var rpList = await SqlSugarHelper.DBClient(server_id)
                                    .Queryable<SysRolePerson, SysRole>(
                                        (a, b) => new JoinQueryInfos(
                                            JoinType.Left, a.i_role_id == b.i_id
                                            ))
                                    .Where((a, b) => a.i_operator_id == info.user_id)
                                    .Where((a, b) => b.type != 3 && b.type != 2)
                                    .ToListAsync();

                    var add_user = new AddUser()
                    {
                        i_id = Convert.ToDecimal(person.i_id),
                        c_login_id = person.c_login_id,
                        c_password = person.c_password,
                        c_name = person.c_name,
                        c_worker_id = person.c_worker_id,
                        i_position_id = info.position_id,
                        c_not_employee = person.c_not_employee,
                        c_school = info.school,
                        c_major = info.major,
                        c_top_education = info.top_education,
                        d_birthday = info.birthday,
                        c_state = person.c_state,
                        d_expired = person.d_expired,
                        c_remark = person.c_remark,
                        orgs = orgs,
                        role_ids = rpList.Select(x => Convert.ToDecimal(x.i_role_id)).ToList(),
                        platform = string.IsNullOrWhiteSpace(person.c_platform) ? new List<int>() :
                            Array.ConvertAll(person.c_platform.Split(","), s => int.Parse(s)).ToList()
                    };

                    await _iSysPersonImp.EditUser(server_id, add_user);
                }
            }

            if (res)
            {
                return _imapper.Map<SysTalentPool, TalentPoolDto>(info);
            }
            return null;
        }

        /// <summary>
        /// 删除
        /// </summary>
        public async Task<bool> DeleteAsync(string server_id, List<decimal> ids)
        {
            var res = await SqlSugarHelper.DBClient(server_id)
                        .Deleteable<SysTalentPool>()
                        .Where(x => ids.Contains(x.id))
                        .ExecuteCommandAsync() > 0;

            if (res)
            {
                //删除相关文件
                await SqlSugarHelper.DBClient(server_id)
                    .Deleteable<SysFileRecord>()
                    .Where(x => ids.Contains(Convert.ToDecimal(x.object_id)))
                    .ExecuteCommandAsync();
            }

            return res;
        }

        /// <summary>
        /// 获取导出数据
        /// </summary>
        public async Task<List<TalentPoolDto>> GetExportDataAsync(string server_id, List<decimal> ids)
        {
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<SysTalentPool, SysPerson>(
                                    (x, y) => new JoinQueryInfos(
                                        JoinType.Left, x.user_id == y.i_id
                                    ))
                                .Where((x, y) => ids.Contains(x.id))
                                .Mapper(x => x.user_info, x => x.user_id)
                                .Mapper(x => x.department_info, x => x.department_base)
                                .Mapper(x => x.position_info, x => x.position_id)
                                .OrderBy(x => x.created_date, OrderByType.Desc)
                                .ToListAsync();

            return _imapper.Map<List<SysTalentPool>, List<TalentPoolDto>>(list);
        }
    }
}
