﻿using ERPModel.EnterpriseManage.SysTalentPools;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.EnterpriseManage.SysTalentPools
{
    public interface ISysTalentPoolImp
    {
        /// <summary>
        /// 分页查询
        /// </summary>
        Task<(List<TalentPoolDto>, int)> GetByPageAsync(TalentPoolQuery query);

        /// <summary>
        /// 新增
        /// </summary>
        Task<TalentPoolDto> CreateAsync(string server_id, decimal? user_id, TalentPoolInput input);

        /// <summary>
        /// 编辑
        /// </summary>
        Task<TalentPoolDto> UpdateAsync(string server_id, decimal? user_id, TalentPoolInput input);

        /// <summary>
        /// 删除
        /// </summary>
        Task<bool> DeleteAsync(string server_id, List<decimal> ids);

        /// <summary>
        /// 获取导出数据
        /// </summary>
        Task<List<TalentPoolDto>> GetExportDataAsync(string server_id, List<decimal> ids);
    }
}
