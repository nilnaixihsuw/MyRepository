﻿using ERPCore.ORM;
using ERPDal.PersonalManage;
using ERPModel.PersonalManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;

namespace ERPBll.PersonalManage
{
    public class SysPersonLifeImp : BusinessRespository<SysPersonLife, ISysPersonLifeDataImp>, ISysPersonLifeImp
    {
        public SysPersonLifeImp(ISysPersonLifeDataImp dataImp): base(dataImp)
        {

        }
    }
}