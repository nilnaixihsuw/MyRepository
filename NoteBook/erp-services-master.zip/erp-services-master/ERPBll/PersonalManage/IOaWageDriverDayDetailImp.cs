﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPModel.ApiModel.PersonalManage;
using ERPModel.PersonalManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.PersonalManage
{
    public interface IOaWageDriverDayDetailImp : IBusinessRepository<OaWageDriverDayDetail>
    {
        Task<bool> AddOaWageDriverDayDetail(string server_id, OaWageDriverDayDetail context, ClientInformation client);
        Task<Tuple<List<OaWageDriverDayDetail>,int>> QueryOaWageDriverDayDetailPageList(string server_id, SalaryListRequest request, string v);
        Task<List<OaWageDriverDayDetail>> QueryOaWageDriverDayDetailList(string server_id, SalaryListRequest request, string v);
        Task<bool> BatchDelete(string server_id, List<decimal> context);
        Task<(List<OaWageDriverDayDetail>, int, Dictionary<string, object>)> QuerySalaryDetailPage(string server_id, SalaryListRequest request, string v);
        Task<(List<OaWageDriverDayDetail>, Dictionary<string, object>)> QuerySalaryDetail(string server_id, SalaryListRequest request, string v);
        Task<(List<SalayDailyQueryByEmpDto>, int, Dictionary<string, object>)> QuerySalaryByEmpPage(string server_id, SalaryListRequest request, string v);
        Task<(List<SalayDailyQueryByEmpDto>, Dictionary<string, object>)> QuerySalaryByEmp(string server_id, SalaryListRequest request, string v);
    }
}