﻿using ERPCore.ORM;
using ERPModel.PersonalManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.PersonalManage
{
    public interface ISysPersonLifeImp : IBusinessRepository<SysPersonLife>
    {
    }
}