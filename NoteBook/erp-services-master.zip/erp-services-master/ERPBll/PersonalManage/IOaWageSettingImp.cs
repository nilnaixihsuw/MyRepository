﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPModel.ApiModel.PersonalManage;
using ERPModel.PersonalManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.PersonalManage
{
    public interface IOaWageSettingImp : IBusinessRepository<OaWageSetting>
    {
        Task<bool> AddOaWageSetting(string server_id, OaWageSetting context, ClientInformation client);
        Task<bool> AddOaWageSettingBatch(string server_id, List<OaWageSetting> context, ClientInformation client);
        Task<Tuple<List<OaWageSetting>,int>> QueryOaWageSettingPageList(string server_id, BaseRequest<OaWageSetting> request, string v);
        Task<List<OaWageSetting>> QueryOaWageSettingList(string server_id, BaseRequest<OaWageSetting> request, string v);
        Task<bool> BatchDelete(string server_id, List<decimal> context);
    }
}