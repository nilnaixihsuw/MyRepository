﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPModel.ApprovalForm;
using ERPModel.PersonalManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.PersonalManage
{
    public interface IOaWorkOvertimeImp : IBusinessRepository<OaWorkOvertime>
    {
        Task<bool> AddOaWorkOvertime(string server_id, OaWorkOvertime context, ClientInformation client);
        Task<Tuple<List<OaWorkOvertime>,int>> QueryOaWorkOvertimePageList(string server_id, BaseRequest<OaWorkOvertime> request, string v);
        Task<List<OaWorkOvertime>> QueryOaWorkOvertimeList(string server_id, BaseRequest<OaWorkOvertime> request, string v);
        Task<bool> BatchDelete(string server_id, List<decimal> context);
    }
}