﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPModel.PersonalManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.PersonalManage
{
    public interface IOaWageSettingDetailImp : IBusinessRepository<OaWageSettingDetail>
    {
        Task<bool> AddOaWageSettingDetail(string server_id, OaWageSettingDetail context, ClientInformation client);
        Task<Tuple<List<OaWageSettingDetail>,int>> QueryOaWageSettingDetailPageList(string server_id, BaseRequest<OaWageSettingDetail> request, string v);
        Task<List<OaWageSettingDetail>> QueryOaWageSettingDetailList(string server_id, BaseRequest<OaWageSettingDetail> request, string v);
        Task<bool> BatchDelete(string server_id, List<decimal> context);
    }
}