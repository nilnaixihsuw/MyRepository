﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ERPBll.Caps
{
    ///事件消息
    public class EventMessages
    {
        private const string Message = "erp.services.";

        #region 维修事件

        /// <summary>
        /// 维修检验消息
        /// </summary>
        public const string RepairCheck = Message + "repair_check";

        /// <summary>
        /// 工单状态更新
        /// </summary>
        public const string OrderStateUpdate = Message + "order_state_update";

        /// <summary>
        /// 维修生命周期更新
        /// </summary>
        public const string RepairLifeUpdate = Message + "repair_life";

        #endregion

        #region 流程事件

        /// <summary>
        /// 流程状态变更消息
        /// </summary>
        public const string FlowStateUpdate = Message + "flow_state_update";

        /// <summary>
        /// 流程待审批节点变更消息
        /// </summary>
        public const string FlowStepUpdate = Message + "flow_step_update";

        /// <summary>
        /// 节点状态变更消息
        /// </summary>
        public const string StepStateUpdate = Message + "step_state_update";

        #endregion

        #region 审批完成事件

        /// <summary>
        /// 会议室
        /// </summary>
        public const string MeetingFinish = Message + "meeting_finish";

        /// <summary>
        /// 公车借记    
        /// </summary>
        public const string BusBorrowFinish = Message + "bus_borrow_finish";

        /// <summary>
        /// 还车
        /// </summary>
        public const string BusReturnFinish = Message + "bus_return_finish";

        /// <summary>
        /// 发文
        /// </summary>
        public const string DocumentMainFinish = Message + "document_main_finish";

        /// <summary>
        /// 收文
        /// </summary>
        public const string DocumentAcceptFinish = Message + "document_accept_finish";

        /// <summary>
        /// 党建会员
        /// </summary>
        public const string PartyMemberFinish = Message + "party_member_finish";

        /// <summary>
        /// 事故
        /// </summary>
        public const string AccidentFinish = Message + "accident_finish";

        /// <summary>
        /// 请假
        /// </summary>
        public const string RestFinish = Message + "rest_finish";

        /// <summary>
        /// 加班
        /// </summary>
        public const string WorkOvertimeFinish = Message + "work_overtime_finish";

        #endregion

        public const string MessagePush = Message + "message_push";

        /// <summary>
        /// 成长记录
        /// </summary>
        public const string GrowthRecord = Message + "growth_record";

        /// <summary>
        /// 采购
        /// </summary>
        public const string PurchaseFinish = Message + "purchase_finish";

        /// <summary>
        /// 采购单
        /// </summary>
        public const string PurchaseOrderFinish = Message + "purchase_order_finish";
    }
}
