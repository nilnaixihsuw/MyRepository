﻿using ERPDal;
using ERPModel.BusServer;
using ERPModel.BusServer.Dto;
using ERPModel.DataBase;
using ERPModel.TicketManage;
using ERPModel.Vehicleinfomanage;
using OADal;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LineInfo = ERPModel.BusServer.Dto.LineInfo;

namespace ERPBll.BusServer
{
    public class BusServerImp : IBusServerImp
    {
        public async Task<List<BusInfo>> GetBuses()
        {
            var dic = await SqlSugarHelper.DBClient("60.191.59.11").Queryable<SysCommonDictDetail>().ToListAsync();
            var vehicles = await SqlSugarHelper.DBClient("60.191.59.11").Queryable<VehicleInfoNew>().ToListAsync();
            var kinds = await SqlSugarHelper.DBClient("60.191.59.11").Queryable<MaintVehicleKind>().ToListAsync();
            var list = new List<BusInfo>();
            kinds.ForEach(r =>
            {
                var temp = new BusInfo();
                temp.name = r.c_name;
                temp.fuel = string.IsNullOrEmpty(r.c_fuel) ? "" : dic.Find(m => m.i_id == Convert.ToDecimal(r.c_fuel))?.c_name;
                temp.seat_count = r.i_seats_count;
                temp.count = vehicles.Count(m => m.cid == r.i_id);
                temp.lp_nums = vehicles.Where(m => m.cid == r.i_id).Select(r => r.lp_num).ToList();
                list.Add(temp);
            });
            return list;
        }

        public async Task<List<StationInfo>> GetStations()
        {
            var stations = await SqlSugarHelper.DBClient("bus_server").Queryable<BUS_STATION>().ToListAsync();
            var list = new List<StationInfo>();
            stations.ForEach(r =>
            {
                var temp = new StationInfo();
                temp.id = r.i_id;
                temp.name = r.c_name;
                temp.latitude = r.n_latitude;
                temp.longitude = r.n_longitude;
                list.Add(temp);
            });
            return list;
        }

        public async Task<List<LineInfo>> GetLines()
        {
            var DB = SqlSugarHelper.DBClient("bus_server");
            var lines = await DB.Queryable<POLYGONINFO>().ToListAsync();
            var line_stations= await DB.Queryable<LineStation>().ToListAsync();
            var stations = await DB.Queryable<STATIONINFO>().ToListAsync();
            var group = line_stations.GroupBy(r => r.i_lineid);
            var list = new List<LineInfo>();
            foreach (var item in group)
            {
                var temp = new LineInfo();
                temp.id = item.Key;
                temp.name = lines.Find(r => r.id == item.Key)?.name;
                temp.stations = new List<line_station>();
                foreach (var item1 in item.ToList())
                {
                    var temp1 = new line_station();
                    temp1.station_id = item1.i_stationid;
                    temp1.station_name = stations.Find(r => r.id == temp1.station_id)?.name;
                    temp1.seq = item1.i_seq;
                    temp1.type = item1.i_type;
                    temp.stations.Add(temp1);
                }
                temp.stations = temp.stations.OrderBy(r => r.type).ThenBy(r => r.seq).ToList();
                list.Add(temp);
            }
            return list;
        }

        public async Task<List<TimeBus>> GetTimeBuses()
        {
            var list = await SqlSugarHelper.DBClient("bus_server").Queryable<VEHICLERUNNINGRECORD, Fitting, VehicleTerminal>((a, b, c) => new JoinQueryInfos(
                JoinType.Left, a.id == b.vehicleid, JoinType.Left, b.terminalid == c.id))
                .Select((a, b, c) => new TimeBus
                {
                    lp_num = c.dev_no,
                    latitude = a.lastvalid_latitude,
                    longitude = a.lastvalid_longitude
                }).ToListAsync();
            var vehicles = await SqlSugarHelper.DBClient("60.191.59.11").Queryable<VehicleInfoNew>()
                .Mapper(r => r.vehicle_kind_info, r => r.cid).ToListAsync();
            list.ForEach(r => r.kind_name = vehicles.Find(m => m.lp_num == r.lp_num)?.vehicle_kind_info?.c_name);
            return list;
        }

        public async Task<List<EStationInfo>> GetEStations()
        {
            var estations = await SqlSugarHelper.DBClient("bus_server").Queryable<e_station_info>().ToListAsync();
            var list = new List<EStationInfo>();
            estations.ForEach(r =>
            {
                var temp = new EStationInfo();
                temp.id = r.i_id;
                temp.name = r.c_name;
                temp.latitude = r.n_lat;
                temp.longitude = r.n_lng;
                temp.is_online = r.d_last_active.HasValue && r.d_last_active.Value.AddMinutes(5) >= DateTime.Now ? 1 : 0;
                list.Add(temp);
            });
            return list;
        }

        public async Task<List<DayOperate>> GetDayOperateData(DateTime date)
        {
            var DB = SqlSugarHelper.DBClient("bus_server");
            var record = await DB.Queryable<DispatchRecord>()
                .Where(r => r.d_time_start_dispatch.HasValue && r.d_time_start_dispatch.Value.ToString("yyyy-MM-dd") == date.ToString("yyyy-MM-dd")).ToListAsync();
            var b = await DB.Queryable<Fitting, VehicleTerminal>((a, b) => new JoinQueryInfos(JoinType.Left, a.terminalid == b.id))
               .Select((a, b) => new
               {
                   id = a.vehicleid,
                   lp_num = b.dev_no
               }).ToListAsync();
            var list = new List<DayOperate>();

            string  sql = $"select * from pos_data_detail_{date.ToString("yyyyMM")} a where to_char(txndate,'yyyy-MM-dd')='{date.ToString("yyyy-MM-dd")}' ";
            var a = SqlSugarHelper.DBClient("60.191.59.11").Ado.SqlQuery<PosDataDetail>(sql);//刷卡数据
            var vehicles = await SqlSugarHelper.DBClient("60.191.59.11").Queryable<VehicleInfoNew>().ToListAsync() ;

            foreach (var item in record.GroupBy(r => r.i_vehicle_id))
            {
                var temp = new DayOperate();
                temp.id = item.Key;
                temp.lp_num = b.Find(r => r.id == temp.id)?.lp_num;
                temp.bc_count = item.Count();
                temp.start = item.Min(r => r.d_time_start_dispatch);
                temp.end = item.Max(r => r.d_time_start_dispatch);
                if (vehicles.Exists(r => r.lp_num == temp.lp_num))
                {
                    var c = a.Where(r => r.vehicle_id == vehicles.Find(m => m.lp_num == temp.lp_num).id).ToList();

                    temp.data = c.GroupBy(r => new { r.cardno }).Select(r => new cardInfo
                    {
                        cardno = r.Key.cardno,
                        card_type = r.ToList()[0].cardmaintype,
                        card_type_child = r.ToList()[0].cardchildtype,
                        count = r.Count()
                    }).ToList();
                }
                //temp.data = a.Where(r => r.vehicle_id == item.Key).ToList();
                list.Add(temp);
            }
            return list;
        }

        public async Task<List<Dispatch>> GetDispatchData(DateTime time)
        {
            var DB = SqlSugarHelper.DBClient("bus_server");
            var record = await DB.Queryable<DispatchRecord>()
                .Where(r => r.d_time_start_dispatch.HasValue && r.d_time_start_dispatch.Value.ToString("yyyy-MM-dd") == time.ToString("yyyy-MM-dd")).ToListAsync();
            var b = await DB.Queryable<Fitting, VehicleTerminal>((a, b) => new JoinQueryInfos(JoinType.Left, a.terminalid == b.id))
               .Select((a, b) => new
               {
                   id = a.vehicleid,
                   lp_num = b.dev_no
               }).ToListAsync();
            var list = new List<Dispatch>();

            foreach (var item in record)
            {
                var temp = new Dispatch();
                temp.time_start = item.d_time_start_dispatch;
                temp.time_end = item.d_time_arrive_dispatch;
                temp.lp_num = b.Find(r => r.id == item.i_vehicle_id)?.lp_num;
                list.Add(temp);
            }
            return list;
        }
    }
}
