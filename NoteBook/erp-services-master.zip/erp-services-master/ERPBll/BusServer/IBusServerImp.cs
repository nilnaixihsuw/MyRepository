﻿using ERPModel.BusServer.Dto;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.BusServer
{
    public interface IBusServerImp
    {
        /// <summary>
        /// 获取车辆信息
        /// </summary>
        /// <returns></returns>
        Task<List<BusInfo>> GetBuses();
      
        /// <summary>
        /// 获取站台信息
        /// </summary>
        /// <returns></returns>
        Task<List<StationInfo>> GetStations();
        /// <summary>
        /// 获取线路信息
        /// </summary>
        /// <returns></returns>
        Task<List<LineInfo>> GetLines();

        /// <summary>
        /// 获取电子站台信息
        /// </summary>
        /// <returns></returns>
        Task<List<EStationInfo>> GetEStations();

        /// <summary>
        /// 获取实时车辆信息
        /// </summary>
        /// <returns></returns>
        Task<List<TimeBus>> GetTimeBuses();
        /// <summary>
        /// 获取日营运信息
        /// </summary>
        /// <returns></returns>
        Task<List<DayOperate>> GetDayOperateData(DateTime date);

        /// <summary>
        /// 获取排班数据
        /// </summary>
        /// <param name="time"></param>
        /// <returns></returns>
        Task<List<Dispatch>> GetDispatchData(DateTime time);
    }
}
