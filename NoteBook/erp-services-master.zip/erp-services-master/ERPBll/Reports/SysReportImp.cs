﻿using AutoMapper;
using ERPDal;
using ERPModel.Reports;
using Newtonsoft.Json;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ERPBll.Reports
{
    /// <summary>
    /// 自定义报表
    /// </summary>
    public class SysReportImp: ISysReportImp
    {
        private readonly IMapper _imapper;

        public SysReportImp(IMapper imapper)
        {
            _imapper = imapper;
        }

        public async Task<(Dictionary<string, string>, List<object>, int)> GetReportBySqlAsync(ReportQuery query)
        {
            string sql = query.sql.ToLower();
            var tables = Tools.GetTableNameBySql(sql);
            if (tables.Count < 1)
            {
                throw new Exception("无法解析表名，请确认表名是否有别名");
            }

            var parameters = new List<SugarParameter>();
            if (query.query != null)
            {
                foreach (var item in query.query)
                {
                    parameters.Add(new SugarParameter(item.Key, item.Value));
                }
            }
            
            try
            {
                RefAsync<int> total = 0;
                var list = await SqlSugarHelper.DBClient(query.server_id)
                            .SqlQueryable<object>(sql)
                            .AddParameters(parameters)
                            .ToPageListAsync(query.page_index, query.page_size, total);
                if(list == null || list.Count < 1)
                {
                    throw new Exception("查无数据");
                }

                string json = JsonConvert.SerializeObject(list[0]);
                var columns = JsonConvert.DeserializeObject<Dictionary<string, string>>(json);

                var columnNames = Tools.GetFieldNameByTable(query.server_id, tables, columns);
                return (columnNames, list, total);
            }
            catch (Exception ex)
            {
                throw new SqlSugarException(ex.Message); 
            }
        }

        public async Task<List<SysReportDto>> GetAllAsync(string server_id)
        {
            var report = await SqlSugarHelper.DBClient(server_id)
                            .Queryable<SysReport>()
                            .ToListAsync();

            return _imapper.Map<List<SysReportDto>>(report);
        }

        public async Task<(Dictionary<string, string>, List<object>, int)> GetReportByCodeAsync(ReportQuery query)
        {
            var report = await SqlSugarHelper.DBClient(query.server_id)
                            .Queryable<SysReport>()
                            .FirstAsync(x => x.code == query.code);
            if(report == null)
            {
                throw new Exception("报表不存在");
            }

            var parameters = new List<SugarParameter>();
            
            if (query.query != null)
            {
                foreach (var item in query.query)
                {
                    parameters.Add(new SugarParameter(item.Key, item.Value));
                }
            }

            RefAsync<int> total = 0;
            var list = await SqlSugarHelper.DBClient(query.server_id)
                        .SqlQueryable<object>(report.sql)
                        .AddParameters(parameters)
                        .ToPageListAsync(query.page_index, query.page_size, total);

            return (JsonConvert.DeserializeObject<Dictionary<string, string>>(report.langs), list, total);
        }

        public async Task AddReportAsync(string server_id, decimal? user_id, CreateOrUpdateReport create)
        {
            var count = await SqlSugarHelper.DBClient(server_id)
                           .Queryable<SysReport>()
                           .CountAsync(x => x.code == create.code && x.id != create.id);
            if(count > 0)
            {
                throw new Exception("报表编号重复");
            }

            var info = _imapper.Map<CreateOrUpdateReport, SysReport>(create);
            info.id = ERPBll.Tools.GetEngineID(server_id);
            info.SetCreate(user_id);

            await SqlSugarHelper.DBClient(server_id).Insertable(info).ExecuteCommandAsync();
        }

        public async Task UpdateAsync(string server_id, decimal? user_id, CreateOrUpdateReport input)
        {
            var info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<SysReport>().FirstAsync(x => x.id == input.id);
            if (info == null)
            {
                throw new Exception($"未找到报表记录，id={input.id}");
            }
            _imapper.Map<CreateOrUpdateReport, SysReport>(input, info);
            info.SetUpdate(user_id);

            await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync();
        }
    }
}
