﻿using ERPModel.Reports;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.Reports
{
    public interface ISysReportImp
    {
        /// <summary>
        /// 获取全部
        /// </summary>
        Task<List<SysReportDto>> GetAllAsync(string server_id);

        /// <summary>
        /// 根据sql获取
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        Task<(Dictionary<string, string>, List<object>, int)> GetReportBySqlAsync(ReportQuery query);

        /// <summary>
        /// 根据报表编号获取
        /// </summary>
        Task<(Dictionary<string, string>, List<object>, int)> GetReportByCodeAsync(ReportQuery query);

        /// <summary>
        /// 新增
        /// </summary>
        Task AddReportAsync(string server_id, decimal? user_id, CreateOrUpdateReport create);

        /// <summary>
        /// 修改
        /// </summary>
        Task UpdateAsync(string server_id, decimal? user_id, CreateOrUpdateReport input);
    }
}
