﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPModel.FormManage;
using ERPModel.Response;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.FormManage
{
    public interface IErpCustFlowClassifyImp : IBusinessRepository<ErpCustFlowClassify>
    {
        Task<bool> Insertable(string server_id, List<ErpCustFlowClassify> context, IClientInformation client);
        Task<List<ErpCustFlowClassify>> QueryGroup(string server_id);
        Task<bool> GroupSort(string server_id, List<ErpCustFlowClassify> context);
        Task<bool> DeleteGroup(string server_id, List<object> list);
        Task<List<FormSortGroup>> GetFormSortGroupList(string server_id, string form_name);
        Task<List<FormSortGroup>> FormSortList(string id, string server_id);
    }
}
