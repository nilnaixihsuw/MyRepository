﻿using ERPCore.ORM;
using ERPModel.FormManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.FormManage
{
    public interface IErpCustFormDetailImp : IBusinessRepository<ErpCustFormDetail>
    {
    }
}