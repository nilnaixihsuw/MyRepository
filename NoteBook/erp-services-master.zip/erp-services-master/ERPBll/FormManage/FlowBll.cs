﻿using ERPBll.UserManage;
using ERPDal;
using ERPDal.FormManage;
using ErpModel.FormManage;
using ERPModel.FormManage;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ErpBll.FormManage
{
    public class FlowBll
    {
        #region 插入
        /// <summary>
        /// 插入流程原始数据
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="form_id"></param>
        /// <param name="source_data"></param>
        /// <param name="flow_name"></param>
        /// <param name="remark"></param>
        /// <returns></returns>
        public static DataTable AddFlowInfo(string serverID, string form_id, string source_data, string flow_name, string remark)
        {
            return FlowDal.addFlowInfo(serverID, form_id, source_data, flow_name, remark);
        }
        public static long AddFlowInfo(ErpCustFlow info, string serverID)
        {
            SqlSugarHelper.DBClient(serverID).Insertable(info).ExecuteCommand();
            return SqlSugarHelper.DBClient(serverID).Queryable<ErpCustFlow>().Where(r => r.c_table_id == info.c_table_id).First().i_id;
        }
        /// <summary>
        /// 插入流程顺序节点数据
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static string AddFlowSequence(string serverID, Sequence obj)
        {
            return FlowDal.addFlowSequence(serverID, obj);
        }
        /// <summary>
        /// 插入流程条件节点相关数据
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="main_id"></param>
        /// <param name="list"></param>
        /// <returns></returns>
        public static string AddFlowCondition(string serverID, string main_id, List<conditContent> list)
        {
            return FlowDal.addFlowCondition(serverID, main_id, list);
        }
        //public static bool addFlowCopy(string serverID, string main_id, List<string> user_ids)
        //{
        //    return FlowDal.addFlowCopy(serverID,main_id,user_ids);
        //}
        
        /// <summary>
        /// 插入流程字段可见性数据
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="list"></param>
        /// <returns></returns>
        public static bool AddFlowField(string serverID, List<Fieled> list)
        {
            return FlowDal.addFlowField(serverID, list);
        }
        //public static bool addFlowUserInfo(string serverID, List<UserInfo> infos)
        //{
        //    return FlowDal.addFlowUserInfo(serverID, infos);
        //}
        
        /// <summary>
        /// 插入流程节点绑定相关数据（发起，审批，抄送）
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="infos"></param>
        /// <returns></returns>
        public static bool AddFlowUserInfo(string serverID, List<ErpCustFlowUserInfo> infos)
        {
            int res = SqlSugarHelper.DBClient(serverID).Insertable(infos).IgnoreColumns(r=>r.i_id).ExecuteCommand();
            if (res > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        #endregion

        #region 修改
        /// <summary>
        /// 更新流程原始json数据
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="form_id"></param>
        /// <param name="source_data"></param>
        /// <param name="flow_name"></param>
        /// <param name="remark"></param>
        /// <returns></returns>
        public static DataTable UpdateFlowInfo(string serverID, string form_id, string source_data, string flow_name, string remark)
        {
            return FlowDal.updateFlowInfo(serverID, form_id, source_data, flow_name, remark); ;
        }
        public static int UpdateFlowInfo(string serverID, ErpCustFlow info)
        {
            return SqlSugarHelper.DBClient(serverID).Updateable(info).IgnoreColumns(new string[] { "i_use" }).ExecuteCommand();
        }
        public static bool UpdateSequenceConditionId(string serverID, string i_id, string conditionid)
        {
            return FlowDal.updateSequenceConditionId(serverID, i_id, conditionid);
        }
        #endregion

        #region 获取
        //public static DataTable GetFlowStructData(string serverID, string form_id)
        //{
        //    return FlowDal.getFlowStructData(serverID, form_id);
        //}
        public static DataTable GetFlowInfo(string serverID, string formid)
        {
            return FlowDal.getFlowInfo(serverID, formid);
        }
        public static DataTable GetFlowSequence(string serverID, string flowid)
        {
            return FlowDal.getFlowSequence(serverID,flowid);
        }
       
        public static DataTable GetFlowCondition(string serverID, string main_id)
        {
            return FlowDal.getFlowCondition(serverID,main_id);
        }
        //public static DataTable GetFlowCopy(string serverID, string main_id)
        //{
        //    return FlowDal.getFlowCopy(serverID,main_id);
        //}
        public static DataTable GetFlowField(string serverID, string main_id)
        {
            return FlowDal.getFlowField(serverID,main_id);
        }
        /// <summary>
        /// 获取流程节点相关人员
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="main_id">主表ID ERP_CUST_FLOW_SEQUNCE 表的I_ID</param>
        /// <param name="type">1：审批指定人员ID，3：抄送指定人员ID，4：发起人指定人员</param>
        /// <returns></returns>
        public static List<ErpCustFlowUserInfo> GetFlowUserInfo(string serverID, int main_id, int type = 0)
        {
            return SqlSugarHelper.DBClient(serverID).Queryable<ErpCustFlowUserInfo>()
                .Where(r => r.i_main_id == main_id)
                .WhereIF(type != 0, r => r.i_type == type).ToList();
        }
       

        /// <summary>
        /// 获取同级条件节点
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="main_id">流程ID</param>
        /// <param name="previd">上级节点ID</param>
        /// <returns></returns>
        public static List<ErpCustFlowSequnce> GetConNode(string serverID, int main_id, string previd)
        {
            return SqlSugarHelper.DBClient(serverID).Queryable<ErpCustFlowSequnce>()
                .Where(r => r.i_main_id == main_id && r.c_previd == previd).ToList();
        }
        /// <summary>
        /// 获取全部流程节点
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="flowid"></param>
        /// <returns></returns>
        public static List<ErpCustFlowSequnce> GetFlowSequence(string serverID, decimal flowid)
        {
            return SqlSugarHelper.DBClient(serverID).Queryable<ErpCustFlowSequnce>()
                .Where(r => r.i_main_id == flowid).OrderBy(r => r.i_id).ToList();
        }
        public static List<ErpCustFlowCondition> GetFlowCondition1(string serverID, string main_id)
        {
            return SqlSugarHelper.DBClient(serverID).Queryable<ErpCustFlowCondition>()
                .Where(r => r.i_main_id == Convert.ToDecimal(main_id)).ToList();
        }

        /// <summary>
        /// 获取某一节点相关人员
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="node_id">节点ID</param>
        /// <param name="user_id">登陆人员ID</param>
        /// <param name="submit_id">发起人员ID</param>
        /// <returns></returns>
        public static List<decimal> GetNodePerson(string serverID, decimal node_id,decimal user_id, decimal submit_id)
        {
            var record = SqlSugarHelper.DBClient(serverID).Queryable<ErpCustFlowSequnce>().Where(r => r.i_id == node_id).ToList();
            if (record == null || record.Count == 0) throw new Exception("该节点不存在");
            if (record.First().i_user_type == 1)
            {
                var list1 = GetFlowUserInfo(serverID, (int)node_id);
                return list1.Select(r => r.i_user_id).ToList();
            }
            else if (record.First().i_user_type == 2)
            {
                if(submit_id == 0)
                {
                    return new List<decimal>() { -1 };
                }
                decimal dept_id = (decimal)DeptInfoBll.GetPersonById(serverID, submit_id).i_department_base;
                var manager_id = DeptInfoBll.GetDeptInfo(serverID, dept_id).manager_id;
                if(manager_id == "0")
                {
                    return new List<decimal>() { submit_id };
                }
                return new List<decimal>() { Convert.ToDecimal(manager_id) };
            }
            else if (record.First().i_user_type == 3)
            {
                var list1 = GetFlowUserInfo(serverID, (int)node_id);
                if (list1.Count > 0)
                {
                    var users = RoleInfoBll.GetRolePerson(serverID, Convert.ToDecimal(list1[0].i_user_id));
                    return users.Select(r => r.user_id).ToList();
                }
                else
                {
                    return new List<decimal>();
                }
            }
            else
            {
                return new List<decimal>();
            }
        }
        #endregion

        #region 删除
        public static bool DeleteFlowInfo(string serverID, string formid)
        {
            return FlowDal.deleteFlowInfo(serverID, formid);
        }
        /// <summary>
        /// 根据流程ID删除流程主表数据
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="flowid"></param>
        /// <returns></returns>
        public static bool DeleteFlowInfoByID(string serverID, string flowid)
        {
            int res = SqlSugarHelper.DBClient(serverID).Deleteable<ErpCustFlow>()
                .Where(r => r.i_id == Convert.ToDecimal(flowid))
                .ExecuteCommand();
            if (res > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public static bool DeleteFlowSequence(string serverID, string flowid)
        {
            return FlowDal.deleteFlowSequence(serverID, flowid);
        }
        public static bool DeleteFlowCondition(string serverID, string main_id)
        {
            return FlowDal.deleteFlowCondition(serverID, main_id);
        }
        //public static bool DeleteFlowCopy(string serverID, string main_id)
        //{
        //    return FlowDal.deleteFlowCopy(serverID, main_id);
        //}
        public static bool DeleteFlowField(string serverID, string main_id)
        {
            return FlowDal.deleteFlowField(serverID, main_id);
        }
        public static bool DeleteFlowUserInfo(string serverID, int main_id,int type)
        {
            int res = SqlSugarHelper.DBClient(serverID).Deleteable<ErpCustFlowUserInfo>()
                .Where(r => r.i_main_id == main_id && r.i_type == type)
                .ExecuteCommand();
            if (res > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool DeleteRelateData(string serverID, List<int> main_ids)
        {
            int res = SqlSugarHelper.DBClient(serverID).Deleteable<ErpCustFlowCondition>().In(r => r.i_main_id, main_ids).ExecuteCommand();
            res += SqlSugarHelper.DBClient(serverID).Deleteable<ErpCustFlowUserInfo>().In(r => r.i_main_id, main_ids).ExecuteCommand();
            res += SqlSugarHelper.DBClient(serverID).Deleteable<ErpCustFlowField>().In(r => r.i_main_id, main_ids).ExecuteCommand();
            if (res > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        #endregion

        /// <summary>
        /// 获取全部表单，流程数据
        /// </summary>
        /// <param name="serverId"></param>
        /// <returns></returns>
        public static List<Flow_Form> GetAllFlow(string serverId)
        {
            var list = SqlSugarHelper.DBClient(serverId).Queryable<ErpCustFlow, ErpCustFormMain>(
                (cfw, cfm) => new JoinQueryInfos(JoinType.Left, Convert.ToInt32(cfw.c_table_id) == cfm.i_id))
                .Select((cfw, cfm) => new Flow_Form
                {
                    flow_id = (int)cfw.i_id,
                    flow_name = cfw.flow_name,
                    table_id = cfw.c_table_id,
                    table_name = cfm.c_form_name,
                    usable = cfw.i_use.ToString(),
                    table_data = cfm.c_json_origin,
                    flow_data = cfw.c_json_origin,
                    flow_remark = cfw.remark,
                    type = cfw.type
                }).ToList();
            return list;
        }
    }
}
