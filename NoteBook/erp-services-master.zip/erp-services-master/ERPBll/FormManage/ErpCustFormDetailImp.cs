﻿using ERPCore.ORM;
using ERPDal.FormManage;
using ERPModel.FormManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;

namespace ERPBll.FormManage
{
    public class ErpCustFormDetailImp : BusinessRespository<ErpCustFormDetail, IErpCustFormDetailDataImp>, IErpCustFormDetailImp
    {
        public ErpCustFormDetailImp(IErpCustFormDetailDataImp dataImp): base(dataImp)
        {

        }
    }
}