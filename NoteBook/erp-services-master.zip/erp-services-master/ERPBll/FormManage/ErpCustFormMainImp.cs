﻿using ERPCore.Entity;
using ERPCore.Extensions;
using ERPCore.ORM;
using ERPDal.FormManage;
using ERPModel.FormManage;
using ERPModel.Response;
using ERPModel.Request;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.FormManage
{
    public class ErpCustFormMainImp : BusinessRespository<ErpCustFormMain, IErpCustFormMainDataImp>, IBusinessRepository<ErpCustFormMain>, IErpCustFormMainImp
    {
        private readonly IErpCustFlowClassifyImp _iErpCustFlowClassifyImp;
        private readonly IErpCustFlowFormClassifyImp _iErpCustFlowFormClassifyImp;
        private readonly IErpCustFormDetailImp _iErpCustFormDetailImp;

        public ErpCustFormMainImp(IErpCustFormDetailImp iErpCustFormDetailImp, IErpCustFormMainDataImp dataImp, IErpCustFlowClassifyImp iERP_CUST_FLOW_CLASSIFY_Imp, IErpCustFlowFormClassifyImp iERP_CUST_FLOW_FORM_CLASSIFY_Imp) : base(dataImp)
        {
            _iErpCustFlowClassifyImp = iERP_CUST_FLOW_CLASSIFY_Imp;
            _iErpCustFlowFormClassifyImp = iERP_CUST_FLOW_FORM_CLASSIFY_Imp;
            _iErpCustFormDetailImp = iErpCustFormDetailImp;
        }

        public async Task<bool> FormSort(string serverId, List<FormSortItem> list)
        {
            return await _dataImp.AdjustFormSort(serverId, list);
        }

        /// <summary>
        /// 编辑表单
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task<bool> EditForm(string serverId, EditForm form, IClientInformation client)
        {
            //修改自定义表单分组表
            var customTableClassify = new ErpCustFlowFormClassify
            {
                i_id = form.form_classify_id,
                i_classify_id = form.classify_id,
            };
            //修改自定义表单主表
            var customTable = new ErpCustFormMain
            {
                i_id = form.id,
                c_form_name = form.form_name,
                c_remark = form.remark,
                c_json_origin = form.source_data,
            };

            var exisitCtds = await _iErpCustFormDetailImp.List(serverId, it => it.i_main_id == form.id && it.i_sign == 1);
            //更新自定表单明细标记
            var upList = exisitCtds.Except(exisitCtds.Where(it => form.info.Select(it => it.form_id.ToString()).Contains(it.c_id))).ToList();
            upList.ForEach(item =>
            {
                item.i_sign = 0;
            });

            var inList = form.info.Except(form.info.Where(it => exisitCtds.Select(it => it.c_id).Contains(it.form_id.ToString()))).ToList();
            //新增自定义表单明细
            var customTableDetails = new List<ErpCustFormDetail>();
            inList.ForEach(item =>
            {
                var e = new ErpCustFormDetail
                {
                    i_id = _dataImp.GetId(serverId, "SEQ_COMMON").Result,
                    c_column_type = item.column_type,
                    c_title = item.column_name,
                    c_id = item.form_id.ToString(),
                    i_sequnce = 1,
                    d_create = DateTime.Now.ToLocalTime(),
                    i_creator = client.i_id,
                    i_sign = 1
                };
                customTableDetails.Add(e);
            });

            return await _dataImp.EditForm(serverId, customTable, customTableClassify, customTableDetails, upList);
        }

        /// <summary>
        /// 创建表单
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="table"></param>
        /// <returns></returns>
        public async Task<bool> CreateForm(string serverId, NewForm table, IClientInformation client)
        {
            //获取最大序号
            var maxSort = Max(serverId, iterator => true, it => it.i_sort.Value).Result;
            //新增自定义表单主表
            var customTable = new ErpCustFormMain
            {
                i_id = _dataImp.GetId(serverId, "SEQ_COMMON").Result,
                c_form_name = table.form_name,
                d_create = DateTime.Now.ToLocalTime(),
                i_creator = 123,
                c_remark = table.remark,
                c_json_origin = table.source_data,
                i_sort = maxSort + 1,
                i_enabled = 1,
                i_visible = 3
            };
            //新增自定义表单分组表
            var customTableClassify = new ErpCustFlowFormClassify
            {
                i_id = _dataImp.GetId(serverId, "SEQ_COMMON").Result,
                i_classify_id = table.classify_id,
                d_create = DateTime.Now.ToLocalTime(),
                i_creator = client.i_id
            };

            //新增自定义表单明细
            var customTableDetails = new List<ErpCustFormDetail>();
            if (table.info == null || table.info.Count == 0)
                throw new Exception("缺少必要参数info");
            table.info.ForEach(item =>
            {
                var e = new ErpCustFormDetail
                {
                    i_id = _dataImp.GetId(serverId, "SEQ_COMMON").Result,
                    c_column_type = item.column_type,
                    c_title = item.column_name,
                    c_id = item.form_id.ToString(),
                    i_sequnce = 1,
                    d_create = DateTime.Now.ToLocalTime(),
                    i_creator = 123,
                    i_sign = 1
                };
                customTableDetails.Add(e);
            });

            return await _dataImp.CreateForm(serverId, customTable, customTableClassify, customTableDetails);
        }

        /// <summary>
        /// 获取最大序号
        /// </summary>
        /// <param name="serverId"></param>
        /// <param name="expression"></param>
        /// <param name="fieldex"></param>
        /// <returns></returns>
        public async Task<int> Max(string serverId, Expression<Func<ErpCustFormMain, bool>> expression, Expression<Func<ErpCustFormMain, int>> fieldex)
        {
            return await _dataImp.Max(serverId, expression, fieldex);
        }

        public async Task<NewForm> GetForm(string serverId, int form_id)
        {
            return await _dataImp.GetForm(serverId, form_id);
        }

        /// <summary>
        /// 启用、停用表单
        /// </summary>
        /// <param name="serverId"></param>
        /// <param name="form_id"></param>
        /// <returns></returns>
        public async Task<bool> EnableForm(string serverId, int form_id, string type_name)
        {
            //获取已停用的分类
            var list = await _iErpCustFlowClassifyImp.List(serverId, it => it.c_type_name == type_name);
            if (list != null && list.Count == 1)
            {
                var formList = await _iErpCustFlowFormClassifyImp.List(serverId, it => it.i_form_id == form_id);
                if (formList != null && formList.Count == 1)
                {
                    var form = formList[0];
                    form.i_classify_id = list[0].i_id;
                    return await _iErpCustFlowFormClassifyImp.Update(serverId, form);
                }
                else if (formList != null && formList.Count > 1)
                {
                    throw new Exception("系统表单分类出现重复记录，请检查！");
                }
                else
                {
                    //创建表单分类记录
                    var r = await _iErpCustFlowFormClassifyImp.Insert(serverId, new ErpCustFlowFormClassify
                    {
                        i_classify_id = list[0].i_id,
                        i_form_id = form_id,
                        d_create = DateTime.Now.ToLocalTime(),
                        i_creator = 123
                    });
                }

            }
            else if (list != null && list.Count > 1)
            {
                throw new Exception("系统分类出现重复记录，请检查！");
            }
            else
            {
                var maxSort = _dataImp.Max(serverId, it => true, it => it.i_sort.Value).Result;
                //创建已停用分类
                var r = await _iErpCustFlowClassifyImp.Insert(serverId, new ErpCustFlowClassify
                {
                    c_type_name = type_name,
                    i_sort = maxSort + 1,
                    d_create = DateTime.Now.ToLocalTime(),
                    i_creator = 123
                });
            }

            return true;
        }

        /// <summary>
        /// 修改表单可见范围
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="form_id"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        public async Task<bool> EditFormVisible(string server_id, int id, int type)
        {
            var e = new ErpCustFormMain
            {
                i_id = id,
                i_visible = type
            };
            return await _dataImp.Update(server_id, e,new string[] { "i_id", "i_visible" });
        }

        public async Task<bool> DeleteForm(string server_id, List<string> context)
        {
            var list = await _dataImp.List(server_id, it => SqlFunc.ContainsArray(context, it.i_id));
            list.ForEach(item => { item.i_enabled = 0; });
            return await _dataImp.Updatetable(server_id, list, new string[] { "I_ENABLED" });
        }
    }
}
