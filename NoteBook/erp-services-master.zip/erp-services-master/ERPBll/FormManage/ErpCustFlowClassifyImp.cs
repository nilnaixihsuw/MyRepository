﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPDal.FormManage;
using ERPModel.FormManage;
using ERPModel.Request;
using ERPModel.Response;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ERPBll.FormManage
{
    public class ErpCustFlowClassifyImp : BusinessRespository<ErpCustFlowClassify, IErpCustFlowClassifyDataImp>, IBusinessRepository<ErpCustFlowClassify>, IErpCustFlowClassifyImp
    {
        private readonly IErpCustFlowClassifyDataImp _dataImp;

        public ErpCustFlowClassifyImp(IErpCustFlowClassifyDataImp DataImp) : base(DataImp)
        {
            _dataImp = DataImp;
        }

        public async Task<bool> DeleteGroup(string server_id, List<object> list)
        {
            return await _dataImp.DeleteGroup(server_id, list);
        }

        public async Task<List<FormSortGroup>> FormSortList(string id, string server_id)
        {
            return await _dataImp.GetFormSortGroupList(server_id, null, id);
        }

        public async Task<List<FormSortGroup>> GetFormSortGroupList(string server_id, string form_name)
        {
            return await _dataImp.GetFormSortGroupList(server_id, form_name);
        }

        public async Task<bool> GroupSort(string server_id, List<ErpCustFlowClassify> context)
        {
            return await _dataImp.GroupSort(server_id, context);
        }

        public async Task<bool> Insertable(string server_id, List<ErpCustFlowClassify> context, IClientInformation client)
        {
            context.ForEach(it =>
            {
                it.i_id = _dataImp.GetId(server_id, "SEQ_COMMON").Result;
                it.i_creator = client.i_id;
            });
            //获取最大I_Sort
            var maxSort = await _dataImp.Max(server_id, it => it.i_sort.Value);
            for (var i = 1; i <= context.Count; i++)
            {
                context[i - 1].i_sort = maxSort + i;
            }

            return await _dataImp.Insertable(server_id, context);
        }

        public async Task<List<ErpCustFlowClassify>> QueryGroup(string server_id)
        {
            return await _dataImp.QueryGroup(server_id);
        }
    }
}