﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPModel.FormManage;
using ERPModel.Request;
using ERPModel.Response;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.FormManage
{
    public interface IErpCustFormMainImp : IBusinessRepository<ErpCustFormMain>
    {
        Task<bool> FormSort(string serverId, List<FormSortItem> list);
        Task<bool> EditForm(string serverId, EditForm form, IClientInformation client);
        Task<bool> CreateForm(string serverId, NewForm table, IClientInformation client);
        Task<int> Max(string serverId, Expression<Func<ErpCustFormMain, bool>> expression, Expression<Func<ErpCustFormMain, int>> fieldex);
        Task<NewForm> GetForm(string serverId, int form_id);
        Task<bool> EnableForm(string serverId, int form_id, string type_name);
        Task<bool> EditFormVisible(string server_id, int id, int type);
        Task<bool> DeleteForm(string server_id, List<string> context);
    }
}