﻿using ERPCore.ORM;
using ERPModel.FormManage;
using ERPModel.Request;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.FormManage
{
    public interface IErpCustFlowFormClassifyImp : IBusinessRepository<ErpCustFlowFormClassify>
    {
        Task<bool> AdjustFormGroup(string server_id, List<AdjustFormGroup> context);
    }
}
