﻿using ERPDal;
using ERPDal.FormManage;
using ErpModel.FormManage;
using ERPModel.FormManage;
using System.Collections.Generic;
using System.Data;

namespace ErpBll.FormManage
{
    public class FormBll
    {
        public static string AddNewFormMain(string serverID, string user_id, string form_name, string source_data, string remark)
        {
            string id = ERPBll.Tools.GetSeqCommonID(serverID).ToString();
            string r = FormDal.addNewFormMain(serverID, user_id, form_name, source_data, id, remark);
            return r;
        }
        public static DataTable GetFormMain(string serverID, string form_name)
        {
            return FormDal.getFormMain(serverID, form_name);
        }
        public static DataTable GetFormMainById(string serverID, string i_id)
        {
            return FormDal.getFormMainById(serverID, i_id);
        }

        public static List<ErpCustFormMain> GetAllMainForm(string serverID)
        {
            return SqlSugarHelper.DBClient(serverID).Queryable<ErpCustFormMain>().ToList();
        }

        public static List<string> AddNewFormDetail(string serverID, string user_id, string form_name, List<ColumnInfo> info, string remark)
        {
            var r = FormDal.addNewFormDetail(serverID, user_id, form_name, info, remark);
            return r;
        }
        public static bool AddFormDetail(string serverID, string user_id, string main_id, List<detail> info, string remark = "")
        {
            return FormDal.addFormDetail(serverID, user_id, main_id, info, remark);
        }
        public static DataTable GetFormDetail(string serverID, string main_id)
        {
            return FormDal.getFormDetail(serverID, main_id);
        }
        /// <summary>
        /// 根据指定ID获取指定表单记录
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="table_name"></param>
        /// <param name="id"></param>
        /// <returns></returns>
        public static DataTable GetFormInfo(string serverID, string table_name, string id)
        {
            return FormDal.getFormInfo(serverID, table_name, id);
        }

        public static bool CreateNewForm(string serverID, string table_name, List<string> column, List<string> type)
        {
            var r = FormDal.createNewForm(serverID, table_name, column, type);
            return r;
        }

        public static bool AddFormData(string serverID, string table_name, List<ColumnData> data)
        {
           
            var r = FormDal.addFormData(serverID, table_name, data);
            return r;
        }
        public static bool UpdateFormMain(string serverID, string user_id, string form_name, string source_data, string i_id, string remark = "")
        {
            return FormDal.updateFormMain(serverID, user_id, form_name, source_data, i_id, remark);
        }
        public static bool AddFormColumn(string serverID, string table_name, List<string> column, List<string> type)
        {
            for (int i = 0; i < column.Count; i++)
            {
                var r = FormDal.addFormColumn(serverID, table_name, column[i], type[i]);
            }
            return true;
        }
        public static bool DeleteForm(string serverID, string table_name)
        {
            return FormDal.deleteForm(serverID, table_name);
        }
        public static bool DeleteFormDetail(string serverID, string main_id)
        {
            return FormDal.deleteFormDetail(serverID, main_id);
        }
        public static bool DeleteFormMain(string serverID, string i_id)
        {
            return FormDal.deleteFormMain(serverID, i_id);
        }
    }
}
