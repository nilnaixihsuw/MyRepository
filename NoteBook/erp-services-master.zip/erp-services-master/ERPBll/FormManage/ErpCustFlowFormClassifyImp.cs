﻿using ERPCore.ORM;
using ERPDal.FormManage;
using ERPModel.FormManage;
using ERPModel.Response;
using ERPModel.Request;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ERPBll.FormManage
{
    public class ErpCustFlowFormClassifyImp : BusinessRespository<ErpCustFlowFormClassify, IErpCustFlowFormClassifyDataImp>, IBusinessRepository<ErpCustFlowFormClassify>, IErpCustFlowFormClassifyImp
    {
        private readonly IErpCustFlowFormClassifyDataImp _dataImp;

        public ErpCustFlowFormClassifyImp(IErpCustFlowFormClassifyDataImp dataImp) : base(dataImp)
        {
            _dataImp = dataImp;
        }

        public async Task<bool> AdjustFormGroup(string server_id, List<AdjustFormGroup> context)
        {
            return await _dataImp.AdjustFormGroup(server_id, context);
        }
    }
}