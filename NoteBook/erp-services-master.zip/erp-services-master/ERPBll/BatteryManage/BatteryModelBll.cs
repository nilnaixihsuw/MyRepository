using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using ERPBll.UserManage;
using ERPBll.VehicleInfo;
using ERPBll.Vehicleinfomanage;
using ERPBll.VehicleInfoManage;
using ERPDal;
using ERPModel.BatteryManage;
using ERPModel.DataBase;
using ERPModel.EngineManage;
using ERPModel.UserManage;
using ERPModel.Vehicleinfomanage;
using SqlSugar;

namespace ERPBll.BatteryManage
{
    public class BatteryModelBll
    {
        /// <summary>
        /// 分页查询
        /// </summary>
        /// <param name="serverID"></param>
        /// <returns></returns>
        public static Task<(List<ErpBatteryModel>, int)> GetByPageAsync(string serverID, BatteryQueryInput input)
        {
            int totalCount = 0;
            return Task.FromResult((SqlSugarHelper.DBClient(serverID).Queryable<ErpBatteryModel>()
                .WhereIF(!string.IsNullOrWhiteSpace(input.name), x => x.c_name.ToLower().Contains(input.name.ToLower()))
                .OrderBy(x => x.d_created_time, OrderByType.Desc)
                .ToPageList(input.page_index, input.page_size, ref totalCount), totalCount));
        }

        /// <summary>
        /// 分页查询电瓶信息
        /// </summary>
        /// <param name="serverID"></param>
        /// <returns></returns>
        public static List<BatteryDto> GetBatBottleByPageAsync(BatBottleQueryInput request)
        {
            var list1 = SqlSugarHelper.DBClient(request.server_id).Queryable<ErpBattery>()
                .Where(request.ToExp())
                .Mapper(r => r.department_info, r => r.department_id)
                .Mapper(r => r.vehicle_info, r => r.vehicle_id)
                .Mapper(r => r.model_info, r => r.model_id)
                .OrderBy(r => r.id, OrderByType.Desc)
                .ToList();
            var list2 = SqlSugarHelper.DBClient(request.server_id).Queryable<ErpBatteryVehicle>().ToList();
            var dic = SqlSugarHelper.DBClient(request.server_id).Queryable<SysCommonDictDetail>().ToList();

            var list = new List<BatteryDto>();
            foreach (var item in list1)
            {
                var temp = new BatteryDto();
                temp.id = item.id;
                temp.code = item.code;
                temp.model_id = item.model_id;
                temp.price = item.n_price;
                temp.buy_date = item.d_buy == null ? "" : item.d_buy.Value.ToString("yyyy-MM-dd");

                temp.position = string.IsNullOrEmpty(item.i_position) ? 0 : Convert.ToInt32(item.i_position);
                temp.position_name = string.IsNullOrEmpty(item.i_position) ? "" : dic.Find(r => r.i_id == Convert.ToDecimal(item.i_position))?.c_name;
                temp.type = string.IsNullOrEmpty(item.i_type) ? 0 : Convert.ToInt32(item.i_type);
                temp.type_name = string.IsNullOrEmpty(item.i_type) ? "" : dic.Find(r => r.i_id == Convert.ToDecimal(item.i_type))?.c_name;

                temp.i_state = item.i_state == null ? 2 : (int)item.i_state;
                temp.remark = item.c_remark;
                temp.scrap_date = item.d_scrap == null ? "" : item.d_scrap.Value.ToString("yyyy-MM-dd");
                temp.scrap_reason = item.c_scrap_reason;

                if (item.department_id == default)
                {
                    temp.dept_info = new List<TreeSlim>();
                }
                else
                {
                    var dept = item.department_info;
                    temp.dept_info = new List<TreeSlim>() { new TreeSlim { i_id = dept?.i_id, c_name = dept?.c_name, type = 1 } };
                    temp.department = dept?.c_name;
                }

                if (item.vehicle_id == default || temp.i_state != 1)
                {
                    temp.vehicle_info = new List<TreeSlim>();
                }
                else
                {
                    var vehicle = item.vehicle_info;
                    temp.vehicle_info = new List<TreeSlim>() { new TreeSlim { i_id = vehicle?.id, c_name = vehicle?.lp_num, type = 3 } };
                    temp.lp_num = vehicle?.lp_num;

                    var record = list2.Where(r => r.i_battery_id == item.id && r.i_vehicle_id == item.vehicle_id).OrderBy(r => r.i_id).Last();
                    temp.install_date = record.d_buy.Value.ToString("yyyy-MM-dd");
                    temp.content = record.c_content;
                    temp.remark1 = record.c_remark;
                }

                switch (temp.i_state)
                {
                    case 1:
                        temp.state = "使用中";
                        break;
                    case 2:
                        temp.state = "闲置中";
                        break;
                    case 3:
                        temp.state = "报废";
                        break;
                    default:
                        break;
                }
                temp.name = item.model_info?.c_name;
                temp.bat_type = item.model_info?.i_type == null ? "" : ((BatteryTypeDic)item.model_info.i_type).ToString();
                temp.brand = item.model_info?.c_brand;
                temp.rate_capacity = item.model_info?.n_rated_capacity;

                list.Add(temp);
            }
            return list;
        }

        /// <summary>
        /// 获取所需相关记录
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="expression"></param>
        /// <returns></returns>
        public static List<ErpBattery> GetRecords(string serverID, Expression<Func<ErpBattery, bool>> expression)
        {
            return SqlSugarHelper.DBClient(serverID).Queryable<ErpBattery>()
                .WhereIF(expression != null, expression).ToList();
        }

        /// <summary>
        /// 根据ID查询电瓶信息
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="id">主键ID</param>
        /// <returns></returns>
        public static ErpBattery GetBatBottleByID(string serverID, decimal id)
        {
            return SqlSugarHelper.DBClient(serverID).Queryable<ErpBattery>().In(id).First();
        }

        /// <summary>
        /// 根据车辆ID查询电瓶信息
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="vehicle_id">车辆ID</param>
        /// <returns></returns>
        public static List<ErpBattery> GetBatBottleByVehicle(string serverID, decimal vehicle_id)
        {
            return SqlSugarHelper.DBClient(serverID).Queryable<ErpBattery>().Where(r => r.vehicle_id == vehicle_id).ToList();
        }

        /// <summary>
        /// 根据车辆ID，电瓶ID查询电瓶使用信息
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="battery_id">电瓶ID</param>
        /// <param name="vehicle_id">车辆ID</param>
        /// <returns></returns>
        public static List<ErpBatteryVehicle> GetBatRecordByID(string serverID, decimal battery_id, decimal vehicle_id = 0)
        {
            return SqlSugarHelper.DBClient(serverID).Queryable<ErpBatteryVehicle>()
                .WhereIF(battery_id != 0, r => r.i_battery_id == battery_id)
                .WhereIF(vehicle_id != 0, r => r.i_vehicle_id == vehicle_id)
                .OrderBy(r => r.i_id, OrderByType.Asc).ToList();
        }

        /// <summary>
        /// 根据车辆ID，电瓶ID查询电瓶生命周期信息
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="battery_id">电瓶ID</param>
        /// <returns></returns>
        public static List<ErpBatteryLife> GetBatLifeByID(string serverID, decimal battery_id)
        {
            return SqlSugarHelper.DBClient(serverID).Queryable<ErpBatteryLife>()
                .Where(r => r.i_battery_id == battery_id)
				.OrderBy(r => r.i_id, OrderByType.Asc).ToList();
		}

        public static Task<int> AddAsync(string serverID, ErpBatteryModel info)
        {
            info.i_id = ERPBll.Tools.GetEngineID(serverID);
            return Task.FromResult(SqlSugarHelper.DBClient(serverID).Insertable(info).ExecuteCommand());
        }

        /// <summary>
        /// 新增电瓶记录信息
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="info"></param>
        /// <returns></returns>
        public static int AddBattery(string serverID, ErpBattery info)
        {
            return SqlSugarHelper.DBClient(serverID).Insertable(info).ExecuteCommand();
        }

        /// <summary>
        /// 新增电瓶使用记录信息
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="info"></param>
        /// <returns></returns>
        public static int AddBatRecord(string serverID, ErpBatteryVehicle info)
        {
            return SqlSugarHelper.DBClient(serverID).Insertable(info).ExecuteCommand();
        }

        /// <summary>
        /// 电瓶生命周期记录
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="info"></param>
        /// <returns></returns>
        public static int AddBatLife(string serverID, ErpBatteryLife info)
        {
            return SqlSugarHelper.DBClient(serverID).Insertable(info).ExecuteCommand();
        }

        public static int UpdateAsync(string serverID, ErpBatteryModel info)
        {
            return SqlSugarHelper.DBClient(serverID).Updateable(info).ExecuteCommand();
        }

        /// <summary>
        /// 更新电瓶记录信息
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="info"></param>
        /// <returns></returns>
        public static int UpdateBattery(string serverID, ErpBattery info)
        {
            return SqlSugarHelper.DBClient(serverID).Updateable(info).ExecuteCommand();
        }

        /// <summary>
        /// 更新电瓶使用记录信息
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="info"></param>
        /// <returns></returns>
        public static int UpdateBatRecord(string serverID, ErpBatteryVehicle info)
        {
            return SqlSugarHelper.DBClient(serverID).Updateable(info)
                .Where(r => r.i_id == info.i_id).ExecuteCommand();
        }

        public static int DeleteAsync(string serverID, decimal id)
        {
            return SqlSugarHelper.DBClient(serverID)
                .Deleteable<ErpBatteryModel>()
                .Where(r => r.i_id == id).ExecuteCommand();
        }

        /// <summary>
        /// 删除电瓶信息
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="id"></param>
        /// <returns></returns>
        public static int DeleteBatBottleRecord(string serverID, decimal id)
        {
            int res = SqlSugarHelper.DBClient(serverID).Deleteable<ErpBattery>()
                .Where(r => r.id == id).ExecuteCommand();
            res += SqlSugarHelper.DBClient(serverID).Deleteable<ErpBatteryVehicle>()
                .Where(r => r.i_battery_id == id).ExecuteCommand();
            res += SqlSugarHelper.DBClient(serverID).Deleteable<ErpBatteryLife>()
               .Where(r => r.i_battery_id == id).ExecuteCommand();
            return res;
        }

        /// <summary>
        /// 电瓶报废
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="id"></param>
        /// <param name="reason">报废原因</param>
        /// <param name="d_scrap">报废时间</param>
        /// <returns></returns>
        public static int ScrapBatBottle(string serverID, decimal id, string reason, DateTime d_scrap)
        {
            int res = SqlSugarHelper.DBClient(serverID).Updateable<ErpBattery>(r => new ErpBattery
            {
                d_scrap = d_scrap,
                c_scrap_reason = reason,
                i_state = 3
            }).Where(r => r.id == id).ExecuteCommand();
            return res;
        }
    }
}