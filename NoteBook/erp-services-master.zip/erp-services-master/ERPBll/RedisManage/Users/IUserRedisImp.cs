﻿using ERPModel.UserManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.RedisManage.Users
{
    /// <summary>
    /// 用户信息缓存
    /// </summary>
    public interface IUserRedisImp
    {
        /// <summary>
        /// 获取全部id
        /// </summary>
        /// <returns></returns>
        Task<List<string>> GetAllIdAsync();

        /// <summary>
        /// 获取全部
        /// </summary>
        /// <returns></returns>
        Task<List<SysPerson>> GetAllAsync();

        /// <summary>
        /// 获取全部
        /// </summary>
        /// <returns></returns>
        List<SysPerson> GetAll();

        /// <summary>
        /// 根据id查询
        /// </summary>
        Task<SysPerson> GetByIdAsync(string id);

        /// <summary>
        /// 根据id查询姓名
        /// </summary>
        Task<string> GetNameByIdAsync(string id);

        /// <summary>
        /// 根据员工名获取员工id
        /// </summary>
        Task<decimal?> GetIdByNameAsync(string name);

        /// <summary>
        /// 根据员工名获取部门id
        /// </summary>
        Task<string> GetDidByNameAsync(string name);

        /// <summary>
        /// 编辑单个员工缓存信息
        /// </summary>
        /// <param name="i_id"></param>
        /// <param name="server_id"></param>
        /// <returns></returns>
        Task SetOneAsync(decimal i_id, string server_id = "60.191.59.11");

        /// <summary>
        /// 删除账号缓存信息
        /// </summary>
        /// <param name="user_ids"></param>
        /// <param name="server_id"></param>
        /// <returns></returns>
        Task DelUserAsync(List<decimal> user_ids, string server_id = "60.191.59.11");
    }
}
