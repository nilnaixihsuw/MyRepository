﻿using BusTools.Redis;
using ERPBll.SignalRs;
using ERPDal;
using ERPModel.ApiModel.MaterialManage.WarehouseManage;
using ERPModel.SystemManage.SysJgUser;
using ERPModel.UserManage;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.RedisManage.Users
{
    /// <summary>
    /// 用户缓存
    /// </summary>
    public class UserRedisImp : IUserRedisImp
    {
        /// <summary>
        /// redis用户信息缓存key
        /// </summary>
        private readonly string _userKey = "user";
        private readonly IRedisService _redisService;
        private readonly IServerHubImp _iServerHubImp;

        public UserRedisImp(IServerHubImp iServerHubImp)
        {
            _redisService = new RedisService(1);
            _iServerHubImp = iServerHubImp;
        }

        public async Task<List<string>> GetAllIdAsync()
        {
            if (!_redisService.KeyExists(_userKey))
            {
                await SetAllAsync();
            }
            return await _redisService.HashKeysAsync<string>(_userKey);
        }

        public async Task<List<SysPerson>> GetAllAsync()
        {
            if (!_redisService.KeyExists(_userKey))
            {
                await SetAllAsync();
            }
            return await _redisService.HashValuesAsync<SysPerson>(_userKey);
        }

        public List<SysPerson> GetAll()
        {
            if (!_redisService.KeyExists(_userKey))
            {
                SetAll();
            }
            return _redisService.HashValues<SysPerson>(_userKey);
        }

        public async Task<SysPerson> GetByIdAsync(string id)
        {
            if (!_redisService.KeyExists(_userKey))
            {
                await SetAllAsync();
            }
            return await _redisService.HashGeAsync<SysPerson>(_userKey, id);
        }

        /// <summary>
        /// 根据员工名获取员工id
        /// </summary>
        public async Task<decimal?> GetIdByNameAsync(string name)
        {
            var list = await GetAllAsync();
            var person = list.Where(x => x.c_name == name).FirstOrDefault();
            return person == null ? null : person.i_id;
        }

        /// <summary>
        /// 根据员工名获取部门id
        /// </summary>
        public async Task<string> GetDidByNameAsync(string name)
        {
            var list = await GetAllAsync();
            var person = list.Where(x => x.c_name == name).FirstOrDefault();
            return person == null ? "" : person.department_name;
        }

        public async Task<string> GetNameByIdAsync(string id)
        {
            if (!_redisService.KeyExists(_userKey))
            {
                await SetAllAsync();
            }
            return (await _redisService.HashGeAsync<SysPerson>(_userKey, id))?.c_name;
        }

        private async Task SetAll(string server_id = "60.191.59.11")
        {
            var list = SqlSugarHelper.DBClient(server_id)
                                .Queryable<SysPerson>()
                                .Mapper(x =>
                                {
                                    x.department_name = SqlSugarHelper.DBClient(server_id)
                                        .Queryable<SysDepartment>()
                                        .First(c => c.i_id == x.i_department_base)?.c_name;

                                })
                                .ToList();
            list.ForEach(item =>
           {
               var res = _redisService.HashSet<SysPerson>(_userKey, item.i_id.ToString(), item);
               if (!res)
               {
                    //记录失败日志
                }
           });
        }

        private async Task SetAllAsync(string server_id = "60.191.59.11")
        {
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<SysPerson>()
                                .Mapper(x =>
                                {
                                    var dept = SqlSugarHelper.DBClient(server_id)
                                        .Queryable<SysDepPerson>()
                                        .Mapper(x => x.group_info, x => x.i_group_id)
                                        .First(c => c.i_child_id == x.i_id && c.sign == 1);
                                    x.i_department_base = dept?.i_group_id;
                                    x.department_name = dept?.group_info?.c_name;
                                    x.department_main_name = dept?.group_info?.c_name;

                                    x.position_name = SqlSugarHelper.DBClient(server_id)
                                       .Queryable<SysPostInfo>()
                                       .First(c => c.i_id == x.i_position_id)?.c_name;

                                    x.jg_user = SqlSugarHelper.DBClient(server_id)
                                        .Queryable<SysJgUser>()
                                        .First(c => c.user_id == x.i_id);
                                })
                                .ToListAsync();
            list.ForEach(async item =>
            {
                var res = await _redisService.HashSetAsync<SysPerson>(_userKey, item.i_id.ToString(), item);
                if (!res)
                {
                    //记录失败日志
                }
            });
        }

        public async Task SetOneAsync(decimal i_id, string server_id = "60.191.59.11")
        {
            var person = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<SysPerson>()
                                .Mapper(x =>
                                {
                                    var dept = SqlSugarHelper.DBClient(server_id)
                                        .Queryable<SysDepPerson>()
                                        .Mapper(x => x.group_info, x => x.i_group_id)
                                        .First(c => c.i_child_id == x.i_id && c.sign == 1);
                                    x.i_department_base = dept?.i_group_id;
                                    x.department_name = dept?.group_info?.c_name;
                                    x.department_main_name = dept?.group_info?.c_name;

                                    x.position_name = SqlSugarHelper.DBClient(server_id)
                                       .Queryable<SysPostInfo>()
                                       .First(c => c.i_id == x.i_position_id)?.c_name;

                                    x.jg_user = SqlSugarHelper.DBClient(server_id)
                                        .Queryable<SysJgUser>()
                                        .First(c => c.user_id == x.i_id);
                                })
                                .FirstAsync(r => r.i_id == i_id);

            if (_redisService.HashExists(_userKey, person.i_id.ToString()))
            {
                await _redisService.HashDeleteAsync(_userKey, person.i_id.ToString());
            }
            var res = await _redisService.HashSetAsync(_userKey, person.i_id.ToString(), person);
            if (!res)
            {
                //记录失败日志
            }

            _redisService.KeyDelete("person");
            _redisService.KeyDelete("person_tree");
            _redisService.KeyDelete("driver_tree");

            await _iServerHubImp.SendMessageToAllAsync(SignalRs.MessageType.UpdateRedis, 1);
            await _iServerHubImp.SendMessageToAllAsync(SignalRs.MessageType.UpdateRedis, 5);
        }

        public async Task DelUserAsync(List<decimal> user_ids, string server_id = "60.191.59.11")
        {
            foreach (var item in user_ids)
            {
                if (_redisService.HashExists(_userKey, item.ToString()))
                {
                    await _redisService.HashDeleteAsync(_userKey, item.ToString());
                }
            }

            _redisService.KeyDelete("person");
            _redisService.KeyDelete("person_tree");
            _redisService.KeyDelete("driver_tree");

            await _iServerHubImp.SendMessageToAllAsync(SignalRs.MessageType.UpdateRedis, 1);
            await _iServerHubImp.SendMessageToAllAsync(SignalRs.MessageType.UpdateRedis, 5);
        }
    }
}
