﻿using BusTools.Redis;
using ERPCore;
using ERPCore.Helpers;
using ERPCore.ORM;
using ERPCore.Redis;
using ErpModel.CommonModel;
using ERPModel.CommonModel;
using ERPModel.SystemManage;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.RedisManage.Stations
{
    public class StationRedisImp : IStationRedisImp
    {
        private readonly string _stationKey = "station";
        private readonly string _lineStationKey = "line_station";
        private readonly IRedisService _redisService;
        private readonly DispatchSys _option;
        private readonly System.Timers.Timer t;

        public StationRedisImp(
            IRedisService redisService,
            IVehicleRedisManageImp vehicleRedisManageImp,
            IConfiguration options)
        {
            _redisService = new RedisService(1);
            _option = options.GetSection("Sugar").Get<SugarOption>().DispatchSys;
        }

        public async void Execute(object source, System.Timers.ElapsedEventArgs e)
        {
            t.Stop();
           await SetStationsAsync();
            t.Start();
        }

        public async Task<List<Station>> GetStationsAsync()
        {
            if (!_redisService.KeyExists(_stationKey))
            {
                return await SetStationsAsync(); 
            }
            else
            {
                return await _redisService.StringGetAsync<List<Station>>(_stationKey);
            }
        }

        public async Task<List<Station>> SetStationsAsync()
        {
            var list = await GetAllStationsAsync();
            if (list != null && list.Count > 0)
            {
                _redisService.StringSet(_stationKey, list);
            }
            return list;
        }

        public Task<List<Station>> GetAllStationsAsync()
        {
            try
            {
                var rep = new List<Station>();
                //获取线路信息
                var data = "req=" + JsonConvert.SerializeObject(new DispatchRequest
                {
                    head = new Head
                    {
                        cmd = "get_user_station_info",
                        user_id = _option.UserId,
                        server_id = _option.ServerId,
                        isCompress = false
                    },
                    content = new Content
                    {
                        //usable = 0
                    }
                });
                //Console.WriteLine("缓存请求站点信息:", _option.Url);
                GlobalFunc.LogInfo($"缓存请求站点信息:{ _option.Url},参数{data}");
                var repStr = HttpHelper.HttpPostFrom(_option.Url, data);
                if (!string.IsNullOrEmpty(repStr))
                {
                    var result = JsonConvert.DeserializeObject<DispatchStation>(repStr);
                    if (result.content.result == "200")
                    {
                        rep = result.content.items;
                    }
                    else
                    {
                        //记录错误日志
                    }
                }
                return Task.FromResult(rep);
            }
            catch (Exception ex)
            {
                GlobalFunc.LogError("获取站点错误", ex);
                return Task.FromResult(new List<Station>());
            }
        }

        public async Task<List<LineStation>> GetLineStationsAsync()
        {
            //_redisService.KeyDelete(_stationKey);
            if (!_redisService.KeyExists(_lineStationKey))
            {
                var list = await GetAllLineStationsAsync();

                var res = _redisService.StringSet(_lineStationKey, list, TimeSpan.FromMinutes(RedisConfigure.TEMPTABLE.CatchTimeMinite));
                if (!res)
                {
                    throw new Exception("缓存站点失败!");
                }
                return list;
            }
            else
            {
                return await _redisService.StringGetAsync<List<LineStation>>(_lineStationKey);
            }
        }

        public async Task<List<LineStation>> GetAllLineStationsAsync()
        {
            return await Task.Run(() =>
            {
                var rep = new List<LineStation>();
                //获取线路信息
                var data = "req=" + JsonConvert.SerializeObject(new DispatchRequest
                {
                    head = new Head
                    {
                        cmd = "get_station_info_for_app",
                        user_id = _option.UserId,
                        server_id = _option.ServerId,
                        isCompress = false
                    },
                    content = new Content
                    {
                        //usable = 0
                    }
                });
                var repStr = HttpHelper.HttpPostFrom(_option.Url, data);
                if (!string.IsNullOrEmpty(repStr))
                {
                    var result = JsonConvert.DeserializeObject<DispatchLineStation>(repStr);
                    if (result.content.result == "200")
                    {
                        rep = result.content.items;
                    }
                    else
                    {
                        //记录错误日志
                    }
                }
                return rep;
            });
        }
        
        public async Task<List<SiteStation>> GetSiteStationsAsync(string name, string state)
        {
            return await Task.Run(() =>
            {
                var rep = new List<SiteStation>();
                //获取线路信息
                var data = "req=" + JsonConvert.SerializeObject(new SiteRequest
                {
                    head = new Head
                    {
                        cmd = "get_busstation",
                        user_id = _option.UserId,
                        server_id = _option.ServerId,
                        isCompress = false
                    },
                    content = new SiteContent
                    {
                        station_name = name,
                        i_use_status = state
                    }
                });
                var repStr = HttpHelper.HttpPostFrom(_option.Url, data);
                if (!string.IsNullOrEmpty(repStr))
                {
                    var result = JsonConvert.DeserializeObject<SiteStationRespose>(repStr);
                    if (result.content.result == "200")
                    {
                        rep = result.content.items;
                    }
                    else
                    {
                        //记录错误日志
                    }
                }
                return rep;
            });
        }

        /// <summary>
        /// 清除缓存
        /// </summary>
        public void ClearKey()
        {
            _redisService.KeyDelete(_lineStationKey);
            _redisService.KeyDelete(_stationKey);
        }

        public async Task AutoUpdateTree()
        {
            _redisService.KeyDelete(_lineStationKey);
            await GetLineStationsAsync();
        }
    }
}
