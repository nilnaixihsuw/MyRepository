﻿using ERPModel.SystemManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.RedisManage.Stations
{
    public interface IStationRedisImp
    {
        /// <summary>
        /// 从调度系统获取全部站点信息
        /// </summary>
        /// <returns></returns>
        Task<List<Station>> GetAllStationsAsync();

        /// <summary>
        /// 从缓存获取全部站点信息
        /// </summary>
        /// <returns></returns>
        Task<List<Station>> GetStationsAsync();

        /// <summary>
        /// 从缓存获取全部站点信息
        /// </summary>
        /// <returns></returns>
        Task<List<SiteStation>> GetSiteStationsAsync(string name, string state);

        /// <summary>
        /// 从调度系统获取全部线路站点
        /// </summary>
        /// <returns></returns>
        Task<List<LineStation>> GetAllLineStationsAsync();

        /// <summary>
        /// 从缓存获取全部线路站点
        /// </summary>
        /// <returns></returns>
        Task<List<LineStation>> GetLineStationsAsync();

        void ClearKey();

        Task AutoUpdateTree();
    }
}
