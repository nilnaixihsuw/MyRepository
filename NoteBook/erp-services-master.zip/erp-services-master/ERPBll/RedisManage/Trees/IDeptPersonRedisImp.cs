﻿using ERPModel.CommonModel;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.RedisManage.Trees
{
    public interface IDeptPersonRedisImp
    {
        /// <summary>
        /// 完整驾驶员树缓存
        /// </summary>
        /// <param name="server_id"></param>
        /// <returns></returns>
        Task<List<DeptTree>> GetDeptDriverTreeRedisAsync(string server_id);

        /// <summary>
        /// 完整人员树缓存(包括从属部门)
        /// </summary>
        /// <param name="server_id"></param>
        /// <returns></returns>
        Task<List<DeptTree>> GetDeptPersonTreeRedisAsync(string server_id);

        /// <summary>
        /// 完整部门人员树缓存(不包括从属部门)
        /// </summary>
        /// <param name="server_id"></param>
        /// <returns></returns>
        Task<List<DeptTree>> GetDeptPersonMainTreeRedisAsync(string server_id);

        /// <summary>
        /// 获取部门人员树
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="user_id"></param>
        /// <returns></returns>
        Task<List<DeptTree>> GetDeptPersonTreeByUserAsync(string server_id, decimal? user_id, int? func_type = null);

        /// <summary>
        /// 获取驾驶员树
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="user_id"></param>
        /// <returns></returns>
        Task<List<DeptTree>> GetDeptDriverTreeByUserAsync(string server_id, decimal? user_id, int? func_type = null);

        /// <summary>
        /// 部门人员树缓存(不包括从属部门)
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="user_id"></param>
        /// <returns></returns>
        Task<List<DeptTree>> GetDeptPersonMainTreeByUserAsync(string server_id, decimal? user_id, int? func_type = null);

        /// <summary>
        /// 清除缓存
        /// </summary>
        void ClearKey();

        /// <summary>
        /// 更新树缓存
        /// </summary>
        Task AutoUpdateTree(string server_id = "60.191.59.11");
    }
}
