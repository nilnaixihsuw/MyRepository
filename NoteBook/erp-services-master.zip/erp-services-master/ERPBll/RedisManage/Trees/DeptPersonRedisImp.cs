﻿using AutoMapper;
using BusTools.Redis;
using DotNetCore.CAP.Messages;
using ERPBll.RedisManage.Users;
using ERPBll.SignalRs;
using ERPCore.Redis;
using ERPDal;
using ERPModel.ApiModel;
using ERPModel.CommonModel;
using ERPModel.UserManage;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.RedisManage.Trees
{
    /// <summary>
    /// 部门人员
    /// </summary>
    public class DeptPersonRedisImp : IDeptPersonRedisImp
    {
        /// <summary>
        /// redis人员信息缓存key
        /// </summary>
        private readonly string _personKey = "person";
        //完整人员树(包括从属部门)
        private readonly string _personTreeKey = "person_tree";
        //完整驾驶员树
        private readonly string _driverTreeKey = "driver_tree";
        //完整人员树(不包括从属部门)
        private readonly string _personMainTreeKey = "person_main_tree";
        private readonly IRedisService _redisService;
        private readonly IMapper _imapper;
        private readonly IDeptRedisImp _deptRedisImp;
        private readonly IUserRedisImp _userRedisImp;
        private readonly IServerHubImp _iServerHubImp;

        public DeptPersonRedisImp(
            IDeptRedisImp deptRedisImp,
            IMapper imapper,
            IServerHubImp iServerHubImp,
            IUserRedisImp userRedisImp)
        {
            _redisService = new RedisService(1);
            _imapper = imapper;
            _deptRedisImp = deptRedisImp;
            _userRedisImp = userRedisImp;
            _iServerHubImp = iServerHubImp;
        }

        #region 人员信息

        public async Task<List<SysDepPerson>> GetAllAsync()
        {
            if (!_redisService.KeyExists(_personKey))
            {
                await SetAll();
            }
            return await _redisService.StringGetAsync<List<SysDepPerson>>(_personKey);
        }

        public async Task SetAll(string server_id = "60.191.59.11")
        {
            var list = await SqlSugarHelper.DBClient(server_id)
                                           .Queryable<SysDepPerson>()
                                           .Where(x => x.i_child_id > 2000000)
                                           .Mapper(x => x.person_info, x => x.i_child_id)
                                           .OrderBy(x => x.sort)
                                           .ToListAsync();

            var res = _redisService.StringSet(_personKey, list, TimeSpan.FromMinutes(RedisConfigure.TEMPTABLE.CatchTimeMinite));
            if (!res)
            {
                throw new Exception("缓存人员失败!");
            }
        }

        #endregion

        #region 完整部门人员树

        /// <summary>
        /// 完整部门人员树缓存(包括从属部门)
        /// </summary>
        /// <param name="server_id"></param>
        /// <returns></returns>
        public async Task<List<DeptTree>> GetDeptPersonTreeRedisAsync(string server_id)
        {
            if (!_redisService.KeyExists(_personTreeKey))
            {
                await SetDeptPersonTreeRedisAsync(server_id, false, true, _personTreeKey);
            }
            return await _redisService.StringGetAsync<List<DeptTree>>(_personTreeKey);
        }

        /// <summary>
        /// 完整驾驶员树缓存
        /// </summary>
        /// <param name="server_id"></param>
        /// <returns></returns>
        public async Task<List<DeptTree>> GetDeptDriverTreeRedisAsync(string server_id)
        {
            if (!_redisService.KeyExists(_driverTreeKey))
            {
                await SetDeptPersonTreeRedisAsync(server_id, true, true, _driverTreeKey);
            }
            return await _redisService.StringGetAsync<List<DeptTree>>(_driverTreeKey);
        }

        /// <summary>
        /// 完整部门人员树缓存(不包括从属部门)
        /// </summary>
        /// <param name="server_id"></param>
        /// <returns></returns>
        public async Task<List<DeptTree>> GetDeptPersonMainTreeRedisAsync(string server_id)
        {
            if (!_redisService.KeyExists(_personMainTreeKey))
            {
                await SetDeptPersonTreeRedisAsync(server_id, false, false, _personMainTreeKey);
            }
            return await _redisService.StringGetAsync<List<DeptTree>>(_personMainTreeKey);
        }

        public async Task SetDeptPersonTreeRedisAsync(string server_id, bool is_driver, bool show_all, string key)
        {
            var list = await GetDeptPersonTreeAsync(server_id, is_driver, show_all);

            var res = _redisService.StringSet(key, list, TimeSpan.FromMinutes(RedisConfigure.TEMPTABLE.CatchTimeMinite));
            if (!res)
            {
                throw new Exception("缓存部门人员树失败!");
            }
        }

        /// <summary>
        /// 获取人员树
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="is_driver">是否驾驶员</param>
        /// <returns></returns>
        public async Task<List<DeptTree>> GetDeptPersonTreeAsync(string server_id, bool is_driver, bool show_all)
        {
            var dept_tree = await _deptRedisImp.GetDeptTreeRedisAsync(server_id);
            var persons = await GetAllAsync();
            var users = await _userRedisImp.GetAllAsync();
            if (is_driver)
            {
                persons = persons.Where(x => x.person_info != null && x.person_info.i_is_driver == 1).ToList();
                users = users.Where(x => x.i_is_driver == 1).ToList();
            }
            else
            {
                persons = persons.Where(x => x.person_info != null && 
                                        (x.person_info.i_is_driver == 0 || x.person_info.i_is_driver == null) &&
                                        (x.person_info.i_emp_state == 1 || x.person_info.i_emp_state == null) &&
                                        x.person_info.c_state != "3").ToList();
                users = users.Where(x => (x.i_is_driver == 0 || x.i_is_driver == null) && 
                                        (x.i_emp_state == 1 || x.i_emp_state == null) && x.c_state != "3").ToList();
            }

            var data = await GetDeptPersonLoop(dept_tree, users, persons, show_all);
            return data;
        }

        public async Task<List<DeptTree>> GetDeptPersonLoop(
            List<DeptTree> list, List<SysPerson> users, List<SysDepPerson> persons, bool show_all, string index = "0")
        {
            foreach (var item in list)
            {
                if (item.children != null && item.children.Count > 0)
                {
                    await GetDeptPersonLoop(item.children, users, persons, show_all, ((int)item.i_id.Value).ToString());
                }
                else
                {
                    item.children = new List<DeptTree>();
                }

                var tempLists = persons.Where(x => x.i_group_id == item.i_id).ToList();
                if(!show_all)
                {
                    tempLists = tempLists.Where(x => x.sign == 1).ToList();
                }
                var temps = tempLists.Select(x => x.person_info).ToList();

                temps.AddRange(users.Where(x => x.i_department_base == item.i_id &&
                    !temps.Select(i => i.i_id).Contains(x.i_id)).OrderBy(x => x.i_id).ToList());
                var childs = _imapper.Map<List<SysPerson>, List<DeptTree>>(temps);
                childs.ForEach(x => 
                { 
                    x.parent_id = item.i_id;
                    x.type = 0;
                    x.index = (int)item.i_id.Value + "_" + (int)x.i_id.Value;
                    x.children = new List<DeptTree>();
                    x.children_count = 1;
                });
                item.index = index + "_" + (int)item.i_id.Value;
                item.children.AddRange(childs);
                item.children_count = item.children.Sum(x => x.children_count);
            }
            return list;
        }

        #endregion

        #region 权限部门人员树

        /// <summary>
        /// 部门人员树
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="user_id"></param>
        /// <returns></returns>
        public async Task<List<DeptTree>> GetDeptPersonTreeByUserAsync(string server_id, decimal? user_id, int? func_type = null)
        {
            var tree = await GetDeptPersonTreeRedisAsync(server_id);

            //过滤权限
            var (orgs_parents, orgs) = await _deptRedisImp.QueryDeptId(server_id, user_id, func_type);

            if (orgs_parents == null) //管理员
            {
                return tree;
            }

            return await _deptRedisImp.GetDeptTreeUserLoop(tree, orgs_parents, orgs);
        }

        /// <summary>
        /// 驾驶员树
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="user_id"></param>
        /// <returns></returns>
        public async Task<List<DeptTree>> GetDeptDriverTreeByUserAsync(string server_id, decimal? user_id, int? func_type = null)
        {
            var tree = await GetDeptDriverTreeRedisAsync(server_id);

            //过滤权限
            var (orgs_parents, orgs) = await _deptRedisImp.QueryDeptId(server_id, user_id, func_type);

            if (orgs_parents == null) //管理员
            {
                return tree;
            }

            return await _deptRedisImp.GetDeptTreeUserLoop(tree, orgs_parents, orgs);
        }

        /// <summary>
        /// 部门人员树缓存(不包括从属部门)
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="user_id"></param>
        /// <returns></returns>
        public async Task<List<DeptTree>> GetDeptPersonMainTreeByUserAsync(string server_id, decimal? user_id, int? func_type = null)
        {
            var tree = await GetDeptPersonMainTreeRedisAsync(server_id);

            //过滤权限
            var (orgs_parents, orgs) = await _deptRedisImp.QueryDeptId(server_id, user_id, func_type);

            if (orgs_parents == null) //管理员
            {
                return tree;
            }

            return await _deptRedisImp.GetDeptTreeUserLoop(tree, orgs_parents, orgs);
        }

        #endregion

        /// <summary>
        /// 清除缓存
        /// </summary>
        public void ClearKey()
        {
            _redisService.KeyDelete("user");
            _redisService.KeyDelete(_personKey);
            _redisService.KeyDelete(_personTreeKey);
            _redisService.KeyDelete(_driverTreeKey);

            _iServerHubImp.SendMessageToAllAsync(SignalRs.MessageType.UpdateRedis, 1);
            _iServerHubImp.SendMessageToAllAsync(SignalRs.MessageType.UpdateRedis, 5);
        }

        public async Task AutoUpdateTree(string server_id = "60.191.59.11")
        {
            await SetDeptPersonTreeRedisAsync(server_id, false, true, _personTreeKey);
            await SetDeptPersonTreeRedisAsync(server_id, true, true, _driverTreeKey);
            await SetDeptPersonTreeRedisAsync(server_id, false, false, _personMainTreeKey);
        }
    }
}
