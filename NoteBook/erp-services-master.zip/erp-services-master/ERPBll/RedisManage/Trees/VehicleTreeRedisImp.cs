﻿using AutoMapper;
using BusTools.Redis;
using ERPBll.RedisManage.Lines;
using ERPBll.SignalRs;
using ERPCore.Redis;
using ERPDal;
using ErpModel.CommonModel;
using ERPModel.CommonModel;
using ERPModel.DataBase;
using ERPModel.SystemManage;
using ERPModel.Vehicleinfomanage;
using ERPModel.Workplace;
using Masuit.Tools.Models;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.RedisManage.Trees
{
    /// <summary>
    /// 车辆树缓存
    /// </summary>
    public class VehicleTreeRedisImp : IVehicleTreeRedisImp
    {
        // redis车牌号树缓存key
        private readonly string _vehTreeKey = "vehicle_tree";
        private readonly string _vehOilTreeKey = "vehicle_oil_tree";
        private readonly string _vehEltricTreeKey = "vehicle_eltric_tree";
        // redis自编号树缓存key
        private readonly string _vehCodeTreeKey = "vehicle_code_tree";
        private readonly string _vehOilCodeTreeKey = "vehicle_oil_code_tree";
        private readonly string _vehEltricCodeTreeKey = "vehicle_eltric_code_tree";
        private readonly IRedisService _redisService;
        private readonly IMapper _imapper;
        private readonly IDeptRedisImp _deptRedisImp;
        private readonly IVehicleRedisManageImp _vehicleRedisManageImp;
        private readonly ILineTreeRedisImp _lineTreeRedisImp;
        private readonly ILineRedisImp _lineRedisImp;
        private readonly IServerHubImp _iServerHubImp;

        public VehicleTreeRedisImp(
            IMapper imapper,
            IDeptRedisImp deptRedisImp,
            IVehicleRedisManageImp vehicleRedisManageImp,
            ILineTreeRedisImp lineTreeRedisImp,
            IServerHubImp iServerHubImp,
            ILineRedisImp lineRedisImp)
        {
            _redisService = new RedisService(1);
            _imapper = imapper;
            _deptRedisImp = deptRedisImp;
            _vehicleRedisManageImp = vehicleRedisManageImp;
            _lineTreeRedisImp = lineTreeRedisImp;
            _lineRedisImp = lineRedisImp;
            _iServerHubImp = iServerHubImp;
        }

        #region 完整车辆树

        /// <summary>
        /// 完整车牌号树缓存
        /// </summary>
        /// <param name="server_id"></param>
        /// <returns></returns>
        public async Task<List<DeptTree>> GetVehTreeRedisAsync(string server_id)
        {
            if (!_redisService.KeyExists(_vehTreeKey))
            {
                await SetVehTreeRedisAsync(server_id, 0, _vehTreeKey);
            }

            return await _redisService.StringGetAsync<List<DeptTree>>(_vehTreeKey);
        }

        /// <summary>
        /// 完整车牌号树缓存
        /// </summary>
        /// <param name="server_id"></param>
        /// <returns></returns>
        public async Task<List<DeptTree>> GetVehOilTreeRedisAsync(string server_id)
        {
            if (!_redisService.KeyExists(_vehOilTreeKey))
            {
                await SetVehOilTreeRedisAsync(server_id, 0, _vehOilTreeKey);
            }

            return await _redisService.StringGetAsync<List<DeptTree>>(_vehOilTreeKey);
        }

        public async Task<List<DeptTree>> GetVehEletricTreeRedisAsync(string server_id)
        {
            if (!_redisService.KeyExists(_vehEltricTreeKey))
            {
                await SetVehEletricTreeRedisAsync(server_id, 0, _vehEltricTreeKey);
            }

            return await _redisService.StringGetAsync<List<DeptTree>>(_vehEltricTreeKey);
        }

        /// <summary>
        /// 完整自编号树缓存
        /// </summary>
        /// <param name="server_id"></param>
        /// <returns></returns>
        public async Task<List<DeptTree>> GetVehCodeTreeRedisAsync(string server_id)
        {
            if (!_redisService.KeyExists(_vehCodeTreeKey))
            {
                await SetVehTreeRedisAsync(server_id, 1, _vehCodeTreeKey);
            }
            return await _redisService.StringGetAsync<List<DeptTree>>(_vehCodeTreeKey);
        }

        /// <summary>
        /// 完整自编号树缓存
        /// </summary>
        /// <param name="server_id"></param>
        /// <returns></returns>
        public async Task<List<DeptTree>> GetVehOilCodeTreeRedisAsync(string server_id)
        {
            if (!_redisService.KeyExists(_vehOilCodeTreeKey))
            {
                await SetVehOilTreeRedisAsync(server_id, 1, _vehOilCodeTreeKey);
            }
            return await _redisService.StringGetAsync<List<DeptTree>>(_vehOilCodeTreeKey);
        }

        public async Task<List<DeptTree>> GetVehElectricCodeTreeRedisAsync(string server_id)
        {
            if (!_redisService.KeyExists(_vehEltricCodeTreeKey))
            {
                await SetVehEletricTreeRedisAsync(server_id, 1, _vehEltricCodeTreeKey);
            }
            return await _redisService.StringGetAsync<List<DeptTree>>(_vehEltricCodeTreeKey);
        }

        /// <summary>
        /// 刷新缓存
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="type">0车牌号 1自编号</param>
        /// <returns></returns>
        public async Task SetVehTreeRedisAsync(string server_id, int type, string key)
        {
            var list = await GetVehicleTreeAsync(server_id, type);

            var res = _redisService.StringSet(key, list, TimeSpan.FromMinutes(RedisConfigure.TEMPTABLE.CatchTimeMinite));
            if (!res)
            {
                throw new Exception("缓存车牌号树失败!");
            }
        }
        /// <summary>
        /// 刷新缓存
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="type">0车牌号 1自编号</param>
        /// <returns></returns>
        public async Task SetVehOilTreeRedisAsync(string server_id, int type, string key)
        {
            var list = await GetVehicleOilTreeAsync(server_id, type);

            var res = _redisService.StringSet(key, list, TimeSpan.FromMinutes(RedisConfigure.TEMPTABLE.CatchTimeMinite));
            if (!res)
            {
                throw new Exception("缓存车牌号树失败!");
            }
        }

        public async Task SetVehEletricTreeRedisAsync(string server_id, int type, string key)
        {
            var list = await GetVehicleEltricTreeAsync(server_id, type);

            var res = _redisService.StringSet(key, list, TimeSpan.FromMinutes(RedisConfigure.TEMPTABLE.CatchTimeMinite));
            if (!res)
            {
                throw new Exception("缓存车牌号树失败!");
            }
        }

        /// <summary>
        /// 实时完整车辆树
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="type">0车牌号 1自编号</param>
        /// <returns></returns>
        public async Task<List<DeptTree>> GetVehicleTreeAsync(string server_id, int type)
        {
            using var db = SqlSugarHelper.DBClient(server_id);
            //完整线路树
            var dept_tree = await _lineTreeRedisImp.GetLineTreeRedisAsync(server_id);
            //全部车辆信息
            var vehi_all = await db.Queryable<ErpVehicleInfo>()
                                   .Mapper(m =>
                                   {
                                       var cid = m.c_id;
                                       m.ex_type = db.Queryable<MaintVehicleKind, SysCommonDictDetail>((a, b) => new JoinQueryInfos(JoinType.Left, a.c_fuel == b.i_id.ToString())).Where((a, b) => a.i_id == cid).Select((a, b) => b.c_name).Single();
                                   })
                                   .ToListAsync();
            var vehs = vehi_all.Where(x => x.scrap == 0 || x.scrap == null).ToList();
            //全部车辆id
            var vehIds = vehs.Select(x => x.i_id).ToList();
            //全部线路车辆关系
            var line_vehs = await _lineRedisImp.GetLineVehAsync();
            line_vehs.ForEach(x =>
            {
                var info = vehs.FirstOrDefault(i => i.c_lincense_plate_number == x.lp_num);
                if (info != null)
                {
                    x.vehicle_id_erp = info.i_id;
                    if (type == 1)
                    {
                        x.lp_num = info.c_vehicle_number;
                    }
                }
            });
            //移除无效的车辆
            line_vehs = line_vehs.Where(x => x.vehicle_id_erp.HasValue).ToList();
            //全部已有线路的车辆
            var has_line_veh = line_vehs.Select(x => x.lp_num).ToList();
            //获取无线路的车辆id
            var ids = vehs.Where(x => !has_line_veh.Contains(x.c_lincense_plate_number)).Select(x => x.i_id).ToList();
            if (type == 1)
            {
                ids = vehs.Where(x => !has_line_veh.Contains(x.c_vehicle_number)).Select(x => x.i_id).ToList();
            }

            return await GetVehicleTreeLoop(dept_tree, vehs, line_vehs, ids, type);
        }

        /// <summary>
        /// 燃油车辆树
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="type">0车牌号 1自编号</param>
        /// <returns></returns>
        public async Task<List<DeptTree>> GetVehicleOilTreeAsync(string server_id, int type)
        {
            using var db = SqlSugarHelper.DBClient(server_id);
            //完整线路树
            var dept_tree = await _lineTreeRedisImp.GetLineTreeRedisAsync(server_id);
            //全部车辆信息
            var vehi_all = await db.Queryable<ErpVehicleInfo>()
                                   .Mapper(m =>
                                   {
                                       var cid = m.c_id;
                                       m.ex_type = db.Queryable<MaintVehicleKind, SysCommonDictDetail>((a, b) => new JoinQueryInfos(JoinType.Left, a.c_fuel == b.i_id.ToString())).Where((a, b) => a.i_id == cid).Select((a, b) => b.c_name).Single();
                                   })
                                   .ToListAsync();
            var vehs = vehi_all.Where(x => x.scrap == 0 || x.scrap == null).Where(x => x.ex_type == "柴油").ToList();
            //全部车辆id
            var vehIds = vehs.Select(x => x.i_id).ToList();
            //全部线路车辆关系
            var line_vehs = await _lineRedisImp.GetLineVehOilAsync();
            line_vehs.ForEach(x =>
            {
                var info = vehs.FirstOrDefault(i => i.c_lincense_plate_number == x.lp_num);
                if (info != null)
                {
                    x.vehicle_id_erp = info.i_id;
                    if (type == 1)
                    {
                        x.lp_num = info.c_vehicle_number;
                    }
                }
            });
            //移除无效的车辆
            line_vehs = line_vehs.Where(x => x.vehicle_id_erp.HasValue).ToList();
            //全部已有线路的车辆
            var has_line_veh = line_vehs.Select(x => x.lp_num).ToList();
            //获取无线路的车辆id
            var ids = vehs.Where(x => !has_line_veh.Contains(x.c_lincense_plate_number)).Select(x => x.i_id).ToList();
            if (type == 1)
            {
                ids = vehs.Where(x => !has_line_veh.Contains(x.c_vehicle_number)).Select(x => x.i_id).ToList();
            }

            return await GetVehicleTreeLoop(dept_tree, vehs, line_vehs, ids, type);
        }
        public async Task<List<DeptTree>> GetVehicleEltricTreeAsync(string server_id, int type)
        {
            using var db = SqlSugarHelper.DBClient(server_id);
            //完整线路树
            var dept_tree = await _lineTreeRedisImp.GetLineTreeRedisAsync(server_id);
            //全部车辆信息
            var vehi_all = await db.Queryable<ErpVehicleInfo>()
                                   .Mapper(m =>
                                   {
                                       var cid = m.c_id;
                                       m.ex_type = db.Queryable<MaintVehicleKind, SysCommonDictDetail>((a, b) => new JoinQueryInfos(JoinType.Left, a.c_fuel == b.i_id.ToString())).Where((a, b) => a.i_id == cid).Select((a, b) => b.c_name).Single();
                                   })
                                   .ToListAsync();
            var vehs = vehi_all.Where(x => x.scrap == 0 || x.scrap == null).Where(x => x.ex_type == "纯电动").ToList();
            //全部车辆id
            var vehIds = vehs.Select(x => x.i_id).ToList();
            //全部线路车辆关系
            var line_vehs = await _lineRedisImp.GetLineVehEltricAsync();
            line_vehs.ForEach(x =>
            {
                var info = vehs.FirstOrDefault(i => i.c_lincense_plate_number == x.lp_num);
                if (info != null)
                {
                    x.vehicle_id_erp = info.i_id;
                    if (type == 1)
                    {
                        x.lp_num = info.c_vehicle_number;
                    }
                }
            });
            //移除无效的车辆
            line_vehs = line_vehs.Where(x => x.vehicle_id_erp.HasValue).ToList();
            //全部已有线路的车辆
            var has_line_veh = line_vehs.Select(x => x.lp_num).ToList();
            //获取无线路的车辆id
            var ids = vehs.Where(x => !has_line_veh.Contains(x.c_lincense_plate_number)).Select(x => x.i_id).ToList();
            if (type == 1)
            {
                ids = vehs.Where(x => !has_line_veh.Contains(x.c_vehicle_number)).Select(x => x.i_id).ToList();
            }

            return await GetVehicleTreeLoop(dept_tree, vehs, line_vehs, ids, type);
        }

        public async Task<Tuple<int, List<DeptTree>>> GetVehicleTreeByUserAsync(string server_id, decimal? user_id, decimal kind_id, decimal oil_type, int type)
        {
            using var db = SqlSugarHelper.DBClient(server_id);
            //完整线路树
            var dept_tree = await _lineTreeRedisImp.GetLineTreeRedisAsync(server_id);
            //全部车辆信息
            var vehi_all = await db.Queryable<ErpVehicleInfo>()
                                   .Includes(r => r.kind_info)
                                   .ToListAsync();
            var vehs = vehi_all.Where(x => x.scrap == 0 || x.scrap == null).ToList();
            if (kind_id > 0) vehs = vehs.Where(r => r.c_id == kind_id).ToList();
            if (oil_type > 0) vehs = vehs.Where(r => Convert.ToDecimal(r.kind_info?.c_fuel) == oil_type).ToList();
            int total = vehs.Count();

            //全部线路车辆关系
            var lines = (await _lineRedisImp.GetAllAsync()).Where(x => x.usable == 1 && !string.IsNullOrEmpty(x.name)).ToList();
            var dep_lines = await db.Queryable<SysDepLine>()
                .Where(r => lines.Select(m => m.id).Contains(r.i_line_id))
                .ToListAsync();
          
            //获取无线路的车辆id
            var ids = vehs.Where(x => x.line_id == null || (x.line_id.HasValue && !dep_lines.Select(m => m.i_line_id).Contains(x.line_id.Value))).Select(x => x.i_id).ToList();

            var tree = await GetVehicleTreeLoop1(dept_tree, vehs, ids, type);

            //过滤权限
            var (orgs_parents, orgs) = await _deptRedisImp.QueryDeptId(server_id, user_id, 1);

            if (orgs_parents == null) //管理员
            {
                return new Tuple<int, List<DeptTree>>(total, tree);
            }

            var data = await _deptRedisImp.GetDeptTreeUserLoop(tree, orgs_parents, orgs);
            return new Tuple<int, List<DeptTree>>(total, await GetHasVehicleTreeLoop(data));
        }

        private async Task<List<DeptTree>> GetVehicleTreeLoop1(List<DeptTree> list, List<ErpVehicleInfo> vehs, List<decimal?> no_line_veh, int type)
        {
            foreach (var item in list)
            {
                if (item.children != null && item.children.Count > 0)
                {
                    await GetVehicleTreeLoop1(item.children, vehs, no_line_veh, type);
                }
                else
                {
                    item.children = new List<DeptTree>();
                }

                if (item.type == 2) //当前节点是线路
                {
                    var temps = vehs.Where(r => r.line_id == item.i_id).ToList();
                    var childs = temps.Select(r => new DeptTree
                    {
                        i_id = r.i_id,
                        c_name = type == 0 ? r.c_lincense_plate_number : type == 1 ? r.c_vehicle_number : $"{r.c_vehicle_number}({r.c_lincense_plate_number})",
                        parent_id = item.i_id,
                        type = 3
                    }).ToList();

                    //计算线路下所有车数量
                    item.children_count = childs.Count();
                    item.c_name += $"({item.children_count})";
                    item.children.AddRange(childs);
                }

                if (item.type == 1) //当前节点是部门
                {
                    //查询当前部门下无线路车辆
                    var childs = vehs.Where(x => x.c_crews_take == ((int)item.i_id.Value).ToString() && no_line_veh.Contains(x.i_id))
                                    .OrderBy(x => x.c_lincense_plate_number)
                                    .Select(x => new DeptTree()
                                    {
                                        i_id = x.i_id,
                                        parent_id = item.i_id,
                                        c_name = type == 0 ? x.c_lincense_plate_number : type == 1 ? x.c_vehicle_number : $"{x.c_vehicle_number}({x.c_lincense_plate_number})",
                                        type = 3
                                    })
                                    .ToList();
                    //计算部门下所有的车数量
                    item.children_count = item.children.Sum(x => x.children_count) + childs.Count;
                    item.c_name += $"({item.children_count})";
                    item.children.AddRange(childs);

                }
            }
            return list;
        }

        public async Task<List<DeptTree>> GetVehicleTreeLoop(
            List<DeptTree> list, List<ErpVehicleInfo> vehs, List<DispatchVehicleInfo> line_vehs, List<decimal?> no_line_veh, int type)
        {
            foreach (var item in list)
            {
                if (item.children != null && item.children.Count > 0)
                {
                    await GetVehicleTreeLoop(item.children, vehs, line_vehs, no_line_veh, type);
                }
                else
                {
                    item.children = new List<DeptTree>();
                }

                if (item.type == 2) //当前节点是线路
                {
                    var temps = line_vehs.Where(x => x.line_id == item.i_id)
                                            .OrderBy(x => x.lp_num)
                                            .ToList();
                    var childs = _imapper.Map<List<DispatchVehicleInfo>, List<DeptTree>>(temps);

                    childs.ForEach(x => { x.parent_id = item.i_id; x.type = 3; });

                    //计算线路下所有车数量
                    item.children_count = childs.Count;
                    item.c_name += $"({item.children_count})";
                    item.children.AddRange(childs);
                }

                if (item.type == 1) //当前节点是部门
                {
                    if (type == 0) //车牌号树
                    {
                        //查询当前部门下无线路车辆
                        var childs = vehs.Where(x => x.c_crews_take == ((int)item.i_id.Value).ToString() && no_line_veh.Contains(x.i_id))
                                        .OrderBy(x => x.c_lincense_plate_number)
                                        .Select(x => new DeptTree()
                                        {
                                            i_id = x.i_id,
                                            parent_id = item.i_id,
                                            c_name = x.c_lincense_plate_number,
                                            type = 3
                                        })
                                        .ToList();
                        //计算部门下所有的车数量
                        item.children_count = item.children.Sum(x => x.children_count) + childs.Count;
                        item.c_name += $"({item.children_count})";
                        item.children.AddRange(childs);
                    }
                    if (type == 1) //自编号树
                    {
                        //查询当前部门下无线路车辆
                        var childs = vehs.Where(x => x.c_crews_take == ((int)item.i_id.Value).ToString() && no_line_veh.Contains(x.i_id))
                                        .OrderBy(x => x.c_vehicle_number)
                                        .Select(x => new DeptTree()
                                        {
                                            i_id = x.i_id,
                                            parent_id = item.i_id,
                                            c_name = x.c_vehicle_number,
                                            type = 3
                                        })
                                        .ToList();
                        //计算部门下所有的车数量
                        item.children_count = item.children.Sum(x => x.children_count) + childs.Count;
                        item.c_name += $"({item.children_count})";
                        item.children.AddRange(childs);
                    }
                    if (type == 2) //车牌号(自编号)树
                    {
                        //查询当前部门下无线路车辆
                        var childs = vehs.Where(x => x.c_crews_take == ((int)item.i_id.Value).ToString() && no_line_veh.Contains(x.i_id))
                                        .OrderBy(x => x.c_lincense_plate_number)
                                        .Select(x => new DeptTree()
                                        {
                                            i_id = x.i_id,
                                            parent_id = item.i_id,
                                            c_name = $"{x.c_vehicle_number}({x.c_lincense_plate_number})",
                                            type = 3
                                        })
                                        .ToList();
                        //计算部门下所有的车数量
                        item.children_count = item.children.Sum(x => x.children_count) + childs.Count;
                        item.c_name += $"({item.children_count})";
                        item.children.AddRange(childs);
                    }
                }
            }
            return list;
        }

        #endregion

        #region 权限车辆树

        /// <summary>
        /// 权限车牌号树
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="user_id"></param>
        /// <returns></returns>
        public async Task<List<DeptTree>> GetVehTreeByUserAsync(string server_id, decimal? user_id, int? func_type = null)
        {
            DateTime dt = DateTime.Now;
            var tree = await GetVehicleTreeAsync(server_id, 0);

            //过滤权限
            var (orgs_parents, orgs) = await _deptRedisImp.QueryDeptId(server_id, user_id, func_type);

            if (orgs_parents == null) //管理员
            {
                return tree;
            }

            var data = await _deptRedisImp.GetDeptTreeUserLoop(tree, orgs_parents, orgs);
            return await GetHasVehicleTreeLoop(data);
        }

        /// <summary>
        /// 权限车牌号树
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="user_id"></param>
        /// <returns></returns>
        public async Task<List<DeptTree>> GetVehOilTreeByUserAsync(string server_id, decimal? user_id, int? func_type = null)
        {
            DateTime dt = DateTime.Now;
            var tree = await GetVehicleOilTreeAsync(server_id, 0);

            //过滤权限
            var (orgs_parents, orgs) = await _deptRedisImp.QueryDeptId(server_id, user_id, func_type);

            if (orgs_parents == null) //管理员
            {
                return tree;
            }

            var data = await _deptRedisImp.GetDeptTreeUserLoop(tree, orgs_parents, orgs);
            return await GetHasVehicleTreeLoop(data);
        }

        public async Task<List<DeptTree>> GetVehEletricTreeByUserAsync(string server_id, decimal? user_id, int? func_type = null)
        {
            DateTime dt = DateTime.Now;
            var tree = await GetVehicleEltricTreeAsync(server_id, 0);

            //过滤权限
            var (orgs_parents, orgs) = await _deptRedisImp.QueryDeptId(server_id, user_id, func_type);

            if (orgs_parents == null) //管理员
            {
                return tree;
            }

            var data = await _deptRedisImp.GetDeptTreeUserLoop(tree, orgs_parents, orgs);
            return await GetHasVehicleTreeLoop(data);
        }


        /// <summary>
        /// 权限自编号树
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="user_id"></param>
        /// <returns></returns>
        public async Task<List<DeptTree>> GetVehCodeTreeByUserAsync(string server_id, decimal? user_id, int? func_type = null)
        {
            DateTime dt = DateTime.Now;
            var tree = await GetVehCodeTreeRedisAsync(server_id);

            //过滤权限
            var (orgs_parents, orgs) = await _deptRedisImp.QueryDeptId(server_id, user_id, func_type);

            if (orgs_parents == null) //管理员
            {
                return tree;
            }

            var data = await _deptRedisImp.GetDeptTreeUserLoop(tree, orgs_parents, orgs);
            return await GetHasVehicleTreeLoop(data);
        }

        /// <summary>
        /// 权限自编号树
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="user_id"></param>
        /// <returns></returns>
        public async Task<List<DeptTree>> GetVehOilCodeTreeByUserAsync(string server_id, decimal? user_id, int? func_type = null)
        {
            DateTime dt = DateTime.Now;
            var tree = await GetVehOilCodeTreeRedisAsync(server_id);

            //过滤权限
            var (orgs_parents, orgs) = await _deptRedisImp.QueryDeptId(server_id, user_id, func_type);

            if (orgs_parents == null) //管理员
            {
                return tree;
            }

            var data = await _deptRedisImp.GetDeptTreeUserLoop(tree, orgs_parents, orgs);
            return await GetHasVehicleTreeLoop(data);
        }

        public async Task<List<DeptTree>> GetVehEletricCodeTreeByUserAsync(string server_id, decimal? user_id, int? func_type = null)
        {
            DateTime dt = DateTime.Now;
            var tree = await GetVehElectricCodeTreeRedisAsync(server_id);

            //过滤权限
            var (orgs_parents, orgs) = await _deptRedisImp.QueryDeptId(server_id, user_id, func_type);

            if (orgs_parents == null) //管理员
            {
                return tree;
            }

            var data = await _deptRedisImp.GetDeptTreeUserLoop(tree, orgs_parents, orgs);
            return await GetHasVehicleTreeLoop(data);
        }

        /// <summary>
        /// 过滤无车辆节点
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="user_id"></param>
        /// <returns></returns>
        public async Task<List<DeptTree>> GetHasVehicleTreeLoop(List<DeptTree> list)
        {
            list = list.Where(x => x.type == 3 || x.children_count > 0).ToList();

            foreach (var item in list)
            {
                if (item.children != null && item.children.Count() > 0)
                {
                    item.children = await GetHasVehicleTreeLoop(item.children);
                }
                else
                {
                    item.children = new List<DeptTree>();
                }
            }
            return list;
        }

        #endregion

        /// <summary>
        /// 清除缓存
        /// </summary>
        public void ClearKey()
        {
            _redisService.KeyDelete(_vehTreeKey);
            _redisService.KeyDelete(_vehOilTreeKey);
            _redisService.KeyDelete(_vehEltricTreeKey);
            _redisService.KeyDelete(_vehCodeTreeKey);
            _redisService.KeyDelete(_vehOilCodeTreeKey);
            _redisService.KeyDelete(_vehEltricCodeTreeKey);

            _iServerHubImp.SendMessageToAllAsync(MessageType.UpdateRedis, 2);
        }

        public async Task AutoUpdateTree(string server_id = "60.191.59.11")
        {
            await SetVehTreeRedisAsync(server_id, 0, _vehTreeKey);
            await SetVehOilTreeRedisAsync(server_id, 0, _vehOilTreeKey);
            await SetVehEletricTreeRedisAsync(server_id, 0, _vehEltricTreeKey);
            await SetVehTreeRedisAsync(server_id, 1, _vehCodeTreeKey);
            await SetVehOilTreeRedisAsync(server_id, 1, _vehOilCodeTreeKey);
            await SetVehEletricTreeRedisAsync(server_id, 1, _vehEltricCodeTreeKey);
        }
    }
}
