﻿using AutoMapper;
using BusTools.Redis;
using ERPBll.RedisManage.Lines;
using ERPBll.SignalRs;
using ERPBll.UserManage;
using ERPCore.Redis;
using ERPDal;
using ERPModel.CommonModel;
using ERPModel.UserManage;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.RedisManage.Trees
{
    /// <summary>
    /// 部门树
    /// </summary>
    public class DeptRedisImp : IDeptRedisImp
    {
        /// <summary>
        /// redis部门信息缓存key
        /// </summary>
        private readonly string _deptKey = "dept_person";
        private readonly string _deptTreeKey = "dept_tree";
        private readonly IRedisService _redisService;
        private readonly IMapper _imapper;
        private readonly IServerHubImp _iServerHubImp;

        public DeptRedisImp(
            IServerHubImp iServerHubImp,
             IMapper imapper)
        {
            _redisService = new RedisService(1);
            _imapper = imapper;
            _iServerHubImp = iServerHubImp;
        }

        #region 部门信息

        public async Task<List<SysDepPerson>> GetAllAsync()
        {
            if (!_redisService.KeyExists(_deptKey))
            {
                await SetAll();
            }
            return await _redisService.StringGetAsync<List<SysDepPerson>>(_deptKey);
        }

        public async Task SetAll(string server_id = "60.191.59.11")
        {
            var list = await SqlSugarHelper.DBClient(server_id)
                        .Queryable<SysDepPerson>()
                        .Where(x => x.i_child_id < 2000000)
                        .Mapper(x => x.child_info, x => x.i_child_id)
                        .Mapper(x => x.group_info, x => x.i_group_id)
                        .ToListAsync();

            var res = _redisService.StringSet(_deptKey, list, TimeSpan.FromMinutes(RedisConfigure.TEMPTABLE.CatchTimeMinite));
            if (!res)
            {
                throw new Exception("缓存部门人员失败!");
            }
        }

        #endregion

        #region 部门树

        public async Task<List<DeptTree>> GetDeptTreeRedisAsync(string server_id)
        {
            if (!_redisService.KeyExists(_deptTreeKey))
            {
                await SetDeptTreeRedisAll(server_id);
            }
            return await _redisService.StringGetAsync<List<DeptTree>>(_deptTreeKey);
        }

        public async Task SetDeptTreeRedisAll(string server_id)
        {
            var list = await GetDeptTreeAsync(server_id);

            var res = _redisService.StringSet(_deptTreeKey, list, TimeSpan.FromMinutes(RedisConfigure.TEMPTABLE.CatchTimeMinite));
            if (!res)
            {
                throw new Exception("缓存部门树失败!");
            }
        }


        /// <summary>
        /// 获取完整部门组织树
        /// </summary>
        /// <param name="server_id"></param>
        /// <returns></returns>
        private async Task<List<DeptTree>> GetDeptTreeAsync(string server_id)
        {
            List<DeptTree> list = new List<DeptTree>();
            var data = await GetAllAsync();
            var roots = data.FirstOrDefault(x => x.i_group_id == 1000016).group_info;
            //组装部门树
            return new List<DeptTree>
            {
                await GetDeptTreeLoop(data, new DeptTree()
                {
                    i_id = roots.i_id,
                    c_name = roots.c_name,
                    parent_id = 0,
                    type = 1
                })
            };
        }

        /// <summary>
        /// 组装完整部门树
        /// </summary>
        private async Task<DeptTree> GetDeptTreeLoop(List<SysDepPerson> list, DeptTree tree)
        {
            var data = list.Where(x => x.i_group_id == tree.i_id).ToList();
            if (data == null || data.Count() < 1)
            {
                return tree;
            } 
            tree.children = _imapper.Map<List<SysDepPerson>, List<DeptTree>>(data)
                                .OrderBy(x => x.i_sort)
                                .ToList();

            tree.children.ForEach(x => x.type = 1);

            foreach (var item in tree.children)
            {
                item.parent_id = tree.i_id;
                await GetDeptTreeLoop(list, item);
            }
            return tree;
        }

        #endregion

        #region 权限部门树

        public async Task<List<DeptTree>> GetDeptTreeByUserAsync(string server_id, decimal? user_id, int? func_type = null)
        {
            var tree = await GetDeptTreeRedisAsync(server_id);

            var (orgs_parents, orgs) = await QueryDeptId(server_id, user_id, func_type);

            if (orgs_parents == null) //管理员
            {
                return tree;
            }

            return await GetDeptTreeUserLoop(tree, orgs_parents, orgs);
        }

        /// <summary>
        /// 查询用户管理部门(包含上级)
        /// </summary>
        /// <returns></returns>
        public async Task<(List<decimal>, List<decimal>)> QueryDeptId(string server_id, decimal? user_id, int? func_type = null)
        {
            var orgs = RoleInfoBll.GetGroupID(server_id, user_id);
             if (orgs == null) //管理员角色
            {
                //过滤单元
                if (func_type != null && func_type > 0)
                {
                    var dept_funcs = await SqlSugarHelper.DBClient(server_id)
                                            .Queryable<SysDepFunction>()
                                            .Where(x => x.i_func_type == func_type)
                                            .Select(x => x.i_main_id.Value)
                                            .ToListAsync();
                    return (dept_funcs, orgs);
                }
                return (orgs, orgs);
            }

            if(orgs.Count < 1) //角色无部门权限
            {
                return (orgs, orgs);
            }

            var list = new List<decimal>();
            var deps = await GetAllAsync();
            foreach (var item in orgs)
            {
                if (!list.Contains(item))
                {
                    list.Add(item);
                    await QueryGroupLoopAsync(server_id, item, deps, list);
                }
            }
            //过滤单元
            if (func_type != null && func_type > 0)
            {
                var dept_funcs = await SqlSugarHelper.DBClient(server_id)
                                        .Queryable<SysDepFunction>()
                                        .Where(x => x.i_func_type == func_type)
                                        .Select(x => x.i_main_id.Value)
                                        .ToListAsync();
                list = list.Intersect(dept_funcs).ToList();
            }
            return (list, orgs);
        }

        /// <summary>
        /// 组装权限部门树
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="user_id"></param>
        /// <returns></returns>
        public async Task<List<DeptTree>> GetDeptTreeUserLoop(
            List<DeptTree> list, List<decimal> orgs_parents, List<decimal> orgs)
        {
            list = list.Where(x => x.type != 1 || orgs_parents.Contains(x.i_id.Value)).ToList();

            foreach (var item in list)
            {
                if (item.children != null && item.children.Count() > 0)
                {
                    if (item.type == 1 && orgs != null && !orgs.Contains(item.i_id.Value))
                    {
                        //当前节点无权限，只用于展示树结构
                        item.children = item.children.Where(x => x.type == 1).ToList();
                    }
                    item.children = await GetDeptTreeUserLoop(item.children, orgs_parents, orgs);
                }
            }
            return list;
        }    

        /// <summary>
        /// 查询部门的所有上级
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="id"></param>
        /// <param name="list"></param>
        /// <returns></returns>
        public async Task<List<decimal>> QueryGroupLoopAsync(string server_id, decimal id, List<SysDepPerson> deps, List<decimal> list = null)
        {
            var query = deps.Where(x => x.i_child_id == id).FirstOrDefault();

            if (query != null && !list.Contains(query.i_group_id.Value))
            {
                list.Add(query.i_group_id.Value);
                await QueryGroupLoopAsync(server_id, query.i_group_id.Value, deps, list);
            }
            return list;
        }

        #endregion

        /// <summary>
        /// 清除缓存
        /// </summary>
        public void ClearKey()
        {
            _redisService.KeyDelete(_deptKey);
            _redisService.KeyDelete(_deptTreeKey);

            _iServerHubImp.SendMessageToAllAsync(MessageType.UpdateRedis, 4);
        }

        public async Task AutoUpdateTree(string server_id = "60.191.59.11")
        {
            await SetDeptTreeRedisAll(server_id);
        }
    }
}
