﻿using ERPModel.CommonModel;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.RedisManage.Trees
{
    public interface IVehicleTreeRedisImp
    {
        /// <summary>
        /// 完整车牌号树
        /// </summary>
        /// <returns></returns>
        Task<List<DeptTree>> GetVehTreeRedisAsync(string server_id);

        /// <summary>
        /// 完整自编号树
        /// </summary>
        /// <returns></returns>
        Task<List<DeptTree>> GetVehCodeTreeRedisAsync(string server_id);

        /// <summary>
        /// 权限车牌号树
        /// </summary>
        /// <returns></returns>
        Task<List<DeptTree>> GetVehTreeByUserAsync(string server_id, decimal? user_id, int? func_type = null);
        Task<List<DeptTree>> GetVehOilTreeByUserAsync(string server_id, decimal? user_id, int? func_type = null);
        Task<List<DeptTree>> GetVehEletricTreeByUserAsync(string server_id, decimal? user_id, int? func_type = null);

        /// <summary>
        /// 权限自编号树
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="user_id"></param>
        /// <returns></returns>
        Task<List<DeptTree>> GetVehCodeTreeByUserAsync(string server_id, decimal? user_id, int? func_type = null);
        Task<List<DeptTree>> GetVehOilCodeTreeByUserAsync(string server_id, decimal? user_id, int? func_type = null);
        Task<List<DeptTree>> GetVehEletricCodeTreeByUserAsync(string server_id, decimal? user_id, int? func_type = null);

        /// <summary>
        /// 获取新的车辆树
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="user_id"></param>
        /// <param name="kind_id">车型ID</param>
        /// <param name="oil_type">燃料ID</param>
        /// <param name="type">0车牌号 1自编号 2车牌号（自编号）</param>
        /// <returns></returns>
        Task<Tuple<int,List<DeptTree>>> GetVehicleTreeByUserAsync(string server_id, decimal? user_id, decimal kind_id, decimal oil_type, int type);
        /// <summary>
        /// 刷新车辆树缓存
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="type">0车牌号 1自编号</param>
        /// <returns></returns>
        Task SetVehTreeRedisAsync(string server_id, int type, string key);

        /// <summary>
        /// 刷新燃油车缓存
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="type">0车牌号 1自编号</param>
        /// <returns></returns>
        Task SetVehOilTreeRedisAsync(string server_id, int type, string key);

        /// <summary>
        /// 刷新电车缓存
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="type">0车牌号 1自编号</param>
        /// <param name="key"></param>
        /// <returns></returns>
        Task SetVehEletricTreeRedisAsync(string server_id, int type, string key);

        /// <summary>
        /// 清除缓存
        /// </summary>
        void ClearKey();

        /// <summary>
        /// 更新树缓存
        /// </summary>
        Task AutoUpdateTree(string server_id = "60.191.59.11");
    }
}
