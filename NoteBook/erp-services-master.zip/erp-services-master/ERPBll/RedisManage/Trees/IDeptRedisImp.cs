﻿using ERPModel.CommonModel;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.RedisManage.Trees
{
    /// <summary>
    /// 部门树
    /// </summary>
    public interface IDeptRedisImp
    {
        /// <summary>
        /// 获取完整部门组织树
        /// </summary>
        /// <param name="server_id"></param>
        /// <returns></returns>
        Task<List<DeptTree>> GetDeptTreeRedisAsync(string server_id);

        /// <summary>
        /// 获取用户管理的部门树
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="user_id"></param>
        /// <returns></returns>
        Task<List<DeptTree>> GetDeptTreeByUserAsync(string server_id, decimal? user_id, int? func_type = null);

        /// <summary>
        /// 查询用户管理部门(包含上级)
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="user_id"></param>
        /// <returns></returns>
        Task<(List<decimal>, List<decimal>)> QueryDeptId(string server_id, decimal? user_id, int? func_type = null);

        /// <summary>
        /// 组装权限部门树
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="user_id"></param>
        /// <returns></returns>
        Task<List<DeptTree>> GetDeptTreeUserLoop(List<DeptTree> list, List<decimal> orgs_parents, List<decimal> orgs);

        /// <summary>
        /// 清除缓存
        /// </summary>
        void ClearKey();

        /// <summary>
        /// 更新树缓存
        /// </summary>
        Task AutoUpdateTree(string server_id = "60.191.59.11");
    }
}
