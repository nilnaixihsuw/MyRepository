﻿using AutoMapper;
using BusTools.Redis;
using ERPBll.RedisManage.Lines;
using ERPBll.SignalRs;
using ERPCore.Redis;
using ERPDal;
using ERPModel.CommonModel;
using ERPModel.SystemManage;
using ERPModel.UserManage;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.RedisManage.Trees
{
    /// <summary>
    /// 线路树缓存
    /// 过滤权限过程：
    /// 1.缓存完整线路树
    /// 2.获取用户管理部门id（如有查询条件在这处理）
    /// 3.过滤完整线路树，只保留第二步id
    /// </summary>
    public class LineTreeRedisImp: ILineTreeRedisImp
    {
        /// <summary>
        /// redis人员信息缓存key
        /// </summary>
        private readonly string _lineTreeKey = "line_tree";
        private readonly IRedisService _redisService;
        private readonly IMapper _imapper;
        private readonly IDeptRedisImp _deptRedisImp;
        private readonly ILineRedisImp _lineRedisImp;
        private readonly IServerHubImp _iServerHubImp;

        public LineTreeRedisImp(
            IDeptRedisImp deptRedisImp,
            ILineRedisImp lineRedisImp,
            IServerHubImp iServerHubImp,
            IMapper imapper)
        {
            _redisService = new RedisService(1);
            _imapper = imapper;
            _deptRedisImp = deptRedisImp;
            _lineRedisImp = lineRedisImp;
            _iServerHubImp = iServerHubImp;
        }

        #region 完整线路树

        /// <summary>
        /// 完整线路树缓存
        /// </summary>
        /// <param name="server_id"></param>
        /// <returns></returns>
        public async Task<List<DeptTree>> GetLineTreeRedisAsync(string server_id)
        {
            if (!_redisService.KeyExists(_lineTreeKey))
            {
                await SetLineTreeRedisAsync(server_id);
            }
            return await _redisService.StringGetAsync<List<DeptTree>>(_lineTreeKey);
        }

        public async Task SetLineTreeRedisAsync(string server_id)
        {
            var list = await GetLineTreeAsync(server_id);

            var res = _redisService.StringSet(_lineTreeKey, list, TimeSpan.FromMinutes(RedisConfigure.TEMPTABLE.CatchTimeMinite));
            if (!res)
            {
                throw new Exception("缓存线路树失败!");
            }
        }

        /// <summary>
        /// 完整线路树
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="user_id"></param>
        /// <returns></returns>
        public async Task<List<DeptTree>> GetLineTreeAsync(string server_id)
        {
            var dept_tree = await _deptRedisImp.GetDeptTreeRedisAsync(server_id);
            var lines = (await _lineRedisImp.GetAllAsync()).Where(x => x.usable == 1).ToList();
            var dep_lines = await SqlSugarHelper.DBClient(server_id)
                                        .Queryable<SysDepLine>()
                                        .ToListAsync();
            dep_lines.ForEach(x => x.line_name = lines.FirstOrDefault(i => i.id == x.i_line_id)?.name);
            dep_lines.RemoveAll(x => { return string.IsNullOrWhiteSpace(x.line_name); });
            var data = await GetLineTreeLoop(dept_tree, dep_lines);
            return data;
        }

        public async Task<List<DeptTree>> GetLineTreeLoop(List<DeptTree> list, List<SysDepLine> lines, int? func_type = null)
        {
            foreach (var item in list)
            {
                if (item.children != null && item.children.Count > 0)
                {
                    await GetLineTreeLoop(item.children, lines, func_type);
                }
                else
                {
                    item.children = new List<DeptTree>();
                }

                var temps = lines.Where(x => x.i_department_id == ((int)item.i_id.Value).ToString())
                                .OrderBy(x => x.line_name)
                                .ToList();
                var childs = _imapper.Map<List<SysDepLine>, List<DeptTree>>(temps);
                childs.ForEach(x => { x.parent_id = item.i_id; x.type = 2; });
                item.children.AddRange(childs);
            }
            return list;
        }

        #endregion

        #region 权限线路树

        /// <summary>
        /// 权限线路树
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="user_id"></param>
        /// <returns></returns>
        public async Task<List<DeptTree>> GetLineTreeByUserAsync(string server_id, decimal? user_id, int? func_type = null)
        {           
            var tree = await GetLineTreeRedisAsync(server_id);

            //过滤权限
            var (orgs_parents, orgs) = await _deptRedisImp.QueryDeptId(server_id, user_id, func_type);

            if (orgs_parents == null) //管理员
            {
                return tree;
            }

            var data = await _deptRedisImp.GetDeptTreeUserLoop(tree, orgs_parents, orgs);
            return data;
        }

        #endregion   

        /// <summary>
        /// 清除缓存
        /// </summary>
        public void ClearKey()
        {
            _redisService.KeyDelete(_lineTreeKey);

            _iServerHubImp.SendMessageToAllAsync(MessageType.UpdateRedis, 3);
        }

        public async Task AutoUpdateTree(string server_id = "60.191.59.11")
        {
            await SetLineTreeRedisAsync(server_id);
        }
    }
}
