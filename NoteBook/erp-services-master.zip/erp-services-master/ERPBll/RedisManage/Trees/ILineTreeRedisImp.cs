﻿using ERPModel.CommonModel;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.RedisManage.Trees
{
    /// <summary>
    /// 线路树
    /// </summary>
    public interface ILineTreeRedisImp
    {
        /// <summary>
        /// 完整线路树
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="user_id"></param>
        /// <returns></returns>
        Task<List<DeptTree>> GetLineTreeRedisAsync(string server_id);

        /// <summary>
        /// 权限线路树
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="user_id"></param>
        /// <param name="func_type"></param>
        /// <returns></returns>
        Task<List<DeptTree>> GetLineTreeByUserAsync(string server_id, decimal? user_id, int? func_type = null);

        /// <summary>
        /// 清除缓存
        /// </summary>
        void ClearKey();

        /// <summary>
        /// 更新树缓存
        /// </summary>
        Task AutoUpdateTree(string server_id = "60.191.59.11");
    }
}
