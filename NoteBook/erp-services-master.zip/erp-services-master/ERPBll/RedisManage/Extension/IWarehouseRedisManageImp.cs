﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.RedisManage.Extension
{
    public interface IWarehouseRedisManageImp
    {
        /// <summary>
        /// 单号获取
        /// </summary>
        /// <param name="date"></param>
        /// <param name="type">0：入库单号 1：入库单明细批次号 2：出库单号 3：出库单明细批次号 4：外修工单号 5：维修工单号</param>
        /// <returns></returns>
        Task<string> GetBatno(DateTime date, int type);
        /// <summary>
        /// 单号写入
        /// </summary>
        /// <param name="date"></param>
        /// <param name="value"></param>
        /// <param name="type">0：入库单号 1：入库单明细批次号 2：出库单号 3：出库单明细批次号 4：外修工单号 5：维修工单号</param>
        /// <returns></returns>
        Task SetBatno(DateTime date, int value, int type);
    }
}
