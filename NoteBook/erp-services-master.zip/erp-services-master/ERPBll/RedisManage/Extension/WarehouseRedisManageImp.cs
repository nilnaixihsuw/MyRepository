﻿using BusTools.Redis;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.RedisManage.Extension
{
    public class WarehouseRedisManageImp : IWarehouseRedisManageImp
    {
        private readonly string _batnoKey = "batno";//入库单号
        private readonly string _batno1Key = "batno1";//入库单明细批次号
        private readonly string _batno2Key = "batno2";//出库单号
        private readonly string _batno3Key = "batno3";//外修工单号
        private readonly string _batno4Key = "batno4";//工会会员档案编号
        private readonly string _batno5Key = "batno5";//维修工单号
        private readonly string _batno6Key = "batno6";//采购单编号
        private readonly string _batno7Key = "batno7";//领料编号
        private readonly string _batno8Key = "batno8";//退料编号
        private readonly IRedisService _redisService;
        public WarehouseRedisManageImp()
        {
            _redisService = new RedisService(1);
        }
        public async Task<string> GetBatno(DateTime date, int type)
        {
            string aa = DateTime.Now.ToString("yyyyMMdd");
            string key = string.Empty;
            switch (type)
            {
                case 0:
                    key = _batnoKey;
                    break;
                case 1:
                    key = _batno1Key;
                    break;
                case 2:
                    key = _batno2Key;
                    break;
                case 3:
                    key = _batno3Key;
                    break;
                case 4:
                    key = _batno4Key;
                    break;
                case 5:
                    key = _batno5Key;
                    break;
                case 6:
                    key = _batno6Key;
                    break;
                case 7:
                    key = _batno7Key;
                    break;
                case 8:
                    key = _batno8Key;
                    break;
                default:
                    break;
            }
            if (!_redisService.KeyExists(key))
            {
                return null;
            }
            else if (!_redisService.HashExists(key, aa))
            {
                return null;
            }
            else
            {
                var value = await _redisService.HashGeAsync<int>(key, aa);
                value++;
                await _redisService.HashSetAsync(key, aa, value);
                string b = value.ToString().PadLeft(4, '0');
                return $"{aa}{b}";
            }
        }

        public async Task SetBatno(DateTime date, int value, int type)
        {
            string aa = DateTime.Now.ToString("yyyyMMdd");
            string key = string.Empty;
            switch (type)
            {
                case 0:
                    key = _batnoKey;
                    break;
                case 1:
                    key = _batno1Key;
                    break;
                case 2:
                    key = _batno2Key;
                    break;
                case 3:
                    key = _batno3Key;
                    break;
                case 4:
                    key = _batno4Key;
                    break;
                case 5:
                    key = _batno5Key;
                    break;
                case 6:
                    key = _batno6Key;
                    break;
                case 7:
                    key = _batno7Key;
                    break;
                case 8:
                    key = _batno8Key;
                    break;
                default:
                    break;
            }
            await _redisService.HashSetAsync(key, aa, value);
        }

    }
}
