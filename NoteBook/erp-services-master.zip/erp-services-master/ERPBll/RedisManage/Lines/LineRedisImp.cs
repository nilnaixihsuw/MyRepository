﻿using BusTools.Redis;
using ERPBll.SignalRs;
using ERPBll.Vehicleinfomanage;
using ERPCore;
using ERPCore.DI;
using ERPCore.Helpers;
using ERPCore.ORM;
using ERPCore.Redis;
using ErpModel.CommonModel;
using ERPModel.CommonModel;
using ERPModel.SystemManage;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.RedisManage.Lines
{
    public class LineRedisImp : ILineRedisImp
    {
        /// <summary>
        /// redis线路信息缓存key
        /// </summary>
        private readonly string _lineKey = "line";
        private readonly string _lineVehicleKey = "line_vehicle";
        private readonly string _lineVehicleOilKey = "line_oil_vehicle";
        private readonly string _lineVehicleEltricKey = "line_eltric_vehicle";
        private readonly string _lineDieselVehicleKey = "line_diesel_vehicle";
        private readonly IRedisService _redisService;
        private readonly DispatchSys _option;
        private readonly System.Timers.Timer t;
        private readonly IVehicleRedisManageImp _vehicleRedisManageImp;
        private IVehicleInfoImp _iVehicleInfoImp;
        private readonly IServerHubImp _iServerHubImp;

        public LineRedisImp(
            IRedisService redisService,
            IServerHubImp iServerHubImp,
            IVehicleRedisManageImp vehicleRedisManageImp,
            IConfiguration options)
        {
            _redisService = new RedisService(1);
            _option = options.GetSection("Sugar").Get<SugarOption>().DispatchSys;
            _vehicleRedisManageImp = vehicleRedisManageImp;
            _iServerHubImp = iServerHubImp;
        }

        public async Task<List<Line>> GetAllAsync()
        {
            if (!_redisService.KeyExists(_lineKey))
            {
                await SetAllAsync();
            }
            return await _redisService.StringGetAsync<List<Line>>(_lineKey);
        }

        public async Task SetAllAsync()
        {
            var list = await GetLineByDispatchAsync();

            if (list != null && list.Count > 0)
            {
                var res = _redisService.StringSet(_lineKey, list);
                if (!res)
                {
                    throw new Exception("缓存线路失败!");
                }
            }
        }

        public async Task<List<DispatchVehicleInfo>> GetLineVehAsync()
        {
            if (!_redisService.KeyExists(_lineVehicleKey))
            {
                await SetLineVehAsync();
            }
            return await _redisService.StringGetAsync<List<DispatchVehicleInfo>>(_lineVehicleKey);
        }
        public async Task<List<DispatchVehicleInfo>> GetLineVehOilAsync()
        {
            if (!_redisService.KeyExists(_lineVehicleOilKey))
            {
                await SetLineVehOilAsync();
            }
            return await _redisService.StringGetAsync<List<DispatchVehicleInfo>>(_lineVehicleOilKey);
        }

        public async Task<List<DispatchVehicleInfo>> GetLineVehEltricAsync()
        {
            if (!_redisService.KeyExists(_lineVehicleEltricKey))
            {
                await SetLineVehEltricAsync();
            }
            return await _redisService.StringGetAsync<List<DispatchVehicleInfo>>(_lineVehicleEltricKey);
        }

        public async Task<List<DispatchVehicleInfo>> GetDieselLineVehAsync()
        {
            if (!_redisService.KeyExists(_lineDieselVehicleKey))
            {
                await SetDieselLineVehAsync();
            }
            return await _redisService.StringGetAsync<List<DispatchVehicleInfo>>(_lineDieselVehicleKey);
        }

        public async Task SetLineVehAsync()
        {
            var line_ids = (await GetAllAsync()).Select(x => ((int)x.id).ToString()).ToList();
            var list = await GetLineVehicleRelation(line_ids);
            var vehs = await _vehicleRedisManageImp.GetAllAsync();
            foreach (var item in list)
            {
                item.vehicle_id_erp = vehs.FirstOrDefault(x => x.c_lincense_plate_number == item.lp_num)?.i_id;
            }

            _iVehicleInfoImp = DIContainer.ServiceLocator.Instance.GetService<IVehicleInfoImp>();
            var vehicles = await _iVehicleInfoImp.List("60.191.59.11", null);
            vehicles.ForEach(r =>
            {
                r.line_id = list.Find(m => m.lp_num == r.c_lincense_plate_number)?.line_id;
            });
            await _iVehicleInfoImp.Update("60.191.59.11", vehicles);
            await _vehicleRedisManageImp.Clear();

            var res = _redisService.StringSet(_lineVehicleKey, list);
            if (!res)
            {
                throw new Exception("缓存线路车辆关系失败!");
            }
        }

        public async Task SetLineVehOilAsync()
        {
            var line_ids = (await GetAllAsync()).Select(x => ((int)x.id).ToString()).ToList();
            var list = await GetLineVehicleRelation(line_ids);
            var vehs = (await _vehicleRedisManageImp.GetAllAsync()).Where(x => x.ex_type == "柴油").ToList();
            foreach (var item in list)
            {
                item.vehicle_id_erp = vehs.FirstOrDefault(x => x.c_lincense_plate_number == item.lp_num)?.i_id;
            }

            var res = _redisService.StringSet(_lineVehicleOilKey, list);
            if (!res)
            {
                throw new Exception("缓存线路车辆关系失败!");
            }
        }

        public async Task SetLineVehEltricAsync()
        {
            var line_ids = (await GetAllAsync()).Select(x => ((int)x.id).ToString()).ToList();
            var list = await GetLineVehicleRelation(line_ids);
            var vehs = (await _vehicleRedisManageImp.GetAllAsync()).Where(x => x.ex_type == "纯电动").ToList();
            foreach (var item in list)
            {
                item.vehicle_id_erp = vehs.FirstOrDefault(x => x.c_lincense_plate_number == item.lp_num)?.i_id;
            }

            var res = _redisService.StringSet(_lineVehicleEltricKey, list);
            if (!res)
            {
                throw new Exception("缓存线路车辆关系失败!");
            }
        }

        public async Task SetDieselLineVehAsync()
        {
            var line_ids = (await GetAllAsync()).Select(x => ((int)x.id).ToString()).ToList();
            var list = await GetLineVehicleRelation(line_ids);
            var vehs = await _vehicleRedisManageImp.GetDieselAllAsync();
            foreach (var item in list)
            {
                item.vehicle_id_erp = vehs.FirstOrDefault(x => x.c_lincense_plate_number == item.lp_num)?.i_id;
            }

            var res = _redisService.StringSet(_lineDieselVehicleKey, list);
            if (!res)
            {
                throw new Exception("缓存线路车辆关系失败!");
            }
        }

        public async Task<List<Line>> GetLineByDispatchAsync()
        {
            return await Task.Run(() =>
            {
                try
                {
                    var rep = new List<Line>();
                    //获取线路信息
                    var data = "req=" + JsonConvert.SerializeObject(new DispatchRequest
                    {
                        head = new Head
                        {
                            cmd = "get_route_data",
                            user_id = _option.UserId,
                            server_id = _option.ServerId,
                            isCompress = false
                        },
                        content = new Content
                        {
                            //usable = 0
                        }
                    });
                    Console.WriteLine(DateTime.Now.ToString() + "缓存1请求线路信息:" + _option.Url);
                    GlobalFunc.LogInfo($"缓存1请求线路信息:{ _option.Url},参数{data}");
                    var repStr = HttpHelper.HttpPostFrom(_option.Url, data);
                    if (!string.IsNullOrEmpty(repStr))
                    {
                        var result = JsonConvert.DeserializeObject<DispatchResponse>(repStr);
                        if (result.head.result == "200")
                        {
                            rep = result.content.list;
                        }
                        else
                        {
                            //记录错误日志
                        }
                    }
                    return rep;
                }
                catch (Exception ex)
                {
                    GlobalFunc.LogError("获取线路错误", ex);
                    return null;
                }
            });
        }

        public async Task<List<DispatchVehicleInfo>> GetLineVehicleRelation(List<string> line_ids)
        {
            return await Task.Run(() =>
            {
                //线路车辆关系(调度系统)
                var result = new List<DispatchVehicleInfo>();
                var data = "req=" + JsonConvert.SerializeObject(new DispatchLineVehicleRelation
                {
                    head = new Head
                    {
                        cmd = "get_vehicles_by_lineid",
                        user_id = _option.UserId,
                        server_id = _option.ServerId,
                        isCompress = false
                    },
                    content = new DispatchLineVehicleQuery
                    {
                        line_ids = line_ids,
                        lp_nums = new List<string>()
                    }
                });
                var repStr = HttpHelper.HttpPostFrom(_option.Url, data);
                if (!string.IsNullOrEmpty(repStr))
                {
                    var r = JsonConvert.DeserializeObject<DispatchLineVehicleResponse>(repStr);
                    if (r.head.result == "200")
                    {
                        result = r.content.list;
                    }
                    else
                    {
                        throw new Exception(r.head.describle);
                    }
                }
                return result;
            });
        }

        /// <summary>
        /// 清除缓存
        /// </summary>
        public void ClearKey()
        {
            _redisService.KeyDelete(_lineKey);
            _redisService.KeyDelete(_lineVehicleKey);

            _iServerHubImp.SendMessageToAllAsync(MessageType.UpdateRedis, 6);
        }
    }
}
