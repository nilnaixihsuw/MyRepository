﻿using ErpModel.CommonModel;
using ERPModel.SystemManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.RedisManage.Lines
{
    /// <summary>
    /// 线路缓存
    /// </summary>
    public interface ILineRedisImp
    {
        /// <summary>
        /// 获取全部线路
        /// </summary>
        /// <returns></returns>
        Task<List<Line>> GetAllAsync();

        /// <summary>
        /// 更新全部线路
        /// </summary>
        /// <returns></returns>
        Task SetAllAsync();

        /// <summary>
        /// 获取线路车辆关系
        /// </summary>
        /// <returns></returns>
        Task<List<DispatchVehicleInfo>> GetLineVehAsync();
        Task<List<DispatchVehicleInfo>> GetLineVehOilAsync();
        Task<List<DispatchVehicleInfo>> GetLineVehEltricAsync();

        Task<List<DispatchVehicleInfo>> GetDieselLineVehAsync();

        void ClearKey();

    }
}
