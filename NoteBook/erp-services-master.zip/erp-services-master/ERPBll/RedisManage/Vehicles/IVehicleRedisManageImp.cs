﻿using ERPModel.SystemManage;
using ERPModel.Vehicleinfomanage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.RedisManage
{
    public interface IVehicleRedisManageImp
    {
        /// <summary>
        /// 获取所有车辆id
        /// </summary>
        /// <returns></returns>
        Task<List<string>> GetAllIdAsync();

        /// <summary>
        /// 获取所有车辆信息
        /// </summary>
        /// <returns></returns>
        Task<List<ErpVehicleInfo>> GetAllAsync();

        Task<List<ErpVehicleInfo>> GetDieselAllAsync();


        /// <summary>
        /// 获取所有车辆信息
        /// </summary>
        /// <returns></returns>
        Task<List<VehicleInfoNew>> GetAll1Async();

        /// <summary>
        /// 获取所有车辆型号信息
        /// </summary>
        /// <returns></returns>
        Task<List<MaintVehicleKind>> GetAllKindAsync();

        /// <summary>
        /// 清除redis对应数据，以便后续刷新数据
        /// </summary>
        /// <returns></returns>
        Task<bool> Clear();

        Task<bool> ClearKind();

        Task SetAll(string server_id = "60.191.59.11");

        Task SetAllKind(string server_id = "60.191.59.11");

        /// <summary>
        /// 编辑单辆车
        /// </summary>
        /// <param name="i_id"></param>
        /// <param name="server_id"></param>
        /// <returns></returns>
        Task SetOneAsync(decimal i_id, string server_id = "60.191.59.11");

        /// <summary>
        /// 从调度系统获取全部车载信息
        ///</summary>
        /// <returns></returns>
        Task<List<VehicleMachine>> GetAllVehicleMachineAsync();

        /// <summary>
        /// 从缓存获取全部车载信息
        /// </summary>
        /// <returns></returns>
        Task<List<VehicleMachine>> GetVehicleMachineAsync();
    }
}
