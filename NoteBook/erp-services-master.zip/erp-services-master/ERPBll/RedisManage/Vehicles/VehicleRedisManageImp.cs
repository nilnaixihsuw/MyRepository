﻿using BusTools.Redis;
using ERPBll.SignalRs;
using ERPCore.Helpers;
using ERPCore.ORM;
using ERPCore.Redis;
using ERPDal;
using ErpModel.CommonModel;
using ERPModel.CommonModel;
using ERPModel.DataBase;
using ERPModel.SystemManage;
using ERPModel.Vehicleinfomanage;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.RedisManage
{
    /// <summary>
    /// 车辆信息缓存管理
    /// </summary>
    public class VehicleRedisManageImp : IVehicleRedisManageImp
    {
        /// <summary>
        /// redis车辆信息缓存key
        /// </summary>
        private readonly string _vehicleKey = "vehicle";
        private readonly string _vehicle1Key = "vehicle1";
        private readonly string _vehicleKindKey = "vehicle_kind";
        private readonly string _vehicleMachine = "vehicle_machine";
        private readonly IRedisService _redisService;
        private readonly DispatchSys _option;
        private readonly IServerHubImp _iServerHubImp;

        public VehicleRedisManageImp(
            IServerHubImp iServerHubImp,
            IConfiguration options)
        {
            _redisService = new RedisService(1);
            _iServerHubImp = iServerHubImp;
            _option = options.GetSection("Sugar").Get<SugarOption>().DispatchSys;
        }

        public async Task<List<string>> GetAllIdAsync()
        {
            return await _redisService.HashKeysAsync<string>(_vehicleKey);
        }

        public async Task<List<ErpVehicleInfo>> GetAllAsync()
        {
            if (!_redisService.KeyExists(_vehicleKey))
            {
                await SetAll();
            }
            return await _redisService.HashValuesAsync<ErpVehicleInfo>(_vehicleKey);
        }

        public async Task<List<ErpVehicleInfo>> GetDieselAllAsync()
        {
            if (!_redisService.KeyExists("diesel_vehicle"))
            {
                await SetDieselAll();
            }
            return await _redisService.HashValuesAsync<ErpVehicleInfo>("diesel_vehicle");
        }


        public async Task<List<VehicleInfoNew>> GetAll1Async()
        {
            if (!_redisService.KeyExists(_vehicle1Key))
            {
                var list1 = await SqlSugarHelper.DBClient("60.191.59.11")
                              .Queryable<VehicleInfoNew>()
                              .Mapper(r => r.vehicle_kind_info, r => r.cid)
                              .Mapper(r => r.group_info, r => r.group)
                              .ToListAsync();
                list1.ForEach(async item =>
                {
                    var res = await _redisService.HashSetAsync(_vehicle1Key, item.id.ToString(), item);
                    if (!res)
                    {
                        //记录失败日志
                    }
                });
            }
            return await _redisService.HashValuesAsync<VehicleInfoNew>(_vehicle1Key);
        }

        public async Task<List<MaintVehicleKind>> GetAllKindAsync()
        {
            if (!_redisService.KeyExists(_vehicleKindKey))
            {
                await SetAllKind();
            }
            return await _redisService.HashValuesAsync<MaintVehicleKind>(_vehicleKindKey);
        }

        public async Task SetAll(string server_id = "60.191.59.11")
        {
            using (var db = SqlSugarHelper.DBClient(server_id))
            {
                var list = await db.Queryable<ErpVehicleInfo>()
                                   .Mapper(m =>
                                   {
                                       var cid = m.c_id;
                                       m.ex_type = db.Queryable<MaintVehicleKind, SysCommonDictDetail>((a, b) => new JoinQueryInfos(JoinType.Left, a.c_fuel == b.i_id.ToString())).Where((a, b) => a.i_id == cid).Select((a, b) => b.c_name).Single();
                                   })
                                   .ToListAsync();
                list.ForEach(item =>
                {
                    var res = _redisService.HashSetAsync<ErpVehicleInfo>(_vehicleKey, item.i_id.ToString(), item).Result;
                    if (!res)
                    {
                        //记录失败日志
                    }
                });
            }
        }

        public async Task SetDieselAll(string server_id = "60.191.59.11")
        {
            var list = await SqlSugarHelper.DBClient(server_id)
                                           .Queryable<ErpVehicleInfo, MaintVehicleKind>((a, b) => new JoinQueryInfos(JoinType.Inner, a.c_id == b.i_id))
                                           .Where((a, b) => b.c_fuel == "5595")  //柴油
                                           .ToListAsync();
            list.ForEach(async item =>
            {
                var res = await _redisService.HashSetAsync("diesel_vehicle", item.i_id.ToString(), item);
                if (!res)
                {
                    //记录失败日志
                }
            });
        }

        public async Task SetAllKind(string server_id = "60.191.59.11")
        {
            var list = await SqlSugarHelper.DBClient(server_id)
                        .Queryable<MaintVehicleKind>()
                        .ToListAsync();

            list.ForEach(async item =>
            {
                var res = await _redisService.HashSetAsync(_vehicleKindKey, item.i_id.ToString(), item);
                if (!res)
                {
                    //记录失败日志
                }
            });
        }

        /// <summary>
        /// 删除车辆信息缓存key，刷新缓存
        /// </summary>
        /// <returns></returns>
        public async Task<bool> Clear()
        {
            var res = await Task.Run(() =>
            {
                var r = _redisService.KeyDelete(_vehicleKey);
                r = _redisService.KeyDelete(_vehicleMachine);
                r = _redisService.KeyDelete(_vehicle1Key);
                r = _redisService.KeyDelete("vehicle_tree0");
                return r;
            });

            if (res)
            {
                await _iServerHubImp.SendMessageToAllAsync(MessageType.UpdateRedis, 7);
            }

            return res;
        }

        public async Task SetOneAsync(decimal i_id, string server_id = "60.191.59.11")
        {
            var vehicle = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpVehicleInfo>()
                                .Mapper(m =>
                                {
                                    var cid = m.c_id;
                                    m.ex_type = SqlSugarHelper.DBClient(server_id).Queryable<MaintVehicleKind, SysCommonDictDetail>((a, b) => new JoinQueryInfos(JoinType.Left, a.c_fuel == b.i_id.ToString())).Where((a, b) => a.i_id == cid).Select((a, b) => b.c_name).Single();
                                })
                                .FirstAsync(r => r.i_id == i_id);
            if (_redisService.HashExists(_vehicleKey, i_id.ToString()))
            {
                await _redisService.HashDeleteAsync(_vehicleKey, i_id.ToString());
            }
            await _redisService.HashSetAsync(_vehicleKey, i_id.ToString(), vehicle);

            var vehicle1 = await SqlSugarHelper.DBClient(server_id)
                             .Queryable<VehicleInfoNew>()
                             .Mapper(r => r.vehicle_kind_info, r => r.cid)
                             .Mapper(r => r.group_info, r => r.group)
                             .FirstAsync(r => r.id == i_id);
            if (_redisService.HashExists(_vehicle1Key, i_id.ToString()))
            {
                await _redisService.HashDeleteAsync(_vehicle1Key, i_id.ToString());
            }
            await _redisService.HashSetAsync(_vehicle1Key, i_id.ToString(), vehicle1);

            _redisService.KeyDelete(_vehicleMachine);
            _redisService.KeyDelete("vehicle_tree0");
        }

        /// <summary>
        /// 删除车型信息缓存key，刷新缓存
        /// </summary>
        /// <returns></returns>
        public async Task<bool> ClearKind()
        {
            return await Task.Run(() =>
            {
                var r = _redisService.KeyDelete(_vehicleKindKey);
                return r;
            });
        }

        public async Task<List<VehicleMachine>> GetVehicleMachineAsync()
        {
            //_redisService.KeyDelete(_stationKey);
            if (!_redisService.KeyExists(_vehicleMachine))
            {
                var list = await GetAllVehicleMachineAsync();
                list = list.Where(r => r.id.StartsWith("10")).ToList();
                var res = _redisService.StringSet(_vehicleMachine, list, TimeSpan.FromMinutes(RedisConfigure.TEMPTABLE.CatchTimeMinite));
                if (!res)
                {
                    throw new Exception("缓存车载机失败!");
                }
                return list;
            }
            else
            {
                return await _redisService.StringGetAsync<List<VehicleMachine>>(_vehicleMachine);
            }
        }

        public async Task<List<VehicleMachine>> GetAllVehicleMachineAsync()
        {
            return await Task.Run(() =>
            {
                var rep = new List<VehicleMachine>();
                //获取车载机信息
                var data = "req=" + JsonConvert.SerializeObject(new DispatchRequest
                {
                    head = new Head
                    {
                        cmd = "get_user_vehicle",
                        user_id = _option.UserId,
                        server_id = _option.ServerId,
                        isCompress = false
                    },
                    content = new Content
                    {
                        //usable = 0
                    }
                });
                var repStr = HttpHelper.HttpPostFrom(_option.Url, data);
                if (!string.IsNullOrEmpty(repStr))
                {
                    var result = JsonConvert.DeserializeObject<DispatchVehicleMachine>(repStr);
                    if (result.content.result == "200")
                    {
                        rep = result.content.items;
                    }
                    else
                    {
                        //记录错误日志
                    }
                }
                return rep;
            });
        }
    }
}
