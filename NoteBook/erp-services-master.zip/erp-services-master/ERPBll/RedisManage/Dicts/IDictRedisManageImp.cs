﻿using ERPModel.DataBase;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.RedisManage.Dicts
{
    public interface IDictRedisManageImp
    {
        /// <summary>
        /// 获取全部明细字典项
        /// </summary>
        /// <returns></returns>
        Task<List<SysCommonDictDetail>> GetAllAsync();
        /// <summary>
        /// 根据字典key获取对应明细项
        /// </summary>
        /// <returns></returns>
        Task<List<SysCommonDictDetail>> GetByKeyAsync(string key);

        Task<bool> Clear();

        Task SetAll(string server_id = "60.191.59.11");

        /// <summary>
        /// 获取完整字典及其子项
        /// </summary>
        /// <returns></returns>
        Task<List<SysCommonDict>> GetDict(List<string> request);
    }
}
