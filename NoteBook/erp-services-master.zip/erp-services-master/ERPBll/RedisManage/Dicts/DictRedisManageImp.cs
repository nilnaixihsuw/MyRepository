﻿using BusTools.Redis;
using ERPDal;
using ERPModel.DataBase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.RedisManage.Dicts
{
    /// <summary>
    /// 字典信息缓存管理
    /// </summary>
    public class DictRedisManageImp : IDictRedisManageImp
    {
        /// <summary>
        /// redis字典信息缓存key
        /// </summary>
        private readonly string _dictKey = "dict";
        private readonly IRedisService _redisService;

        public DictRedisManageImp()
        {
            _redisService = new RedisService(1);
        }

        public async Task<List<SysCommonDictDetail>> GetAllAsync()
        {
            if (!_redisService.KeyExists(_dictKey))
            {
                await SetAll();
            }
            var list = await _redisService.HashValuesAsync<SysCommonDict>(_dictKey);
            var result = new List<SysCommonDictDetail>();
            foreach (var item in list)
            {
                result.AddRange(item.dic_details);
            }
            return result;
        }

        public async Task<List<SysCommonDictDetail>> GetByKeyAsync(string key)
        {
            if (!_redisService.KeyExists(_dictKey))
            {
                await SetAll();
            }
            var list = await _redisService.HashValuesAsync<SysCommonDict>(_dictKey);
            return list.Where(r => r.c_key == key).FirstOrDefault()?.dic_details;
        }

        public async Task SetAll(string server_id = "60.191.59.11")
        {
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<SysCommonDict>()
                                .ToListAsync();
            var list1 = await SqlSugarHelper.DBClient(server_id)
                        .Queryable<SysCommonDictDetail>().ToListAsync();

            list.ForEach(async item =>
            {
                item.dic_details = list1.Where(r => r.i_main_id == item.i_id).ToList();
                item.dic_detls = item.dic_details.Select(it => new CommonDicSlim
                {
                    code = it.c_code,
                    c_code = it.i_id,
                    c_name = it.c_name,
                    i_seq = it.i_seq,
                    i_is_default = it.i_is_default
                }).ToList();
                var res = await _redisService.HashSetAsync<SysCommonDict>(_dictKey, item.i_id.ToString(), item);
                if (!res)
                {
                    //记录失败日志
                }
            });
        }

        public async Task<bool> Clear()
        {
            return await Task.Run(() => { 
                var r = _redisService.KeyDelete(_dictKey);
                return r;
            });
        }

        public async Task<List<SysCommonDict>> GetDict(List<string> request)
        {
            if (!_redisService.KeyExists(_dictKey))
            {
                await SetAll();
            }
            var list = await _redisService.HashValuesAsync<SysCommonDict>(_dictKey);
            return list.Where(r => request.Contains(r.c_key) || request.Contains(r.c_name)).ToList();
        }
    }
}
