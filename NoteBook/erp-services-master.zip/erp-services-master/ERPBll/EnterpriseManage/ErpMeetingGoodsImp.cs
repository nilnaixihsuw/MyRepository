﻿using ERPCore.ORM;
using ERPDal.EnterpriseManage;
using ERPModel.EnterpriseManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;

namespace ERPBll.EnterpriseManage
{
    public class ErpMeetingGoodsImp : BusinessRespository<ErpMeetingGoods, IErpMeetingGoodsDataImp>, IErpMeetingGoodsImp
    {
        public ErpMeetingGoodsImp(IErpMeetingGoodsDataImp dataImp): base(dataImp)
        {

        }
    }
}