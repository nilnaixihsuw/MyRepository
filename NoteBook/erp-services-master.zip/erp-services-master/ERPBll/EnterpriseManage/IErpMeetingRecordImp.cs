﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPModel.ApiModel.EnterpriseManage;
using ERPModel.EnterpriseManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.EnterpriseManage
{
    public interface IErpMeetingRecordImp : IBusinessRepository<ErpMeetingRecord>
    {
        Task<bool> BookMeetingRoom(string server_id, ErpMeetingRecord context, ClientInformation client);
        Task<MyMeetingRoomBook> ListMyBookRecords(string server_id, ClientInformation client);
        Task<bool> CancelBook(string server_id, List<decimal> request);
        Task<List<ErpMeetingRecord>> ListReserveHistory(ErpMeetingHistoryRequest request, string v, ClientInformation client);
        Task<Tuple<List<ErpMeetingRecord>, int>> ListReserveHistoryPage(ErpMeetingHistoryRequest request, string v, ClientInformation client);
        Task<ErpMeetingRecord> Detail(string server_id, decimal id, ClientInformation client);
    }
}