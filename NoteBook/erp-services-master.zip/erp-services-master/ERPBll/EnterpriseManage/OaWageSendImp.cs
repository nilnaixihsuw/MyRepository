﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPDal.EnterpriseManage;
using ERPModel.EnterpriseManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using System.Linq.Expressions;
using ERPDal;
using ERPModel.EnterpriseManage.OaWage;
using ERPModel.ApiModel.EnterpriseManage;

namespace ERPBll.EnterpriseManage
{
    public class OaWageSendImp : BusinessRespository<OaWageSend, IOaWageSendDataImp>, IOaWageSendImp
    {
        public OaWageSendImp(IOaWageSendDataImp dataImp): base(dataImp)
        {

        }

        public async Task<bool> AddOaWageSend(string server_id, OaWageSend context, ClientInformation client)
        {
            if (context.id > 0)
            {
                var old = await _dataImp.Get(server_id, context.id);
                context.created_id = old.created_id;
                context.created_date = old.created_date;
                return await _dataImp.Update(server_id, context);
            }
            else
            {
                context.created_date = DateTime.Now;
                context.created_id = client.i_id;
                return await _dataImp.Insert(server_id, context);
            }
        }

        public async Task<Tuple<List<OaWageSend>,int>> QueryOaWageSendPageList(string server_id, OawageSendRequest request, string v)
        {
            RefAsync<int> totalCount = 0;

            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<OaWageSend, OaWageMain>(
                                    (x, y) => new JoinQueryInfos (
                                        JoinType.Left, x.main_id == y.id
                                ))
                                .Where(request.ToExp1())
                                .Mapper(x => x.main_info, x => x.main_id)
                                .ToPageListAsync(request.page_index, request.page_size, totalCount);

            return new Tuple<List<OaWageSend>, int>(list, totalCount);

            //var exp = await GetExp(request);
            //return await ExtensionList(server_id, request.ToExp(exp), v, request.page_size, request.page_index, request.orderby);
        }

        public async Task<List<OaWageSend>> QueryOaWageSendList(string server_id, OawageSendRequest request, string v)
        {
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<OaWageSend, OaWageMain>(
                                    (x, y) => new JoinQueryInfos(
                                        JoinType.Left, x.main_id == y.id
                                ))
                                .Where(request.ToExp1())
                                .Mapper(x => x.main_info, x => x.main_id)
                                .ToListAsync();

            return list;
            //var exp = await GetExp(request);
            //return await ExtensionList(server_id, request.ToExp(exp), v, request.orderby);
        }

        public async Task<bool> BatchDelete(string server_id, List<decimal> context)
        {
            var list = await _dataImp.List(server_id, it => SqlFunc.ContainsArray(context, it.id));
            return await _dataImp.Deletetable(server_id, list);
        }

        private async Task<List<Expression<Func<OaWageSend, bool>>>> GetExp(BaseRequest<OaWageSend> request)
        {
            var r = new List<Expression<Func<OaWageSend, bool>>>();
            
            return r;
        }
    }
}