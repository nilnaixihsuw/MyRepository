﻿using ERPCore.ORM;
using ERPDal.EnterpriseManage;
using ERPModel.EnterpriseManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using ERPModel.CommonModel;
using ERPCore.Entity;

namespace ERPBll.EnterpriseManage
{
    public class ErpElectricGroupImp : BusinessRespository<ErpElectricGroup, IErpElectricGroupDataImp>, IErpElectricGroupImp
    {
        public ErpElectricGroupImp(IErpElectricGroupDataImp dataImp) : base(dataImp)
        {

        }

        public async Task<bool> AddElectricGroup(string server_id, ErpElectricGroup context, ClientInformation client)
        {
            if (context.id > 0)
            {
                //编辑
                context.update_date = DateTime.Now;
                context.update_id = client.i_id;
                var old = await Get(server_id, context.id);
                context.created_date = old.created_date;
                context.created_id = old.created_id;
                return await _dataImp.Update(server_id, context);
            }
            else
            {
                //新增
                context.created_date = DateTime.Now;
                context.created_id = client.i_id;
                return await _dataImp.Insert(server_id, context);

            }
        }

        public async Task<bool> BatchDelete(string server_id, List<decimal> context)
        {
            var list = await _dataImp.List(server_id, it => SqlFunc.ContainsArray(context, it.id));
            return await _dataImp.Deletetable(server_id, list);
        }

        public async Task<List<ErpElectricGroup>> GetElectricTree(string server_id)
        {
            return await _dataImp.GetElectricTree(server_id);
        }
    }
}