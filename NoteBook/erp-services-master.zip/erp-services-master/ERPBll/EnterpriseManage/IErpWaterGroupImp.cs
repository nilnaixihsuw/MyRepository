﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPModel.EnterpriseManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.EnterpriseManage
{
    public interface IErpWaterGroupImp : IBusinessRepository<ErpWaterGroup>
    {
        Task<List<ErpWaterGroup>> GetWaterTree(string server_id);
        Task<bool> AddWaterGroup(string server_id, ErpWaterGroup context, ClientInformation client);
        Task<bool> BatchDelete(string server_id, List<decimal> context);
    }
}