﻿using ERPCore.ORM;
using ERPDal.EnterpriseManage;
using ERPModel.EnterpriseManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using ERPModel.ApiModel.EnterpriseManage;
using ERPDal;
using ERPModel.UserManage;
using AutoMapper;
using ERPBll.RedisManage.Dicts;

namespace ERPBll.EnterpriseManage
{
    public class ErpBusMainImp : BusinessRespository<ErpBusMain, IErpBusMainDataImp>, IErpBusMainImp
    {
        private readonly IMapper _imapper;
        private readonly IDictRedisManageImp _iDictRedisManageImp;
        public ErpBusMainImp(IMapper imapper, IDictRedisManageImp iDictRedisManageImp,
            IErpBusMainDataImp dataImp): base(dataImp)
        {
            _imapper = imapper;
            _iDictRedisManageImp = iDictRedisManageImp;
        }

        public async Task<List<BusMainDto>> GetRecord(BusMainRequest request)
        {
            var list = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpBusMain>()
                .Where(request.ToExp())
                .OrderBy(r => r.buy_date, OrderByType.Desc)
                //.Mapper(r => r.files, r => r.files.First().main_id)
                .Includes(r => r.files)
                .ToListAsync();
            var res = _imapper.Map<List<ErpBusMain>, List<BusMainDto>>(list);
            var persons = await SqlSugarHelper.DBClient(request.server_id).Queryable<SysPerson>().ToListAsync();
            var dic = await _iDictRedisManageImp.GetAllAsync();
            var use_records = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpBusRecord>().ToListAsync();
            //var files = await _iErpBusFileImp.List(request.server_id, null);
            res.ForEach(r =>
            {
                r.duty_name = persons.Find(m => m.i_id == r.duty_id)?.c_name;
                r.audit_person_name = persons.Find(m => m.i_id == r.audit_person)?.c_name;
                r.oil_kind_name = dic.Find(m => m.i_id == r.oil_kind)?.c_name;
                //r.files = _imapper.Map<List<ErpBusFile>, List<BusFile>>(list.FirstOrDefault(m => m.id == r.id)?.files);
                //r.files = files.Where(m => m.main_id == r.id).Select(m => new BusFile
                //{
                //    name = m.name,
                //    file_url = m.file_url
                //}).ToList();

                if (r.state == 0)
                {
                    r.state_name = "未使用";
                    r.use_state_name = "未使用";
                }
                if (r.state == 1)
                {
                    var use_record = use_records.Find(m => m.bus_id == r.id && m.state == 1);
                    var user_name = persons.Find(m => m.i_id == use_record?.borrow_id)?.c_name;
                    r.record = use_record;
                    r.user_name = user_name;
                    r.borrow_time = use_record != null ? use_record.borrow_time : null;
                    r.expect_back_time = use_record != null ? use_record.expect_back_time : null;
                    if (use_record != null && use_record.back_id.HasValue && use_record.back_id != 0)
                    {
                        var back_name = persons.FirstOrDefault(m => m.i_id == use_record.back_id)?.c_name;
                        r.back_name = back_name;
                        r.back_time = use_record.back_time;
                        r.back_mile = use_record.back_mile;
                    }

                    if (r.is_audit == 0)
                    {
                        r.state_name = user_name + "使用中";
                        r.use_state_name = user_name + "借车中";
                    }
                    else
                    {
                        switch (use_record.state_child)
                        {
                            case 1:
                                r.state_name = "借车审批中";
                                r.use_state_name = user_name + "借车审批中";
                                break;
                            case 2:
                                r.state_name = "借车通过";
                                r.use_state_name = user_name + "借车中";
                                break;
                            case 4:
                                r.state_name = "还车审批中";
                                r.use_state_name = user_name + "还车审批中";
                                break;
                            case 6:
                                r.state_name = "还车拒绝";
                                r.use_state_name = user_name + "还车拒绝";
                                break;
                        }
                    }
                }
            });

            if (!string.IsNullOrEmpty(request.duty_name))
            {
                res = res.Where(r => r.duty_name != null && r.duty_name.Contains(request.duty_name)).ToList();
            }
            //res = res.OrderByDescending(r => r.buy_date).ToList();
            return res;
        }
    }
}