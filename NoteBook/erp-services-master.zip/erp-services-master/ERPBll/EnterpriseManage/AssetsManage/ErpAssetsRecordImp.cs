﻿using ERPDal;
using ERPDal.Repository;
using ERPModel.ApiModel.MaterialManage.BaseinfoManage;
using ERPModel.EnterpriseManage.AssetsManage;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.EnterpriseManage.AssetsManage
{
    public class ErpAssetsRecordImp : BaseBusiness<ErpAssetsRecord>, IErpAssetsRecordImp
    {
        public async Task<List<AssetsRecordDto>> GetHistory(AssetsRecordRequest request)
        {
            var records = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpAssetsRecord>()
                .Where(r => r.assets_id == request.assets_id)
                .Mapper(r => r.user_info, r => r.user_id)
                .Mapper(r => r.dept_info, r => r.dept_id)
                .OrderBy(r => r.id)
                .ToListAsync();
            var list = new List<AssetsRecordDto>();
            foreach (var item in records)
            {
                var temp = new AssetsRecordDto();
                temp.user_id = item.user_id;
                temp.user_name = item.user_info?.c_name;
                temp.dept_id = item.dept_id;
                temp.dept_name = item.dept_info?.c_name;
                temp.borrow_back_date = item.borrow_date;
                temp.type = 1;
                list.Add(temp);
                if (item.back_date != null)
                {
                    var temp1 = Tools.DeepCopy(temp);
                    temp1.borrow_back_date = item.back_date;
                    temp1.type = 2;
                    list.Add(temp1);
                }
            }

            if (request.date_start != null && request.date_end != null)
            {
                list = list.Where(r => r.borrow_back_date >= request.date_start && r.borrow_back_date <= request.date_end).ToList();
            }
            if (request.type > 0)
            {
                list = list.Where(r => r.type == request.type).ToList();
            }
            return list;
        }
    }
}
