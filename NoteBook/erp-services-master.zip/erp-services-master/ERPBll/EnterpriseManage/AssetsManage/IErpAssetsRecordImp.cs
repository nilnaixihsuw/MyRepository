﻿using ERPDal.Repository;
using ERPModel.ApiModel.MaterialManage.BaseinfoManage;
using ERPModel.EnterpriseManage.AssetsManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.EnterpriseManage.AssetsManage
{
    public interface IErpAssetsRecordImp : IBaseBusiness<ErpAssetsRecord>
    {
        public Task<List<AssetsRecordDto>> GetHistory(AssetsRecordRequest request);
    }
}
