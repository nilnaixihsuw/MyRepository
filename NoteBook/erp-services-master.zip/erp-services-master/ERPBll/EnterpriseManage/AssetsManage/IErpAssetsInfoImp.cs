﻿using ERPDal.Repository;
using ERPModel.ApiModel.MaterialManage.BaseinfoManage;
using ERPModel.EnterpriseManage.AssetsManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.EnterpriseManage.AssetsManage
{
    public interface IErpAssetsInfoImp : IBaseBusiness<ErpAssetsInfo>
    {
        Task<Tuple<int, List<AssetsInfoDto>>> GetData(AssetsInfoRequest request);
    }
}
