﻿using ERPDal;
using ERPDal.Repository;
using ERPModel.EnterpriseManage.AssetsManage;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.EnterpriseManage.AssetsManage
{
    public class ErpAssetsGroupImp : BaseBusiness<ErpAssetsGroup>, IErpAssetsGroupImp
    {
        public async Task<List<ErpAssetsGroup>> GetGroups(string name, string server_id)
        {
            var list = await SqlSugarHelper.DBClient(server_id).Queryable<ErpAssetsGroup>()
                 .WhereIF(!string.IsNullOrEmpty(name), r => r.name.Contains(name))
                 .Mapper(r => r.details, r => r.details.First().group_id)
                 .ToListAsync();
            return list;
        }
    }
}
