﻿using ERPDal.Repository;
using ERPModel.EnterpriseManage.AssetsManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.EnterpriseManage.AssetsManage
{
    public interface IErpAssetsGroupImp : IBaseBusiness<ErpAssetsGroup>
    {
        Task<List<ErpAssetsGroup>> GetGroups(string name, string server_id);
    }
}
