﻿using AutoMapper;
using ERPDal;
using ERPDal.Repository;
using ERPModel.ApiModel.MaterialManage.BaseinfoManage;
using ERPModel.DataBase;
using ERPModel.EnterpriseManage.AssetsManage;
using ERPModel.UserManage;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.EnterpriseManage.AssetsManage
{
    public class ErpAssetsInfoImp : BaseBusiness<ErpAssetsInfo>, IErpAssetsInfoImp
    {
        private readonly IMapper _imapper;
        public ErpAssetsInfoImp(IMapper imapper)
        {
            _imapper = imapper;
        }

        public async Task<Tuple<int, List<AssetsInfoDto>>> GetData(AssetsInfoRequest request)
        {
            RefAsync<int> totalNumber = 0;
            var records = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpAssetsInfo>()
                .Where(request.ToExp())
                .Mapper(r => r.user_info, r => r.user_id)
                .Mapper(r => r.dept_info, r => r.dept_id)
                .Mapper(r => r.use_history, r => r.use_history.First().assets_id)
                .ToPageListAsync(request.page_index, request.page_size, totalNumber);

            var list = new List<AssetsInfoDto>();
            var groups = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpAssetsGroup>().ToListAsync();
            var dic = await SqlSugarHelper.DBClient(request.server_id).Queryable<SysCommonDictDetail>().ToListAsync();
            //var history = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpAssetsRecord>().ToListAsync();
            var simple_groups = GetGroupName(groups);
            foreach (var item in records)
            {
                var temp = _imapper.Map<ErpAssetsInfo, AssetsInfoDto>(item);
                temp.user_name = item.user_info?.c_name;
                temp.borrow_date = item.use_history.OrderBy(r => r.created_date).LastOrDefault()?.borrow_date;
                temp.dept_name = item.dept_info?.c_name;
                temp.group_name = simple_groups.Find(r => r.group_id == temp.group_id)?.group_name;
                temp.unit_name = dic.Find(r => r.i_id == temp.unit)?.c_name;
                switch (temp.state)
                {
                    case 0:
                        temp.state_name = "闲置中";
                        break;
                    case 1:
                        temp.state_name = "使用中";
                        break;
                    case 2:
                        temp.state_name = "已报废";
                        break;
                }
                switch (temp.source)
                {
                    case 1:
                        temp.source_name = "采购";
                        break;
                    case 2:
                        temp.source_name = "赠送";
                        break;
                    case 3:
                        temp.source_name = "调入";
                        break;
                }
                list.Add(temp);
            }
            return new Tuple<int, List<AssetsInfoDto>>(totalNumber, list);
        }

        private List<SimpleGroup> GetGroupName(List<ErpAssetsGroup> groups)
        {
            var list = new List<SimpleGroup>();
            foreach (var group in groups)
            {
                if (group.parents == 0)
                {
                    var temp = new SimpleGroup();
                    temp.group_id = group.id;
                    temp.group_name = group.name;
                    list.Add(temp);
                }
                else
                {
                    var parents = Loop(groups, new List<ErpAssetsGroup>(), group);
                    parents.Reverse();
                    var temp = new SimpleGroup();
                    temp.group_id = group.id;
                    temp.group_name = string.Join("-", parents.Select(r => r.name).ToList());
                    list.Add(temp);
                }
            }
            return list;
        }

        private List<ErpAssetsGroup> Loop(List<ErpAssetsGroup> origin, List<ErpAssetsGroup> result, ErpAssetsGroup request)
        {
            if (request == null)
            {
                return result;
            }

            result.Add(request);
            if (request.parents == 0)
            {
                return result;
            }
            else
            {
                request = origin.Find(r => r.id == request.parents);
                return Loop(origin, result, request);
            }
        }
    }
}
