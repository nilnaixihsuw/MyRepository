﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPModel.ApiModel.EnterpriseManage;
using ERPModel.EnterpriseManage;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.EnterpriseManage
{
    public interface IErpElectricRecordImp : IBusinessRepository<ErpElectricRecord>
    {
        Task<bool> AddElectric(string server_id, ErpElectricRecord context, ClientInformation client);
        Task<bool> Import(string server_id, IFormFile file, int type, ClientInformation client);
        Task<Tuple<List<ErpElectricRecord>,int>> ElectricPageList(string server_id, ElectricRecordManage.QueryRequest request, string where);
        Task<List<ErpElectricRecord>> ElectricList(string server_id, ElectricRecordManage.QueryRequest request, string v);
        Task<bool> BatchDelete(string server_id, List<decimal> context);
    }
}