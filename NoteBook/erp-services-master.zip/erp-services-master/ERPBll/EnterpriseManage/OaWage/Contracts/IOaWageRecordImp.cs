﻿using ERPCore.Entity;
using ERPModel.EnterpriseManage.OaWage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.EnterpriseManage.OaWage.Contracts
{
    public interface IOaWageRecordImp
    {
        /// <summary>
        /// 导入工资条
        /// </summary>
        Task<(bool, List<string>)> Import(ImportOaWageRecord input, decimal? user_id);

        /// <summary>
        /// 获取最近一次上传的工资条
        /// </summary>
        Task<(List<OaWageRecordDto>, int, decimal?, DateTime?)> GetRecentAsync(OaWageRecordQuery query);

        /// <summary>
        /// 删除
        /// </summary>
        Task<bool> DeleteAsync(string server_id, List<decimal> ids);

        /// <summary>
        /// 获取发放记录
        /// </summary>
        Task<(List<WageCountDto>, int, decimal?)> GetSendRecordAsync(OaWageMainQuery query);

        /// <summary>
        /// 查看发放记录详情
        /// </summary>
        Task<(OaWageMainDto, int, decimal?, DateTime?)> GetSendDetailAsync(decimal main_id, List<decimal> user_ids, string server_id = "60.191.59.11");

        /// <summary>
        /// 下发工资条
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="month"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        Task<(bool, int)> SendAsync(OaWageSendRequest request, ClientInformation client);

        /// <summary>
        /// 查询工资下发状态
        /// </summary>
        Task<bool> GetSendStateAsync(GetSendStateRequest request);
    }
}
