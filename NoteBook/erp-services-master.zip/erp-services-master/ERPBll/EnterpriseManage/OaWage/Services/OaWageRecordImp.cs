﻿using AutoMapper;
using ERPBll.EnterpriseManage.OaWage.Contracts;
using ERPBll.RedisManage.Users;
using ERPBll.WorkPlace;
using ERPCore;
using ERPCore.Entity;
using ERPCore.Extensions;
using ERPDal;
using ERPModel.EnterpriseManage;
using ERPModel.EnterpriseManage.OaWage;
using ERPModel.Workplace;
using ERPModel.Workplace;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.EnterpriseManage.OaWage.Services
{
    public class OaWageRecordImp : Contracts.IOaWageRecordImp
    {
        private readonly IMapper _imapper;
        private readonly IUserRedisImp _iUserRedisImp;
        private readonly IErpMessageMainImp _iErpMessageMainImp;
        public OaWageRecordImp(
            IErpMessageMainImp iErpMessageMainImp,
            IUserRedisImp iUserRedisImp,
            IMapper imapper)
        {
            _imapper = imapper;
            _iUserRedisImp = iUserRedisImp;
            _iErpMessageMainImp = iErpMessageMainImp;
        }

        /// <summary>
        /// 导入工资条
        /// </summary>
        public async Task<(bool, List<string>)> Import(ImportOaWageRecord input, decimal? create_id)
        {
            var title = new Dictionary<string, string>()
            {
               { "姓名（必填项）","user_name" },
               { "手机号（必填项）","phone" },
               { "账号（非必填）","account" },
               { "基本工资（非必填）","basic_salary" },
               { "工龄工资（非必填）","seniority_pay" },
               { "职称补贴（非必填）","title_subsidies" },
               { "预发数（非必填）","pretest_number" },
               { "奖金（非必填）","bonus" },
               { "加班费（非必填）","overtime_pay" },
               { "代发工资（非必填）","agency_salary" },
               { "应发工资（非必填）","should_pay" },
               { "扣基本养老金（非必填）","pension" },
               { "扣医保基本金（非必填）","health_care" },
               { "扣住房公积金（非必填）","accumulation_fund" },
               { "扣失业保险金（非必填）","unemployment_insurance" },
               { "工会费（非必填）","union_fee" },
               { "房租水电费（非必填）","rent_hydropower" },
               { "考勤扣款（非必填）","attendance_deductions" },
               { "应扣合计（非必填）","should_deduct" },
               { "补扣20%工资（非必填）","fill_deduct" },
               { "计税工资（非必填）","plan_duty_salary" },
               { "扣个税（非必填）","income_tax" },
               { "实发工资（非必填）","real_wages" }
            };

            var result = new byte[] { };
            using (var ms = new MemoryStream())
            {
                input.file.CopyTo(ms);
                ms.Position = 0;
                result = ms.ToArray();
            }

            var dt = ExcelImportHelper.ReadBytesToDataTable(result, title);

            int index = 3;
            var errlist = new List<string>();

            for (int i = 1; i < dt.Rows.Count; i++)
            {
                for (int j = 0; j < dt.Columns.Count; j++)
                {
                    if (j == 0)
                    {
                        //检查必填项是否为空
                        if (string.IsNullOrEmpty(dt.Rows[i][j].ToString()))
                        {
                            errlist.Add("第" + index + "行姓名未填写，无法导入");
                        }
                        else
                        {
                            var user_id = await _iUserRedisImp.GetIdByNameAsync(dt.Rows[i][j].ToString());

                            if (user_id == null || user_id == 0)
                            {
                                errlist.Add("第" + index + "行姓名" + dt.Rows[i][j].ToString() + "不存在，无法导入");
                            }
                        }
                    }
                    else if (j == 1)
                    {
                        if (string.IsNullOrEmpty(dt.Rows[i][j].ToString()))
                        {
                            errlist.Add("第" + index + "行手机号未填写，无法导入");
                        }
                        else
                        {
                            if (!System.Text.RegularExpressions.Regex.IsMatch(dt.Rows[i][j].ToString(), @"^1[3456789]\d{9}$"))
                                errlist.Add("第" + index + "行手机号格式错误，无法导入");
                        }
                    }
                    else
                    {
                        System.Text.RegularExpressions.Regex reg = new System.Text.RegularExpressions.Regex(@"^[-]?\d+[.]?\d*$");
                        if (!string.IsNullOrEmpty(dt.Rows[i][j].ToString()) && !reg.IsMatch(dt.Rows[i][j].ToString()))
                        {
                            errlist.Add("第" + index + "行第" + (j + 1) + "列数据格式错误，无法导入");
                        }
                    }
                }
                index++;
            }

            //如果有错误
            if (errlist.Count > 0)
            {
                return (false, errlist);
            }

            var impotList = dt.ToImportDataList<ImportOaWageRecordData>();

            //跳过第一行模板数据
            impotList = impotList.Skip(1).Take(impotList.Count - 1).ToList();

            if (impotList == null || impotList.Count < 1)
            {
                throw new Exception("导入内容不能为空");
            }

            foreach (var item in impotList)
            {
                item.user_id = await _iUserRedisImp.GetIdByNameAsync(item.user_name);
            }

            var list = _imapper.Map<List<ImportOaWageRecordData>, List<OaWageRecord>>(impotList);

            var createMain = new CreateOrUpdateOaWageMain
            {
                month = (DateTime)input.month,
                type = input.type
            };

            var main = _imapper.Map<CreateOrUpdateOaWageMain, OaWageMain>(createMain);

            main.id = ERPBll.Tools.GetEngineID(input.server_id);
            main.SetCreate(create_id);

            list.ForEach(x =>
            {
                x.id = ERPBll.Tools.GetEngineID(input.server_id);
                x.main_id = main.id;
                x.SetCreate(create_id);
            });

            var res = await SqlSugarHelper.DBClient(input.server_id).Insertable(list).ExecuteCommandAsync() > 0;

            if (res)
            {
                res = await SqlSugarHelper.DBClient(input.server_id).Insertable(main).ExecuteCommandAsync() > 0;
            }

            return (res, errlist);
        }

        /// <summary>
        /// 获取最近一次上传的工资条
        /// </summary>
        public async Task<(List<OaWageRecordDto>, int, decimal?, DateTime?)> GetRecentAsync(OaWageRecordQuery query)
        {
            var main = await SqlSugarHelper.DBClient(query.server_id)
                                .Queryable<OaWageMain>()
                                .OrderBy(x => x.created_date, SqlSugar.OrderByType.Desc)
                                .FirstAsync();

            if (main == null)
            {
                return (new List<OaWageRecordDto>(), 0, null, null);
            }

            //查询
            var list = await SqlSugarHelper.DBClient(query.server_id)
                                .Queryable<OaWageRecord>()
                                .Where(x => x.main_id == main.id)
                                .Where(query.ToExp())
                                .Mapper(x => x.user_info, x => x.user_id)
                                .ToListAsync();

            var data = _imapper.Map<List<OaWageRecord>, List<OaWageRecordDto>>(list);

            if (list == null || list.Count < 1)
            {
                return (data, 0, 0, main.month);
            }

            return (data, list.Count, list.Sum(x => x.real_wages), main.month);
        }

        /// <summary>
        /// 删除
        /// </summary>
        public async Task<bool> DeleteAsync(string server_id, List<decimal> ids)
        {
            var res = await SqlSugarHelper.DBClient(server_id)
                                .Deleteable<OaWageRecord>()
                                .Where(x => ids.Contains(x.id))
                                .ExecuteCommandAsync() > 0;

            return res;
        }

        /// <summary>
        /// 获取发放记录
        /// </summary>
        public async Task<(List<WageCountDto>, int, decimal?)> GetSendRecordAsync(OaWageMainQuery query)
        {
            RefAsync<int> totalCount = 0;

            var list = await SqlSugarHelper.DBClient(query.server_id)
                        .Queryable<OaWageMain>()
                        .Where(query.ToExp())
                        .Mapper(x =>
                        {
                            x.records = SqlSugarHelper.DBClient(query.server_id)
                                                .Queryable<OaWageRecord>()
                                                .Where(y => y.main_id == x.id)
                                                .Mapper(y => y.user_info, y => y.user_id)
                                                .ToList();
                            x.people_count = x.records.Count;
                            x.money = x.records.Sum(y => y.real_wages);
                        })
                        .ToPageListAsync(query.page_index, query.page_size, totalCount);

            var mainIds = await SqlSugarHelper.DBClient(query.server_id)
                        .Queryable<OaWageMain>()
                        .Where(query.ToExp())
                        .Select(x => x.id)
                        .ToListAsync();

            var totalMoney = await SqlSugarHelper.DBClient(query.server_id)
                        .Queryable<OaWageRecord>()
                        .Where(x => mainIds.Contains(x.main_id))
                        .SumAsync(x => x.real_wages);

            var data = _imapper.Map<List<OaWageMain>, List<WageCountDto>>(list);

            if (list == null || list.Count < 1)
            {
                return (data, 0, 0);
            }

            return (data, totalCount, totalMoney);
        }

        /// <summary>
        /// 查看发放记录详情
        /// </summary>
        public async Task<(OaWageMainDto, int, decimal?, DateTime?)> GetSendDetailAsync(decimal main_id, List<decimal> user_ids, string server_id = "60.191.59.11")
        {

            //查询
            var main = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<OaWageMain>()
                                .Where(x => x.id == main_id)
                                .Mapper(x =>
                                {
                                    x.records = SqlSugarHelper.DBClient(server_id)
                                                        .Queryable<OaWageRecord>()
                                                        .Where(y => y.main_id == main_id)
                                                        .WhereIF(user_ids != null && user_ids.Count > 0,
                                                                y => user_ids.Contains(y.user_id))
                                                        .Mapper(y => y.user_info, y => y.user_id)
                                                        .ToList();
                                })
                                .FirstAsync();

            var data = _imapper.Map<OaWageMain, OaWageMainDto>(main);

            if (main == null || main.records == null)
            {
                return (data, 0, 0, null);
            }

            return (data, main.records.Count, main.records.Sum(x => x.real_wages), main.month);
        }

        /// <summary>
        /// 查询工资下发状态
        /// </summary>
        public async Task<bool> GetSendStateAsync(GetSendStateRequest request)
        {
            //查询
            var main = await SqlSugarHelper.DBClient(request.server_id).Queryable<OaWageMain>()
                               .Where(x => SqlFunc.Oracle_ToChar(x.month, "yyyy-MM") == request.month && x.type == request.type)
                               .FirstAsync();
            if (main != null && main.send == 1)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// 下发工资条
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="month"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        public async Task<(bool, int)> SendAsync(OaWageSendRequest request, ClientInformation client)
        {
            var result = false;
            var sends = new List<OaWageSend>();
            using (var db = SqlSugarHelper.DBClient(request.server_id))
            {
                //查询
                var main = await db.Queryable<OaWageMain>()
                                   .Where(x => SqlFunc.Oracle_ToChar(x.month, "yyyy-MM") == request.month && x.type == request.type)
                                   .OrderBy(x => x.created_date, OrderByType.Desc)
                                   //.WhereIF(request.cover == 0, x => x.send == 0)
                                   .Mapper(x =>
                                   {
                                       x.records = db.Queryable<OaWageRecord>()
                                                     .Where(y => y.main_id == x.id)
                                                     .ToList();
                                   })
                                   .FirstAsync();

                if (main == null)
                {
                    throw new Exception("工资条未导入");
                }
                if (request.cover == 0 && main.send == 1)
                {
                    return (false, 1);
                }

                if (main != null && main.records != null && main.records.Count > 0)
                {
                    foreach (var record in main.records)
                    {
                        var contents = "{";
                        for (var i = 0; i < request.send_types.Count; i++)
                        {
                            var isLast = (i == request.send_types.Count - 1);
                            if (request.send_types[i] == "基本工资")
                            {
                                contents += "\"基本工资\":" + record.basic_salary + (isLast ? "" : ",");
                            }
                            if (request.send_types[i] == "工龄工资")
                            {
                                contents += "\"工龄工资\":" + record.seniority_pay + (isLast ? "" : ",");
                            }
                            if (request.send_types[i] == "职称补贴")
                            {
                                contents += "\"职称补贴\":" + record.title_subsidies + (isLast ? "" : ",");
                            }
                            if (request.send_types[i] == "预发数")
                            {
                                contents += "\"预发数\":" + record.pretest_number + (isLast ? "" : ",");
                            }
                            if (request.send_types[i] == "奖金")
                            {
                                contents += "\"奖金\":" + record.bonus + (isLast ? "" : ",");
                            }
                            if (request.send_types[i] == "加班费")
                            {
                                contents += "\"加班费\":" + record.overtime_pay + (isLast ? "" : ",");
                            }
                            if (request.send_types[i] == "代发工资")
                            {
                                contents += "\"代发工资\":" + record.agency_salary + (isLast ? "" : ",");
                            }
                            if (request.send_types[i] == "应发工资")
                            {
                                contents += "\"应发工资\":" + record.should_pay + (isLast ? "" : ",");
                            }
                            if (request.send_types[i] == "扣基本养老金")
                            {
                                contents += "\"扣基本养老金\":" + record.pension + (isLast ? "" : ",");
                            }
                            if (request.send_types[i] == "扣医保基本金")
                            {
                                contents += "\"扣医保基本金\":" + record.health_care + (isLast ? "" : ",");
                            }
                            if (request.send_types[i] == "扣住房公积金")
                            {
                                contents += "\"扣住房公积金\":" + record.accumulation_fund + (isLast ? "" : ",");
                            }
                            if (request.send_types[i] == "扣失业保险金")
                            {
                                contents += "\"扣失业保险金\":" + record.unemployment_insurance + (isLast ? "" : ",");
                            }
                            if (request.send_types[i] == "工会费")
                            {
                                contents += "\"工会费\":" + record.union_fee + (isLast ? "" : ",");
                            }
                            if (request.send_types[i] == "房租水电费")
                            {
                                contents += "\"房租水电费\":" + record.rent_hydropower + (isLast ? "" : ",");
                            }
                            if (request.send_types[i] == "考勤扣款")
                            {
                                contents += "\"考勤扣款\":" + record.attendance_deductions + (isLast ? "" : ",");
                            }
                            if (request.send_types[i] == "应扣合计")
                            {
                                contents += "\"应扣合计\":" + record.should_deduct + (isLast ? "" : ",");
                            }
                            if (request.send_types[i] == "补扣20%工资")
                            {
                                contents += "\"补扣20%工资\":" + record.fill_deduct + (isLast ? "" : ",");
                            }
                            if (request.send_types[i] == "计税工资")
                            {
                                contents += "\"计税工资\":" + record.plan_duty_salary + (isLast ? "" : ",");
                            }
                            if (request.send_types[i] == "扣个税")
                            {
                                contents += "\"扣个税\":" + record.income_tax + (isLast ? "" : ",");
                            }
                            if (request.send_types[i] == "实发工资")
                            {
                                contents += "\"实发工资\":" + record.real_wages + (isLast ? "" : ",");
                            }
                        }
                        contents += "}";

                        var send = new OaWageSend
                        {
                            id = Tools.GetEngineID(request.server_id),
                            month = main.month,
                            main_id = main.id,
                            user_id = record.user_id,
                            content = contents,
                            real_wages = record.real_wages,
                            created_id = client.i_id,
                            created_date = DateTime.Now
                        };
                        sends.Add(send);
                    }

                }
                //消息表插入消息
                if (sends.Count > 0)
                {
                    //删除旧记录
                    if (request.cover == 1)
                    {
                        var list = await db.Queryable<OaWageSend>().Where(x => x.month == main.month && x.main_id == main.id).ToListAsync();
                        await db.Deleteable(list).ExecuteCommandAsync();
                    }
                    result = db.Insertable(sends).ExecuteCommand() > 0 ? true : false;
                    if (!result) throw new Exception("插入发放记录失败!");

                    sends.ForEach(send =>
                    {
                        var e = new ErpMessageMain
                        {
                            title = "下发工资条",
                            type = 1,
                            state = 2,
                            model = (int)MessageModelDic.工资条消息,
                            object_id = send.id.ToString(),
                            send_id = client.i_id,
                            created_id = send.user_id,
                            created_date = DateTime.Now,
                            warn = 1,
                            content = $"{send.month.ToString("yyyy年MM月")}工资已发放，点击查看详情。"
                        };
                        result = _iErpMessageMainImp.AddErpMessageMain(request.server_id, e, client).Result;
                        if (!result) throw new Exception("插入发放消息记录失败!");
                    });
                }

                if (main.send != 1)
                {
                    main.send = 1;
                    await db.Updateable(main).ExecuteCommandAsync();
                }
            }
            return (result, 0);
        }
    }
}
