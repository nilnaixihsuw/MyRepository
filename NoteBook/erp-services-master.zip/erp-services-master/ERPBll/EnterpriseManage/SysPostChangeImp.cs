﻿using ERPCore.ORM;
using ERPDal.EnterpriseManage;
using ERPModel.EnterpriseManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using ERPModel.ApiModel.EnterpriseManage;
using System.Linq.Expressions;
using ERPDal.UserManage;
using ERPCore.Entity;

namespace ERPBll.EnterpriseManage
{
    public class SysPostChangeImp : BusinessRespository<SysPostChange, ISysPostChangeDataImp>, ISysPostChangeImp
    {
        private readonly ISysPersonDataImp _iSysPersonDataImp;
        public SysPostChangeImp(
            ISysPersonDataImp iSysPersonDataImp,
            ISysPostChangeDataImp dataImp) : base(dataImp)
        {
            _iSysPersonDataImp = iSysPersonDataImp;
        }

        public async Task<bool> Cancel(string server_id, List<decimal> context)
        {
            var list = await _dataImp.List(server_id, it => SqlFunc.ContainsArray(context, it.id));
            return await _dataImp.Deletetable(server_id, list);
        }

        public async Task<bool> Confirm(string server_id, List<decimal> context)
        {
            var list = await _dataImp.List(server_id, it => SqlFunc.ContainsArray(context, it.id));
            list.ForEach(item =>
            {
                item.deal = 1;
            });
            return await _dataImp.Updatetable(server_id, list, new string[] { "state" });
        }

        public async Task<bool> PostChange(string server_id, SysPostChange context, ClientInformation client)
        {
            context.created_id = client.i_id;
            context.created_date = DateTime.Now;
            context.deal = 0;
            return await _dataImp.Insert(server_id, context);
        }

        public async Task<List<SysPostChange>> QueryPostChangeList(string server_id, PostChangeManageRequest request, string where)
        {
            var exp = await GetExp(request);
            return await ExtensionList(server_id, request.ToExp(exp), where, request.orderby);
        }

        public async Task<Tuple<List<SysPostChange>, int>> QueryPostChangePageList(string server_id, PostChangeManageRequest request, string where)
        {
            var exp = await GetExp(request);
            return await ExtensionList(server_id, request.ToExp(exp), where, request.page_size, request.page_index, request.orderby);
        }

        private async Task<List<Expression<Func<SysPostChange, bool>>>> GetExp(PostChangeManageRequest request)
        {
            var r = new List<Expression<Func<SysPostChange, bool>>>();
            if (!string.IsNullOrEmpty(request.name))
            {
                var emps = await _iSysPersonDataImp.List(request.server_id, it => it.c_name.Contains(request.name));
                r.Add(it => SqlFunc.ContainsArray(emps.Select(it => it.i_id).ToList(), it.user_id));
            }
            return r;
        }
    }
}