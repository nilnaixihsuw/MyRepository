﻿using ERPCore.ORM;
using ERPDal.EnterpriseManage;
using ERPModel.EnterpriseManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using ERPCore.Entity;
using Microsoft.AspNetCore.Http;
using System.IO;
using ERPCore;
using ERPCore.Extensions;
using ERPModel.ApiModel.EnterpriseManage;
using System.Linq.Expressions;

namespace ERPBll.EnterpriseManage
{
    public class ErpElectricRecordImp : BusinessRespository<ErpElectricRecord, IErpElectricRecordDataImp>, IErpElectricRecordImp
    {
        private readonly IErpElectricGroupDataImp _iErpElectricGroupDataImp;
        public ErpElectricRecordImp(
            IErpElectricGroupDataImp iErpElectricGroupDataImp,
            IErpElectricRecordDataImp dataImp) : base(dataImp)
        {
            _iErpElectricGroupDataImp = iErpElectricGroupDataImp;
        }

        public async Task<bool> AddElectric(string server_id, ErpElectricRecord context, ClientInformation client)
        {
            if (context.id > 0)
            {
                //编辑
                context.update_date = DateTime.Now;
                context.update_id = client.i_id;
                var old = await Get(server_id, context.id);
                context.created_date = old.created_date;
                context.created_id = old.created_id;
                return await _dataImp.Update(server_id, context);
            }
            else
            {
                //新增
                context.created_date = DateTime.Now;
                context.created_id = client.i_id;
                return await _dataImp.Insert(server_id, context);

            }
        }

        public async Task<List<ErpElectricRecord>> ElectricList(string server_id, ElectricRecordManage.QueryRequest request, string where)
        {
            var exp = await GetExp(request);
            return await ExtensionList(server_id, request.ToExp(exp), where, request.orderby);
        }

        private async Task<List<Expression<Func<ErpElectricRecord, bool>>>> GetExp(ElectricRecordManage.QueryRequest request)
        {
            var r = new List<Expression<Func<ErpElectricRecord, bool>>>();
            if (request.id != null)
            {
                var ids = await _iErpElectricGroupDataImp.QueryChildIds(request.server_id, request.id);
                r.Add(it => it.electric_id == request.id || SqlFunc.ContainsArray(ids, it.electric_id));
            }
            return r;
        }

        public async Task<Tuple<List<ErpElectricRecord>, int>> ElectricPageList(string server_id, ElectricRecordManage.QueryRequest request, string where)
        {
            var exp = await GetExp(request);
            return await ExtensionList(server_id, request.ToExp(exp), where, request.page_size, request.page_index, request.orderby);
        }

        public async Task<bool> Import(string server_id, IFormFile file, int type, ClientInformation client)
        {
            var title = new Dictionary<string, string>()
            {
               { "抄表日期", "read_date"},
               { "所属地址", "ex_elctric_belong"},
               { "电表名称", "ex_elctric_name"},
               { "每度金额(度/元)","price"},
               { "电表上月底数", "last_value"},
               { "电表本月度数", "this_value"},
            };

            var result = new byte[] { };
            //文件内容是否为空
            if (file.Length == 0)
                throw new Exception("文件不能为空");

            //文件后缀
            string filename = file.FileName;
            var ext = filename.Substring(filename.LastIndexOf("."), filename.Length - filename.LastIndexOf("."));

            // 判断后缀
            if (ext != ".xlsx" && ext != ".xls")
            {
                throw new Exception("请上传Excel文件！");
            }

            using (var ms = new MemoryStream())
            {
                file.CopyTo(ms);
                ms.Position = 0;
                result = ms.ToArray();
            }
            var dt = ExcelImportHelper.ReadBytesToDataTable(result, title);
            var list = dt.ToDataList<ErpElectricRecord>();
            var upList = new List<ErpElectricRecord>();

            //检查空值
            if (list.Exists(it => it.read_date == null))
            {
                throw new Exception("存在抄表日期为空记录！");
            }
            if (list.Exists(it => string.IsNullOrEmpty(it.ex_elctric_name)))
            {
                throw new Exception("存在电表名称为空记录！");
            }
            if (list.Exists(it => string.IsNullOrEmpty(it.ex_elctric_belong)))
            {
                throw new Exception("存在所属地址为空记录！");
            }
            if (list.Exists(it => it.last_value == null))
            {
                throw new Exception("存在电表上月底数为空记录！");
            }
            if (list.Exists(it => it.last_value == null))
            {
                throw new Exception("存在电表本月度数为空记录！");
            }
            var electricNames = list.Select(it => it.ex_elctric_name).ToList();
            var electricGroups = await _iErpElectricGroupDataImp.List(server_id, it => SqlFunc.ContainsArray(electricNames, it.name));
            //补充list其他的值
            list.ForEach(item =>
            {
                if (electricGroups.Exists(it => it.name == item.ex_elctric_name))
                {
                    var electric = electricGroups.Find(it => it.name == item.ex_elctric_name);
                    item.electric_id = electric.id;
                }
                else
                {
                    throw new Exception("不存在电表名称！");
                }
                item.use = item.this_value - item.last_value;
                item.total_fee = item.use * item.price;
                item.remark = "导入";
                item.created_date = DateTime.Now;
                item.created_id = client.i_id;
            });
            //覆盖
            if (type == 1)
            {

            }
            //保持原数据
            if (type == 0)
            {

            }

            return await _dataImp.Insertable(server_id, list);
        }

        public async Task<bool> BatchDelete(string server_id, List<decimal> context)
        {
            var list = await _dataImp.List(server_id, it => SqlFunc.ContainsArray(context, it.id));
            return await _dataImp.Deletetable(server_id, list);
        }
    }
}