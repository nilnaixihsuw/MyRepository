﻿using ERPDal.Repository;
using ERPModel.ApiModel.EnterpriseManage.TaxiManage;
using ERPModel.EnterpriseManage.TaxiManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.EnterpriseManage.TaxiManage
{
    public interface ITaxiDriverInfoImp : IBaseBusiness<TaxiDriverInfo>
    {
        Task<Tuple<int, List<TaxiDriverDto>>> GetRecord(TaxiDriverRequest request);
    }
}
