﻿using AutoMapper;
using ERPDal;
using ERPDal.Repository;
using ERPModel.ApiModel.EnterpriseManage.TaxiManage;
using ERPModel.EnterpriseManage.TaxiManage;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.EnterpriseManage.TaxiManage
{
    public class TaxiInfoImp : BaseBusiness<TaxiInfo>, ITaxiInfoImp
    {
        private readonly IMapper _imapper;
        private readonly ITaxiDriverRelationImp _iTaxiDriverRelationImp;
        public TaxiInfoImp(
            ITaxiDriverRelationImp iTaxiDriverRelationImp,
            IMapper imapper)
        {
            _iTaxiDriverRelationImp = iTaxiDriverRelationImp;
            _imapper = imapper;
        }
        public async Task<Tuple<int, List<TaxiInfoDto>>> GetRecord(TaxiInfoRequest request)
        {
            var ids = new List<decimal>();
            if (request.driver_id != null && request.driver_id > 0)
            {
                var relations = await _iTaxiDriverRelationImp.List(request.server_id, r => r.driver_id == request.driver_id);
                ids = relations.Select(r => r.taxi_id).ToList();
            }

            RefAsync<int> totalNumber = 0;
            var records = await SqlSugarHelper.DBClient(request.server_id).Queryable<TaxiInfo>()
                .Includes(r => r.brand_info)
                .Includes(r => r.relations)
                .WhereIF(ids != null && ids.Count > 0, r => ids.Contains(r.id))
                .Where(request.ToExp()).ToListAsync();
                //.ToPageListAsync(request.page_index, request.page_size, totalNumber);

            records = records.OrderBy(r => r.lincense_plate_number).ToList();
            totalNumber = records.Count;
            records = Tools.Sort(records, request.sort, request.ase).ToList();
            if (request.page_index > 0 && request.page_size > 0)
            {
                records = records.Skip((request.page_index - 1) * request.page_size).Take(request.page_size).ToList();
            }

            var list = new List<TaxiInfoDto>();
            using (var DB = SqlSugarHelper.DBClient(request.server_id))
            {
                foreach (var item in records)
                {
                    var temp = _imapper.Map<TaxiInfo, TaxiInfoDto>(item);
                    temp.brand_name = item.brand_info?.c_name;
                    switch (item.operation_state)
                    {
                        case 1:
                            temp.operation_state_name = "营运";
                            break;
                        case 2:
                            temp.operation_state_name = "停运";
                            break;
                        case 3:
                            temp.operation_state_name = "报废";
                            break;
                        default:
                            break;
                    }
                    temp.vehicle_owner_name = item.vehicle_owner == 1 ? "自营" : "挂靠";
                    if (item.relations != null && item.relations.Count > 0)
                    {
                        temp.driver_ids = item.relations.Select(r => r.driver_id).ToList();
                        var drivers = await DB.Queryable<TaxiDriverInfo>()
                            .Where(r => temp.driver_ids.Contains(r.id)).ToListAsync();
                        var a = new List<string>();
                        drivers.ForEach(r => a.Add($"{r.name}({r.phone})"));
                        temp.driver_phone = string.Join(',', a);
                    }
                    list.Add(temp);
                }
            }
            return new Tuple<int, List<TaxiInfoDto>>(totalNumber, list);
        }
    }
}
