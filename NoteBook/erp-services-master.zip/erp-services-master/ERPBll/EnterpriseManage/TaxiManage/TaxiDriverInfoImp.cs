﻿using AutoMapper;
using ERPDal;
using ERPDal.Repository;
using ERPModel.ApiModel.EnterpriseManage.TaxiManage;
using ERPModel.EnterpriseManage.TaxiManage;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.EnterpriseManage.TaxiManage
{
    public class TaxiDriverInfoImp : BaseBusiness<TaxiDriverInfo>, ITaxiDriverInfoImp
    {
        private readonly IMapper _imapper;
        private readonly ITaxiDriverRelationImp _iTaxiDriverRelationImp;
        public TaxiDriverInfoImp(
            ITaxiDriverRelationImp iTaxiDriverRelationImp,
            IMapper imapper)
        {
            _iTaxiDriverRelationImp = iTaxiDriverRelationImp;
            _imapper = imapper;
        }
        public async Task<Tuple<int, List<TaxiDriverDto>>> GetRecord(TaxiDriverRequest request)
        {
            var ids = new List<decimal>();
            if (request.taxi_id == null || request.taxi_id == 0)
            {
                ids = null;
            }
            else 
            {
                var relations = await _iTaxiDriverRelationImp.List(request.server_id, r => r.taxi_id == request.taxi_id);
                ids = relations.Select(r => r.driver_id).ToList();
                ids = ids == null || ids.Count == 0 ? new List<decimal>() : ids;
            }

            RefAsync<int> totalNumber = 0;
            var records = await SqlSugarHelper.DBClient(request.server_id).Queryable<TaxiDriverInfo>()
                .Includes(r => r.relation.MappingField(a => a.driver_id, () => r.id).ToList())
                .WhereIF(ids != null, r => ids.Contains(r.id))
                .Where(request.ToExp()).ToListAsync();
            //.ToPageListAsync(request.page_index, request.page_size, totalNumber);

            records = records.OrderBy(r => r.name).ToList();
            totalNumber = records.Count;
            records = Tools.Sort(records, request.sort, request.ase).ToList();
            if (request.page_index > 0 && request.page_size > 0)
            {
                records = records.Skip((request.page_index - 1) * request.page_size).Take(request.page_size).ToList();
            }

            var list = new List<TaxiDriverDto>();
            using (var DB = SqlSugarHelper.DBClient(request.server_id))
            {
                foreach (var item in records)
                {
                    var temp = _imapper.Map<TaxiDriverInfo, TaxiDriverDto>(item);
                    temp.gender_name = temp.gender == 2 ? "女" : "男";
                    temp.state_name = temp.state == 1 ? "在聘" : "解聘";
                    if (item.relation != null)
                    {
                        temp.taxi_id = item.relation.taxi_id;
                        var taxi = await DB.Queryable<TaxiInfo>()
                            .Where(r => item.relation.taxi_id == r.id).FirstAsync();
                        temp.lincense_plate_number = taxi?.lincense_plate_number;
                    }
                    list.Add(temp);
                }
            }
           

            return new Tuple<int, List<TaxiDriverDto>>(totalNumber, list);
        }
    }
}
