﻿using ERPDal.Repository;
using ERPModel.EnterpriseManage.TaxiManage;
using System;
using System.Collections.Generic;
using System.Text;

namespace ERPBll.EnterpriseManage.TaxiManage
{
    public interface ITaxiDriverRelationImp : IBaseBusiness<TaxiDriverRelation>
    {

    }
}
