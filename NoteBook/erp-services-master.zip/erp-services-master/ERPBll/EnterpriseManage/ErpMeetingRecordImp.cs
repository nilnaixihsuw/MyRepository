﻿using ERPCore.ORM;
using ERPDal.EnterpriseManage;
using ERPModel.EnterpriseManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using ERPCore.Entity;
using ERPModel.ApiModel.EnterpriseManage;
using BusTools.Redis;
using ERPCore.Redis;
using ERPDal;
using ERPModel.FlowManage.FlowRecords;
using ERPBll.FlowManage.Contracts;
using DotNetCore.CAP;
using ERPBll.Caps;
using ERPModel.FlowManage;
using System.Text;
using ERPModel.FlowManage.FlowSteps;
using ERPBll.RedisManage.Users;

namespace ERPBll.EnterpriseManage
{
    public class ErpMeetingRecordImp : BusinessRespository<ErpMeetingRecord, IErpMeetingRecordDataImp>, IErpMeetingRecordImp, ICapSubscribe
    {
        private readonly IErpFlowRecordImp _iErpFlowRecordImp;
        private readonly IErpMeetingMainImp _iErpMeetingMainImp;
        private readonly IUserRedisImp _iUserRedisImp;

        public ErpMeetingRecordImp(
            IUserRedisImp iUserRedisImp,
            IErpMeetingMainImp iErpMeetingMainImp,
            IErpFlowRecordImp iErpFlowRecordImp,
            IErpMeetingRecordDataImp dataImp) : base(dataImp)
        {
            _iUserRedisImp = iUserRedisImp;
            _iErpFlowRecordImp = iErpFlowRecordImp;
            _iErpMeetingMainImp = iErpMeetingMainImp;
        }

        public async Task<bool> BookMeetingRoom(string server_id, ErpMeetingRecord context, ClientInformation client)
        {
            context.created_id = client.i_id;
            context.created_date = DateTime.Now;
            context.id = await _dataImp.GetId(server_id, "SEQ_COMMON");
            if (!string.IsNullOrEmpty(context.content))
            {
                context.state = 2;

                var name = await _iUserRedisImp.GetNameByIdAsync(context.apply_id.ToString());
                var room = await _iErpMeetingMainImp.Get(server_id, context.meeting_id);
                StringBuilder sb = new StringBuilder();
                sb.AppendLine($"预定人:{name}");
                sb.AppendLine($"开始时间:{context.begin_time}");
                sb.AppendLine($"结束时间:{context.end_time}");
                sb.AppendLine($"会议内容:{context.content}");
                // 发起流程
                var flowRecord = await _iErpFlowRecordImp.AddAsync(server_id, client.i_id,
                    new CreateErpFlowRecord
                    {
                        title = $"{name}提交的会议室预订申请",
                        content = sb.ToString(),
                        type = 2,
                        object_id = (int)FlowRecordType.会议室申请,
                        user_id = context.apply_id,
                        flow_steps = new List<CreateErpFlowStep>()
                        {
                                new CreateErpFlowStep()
                                {
                                    user_ids = new List<decimal> { room.check_id.Value },
                                }
                        }
                    });

                if (flowRecord == null)
                {
                    throw new Exception("发起流程失败");
                }
                context.flow_id = flowRecord.id;
                context.flow_code = flowRecord.code;
                await _iErpFlowRecordImp.UpdateAsync(server_id, Convert.ToInt32(context.flow_id), Convert.ToInt32(context.id), "");
            }
            else
            {
                context.state = 3;
            }
            return await _dataImp.BookMeetingRoom(server_id, context, client);
        }

        public async Task<bool> CancelBook(string server_id, List<decimal> request)
        {
            var list = await _dataImp.List(server_id, it => SqlFunc.ContainsArray(request, it.id));
            list.ForEach(item =>
            {
                item.state = 5;
            });
            return await _dataImp.Updatetable(server_id, list, new string[] { "state" });
        }

        public async Task<ErpMeetingRecord> Detail(string server_id, decimal id, ClientInformation client)
        {
            var q = await SqlSugarHelper.DBClient(server_id).Queryable<ErpMeetingRecord>()
                                                            .Where(it => it.id == id)
                                                            .ToListAsync();
            var list = await _dataImp.ExtList(server_id, q);
            if (list.Count > 0)
            {
                var all = await _iErpFlowRecordImp.GetListAsync(server_id, client.i_id,
                    new FlowRecordQuery()
                    {
                        detail_ids = list.Select(x => (int)x.id).ToList()
                    }
                );
                foreach (var item in list)
                {
                    if (item.state == 2)//处理中
                    {
                        var info = all.FirstOrDefault(x => x.detail_id == item.id);
                        if (info != null)
                        {
                            item.user_ids = info.state_child_id;
                            item.user_names = info.state_child_name;
                        }
                    }
                }
                return list.FirstOrDefault();
            }
            else
                return null;
        }

        public async Task<MyMeetingRoomBook> ListMyBookRecords(string server_id, ClientInformation client)
        {
            var q = await SqlSugarHelper.DBClient(server_id).Queryable<ErpMeetingRecord>()
                                                            .Where(it => it.apply_id == client.i_id)
                                                            .ToListAsync();
            var list = await _dataImp.ExtList(server_id, q);
            if (list.Count > 0)
            {
                var all = await _iErpFlowRecordImp.GetListAsync(server_id, client.i_id,
                    new FlowRecordQuery()
                    {
                        detail_ids = list.Select(x => (int)x.id).ToList()
                    }
                );
                foreach (var item in list)
                {
                    if (item.state == 2)//处理中
                    {
                        var info = all.FirstOrDefault(x => x.detail_id == item.id);
                        if (info != null)
                        {
                            item.user_ids = info.state_child_id;
                            item.user_names = info.state_child_name;
                        }
                    }
                }
            }

            var r = new MyMeetingRoomBook
            {
                reserved = list.Where(it => it.end_time >= DateTime.Now && (it.state == 2 || it.state == 3)).OrderByDescending(it => it.begin_time).ToList(),
                finished = list.Where(it => it.end_time < DateTime.Now || it.state == 4 || it.state == 5).OrderByDescending(it => it.begin_time).ToList()
            };
            return r;
        }

        public async Task<List<ErpMeetingRecord>> ListReserveHistory(ErpMeetingHistoryRequest request, string v, ClientInformation client)
        {
            var q = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpMeetingRecord>()
                                                           .WhereIF(request.ToExp() != null, request.ToExp())
                                                           .WhereIF(!string.IsNullOrEmpty(v), v)
                                                           .OrderByIF(!string.IsNullOrEmpty(request.orderby), request.orderby)
                                                           .ToListAsync();
            var list = await _dataImp.ExtList(request.server_id, q);
            if (list.Count > 0)
            {
                var all = await _iErpFlowRecordImp.GetListAsync(request.server_id, client.i_id,
                    new FlowRecordQuery()
                    {
                        detail_ids = list.Select(x => (int)x.id).ToList()
                    }
                );
                foreach (var item in list)
                {
                    if (item.state == 2)//处理中
                    {
                        var info = all.FirstOrDefault(x => x.detail_id == item.id);
                        if (info != null)
                        {
                            item.user_ids = info.state_child_id;
                            item.user_names = info.state_child_name;
                        }
                    }
                }
            }

            return list;
        }

        public async Task<Tuple<List<ErpMeetingRecord>, int>> ListReserveHistoryPage(ErpMeetingHistoryRequest request, string v, ClientInformation client)
        {
            RefAsync<int> total = 0;
            var q = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpMeetingRecord>()
                                                            .WhereIF(request.ToExp() != null, request.ToExp())
                                                            .WhereIF(!string.IsNullOrEmpty(v), v)
                                                            .OrderByIF(!string.IsNullOrEmpty(request.orderby), request.orderby)
                                                            .ToPageListAsync(request.page_index, request.page_size, total);
            var list = await _dataImp.ExtList(request.server_id, q);
            if (list.Count > 0)
            {
                var all = await _iErpFlowRecordImp.GetListAsync(request.server_id, client.i_id,
                   new FlowRecordQuery()
                   {
                       detail_ids = list.Select(x => (int)x.id).ToList()
                   }
                );
                foreach (var item in list)
                {
                    if (item.state == 2)//处理中
                    {
                        var info = all.FirstOrDefault(x => x.detail_id == item.id);
                        if (info != null)
                        {
                            item.user_ids = info.state_child_id;
                            item.user_names = info.state_child_name;
                        }
                    }
                }
            }

            return new Tuple<List<ErpMeetingRecord>, int>(list, total);
        }


    }
}