﻿using ERPCore.ORM;
using ERPModel.ApiModel.EnterpriseManage;
using ERPModel.EnterpriseManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.EnterpriseManage
{
    public interface IErpBusRecordImp : IBusinessRepository<ErpBusRecord>
    {
        Task<List<BusRecordDto>> GetUseRecord(int? type, decimal bus_id, decimal user_id, string server_id);

        Task<BusRecordDto> GetDetail(string server_id, decimal? user_id, decimal id);
    }
}