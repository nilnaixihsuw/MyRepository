﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPModel.ApiModel.EnterpriseManage;
using ERPModel.EnterpriseManage;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.EnterpriseManage
{
    public interface IErpWaterRecordImp : IBusinessRepository<ErpWaterRecord>
    {
        Task<bool> AddWater(string server_id, ErpWaterRecord context, ClientInformation client);
        Task<bool> Import(string server_id, IFormFile file, int type, ClientInformation client);
        Task<Tuple<List<ErpWaterRecord>, int>> WaterPageList(string server_id, ElectricRecordManage.WaterQueryRequest request, string v);
        Task<List<ErpWaterRecord>> WaterList(string server_id, ElectricRecordManage.WaterQueryRequest request, string v);
        Task<bool> BatchDelete(string server_id, List<decimal> context);
    }
}