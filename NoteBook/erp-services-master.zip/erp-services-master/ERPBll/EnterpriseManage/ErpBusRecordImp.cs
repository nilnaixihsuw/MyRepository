﻿using ERPCore.ORM;
using ERPDal.EnterpriseManage;
using ERPModel.EnterpriseManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using ERPModel.ApiModel.EnterpriseManage;
using ERPBll.UserManage;
using AutoMapper;
using DotNetCore.CAP;
using ERPBll.Caps;
using ERPModel.FlowManage.FlowRecords;
using ERPDal;
using ERPModel.FlowManage;
using ERPModel.UserManage;
using ERPBll.FlowManage.Contracts;
using ERPModel.EnterpriseManage.BusRequest;

namespace ERPBll.EnterpriseManage
{
    public class ErpBusRecordImp : BusinessRespository<ErpBusRecord, IErpBusRecordDataImp>, IErpBusRecordImp, ICapSubscribe
    {
        private readonly IErpBusMainImp _iErpBusMainImp;
        private readonly ISysPersonImp _iSysPersonImp;
        private readonly IMapper _imapper;
        private readonly IErpFlowRecordImp _erpFlowRecordImp;
        public ErpBusRecordImp(IErpBusRecordDataImp dataImp,
            IErpBusMainImp iErpBusMainImp,
            ISysPersonImp iSysPersonImp,
            IErpFlowRecordImp erpFlowRecordImp,
            IMapper imapper) : base(dataImp)
        {
            _iErpBusMainImp = iErpBusMainImp;
            _iSysPersonImp = iSysPersonImp;
            _imapper = imapper;
            _erpFlowRecordImp = erpFlowRecordImp;
        }

        public async Task<List<BusRecordDto>> GetUseRecord(int? type, decimal bus_id, decimal user_id, string server_id)
        {
            var buses = await _iErpBusMainImp.List(server_id, null);
            var persons = await _iSysPersonImp.List(server_id, null);
            var dept = DeptInfoBll.GetAllDeptments(server_id);
            var all_records = await _dataImp.List(server_id, null);
            var records = all_records;

            var requests = new List<ErpBusRequestQueue>();

            if (!type.HasValue || type != 1)
            {
                requests = await SqlSugarHelper.DBClient(server_id)
                           .Queryable<ErpBusRequestQueue>()
                           .WhereIF(bus_id > 0, x => x.bus_id == bus_id)
                           .WhereIF(user_id > 0, x => x.user_id == user_id)
                           .ToListAsync();
            }

            if (bus_id != 0)
            {
                records = records.Where(r => r.bus_id == bus_id).ToList();
            }
            if (user_id != 0)
            {
                records = records.Where(r => r.borrow_id == user_id).ToList();
            }
            var record_list = _imapper.Map<List<ErpBusRecord>, List<BusRecordDto>>(records);
            var request_list = _imapper.Map<List<ErpBusRequestQueue>, List<BusRecordDto>>(requests);

            var list = new List<BusRecordDto>();

            if (!type.HasValue || type != 2)
            {
                record_list.ForEach(r =>
                {
                    r.type = 1;
                    var temp = persons.FirstOrDefault(m => m.i_id == r.borrow_id);
                    r.borrow_name = temp?.c_name;
                    r.borrow_dept = dept.FirstOrDefault(m => m.i_id == temp?.i_department_base)?.c_name;

                    var temp1 = persons.FirstOrDefault(m => m.i_id == r.back_id);
                    r.back_name = temp?.c_name;

                    if (r.borrow_time != null && r.back_time != null)
                    {
                        r.use_time = Math.Round((r.back_time.Value - r.borrow_time.Value).TotalHours, 2, MidpointRounding.AwayFromZero);
                    }

                    var bus = buses.FirstOrDefault(m => m.id == r.bus_id);
                    if (bus != null)
                    {
                        r.name = bus.name;
                        r.kind = bus.kind;
                        r.code = bus.code;
                        r.max_count = bus.max_count;
                        r.last_position = bus.last_position;
                        r.img_url = bus.img_url;
                        r.audit_person = bus.audit_person;
                        r.audit_person_name = persons.FirstOrDefault(m => m.i_id == r.audit_person)?.c_name;
                        r.is_audit = bus.is_audit;
                    }
                    list.Add(r);
                });
            }

            request_list.ForEach(r =>
            {
                var record = all_records.Where(x => x.bus_id == r.bus_id && x.state == 1).FirstOrDefault();
                r.type = 2;

                if (record != null)
                {
                    var temp = persons.FirstOrDefault(m => m.i_id == record.borrow_id);
                    r.state_child = record.state_child;
                    r.borrow_name = temp?.c_name;
                    r.borrow_dept = dept.FirstOrDefault(m => m.i_id == temp?.i_department_base)?.c_name;
                }
                if (r.request_state == 1)
                {
                    r.state = 1;
                }
                else
                {
                    r.state = 2;
                }

                if (r.borrow_time != null && r.back_time != null)
                {
                    r.use_time = Math.Round((r.back_time.Value - r.borrow_time.Value).TotalHours, 2, MidpointRounding.AwayFromZero);
                }

                var bus = buses.FirstOrDefault(m => m.id == r.bus_id);
                if (bus != null)
                {
                    r.name = bus.name;
                    r.kind = bus.kind;
                    r.code = bus.code;
                    r.max_count = bus.max_count;
                    r.last_position = bus.last_position;
                    r.img_url = bus.img_url;
                    r.audit_person = bus.audit_person;
                    r.audit_person_name = persons.FirstOrDefault(m => m.i_id == r.audit_person)?.c_name;
                    r.is_audit = bus.is_audit;
                }
                list.Add(r);
            });
            return list;
        }

        public async Task<BusRecordDto> GetDetail(string server_id, decimal? user_id, decimal id)
        {
            var persons = await _iSysPersonImp.List(server_id, null);
            //查询
            var info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpBusRecord>()
                                .Where(x => x.id == id)
                                .Mapper(x => x.bus_info, x => x.bus_id)
                                .Mapper(async x =>
                                {
                                    x.borrow_info = await SqlSugarHelper.DBClient(server_id).Queryable<SysPerson, SysDepPerson, SysDepartment>(
                                        (a, b, c) => new JoinQueryInfos(JoinType.Left, a.i_id == b.i_child_id && b.sign == 1, JoinType.Left, b.i_group_id == c.i_id))
                                    .Where(a => a.i_id == x.borrow_id)
                                   .Select((a, b, c) => new SysPerson
                                   {
                                       i_id = a.i_id,
                                       department_main_name = c.c_name,
                                       c_name = a.c_name
                                   }).FirstAsync();
                                })
                                 .Mapper(async x =>
                                 {
                                     x.back_info = await SqlSugarHelper.DBClient(server_id).Queryable<SysPerson, SysDepPerson, SysDepartment>(
                                         (a, b, c) => new JoinQueryInfos(JoinType.Left, a.i_id == b.i_child_id && b.sign == 1, JoinType.Left, b.i_group_id == c.i_id))
                                     .Where(a => a.i_id == x.back_id)
                                    .Select((a, b, c) => new SysPerson
                                    {
                                        i_id = a.i_id,
                                        department_main_name = c.c_name,
                                        c_name = a.c_name
                                    }).FirstAsync();
                                 }).FirstAsync();

            var ids = new List<int>();

            if (info == null)
            {
                throw new Exception($"未找到车辆借记信息，id={id}");
            }

            ids.Add(Convert.ToInt32(info.id));

            var all = await _erpFlowRecordImp.GetListAsync(server_id, user_id,
                new FlowRecordQuery()
                {
                    detail_ids = ids
                });

            if (info.state_child == 1 || info.state_child == 4)//审核中
            {
                var flow_info = all.FirstOrDefault(x => x.detail_id == info.id);
                if (flow_info != null)
                {
                    info.user_ids = flow_info.state_child_id;
                    info.user_names = flow_info.state_child_name;
                }
            }

            var result = _imapper.Map<ErpBusRecord, BusRecordDto>(info);
            result.borrow_name = info.borrow_info?.c_name;
            result.borrow_dept = info.borrow_info?.department_main_name;
            result.back_name = info.back_info?.c_name;
            //result.bd = info.borrow_info?.department_main_name;

            if (result.borrow_time != null && result.back_time != null)
            {
                result.use_time = (result.borrow_time.Value - result.back_time.Value).TotalHours;
            }

            var bus = info.bus_info;
            if (bus != null)
            {
                result.name = bus.name;
                result.kind = bus.kind;
                result.code = bus.code;
                result.max_count = bus.max_count;
                result.last_position = bus.last_position;
                result.img_url = bus.img_url;
                result.audit_person = bus.audit_person;
                result.audit_person_name = persons.FirstOrDefault(m => m.i_id == result.audit_person)?.c_name;
            }
            return result;
        }
    }
}