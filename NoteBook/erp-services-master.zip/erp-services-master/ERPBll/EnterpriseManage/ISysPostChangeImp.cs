﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPModel.ApiModel.EnterpriseManage;
using ERPModel.EnterpriseManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.EnterpriseManage
{
    public interface ISysPostChangeImp : IBusinessRepository<SysPostChange>
    {
        Task<Tuple<List<SysPostChange>, int>> QueryPostChangePageList(string server_id, PostChangeManageRequest request, string v);
        Task<List<SysPostChange>> QueryPostChangeList(string server_id, PostChangeManageRequest request, string v);
        Task<bool> PostChange(string server_id, SysPostChange context, ClientInformation client);
        Task<bool> Confirm(string server_id, List<decimal> context);
        Task<bool> Cancel(string server_id, List<decimal> context);
    }
}