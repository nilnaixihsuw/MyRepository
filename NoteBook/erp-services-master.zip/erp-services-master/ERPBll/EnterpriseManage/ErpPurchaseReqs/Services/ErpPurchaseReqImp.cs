﻿using AutoMapper;
using DotNetCore.CAP;
using ERPBll.Caps;
using ERPBll.EnterpriseManage.ErpPurchaseReqs.Contracts;
using ERPBll.FlowManage.Contracts;
using ERPBll.RedisManage.Users;
using ERPCore.Entity;
using ERPDal;
using ERPModel.EnterpriseManage.ErpPurchaseReqs;
using ERPModel.FlowManage;
using ERPModel.FlowManage.FlowRecords;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.EnterpriseManage.ErpPurchaseReqs.Services
{
    public class ErpPurchaseReqImp : IErpPurchaseReqImp
    {
        private readonly IMapper _imapper;
        private readonly IErpFlowRecordImp _iErpFlowRecordImp;
        private readonly IUserRedisImp _iUserRedisImp;

        public ErpPurchaseReqImp(
            IMapper imapper,
            IErpFlowRecordImp iErpFlowRecordImp,
            IUserRedisImp iUserRedisImp)
        {
            _imapper = imapper;
            _iErpFlowRecordImp = iErpFlowRecordImp;
            _iUserRedisImp = iUserRedisImp;
        }

        /// <summary>
        /// 分页查询
        /// </summary>
        public async Task<(List<ErpPurchaseReqDto>, int)> GetByPageAsync(
            decimal? user_id, ErpPurchaseReqQuery query)
        {
            RefAsync<int> totalCount = 0;

            //查询
            var list = await SqlSugarHelper.DBClient(query.server_id)
                                .Queryable<ErpPurchaseReq>()
                                .Mapper(x => x.user_info, x => x.user_id)
                                .Mapper(x => x.created_info, x => x.created_id)
                                .Mapper(x =>
                                {
                                    x.details = SqlSugarHelper.DBClient(query.server_id)
                                                .Queryable<ErpPurchaseReqDetail>()
                                                .Where(y => y.main_id == x.id)
                                                .ToList();
                                    x.files = SqlSugarHelper.DBClient(query.server_id)
                                                .Queryable<ErpPurchaseReqFile>()
                                                .Where(y => y.main_id == x.id)
                                                .ToList();
                                })
                                .ToPageListAsync(query.page_index, query.page_size, totalCount);
            if (list.Count > 0)
            {
                var all = await _iErpFlowRecordImp.GetListAsync(query.server_id, user_id,
                    new FlowRecordQuery()
                    {
                        detail_ids = list.Select(x => (int)x.id).ToList()
                    });
                foreach (var item in list)
                {
                    if (item.state == 1)//审核中
                    {
                        var info = all.FirstOrDefault(x => x.detail_id == item.id);
                        if (info != null)
                        {
                            item.user_ids = info.state_child_id;
                            item.user_names = info.state_child_name;
                        }
                    }
                }
            }

            var data = _imapper.Map<List<ErpPurchaseReq>, List<ErpPurchaseReqDto>>(list);

            return (data, totalCount);
        }

        /// <summary>
        /// 提交
        /// </summary>
        public async Task<ErpPurchaseReqDto> CreateAsync(
            string server_id, ClientInformation client, PurchaseOrderFormData input)
        {
            var info = _imapper.Map<CreateErpPurchaseReq, ErpPurchaseReq>(input.form_data);
            info.id = Tools.GetEngineID(server_id);
            info.state = 1;
            info.SetCreate(client.i_id);

            //发起流程
            var flow = await _iErpFlowRecordImp.StartAsync(server_id, client.i_id, input.step_data);
            if (flow == null)
            {
                throw new Exception("发起采购申请流程失败");
            }
            await _iErpFlowRecordImp.UpdateAsync(server_id, flow.id, Convert.ToInt32(info.id),
                    PurchaseMessage.GetContent(client.c_name, info));
            info.flow_id = flow.id;
            info.flow_code = flow.code;
            info.state = 1;

            //添加采购明细
            if (info.details != null && info.details.Count > 0)
            {
                info.details.ForEach(r =>
                {
                    r.id = Tools.GetEngineID(server_id);
                    r.SetCreate(client.i_id, info.id);
                });
                await SqlSugarHelper.DBClient(server_id).Insertable(info.details).ExecuteCommandAsync();
            }

            //上传附件
            if (info.files != null && info.files.Count > 0)
            {
                info.files.ForEach(r =>
                {
                    r.id = Tools.GetEngineID(server_id);
                    r.SetCreate(client.i_id, info.id);
                });
                await SqlSugarHelper.DBClient(server_id).Insertable(info.files).ExecuteCommandAsync();
            }

            //添加申请信息
            await SqlSugarHelper.DBClient(server_id).Insertable(info).ExecuteCommandAsync();

            return _imapper.Map<ErpPurchaseReq, ErpPurchaseReqDto>(info);
        }

        /// <summary>
        /// 查看详情
        /// </summary>
        public async Task<ErpPurchaseReqDto> LookDetailAsync(
            string server_id, decimal? user_id, decimal id)
        {

            //查询
            var info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpPurchaseReq>()
                                .Where(x => x.id == id)
                                .Mapper(x => x.user_info, x => x.user_id)
                                .Mapper(x => x.created_info, x => x.created_id)
                                .Mapper(x =>
                                {
                                    x.details = SqlSugarHelper.DBClient(server_id)
                                                .Queryable<ErpPurchaseReqDetail>()
                                                .Where(y => y.main_id == x.id)
                                                .ToList();
                                    x.files = SqlSugarHelper.DBClient(server_id)
                                                .Queryable<ErpPurchaseReqFile>()
                                                .Where(y => y.main_id == x.id)
                                                .ToList();
                                })
                                .FirstAsync();

            var ids = new List<int>();

            if (info == null)
            {
                throw new Exception($"未找到采购申请信息，id={id}");
            }

            ids.Add(Convert.ToInt32(info.id));

            var all = await _iErpFlowRecordImp.GetListAsync(server_id, user_id,
                new FlowRecordQuery()
                {
                    detail_ids = ids
                });

            if (info.state == 1)//审核中
            {
                var flow_info = all.FirstOrDefault(x => x.detail_id == info.id);
                if (flow_info != null)
                {
                    info.user_ids = flow_info.state_child_id;
                    info.user_names = flow_info.state_child_name;
                }
            }
            var data = _imapper.Map<ErpPurchaseReq, ErpPurchaseReqDto>(info);

            return data;
        }

        ///// <summary>
        ///// 监听器
        ///// </summary>
        //[CapSubscribe(EventMessages.PurchaseFinish, Group = "ErpPurchaseReq")]
        //public async Task UpdateStateAsync(UpdateErpFlowRecordState input)
        //{
        //    var info = await SqlSugarHelper.DBClient("60.191.59.11")
        //                        .Queryable<ErpPurchaseReq>()
        //                        .FirstAsync(x => x.flow_id == input.flow_id);
        //    if (info != null)
        //    {

        //        Console.WriteLine("采购申请通过");

        //        if (input.state == FlowRecordState.审核通过)
        //        {
        //            info.state = 2;
        //        }
        //        else if (input.state == FlowRecordState.审核拒绝)
        //        {
        //            info.state = 3;
        //        }
        //        else if (input.state == FlowRecordState.已撤销)
        //        {
        //            info.state = 4;
        //        }

        //        await SqlSugarHelper.DBClient("60.191.59.11").Updateable(info).ExecuteCommandAsync();
        //    }
        //}
    }
}
