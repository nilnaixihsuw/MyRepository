﻿using ERPCore.Entity;
using ERPModel.EnterpriseManage.ErpPurchaseReqs;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.EnterpriseManage.ErpPurchaseReqs.Contracts
{
    public interface IErpPurchaseReqImp
    {
        /// <summary>
        /// 分页查询
        /// </summary>
        Task<(List<ErpPurchaseReqDto>, int)> GetByPageAsync(decimal? user_id, ErpPurchaseReqQuery query);

        /// <summary>
        /// 提交
        /// </summary>
        Task<ErpPurchaseReqDto> CreateAsync(string server_id, ClientInformation client, PurchaseOrderFormData input);

        /// <summary>
        /// 查看详情
        /// </summary>
        Task<ErpPurchaseReqDto> LookDetailAsync(string server_id, decimal? user_id, decimal id);
    }
}
