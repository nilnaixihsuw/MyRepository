﻿using ERPCore.ORM;
using ERPModel.ApiModel.EnterpriseManage;
using ERPModel.EnterpriseManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.EnterpriseManage
{
    public interface IErpBusMainImp : IBusinessRepository<ErpBusMain>
    {
        Task<List<BusMainDto>> GetRecord(BusMainRequest request);
    }
}