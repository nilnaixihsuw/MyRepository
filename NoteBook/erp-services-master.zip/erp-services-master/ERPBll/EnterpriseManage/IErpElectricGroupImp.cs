﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPModel.CommonModel;
using ERPModel.EnterpriseManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.EnterpriseManage
{
    public interface IErpElectricGroupImp : IBusinessRepository<ErpElectricGroup>
    {
        Task<List<ErpElectricGroup>> GetElectricTree(string server_id);
        Task<bool> AddElectricGroup(string server_id, ErpElectricGroup context, ClientInformation client);
        Task<bool> BatchDelete(string server_id, List<decimal> context);
    }
}