﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPModel.ApiModel.EnterpriseManage;
using ERPModel.EnterpriseManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.EnterpriseManage
{
    public interface IOaWageSendImp : IBusinessRepository<OaWageSend>
    {
        Task<bool> AddOaWageSend(string server_id, OaWageSend context, ClientInformation client);
        Task<Tuple<List<OaWageSend>,int>> QueryOaWageSendPageList(string server_id, OawageSendRequest request, string v);
        Task<List<OaWageSend>> QueryOaWageSendList(string server_id, OawageSendRequest request, string v);
        Task<bool> BatchDelete(string server_id, List<decimal> context);
    }
}