﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPModel.ApiModel.EnterpriseManage;
using ERPModel.EnterpriseManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.EnterpriseManage
{
    public interface IErpMeetingMainImp : IBusinessRepository<ErpMeetingMain>
    {
        Task<bool> InsertMeetingRoom(string server_id, ErpMeetingMain context, ClientInformation client);
        Task<bool> BatchDelete(string server_id, List<decimal> context);
        Task<Tuple<List<ErpMeetingMain>, int>> QueryMeetingList(string server_id, ErpMeetingMainRequest request, string v, int page_size, int page_index, string orderby);
        Task<List<ErpMeetingMain>> QueryMeetingList(string server_id, ErpMeetingMainRequest request, string v, string orderby);
        Task<List<ErpMeetingBook>> ListBookRecords(DateTime date, string server_id, ClientInformation client);
    }
}