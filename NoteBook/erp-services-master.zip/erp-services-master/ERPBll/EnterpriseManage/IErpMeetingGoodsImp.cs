﻿using ERPCore.ORM;
using ERPModel.EnterpriseManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.EnterpriseManage
{
    public interface IErpMeetingGoodsImp : IBusinessRepository<ErpMeetingGoods>
    {
    }
}