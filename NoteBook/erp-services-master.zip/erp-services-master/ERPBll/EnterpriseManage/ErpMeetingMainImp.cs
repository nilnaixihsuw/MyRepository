﻿using ERPCore.ORM;
using ERPDal.EnterpriseManage;
using ERPModel.EnterpriseManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using ERPCore.Entity;
using ERPModel.ApiModel.EnterpriseManage;
using System.Linq.Expressions;
using ERPDal.UserManage;

namespace ERPBll.EnterpriseManage
{
    public class ErpMeetingMainImp : BusinessRespository<ErpMeetingMain, IErpMeetingMainDataImp>, IErpMeetingMainImp
    {
        private readonly IErpMeetingPersonDataImp _iErpMeetingPersonDataImp;
        private readonly IErpMeetingGoodsDataImp _iErpMeetingGoodsDataImp;
        private readonly ISysPersonDataImp _iSysPersonDataImp;
        private readonly IErpMeetingRecordDataImp _iErpMeetingRecordDataImp;
        public ErpMeetingMainImp(
            IErpMeetingRecordDataImp iErpMeetingRecordDataImp,
            ISysPersonDataImp iSysPersonDataImp,
            IErpMeetingGoodsDataImp iErpMeetingGoodsDataImp,
            IErpMeetingPersonDataImp iErpMeetingPersonDataImp,
            IErpMeetingMainDataImp dataImp) : base(dataImp)
        {
            _iSysPersonDataImp = iSysPersonDataImp;
            _iErpMeetingPersonDataImp = iErpMeetingPersonDataImp;
            _iErpMeetingGoodsDataImp = iErpMeetingGoodsDataImp;
            _iErpMeetingRecordDataImp = iErpMeetingRecordDataImp;
        }

        public async Task<bool> BatchDelete(string server_id, List<decimal> context)
        {
            var list = await _dataImp.List(server_id, it => SqlFunc.ContainsArray(context, it.id));
            var dPersonList = await _iErpMeetingPersonDataImp.List(server_id, it => SqlFunc.ContainsArray(context, it.meeting_id));
            var dEquipList = await _iErpMeetingGoodsDataImp.List(server_id, it => SqlFunc.ContainsArray(context, it.meeting_id));
            var records = await _iErpMeetingRecordDataImp.List(server_id, it => SqlFunc.ContainsArray(context, it.meeting_id));
            return await _dataImp.BatchDelete(server_id, list, dPersonList, dEquipList, records);
        }

        public async Task<bool> InsertMeetingRoom(string server_id, ErpMeetingMain context, ClientInformation client)
        {
            if (context.id > 0)
            {
                //编辑
                context.update_date = DateTime.Now;
                context.update_id = client.i_id;
                var old = await Get(server_id, context.id);
                context.created_date = old.created_date;
                context.created_id = old.created_id;
                return await _dataImp.UpdateMeetingRoom(server_id, context, client);
            }
            else
            {
                //新增
                context.created_date = DateTime.Now;
                context.created_id = client.i_id;
                return await _dataImp.InsertMeetingRoom(server_id, context, client);
            }
        }

        public async Task<List<ErpMeetingBook>> ListBookRecords(DateTime date, string server_id, ClientInformation client)
        {
            var meetingIds = await _iErpMeetingPersonDataImp.List(server_id, it => it.person_id == client.i_id || it.person_id == 0);
            var list = await ExtensionList(server_id, it => SqlFunc.ContainsArray(meetingIds.Select(it => it.meeting_id).ToList(), it.id), "", "");
            var endDate = date.AddHours(23).AddMinutes(59).AddSeconds(59);
            var result = list.Select(it => new ErpMeetingBook
            {
                meeting_id = it.id,
                img_url = it.img_url,
                name = it.name,
                need_check = it.need_check,
                equips = it.ex_equipment_name,
                capacity = it.capacity,
                books = it.ex_books?.Where(c => c.begin_time >= date && c.end_time <= endDate).ToList(),
                check_person = it.ex_check_person
            }).ToList();
            return result;
        }

        public async Task<Tuple<List<ErpMeetingMain>, int>> QueryMeetingList(string server_id, ErpMeetingMainRequest request, string v, int page_size, int page_index, string orderby)
        {
            var exp = await GetExp(request);
            return await ExtensionList(server_id, request.ToExp(exp), v, page_size, page_index, orderby);
        }

        public async Task<List<ErpMeetingMain>> QueryMeetingList(string server_id, ErpMeetingMainRequest request, string v, string orderby)
        {
            var exp = await GetExp(request);
            return await ExtensionList(server_id, request.ToExp(exp), v, orderby);
        }

        private async Task<List<Expression<Func<ErpMeetingMain, bool>>>> GetExp(ErpMeetingMainRequest request)
        {
            var r = new List<Expression<Func<ErpMeetingMain, bool>>>();
            if (!string.IsNullOrEmpty(request.duty_name))
            {
                var emps = await _iSysPersonDataImp.List(request.server_id, it => it.c_name.Contains(request.duty_name));
                r.Add(it => SqlFunc.ContainsArray(emps.Select(it => it.i_id).ToList(), it.duty_person));
            }
            return r;
        }
    }
}