﻿using ERPCore.ORM;
using ERPDal.EnterpriseManage.RentManage;
using ERPModel.EnterpriseManage.RentManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;

namespace ERPBll.EnterpriseManage.RentManage
{
    public class ErpContractFileImp : BusinessRespository<ErpContractFile, IErpContractFileDataImp>, IErpContractFileImp
    {
        public ErpContractFileImp(IErpContractFileDataImp dataImp): base(dataImp)
        {

        }
    }
}