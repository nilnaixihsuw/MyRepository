﻿using ERPCore.ORM;
using ERPModel.ApiModel.EnterpriseManage.RentManage;
using ERPModel.EnterpriseManage.RentManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.EnterpriseManage.RentManage
{
    public interface IErpCustomerMainImp : IBusinessRepository<ErpCustomerMain>
    {
        Task<List<CustomerDto>> GetByPageAsync(CustomerRequest request);
    }
}