﻿using ERPCore.ORM;
using ERPModel.ApiModel.EnterpriseManage.RentManage;
using ERPModel.EnterpriseManage.RentManage;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.EnterpriseManage.RentManage
{
    public interface IErpContractMainImp : IBusinessRepository<ErpContractMain>
    {
        /// <summary>
        /// 获取合同分页数据
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        Task<Tuple<int, List<ContractDto>>> GetRecordAsync(ContractRequest request);

        /// <summary>
        /// 获取合同简要数据
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="exp"></param>
        /// <returns></returns>
        Task<List<ErpContractMain>> GetSimpleDataAsync(string server_id, Expression<Func<ErpContractMain, bool>> exp);
    }
}