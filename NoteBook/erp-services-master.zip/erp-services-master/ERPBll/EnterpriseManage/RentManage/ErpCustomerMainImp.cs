﻿using ERPCore.ORM;
using ERPDal.EnterpriseManage.RentManage;
using ERPModel.EnterpriseManage.RentManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using ERPModel.ApiModel.EnterpriseManage.RentManage;
using AutoMapper;
using ERPBll.RedisManage.Dicts;
using ERPBll.UserManage;
using ERPDal;
using ERPModel.DataBase;
using ERPModel.UserManage;

namespace ERPBll.EnterpriseManage.RentManage
{
    public class ErpCustomerMainImp : BusinessRespository<ErpCustomerMain, IErpCustomerMainDataImp>, IErpCustomerMainImp
    {
        private readonly IDictRedisManageImp _iDictRedisManageImp;
        private readonly IMapper _imapper;
        private readonly IErpContractMainImp _iErpContractMainImp;

        public ErpCustomerMainImp(IDictRedisManageImp iDictRedisManageImp, IMapper imapper,
            IErpContractMainImp iErpContractMainImp,
            IErpCustomerMainDataImp dataImp): base(dataImp)
        {
            _iDictRedisManageImp = iDictRedisManageImp;
            _imapper = imapper;
            _iErpContractMainImp = iErpContractMainImp;
        }

        public async Task<List<CustomerDto>> GetByPageAsync(CustomerRequest request)
        {
            var customers = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpCustomerMain>()
                .Where(request.ToExp())
                .Mapper(r => r.files, r => r.files.First().customer_id)
                .Mapper(r => r.persons, r => r.persons.First().custome_id)
                .OrderBy(r => r.created_date, OrderByType.Desc)
                .ToListAsync();
            
            var persons = SqlSugarHelper.DBClient(request.server_id).Queryable<SysPerson>().ToList();
            var list = _imapper.Map<List<ErpCustomerMain>, List<CustomerDto>>(customers);
            var dic = await _iDictRedisManageImp.GetAllAsync();
            list.ForEach(r =>
            {
                r.firm_name = dic.Find(m => m.i_id == r.firm_id)?.c_name;
                r.tag_name = dic.Find(m => m.i_id == r.tag_id)?.c_name;
                r.target_name = dic.Find(m => m.i_id == r.target)?.c_name;
                r.source_name = dic.Find(m => m.i_id == r.source)?.c_name;
                r.duty_name = persons.Find(m => m.i_id == r.duty_id)?.c_name;
                r.create_name = persons.Find(m => m.i_id == r.created_id)?.c_name;

                var person = r.persons.Find(m => m.type == 1);
                r.con_name = person?.name;
                r.phone = person?.phone;
            });

            ContractRequest request1 = new ContractRequest() { server_id = request.server_id, page_index = 1, page_size = 10000 };
            var (total, contracts) = await _iErpContractMainImp.GetRecordAsync(request1);
            list.ForEach(r =>
            {
                r.contracts = contracts.Where(m => m.customer_id == r.id).OrderByDescending(m => m.created_date).ToList();
                var aa = r.contracts.Where(m => m.state == 1).ToList();
                if (aa != null && aa.Count > 0)
                {
                    r.vehicle_name = string.Join(',', aa.Where(m => m.type == 1).Select(m => m.vehicle_name).Distinct());
                    r.house_name = string.Join(',', aa.Where(m => m.type == 2).Select(m => m.house_name).Distinct());
                }
            });
            return list;
        }
    }
}