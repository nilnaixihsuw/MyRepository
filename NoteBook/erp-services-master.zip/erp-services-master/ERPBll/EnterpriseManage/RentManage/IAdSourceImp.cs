﻿using ERPModel.ApiModel.EnterpriseManage.RentManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.EnterpriseManage.RentManage
{
    public interface IAdSourceImp
    {
        Task<List<AdResourceDto>> GetData(AdResourceRequest request);
    }
}
