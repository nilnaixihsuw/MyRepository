﻿using ERPDal.Repository;
using ERPModel.EnterpriseManage.RentManage;
using System;
using System.Collections.Generic;
using System.Text;

namespace ERPBll.EnterpriseManage.RentManage
{
    public interface IErpContractVehicleImp : IBaseBusiness<ErpContractVehicle>
    {

    }
}
