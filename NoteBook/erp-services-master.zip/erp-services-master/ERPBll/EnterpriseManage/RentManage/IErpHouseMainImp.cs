﻿using ERPCore.ORM;
using ERPModel.EnterpriseManage.RentManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.EnterpriseManage.RentManage
{
    public interface IErpHouseMainImp : IBusinessRepository<ErpHouseMain>
    {
    }
}