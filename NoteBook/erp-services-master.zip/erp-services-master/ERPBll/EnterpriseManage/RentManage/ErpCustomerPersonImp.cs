﻿using ERPCore.ORM;
using ERPDal.EnterpriseManage.RentManage;
using ERPModel.EnterpriseManage.RentManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;

namespace ERPBll.EnterpriseManage.RentManage
{
    public class ErpCustomerPersonImp : BusinessRespository<ErpCustomerPerson, IErpCustomerPersonDataImp>, IErpCustomerPersonImp
    {
        public ErpCustomerPersonImp(IErpCustomerPersonDataImp dataImp): base(dataImp)
        {

        }
    }
}