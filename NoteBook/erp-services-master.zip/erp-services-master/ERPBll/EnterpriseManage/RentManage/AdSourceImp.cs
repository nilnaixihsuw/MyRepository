﻿using AutoMapper;
using ERPBll.RedisManage;
using ERPBll.RedisManage.Dicts;
using ERPBll.RedisManage.Lines;
using ERPBll.RedisManage.Trees;
using ERPDal;
using ERPModel.ApiModel.EnterpriseManage.RentManage;
using ERPModel.EnterpriseManage.RentManage;
using ERPModel.SystemManage;
using ERPModel.UserManage;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.EnterpriseManage.RentManage
{
    public class AdSourceImp : IAdSourceImp
    {
        private readonly IErpContractMainImp _iErpContractMainImp;
        private readonly IErpCustomerMainImp _iErpCustomerMainImp;
        private readonly ILineRedisImp _lineRedisImp;
        private readonly IVehicleRedisManageImp _iVehicleRedisManageImp;
        private readonly IErpContractVehicleImp _iErpContractVehicleImp;
        private readonly IDictRedisManageImp _iDictRedisManageImp;
        private readonly IMapper _imapper;

        public AdSourceImp(
            ILineRedisImp lineRedisImp,
            IErpContractMainImp iErpContractMainImp,
            IErpCustomerMainImp iErpCustomerMainImp,
            IVehicleRedisManageImp iVehicleRedisManageImp,
            IDictRedisManageImp iDictRedisManageImp, 
            IMapper imapper,
            IErpContractVehicleImp iErpContractVehicleImp)
        {
            _lineRedisImp = lineRedisImp;
            _iErpContractMainImp = iErpContractMainImp;
            _iErpCustomerMainImp = iErpCustomerMainImp;
            _iVehicleRedisManageImp = iVehicleRedisManageImp;
            _iErpContractVehicleImp = iErpContractVehicleImp;
            _iDictRedisManageImp = iDictRedisManageImp;
            _imapper = imapper;
        }

        public async Task<List<AdResourceDto>> GetData(AdResourceRequest request)
        {
            var lines = await _lineRedisImp.GetLineVehAsync();
            var vehicles = await _iVehicleRedisManageImp.GetAll1Async();
            vehicles = vehicles.Where(r => r.scrap == 0 || r.scrap == null).ToList();
            if (request.vehicle_ids != null && request.vehicle_ids.Count > 0)
            {
                vehicles = vehicles.Where(r => request.vehicle_ids.Contains(r.id)).ToList();
            }
            if (request.line_id != null && request.line_id > 0)
            {
                vehicles = vehicles.Where(r => r.line_id == request.line_id).ToList();
            }
            if (request.dept_id != null && request.dept_id > 0)
            {
                var dep_persons = await SqlSugarHelper.DBClient(request.server_id).Queryable<SysDepPerson>().ToListAsync();
                var result = new List<decimal?>();
                Tools.getDeptsByID(dep_persons, new List<decimal?> { request.dept_id }, ref result);

                var dept_lines = await SqlSugarHelper.DBClient(request.server_id).Queryable<SysDepLine>()
                    .Where(r => result.Contains(Convert.ToDecimal(r.i_department_id))).ToListAsync();
                vehicles = vehicles.Where(r => (r.line_id != null && dept_lines.Select(m => m.i_line_id).ToList().Contains(r.line_id.Value)) || 
                    result.Contains(Convert.ToDecimal(r.group))).ToList();
            }

            //var exp = Expressionable.Create<ErpContractMain>()
            //    //.AndIF(request.start != null && request.end != null, r => r.end_date >= request.start && r.end_date <= request.end)
            //    .And(r => r.type == 1 ).ToExpression();
            var contracts = await _iErpContractMainImp.List(request.server_id, r => r.type == 1 && r.state == 1);

            //CustomerRequest request2 = new CustomerRequest() { server_id = request.server_id };
            //var customers = await _iErpCustomerMainImp.GetByPageAsync(request2);

            var customers = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpCustomerMain>()
               .Mapper(r => r.persons, r => r.persons.First().custome_id)
               .OrderBy(r => r.created_date, OrderByType.Desc)
               .ToListAsync();

            var persons = SqlSugarHelper.DBClient(request.server_id).Queryable<SysPerson>().ToList();
            var list1 = _imapper.Map<List<ErpCustomerMain>, List<CustomerDto>>(customers);
            var dic = await _iDictRedisManageImp.GetAllAsync();
            list1.ForEach(r =>
            {
                r.firm_name = dic.Find(m => m.i_id == r.firm_id)?.c_name;
                r.tag_name = dic.Find(m => m.i_id == r.tag_id)?.c_name;
                r.target_name = dic.Find(m => m.i_id == r.target)?.c_name;
                r.source_name = dic.Find(m => m.i_id == r.source)?.c_name;
                r.duty_name = persons.Find(m => m.i_id == r.duty_id)?.c_name;
                r.create_name = persons.Find(m => m.i_id == r.created_id)?.c_name;

                var person = r.persons.Find(m => m.type == 1);
                r.con_name = person?.name;
                r.phone = person?.phone;
            });
            var list = new List<AdResourceDto>();
            var con_vehicles = await _iErpContractVehicleImp.List(request.server_id, null);
            bool is_add = false;
            foreach (var item in vehicles)
            {
                var temp = new AdResourceDto();
                temp.line_name = lines.FirstOrDefault(r => r.lp_num == item.lp_num)?.line_name;
                temp.vehicle_id = item.id;
                temp.lp_num = item.lp_num;
                if (con_vehicles.Exists(r => r.vehicle_id == temp.vehicle_id))
                {
                    var con_vehicle = con_vehicles.Where(r => r.vehicle_id == temp.vehicle_id).ToList();
                    foreach (var item1 in con_vehicle)
                    {
                        var contract = contracts.FirstOrDefault(r => r.id == item1.contract_id);
                        if (contract == null) continue;

                        var temp1 = ERPBll.Tools.DeepCopy(temp);
                        temp1.state = 1;
                        temp1.state_name = "已投放";
                        temp1.start = contract.start_date;
                        temp1.end = contract.end_date;
                        temp1.timer_date = contract.timer_date;
                        temp1.rise_rate = contract.rise_rate;
                        temp1.fee = contract.fee;
                        if (list1.Exists(r => r.id == contract?.customer_id))
                        {
                            var customer = list1.Find(r => r.id == contract.customer_id);
                            temp1.customer_name = customer.name;
                            temp1.firm_id = customer.firm_id;
                            temp1.firm_name = customer.firm_name;
                            temp1.con_name = customer.con_name;
                            temp1.phone = customer.phone;
                            temp1.duty_id = customer.duty_id;
                            temp1.duty_name = customer.duty_name;
                        }
                        list.Add(temp1);
                        is_add = true;
                    }

                    if (!is_add)
                    {
                        temp.state = 0;
                        temp.state_name = "未投放";
                        list.Add(temp);
                    }
                }
                else
                {
                    temp.state = 0;
                    temp.state_name = "未投放";
                    list.Add(temp);
                }
                is_add = false;
            }

            return list;
        }
    }
}
