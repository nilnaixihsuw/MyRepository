﻿using ERPCore.ORM;
using ERPDal.EnterpriseManage.RentManage;
using ERPModel.EnterpriseManage.RentManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;

namespace ERPBll.EnterpriseManage.RentManage
{
    public class ErpHouseImgImp : BusinessRespository<ErpHouseImg, IErpHouseImgDataImp>, IErpHouseImgImp
    {
        public ErpHouseImgImp(IErpHouseImgDataImp dataImp): base(dataImp)
        {

        }
    }
}