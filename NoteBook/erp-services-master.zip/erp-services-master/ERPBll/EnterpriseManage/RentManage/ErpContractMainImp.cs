﻿using ERPCore.ORM;
using ERPDal.EnterpriseManage.RentManage;
using ERPModel.EnterpriseManage.RentManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using ERPModel.ApiModel.EnterpriseManage.RentManage;
using AutoMapper;
using ERPBll.UserManage;
using ERPDal;
using ERPBll.RedisManage.Dicts;
using ERPModel.UserManage;
using System.Linq.Expressions;
using ERPBll.RedisManage.Users;

namespace ERPBll.EnterpriseManage.RentManage
{
    public class ErpContractMainImp : BusinessRespository<ErpContractMain, IErpContractMainDataImp>, IErpContractMainImp
    {
        private readonly IMapper _imapper;
        private readonly IErpHouseMainImp _iErpHouseMainImp;
        private readonly IDictRedisManageImp _iDictRedisManageImp;
        private readonly IUserRedisImp _iUserRedisImp;
        public ErpContractMainImp(IMapper imapper,
            IErpHouseMainImp iErpHouseMainImp,
            IDictRedisManageImp iDictRedisManageImp,
            IUserRedisImp iUserRedisImp,
            IErpContractMainDataImp dataImp): base(dataImp)
        {
            _imapper = imapper;
            _iErpHouseMainImp = iErpHouseMainImp;
            _iDictRedisManageImp = iDictRedisManageImp;
            _iUserRedisImp = iUserRedisImp;
        }

        public async Task<Tuple<int, List<ContractDto>>> GetRecordAsync(ContractRequest request)
        {
            RefAsync<int> total = 0;
            var records = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpContractMain, ErpCustomerMain>((a, b) =>
                    new JoinQueryInfos(JoinType.Left, a.customer_id == b.id))
                .Where(request.ToExp1())
                .Mapper(a => a.created_person, a => a.created_id)
                .Mapper(a => a.files, a => a.files.First().contract_id)
                .Mapper(async a => a.customer_info = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpCustomerMain>()
                        .Where(m => m.id == a.customer_id)
                        .Mapper(m => m.files, r => r.files.First().customer_id)
                        .Mapper(m => m.persons, r => r.persons.First().custome_id).FirstAsync())
                .Mapper(a => a.fee_records, a => a.fee_records.First().main_id)
                .OrderBy(a => a.created_date, OrderByType.Desc)
                .ToPageListAsync(request.page_index, request.page_size, total);

            //var vehicles = VehicleInfo.VehicleInfoBll.GetAllCInfo2(request.server_id);
            var houses = await _iErpHouseMainImp.List(request.server_id, null);
            var contract_vehicles = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpContractVehicle>()
                .Mapper(r => r.vehicle_info, r => r.vehicle_id).ToListAsync();
            var list = _imapper.Map<List<ErpContractMain>, List<ContractDto>>(records);
            var dic = await _iDictRedisManageImp.GetAllAsync();
            var persons = await _iUserRedisImp.GetAllAsync();
            list.ForEach(r =>
            {
                //r.files = _imapper.Map<List<ErpContractFile>, List<ContractFileDto>>(records.Find(m => m.id == r.id)?.files);
                r.way_name = dic.Find(m => m.i_id == r.way)?.c_name;
                //r.state_name = dic.FirstOrDefault(m => m.i_id == r.state)?.c_name;

                var customer = records.Find(m => m.customer_id == r.customer_id).customer_info;
                r.customer_name = customer?.name;
                r.customer_person = customer?.persons?.Find(m => m.type == 1)?.name;
                r.customer_phone = customer?.persons?.Find(m => m.type == 1)?.phone;

                if (r.type == 1)
                {
                    //r.vehicle_name = vehicles.Find(m => m.id == r.object_id)?.lp_num;
                    r.vehicle_name = string.Join(',', contract_vehicles.Where(m => m.contract_id == r.id).Select(m => m.vehicle_info?.lp_num));
                    r.vehicles = contract_vehicles.Where(m => m.contract_id == r.id).ToList();
                    r.type_name = "广告合同";
                }
                if (r.type == 2)
                {
                    r.house_name = houses.Find(m => m.id == r.object_id)?.name;
                    r.type_name = "租房合同";
                }
                switch (r.state)
                {
                    case 1:
                        r.state_name = "有效合同";
                        break;
                    case 2:
                        r.state_name = "无效合同";
                        break;
                    case 3:
                        r.state_name = "撤销合同";
                        break;
                    case 4:
                        r.state_name = "待定合同";
                        break;
                }
                if (r.fee_records != null && r.fee_records.Count > 0)
                {
                    r.fee_records.ForEach(m =>
                    {
                        //m.user_name = persons.Find(n => n.i_id == m.user_id)?.c_name;
                        m.created_name = persons.Find(n => n.i_id == m.created_id)?.c_name;
                    });
                }
            });
            //if (!string.IsNullOrEmpty(request.customer_name))
            //{
            //    list = list.Where(r => r.customer_name.Contains(request.customer_name)).ToList();
            //}
            return new Tuple<int, List<ContractDto>>(total, list);
        }

        public async Task<List<ErpContractMain>> GetSimpleDataAsync(string server_id, Expression<Func<ErpContractMain, bool>> exp)
        {
            var records = await SqlSugarHelper.DBClient(server_id).Queryable<ErpContractMain>()
                   .Where(exp)
                   .Mapper(a => a.created_person, a => a.created_id)
                   .Mapper(a => a.files, a => a.files.First().contract_id)
                   .Mapper(async a => a.customer_info = await SqlSugarHelper.DBClient(server_id).Queryable<ErpCustomerMain>()
                           .Where(m => m.id == a.customer_id)
                           .Mapper(m => m.files, r => r.files.First().customer_id)
                           .Mapper(m => m.persons, r => r.persons.First().custome_id).FirstAsync())
                   .ToListAsync();

            return records;
        }
    }
}