﻿using AutoMapper;
using ERPBll.FlowManage.Contracts;
using ERPBll.RedisManage.Users;
using ERPBll.WorkPlace;
using ERPCore.Entity;
using ERPDal;
using ERPModel.EnterpriseManage;
using ERPModel.EnterpriseManage.BusRequest;
using ERPModel.FlowManage;
using ERPModel.FlowManage.FlowRecords;
using ERPModel.FlowManage.FlowSteps;
using ERPModel.Workplace;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.EnterpriseManage.BusRequest
{
    public class BusRequestImp : IBusRequestImp
    {
        private readonly IMapper _imapper;
        private readonly IErpBusMainImp _iErpBusMainImp;
        private readonly IErpBusRecordImp _iErpBusRecordImp;
        private readonly IErpFlowRecordImp _erpFlowRecordImp;
        private readonly IUserRedisImp _userRedisImp;
        private readonly IErpMessageMainImp _erpMessageMainImp;

        public BusRequestImp(
            IErpBusMainImp iErpBusMainImp,
            IErpBusRecordImp iErpBusRecordImp,
            IErpFlowRecordImp erpFlowRecordImp,
            IUserRedisImp userRedisImp,
            IErpMessageMainImp erpMessageMainImp,
            IMapper imapper)
        {
            _iErpBusMainImp = iErpBusMainImp;
            _iErpBusRecordImp = iErpBusRecordImp;
            _erpFlowRecordImp = erpFlowRecordImp;
            _imapper = imapper;
            _userRedisImp = userRedisImp;
            _erpMessageMainImp = erpMessageMainImp;
        }

        /// <summary>
        /// 根据公车id获取预约记录
        /// </summary>
        public async Task<List<BusRequestQueueDto>> GetByBusId(decimal? bus_id, string server_id = "60.191.59.11")
        {
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpBusRequestQueue>()
                                .Where(x => x.state == 1 && x.bus_id == bus_id)
                                .Mapper(x => x.user_info, x => x.user_id)
                                .OrderBy(x => x.req_time)
                                .ToListAsync();

            return _imapper.Map<List<ErpBusRequestQueue>, List<BusRequestQueueDto>>(list);
        }

        /// <summary>
        /// 查看详情
        /// </summary>
        public async Task<BusRequestQueueDto> GetDetail(decimal? id, string server_id = "60.191.59.11")
        {
            var info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpBusRequestQueue>()
                                .Where(x => x.id == id)
                                .Mapper(x => x.user_info, x => x.user_id)
                                .FirstAsync();

            return _imapper.Map<ErpBusRequestQueue, BusRequestQueueDto>(info);
        }

        /// <summary>
        /// 新增
        /// </summary>
        public async Task<BusRequestQueueDto> Create(CreateOrUpdateBusRequestQueue input, decimal? user_id, string server_id = "60.191.59.11")
        {
            if (input.req_time < DateTime.Now.AddHours(1))
            {
                throw new Exception($"预约开始时间要在1小时之后");
            }
            if (input.req_time >= input.back_time)
            {
                throw new Exception($"预约还车时间必须大于预约时间");
            }

            var request_list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpBusRequestQueue>()
                                .Where(x => x.state < 3 &&
                                    x.bus_id == input.bus_id &&
                                    ((x.req_time < input.req_time && x.back_time > input.req_time) ||
                                    (x.req_time < input.back_time && x.back_time > input.back_time) ||
                                    (x.req_time >= input.req_time && x.back_time <= input.back_time) ||
                                    (x.req_time <= input.req_time && x.back_time >= input.back_time)))
                                .ToListAsync();

            var record_list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpBusRecord>()
                                .Where(x => x.state == 1 &&
                                    x.bus_id == input.bus_id &&
                                    ((x.borrow_time < input.req_time && x.expect_back_time > input.req_time) ||
                                    (x.borrow_time < input.back_time && x.expect_back_time > input.back_time) ||
                                    (x.borrow_time >= input.req_time && x.expect_back_time <= input.back_time) ||
                                    (x.borrow_time <= input.req_time && x.expect_back_time >= input.back_time)))
                                .ToListAsync();

            if ((request_list != null && request_list.Count > 0) || (record_list != null && record_list.Count > 0))
            {
                //var users = await _userRedisImp.GetAllAsync();
                //var err_msg = "";
                //if (record_list != null && record_list.Count > 0)
                //{
                //    record_list.ForEach(x => {
                //        var borrow_name = users.Where(y => y.i_id == x.borrow_id).FirstOrDefault()?.c_name;
                //        err_msg += $"{x.borrow_time.Value.ToString("yyyy-MM-dd HH:mm:ss")}-{x.expect_back_time.Value.ToString("yyyy-MM-dd HH:mm:ss")}已被{borrow_name}借用 ";
                //    });
                //}
                //if (request_list != null && request_list.Count > 0)
                //{
                //    request_list.ForEach(x => {
                //        var req_name = users.Where(y => y.i_id == x.user_id).FirstOrDefault()?.c_name;
                //        err_msg += $"{x.req_time.Value.ToString("yyyy-MM-dd HH:mm:ss")}-{x.back_time.Value.ToString("yyyy-MM-dd HH:mm:ss")}已被{req_name}预订 ";
                //    });
                //}
                //throw new Exception($"{err_msg}");

                throw new Exception($"时间冲突，请查看预约记录或预计还车时间");
            }

            var info = _imapper.Map<CreateOrUpdateBusRequestQueue, ErpBusRequestQueue>(input);
            info.id = Tools.GetSeqCommonID(server_id);
            info.state = 1;
            info.SetCreate(user_id);
            var res = await SqlSugarHelper.DBClient(server_id).Insertable(info).ExecuteCommandAsync() > 0;
            if (res)
            {
                return _imapper.Map<ErpBusRequestQueue, BusRequestQueueDto>(info);
            }
            return null;
        }

        /// <summary>
        /// 取消
        /// </summary>
        public async Task<bool> Cancel(decimal id, decimal? user_id, string server_id = "60.191.59.11")
        {
            var info = await SqlSugarHelper.DBClient(server_id)
                       .Queryable<ErpBusRequestQueue>()
                       .FirstAsync(x => x.id == id);
            if (info == null)
            {
                throw new Exception($"未找到公车预约记录，id={id}");
            }
            if (info.state == 2)
            {
                throw new Exception($"已提交无法取消，id={id}");
            }

            info.state = 4;
            info.SetUpdate(user_id);
            return await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync() > 0;
        }

        /// <summary>
        /// 定时自动处理预约记录
        /// </summary>
        public async Task AutoOperate(string server_id = "60.191.59.11")
        {
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpBusRequestQueue>()
                                .Where(x => x.req_time <= DateTime.Now && x.state == 1)
                                .ToListAsync();

            foreach (var item in list)
            {
                if (item.back_time < DateTime.Now)
                {
                    item.state = 3;
                    item.update_date = DateTime.Now;
                    await SqlSugarHelper.DBClient(server_id).Updateable(item).ExecuteCommandAsync();

                    var name = await _userRedisImp.GetNameByIdAsync(((int)item.user_id).ToString());
                    //添加未读消息
                    ErpMessageMain context = new ErpMessageMain()
                    {
                        title = $"{name}在{DateTime.Now.ToString("yyyy-MM-dd HH:mm")}提交的借车预约已预约过期，请及时查看！",
                        type = 1,
                        model = (int)MessageModelDic.公车预约,
                        object_id = item.id.ToString(),
                        state = 1,
                        created_id = item.user_id,
                        warn = 1
                    };
                    await _erpMessageMainImp.AddErpMessageMain(server_id, context, new ClientInformation() { i_id = 0 }, null);

                    continue;
                }

                var bus_info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpBusMain>()
                                .Where(x => x.id == item.bus_id)
                                .FirstAsync();

                if (bus_info != null && bus_info.state == 0)
                {
                    var bus_record = new ErpBusRecord()
                    {
                        id = Tools.GetSeqCommonID(server_id),
                        bus_id = Convert.ToDecimal(item.bus_id),
                        borrow_id = item.user_id,
                        borrow_time = DateTime.Now,
                        expect_back_time = item.back_time,
                        purpose = item.purpose,
                        from_address = item.from_address,
                        to_address = item.to_address,
                        state = 1,
                        created_date = DateTime.Now,
                        created_id = item.user_id
                    };

                    //借车人姓名
                    var name = await _userRedisImp.GetNameByIdAsync(((int)bus_record.borrow_id).ToString());

                    if (bus_info.is_audit == 1)
                    {
                        bus_record.state_child = 1;

                        //发起审核
                        var flowRecord = await _erpFlowRecordImp.AddAsync(server_id, bus_record.borrow_id,
                            new CreateErpFlowRecord
                            {
                                detail_id = (int)bus_record.id,
                                title = BusBorrowMessage.GetTitle(name),
                                content = BusBorrowMessage.GetContent(name, bus_info.name, bus_info.code, bus_record),
                                type = 2,
                                object_id = (int)FlowRecordType.公车申请,
                                user_id = bus_record.borrow_id,
                                flow_steps = new List<CreateErpFlowStep>()
                                {
                                new CreateErpFlowStep()
                                {
                                    user_ids = new List<decimal> { bus_info.audit_person.Value },
                                }
                                }
                            });

                        if (flowRecord == null)
                        {
                            continue;
                        }
                        bus_record.borrow_flow_id = flowRecord.id;
                        bus_record.borrow_flow_code = flowRecord.code;
                        bus_info.state = 1;
                        await _erpFlowRecordImp.UpdateAsync(server_id, flowRecord.id, (int)bus_record.id, "");

                        //添加未读消息
                        ErpMessageMain context = new ErpMessageMain()
                        {
                            title = $"{name}在{DateTime.Now.ToString("yyyy-MM-dd HH:mm")}提交了借车审批单，请及时处理！",
                            type = 1,
                            model = (int)MessageModelDic.公车申请,
                            object_id = bus_record.id.ToString(),
                            state = 1,
                            created_id = bus_info.audit_person,
                            warn = 1
                        };
                        await _erpMessageMainImp.AddErpMessageMain(server_id, context, new ClientInformation() { i_id = bus_record.borrow_id }, null);
                    }
                    else
                    {
                        bus_record.state_child = 2;
                        bus_info.state = 1;
                    }
                    //新增使用记录
                    await _iErpBusRecordImp.Insert(server_id, bus_record);
                    //更改公车状态
                    await _iErpBusMainImp.Update(server_id, bus_info);

                    //添加预约成功消息
                    ErpMessageMain context1 = new ErpMessageMain()
                    {
                        title = $"{name}在{DateTime.Now.ToString("yyyy-MM-dd HH:mm")}提交的借车预约已预约成功，请及时查看！",
                        type = 1,
                        model = (int)MessageModelDic.公车预约,
                        object_id = bus_record.id.ToString(),
                        state = 1,
                        created_id = bus_record.borrow_id,
                        warn = 1
                    };
                    await _erpMessageMainImp.AddErpMessageMain(server_id, context1, new ClientInformation() { i_id = 0 }, null);

                    item.state = 2;
                    item.record_id = bus_record.id;
                    item.update_date = DateTime.Now;

                    //更新预约记录
                    await SqlSugarHelper.DBClient(server_id).Updateable(item).ExecuteCommandAsync();
                }
            }
        }
    }
}
