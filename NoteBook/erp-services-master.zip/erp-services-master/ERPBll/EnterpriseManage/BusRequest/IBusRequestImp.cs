﻿using ERPModel.EnterpriseManage.BusRequest;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.EnterpriseManage.BusRequest
{
    public interface IBusRequestImp
    {
        /// <summary>
        /// 根据公车id获取预约记录
        /// </summary>
        Task<List<BusRequestQueueDto>> GetByBusId(decimal? bus_id, string server_id = "60.191.59.11");

        /// <summary>
        /// 查看详情
        /// </summary>
        Task<BusRequestQueueDto> GetDetail(decimal? id, string server_id = "60.191.59.11");

        /// <summary>
        /// 新增预约记录
        /// </summary>
        Task<BusRequestQueueDto> Create(CreateOrUpdateBusRequestQueue input, decimal? user_id, string server_id = "60.191.59.11");

        /// <summary>
        /// 取消预约
        /// </summary>
        Task<bool> Cancel(decimal id, decimal? user_id, string server_id = "60.191.59.11");

        /// <summary>
        /// 定时自动处理预约记录
        /// </summary>
        Task AutoOperate(string server_id = "60.191.59.11");
    }
}
