﻿using ERPCore.ORM;
using ERPDal.MileManage;
using ERPModel.ApiModel;
using ERPModel.MileManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ERPBll.MileManage
{
    public class MaintOdometerDetailImp : BusinessRespository<MaintOdometerDetail, IMaintOdometerDetailDataImp>, IBusinessRepository<MaintOdometerDetail>, IMaintOdometerDetailImp
    {
        private readonly IMaintOdometerDetailDataImp _dataImp;

        public MaintOdometerDetailImp(IMaintOdometerDetailDataImp dataImp) : base(dataImp)
        {
            _dataImp = dataImp;
        }

    }
}