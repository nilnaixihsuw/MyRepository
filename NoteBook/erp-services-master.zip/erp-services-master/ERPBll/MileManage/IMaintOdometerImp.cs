﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPModel.ApiModel;
using ERPModel.MileManage;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.MileManage
{
    public interface IMaintOdometerImp : IBusinessRepository<MaintOdometer>
    {
        Task<bool> Delete(string serverId, List<int> keys);
        Task<bool> AdditionMile(string server_id, AdditionRecord context, IClientInformation client);
        Task<bool> Import(string server_id, decimal? user_id, IFormFile file);

        /// <summary>
        /// 获取gps里程
        /// </summary>
        Task<List<GpsMileRepose>> GetGpsMile(string server_id, List<string> vehicle_names);

        /// <summary>
        /// 录入gps里程
        /// </summary>
        Task AddGpsMile(string server_id, DateTime date);

        /// <summary>
        /// 根据日期删除车辆里程
        /// </summary>
        Task<bool> DeleteByDateAsync(string serverId, DateTime date);
    }
}