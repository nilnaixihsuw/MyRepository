﻿using ERPCore.ORM;
using ERPModel.ApiModel;
using ERPModel.MileManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.MileManage
{
    public interface IMaintOdometerDetailImp : IBusinessRepository<MaintOdometerDetail>
    {
        
    }
}