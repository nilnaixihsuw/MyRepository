﻿using AutoMapper;
using ERPBll.RedisManage;
using ERPCore;
using ERPCore.Entity;
using ERPCore.Extensions;
using ERPCore.Helpers;
using ERPCore.ORM;
using ERPDal.MileManage;
using ERPModel.ApiModel;
using ERPModel.MileManage;
using Microsoft.AspNetCore.Http;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace ERPBll.MileManage
{
    public class MaintOdometerImp : BusinessRespository<MaintOdometer, IMaintOdometerDataImp>, IBusinessRepository<MaintOdometer>, IMaintOdometerImp
    {
        private readonly IMapper _imapper;
        private readonly IMaintOdometerDataImp _dataImp;
        private readonly IMaintOdometerDetailDataImp _dataDetailImp;
        private readonly IMaintOdometerDetailDataImp _iMAINT_ODOMETER_DETAIL_DataImp;
        private readonly IVehicleRedisManageImp _vehicleRedisManageImp;

        public MaintOdometerImp(
            IMapper imapper,
            IMaintOdometerDataImp dataImp,
            IMaintOdometerDetailDataImp iMAINT_ODOMETER_DETAIL_DataImp,
            IVehicleRedisManageImp vehicleRedisManageImp,
            IMaintOdometerDetailDataImp dataDetailImp) : base(dataImp)
        {
            _imapper = imapper;
            _dataImp = dataImp;
            _iMAINT_ODOMETER_DETAIL_DataImp = iMAINT_ODOMETER_DETAIL_DataImp;
            _vehicleRedisManageImp = vehicleRedisManageImp;
            _dataDetailImp = dataDetailImp;
        }

        public async Task<bool> AdditionMile(string server_id, AdditionRecord context, IClientInformation client)
        {
            if (context.id != null && context.id > 0)
            {
                //编辑
                return await _dataImp.EditMile(server_id, context, client);
            }
            else
            {
                //添加里程
                return await _dataImp.AdditionMile(server_id, context, client);
            }
        }

        public async Task<bool> Delete(string serverId, List<int> keys)
        {
            var list = await _dataImp.List(serverId, it => SqlFunc.ContainsArray(keys, it.id));
            return await _dataImp.Deletetable(serverId, list);
        }

        public async Task<bool> Import(string server_id, decimal? user_id, IFormFile file)
        {
            var title = new Dictionary<string, string>()
            {
               { "车牌号","vehicle_code"},
               { "日期", "date"},
               { "里程(km)", "mile"}
            };
            var result = new byte[] { };
            //文件内容是否为空
            if (file.Length == 0)
                throw new Exception("文件不能为空");

            //文件后缀
            string filename = file.FileName;
            var ext = filename.Substring(filename.LastIndexOf("."), filename.Length - filename.LastIndexOf("."));

            // 判断后缀
            if (ext != ".xlsx" && ext != ".xls")
            {
                throw new Exception("请上传Excel文件！");
            }

            using (var ms = new MemoryStream())
            {
                file.CopyTo(ms);
                ms.Position = 0;
                result = ms.ToArray();
            }
            var dt = ExcelImportHelper.ReadBytesToDataTable(result, title);
            var list = dt.ToDataList<ImportMileDetail>();
            
            //检查车牌号是否为空
            if (list.Exists(it => string.IsNullOrEmpty(it.vehicle_code)))
            {
                var row = list.FindIndex(it => string.IsNullOrEmpty(it.vehicle_code));
                throw new Exception($"第{row + 2}行车牌号为空！");
            }
            if (list.Exists(it => !it.date.HasValue))
            {
                var row = list.FindIndex(it => !it.date.HasValue);
                throw new Exception($"第{row + 2}行日期为空！");
            }
            return await _dataImp.BatchAddMile(server_id,user_id,  list);
        }

        public async Task<List<GpsMileRepose>> GetGpsMile(string server_id, List<string> vehicle_names)
        {
            QueryGpsMile query = new QueryGpsMile
            {
                begin_date = DateTime.Now.AddDays(-10).ToString("yyyy-MM-dd"),
                end_date = DateTime.Now.AddDays(1).ToString("yyyy-MM-dd"),
                vehicle_name_list = vehicle_names
            };
            return await _dataImp.GetGpsMile(query, server_id);
        }

        public async Task AddGpsMile(string server_id, DateTime date)
        {
            await DeleteByDateAsync(server_id, date);

            //从缓存中获取所有车辆信息
            var list = await _vehicleRedisManageImp.GetAllAsync();
            var vehicle_name_list = list.Select(x => x.c_lincense_plate_number).ToList();

            ListHelper.ListSplit(20, vehicle_name_list, split =>
            {
                Task.Run(async () =>
                {
                    QueryGpsMile query = new QueryGpsMile
                    {
                        begin_date = date.ToString("yyyy-MM-dd"),
                        end_date = date.AddDays(1).ToString("yyyy-MM-dd"),
                        vehicle_name_list = split
                    };

                    //获取车辆里程
                    var vehGpsMiles = await _dataImp.GetGpsMile(query, server_id);

                    if (vehGpsMiles != null)
                    {
                        vehGpsMiles.ForEach(async item =>
                        {
                            item.id = ERPBll.Tools.GetEngineID(server_id);
                            item.vehicle_id = list.FirstOrDefault(x => x.c_lincense_plate_number == item.vehicle_name)?.i_id;
                            item.date = date.Date;
                            item.create_id = 0;
                            item.create_date = DateTime.Now;
                        });
                    }
                    var maintOdometerDetail = _imapper.Map<List<GpsMileRepose>, List<MaintOdometerDetail>>(vehGpsMiles);

                    await _dataImp.InsertManyAsync(server_id, maintOdometerDetail);
                });
                return split;
            });
        }

        public async Task<bool> DeleteByDateAsync(string serverId, DateTime date)
        {
            var list = await _dataDetailImp.List(serverId, it => it.date.Value.Date == date.Date);
            return await _dataDetailImp.Deletetable(serverId, list);
        }
    }
}