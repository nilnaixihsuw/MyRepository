﻿using AutoMapper;
using ERPBll.FlowManage.Contracts;
using ERPBll.RedisManage;
using ERPBll.RedisManage.Users;
using ERPCore.Enums;
using ERPDal;
using ERPModel.FlowManage;
using ERPModel.FlowManage.FlowRecords;
using ERPModel.Oamanage.SysVehicleChecks;
using ERPModel.SystemManage;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Yitter.IdGenerator;

namespace ERPBll.OAManage
{
    public class SysVehicleCheckImp: ISysVehicleCheckImp
    {

        private readonly IMapper _imapper;
        private readonly IErpFlowRecordImp _erpFlowRecordImp;
        private readonly IUserRedisImp _userRedisImp;
        private readonly IVehicleRedisManageImp _vehicleRedisManageImp;

        public SysVehicleCheckImp(
            IMapper imapper,
            IErpFlowRecordImp erpFlowRecordImp,
            IUserRedisImp userRedisImp,
            IVehicleRedisManageImp vehicleRedisManageImp)
        {
            _imapper = imapper;
            _erpFlowRecordImp = erpFlowRecordImp;
            _userRedisImp = userRedisImp;
            _vehicleRedisManageImp = vehicleRedisManageImp;
        }

        public async Task<SysVehicleCheckDto> GetById(string server_id, decimal? user_id, int id)
        {
            var query = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<SysVehicleCheck>()
                                .Mapper(x => x.vehicle_info, x => x.vehicle_id)
                                .Mapper(x => x.driver_info, x => x.driver_id)
                                .Mapper(x => {
                                    x.file_list = SqlSugarHelper.DBClient(server_id)
                                                    .Queryable<SysFileRecord>()
                                                    .Where(y => y.object_id == x.id)
                                                    .ToList();
                                    if (x.file_list.Count > 0)
                                    {
                                        x.files = x.file_list.Select(y => y.url).ToList();
                                    }
                                })
                                .FirstAsync(x => x.id == id);
            if (query == null || query.id < 1)
            {
                throw new Exception("未找到车辆例检记录，id=" + id);
            }
            query.create_info = await _userRedisImp.GetByIdAsync(query.created_id.ToString());
            query.person_info = await _userRedisImp.GetByIdAsync(query.user_id.ToString());
            if (query.state == 1)//审核中
            {
                var all = await _erpFlowRecordImp.GetListAsync(server_id, user_id,
                  new FlowRecordQuery()
                  {
                      detail_ids = new List<int>() { query.id }
                  });

                var info = all.FirstOrDefault(x => x.detail_id == query.id);
                if (info != null)
                {
                    query.user_ids = info.state_child_id;
                    query.user_names = info.state_child_name;
                }
            }

            return _imapper.Map<SysVehicleCheck, SysVehicleCheckDto>(query);
        }

        public async Task<SysVehicleCheckDto> AddAsync(string server_id, decimal? user_id, SysVehicleCheckFormData input, SqlSugarClient db)
        {
            if (input.step_data == null || input.step_data.Count < 1)
            {
                throw new Exception("审批流程数据为空");
            }
            input.step_data.Where(x => x.oper_type == 1).ToList().ForEach(x =>
            {
                if (x.users.Count < 1)
                {
                    throw new Exception("审批节点人员不能为空");
                }
                if (x.users.Count > 15)
                {
                    throw new Exception("审批节点人员最多15人");
                }
            });

            var info = _imapper.Map<CreateSysVehicleCheck, SysVehicleCheck>(input.form_data);
            info.id = ERPBll.Tools.GetEngineID(server_id);
            info.created_id = user_id;
            info.created_date = DateTime.Now;

            //发起流程
            var flow = await _erpFlowRecordImp.StartAsync(server_id, user_id, input.step_data, db);
            if (flow == null)
            {
                throw new Exception("发起车辆例检流程失败");
            }

            string user_name = await _userRedisImp.GetNameByIdAsync(info.user_id.ToString());
            string vehicle_name = (await _vehicleRedisManageImp.GetAllAsync())
                                    .FirstOrDefault(x => x.i_id == info.vehicle_id)?.c_lincense_plate_number;
            await _erpFlowRecordImp.UpdateAsync(server_id, flow.id, info.id,
                    SysVehicleCheckMessage.GetContent(user_name, info.check_date, vehicle_name), "", db);
            info.flow_id = flow.id;
            info.flow_code = flow.code;
            info.state = 1;

            var file_list = new List<SysFileRecord>();
            if (input.form_data.files != null && input.form_data.files.Count > 0)
            {
                input.form_data.files.ForEach(x => {
                    var file = new SysFileRecord()
                    {
                        model = (int)FileRecordType.VEHICLECHECK,
                        object_id = info.id,
                        type = 1,
                        url = x,
                        created_id = user_id,
                        created_date = DateTime.Now
                    };
                    file_list.Add(file);
                });

                await db.Insertable(file_list).ExecuteCommandAsync();
            }

            await db.Insertable(info).ExecuteCommandAsync();
          
            return _imapper.Map<SysVehicleCheck, SysVehicleCheckDto>(info);
        }
    }
}
