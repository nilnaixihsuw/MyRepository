﻿using ERPDal.Repository;
using ERPModel.Oamanage.OaKqbcs;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.OAManage
{
    public interface IOaKqzImp : IBaseBusiness<OaKqz>
    {
        /// <summary>
        /// 分页获取考勤组
        /// </summary>
        Task<(List<OaKqzDto>, int)> GetByPageAsync(string server_id, OaKqzQuery input);

        /// <summary>
        /// 根据用户id获取考勤规则
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="user_id"></param>
        /// <returns></returns>
        Task<OaKqzDto> GetByIdAsync(string server_id, int user_id);

        /// <summary>
        /// 根据用户id获取考勤班次列表
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="user_id"></param>
        /// <returns></returns>
        Task<List<OaKqbcChildDto>> GetKqbcAsync(string server_id, int user_id, DateTime dt);

        /// <summary>
        /// 获取默认考勤组
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="dt"></param>
        /// <returns></returns>
        Task<List<OaKqbcChildDto>> GetDefaultKqbcAsync(string server_id, DateTime dt);
        Task<List<OaKqbcChildDto>> GetUserDayKqbcAsync(string server_id, int user_id, DateTime dt, SqlSugarClient db = null);
        /// <summary>
        /// 根据用户id获取当日考勤班次id
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="user_id"></param>
        /// <returns></returns>
        Task<(int,long)> GetDayKqbcAsync(string server_id, int user_id, DateTime dt, SqlSugarClient db = null);

        /// <summary>
        /// 更新默认考勤组
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="id"></param>
        /// <returns></returns>
        Task UpdateDefault(string server_id, long id);

        /// <summary>
        /// 新增考勤组
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        Task<bool> AddKqzAsync(string server_id, int user_id, CreateOaKqz input, SqlSugarClient db = null);
        /// <summary>
        /// 编辑考勤组
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>

        Task<bool> EditKqzAsync(string server_id, int user_id, CreateOaKqz input, SqlSugarClient db = null);

        /// <summary>
        /// 删除考勤组
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        Task DelAsync(string server_id, long id, SqlSugarClient db = null);
    }
}
