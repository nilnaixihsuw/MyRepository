﻿using ERPModel.Oamanage.OaLeaveRules;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.OAManage
{
    public interface IOaLeaveRuleImp
    {
        /// <summary>
        /// 分页获取
        /// </summary>
        Task<(List<OaLeaveRuleDto>, int)> GetByPageAsync(string server_id, OaLeaveRuleQuery input);

        /// <summary>
        /// 获取用户符合的假期规则
        /// </summary>
        Task<OaLeaveRuleDto> GetByUserAsync(string server_id, decimal user_id);

        /// <summary>
        /// 新增
        /// </summary>
        Task AddAsync(string server_id, decimal user_id, CreateOaLeaveRule input);

        /// <summary>
        /// 更新
        /// </summary>
        Task UpdateAsync(string server_id, decimal user_id, CreateOaLeaveRule input);

        /// <summary>
        /// 更新状态
        /// </summary>
        Task UpdateStateAsync(string server_id, decimal user_id, UpdateStateLeaveRule input);

        /// <summary>
        /// 删除假期规则
        /// </summary>
        Task DelAsync(string server_id, long id);
    }
}
