﻿using AutoMapper;
using ERPDal;
using ERPModel.Oamanage.OaLeaveRules;
using ERPModel.UserManage;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Yitter.IdGenerator;

namespace ERPBll.OAManage
{
    public class OaLeaveRuleImp: IOaLeaveRuleImp
    {
        private readonly IMapper _imapper;

        public OaLeaveRuleImp(
             IMapper imapper)
        {
            _imapper = imapper;
        }

        public async Task<(List<OaLeaveRuleDto>, int)> GetByPageAsync(string server_id, OaLeaveRuleQuery input)
        {
            RefAsync<int> totalCount = 0;

            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<OaLeaveRule>()
                                .Includes(x => x.childs)
                                .OrderBy(x=>x.id,OrderByType.Asc)
                                .ToPageListAsync(input.page_index, input.page_size, totalCount);

            var data = _imapper.Map<List<OaLeaveRule>, List<OaLeaveRuleDto>>(list);
            return (data, totalCount);
        }

        public async Task<OaLeaveRuleDto> GetByUserAsync(string server_id, decimal user_id)
        {
            using (var db = SqlSugarHelper.DBClient(server_id))
            {
                var groups = await db.Queryable<SysDepPerson>().ToParentListAsync(x => x.i_group_id, user_id);
                if (groups == null || groups.Count < 1)
                {
                    return null;
                }

                var deptids = groups.Select(x => x.i_group_id).ToList();
                var data = await db.Queryable<OaLeaveRule>()
                    .Includes(x => x.childs)
                     .Where(x => x.type == 5 && x.state == 1)
                    .FirstAsync(x => deptids.Contains(x.dept_id));

                return _imapper.Map<OaLeaveRule, OaLeaveRuleDto>(data);
            }
        }

        public async Task AddAsync(string server_id, decimal user_id, CreateOaLeaveRule input)
        {
            using (var db = SqlSugarHelper.DBClient(server_id))
            {
                var query = await db.Queryable<OaLeaveRule>().CountAsync(x => x.dept_id == input.dept_id && x.type == input.type && x.state == 1);
                if(query > 0)
                {
                    throw new Exception("当前部门已有该类型假期规则");
                }

                var info = _imapper.Map<CreateOaLeaveRule, OaLeaveRule>(input);
                info.id = YitIdHelper.NextId();
                info.SetCreate(user_id);

                var childs = _imapper.Map<List<CreateOaLeaveRuleChild>, List<OaLeaveRuleChild>>(input.childs);
                childs.ForEach(child =>
                {
                    child.id = YitIdHelper.NextId();
                    child.rule_id = info.id;
                    child.created_id = user_id;
                    child.created_date = DateTime.Now;
                });

                await db.Insertable(childs).ExecuteCommandAsync();
                await db.Insertable(info).ExecuteCommandAsync();
            }
        }

        public async Task UpdateAsync(string server_id, decimal user_id, CreateOaLeaveRule input)
        {
            using (var db = SqlSugarHelper.DBClient(server_id))
            {
                var info = await db.Queryable<OaLeaveRule>().FirstAsync(x => x.id == input.id);
                if (info == null)
                {
                    throw new Exception($"未找到记录");
                }
                if (input.state==0)
                {
                    input.state = info.state;
                }
                _imapper.Map<CreateOaLeaveRule, OaLeaveRule>(input, info);
                info.SetUpdate(user_id);
                var childs = _imapper.Map<List<CreateOaLeaveRuleChild>, List<OaLeaveRuleChild>>(input.childs);
                for (int i = 0; i < childs.Count-1; i++)
                {
                    if (i + 2 == childs.Count && childs[i].end == childs[i+1].start)
                    {

                    }
                    else if (i == 0 && childs[i].end == childs[i+1].start)
                    {

                    }
                    else if (i!=0&&i+2!=childs.Count&&childs[i].start < childs[i].end)
                    {

                    }
                    else
                    {
                        throw new Exception($"司龄配额区间重复或跳跃，请检查");
                    }
                }
                childs.ForEach(child =>
                {
                    child.id = YitIdHelper.NextId();
                    child.rule_id = info.id;
                    child.created_id = user_id;
                    child.created_date = DateTime.Now;
                });
                await db.Deleteable<OaLeaveRuleChild>().Where(x => x.rule_id == input.id).ExecuteCommandAsync();
                await db.Insertable(childs).ExecuteCommandAsync();
                await db.Updateable(info).ExecuteCommandAsync();
            }
        }

        public async Task UpdateStateAsync(string server_id, decimal user_id, UpdateStateLeaveRule input)
        {
            using (var db = SqlSugarHelper.DBClient(server_id))
            {
                var info = await db.Queryable<OaLeaveRule>().FirstAsync(x => x.id == input.id);
                if (info == null)
                {
                    throw new Exception($"未找到记录");
                }
                info.state = input.state;
                info.SetUpdate(user_id);

                await db.Updateable(info).UpdateColumns(x => x.state).ExecuteCommandAsync();
            }
        }

        public async Task DelAsync(string server_id, long id)
        {
            using (var db = SqlSugarHelper.DBClient(server_id))
            {
                var info = await db.Queryable<OaLeaveRule>().FirstAsync(x => x.id == id);
                if (info == null)
                {
                    throw new Exception($"未找到记录");
                }

                await db.Deleteable(info).ExecuteCommandAsync();
            }
        }
    }
}
