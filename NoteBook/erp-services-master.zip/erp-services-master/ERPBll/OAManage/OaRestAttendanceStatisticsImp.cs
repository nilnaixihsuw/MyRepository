﻿using AutoMapper;
using ERPBll.ApprovalForm.Contracts;
using ERPCore.Enums;
using ERPDal;
using ERPModel.ApprovalForm;
using ERPModel.Oamanage;
using ERPModel.OAManage;
using ERPModel.PersonalManage;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.OAManage
{
    public class OaRestAttendanceStatisticsImp : IOaRestAttendanceStatisticsImp
    {
        private readonly IMapper _imapper;
        private readonly IOaTripRecordImp _oaTripRecordImp;
        public OaRestAttendanceStatisticsImp(
            IOaTripRecordImp oaTripRecordImp,
            IMapper imapper)
        {
            _imapper = imapper;
            _oaTripRecordImp = oaTripRecordImp;
        }

        public async Task<List<RestAttendanceStatisticsResponse>> GetOaAttendanceRecordList(RestAttendanceStatisticsRequest request)
        {
            using var db = SqlSugarHelper.DBClient(request.server_id);
            var list = await db.Queryable<OaAttendanceRecord>()
                .Where(it => it.user_id == request.user_id && (it.type == 1 || it.type == 3))
                .WhereIF(request.date is { Count: 2 }, it => it.date >= request.date[0] && it.date <= request.date[1])
                .GroupBy(x => new { x.type_child })
                .Select(x => new RestAttendanceStatisticsResponse
                {
                    hour = SqlFunc.AggregateSum(x.duration.Value),
                    type = x.type_child == 0 ? 10 : x.type_child
                })
                .ToListAsync();
            return list;
        }

        public async Task<List<OaAttendanceRecordDto>> GetRecordDetailList(RestDetailRequest request)
        {
            using var db = SqlSugarHelper.DBClient(request.server_id);
            var list = await db.Queryable<OaAttendanceRecord>()
                .Where(it => it.user_id == request.user_id && it.type == 1 && it.type_child == request.type)
                .WhereIF(request.date is { Count: 2 }, it => it.date >= request.date[0] && it.date <= request.date[1])
                .ToListAsync();
            var data = _imapper.Map<List<OaAttendanceRecord>, List<OaAttendanceRecordDto>>(list);
            var info = await db.Queryable<OaRestMain>().ToListAsync();
            foreach (var item in data)
            {
                var detail = info.FirstOrDefault(x => x.id == item.main_id);
                if (detail != null)
                {
                    item.start_end = (detail.type == 1 || detail.type == 2)
                    ? detail.start_date.ToString("yyyy-MM-dd HH:mm") + "-" +
                      detail.end_date.ToString("yyyy-MM-dd HH:mm")
                    : detail.start_date.ToString("yyyy-MM-dd") + (detail.start_time < 2 ? " 上午" : " 下午") + "-" +
                      detail.end_date.ToString("yyyy-MM-dd") + (detail.end_time < 2 ? " 上午" : " 下午");
                }
            }
            return data;
        }
        public async Task<OaRestMainDto> GetRestMainDetailList(string server_id, decimal main_id)
        {
            using var db = SqlSugarHelper.DBClient(server_id);
            var info = await db.Queryable<OaRestMain>().FirstAsync(x => x.id == main_id);
            var data = _imapper.Map<OaRestMain, OaRestMainDto>(info);
            return data;
        }

        public async Task<List<RestDetail>> GetUserRestAsync(string server_id, RequestRest request)
        {
            using var db = SqlSugarHelper.DBClient(server_id);
            var data = await db.Queryable<OaAttendanceRecord>()
                .Where(x => x.user_id == request.user_id && x.date >= request.start_time.Date && x.date <= request.end_time.Date)
                .Select(x => new { x.type, x.main_id, x.type_child })
                .ToListAsync();
            var cc_data = await db.Queryable<OaTripRecord>().Where(x => x.user_id == request.user_id && x.start_date <= request.start_time && x.end_date >= request.end_time).ToListAsync();
            var response_data = new List<RestDetail>();
            //加班
            var over_time = data.Where(x => x.type == 2).Select(x => x.main_id).ToList();
            if (over_time.Count > 0)
            {
                var responses = await db.Queryable<OaWorkOvertime>().Where(x => over_time.Contains(x.id)).ToListAsync();
                List<RestDetail> response = responses.Select(x => new RestDetail()
                {
                    id = x.id,
                    day = "(共" + x.hour + "小时)",
                    start_date = x.start_time,
                    end_date = x.end_time,
                    flow_id = x.flow_id,
                    start_end = x.start_time.ToString("yyyy-MM-dd HH:mm:ss") + "～" + x.end_time.ToString("yyyy-MM-dd HH: mm:ss"),
                    name = "加班"
                }).ToList();
                response_data = response_data.Concat(response).ToList();
            }
            //请假
            var rest_time = data.Where(x => x.type == 1).Select(x => x.main_id).ToList();
            if (rest_time.Count > 0)
            {
                var rest_data = await db.Queryable<OaRestMain>().Where(x => rest_time.Contains(x.id)).OrderBy(x => x.start_date).ToListAsync();
                var response = rest_data.Where(x => x.type != 3).Select(x =>
                new RestDetail()
                {
                    id = x.id,
                    day = "(共" + x.day + ((x.type == 1 || x.type == 2) ? "小时)" : "天)"),
                    start_date = x.start_date,
                    end_date = x.end_date,
                    start_time = x.start_time,
                    end_time = x.end_time,
                    flow_id = x.flow_id,
                    start_end = x.start_time != 0 ? x.start_date.ToString("yyyy-MM-dd") + (x.start_time == 1 ? "上午" : "下午") + "～" + x.end_date.ToString("yyyy-MM-dd") + (x.end_time == 1 ? "上午" : "下午") : x.start_date.ToString("yyyy-MM-dd HH:mm:ss") + "～" + x.end_date.ToString("yyyy-MM-dd HH:mm:ss"),
                    name = ((QJJBEnums)x.type).ToString(),
                }).ToList();
                response_data = response_data.Concat(response).ToList();
            }
            //出差
            if (cc_data.Count > 0)
            {
                var response = cc_data.Select(x =>
                new RestDetail()
                {
                    id = x.id,
                    day = "(共" + x.duration + "天)",
                    start_date = x.start_date,
                    end_date = x.end_date,
                    flow_id = x.flow_id,
                    start_end = x.start_time != 0 ? x.start_date.ToString("yyyy-MM-dd") + (x.start_time == 1 ? "上午" : "下午") + "～" + x.end_date.ToString("yyyy-MM-dd") + (x.end_time == 1 ? "上午" : "下午") : x.start_date.ToString("yyyy-MM-dd HH:mm:ss") + "～" + x.end_date.ToString("yyyy-MM-dd HH:mm:ss"),
                    name = "出差"
                }).ToList();
                response_data = response_data.Concat(response).ToList();
            }
            response_data = response_data.OrderBy(x => x.start_time).ToList();

            return response_data;
        }
    }
}
