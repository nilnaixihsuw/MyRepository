﻿using ERPModel.Oamanage.OaKqRecords;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.OAManage
{
    public interface IOaKqRecordImp
    {
        /// <summary>
        /// 获取个人考勤汇总
        /// </summary>
        Task<OaKqRecordTotalDto> GetByUserTotalAsync(string server_id, OaKqRecordQuery query);

        /// <summary>
        /// 获取个人考勤明细
        /// </summary>
        Task<List<OaKqRecordTotalDetailDto>> GetByUserDetailAsync(string server_id, OaKqRecordQuery query);

        /// <summary>
        /// 获取个人打卡明细
        /// </summary>
        Task<List<OaKqRecordDto>> GetDetilAsync(string server_id, OaKqRecordQuery query);

        /// <summary>
        /// 新增
        /// </summary>
        Task AddAsync(string server_id, List<CreateOaKqRecord> input);

        /// <summary>
        /// 更新打卡时间
        /// </summary>
        Task<(bool, string)> UpdateAsync(string server_id, KqClock input);

        ///重新生成考勤记录
        Task AddKqRecord(string server_id, List<int> user_ids, DateTime date, SqlSugarClient db = null);
    }
}
