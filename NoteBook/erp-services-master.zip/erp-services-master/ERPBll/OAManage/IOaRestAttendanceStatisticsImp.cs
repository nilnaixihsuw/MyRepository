﻿using ERPModel.Oamanage;
using ERPModel.PersonalManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.OAManage
{
    public interface IOaRestAttendanceStatisticsImp
    {
        /// <summary>
        /// 获取个人假勤统计
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="request"></param>
        /// <returns></returns>
        Task<List<RestAttendanceStatisticsResponse>> GetOaAttendanceRecordList(RestAttendanceStatisticsRequest request);

        /// <summary>
        /// 获取个人假勤统计类别详情
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="request"></param>
        /// <returns></returns>
        Task<List<OaAttendanceRecordDto>> GetRecordDetailList(RestDetailRequest request);

        /// <summary>
        /// 获取个人请假记录表详情
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="main_id"></param>
        /// <returns></returns>
        Task<OaRestMainDto> GetRestMainDetailList(string server_id, decimal main_id);

        /// <summary>
        /// 获取指定时间范围内个人假勤
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="request"></param>
        /// <returns></returns>
        Task<List<RestDetail>> GetUserRestAsync(string server_id, RequestRest request);
    }
}
