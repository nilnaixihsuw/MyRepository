﻿using AutoMapper;
using ERPBll.RedisManage.Users;
using ERPDal;
using ERPModel.Oamanage.OaLeaveBalances;
using ERPModel.Oamanage.OaLeaveRules;
using ERPModel.UserManage;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Yitter.IdGenerator;

namespace ERPBll.OAManage
{
    public class OaLeaveBalanceImp : IOaLeaveBalanceImp
    {
        private readonly IMapper _imapper;
        private readonly IOaLeaveRuleImp _oaLeaveRuleImp;
        private readonly IUserRedisImp _userRedisImp;

        public OaLeaveBalanceImp(
             IMapper imapper,
             IOaLeaveRuleImp oaLeaveRuleImp,
             IUserRedisImp userRedisImp)
        {
            _imapper = imapper;
            _oaLeaveRuleImp = oaLeaveRuleImp;
            _userRedisImp = userRedisImp;
        }

        public async Task<(List<OaLeaveBalanceDto>, int)> GetByPageAsync(string server_id, OaLeaveBalanceQuery input)
        {
            RefAsync<int> totalCount = 0;

            using (var db = SqlSugarHelper.DBClient(server_id))
            {
                if (input.dept_id > 0)
                {
                    input.user_ids = await db.Queryable<SysDepPerson>()
                                            .Where(x => x.i_group_id == input.dept_id && x.i_child_id > 2000000)
                                            .Select(x => Convert.ToInt32(x.i_child_id))
                                            .ToListAsync();
                }
                //查询
                var list = await db.Queryable<OaLeaveBalance>().Where(input.ToExp()).ToPageListAsync(input.page_index, input.page_size, totalCount);

                var data = _imapper.Map<List<OaLeaveBalance>, List<OaLeaveBalanceDto>>(list);
                var users = await _userRedisImp.GetAllAsync();
                foreach (var item in data)
                {
                    var user = await _userRedisImp.GetByIdAsync(item.user_id.ToString());
                    item.user_name = user?.c_name;
                    item.dept_id = !(user?.i_department_base).HasValue ? 0 : (int)user.i_department_base.Value;
                    item.dept_name = user?.department_name;
                    item.word_year = !item.join_in.HasValue ? 0 : Math.Round((DateTime.Now - item.join_in.Value).TotalDays / 365, 1);
                }
                return (data, totalCount);
            }
        }

        /// <summary>
        /// 获取年假明细
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<OaLeaveBalanceDto> GetOaLeaveDetailByIdAsync(string server_id, decimal id)
        {
            //查询
            var balance = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<OaLeaveBalance>()
                                .Where(x => x.id == id)
                                .FirstAsync();

            var data = _imapper.Map<OaLeaveBalance, OaLeaveBalanceDto>(balance);

            if (data != null)
            {
                var user = await _userRedisImp.GetByIdAsync(data.user_id.ToString());
                data.user_name = user.c_name;
                data.dept_id = !user.i_department_base.HasValue ? 0 : (int)user.i_department_base.Value;
                data.dept_name = user.department_name;
                data.word_year = !data.join_in.HasValue ? 0 : Math.Round((DateTime.Now - data.join_in.Value).TotalDays / 365, 1);
                data.detail = await GetDetailAsync(server_id, data.user_id, 5);

                var rule = await _oaLeaveRuleImp.GetByUserAsync(server_id, data.user_id);
                if (rule != null)
                {
                    data.rule = $"当前 年假规则：每年的{(rule.add_time == 1 ? "1月1日" : "入职日")}自动发放，按{(rule.add_rule == 1 ? "固定" : "司龄")}配额";
                }
            }

            return data;
        }

        public async Task<List<OaLeaveBalanceDetailDto>> GetDetailAsync(string server_id, decimal user_id, int type = 0)
        {
            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<OaLeaveBalanceDetail>()
                                .Where(x => x.user_id == user_id)
                                .WhereIF(type > 0, x => x.type == type)
                                .OrderBy(x => x.id, OrderByType.Desc)
                                .ToListAsync();

            var data = _imapper.Map<List<OaLeaveBalanceDetail>, List<OaLeaveBalanceDetailDto>>(list);
            return data;
        }

        /// <summary>
        /// 获取用户年假剩余天数
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="user_id">用户id</param>
        /// <param name="join_time">入职时间</param>
        /// <param name="rules">假期规则</param>
        /// <returns></returns>
        public async Task<decimal> GetYearBalanceByUserAsync(string server_id, decimal user_id)
        {
            using (var db = SqlSugarHelper.DBClient(server_id))
            {
                var query = await db.Queryable<OaLeaveBalance>().FirstAsync(x => x.user_id == user_id);
                return query == null ? 0 : query.year_balance;
            }
        }

        /// <summary>
        /// 根据规则计算用户年假
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="user_id">用户id</param>
        /// <param name="join_time">入职时间</param>
        /// <param name="rules">假期规则</param>
        /// <returns></returns>
        public int GetYearBalanceByRuleAsync(DateTime? join_time, OaLeaveRuleDto rule)
        {
            if (!join_time.HasValue)
            {
                return 0;
            }

            int? value = 0;
            if (rule.add_rule == 1) //固定额度
            {
                value = rule.childs.First(x => x.start == 0 && x.end == 0)?.value;
            }
            else if (rule.add_rule == 2) //根据工作年薪分配
            {
                var year = Math.Round((DateTime.Now - join_time.Value).TotalDays / 365, 1);
                value = rule.childs.First(x => (x.start <= year && year < x.end) || (x.start <= year && x.end == 0))?.value;
            }
            return value.HasValue ? value.Value : 0;
        }

        public async Task AddAsync(string server_id)
        {
            using (var db = SqlSugarHelper.DBClient(server_id))
            {
                var users = await db.Queryable<SysPerson>()
                                    .Where(x => x.i_emp_state == 1 || x.i_emp_state == null)
                                    .OrderBy(x => x.i_id)
                                    .ToListAsync();
                var userids = users.Select(x => x.i_id).ToList();

                var list = await db.Queryable<OaLeaveBalance>().ToListAsync();

                foreach (var user in users)
                {
                    var rule = await _oaLeaveRuleImp.GetByUserAsync(server_id, user.i_id.Value);
                    if (rule == null)
                    {
                        continue;
                    }
                    //1月1日发放
                    if (rule.add_time == 1)
                    {
                        if (DateTime.Now.Month != 1 || DateTime.Now.Day != 1)
                            continue;
                    }
                    //入职日期发放
                    else
                    {
                        if (!user.d_join_company.HasValue || !(user.d_join_company.Value.Month == DateTime.Now.Month &&
                            user.d_join_company.Value.Day == DateTime.Now.Day))
                            continue;

                    }
                    var info = list.FirstOrDefault(x => x.user_id == user.i_id);
                    if (info.year_balance > 0)
                    {
                        var detail = new CreateOaLeaveBalanceDetail
                        {
                            user_id = info.user_id,
                            model = 2,
                            content = $"系统按照规则自动过期{info.year_balance}天年假",
                            value = info.year_balance
                        };
                        await ReduceDetailAsync(server_id, detail);
                    }
                    info.year_balance = GetYearBalanceByRuleAsync(info.join_in, rule);
                    await db.Updateable(info).ExecuteCommandAsync();

                    if (info.year_balance > 0)
                    {
                        await AddDetailAsync(server_id, info.user_id, info.year_balance, rule.extend_day);
                    }
                }

                //离职员工
                var leaves = list.Where(x => !userids.Contains(x.user_id)).ToList();
                if (leaves != null && leaves.Count > 0)
                {
                    foreach (var item in leaves)
                    {
                        item.state = 2;
                    }
                    await db.Updateable(leaves).ExecuteCommandAsync();
                }
            }
        }
        /// <summary>
        /// 新员工入职年假计算
        /// </summary>
        /// <param name="server_id"></param>
        /// <returns></returns>
        public async Task AddNewUserBalance(string server_id, decimal user_id)
        {
            using (var db = SqlSugarHelper.DBClient(server_id))
            {
                var user = await db.Queryable<SysPerson>().FirstAsync(x => x.i_id == user_id);
                var list = await db.Queryable<OaLeaveBalance>().ToListAsync();
                var rule = await _oaLeaveRuleImp.GetByUserAsync(server_id, user.i_id.Value);

                if (!list.Exists(x => x.user_id == user.i_id) && rule != null) //新入职
                {
                    var info = new OaLeaveBalance();
                    info.id = YitIdHelper.NextId();
                    info.user_id = (int)user.i_id.Value;
                    info.join_in = user.d_join_company;
                    info.year_balance = GetYearBalanceByRuleAsync(info.join_in, rule);
                    await db.Insertable(info).ExecuteCommandAsync();

                    if (info.year_balance > 0)
                    {
                        await AddDetailAsync(server_id, info.user_id, info.year_balance, rule.extend_day);
                    }
                }
            }

        }
        /// <summary>
        /// 更新入职日期重新计算年假
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="user_id"></param>
        /// <returns></returns>
        public async Task EditUserBalance(string server_id, decimal user_id)
        {
            using (var db = SqlSugarHelper.DBClient(server_id))
            {
                var user = await db.Queryable<SysPerson>().FirstAsync(x => x.i_id == user_id);
                if (user.d_join_company != null)
                {
                    var info = await db.Queryable<OaLeaveBalance>().FirstAsync(x => x.user_id == user_id);
                    if (info != null && user.d_join_company != info.join_in)
                    {
                        await db.Deleteable<OaLeaveBalanceDetail>().Where(it => it.user_id == user_id && it.model == 1 && it.type == 5).ExecuteCommandAsync();
                        var rule = await _oaLeaveRuleImp.GetByUserAsync(server_id, user.i_id.Value);
                        if (rule==null)
                        {
                            throw new Exception($"未找到name={user.c_name}所属部门的假期规则");
                        }
                        info.join_in = user.d_join_company;
                        for (DateTime i = (DateTime)user.d_join_company; i < DateTime.Now; i = i.AddYears(1))
                        {
                            info.year_balance = EditYearBalanceByRuleAsync(user.d_join_company, i, rule);
                            await db.Updateable(info).ExecuteCommandAsync();

                            if (info.year_balance > 0)
                            {
                                await EditDetailAsync(server_id, info.user_id, info.year_balance, rule.extend_day, i, rule.add_time);
                            }
                            var use_balances = await db.Queryable<OaLeaveBalanceDetail>().Where(it => it.user_id == user_id && it.start_time > i && it.end_time < i.AddYears(1) && it.model == 2 && it.type == 5).ToListAsync();
                            decimal total_balance = 0;
                            foreach (var item in use_balances)
                            {
                                total_balance += item.value;
                            }
                            info.year_balance = (info.year_balance - total_balance) > 0 ? info.year_balance - total_balance : 0;
                            await db.Updateable(info).ExecuteCommandAsync();
                            if (i.AddYears(1) < DateTime.Now)
                            {
                                if (info.year_balance > 0)
                                {
                                    var detail = new CreateOaLeaveBalanceDetail
                                    {
                                        user_id = info.user_id,
                                        model = 2,
                                        content = $"系统按照规则自动过期{info.year_balance}天年假",
                                        value = info.year_balance,
                                        start_time = i,
                                        end_time = i.AddYears(1).AddDays(rule.extend_day),
                                        created_date = i.AddYears(1).AddDays(rule.extend_day)
                                    };
                                    await ReduceDetailAsync(server_id, detail);
                                }
                            }
                        }
                    }
                }
            }
        }
        /// <summary>
        /// 更改入职时间重新计算假期余额
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="user_id"用户id></param>
        /// <param name="balance">增加的余额</param>
        /// <param name="extend_day">延长过期时间：天</param>
        /// <returns></returns>
        public async Task EditDetailAsync(string server_id, decimal user_id, decimal balance, int extend_day, DateTime cur_time, int year_time)
        {
            using (var db = SqlSugarHelper.DBClient(server_id))
            {
                var detail = new OaLeaveBalanceDetail();
                detail.id = YitIdHelper.NextId();
                detail.user_id = user_id;
                detail.model = 1;
                detail.content = $"系统按照规则自动新增{balance}天年假，余额{balance}天";
                detail.value = balance;
                if (year_time == 1)
                {
                    detail.start_time = new DateTime(cur_time.Year, 1, 1);
                    detail.end_time = new DateTime(cur_time.Year + 1, 1, 1).AddDays(extend_day);
                    detail.created_date = new DateTime(cur_time.Year, 1, 1); ;
                }
                else
                {
                    detail.start_time = cur_time;
                    detail.end_time = cur_time.AddYears(1).AddDays(extend_day).Date;
                    detail.created_date = cur_time;
                }

                await db.Insertable(detail).ExecuteCommandAsync();
            }
        }
        /// <summary>
        /// 更改入职时间计算年假规则
        /// </summary>
        /// <param name="join_time"></param>
        /// <param name="count_time"></param>
        /// <param name="rule"></param>
        /// <returns></returns>
        public int EditYearBalanceByRuleAsync(DateTime? join_time, DateTime count_time, OaLeaveRuleDto rule)
        {
            if (!join_time.HasValue)
            {
                return 0;
            }

            int? value = 0;
            if (rule.add_rule == 1) //固定额度
            {
                value = rule.childs.FirstOrDefault(x => x.start == 0 && x.end == 0)?.value;
            }
            else if (rule.add_rule == 2) //根据工作年限分配
            {
                var year = Math.Round((count_time - join_time.Value).TotalDays / 365, 1);
                value = rule.childs.FirstOrDefault(x => (x.start <= year && year < x.end) || (x.start <= year && x.end == 0))?.value;
            }
            return value.HasValue ? value.Value : 0;
        }

        /// <summary>
        /// 增加余额
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="user_id"用户id></param>
        /// <param name="balance">增加的余额</param>
        /// <param name="extend_day">延长过期时间：天</param>
        /// <returns></returns>
        public async Task AddDetailAsync(string server_id, decimal user_id, decimal balance, int extend_day)
        {
            using (var db = SqlSugarHelper.DBClient(server_id))
            {
                var detail = new OaLeaveBalanceDetail();
                detail.id = YitIdHelper.NextId();
                detail.user_id = user_id;
                detail.model = 1;
                detail.content = $"系统按照规则自动新增{balance}天年假，余额{balance}天";
                detail.value = balance;
                detail.start_time = DateTime.Now.Date;
                detail.end_time = DateTime.Now.AddYears(1).AddDays(extend_day).Date;
                await db.Insertable(detail).ExecuteCommandAsync();
            }
        }

        /// <summary>
        /// 修改余额
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="input"></param>
        /// <returns></returns>
        public async Task<bool> UpdateDetailAsync(string server_id, CreateOaLeaveBalanceDetail input)
        {
            using (var db = SqlSugarHelper.DBClient(server_id))
            {
                var detail = _imapper.Map<CreateOaLeaveBalanceDetail, OaLeaveBalanceDetail>(input);
                detail.id = YitIdHelper.NextId();
                return await db.Insertable(detail).ExecuteCommandAsync() > 0;
            }
        }
        public async Task ReduceDetailAsync(string server_id, CreateOaLeaveBalanceDetail input)
        {
            using (var db = SqlSugarHelper.DBClient(server_id))
            {
                var detail = _imapper.Map<CreateOaLeaveBalanceDetail, OaLeaveBalanceDetail>(input);
                detail.id = YitIdHelper.NextId();
                await db.Insertable(detail).ExecuteCommandAsync();
            }
        }
        /// <summary>
        /// 修改年假余额
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="user_id">用户id</param>
        /// <param name="model">数据类型;1增加 2减少</param>
        /// <param name="value">变动数值</param>
        /// <param name="update_user_id">修改人id</param>
        /// <returns></returns>
        public async Task<bool> UpdateYearBalanceAsync(UpdateYearBalanceInput input, decimal? update_user_id)
        {
            var info = await SqlSugarHelper.DBClient(input.server_id)
                                .Queryable<OaLeaveBalance>()
                                .FirstAsync(x => x.user_id == input.user_id);
            if (info == null)
            {
                throw new Exception($"未找到记录，user_id={input.user_id}");
            }

            var update_user_info = await SqlSugarHelper.DBClient(input.server_id)
                                .Queryable<SysPerson>()
                                .FirstAsync(x => x.i_id == update_user_id);
            var update_user_name = update_user_info != null ? update_user_info.c_name : "";

            var detail = new CreateOaLeaveBalanceDetail()
            {
                user_id = input.user_id,
                type = 5,
                model = input.model,
                value = input.value
            };
            var rule = await _oaLeaveRuleImp.GetByUserAsync(input.server_id, input.user_id);
            if (rule != null && rule.add_time == 1)
            {
                detail.start_time = new DateTime(DateTime.Now.Year, 1, 1);
                detail.end_time = detail.start_time.AddYears(1);
            }
            if (rule != null && rule.add_time == 2)
            {
                var user = await SqlSugarHelper.DBClient(input.server_id)
                            .Queryable<SysPerson>()
                            .Where(x => x.i_id == input.user_id && (x.i_emp_state == 1 || x.i_emp_state == null))
                            .FirstAsync();
                if (user != null && user.d_join_company.HasValue)
                {
                    detail.start_time = new DateTime(DateTime.Now.Year, user.d_join_company.Value.Month, user.d_join_company.Value.Day);
                    detail.end_time = detail.start_time.AddYears(1);
                }
            }
            if (input.model == 1)
            {
                info.year_balance = info.year_balance + input.value;

                detail.content = $"管理员{update_user_name}修改年假余额新增{input.value}天，余额{info.year_balance}天 理由:{input.reason}";
            }
            else
            {
                info.year_balance = info.year_balance - input.value;
                if (info.year_balance<0)
                {
                    throw new Exception("年假余额不能小于0");
                }
                detail.content = $"管理员{update_user_name}修改年假余额减少{input.value}天，余额{info.year_balance}天 理由:{input.reason}";
            }

            await UpdateDetailAsync(input.server_id, detail);

            return await SqlSugarHelper.DBClient(input.server_id).Updateable(info).ExecuteCommandAsync() > 0;
        }
    }
}
