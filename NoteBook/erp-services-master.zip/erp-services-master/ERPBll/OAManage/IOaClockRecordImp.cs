﻿using ERPCore.Entity;
using ERPModel.Oamanage.OaClockRecords;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.OAManage
{
    public interface IOaClockRecordImp
    {
        /// <summary>
        /// 新增打卡记录
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        Task<OaClockRecordDto> AddOaClockRecordAsync(string server_id, CreateOaClockRecord input);

        /// <summary>
        /// 原始记录
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        Task<OaClockRecordDetailResponse> OaClockRecordDetailAsync(ClockRecordStatisticsRequest request);

        /// <summary>
        /// 打卡时间
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        Task<OaClockRecordDetailResponse> OaClockRecordTimeAsync(ClockRecordStatisticsRequest request);

        /// <summary>
        /// 获取用户当天打卡详情
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="input"></param>
        /// <returns></returns>
        Task<DayClockResponse> GetOaClockDetailAsync(GetClockDetailRequest input);

        /// <summary>
        /// 管理员修改打卡结果
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="input"></param>
        /// <returns></returns>
        Task UpdateClockStateAsync( UpdateClockStateRequest input, ClientInformation client);

        /// <summary>
        /// 获取用户指定时间内考勤详情
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="input"></param>
        /// <returns></returns>
        Task<List<MonthClockResponse>> GetOaClockAsync(GetOaClockRequest input);
    }
}
