﻿using ERPModel.ApiModel;
using ERPModel.Oamanage.OaKqbcs;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.OAManage
{
    public interface IOaKqbcImp
    {
        /// <summary>
        /// 分页获取班次
        /// </summary>
        Task<(List<OaKqbcDto>, int)> GetByPageAsync(string server_id, OaKqbcQuery input);
        /// <summary>
        /// 新增班次
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        Task AddKqbcAsync(string server_id, int user_id, CreateOaKqbc input);
        /// <summary>
        /// 编辑班次
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>

        Task<bool> EditKqbcAsync(string server_id, int user_id, CreateOaKqbc input, SqlSugarClient db = null);

        /// <summary>
        /// 删除班次
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        Task DelAsync(string server_id, long id);
    }
}
