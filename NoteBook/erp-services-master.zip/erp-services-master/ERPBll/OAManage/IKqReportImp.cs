﻿using ERPModel.Oamanage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.OAManage
{
    public interface IKqReportImp
    {
        /// <summary>
        /// 获取日考勤数据
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        Task<Tuple<List<DayKqDto>, int>> GetDayKqData(DayKqRequest request);

        /// <summary>
        /// 获取月考勤数据
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        Task<Tuple<List<MonthKqDto>, int>> GetMonthKqData(MonthKqRequest request);

        /// <summary>
        /// 获取月考勤明细数据
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        Task<MonthKqDetailDto> GetMonthKqDetailData(MonthKqDetailRequest request);
    }
}
