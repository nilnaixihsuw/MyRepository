﻿using AutoMapper;
using ERPBll.RedisManage.Users;
using ERPDal;
using ERPModel.Oamanage.OaKqbcs;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using ERPModel.Oamanage.OaKqzs;
using Yitter.IdGenerator;
using ERPModel.Oamanage.OaKqRecords;
using System.Linq;
using ERPBll.SignalRs;

namespace ERPBll.OAManage
{
    public class OaKqbcImp : IOaKqbcImp
    {
        private readonly IMapper _imapper;
        private readonly IOaKqRecordImp _oaKqRecordImp;
        protected IServerHubImp _iServerHubImp;

        public OaKqbcImp(
             IMapper imapper,
             IServerHubImp iServerHubImp,
             IOaKqRecordImp oaKqRecordImp)
        {
            _imapper = imapper;
            _iServerHubImp = iServerHubImp;
            _oaKqRecordImp = oaKqRecordImp;
        }

        public async Task<(List<OaKqbcDto>, int)> GetByPageAsync(string server_id, OaKqbcQuery input)
        {
            RefAsync<int> totalCount = 0;
            using var db = SqlSugarHelper.DBClient(server_id);
            var list = await db.Queryable<OaKqbc>()
                .Where(x => x.is_delete == 0)
                .Where(input.ToExp())
                .Includes(x => x.child.OrderBy(x => x.up_time).ToList())
                .ToPageListAsync(input.page_index, input.page_size, totalCount);
            var data = _imapper.Map<List<OaKqbc>, List<OaKqbcDto>>(list);

            return (data, totalCount);
        }
        public async Task AddKqbcAsync(string server_id, int user_id, CreateOaKqbc input)
        {
            using var db = SqlSugarHelper.DBClient(server_id);
            var query = await db.Queryable<OaKqbc>().CountAsync(x => x.name == input.name && x.is_delete == 0);
            if (query > 0)
            {
                throw new Exception("当前已有该名称的班次明细");
            }
            checkTime(input.child);
            foreach (var item in input.child)
            {
                item.up_start = item.up_section[0];
                item.up_end = item.up_section[1];
                item.down_start = item.down_section[0];
                item.down_end = item.down_section[1];
                if (item.is_rest == 1 && item.rest_section != null && item.rest_section.Count == 2)
                {
                    item.rest_start = item.rest_section[0];
                    item.rest_end = item.rest_section[1];
                }
            }
            var info = _imapper.Map<CreateOaKqbc, OaKqbc>(input);
            info.id = Tools.GetEngineID(server_id);
            info.SetCreate(user_id);
            var list = _imapper.Map<List<CreateOaKqbcChild>, List<OaKqbcChild>>(input.child);
            foreach (var item in list)
            {
                item.id = Tools.GetEngineID(server_id);
                item.main_id = info.id;
                item.created_id = user_id;
                item.created_date = DateTime.Now;
            }
            await db.Insertable(list).ExecuteCommandAsync();
            await db.Insertable(info).ExecuteCommandAsync();
        }
        public void checkTime(List<CreateOaKqbcChild> child)
        {
            var data = new List<DateTime>();
            string dtString = "2022-08-10 ";
            foreach (var item in child)
            {
                if (Convert.ToDateTime(dtString + item.up_time + ":00") < Convert.ToDateTime(dtString + item.up_section[0] + ":00") ||
                    Convert.ToDateTime(dtString + item.up_time + ":00") > Convert.ToDateTime(dtString + item.up_section[1] + ":00"))
                {
                    throw new Exception("上班时间不在上班打卡时间范围内");
                }
                if (Convert.ToDateTime(dtString + item.down_time + ":00") < Convert.ToDateTime(dtString + item.down_section[0] + ":00") ||
                    Convert.ToDateTime(dtString + item.down_time + ":00") > Convert.ToDateTime(dtString + item.down_section[1] + ":00"))
                {
                    throw new Exception("下班时间不在下班打卡时间范围内");
                }
                data.Add(Convert.ToDateTime(dtString + item.up_section[0] + ":00"));
                data.Add(Convert.ToDateTime(dtString + item.up_section[1] + ":00"));
                data.Add(Convert.ToDateTime(dtString + item.down_section[0] + ":00"));
                data.Add(Convert.ToDateTime(dtString + item.down_section[1] + ":00"));
                if (item.is_rest == 1 && item.rest_section != null && item.rest_section.Count == 2)
                {
                    if (Convert.ToDateTime(dtString + item.rest_section[0] + ":00") < Convert.ToDateTime(dtString + item.up_time + ":00") ||
                    Convert.ToDateTime(dtString + item.rest_section[1] + ":00") > Convert.ToDateTime(dtString + item.down_time + ":00"))
                    {
                        throw new Exception("休息时间不在上下班时间范围内");
                    }
                }
            }
            for (int i = 0; i < data.Count - 1; i++)
            {
                if (data[i] > data[i + 1])
                {
                    throw new Exception("时间范围设置有冲突,不能交叉");
                }
            }
        }
        public async Task<bool> EditKqbcAsync(string server_id, int user_id, CreateOaKqbc input, SqlSugarClient db = null)
        {
            db ??= SqlSugarHelper.DBClient(server_id);
            var info = await db.Queryable<OaKqbc>().FirstAsync(x => x.id == input.id);
            if (info == null)
            {
                throw new Exception("未找到该班次记录");
            }
            var query = await db.Queryable<OaKqbc>().CountAsync(x => x.name == input.name && x.id != input.id && x.is_delete == 0);
            if (query > 0)
            {
                throw new Exception("当前已有该名称的班次明细");
            }
            checkTime(input.child);
            foreach (var item in input.child)
            {
                item.up_start = item.up_section[0];
                item.up_end = item.up_section[1];
                item.down_start = item.down_section[0];
                item.down_end = item.down_section[1];
                if (item.rest_section != null && item.rest_section.Count == 2)
                {
                    item.rest_start = item.rest_section[0];
                    item.rest_end = item.rest_section[1];
                }
            }
            var new_bc = _imapper.Map<CreateOaKqbc, OaKqbc>(input);
            new_bc.id = Tools.GetEngineID(server_id);
            new_bc.SetCreate(user_id);
            info.SetUpdate(user_id);
            info.is_delete = 1;
            var list = _imapper.Map<List<CreateOaKqbcChild>, List<OaKqbcChild>>(input.child);
            foreach (var item in list)
            {
                item.id = Tools.GetEngineID(server_id);
                item.main_id = new_bc.id;
                item.created_id = user_id;
                item.created_date = DateTime.Now;
            }
            await db.Updateable(info).ExecuteCommandAsync();
            await db.Insertable(list).ExecuteCommandAsync();
            await db.Insertable(new_bc).ExecuteCommandAsync();
            DateTime dt = input.isEnableToday == 1 ? DateTime.Now.Date : DateTime.Now.Date.AddDays(1);
            //更新特殊日期使用班次
            await db.Updateable<OaKqzTsrq>()
                 .SetColumns(x => x.kqbc_id == new_bc.id)
                 .Where(x => x.kqbc_id == info.id && x.ts_date >= dt)
                 .ExecuteCommandAsync();
            //更新考勤工作日正在使用的班次
            await db.Updateable<OaKqzWeek>()
                 .SetColumns(x => x.kqbc_id == new_bc.id)
                 .Where(x => x.kqbc_id == info.id)
                 .ExecuteCommandAsync();
            var r = await _iServerHubImp.SendMessageToAllAsync(MessageType.UpdateKqbc, 8);
            if (input.isEnableToday == 1)
            {
                //找到受影响的用户id
                var users = await db.Queryable<OaKqbcDay>().Where(x => x.kqbc_id == info.id && x.kq_date == DateTime.Now.Date).Select(x => x.user_id).ToListAsync();
                if (users.Count > 0)
                {
                    await db.Updateable<OaKqbcDay>()
                   .SetColumns(x => x.kqbc_id == new_bc.id)
                   .Where(x => x.kqbc_id == info.id && x.kq_date == DateTime.Now.Date)
                   .ExecuteCommandAsync();
                    Task.Run(() => _oaKqRecordImp.AddKqRecord(server_id, users, DateTime.Now.Date));
                    //重新生成考勤记录
                }
            }
            return true;
        }

        public async Task DelAsync(string server_id, long id)
        {
            using var db = SqlSugarHelper.DBClient(server_id);
            var info = await db.Queryable<OaKqbc>().FirstAsync(x => x.id == id);
            if (info == null)
            {
                throw new Exception($"未找到班次记录");
            }

            var tsrq = await db.Queryable<OaKqzTsrq>().CountAsync(x => x.kqbc_id == id && x.ts_date > DateTime.Now);
            if (tsrq > 0)
            {
                throw new Exception($"特殊日期正在使用的班次不允许删除");
            }
            var kqzweek = await db.Queryable<OaKqzWeek>().Where(x => x.kqbc_id == id).Select(x => x.kqz_id).ToListAsync();
            var kqz = await db.Queryable<OaKqz>().CountAsync(x => kqzweek.Contains(id) && (x.is_delete == 0 || (x.is_delete == 1 && x.update_date > DateTime.Now.AddDays(-1))));

            if (kqz > 0)
            {
                throw new Exception($"考勤工作日正在使用的班次不允许删除");
            }
            await db.Deleteable<OaKqbcChild>().Where(x => x.main_id == id).ExecuteCommandAsync();
            await db.Deleteable(info).ExecuteCommandAsync();
        }
    }
}
