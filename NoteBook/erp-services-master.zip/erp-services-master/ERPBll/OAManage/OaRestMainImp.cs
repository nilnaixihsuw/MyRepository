﻿using ERPCore.ORM;
using ERPDal.OAManage;
using ERPModel.OAManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using ERPModel.Oamanage;
using ERPModel.ApiModel.OAManage;
using ERPDal;
using ERPModel.FlowManage.FlowRecords;
using AutoMapper;
using ERPBll.FlowManage.Contracts;
using ERPBll.RedisManage.Users;
using ERPModel.FlowManage;
using ERPCore.Entity;
using ERPModel.SystemManage;
using ERPCore.Enums;
using ERPModel.Oamanage.OaKqbcs;
using ERPModel.Oamanage.OaKqzs;
using RazorEngine.Compilation.ImpromptuInterface;

namespace ERPBll.OAManage
{
    public class OaRestMainImp : IOaRestMainImp
    {
        private readonly IMapper _imapper;
        private readonly IErpFlowRecordImp _erpFlowRecordImp;
        private readonly IUserRedisImp _userRedisImp;
        private readonly IOaLeaveBalanceImp _oaLeaveBalanceImp;
        private readonly IOaKqzImp _oaKqzImp;

        public OaRestMainImp(
            IMapper imapper,
            IErpFlowRecordImp erpFlowRecordImp,
            IUserRedisImp userRedisImp,
            IOaLeaveBalanceImp oaLeaveBalanceImp,
            IOaKqzImp oaKqzImp)
        {
            _imapper = imapper;
            _erpFlowRecordImp = erpFlowRecordImp;
            _userRedisImp = userRedisImp;
            _oaLeaveBalanceImp = oaLeaveBalanceImp;
            _oaKqzImp = oaKqzImp;
        }

        public async Task<List<RestFormDataDto>> GetByPageAsync(string server_id, decimal? user_id, OaRestRequest request)
        {
            var list = await SqlSugarHelper.DBClient(server_id)
                               .Queryable<OaRestMain>()
                               .Where(request.ToExp())
                               .Mapper(x => x.person_info, x => x.person_id)
                               .Mapper(x => x.flow_record, x => x.flow_id)
                               .Mapper(x => x.create_info, x => x.created_id)
                               .Mapper(x =>
                               {
                                   x.file_list = SqlSugarHelper.DBClient(server_id)
                                                   .Queryable<SysFileRecord>()
                                                   .Where(y => y.object_id == x.id)
                                                   .ToList();
                                   if (x.file_list.Count > 0)
                                   {
                                       x.files = x.file_list.Select(y => y.url).ToList();
                                   }
                               })
                               .ToListAsync();

            if (list != null && list.Count > 0)
            {
                var all = await _erpFlowRecordImp.GetListAsync(request.server_id, user_id,
                   new FlowRecordQuery()
                   {
                       detail_ids = list.Select(x => (int)x.id).ToList()
                   });
                foreach (var item in list)
                {
                    var user = await _userRedisImp.GetByIdAsync(((int)item.created_id).ToString());
                    item.dept_id = user.i_department_base;
                    item.dept_name = user.department_name;

                    if (item.state == 1)//审核中
                    {
                        var info = all.FirstOrDefault(x => x.detail_id == item.id);
                        if (info != null)
                        {
                            item.user_ids = info.state_child_id;
                            item.user_names = info.state_child_name;
                        }
                    }
                }
            }

            return _imapper.Map<List<OaRestMain>, List<RestFormDataDto>>(list);
        }

        public async Task<OaRestMain> AddAsymc(string server_id, ClientInformation client, RestFormData input, SqlSugarClient db)
        {
            if (input.step_data == null || input.step_data.Count < 1)
            {
                throw new Exception("审批流程数据为空");
            }

            input.step_data.Where(x => x.oper_type == 1).ToList().ForEach(x =>
            {
                if (x.users.Count < 1)
                {
                    throw new Exception("审批节点人员不能为空");
                }
                if (x.users.Count > 15)
                {
                    throw new Exception("审批节点人员最多15人");
                }
            });

            if (db == null)
            {
                db = SqlSugarHelper.DBClient(server_id);
            }
            if (input.form_data.type == 0)
            {
                throw new Exception("该请假类型不存在");
            }
            if (input.form_data.type == 5)
            {
                var balance = await _oaLeaveBalanceImp.GetYearBalanceByUserAsync(server_id, client.i_id.Value);
                if (balance < input.form_data.day)
                {
                    throw new Exception("年假余额不足");
                }
            }

            var req = new OaRestRequest()
            {
                start_date = input.form_data.start_date,
                end_date = input.form_data.end_date,
                start_time = input.form_data.start_time,
                end_time = input.form_data.end_time
            };

            var list = await db.Queryable<OaRestMain>()
                               .Where(req.ToValidation(client.i_id))
                               .ToListAsync();
            if (list != null && list.Count > 0)
            {
                throw new Exception("当前时间段已有请假记录");
            }

            var insert = _imapper.Map<OaRestDto, OaRestMain>(DealData(input.form_data));
            insert.id = ERPBll.Tools.GetSeqCommonID(server_id);
            insert.created_id = client.i_id;
            insert.created_date = DateTime.Now;
            insert.unit = input.form_data.type == 1 || input.form_data.type == 2 ? 2 : 3;

            //发起流程
            var flow = await _erpFlowRecordImp.StartAsync(server_id, client.i_id, input.step_data, db);
            if (flow == null)
            {
                throw new Exception("发起请假流程失败");
            }

            await _erpFlowRecordImp.UpdateAsync(server_id, flow.id, Convert.ToInt32(insert.id),
                    RestMessage.GetContent(client.c_name, insert), "", db);
            insert.flow_id = flow.id;
            insert.flow_code = flow.code;
            insert.state = 1;

            var file_list = new List<SysFileRecord>();

            if (input.form_data.files != null && input.form_data.files.Count > 0)
            {
                input.form_data.files.ForEach(x =>
                {
                    var file = new SysFileRecord()
                    {
                        model = (int)FileRecordType.OARESTMAIN,
                        object_id = insert.id,
                        type = 1,
                        url = x,
                        created_id = client.i_id,
                        created_date = DateTime.Now
                    };
                    file_list.Add(file);
                });

                await db.Insertable(file_list).ExecuteCommandAsync();
            }

            await db.Insertable(insert).ExecuteCommandAsync();

            return insert;
        }

        public async Task<RestTimeDetail> GetTimeDetail(string server_id, GetHourRequest request)
        {
            using var db = SqlSugarHelper.DBClient(server_id);

            if (!(request.type == QJJBEnums.公出 || request.type == QJJBEnums.事假)!)
            {
                if (request.start_time == 1)
                {
                    request.start_date = request.start_date.Date;
                }
                if (request.start_time == 2)
                {
                    request.start_date = request.start_date.Date.AddHours(12);
                }
                if (request.end_time == 1)
                {
                    request.end_date = request.end_date.Date.AddHours(12);
                }
                if (request.end_time == 2)
                {
                    request.end_date = request.end_date.Date.AddHours(24);
                }
                return await GetDays(server_id, request.user_id, request.start_date, request.end_date);
            }

            var details = new List<DayDetails>();
            var kqbc = await GetRestKqbcDetail(server_id, request.user_id, request.start_date.Date);
            if (request.start_date.Date == request.end_date.Date)
            {
                if (kqbc.Count > 0)
                {
                    details.Add(GetHour(kqbc, request.start_date, request.end_date));
                }
            }
            else //跨天提交
            {
                //第一天
                if (kqbc.Count > 0)
                {
                    details.Add(GetHour(kqbc, request.start_date, request.start_date.Date.AddDays(1)));
                }

                for (var i = request.start_date.Date.AddDays(1); i <= request.end_date; i = i.AddDays(1))
                {
                    kqbc = await GetRestKqbcDetail(server_id, request.user_id, i.Date);
                    if (kqbc.Count > 0) //休息或者没有考勤组
                    {
                        if (i.Date == request.end_date.Date) //最后一天
                        {
                            if (request.end_date.Hour != 0)
                            {
                                details.Add(GetHour(kqbc, i.Date, request.end_date));
                            }
                        }
                        else
                        {
                            details.Add(GetHour(kqbc, i.Date, i.Date.AddDays(1)));
                        }
                    }
                }
            }
            details = details.Where(x => x.day_hour != 0).ToList();
            //var (time, str_time) = Tools.getTime(details.Sum(x => x.day_hour));
            if (details.Sum(x => x.day_hour) < 0.5)
            {
                throw new Exception("有效请假时长不能小于半小时");
            }
            return new RestTimeDetail()
            {
                total_time = details.Sum(x => x.day_hour),
                str_time = details.Sum(x => x.day_hour) + "小时",
                day_details = details,
            };
        }
        public async Task<List<OaKqbcChildDto>> GetRestKqbcDetail(string server_id,int user_id,DateTime start)
        {
            var kqbc = await _oaKqzImp.GetKqbcAsync(server_id, user_id, start.Date);
            if (kqbc == null)
            {
                kqbc = await _oaKqzImp.GetDefaultKqbcAsync(server_id, start.Date);
            }
            return kqbc;
        }
        /// <summary>
        /// 根据时间段计算天数
        /// </summary>
        /// <returns></returns>
        public async Task<RestTimeDetail> GetDays(string server_id, int user_id, DateTime start, DateTime end)
        {
            var details = new List<DayDetails>();
            double total_time = 0;
            var kqbc = await GetRestKqbcDetail(server_id, user_id, start.Date);
            if (start.Date == end.Date)//日期相同
            {
                if (kqbc.Count > 0)
                {
                    total_time += end.Hour - start.Hour;

                    details.Add(new DayDetails()
                    {
                        day = start.Date,
                        day_hour = (double)(end.Hour - start.Hour) / 24
                    });
                }
            }
            else//跨天
            {
                //第一天
                if (kqbc.Count > 0)
                {
                    total_time += 24 - start.Hour;

                    details.Add(new DayDetails()
                    {
                        day = start.Date,
                        day_hour = (double)(24 - start.Hour) / 24
                    });
                }

                for (DateTime i = start.Date.AddDays(1); i <= end.Date; i = i.AddDays(1))
                {
                    kqbc = await GetRestKqbcDetail(server_id, user_id, i.Date);
                    if (kqbc.Count > 0)
                    {
                        if (i.Date == end.Date) //最后一天
                        {
                            if (end.Hour != 0)
                            {
                                total_time += end.Hour;

                                details.Add(new DayDetails()
                                {
                                    day = i.Date,
                                    day_hour = (double)end.Hour / 24
                                });
                            }
                        }
                        else
                        {
                            total_time += 24;

                            details.Add(new DayDetails()
                            {
                                day = i.Date,
                                day_hour = 1
                            });
                        }
                    }
                }
            }
            if (total_time / 24 < 0.5)
            {
                throw new Exception("有效请假时长不能小于半天");
            }
            return new RestTimeDetail()
            {
                total_time = total_time / 24,
                str_time = $"{total_time / 24}天",
                day_details = details
            };
        }

        /// <summary>
        ///  根据时间段计算小时
        /// </summary>
        public DayDetails GetHour(List<OaKqbcChildDto> kqbcChild, DateTime start, DateTime end)
        {
            var data = new DayDetails()
            {
                day = start.Date,
                day_hour = 0,
                unit = 2
            };
            foreach (var child in kqbcChild)
            {
                DateTime up_time = start.Date.AddHours(child.up_time.Value.Hour).AddMinutes(child.up_time.Value.Minute);
                DateTime down_time = start.Date.AddHours(child.down_time.Value.Hour).AddMinutes(child.down_time.Value.Minute);

                //休息范围
                if (child.is_rest == 1 && child.rest_start.HasValue && child.rest_end.HasValue)
                {
                    DateTime rest_start = start.Date.AddHours(child.rest_start.Value.Hour).AddMinutes(child.rest_start.Value.Minute);
                    DateTime rest_end = start.Date.AddHours(child.rest_end.Value.Hour).AddMinutes(child.rest_end.Value.Minute);
                    data.day_hour += GetMinutes(start, end, up_time, rest_start);
                    data.day_hour += GetMinutes(start, end, rest_end, down_time);
                }
                else
                {
                    data.day_hour += GetMinutes(start, end, up_time, down_time);
                }
            }
            return data;
        }

        public double GetMinutes(DateTime start, DateTime end, DateTime up_time, DateTime down_time)
        {
            double num = 0;
            //起始时间在上下班时间之间，结束时间大于下班时间
            if (start >= up_time && start <= down_time && end >= down_time)
            {
                num += (down_time - start).TotalHours;
            }
            //起始时间早于上班时间 且 结束时间在上下班时间之间
            else if (start <= up_time && end <= down_time && end >= up_time)
            {
                num += (end - up_time).TotalHours;
            }
            //起始时间和结束时间都在上下班时间范围之内
            else if (start >= up_time && end <= down_time && end >= up_time)
            {
                num += (end - start).TotalHours;
            }
            //起始时间早于上班时间，结束时间晚于下班时间
            else if (start <= up_time && end >= down_time)
            {
                num += (down_time - up_time).TotalHours;
            }
            return Math.Round(num, 2);
        }


        private OaRestDto DealData(OaRestDto data)
        {
            if (data.type != 1 && data.type != 2)
            {
                data.start_date = data.start_date.Date;
                data.end_date = data.end_date.Date;
            }
            return data;
        }
    }
}