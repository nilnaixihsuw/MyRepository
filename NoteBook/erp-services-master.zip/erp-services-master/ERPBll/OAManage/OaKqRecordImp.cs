using AutoMapper;
using ERPCore.Enums;
using ERPDal;
using ERPModel.Oamanage.OaClockRecords;
using ERPModel.Oamanage.OaKqbcs;
using ERPModel.Oamanage.OaKqDays;
using ERPModel.Oamanage.OaKqRecords;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.OAManage
{
    public class OaKqRecordImp : IOaKqRecordImp
    {
        private readonly IMapper _imapper;
        private readonly IOaKqzImp _oaKqzImps;

        public OaKqRecordImp(IMapper imapper,
            IOaKqzImp oaKqzImps)
        {
            _imapper = imapper;
            _oaKqzImps = oaKqzImps;
        }

        public async Task<OaKqRecordTotalDto> GetByUserTotalAsync(string server_id, OaKqRecordQuery query)
        {
            using (var db = SqlSugarHelper.DBClient(server_id))
            {
                var kq = await db.Queryable<OaKqDay>().Where(query.ToDayExp()).OrderBy(x => x.kq_date).ToListAsync();

                var res = await db.Queryable<OaKqRecord>()
                   .Where(query.ToExp())
                   .GroupBy(x => new { x.user_id, x.kq_date, x.state })
                   .Select(x => new
                   {
                       user_id = x.user_id,
                       kq_date = x.kq_date,
                       state = x.state,
                       count = SqlFunc.AggregateCount(x.state)
                   })
                   .ToListAsync();

                var detail = new List<OaKqRecordDayDetailDto>();
                for (DateTime dt = query.start_date; dt <= query.end_date; dt = dt.AddDays(1))
                {
                    var list = res.Where(x => x.kq_date == dt.Date).ToList();
                    if (list != null && list.Count > 0)
                    {
                        detail.Add(new OaKqRecordDayDetailDto()
                        {
                            day = dt,
                            state = list.Count(x => x.state > 1) > 0 ?
                                (kq.Exists(x => x.kq_date == dt.Date && x.state == 3) ? 3 : 2) : 1
                        });
                    }
                }

                return new OaKqRecordTotalDto()
                {
                    month = query.start_date.ToString("yyyy-MM"),
                    cq_count = kq.Count(x => x.state == 1 || x.state == 2),
                    xx_count = kq.Count(x => x.state == 0),
                    wq_count = kq.Count(x => x.state == 2),
                    cd_count = res.Where(x => x.state == 2 || x.state == 11).Sum(x => x.count),
                    zt_count = res.Where(x => x.state == 3 || x.state == 10).Sum(x => x.count),
                    qk_count = res.Where(x => x.state == 5).Sum(x => x.count),
                    kg_count = kq.Count(x => x.state == 3),
                    detail = detail,
                };
            }
        }

        public async Task<List<OaKqRecordTotalDetailDto>> GetByUserDetailAsync(string server_id, OaKqRecordQuery query)
        {
            using (var db = SqlSugarHelper.DBClient(server_id))
            {
                var res = await db.Queryable<OaKqDay>()
                    .Where(query.ToDayExp())
                    .Select(x => new OaKqRecordTotalDetailDto
                    {
                        day = x.kq_date,
                        state = query.kq_state == 1 ? 1 : x.state
                    })
                    .OrderBy(x => x.day)
                    .ToListAsync();

                return res;
            }
        }

        public async Task<List<OaKqRecordDto>> GetDetilAsync(string server_id, OaKqRecordQuery query)
        {
            using (var db = SqlSugarHelper.DBClient(server_id))
            {
                var data = new List<OaKqRecordDto>();
                if (query.start_date.Date == query.end_date.Date && query.start_date.Date == DateTime.Now.Date)
                {
                    var result = new OaKqRecordDto();
                    var user = await db.Queryable<OaKqbcDay>().FirstAsync(x => x.user_id == query.user_id && x.kq_date == DateTime.Now.Date);
                    if (user == null)
                    {
                        result.xx_kqz = 2;
                        data.Add(result);
                        return data;
                    }
                    else if (user.kqbc_id == 0)
                    {
                        result.xx_kqz = 1;
                        data.Add(result);
                        return data;
                    }
                }

                var res = await db.Queryable<OaKqRecord>().Where(query.ToExp()).OrderBy(x => x.ls_time).ToListAsync();
                data = _imapper.Map<List<OaKqRecord>, List<OaKqRecordDto>>(res);
                if (!query.state.HasValue)
                {
                    for (int i = 0; i < data.Count; i++)
                    {
                        if (data[i].type == 2)
                        {
                            if (data[i - 1].zd_minutes != 0)
                            {
                                data[i].tx_time = data[i].ls_time.Value.AddMinutes(-data[i - 1].zd_minutes);
                            }
                            else if (data[i - 1].wd_minutes != 0)
                            {
                                data[i].tx_time = data[i].ls_time.Value.AddMinutes(data[i - 1].wd_minutes);
                            }
                        }
                    }
                }
                return data;
            }
        }

        public async Task AddAsync(string server_id, List<CreateOaKqRecord> input)
        {
            using (var db = SqlSugarHelper.DBClient(server_id))
            {
                var info = _imapper.Map<List<CreateOaKqRecord>, List<OaKqRecord>>(input);
                await db.Insertable(info).ExecuteCommandAsync();
            }
        }

        public async Task<(bool, string)> UpdateAsync(string server_id, KqClock input)
        {
            using (var db = SqlSugarHelper.DBClient(server_id))
            {
                var res = await db.Queryable<OaKqRecord>()
                    .FirstAsync(x => x.user_id == input.user_id && x.ls_time == input.ls_time && x.kq_date == input.kq_date);
                if (res == null)
                {
                    return (false, "无效打卡，当天休息");
                }

                if (input.sj_time > DateTime.Now.AddMinutes(1) || input.sj_time < DateTime.Now.AddMinutes(-1))
                {
                    return (false, "无效打卡，打卡时间与当前实际时间误差超过一分钟");
                }

                if (input.sj_time < res.start_time || input.sj_time > res.end_time)
                {
                    return (false, "无效打卡，不在有效打卡时间范围内");
                }

                if (res.type == 1 && res.sj_time.HasValue && res.sj_time < input.sj_time)
                {
                    return (false, "无效打卡，以最早上班打卡时间为准");
                }

                if (res.type == 2 && res.sj_time.HasValue && res.sj_time > input.sj_time)
                {
                    return (false, "无效打卡，以最晚下班打卡时间为准");
                }

                _imapper.Map<KqClock, OaKqRecord>(input, res);
                await db.Updateable(res).ExecuteCommandAsync();

                if (input.state == 4) // 外勤打卡更新考勤记录
                {
                    await db.Updateable<OaKqDay>().SetColumns(x => x.state == 2).Where(x => x.kq_code == res.kq_code).ExecuteCommandAsync();
                }
                return (true, "");
            }
        }

        ///重新生成考勤记录
        public async Task AddKqRecord(string server_id, List<int> user_ids, DateTime date, SqlSugarClient db = null)
        {
            db ??= SqlSugarHelper.DBClient(server_id);
            await db.Deleteable<OaKqRecord>().Where(x => user_ids.Contains(x.user_id) && x.kq_date.Date == date.Date).ExecuteCommandAsync();
            foreach (var userid in user_ids)
            {
                var kqbc = await GetKqbcAsync(server_id, userid, date, db);
                var day = await db.Queryable<OaKqDay>().FirstAsync(x => x.user_id == userid && x.kq_date == date.Date);
                OaKqDay kqday = new OaKqDay();
                if (day == null)
                {
                    kqday = new OaKqDay()
                    {
                        id = Tools.GetEngineID(server_id),
                        kq_code = Tools.GetBusinessCode(),
                        user_id = userid,
                        kq_date = DateTime.Now.Date
                    };
                }
                List<CreateOaKqRecord> list = new List<CreateOaKqRecord>();
                if (kqbc != null && kqbc.Count > 0)
                {
                    if (kqday.id != 0)
                    {
                        kqday.state = 1;
                    }
                    foreach (var item in kqbc)
                    {
                        if (item.is_up == 1 && item.up_time.HasValue)
                        {
                            list.Add(new CreateOaKqRecord
                            {

                                kq_code = day == null ? kqday.kq_code : day.kq_code,
                                user_id = userid,
                                kqz_id = item.kqz_id,
                                kqbc_id = item.main_id,
                                kq_date = date.Date,
                                start_time = date.Date.AddHours(item.up_start.Value.Hour).AddMinutes(item.up_start.Value.Minute),
                                end_time = date.Date.AddHours(item.up_end.Value.Hour).AddMinutes(item.up_end.Value.Minute),
                                type = 1,
                                ls_time = date.Date.AddHours(item.up_time.Value.Hour).AddMinutes(item.up_time.Value.Minute)
                            });
                        }
                        if (item.is_down == 1 && item.down_time.HasValue)
                        {
                            list.Add(new CreateOaKqRecord
                            {
                                kq_code = day == null ? kqday.kq_code : day.kq_code,
                                user_id = userid,
                                kqz_id = item.kqz_id,
                                kqbc_id = item.main_id,
                                kq_date = date.Date,
                                start_time = date.Date.AddHours(item.down_start.Value.Hour).AddMinutes(item.down_start.Value.Minute),
                                end_time = date.Date.AddHours(item.down_end.Value.Hour).AddMinutes(item.down_end.Value.Minute),
                                type = 2,
                                ls_time = date.Date.AddHours(item.down_time.Value.Hour).AddMinutes(item.down_time.Value.Minute)
                            });
                        }
                    }
                }
                if (kqday.id != 0)
                {
                    await db.Insertable(kqday).ExecuteCommandAsync();
                }
                var info = _imapper.Map<List<CreateOaKqRecord>, List<OaKqRecord>>(list);
                info.ForEach(x => x.id = Tools.GetEngineID(server_id));
                var dk_record = await db.Queryable<OaClockRecord>().Where(x => x.user_id == userid && x.kqri.Date == date.Date && x.state != 5).OrderBy(x => x.dcsj).ToListAsync();
                var last_record = new OaClockRecord();
                foreach (var item in dk_record)
                {
                    //判断是第几次打卡：上班打卡取早于下班时间的第一条，下班打卡取晚于下班时间的最后一条
                    var kqbc_detail = item.type == 1 ? kqbc.FirstOrDefault(x => string.Compare(x.down_time.Value.ToString("HH:mm"), item.kqsj.ToString("HH:mm")) >= 0)
                        : kqbc.Where(x => string.Compare(item.kqsj.ToString("HH:mm"), x.down_time.Value.ToString("HH:mm")) >= 0).LastOrDefault();
                    if (kqbc_detail == null)
                    {
                        break;
                    }
                    var res = item.type == 1 ? info.FirstOrDefault(x => x.ls_time.Value.ToString("HH:mm") == kqbc_detail.up_time.Value.ToString("HH:mm")) : info.FirstOrDefault(x => x.ls_time.Value.ToString("HH:mm") == kqbc_detail.down_time.Value.ToString("HH:mm"));
                    if (res == null)
                    {
                        item.state = 5; item.state_name = "无效打卡，当天休息";
                    }
                    else if (item.dcsj < res.start_time || item.dcsj > res.end_time)
                    {
                        item.state = 5; item.state_name = "无效打卡，不在有效打卡时间范围内";
                    }
                    else if (res.type == 1 && res.sj_time.HasValue && res.sj_time < item.dcsj)
                    {
                        item.state = 5; item.state_name = "无效打卡，以最早上班打卡时间为准";
                    }
                    else if (res.type == 2 && res.sj_time.HasValue && res.sj_time > item.dcsj)
                    {
                        item.state = 5; item.state_name = "无效打卡，以最晚下班打卡时间为准";
                    }
                    if (item.state != 5)
                    {
                        var kqbc_zhu = await db.Queryable<OaKqbc>().FirstAsync(x => x.id == kqbc_detail.main_id);
                        //上班且在打卡范围内
                        if (item.type == 1 && item.dcsj >= kqbc_detail.up_start && item.dcsj <= kqbc_detail.up_end)
                        {
                            //开启弹性打卡
                            if (kqbc_zhu.is_tx == 1)
                            {
                                //正常打卡（早于理论上班时间+弹性允许晚到时间）
                                if (item.dcsj <= kqbc_detail.up_time.Value.AddMinutes((double)kqbc_zhu.tx_down))
                                {
                                    if (item.dcsj <= kqbc_detail.up_time.Value)
                                    {
                                        item.zd_minutes = (int)(kqbc_detail.up_time.Value - item.dcsj).TotalMinutes;
                                        item.zd_minutes = item.zd_minutes > kqbc_zhu.tx_up ? kqbc_zhu.tx_up : item.zd_minutes;
                                    }
                                    else
                                    {
                                        item.wd_minutes = (int)(item.dcsj - kqbc_detail.up_time.Value).TotalMinutes;
                                        item.wd_minutes = item.wd_minutes > kqbc_zhu.tx_down ? kqbc_zhu.tx_down : item.wd_minutes;
                                    }
                                    item.state = 1;
                                }
                                else
                                {
                                    var minutes = (int)(item.dcsj - kqbc_detail.up_time.Value.AddMinutes((double)kqbc_zhu.tx_down)).TotalMinutes;
                                    //开启迟到旷工
                                    if (kqbc_zhu.is_cdkg == 1)
                                    {
                                        if (minutes >= kqbc_zhu.cdkg)
                                        {
                                            item.state = 11;
                                            item.minutes = minutes;
                                        }
                                        else
                                        {
                                            item.state = 2;
                                            item.minutes = minutes;
                                        }
                                    }
                                    else
                                    {
                                        item.state = 2;
                                        item.minutes = minutes;
                                    }
                                }
                            }
                            else if (kqbc_zhu.is_yx == 1)
                            {
                                //正常打卡（早于理论上班时间+异常允许晚到时间）
                                if (item.dcsj <= kqbc_detail.up_time.Value.AddMinutes((double)kqbc_zhu.yc_up))
                                {
                                    item.state = 1;
                                }
                                else
                                {
                                    var minutes = (int)(item.dcsj - kqbc_detail.up_time.Value.AddMinutes((double)kqbc_zhu.yc_up)).TotalMinutes;
                                    //开启迟到旷工
                                    if (kqbc_zhu.is_cdkg == 1)
                                    {
                                        if (minutes >= kqbc_zhu.cdkg)
                                        {
                                            item.state = 11;
                                            item.minutes = minutes;
                                        }
                                        else
                                        {
                                            item.state = 2;
                                            item.minutes = minutes;
                                        }
                                    }
                                    else
                                    {
                                        item.state = 2;
                                        item.minutes = minutes;
                                    }
                                }
                            }
                            else
                            {
                                //正常打卡（早于理论上班时间）
                                if (item.dcsj <= kqbc_detail.up_time)
                                {
                                    item.state = 1;
                                }
                                else
                                {
                                    var minutes = (int)(item.dcsj - kqbc_detail.up_time.Value).TotalMinutes;
                                    //开启迟到旷工
                                    if (kqbc_zhu.is_cdkg == 1)
                                    {
                                        if (minutes >= kqbc_zhu.cdkg)
                                        {
                                            item.state = 11;
                                            item.minutes = minutes;
                                        }
                                        else
                                        {
                                            item.state = 2;
                                            item.minutes = minutes;
                                        }
                                    }
                                    else
                                    {
                                        item.state = 2;
                                        item.minutes = minutes;
                                    }
                                }
                            }
                        }
                        //下班且在下班打卡范围内
                        else if (item.type == 2 && item.dcsj >= kqbc_detail.down_start && item.dcsj <= kqbc_detail.down_end)
                        {
                            //开启弹性打卡
                            if (kqbc_zhu.is_tx == 1)
                            {
                                //正常打卡（晚于理论下班时间+上班早到晚到时间）
                                if (item.dcsj >= kqbc_detail.down_time.Value.AddMinutes(last_record.zd_minutes == 0 ? last_record.wd_minutes : -last_record.zd_minutes))
                                {
                                    item.state = 1;
                                }
                                else
                                {
                                    var minutes = (int)(kqbc_detail.down_time.Value.AddMinutes(last_record.zd_minutes == 0 ? last_record.wd_minutes : -last_record.zd_minutes) - item.dcsj).TotalMinutes;
                                    //开启早退旷工
                                    if (kqbc_zhu.is_ztkg == 1)
                                    {
                                        if (minutes >= kqbc_zhu.ztkg)
                                        {
                                            item.state = 10;
                                            item.minutes = minutes;
                                        }
                                        else
                                        {
                                            item.state = 3;
                                            item.minutes = minutes;
                                        }
                                    }
                                    else
                                    {
                                        item.state = 3;
                                        item.minutes = minutes;
                                    }
                                }
                            }
                            else if (kqbc_zhu.is_yx == 1)
                            {
                                //正常打卡（晚于理论下班时间+允许异常时间）
                                if (item.dcsj >= kqbc_detail.down_time.Value.AddMinutes(-(double)kqbc_zhu.yc_down))
                                {
                                    item.state = 1;
                                }
                                else
                                {
                                    var minutes = (int)(kqbc_detail.down_time.Value.AddMinutes((double)kqbc_zhu.yc_down) - item.dcsj).TotalMinutes;
                                    //开启早退旷工
                                    if (kqbc_zhu.is_ztkg == 1)
                                    {
                                        if (minutes >= kqbc_zhu.ztkg)
                                        {
                                            item.state = 10;
                                            item.minutes = minutes;
                                        }
                                        else
                                        {
                                            item.state = 3;
                                            item.minutes = minutes;
                                        }
                                    }
                                    else
                                    {
                                        item.state = 3;
                                        item.minutes = minutes;
                                    }
                                }
                            }
                            else
                            {
                                //正常打卡（晚于理论下班时间）
                                if (item.dcsj >= kqbc_detail.down_time)
                                {
                                    item.state = 1;
                                }
                                else
                                {
                                    var minutes = (int)(kqbc_detail.down_time.Value - item.dcsj).TotalMinutes;
                                    //开启早退旷工
                                    if (kqbc_zhu.is_ztkg == 1)
                                    {
                                        if (minutes >= kqbc_zhu.ztkg)
                                        {
                                            item.state = 10;
                                            item.minutes = minutes;
                                        }
                                        else
                                        {
                                            item.state = 3;
                                            item.minutes = minutes;
                                        }
                                    }
                                    else
                                    {
                                        item.state = 3;
                                        item.minutes = minutes;
                                    }
                                }
                            }
                        }
                        info.RemoveAll(x => x.id == res.id);
                        info.Add(_imapper.Map<OaClockRecord, OaKqRecord>(item, res));
                    }
                    if (item.is_wq == 1) // 外勤打卡更新考勤记录
                    {
                        await db.Updateable<OaKqDay>().SetColumns(x => x.state == 2).Where(x => x.kq_code == res.kq_code).ExecuteCommandAsync();
                    }
                    await db.Updateable(item).ExecuteCommandAsync();
                    if (item.type == 1 && item.state != 5)
                    {
                        last_record = item;
                    }
                }
                await db.Insertable(info).ExecuteCommandAsync();
            }
        }
        public async Task<(bool, string)> UpdateKqClockAsync(string server_id, KqClock input)
        {
            using (var db = SqlSugarHelper.DBClient(server_id))
            {
                var res = await db.Queryable<OaKqRecord>()
                    .FirstAsync(x => x.user_id == input.user_id && x.ls_time == input.ls_time && x.kq_date == input.kq_date);
                if (res == null)
                {
                    return (false, "无效打卡，当天休息");
                }

                if (input.sj_time < res.start_time || input.sj_time > res.end_time)
                {
                    return (false, "无效打卡，不在有效打卡时间范围内");
                }

                if (res.type == 1 && res.sj_time.HasValue && res.sj_time < input.sj_time)
                {
                    return (false, "无效打卡，以最早上班打卡时间为准");
                }

                if (res.type == 2 && res.sj_time.HasValue && res.sj_time > input.sj_time)
                {
                    return (false, "无效打卡，以最晚下班打卡时间为准");
                }

                _imapper.Map<KqClock, OaKqRecord>(input, res);
                await db.Updateable(res).ExecuteCommandAsync();

                if (input.state == 4) // 外勤打卡更新考勤记录
                {
                    await db.Updateable<OaKqDay>().SetColumns(x => x.state == 2).Where(x => x.kq_code == res.kq_code).ExecuteCommandAsync();
                }
                return (true, "");
            }
        }

        public async Task<List<OaKqbcChildDto>> GetKqbcAsync(string server_id, int user_id, DateTime dt, SqlSugarClient db = null)
        {
            db ??= SqlSugarHelper.DBClient(server_id);

            var oaKqbcDay = await db.Queryable<OaKqbcDay>().FirstAsync(x => x.user_id == user_id && x.kq_date == dt.Date);
            var kqz_id = oaKqbcDay == null ? 0 : oaKqbcDay.kqz_id;
            var kqbc = oaKqbcDay == null ? 0 : oaKqbcDay.kqbc_id;

            if (kqbc == 0) //休息不用打卡
            {
                return new List<OaKqbcChildDto>();
            }
            var day_kqbc = await db.Queryable<OaKqbcChild>().Where(x => x.main_id == kqbc).ToListAsync();
            var user_data = _imapper.Map<List<OaKqbcChild>, List<OaKqbcChildDto>>(day_kqbc).OrderBy(x => x.up_time).ToList();
            user_data.ForEach(x => x.kqz_id = kqz_id);
            return user_data;
        }


    }
}
