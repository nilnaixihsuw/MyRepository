﻿using ERPModel.Oamanage.SysVehicleChecks;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.OAManage
{
    public interface ISysVehicleCheckImp
    {
        /// <summary>
        /// 获取详情
        /// </summary>
        Task<SysVehicleCheckDto> GetById(string server_id, decimal? user_id, int id);

        /// <summary>
        /// 保存
        /// </summary>
        Task<SysVehicleCheckDto> AddAsync(string server_id, decimal? user_id, SysVehicleCheckFormData input, SqlSugarClient db);
    }
}
