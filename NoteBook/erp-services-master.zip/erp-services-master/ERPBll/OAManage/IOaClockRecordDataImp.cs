﻿using ERPCore.ORM;
using ERPModel.Oamanage.OaClockRecords;
using System;
using System.Collections.Generic;
using System.Text;

namespace ERPBll.OAManage
{
    public interface IOaClockRecordDataImp : IBaseDataRepository<OaClockRecord>
    {

    }
}
