﻿using ERPModel.Oamanage.OaLeaveBalances;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.OAManage
{
    public interface IOaLeaveBalanceImp
    {
        /// <summary>
        /// 分页获取
        /// </summary>
        Task<(List<OaLeaveBalanceDto>, int)> GetByPageAsync(string server_id, OaLeaveBalanceQuery input);

        /// <summary>
        /// 获取年假明细
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<OaLeaveBalanceDto> GetOaLeaveDetailByIdAsync(string server_id, decimal id);

        /// <summary>
        /// 获取用户年假剩余天数
        /// </summary>
        Task<decimal> GetYearBalanceByUserAsync(string server_id, decimal user_id);

        /// <summary>
        /// 获取用户假期余额明细
        /// </summary>
        /// <returns></returns>
        Task<List<OaLeaveBalanceDetailDto>> GetDetailAsync(string server_id, decimal user_id, int type = 0);

        /// <summary>
        /// 生成用户假期余额
        /// </summary>
        /// <param name="server_id"></param>
        /// <returns></returns>
        Task AddAsync(string server_id);

        /// <summary>
        /// 修改年假余额
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="user_id">用户id</param>
        /// <param name="model">数据类型;1发放 2使用</param>
        /// <param name="value">变动数值</param>
        /// <param name="update_user_id">修改人id</param>
        /// <returns></returns>
        Task<bool> UpdateYearBalanceAsync(UpdateYearBalanceInput input, decimal? update_user_id);

        /// <summary>
        /// 添加修改余额记录
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="input"></param>
        /// <returns></returns>
        Task<bool> UpdateDetailAsync(string server_id, CreateOaLeaveBalanceDetail input);

        /// <summary>
        /// 新员工入职年假计算
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="user_id"></param>
        /// <returns></returns>
        Task AddNewUserBalance(string server_id, decimal user_id);

        /// <summary>
        /// 更新入职日期重新计算年假
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="user_id"></param>
        /// <returns></returns>
        Task EditUserBalance(string server_id, decimal user_id);
    }
}
