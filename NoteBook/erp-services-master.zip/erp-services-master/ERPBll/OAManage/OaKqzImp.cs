﻿using AutoMapper;
using ERPDal;
using ERPModel.Oamanage.OaKqbcs;
using ERPModel.Oamanage.OaKqzs;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ERPCore.Enums;
using ERPDal.Repository;
using Microsoft.Extensions.DependencyInjection;
using ERPModel.Oamanage.OaClockRecords;
using System.Threading;
using ERPModel.Oamanage.OaKqRecords;
using ERPModel.Oamanage.OaKqDays;

namespace ERPBll.OAManage
{
    public class OaKqzImp : BaseBusiness<OaKqz>, IOaKqzImp
    {
        private readonly IMapper _imapper;
        private IServiceProvider _serviceProvider;

        public OaKqzImp(
             IMapper imapper,
             IServiceProvider serviceProvider)
        {
            _imapper = imapper;
            _serviceProvider = serviceProvider;
        }
        public async Task<List<OaKqbcChildDto>> GetKqbcAsync(string server_id, int user_id, DateTime dt)
        {
            using var db = SqlSugarHelper.DBClient(server_id);
            var kqbc = 0; //考勤班次id
            var kqzs = await db.Queryable<OaKqz>()
                               .Where(x => x.is_delete == 0)
                               .Includes(x => x.kqz_users)
                               .Includes(x => x.kqz_tsrqs)
                               .Includes(x => x.kqz_week)
                               .ToListAsync();

            var info = kqzs.FirstOrDefault(x => x.id == x.kqz_users.FirstOrDefault(y => y.user_id == user_id)?.kqz_id);
            if (info == null) //没有考勤组不用打卡
            {
                return null;
            }
            var kqz_id = info == null ? 0 : info.id;
            if (dt.Date <= DateTime.Now.Date)
            {
                var oaKqbcDay = await db.Queryable<OaKqbcDay>().FirstAsync(x => x.user_id == user_id && x.kq_date == dt.Date);
                kqz_id = oaKqbcDay == null ? 0 : oaKqbcDay.kqz_id;
                kqbc = oaKqbcDay == null ? 0 : oaKqbcDay.kqbc_id;
            }
            else
            {
                var tsrq = info.kqz_tsrqs.FirstOrDefault(x => x.ts_date.HasValue && x.ts_date.Value.Date == dt.Date);
                if (tsrq != null)
                {
                    if (tsrq.type == 1) //特殊日期需要打卡
                    {
                        kqbc = tsrq.kqbc_id;
                    }
                }
                else
                {
                    kqbc = GetKqbc(info, dt);
                }
            }
            if (kqbc == 0) //休息不用打卡
            {
                return new List<OaKqbcChildDto>();
            }
            var day_kqbc = await db.Queryable<OaKqbcChild>().Where(x => x.main_id == kqbc).OrderBy(x => x.up_time).ToListAsync();
            var user_data = _imapper.Map<List<OaKqbcChild>, List<OaKqbcChildDto>>(day_kqbc);
            var kqbc_detail = await db.Queryable<OaKqbc>().FirstAsync(x => x.id == kqbc);
            var dk_info = await db.Queryable<OaKqRecord>().Where(x => x.user_id == user_id && x.kq_date.Date == DateTime.Now.Date).ToListAsync();
            dk_info = dk_info.Where(x => x.sj_time != null).ToList();
            user_data.ForEach(x =>
            {
                x.zd_minutes = dk_info.FirstOrDefault(y => y.ls_time.Value.ToString("HH:mm") == x.up_time.Value.ToString("HH:mm")) == null ? 0 : dk_info.FirstOrDefault(y => y.ls_time.Value.ToString("HH:mm") == x.up_time.Value.ToString("HH:mm")).zd_minutes;
                x.wd_minutes = dk_info.FirstOrDefault(y => y.ls_time.Value.ToString("HH:mm") == x.up_time.Value.ToString("HH:mm")) == null ? 0 : dk_info.FirstOrDefault(y => y.ls_time.Value.ToString("HH:mm") == x.up_time.Value.ToString("HH:mm")).wd_minutes;
                x.kqz_id = kqz_id;
                x.name = kqbc_detail.name;
                x.tx_down_time = x.zd_minutes == 0 ? (x.wd_minutes == 0 ? x.down_time.Value : x.down_time.Value.AddMinutes(x.wd_minutes)) : x.down_time.Value.AddMinutes(-x.zd_minutes);
            });

            return user_data;
        }

        public async Task<List<OaKqbcChildDto>> GetDefaultKqbcAsync(string server_id, DateTime dt)
        {
            using var db = SqlSugarHelper.DBClient(server_id);
            var kqbc_id = 0;
            var info = await db.Queryable<OaKqz>().Includes(x => x.kqz_tsrqs).Includes(x => x.kqz_week).FirstAsync(x => x.is_default == 1 && x.is_delete == 0);
            var tsrq = info.kqz_tsrqs.FirstOrDefault(x => x.ts_date.HasValue && x.ts_date.Value.Date == dt.Date);
            if (tsrq != null)
            {
                if (tsrq.type == 1) //特殊日期需要打卡
                {
                    kqbc_id = tsrq.kqbc_id;
                }
            }
            else
            {
                kqbc_id = GetKqbc(info, dt);
            }
            if (kqbc_id == 0) //休息不用打卡
            {
                return new List<OaKqbcChildDto>();
            }
            var day_kqbc = await db.Queryable<OaKqbcChild>().Where(x => x.main_id == kqbc_id).OrderBy(x => x.up_time).ToListAsync();
            var user_data = _imapper.Map<List<OaKqbcChild>, List<OaKqbcChildDto>>(day_kqbc);
            return user_data;
        }
        public async Task<List<OaKqbcChildDto>> GetUserDayKqbcAsync(string server_id, int user_id, DateTime dt, SqlSugarClient db = null)
        {
            db ??= SqlSugarHelper.DBClient(server_id);
            var kqbc = 0; //考勤班次id
            var kqzs = await db.Queryable<OaKqz>()
                               .Where(x => x.is_delete == 0)
                               .Includes(x => x.kqz_users)
                               .Includes(x => x.kqz_tsrqs)
                               .Includes(x => x.kqz_week)
                               .ToListAsync();

            var info = kqzs.FirstOrDefault(x => x.id == x.kqz_users.FirstOrDefault(y => y.user_id == user_id)?.kqz_id);
            if (info == null) //没有考勤组不用打卡
            {
                return new List<OaKqbcChildDto>();
            }
            var tsrq = info.kqz_tsrqs.FirstOrDefault(x => x.ts_date.HasValue && x.ts_date.Value.Date == dt.Date);
            if (tsrq != null)
            {
                if (tsrq.type == 1) //特殊日期需要打卡
                {
                    kqbc = tsrq.kqbc_id;
                }
            }
            else
            {
                kqbc = GetKqbc(info, dt);
            }
            var day_kqbc = await db.Queryable<OaKqbcChild>().Where(x => x.main_id == kqbc).OrderBy(x => x.up_time).ToListAsync();
            return _imapper.Map<List<OaKqbcChild>, List<OaKqbcChildDto>>(day_kqbc);
        }
        public async Task<(int, long)> GetDayKqbcAsync(string server_id, int user_id, DateTime dt, SqlSugarClient db = null)
        {
            db ??= SqlSugarHelper.DBClient(server_id);
            var kqbc = 0; //考勤班次id
            var kqzs = await db.Queryable<OaKqz>()
                               .Where(x => x.is_delete == 0)
                               .Includes(x => x.kqz_users)
                               .Includes(x => x.kqz_tsrqs)
                               .Includes(x => x.kqz_week)
                               .ToListAsync();

            var info = kqzs.FirstOrDefault(x => x.id == x.kqz_users.FirstOrDefault(y => y.user_id == user_id)?.kqz_id);
            if (info == null) //没有考勤组不用打卡
            {
                return (0, 0);
            }
            var tsrq = info.kqz_tsrqs.FirstOrDefault(x => x.ts_date.HasValue && x.ts_date.Value.Date == dt.Date);
            if (tsrq != null)
            {
                if (tsrq.type == 1) //特殊日期需要打卡
                {
                    kqbc = tsrq.kqbc_id;
                }
            }
            else
            {
                kqbc = GetKqbc(info, dt);
            }
            return (kqbc, info.id);
        }
        public async Task<bool> EditKqzAsync(string server_id, int user_id, CreateOaKqz input, SqlSugarClient db = null)
        {
            db ??= SqlSugarHelper.DBClient(server_id);
            var info = await db.Queryable<OaKqz>().FirstAsync(x => x.id == input.id);
            if (info == null)
            {
                throw new Exception($"未找到该考勤组");
            }
            await CheckOnly(input, db);
            var query = await db.Queryable<OaKqz>().CountAsync(x => x.name == input.name && x.id != input.id && x.is_delete == 0);
            if (query > 0)
            {
                throw new Exception("当前已有该名称的考勤组");
            }
            info.is_delete = 1;
            var new_kqz = _imapper.Map<CreateOaKqz, OaKqz>(input);
            new_kqz.id = Tools.GetEngineID(server_id);
            new_kqz.SetCreate(user_id);
            info.SetUpdate(user_id);
            await InsertDept(server_id, new_kqz.id, user_id, input.oaKqzDept, db);
            await InsertUser(server_id, new_kqz.id, user_id, input.oaKqzUser, db);
            await InsertWeek(server_id, new_kqz.id, user_id, input.oaKqzWeek, db);
            await InsertTsrq(server_id, new_kqz.id, user_id, input.oaKqzTsrq, db);
            await InsertAddress(server_id, new_kqz.id, user_id, input.oaKqzAddress, db);
            await db.Updateable(info).ExecuteCommandAsync();
            await db.Insertable(new_kqz).ExecuteCommandAsync();

            if (input.isEnableToday == 1)
            {
                var users = input.oaKqzUser.Select(item => (int)item).ToList();
                Task.Run(() => UpdateKqRecord(server_id, input, users, new_kqz.id));
            }
            return true;
        }
        //更新考勤记录
        public async Task UpdateKqRecord(string server_id, CreateOaKqz kqz, List<int> users, long kqzid, SqlSugarClient db = null)
        {
            db ??= SqlSugarHelper.DBClient(server_id);
            foreach (var userid in users)
            {
                var bc_id = 0;
                var tsrq_dk = kqz.oaKqzTsrq.FirstOrDefault(x => x.type == 1);
                var tsrq_bdk = kqz.oaKqzTsrq.FirstOrDefault(x => x.type == 2);
                var tsrq = tsrq_dk == null ? null : tsrq_dk.detail.FirstOrDefault(x => x.ts_date.Date == DateTime.Now.Date);
                var tsrq2 = tsrq_bdk == null ? null : tsrq_bdk.detail.FirstOrDefault(x => x.ts_date.Date == DateTime.Now.Date);
                if (tsrq != null)
                {
                    bc_id = tsrq.kqbc_id;
                }
                else if (tsrq2 != null)
                {
                    bc_id = 0;
                }
                else
                {
                    var day = (int)DateTime.Now.DayOfWeek;
                    if (day == 0) day = 7;
                    var bcid = kqz.oaKqzWeek?.FirstOrDefault(x => x.sort == day);
                    bc_id = bcid == null ? 0 : bcid.kqbc_id;
                }
                var user = await db.Queryable<OaKqbcDay>().FirstAsync(x => x.user_id == userid && x.kq_date.Date == DateTime.Now.Date);
                if (user == null)
                {
                    OaKqbcDay kqbc_day = new OaKqbcDay()
                    {
                        id = Tools.GetEngineID(server_id),
                        user_id = userid,
                        kq_date = DateTime.Now.Date,
                        kqbc_id = bc_id,
                        kqz_id = (int)kqzid
                    };
                    await db.Insertable(kqbc_day).ExecuteCommandAsync();
                }
                else
                {
                    user.kqbc_id = bc_id;
                    user.kqz_id = (int)kqzid;
                    await db.Updateable(user).ExecuteCommandAsync();
                }
            }
            //IOaKqRecordImp _oaKqRecordImp = _serviceProvider.GetService<IOaKqRecordImp>();
            await AddKqRecord(server_id, users, DateTime.Now.Date, db);
        }
        /// <summary>
        /// 重新生成考勤
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="user_ids"></param>
        /// <param name="date"></param>
        /// <param name="db"></param>
        /// <returns></returns>
        public async Task AddKqRecord(string server_id, List<int> user_ids, DateTime date, SqlSugarClient db = null)
        {
            db ??= SqlSugarHelper.DBClient(server_id);
            await db.Deleteable<OaKqRecord>().Where(x => user_ids.Contains(x.user_id) && x.kq_date.Date == date.Date).ExecuteCommandAsync();
            foreach (var userid in user_ids)
            {
                var kqbc = await GetKqbcAsync(server_id, userid, date, db);
                var day = await db.Queryable<OaKqDay>().FirstAsync(x => x.user_id == userid && x.kq_date == date.Date);
                OaKqDay kqday = new OaKqDay();
                if (day == null)
                {
                    kqday = new OaKqDay()
                    {
                        id = Tools.GetEngineID(server_id),
                        kq_code = Tools.GetBusinessCode(),
                        user_id = userid,
                        kq_date = DateTime.Now.Date
                    };
                }
                List<CreateOaKqRecord> list = new List<CreateOaKqRecord>();
                if (kqbc != null && kqbc.Count > 0)
                {
                    if (kqday.id != 0)
                    {
                        kqday.state = 1;
                    }
                    foreach (var item in kqbc)
                    {
                        if (item.is_up == 1 && item.up_time.HasValue)
                        {
                            list.Add(new CreateOaKqRecord
                            {

                                kq_code = day == null ? kqday.kq_code : day.kq_code,
                                user_id = userid,
                                kqz_id = item.kqz_id,
                                kqbc_id = item.main_id,
                                kq_date = date.Date,
                                start_time = date.Date.AddHours(item.up_start.Value.Hour).AddMinutes(item.up_start.Value.Minute),
                                end_time = date.Date.AddHours(item.up_end.Value.Hour).AddMinutes(item.up_end.Value.Minute),
                                type = 1,
                                ls_time = date.Date.AddHours(item.up_time.Value.Hour).AddMinutes(item.up_time.Value.Minute)
                            });
                        }
                        if (item.is_down == 1 && item.down_time.HasValue)
                        {
                            list.Add(new CreateOaKqRecord
                            {
                                kq_code = day == null ? kqday.kq_code : day.kq_code,
                                user_id = userid,
                                kqz_id = item.kqz_id,
                                kqbc_id = item.main_id,
                                kq_date = date.Date,
                                start_time = date.Date.AddHours(item.down_start.Value.Hour).AddMinutes(item.down_start.Value.Minute),
                                end_time = date.Date.AddHours(item.down_end.Value.Hour).AddMinutes(item.down_end.Value.Minute),
                                type = 2,
                                ls_time = date.Date.AddHours(item.down_time.Value.Hour).AddMinutes(item.down_time.Value.Minute)
                            });
                        }
                    }
                }
                if (kqday.id != 0)
                {
                    await db.Insertable(kqday).ExecuteCommandAsync();
                }
                var info = _imapper.Map<List<CreateOaKqRecord>, List<OaKqRecord>>(list);
                info.ForEach(x => x.id = Tools.GetEngineID(server_id));
                var dk_record = await db.Queryable<OaClockRecord>().Where(x => x.user_id == userid && x.kqri.Date == date.Date && x.state != 5).OrderBy(x => x.dcsj).ToListAsync();
                var last_record = new OaClockRecord();
                foreach (var item in dk_record)
                {
                    //判断是第几次打卡：上班打卡取早于下班时间的第一条，下班打卡取晚于下班时间的最后一条
                    var kqbc_detail = item.type == 1 ? kqbc.FirstOrDefault(x => string.Compare(x.down_time.Value.ToString("HH:mm"), item.kqsj.ToString("HH:mm")) >= 0)
                        : kqbc.Where(x => string.Compare(item.kqsj.ToString("HH:mm"), x.down_time.Value.ToString("HH:mm")) >= 0).LastOrDefault();
                    if (kqbc_detail == null)
                    {
                        break;
                    }
                    var res = item.type == 1 ? info.FirstOrDefault(x => x.ls_time.Value.ToString("HH:mm") == kqbc_detail.up_time.Value.ToString("HH:mm")) : info.FirstOrDefault(x => x.ls_time.Value.ToString("HH:mm") == kqbc_detail.down_time.Value.ToString("HH:mm"));
                    if (res == null)
                    {
                        item.state = 5; item.state_name = "无效打卡，当天休息";
                    }
                    else if (item.dcsj < res.start_time || item.dcsj > res.end_time)
                    {
                        item.state = 5; item.state_name = "无效打卡，不在有效打卡时间范围内";
                    }
                    else if (res.type == 1 && res.sj_time.HasValue && res.sj_time < item.dcsj)
                    {
                        item.state = 5; item.state_name = "无效打卡，以最早上班打卡时间为准";
                    }
                    else if (res.type == 2 && res.sj_time.HasValue && res.sj_time > item.dcsj)
                    {
                        item.state = 5; item.state_name = "无效打卡，以最晚下班打卡时间为准";
                    }
                    if (item.state != 5)
                    {
                        var kqbc_zhu = await db.Queryable<OaKqbc>().FirstAsync(x => x.id == kqbc_detail.main_id);
                        //上班且在打卡范围内
                        if (item.type == 1 && item.dcsj >= kqbc_detail.up_start && item.dcsj <= kqbc_detail.up_end)
                        {
                            //开启弹性打卡
                            if (kqbc_zhu.is_tx == 1)
                            {
                                //正常打卡（早于理论上班时间+弹性允许晚到时间）
                                if (item.dcsj <= kqbc_detail.up_time.Value.AddMinutes((double)kqbc_zhu.tx_down))
                                {
                                    if (item.dcsj <= kqbc_detail.up_time.Value)
                                    {
                                        item.zd_minutes = (int)(kqbc_detail.up_time.Value - item.dcsj).TotalMinutes;
                                    }
                                    else
                                    {
                                        item.wd_minutes = (int)(item.dcsj - kqbc_detail.up_time.Value).TotalMinutes;
                                    }
                                    item.state = 1;
                                }
                                else
                                {
                                    var minutes = (int)(item.dcsj - kqbc_detail.up_time.Value.AddMinutes((double)kqbc_zhu.tx_down)).TotalMinutes;
                                    //开启迟到旷工
                                    if (kqbc_zhu.is_cdkg == 1)
                                    {
                                        if (minutes >= kqbc_zhu.cdkg)
                                        {
                                            item.state = 11;
                                            item.minutes = minutes;
                                        }
                                        else
                                        {
                                            item.state = 2;
                                            item.minutes = minutes;
                                        }
                                    }
                                    else
                                    {
                                        item.state = 2;
                                        item.minutes = minutes;
                                    }
                                }
                            }
                            else if (kqbc_zhu.is_yx == 1)
                            {
                                //正常打卡（早于理论上班时间+异常允许晚到时间）
                                if (item.dcsj <= kqbc_detail.up_time.Value.AddMinutes((double)kqbc_zhu.yc_up))
                                {
                                    item.state = 1;
                                }
                                else
                                {
                                    var minutes = (int)(item.dcsj - kqbc_detail.up_time.Value.AddMinutes((double)kqbc_zhu.yc_up)).TotalMinutes;
                                    //开启迟到旷工
                                    if (kqbc_zhu.is_cdkg == 1)
                                    {
                                        if (minutes >= kqbc_zhu.cdkg)
                                        {
                                            item.state = 11;
                                            item.minutes = minutes;
                                        }
                                        else
                                        {
                                            item.state = 2;
                                            item.minutes = minutes;
                                        }
                                    }
                                    else
                                    {
                                        item.state = 2;
                                        item.minutes = minutes;
                                    }
                                }
                            }
                            else
                            {
                                //正常打卡（早于理论上班时间）
                                if (item.dcsj <= kqbc_detail.up_time)
                                {
                                    item.state = 1;
                                }
                                else
                                {
                                    var minutes = (int)(item.dcsj - kqbc_detail.up_time.Value).TotalMinutes;
                                    //开启迟到旷工
                                    if (kqbc_zhu.is_cdkg == 1)
                                    {
                                        if (minutes >= kqbc_zhu.cdkg)
                                        {
                                            item.state = 11;
                                            item.minutes = minutes;
                                        }
                                        else
                                        {
                                            item.state = 2;
                                            item.minutes = minutes;
                                        }
                                    }
                                    else
                                    {
                                        item.state = 2;
                                        item.minutes = minutes;
                                    }
                                }
                            }
                        }
                        //下班且在下班打卡范围内
                        else if (item.type == 2 && item.dcsj >= kqbc_detail.down_start && item.dcsj <= kqbc_detail.down_end)
                        {
                            //开启弹性打卡
                            if (kqbc_zhu.is_tx == 1)
                            {
                                //正常打卡（晚于理论下班时间+上班早到晚到时间）
                                if (item.dcsj >= kqbc_detail.down_time.Value.AddMinutes(last_record.zd_minutes == 0 ? last_record.wd_minutes : -last_record.zd_minutes))
                                {
                                    item.state = 1;
                                }
                                else
                                {
                                    var minutes = (int)(kqbc_detail.down_time.Value.AddMinutes(last_record.zd_minutes == 0 ? last_record.wd_minutes : -last_record.zd_minutes) - item.dcsj).TotalMinutes;
                                    //开启早退旷工
                                    if (kqbc_zhu.is_ztkg == 1)
                                    {
                                        if (minutes >= kqbc_zhu.ztkg)
                                        {
                                            item.state = 10;
                                            item.minutes = minutes;
                                        }
                                        else
                                        {
                                            item.state = 3;
                                            item.minutes = minutes;
                                        }
                                    }
                                    else
                                    {
                                        item.state = 3;
                                        item.minutes = minutes;
                                    }
                                }
                            }
                            else if (kqbc_zhu.is_yx == 1)
                            {
                                //正常打卡（晚于理论下班时间+允许异常时间）
                                if (item.dcsj >= kqbc_detail.down_time.Value.AddMinutes(-(double)kqbc_zhu.yc_down))
                                {
                                    item.state = 1;
                                }
                                else
                                {
                                    var minutes = (int)(kqbc_detail.down_time.Value.AddMinutes((double)kqbc_zhu.yc_down) - item.dcsj).TotalMinutes;
                                    //开启早退旷工
                                    if (kqbc_zhu.is_ztkg == 1)
                                    {
                                        if (minutes >= kqbc_zhu.ztkg)
                                        {
                                            item.state = 10;
                                            item.minutes = minutes;
                                        }
                                        else
                                        {
                                            item.state = 3;
                                            item.minutes = minutes;
                                        }
                                    }
                                    else
                                    {
                                        item.state = 3;
                                        item.minutes = minutes;
                                    }
                                }
                            }
                            else
                            {
                                //正常打卡（晚于理论下班时间）
                                if (item.dcsj >= kqbc_detail.down_time)
                                {
                                    item.state = 1;
                                }
                                else
                                {
                                    var minutes = (int)(kqbc_detail.down_time.Value - item.dcsj).TotalMinutes;
                                    //开启早退旷工
                                    if (kqbc_zhu.is_ztkg == 1)
                                    {
                                        if (minutes >= kqbc_zhu.ztkg)
                                        {
                                            item.state = 10;
                                            item.minutes = minutes;
                                        }
                                        else
                                        {
                                            item.state = 3;
                                            item.minutes = minutes;
                                        }
                                    }
                                    else
                                    {
                                        item.state = 3;
                                        item.minutes = minutes;
                                    }
                                }
                            }
                        }
                        info.RemoveAll(x => x.id == res.id);
                        info.Add(_imapper.Map<OaClockRecord, OaKqRecord>(item, res));
                    }
                    if (item.is_wq == 1) // 外勤打卡更新考勤记录
                    {
                        await db.Updateable<OaKqDay>().SetColumns(x => x.state == 2).Where(x => x.kq_code == res.kq_code).ExecuteCommandAsync();
                    }
                    await db.Updateable(item).ExecuteCommandAsync();
                    if (item.type == 1 && item.state != 5)
                    {
                        last_record = item;
                    }
                }
                await db.Insertable(info).ExecuteCommandAsync();
            }
        }


        public async Task<List<OaKqbcChildDto>> GetKqbcAsync(string server_id, int user_id, DateTime dt, SqlSugarClient db = null)
        {
            db ??= SqlSugarHelper.DBClient(server_id);

            var oaKqbcDay = await db.Queryable<OaKqbcDay>().FirstAsync(x => x.user_id == user_id && x.kq_date == dt.Date);
            var kqz_id = oaKqbcDay == null ? 0 : oaKqbcDay.kqz_id;
            var kqbc = oaKqbcDay == null ? 0 : oaKqbcDay.kqbc_id;

            if (kqbc == 0) //休息不用打卡
            {
                return new List<OaKqbcChildDto>();
            }
            var day_kqbc = await db.Queryable<OaKqbcChild>().Where(x => x.main_id == kqbc).ToListAsync();
            var user_data = _imapper.Map<List<OaKqbcChild>, List<OaKqbcChildDto>>(day_kqbc).OrderBy(x => x.up_time).ToList();
            user_data.ForEach(x => x.kqz_id = kqz_id);
            return user_data;
        }

        public async Task<bool> AddKqzAsync(string server_id, int user_id, CreateOaKqz input, SqlSugarClient db = null)
        {
            db ??= SqlSugarHelper.DBClient(server_id);
            var query = await db.Queryable<OaKqz>().CountAsync(x => x.name == input.name && x.is_delete == 0);
            if (query > 0)
            {
                throw new Exception("当前已有该名称的考勤组");
            }
            input = await CheckOnly(input, db);
            var info = _imapper.Map<CreateOaKqz, OaKqz>(input);
            var default_kqz = await db.Queryable<OaKqz>().CountAsync(x => x.is_default == 1 && x.is_delete == 0);
            if (default_kqz == 0)
            {
                info.is_default = 1;
            }
            else if (input.is_default == 1)
            {
                throw new Exception("只能存在一个默认考勤组");
            }
            info.id = Tools.GetEngineID(server_id);
            info.SetCreate(user_id);
            await db.Insertable(info).ExecuteCommandAsync();
            await InsertDept(server_id, info.id, user_id, input.oaKqzDept, db);
            await InsertWeek(server_id, info.id, user_id, input.oaKqzWeek, db);
            await InsertUser(server_id, info.id, user_id, input.oaKqzUser, db);
            await InsertTsrq(server_id, info.id, user_id, input.oaKqzTsrq, db);
            await InsertAddress(server_id, info.id, user_id, input.oaKqzAddress, db);

            if (input.isEnableToday == 1)
            {
                var users = input.oaKqzUser.Select(item => (int)item).ToList();
                Task.Run(() => UpdateKqRecord(server_id, input, users, info.id));
            }
            return true;
        }


        public async Task DelAsync(string server_id, long id, SqlSugarClient db = null)
        {
            db ??= SqlSugarHelper.DBClient(server_id);
            var info = await db.Queryable<OaKqz>().FirstAsync(x => x.id == id);
            if (info == null)
            {
                throw new Exception($"未找到考勤组记录");
            }
            var user_ids = await db.Queryable<OaKqzUser>().Where(it => it.kqz_id == id).ToListAsync();
            await db.Deleteable<OaKqbcDay>().Where(it => it.kqz_id == id && it.kq_date.Date == DateTime.Now.Date).ExecuteCommandAsync();
            await BatchDelete(info.id, db);
            await db.Deleteable(info).ExecuteCommandAsync();

        }
        public async Task BatchDelete(long id, SqlSugarClient db = null)
        {
            await db.Deleteable<OaKqzDept>().Where(it => it.kqz_id == id).ExecuteCommandAsync();
            await db.Deleteable<OaKqzUser>().Where(it => it.kqz_id == id).ExecuteCommandAsync();
            await db.Deleteable<OaKqzWeek>().Where(it => it.kqz_id == id).ExecuteCommandAsync();
            await db.Deleteable<OaKqzAddress>().Where(it => it.kqz_id == id).ExecuteCommandAsync();
            await db.Deleteable<OaKqzTsrq>().Where(it => it.kqz_id == id).ExecuteCommandAsync();
        }


        /// <summary>
        /// 检验输入内容
        /// </summary>
        /// <param name="input"></param>
        /// <param name="db"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public async Task<CreateOaKqz> CheckOnly(CreateOaKqz input, SqlSugarClient db)
        {
            var kqz = await db.Queryable<OaKqz>().Where(x => x.is_delete == 0).Select(x => x.id).ToListAsync();
            if (input.oaKqzUser != null && input.oaKqzUser.Count > 0)
            {
                var user = await db.Queryable<OaKqzUser>().Where(x => input.oaKqzUser.Contains(x.user_id) && x.kqz_id != input.id).Select(x => x.kqz_id).ToListAsync();
                if (user.Count > 0)
                {
                    if (kqz.Intersect(user).ToList().Count > 0)
                    {
                        throw new Exception("一个人只能存在于一个考勤组");
                    }
                }
            }
            if (input.oaKqzDept != null && input.oaKqzDept.Count > 0)
            {
                var dept = await db.Queryable<OaKqzDept>().Where(x => input.oaKqzDept.Contains(x.dept_id) && x.kqz_id != input.id).Select(x => x.kqz_id).ToListAsync();
                if (dept.Count > 0)
                {
                    if (kqz.Intersect(dept).ToList().Count > 0)
                    {
                        throw new Exception("一个部门只能存在于一个考勤组");
                    }
                }
            }
            var tsrqs = input.oaKqzTsrq.SelectMany(x => x.detail.Select(y => y.ts_date.Date)).ToList();
            if (tsrqs.Distinct().Count() != tsrqs.Count())
            {
                throw new Exception("特殊日期不能重复添加同一天");
            }
            if (input.oaKqzAddress.Select(x => x.address).Contains(""))
            {
                throw new Exception("考勤地点不能为空");
            }
            if (input.clock_mode.Count > 0)
            {
                if (input.clock_mode.Contains(1))
                    input.address_clock = 1;
                if (input.clock_mode.Contains(2))
                    input.photo_clock = 1;
                if (input.clock_mode.Contains(3))
                    input.wq_clock = 1;
                if (input.clock_mode.Contains(4))
                    input.wq_photo_clock = 1;
            }
            return input;
        }

        public async Task<(List<OaKqzDto>, int)> GetByPageAsync(string server_id, OaKqzQuery input)
        {
            RefAsync<int> totalCount = 0;
            using var db = SqlSugarHelper.DBClient(server_id);
            var list = await db.Queryable<OaKqz>()
                            .Where(x => x.is_delete == 0)
                            .Includes(x => x.kqz_users)
                            .Includes(x => x.kqz_depts)
                            .Includes(x => x.kqz_week.OrderBy(x => x.sort).ToList())
                            .Includes(x => x.kqz_tsrqs)
                            .Includes(x => x.kqz_addresss)
                            .Where(input.ToExp())
                            .OrderBy(x => x.is_default, OrderByType.Desc)
                            .ToPageListAsync(input.page_index, input.page_size, totalCount);
            var data = _imapper.Map<List<OaKqz>, List<OaKqzDto>>(list);
            data.ForEach(async x =>
            {
                ///先找休息日
                var xiuxi = x.oaKqzWeek.Where(x => x.kqbc_id == 0).Select(x => x.sort).ToList();
                if (xiuxi.Count > 0)
                {
                    x.kqsj += string.Join("、", xiuxi.Select(x => (SortWeekType)x).ToList());
                    x.kqsj += "  休息<br/>";
                }
                var info = x.oaKqzWeek.Where(x => x.kqbc_id != 0).OrderBy(x => x.sort).GroupBy(x => x.kqbc_id).ToList();
                foreach (var item in info)
                {
                    x.kqsj += string.Join("、", item.Select(x => (SortWeekType)x.sort).ToList());
                    x.kqsj += " " + await GetById(server_id, item.Key) + "<br/>";
                }
                if (!string.IsNullOrEmpty(x.kqsj))
                {
                    x.kqsj = x.kqsj.Remove(x.kqsj.Length - 5, 5);
                }
                if (x.address_clock == 1)
                    x.clock_mode.Add(1);
                if (x.photo_clock == 1)
                    x.clock_mode.Add(2);
                if (x.wq_clock == 1)
                    x.clock_mode.Add(3);
                if (x.wq_photo_clock == 1)
                    x.clock_mode.Add(4);
            });
            return (data, totalCount);
        }
        public async Task<string> GetById(string server_id, long id)
        {
            using var db = SqlSugarHelper.DBClient(server_id);
            var list = await db.Queryable<OaKqbcChild>()
                .Where(x => x.main_id == id)
                .OrderBy(x => x.up_time)
                .ToListAsync();
            string up_down_time = null;
            if (list.Count > 0)
            {
                var kqbc = await db.Queryable<OaKqbc>().FirstAsync(x => x.id == id);
                if (kqbc != null)
                {
                    up_down_time += $"{kqbc.name}:" + string.Join(" ", list.Select(x => new { day = (x.up_time.Value.ToString("HH:mm") + "-" + x.down_time.Value.ToString("HH:mm")) }).ToList().Select(r => r.day));
                }
            }
            return up_down_time;
        }

        public async Task<OaKqzDto> GetByIdAsync(string server_id, int user_id)
        {
            using var db = SqlSugarHelper.DBClient(server_id);
            var user = await db.Queryable<OaKqbcDay>().Where(x => x.user_id == user_id && x.kq_date == DateTime.Now.Date).FirstAsync();
            var user_kqz = await db.Queryable<OaKqz>().Where(x => x.is_delete == 0).Includes(x => x.kqz_users.Where(y => y.user_id == user_id).ToList()).ToListAsync();
            var kqz = user_kqz.FirstOrDefault(x => x.kqz_users.Count > 0);
            if (user == null && kqz == null)
            {
                throw new Exception("该用户暂不属于任何考勤组");
            }
            var kqz_id = user == null ? kqz.id : user.kqz_id;

            var info = await db.Queryable<OaKqz>()
                           .Includes(x => x.kqz_tsrqs.Where(y => y.ts_date.Value.Date.Month == DateTime.Now.Date.Month).ToList())
                           .Includes(x => x.kqz_addresss)
                           .Where(x => x.id == kqz_id)
                           .FirstAsync();
            var data = _imapper.Map<OaKqz, OaKqzDto>(info);
            if (user != null && user.kqbc_id != 0)
            {
                var kqbc = await db.Queryable<OaKqbc>().FirstAsync(x => x.id == user.kqbc_id);
                data.is_tx = kqbc.is_tx;
                data.tx_up = kqbc.tx_up;
                data.tx_down = kqbc.tx_down;
                data.is_cdkg = kqbc.is_cdkg;
                data.cdkg = kqbc.cdkg == null ? 0 : (int)kqbc.cdkg;
                data.is_ztkg = kqbc.is_ztkg;
                data.is_yx = kqbc.is_yx;
                data.ztkg = kqbc.ztkg == null ? 0 : (int)kqbc.ztkg;
                data.yc_up = kqbc.yc_up == null ? 0 : (int)kqbc.yc_up;
                data.yc_down = kqbc.yc_down == null ? 0 : (int)kqbc.yc_down;
            }
            return data;
        }

        public async Task UpdateDefault(string server_id, long id)
        {
            using var db = SqlSugarHelper.DBClient(server_id);
            var new_default = await db.Queryable<OaKqz>().FirstAsync(x => x.id == id);
            if (new_default == null)
            {
                throw new Exception("未找到该考勤组");
            }
            var default_kqz = await db.Queryable<OaKqz>().FirstAsync(x => x.is_default == 1 && x.is_delete == 0);
            if (default_kqz.id == id)
            {
                throw new Exception("默认考勤组必须存在，可以将其他考勤组设置为默认");
            }
            default_kqz.is_default = 0;
            new_default.is_default = 1;
            await db.Updateable(new_default).UpdateColumns(x => x.is_default).ExecuteCommandAsync();
            await db.Updateable(default_kqz).UpdateColumns(x => x.is_default).ExecuteCommandAsync();

        }
        public int GetKqbc(OaKqz oaKqz, DateTime dt)
        {
            var day = (int)dt.DayOfWeek;
            if (day == 0) day = 7;

            var bcid = oaKqz.kqz_week?.FirstOrDefault(x => x.sort == day);
            return bcid == null ? 0 : bcid.kqbc_id;
        }

        public async Task InsertDept(string server_id, long id, int user_id, List<int> context, SqlSugarClient db = null)
        {
            var dept_list = new List<OaKqzDept>();
            if (context != null && context.Count > 0)
            {
                context.ForEach(x =>
                {
                    var file = new OaKqzDept()
                    {
                        id = Tools.GetEngineID(server_id),
                        kqz_id = id,
                        dept_id = x,
                        created_id = user_id,
                        created_date = DateTime.Now
                    };
                    dept_list.Add(file);
                });

                await db.Insertable(dept_list).ExecuteCommandAsync();
            }
        }
        public async Task InsertWeek(string server_id, long id, int user_id, List<CreateOaKqzWeek> context, SqlSugarClient db = null)
        {
            var week_list = new List<OaKqzWeek>();
            if (context != null && context.Count > 0)
            {
                context.ForEach(x =>
                {
                    var week = new OaKqzWeek()
                    {
                        id = Tools.GetEngineID(server_id),
                        kqz_id = id,
                        kqbc_id = x.kqbc_id,
                        sort = x.sort,
                        created_id = user_id,
                        created_date = DateTime.Now
                    };
                    week_list.Add(week);
                });

                await db.Insertable(week_list).ExecuteCommandAsync();
            }
        }
        public async Task InsertUser(string server_id, long id, int user_id, List<long> context, SqlSugarClient db = null)
        {
            var user_list = new List<OaKqzUser>();
            if (context != null && context.Count > 0)
            {
                context.ForEach(x =>
                {
                    var user = new OaKqzUser()
                    {
                        id = Tools.GetEngineID(server_id),
                        kqz_id = id,
                        user_id = x,
                        created_id = user_id,
                        created_date = DateTime.Now
                    };
                    user_list.Add(user);
                });

                await db.Insertable(user_list).ExecuteCommandAsync();
            }
        }
        public async Task InsertTsrq(string server_id, long id, int user_id, List<CreateOaKqzTsrq> context, SqlSugarClient db = null)
        {
            var tsrq_list = new List<OaKqzTsrq>();
            if (context != null && context.Count > 0)
            {
                context.ForEach(x =>
                {
                    x.detail.ForEach(r =>
                    {
                        var tsrq = new OaKqzTsrq()
                        {
                            id = Tools.GetEngineID(server_id),
                            kqz_id = id,
                            ts_date = r.ts_date,
                            kqbc_id = r.kqbc_id,
                            type = x.type,
                            remark = r.remark,
                            created_id = user_id,
                            created_date = DateTime.Now
                        };
                        tsrq_list.Add(tsrq);
                    });
                });

                await db.Insertable(tsrq_list).ExecuteCommandAsync();
            }
        }
        public async Task InsertAddress(string server_id, long id, int user_id, List<CreateOaKqzAddress> context, SqlSugarClient db = null)
        {
            var address_list = new List<OaKqzAddress>();
            if (context != null && context.Count > 0)
            {
                context.ForEach(x =>
                {
                    var tsrq = new OaKqzAddress()
                    {
                        id = Tools.GetEngineID(server_id),
                        kqz_id = id,
                        lat = x.lat,
                        lon = x.lon,
                        address = x.address,
                        range = x.range == null ? 0 : (int)x.range,
                        created_id = user_id,
                        created_date = DateTime.Now
                    };
                    address_list.Add(tsrq);
                });

                await db.Insertable(address_list).ExecuteCommandAsync();
            }
        }


    }
}
