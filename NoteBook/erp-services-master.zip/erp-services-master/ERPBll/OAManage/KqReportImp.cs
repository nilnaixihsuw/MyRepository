﻿using ERPBll.ApprovalForm.Contracts;
using ERPBll.RedisManage.Dicts;
using ERPBll.RedisManage.Users;
using ERPCore.Enums;
using ERPDal;
using ERPModel.ApprovalForm;
using ERPModel.Oamanage;
using ERPModel.Oamanage.OaKqbcs;
using ERPModel.Oamanage.OaKqDays;
using ERPModel.Oamanage.OaKqRecords;
using ERPModel.Oamanage.OaKqzs;
using ERPModel.PersonalManage;
using ERPModel.UserManage;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.OAManage
{
    public class KqReportImp : IKqReportImp
    {
        private readonly IUserRedisImp _userRedisImp;
        private readonly IDictRedisManageImp _iDictRedisManageImp;
        public KqReportImp(IUserRedisImp userRedisImp,
            IDictRedisManageImp iDictRedisManageImp)
        {
            _userRedisImp = userRedisImp;
            _iDictRedisManageImp = iDictRedisManageImp;
        }
        public async Task<Tuple<List<DayKqDto>, int>> GetDayKqData(DayKqRequest request)
        {
            using var DB = SqlSugarHelper.DBClient(request.server_id);
            var persons = await _userRedisImp.GetAllAsync();
            if (request.is_dimission == 1)
            {
                persons = persons.Where(r => (r.d_dimission_date > DateTime.Now.AddDays(-90) || r.d_dimission_date == null) && (r.i_is_driver == 0 || r.i_is_driver == null)).ToList();
            }
            else
            {
                persons = persons.Where(r => r.c_state == "1" && (r.i_emp_state == 1 || r.i_emp_state == null) && (r.i_is_driver == 0 || r.i_is_driver == null)).ToList();
            }

            var dep_pers = await DB.Queryable<SysDepPerson>().ToListAsync();
            RefAsync<int> totalNumber = 0;
            var records = await DB.Queryable<OaKqRecord>()
                .WhereIF(request.start != null, r => r.kq_date >= request.start && r.kq_date <= request.end)
                .WhereIF(request.kqz_id > 0, r => r.kqz_id == request.kqz_id)
                .WhereIF(request.user_ids != null && request.user_ids.Count > 0, r => request.user_ids.Contains(r.user_id))
                .WhereIF(request.dept_ids != null && request.dept_ids.Count > 0, r => dep_pers.Where(m => request.dept_ids.Contains(m.i_group_id.Value)).Select(m => m.i_child_id).Contains(r.user_id))
                .Where(r => persons.Select(m => m.i_id).Contains(r.user_id))
                .ToListAsync();
            var groups = records.GroupBy(r => new { r.user_id, r.kq_date }).OrderBy(r => r.Key.user_id).ThenBy(r => r.Key.kq_date).ToList();
            var kqzs = await DB.Queryable<OaKqz>().Where(r => r.is_delete == 0)
                .Includes(r => r.kqz_users).ToListAsync();
            var kqbcs = await DB.Queryable<OaKqbc>()
                .Includes(r => r.child).ToListAsync();
            var dic = await _iDictRedisManageImp.GetAllAsync();
            var workovers = await DB.Queryable<OaWorkOvertime>().Where(r => r.state == 2).ToListAsync();
            var attendances = await DB.Queryable<OaAttendanceRecord>().ToListAsync();
            var kqbc_days = await DB.Queryable<OaKqbcDay>().ToListAsync();
            var kq_days = await DB.Queryable<OaKqDay>().WhereIF(request.start != null, r => r.kq_date >= request.start && r.kq_date <= request.end).ToListAsync();

            var list = new List<DayKqDto>();
            foreach (var user_id in records.Select(r => r.user_id).Distinct())
            {
                var temp1 = new DayKqDto();
                temp1.user_id = user_id;
                temp1.user_name = persons.Find(r => r.i_id == temp1.user_id).c_name;
                temp1.job_level = dic.Find(r => r.i_id == persons.Find(r => r.i_id == temp1.user_id).i_job_level)?.c_name;
                temp1.group_id = persons.Find(r => r.i_id == temp1.user_id).i_department_base;
                temp1.group_name = persons.Find(r => r.i_id == temp1.user_id).department_main_name;
                if (kqzs.Exists(r => r.kqz_users.Select(r => r.user_id).Contains(Convert.ToInt64(user_id))))
                {
                    temp1.kqz_id = (int)kqzs.Find(r => r.kqz_users.Select(r => r.user_id).Contains(Convert.ToInt64(user_id))).id;
                    temp1.kqz_name = kqzs.Find(r => r.id == temp1.kqz_id)?.name;
                }
                for (var i = request.start; i < request.end; i = i.Value.AddDays(1))
                {
                    var temp = Tools.DeepCopy(temp1);
                    temp.date = i.Value.ToString("yyyy-MM-dd");
                    if (kqbcs.Exists(r => r.id == kqbc_days.Find(r => r.kq_date.ToString("yyyy-MM-dd") == temp.date && r.user_id == user_id)?.kqbc_id))
                    {
                        var kqbc = kqbcs.Find(r => r.id == kqbc_days.Find(r => r.kq_date.ToString("yyyy-MM-dd") == temp.date && r.user_id == user_id).kqbc_id);
                        temp.kqbc = kqbc.name;
                        foreach (var item1 in kqbc.child.OrderBy(r => r.up_time))
                        {
                            temp.kqbc += $" {item1.up_time.Value.ToString("HH:mm")}-{item1.down_time.Value.ToString("HH:mm")}";
                        }
                    }
                   
                    if (!kq_days.Exists(r => r.user_id == user_id && r.kq_date.ToString("yyyy-MM-dd") == temp.date))
                    {
                        list.Add(temp);
                        continue;
                    }
                    if (kq_days.Exists(r => r.user_id == user_id && r.kq_date.ToString("yyyy-MM-dd") == temp.date && r.state == 0))
                    {
                        temp.rest_day = 1;
                        list.Add(temp);
                        continue;
                    }
                    var item = groups.Find(r => r.Key.user_id == user_id && r.Key.kq_date.ToString("yyyy-MM-dd") == temp.date);
                    if (item == null) continue;
                    var a = item.OrderBy(r => r.ls_time).ToList();
                    int index = 1;
                    double work_time = 0;
                    foreach (var item1 in a)
                    {
                        if (item1.type == 1)
                        {
                            switch (index)
                            {
                                case 1:
                                    temp.on_work_time1 = item1.sj_time.HasValue ? item1.sj_time.Value.ToString("HH:mm") : "";
                                    if (item1.state == 2 || item1.state == 3)
                                    {
                                        temp.on_work_result1 = !string.IsNullOrEmpty(item1.state_name) ? item1.state_name : $"{kq_state[item1.state]}{item1.value}分钟";
                                    }
                                    else
                                    {
                                        temp.on_work_result1 = !string.IsNullOrEmpty(item1.state_name) ? item1.state_name : $"{kq_state[item1.state]}";
                                    }
                                    break;
                                case 2:
                                    temp.on_work_time2 = item1.sj_time.HasValue ? item1.sj_time.Value.ToString("HH:mm") : "";
                                    if (item1.state == 2 || item1.state == 3)
                                    {
                                        temp.on_work_result2 = !string.IsNullOrEmpty(item1.state_name) ? item1.state_name : $"{kq_state[item1.state]}{item1.value}分钟";
                                    }
                                    else
                                    {
                                        temp.on_work_result2 = !string.IsNullOrEmpty(item1.state_name) ? item1.state_name : $"{kq_state[item1.state]}";
                                    }
                                    break;
                                case 3:
                                    temp.on_work_time3 = item1.sj_time.HasValue ? item1.sj_time.Value.ToString("HH:mm") : "";
                                    if (item1.state == 2 || item1.state == 3)
                                    {
                                        temp.on_work_result3 = !string.IsNullOrEmpty(item1.state_name) ? item1.state_name : $"{kq_state[item1.state]}{item1.value}分钟";
                                    }
                                    else
                                    {
                                        temp.on_work_result3 = !string.IsNullOrEmpty(item1.state_name) ? item1.state_name : $"{kq_state[item1.state]}";
                                    }
                                    break;
                            }
                        }
                        if (item1.type == 2)
                        {
                            switch (index)
                            {
                                case 1:
                                    temp.off_work_time1 = item1.sj_time.HasValue ? item1.sj_time.Value.ToString("HH:mm") : "";
                                    if (item1.state == 2 || item1.state == 3)
                                    {
                                        temp.off_work_result1 = !string.IsNullOrEmpty(item1.state_name) ? item1.state_name : $"{kq_state[item1.state]}{item1.value}分钟";
                                    }
                                    else
                                    {
                                        temp.off_work_result1 = !string.IsNullOrEmpty(item1.state_name) ? item1.state_name : $"{kq_state[item1.state]}";
                                    }
                                    if (!string.IsNullOrEmpty(temp.on_work_time1) && !string.IsNullOrEmpty(temp.off_work_time1))
                                    {
                                        work_time += (Convert.ToDateTime(temp.off_work_time1) - Convert.ToDateTime(temp.on_work_time1)).TotalMinutes;
                                    }
                                    break;
                                case 2:
                                    temp.off_work_time2 = item1.sj_time.HasValue ? item1.sj_time.Value.ToString("HH:mm") : "";
                                    if (item1.state == 2 || item1.state == 3)
                                    {
                                        temp.off_work_result2 = !string.IsNullOrEmpty(item1.state_name) ? item1.state_name : $"{kq_state[item1.state]}{item1.value}分钟";
                                    }
                                    else
                                    {
                                        temp.off_work_result2 = !string.IsNullOrEmpty(item1.state_name) ? item1.state_name : $"{kq_state[item1.state]}";
                                    }
                                    if (!string.IsNullOrEmpty(temp.on_work_time2) && !string.IsNullOrEmpty(temp.off_work_time2))
                                    {
                                        work_time += (Convert.ToDateTime(temp.off_work_time2) - Convert.ToDateTime(temp.on_work_time2)).TotalMinutes;
                                    }
                                    break;
                                case 3:
                                    temp.off_work_time3 = item1.sj_time.HasValue ? item1.sj_time.Value.ToString("HH:mm") : "";
                                    if (item1.state == 2 || item1.state == 3)
                                    {
                                        temp.off_work_result3 = !string.IsNullOrEmpty(item1.state_name) ? item1.state_name : $"{kq_state[item1.state]}{item1.value}分钟";
                                    }
                                    else
                                    {
                                        temp.off_work_result3 = !string.IsNullOrEmpty(item1.state_name) ? item1.state_name : $"{kq_state[item1.state]}";
                                    }
                                    if (!string.IsNullOrEmpty(temp.on_work_time3) && !string.IsNullOrEmpty(temp.off_work_time3))
                                    {
                                        work_time += (Convert.ToDateTime(temp.off_work_time3) - Convert.ToDateTime(temp.on_work_time3)).TotalMinutes;
                                    }
                                    break;
                            }
                            index++;
                        }
                    }
                    if (work_time > 0) temp.work_time = Math.Round(work_time, 2);
                    if (a.Exists(r => r.state > 0 && r.state != 5))
                    {
                        temp.work_day = 1;
                    }
                    //if (a.Exists(r => r.state == 10))
                    //{
                    //    temp.absenteeism_early_day = 1;
                    //}
                    //if (a.Exists(r => r.state == 11))
                    //{
                    //    temp.absenteeism_late_day = 1;
                    //}

                    temp.absenteeism_late_day = a.Where(r => r.type == 1 && r.state == 11).Count();
                    temp.absenteeism_late_day = temp.absenteeism_late_day == 0 ? null : temp.absenteeism_late_day;

                    temp.absenteeism_early_day = a.Where(r => r.type == 2 &&  r.state == 10).Count();
                    temp.absenteeism_early_day = temp.absenteeism_early_day == 0 ? null : temp.absenteeism_early_day;

                    if (a.Where(r => r.state == 5).Count() == a.Count())
                    {
                        temp.absenteeism_day = 1;
                    }
                    temp.late_count = a.Where(r => r.type == 1 && (r.state == 2 || r.state == 11)).Count();
                    temp.late_count = temp.late_count == 0 ? null : temp.late_count;

                    temp.late_time = a.Where(r => r.type == 1 && (r.state == 2 || r.state == 11)).Sum(r => r.value);
                    temp.late_time = temp.late_time == 0 ? null : temp.late_time;

                    temp.early_count = a.Where(r => r.type == 2 && (r.state == 3 || r.state == 10)).Count();
                    temp.early_count = temp.early_count == 0 ? null : temp.early_count;

                    temp.early_time = a.Where(r => r.type == 2 && (r.state == 3 || r.state == 10)).Sum(r => r.value);
                    temp.early_time = temp.early_time == 0 ? null : temp.early_time;

                    temp.on_lack_count = a.Where(r => r.type == 1 && r.state == 5).Count();
                    temp.on_lack_count = temp.on_lack_count == 0 ? null : temp.on_lack_count;

                    temp.off_lack_count = a.Where(r => r.type == 2 && r.state == 5).Count();
                    temp.off_lack_count = temp.off_lack_count == 0 ? null : temp.off_lack_count;

                    var attendance = attendances.Where(r => r.user_id == temp.user_id && r.date.ToString("yyyy-MM-dd") == temp.date).ToList();
                    if (attendance.Exists(r => r.type == 1))
                    {
                        var b = attendance.Where(r => r.type == 1).ToList();

                        temp.offical_leave = b.Where(r => r.type_child == 1).Sum(r => r.duration);
                        temp.offical_leave = temp.offical_leave == 0 ? null : temp.offical_leave;

                        temp.affair_leave = b.Where(r => r.type_child == 2).Sum(r => r.duration);
                        temp.affair_leave = temp.affair_leave == 0 ? null : temp.affair_leave;

                        temp.funeral_leave = b.Where(r => r.type_child == 3).Sum(r => r.duration);
                        temp.funeral_leave = temp.funeral_leave == 0 ? null : temp.funeral_leave;

                        temp.sick_leave = b.Where(r => r.type_child == 4).Sum(r => r.duration);
                        temp.sick_leave = temp.sick_leave == 0 ? null : temp.sick_leave;

                        temp.annual_leave = b.Where(r => r.type_child == 5).Sum(r => r.duration);
                        temp.annual_leave = temp.annual_leave == 0 ? null : temp.annual_leave;

                        temp.marriage_leave = b.Where(r => r.type_child == 6).Sum(r => r.duration);
                        temp.marriage_leave = temp.marriage_leave == 0 ? null : temp.marriage_leave;

                        temp.maternity_leave = b.Where(r => r.type_child == 7).Sum(r => r.duration);
                        temp.maternity_leave = temp.maternity_leave == 0 ? null : temp.maternity_leave;

                        temp.breast_feeding_leave = b.Where(r => r.type_child == 8).Sum(r => r.duration);
                        temp.breast_feeding_leave = temp.breast_feeding_leave == 0 ? null : temp.breast_feeding_leave;

                        temp.industrial_hurt_leave = b.Where(r => r.type_child == 9).Sum(r => r.duration);
                        temp.industrial_hurt_leave = temp.industrial_hurt_leave == 0 ? null : temp.industrial_hurt_leave;
                    }
                    if (attendance.Exists(r => r.type == 2))
                    {
                        var workover = workovers.Where(r => attendance.Where(r => r.type == 2).Select(m => m.main_id).Contains(r.id)).ToList();
                        if (workover != null && workover.Count() > 0)
                        {
                            temp.holiday_overwork_time = workover.Where(r => r.type == 1).Sum(r => r.hour);
                            temp.holiday_overwork_time = temp.holiday_overwork_time == 0 ? null : temp.holiday_overwork_time;

                            temp.rest_overwork_time = workover.Where(r => r.type == 2).Sum(r => r.hour);
                            temp.rest_overwork_time = temp.rest_overwork_time == 0 ? null : temp.rest_overwork_time;

                            temp.work_overwork_time = workover.Where(r => r.type == 3).Sum(r => r.hour);
                            temp.work_overwork_time = temp.work_overwork_time == 0 ? null : temp.work_overwork_time;

                            temp.overwork_fee = workover.Sum(r => r.fee);
                            temp.overwork_fee = temp.overwork_fee == 0 ? null : temp.overwork_fee;

                            temp.overwork_time = workover.Sum(r => r.hour);
                            temp.overwork_time = temp.overwork_time == 0 ? null : temp.overwork_time;
                        }
                    }
                    if (attendance.Exists(r => r.type == 3))
                    {
                        temp.business_type = attendance.Where(r => r.type == 3).Sum(r => r.duration);
                        temp.business_type = temp.business_type == 0 ? null : temp.business_type;
                    }
                    list.Add(temp);

                }
            }

            totalNumber = list.Count;
            if (request.page_index > 0 && request.page_size > 0)
            {
                list = list.Skip((request.page_index - 1) * request.page_size).Take(request.page_size).ToList();
            }
            return new Tuple<List<DayKqDto>, int>(list, totalNumber);
        }

        public async Task<Tuple<List<MonthKqDto>, int>> GetMonthKqData(MonthKqRequest request)
        {
            using var DB = SqlSugarHelper.DBClient(request.server_id);
            var persons = await _userRedisImp.GetAllAsync();
            if (request.is_dimission == 1)
            {
                persons = persons.Where(r => (r.d_dimission_date > DateTime.Now.AddDays(-90) || r.d_dimission_date == null) && (r.i_is_driver == 0 || r.i_is_driver == null)).ToList();
            }
            else
            {
                persons = persons.Where(r => r.c_state == "1" && (r.i_emp_state == 1 || r.i_emp_state == null) && (r.i_is_driver == 0 || r.i_is_driver == null)).ToList();
            }

            RefAsync<int> totalNumber = 0;
            var dep_pers = await DB.Queryable<SysDepPerson>().ToListAsync();
            var records = await DB.Queryable<OaKqRecord>()
                .WhereIF(request.start != null, r => r.kq_date >= request.start && r.kq_date <= request.end)
                .WhereIF(request.kqz_id > 0, r => r.kqz_id == request.kqz_id)
                .WhereIF(request.user_ids != null && request.user_ids.Count > 0, r => request.user_ids.Contains(r.user_id))
                .WhereIF(request.dept_ids != null && request.dept_ids.Count > 0, r => dep_pers.Where(m => request.dept_ids.Contains(m.i_group_id.Value)).Select(m => m.i_child_id).Contains(r.user_id))
                .Where(r => persons.Select(m => m.i_id).Contains(r.user_id))
                .ToListAsync();
            var groups = records.GroupBy(r => r.user_id).OrderBy(r => r.Key).ToList();
            var kqzs = await DB.Queryable<OaKqz>().Where(r => r.is_delete == 0)
                .Includes(r => r.kqz_users).ToListAsync();
            var kqbcs = await DB.Queryable<OaKqbc>()
                .Includes(r => r.child).ToListAsync();
            var dic = await _iDictRedisManageImp.GetAllAsync();
            var workovers = await DB.Queryable<OaWorkOvertime>().Where(r => r.state == 2).ToListAsync();
            var attendances = await DB.Queryable<OaAttendanceRecord>().ToListAsync();
            var kqz_users = await DB.Queryable<OaKqzUser>().ToListAsync();
            var kq_days = await DB.Queryable<OaKqDay>()
                 .WhereIF(request.start != null, r => r.kq_date >= request.start && r.kq_date <= request.end).ToListAsync();

            totalNumber = groups.Count;
            var list = new List<MonthKqDto>();
            if (request.page_index > 0 && request.page_size > 0)
            {
                groups = groups.Skip((request.page_index - 1) * request.page_size).Take(request.page_size).ToList();
            }
            foreach (var user_id in records.Select(r => r.user_id).Distinct())
            {
                var temp = new MonthKqDto();
                temp.user_id = user_id;
                temp.user_name = persons.Find(r => r.i_id == temp.user_id).c_name;
                temp.job_level = dic.Find(r => r.i_id == persons.Find(r => r.i_id == temp.user_id).i_job_level)?.c_name;
                temp.group_id = persons.Find(r => r.i_id == temp.user_id).i_department_base;
                temp.group_name = persons.Find(r => r.i_id == temp.user_id).department_main_name;
                if (kqzs.Exists(r => r.kqz_users.Select(r => r.user_id).Contains(Convert.ToInt64(user_id))))
                {
                    temp.kqz_id = (int)kqzs.Find(r => r.kqz_users.Select(r => r.user_id).Contains(Convert.ToInt64(user_id))).id;
                    temp.kqz_name = kqzs.Find(r => r.id == temp.kqz_id)?.name;
                }

                var a = groups.Find(r => r.Key == user_id).OrderBy(r => r.sj_time).ToList();
                temp.rest_day = kq_days.Count(r => r.user_id == user_id && r.state == 0);
                temp.rest_day = temp.rest_day == 0 ? null : temp.rest_day;
                temp.work_day = kq_days.Count(r => r.user_id == user_id && r.state == 1);
                temp.work_day = temp.work_day == 0 ? null : temp.work_day;

                temp.absenteeism_day = kq_days.Count(r => r.user_id == user_id && r.state == 3); ;
                temp.absenteeism_day = temp.absenteeism_day == 0 ? null : temp.absenteeism_day;

                temp.absenteeism_early_day = a.Where(r => r.state == 10).Count();
                temp.absenteeism_early_day = temp.absenteeism_early_day == 0 ? null : temp.absenteeism_early_day;

                temp.absenteeism_late_day = a.Where(r => r.state == 11).Count();
                temp.absenteeism_late_day = temp.absenteeism_late_day == 0 ? null : temp.absenteeism_late_day;
                if (a.Count() > 1)
                {
                    double work_time = 0;
                    for (int i = 0; i < a.Count; i++)
                    {
                        if (a[i].type == 2 && a[i].sj_time.HasValue && a[i - 1].type == 1 && a[i - 1].sj_time.HasValue)
                        {
                            work_time += (a[i].sj_time.Value - a[i - 1].sj_time.Value).TotalMinutes;
                        }
                    }
                    if (work_time > 0) temp.work_time = Math.Round(work_time, 2);
                }
                
                temp.late_count = a.Where(r => r.type == 1 && (r.state == 2 || r.state == 11)).Count();
                temp.late_count = temp.late_count == 0 ? null : temp.late_count;

                temp.late_time = a.Where(r => r.type == 1 && (r.state == 2 || r.state == 11)).Sum(r => r.value);
                temp.late_time = temp.late_time == 0 ? null : temp.late_time;

                temp.early_count = a.Where(r => r.type == 2 && (r.state == 3 || r.state == 10)).Count();
                temp.early_count = temp.early_count == 0 ? null : temp.early_count;

                temp.early_time = a.Where(r => r.type == 2 && (r.state == 3 || r.state == 10)).Sum(r => r.value);
                temp.early_time = temp.early_time == 0 ? null : temp.early_time;

                temp.on_lack_count = a.Where(r => r.type == 1 && r.state == 5).Count();
                temp.on_lack_count = temp.on_lack_count == 0 ? null : temp.on_lack_count;

                temp.off_lack_count = a.Where(r => r.type == 2 && r.state == 5).Count();
                temp.off_lack_count = temp.off_lack_count == 0 ? null : temp.off_lack_count;

                var attendance = attendances.Where(r => r.user_id == temp.user_id && r.date >= request.start && r.date <= request.end).ToList();
                if (attendance.Exists(r => r.type == 1))
                {
                    var b = attendance.Where(r => r.type == 1).ToList();

                    temp.offical_leave = b.Where(r => r.type_child == 1).Sum(r => r.duration);
                    temp.offical_leave = temp.offical_leave == 0 ? null : temp.offical_leave;

                    temp.affair_leave = b.Where(r => r.type_child == 2).Sum(r => r.duration);
                    temp.affair_leave = temp.affair_leave == 0 ? null : temp.affair_leave;

                    temp.funeral_leave = b.Where(r => r.type_child == 3).Sum(r => r.duration);
                    temp.funeral_leave = temp.funeral_leave == 0 ? null : temp.funeral_leave;

                    temp.sick_leave = b.Where(r => r.type_child == 4).Sum(r => r.duration);
                    temp.sick_leave = temp.sick_leave == 0 ? null : temp.sick_leave;

                    temp.annual_leave = b.Where(r => r.type_child == 5).Sum(r => r.duration);
                    temp.annual_leave = temp.annual_leave == 0 ? null : temp.annual_leave;

                    temp.marriage_leave = b.Where(r => r.type_child == 6).Sum(r => r.duration);
                    temp.marriage_leave = temp.marriage_leave == 0 ? null : temp.marriage_leave;

                    temp.maternity_leave = b.Where(r => r.type_child == 7).Sum(r => r.duration);
                    temp.maternity_leave = temp.maternity_leave == 0 ? null : temp.maternity_leave;

                    temp.breast_feeding_leave = b.Where(r => r.type_child == 8).Sum(r => r.duration);
                    temp.breast_feeding_leave = temp.breast_feeding_leave == 0 ? null : temp.breast_feeding_leave;

                    temp.industrial_hurt_leave = b.Where(r => r.type_child == 9).Sum(r => r.duration);
                    temp.industrial_hurt_leave = temp.industrial_hurt_leave == 0 ? null : temp.industrial_hurt_leave;
                }
                if (attendance.Exists(r => r.type == 2))
                {
                    //var b = attendance.Where(r => r.type == 2).ToList();
                    //temp.holiday_overwork_time = b.Where(r => r.type_child == 1).Sum(r => r.duration);
                    //temp.rest_overwork_time = b.Where(r => r.type_child == 2).Sum(r => r.duration);
                    //temp.work_overwork_time = b.Where(r => r.type_child == 3).Sum(r => r.duration);

                    //var workover = workovers.Where(r => r.user_id == temp.user_id && r.start_time <= request.start && r.end_time >= request.end);
                    var workover = workovers.Where(r => attendance.Where(r => r.type == 2).Select(m => m.main_id).Contains(r.id)).ToList();
                    if (workover != null && workover.Count() > 0)
                    {
                        temp.holiday_overwork_time = workover.Where(r => r.type == 1).Sum(r => r.hour);
                        temp.holiday_overwork_time = temp.holiday_overwork_time == 0 ? null : temp.holiday_overwork_time;

                        temp.rest_overwork_time = workover.Where(r => r.type == 2).Sum(r => r.hour);
                        temp.rest_overwork_time = temp.rest_overwork_time == 0 ? null : temp.rest_overwork_time;

                        temp.work_overwork_time = workover.Where(r => r.type == 3).Sum(r => r.hour);
                        temp.work_overwork_time = temp.work_overwork_time == 0 ? null : temp.work_overwork_time;

                        temp.overwork_fee = workover.Sum(r => r.fee);
                        temp.overwork_fee = temp.overwork_fee == 0 ? null : temp.overwork_fee;

                        temp.overwork_time = workover.Sum(r => r.hour);
                        temp.overwork_time = temp.overwork_time == 0 ? null : temp.overwork_time;
                    }
                }
                if (attendance.Exists(r => r.type == 3))
                {
                    temp.business_type = attendance.Where(r => r.type == 3).Sum(r => r.duration);
                    temp.business_type = temp.business_type == 0 ? null : temp.business_type;
                }
                list.Add(temp);

            }
            return new Tuple<List<MonthKqDto>, int>(list, totalNumber);
        }

        public async Task<MonthKqDetailDto> GetMonthKqDetailData(MonthKqDetailRequest request)
        {
            var r = new MonthKqDetailDto();
            using var DB = SqlSugarHelper.DBClient(request.server_id);
            var persons = await _userRedisImp.GetAllAsync();
            //persons = persons.Where(r => r.c_state == "1" && (r.i_emp_state == 1 || r.i_emp_state == null) && (r.i_is_driver == 0 || r.i_is_driver == null)).ToList();

            RefAsync<int> totalNumber = 0;
            var records = await DB.Queryable<OaKqRecord>()
                .WhereIF(request.start != null, r => r.kq_date >= request.start && r.kq_date <= request.end)
                .WhereIF(request.user_ids != null && request.user_ids.Count > 0, r => request.user_ids.Contains(r.user_id))
                .ToListAsync();
            var kqbcs = await DB.Queryable<OaKqbc>().ToListAsync();
            var kqzs = await DB.Queryable<OaKqz>().ToListAsync();

            //获取表头
            r.titles.Add("user_id", "用户ID");
            r.titles.Add("user_name", "姓名");
            r.titles.Add("kqbc", "班次");
            r.titles.Add("kqz", "考勤组");
            if (request.start != null && request.end != null)
            {
                for (var i = request.start; i <= request.end; i = i.Value.AddDays(1))
                {
                    r.titles.Add(i.Value.ToString("yyyyMMdd"), $"{i.Value.Day}({(DayOfWeekEnumsSimple)i.Value.DayOfWeek})");
                }
            }

            records.GroupBy(it => it.user_id).ToList().ForEach(item =>
            {
                var obj = new Dictionary<string, object>();
                obj.Add("user_id", item.Key);
                obj.Add("user_name", persons.Find(m => m.i_id == item.Key)?.c_name);

                //每天详细情况
                if (request.start != null && request.end != null)
                {
                    var a = item.OrderBy(r => r.kq_date).ToList();
                    string kqbc_name = kqbcs.Find(r => r.id == Convert.ToInt64(a.Last().kqbc_id))?.name;
                    foreach (var item1 in a.Where(r => r.kq_date == a.Last().kq_date).OrderBy(r=>r.ls_time))
                    {
                        var b = item1.ls_time.HasValue ? item1.ls_time.Value.ToString("HH:mm") : "";
                        if (item1.type == 1)
                        {
                            if (!string.IsNullOrEmpty(b) && !string.IsNullOrEmpty(kqbc_name)) kqbc_name += $" {b}";
                        }
                        if (item1.type == 2)
                        {
                            if (!string.IsNullOrEmpty(b) && !string.IsNullOrEmpty(kqbc_name)) kqbc_name += $"-{b}";
                        }
                    }
                    obj.Add("kqbc", kqbc_name);
                    obj.Add("kqz", kqzs.Find(r => r.id == Convert.ToInt64(a.Last().kqz_id))?.name);

                    for (var i = request.start.Value; i <= request.end.Value; i = i.AddDays(1))
                    {
                        //每天的详细情况 正常,加班,请假
                        var detail = "";
                        if (records.Exists(it => it.kq_date.ToString("yyyy-MM-dd") == i.ToString("yyyy-MM-dd") && it.user_id == item.Key))
                        {
                            a = records.Where(it => it.kq_date.ToString("yyyy-MM-dd") == i.ToString("yyyy-MM-dd") && it.user_id == item.Key).ToList();
                            if (a.Exists(m => m.state != 1))
                            {
                                if (a.Exists(m => m.state == 2)) detail += string.IsNullOrEmpty(detail)? "迟到":  "，迟到";
                                if (a.Exists(m => m.state == 3)) detail += string.IsNullOrEmpty(detail) ? "早退" : "，早退";
                                if (a.Exists(m => m.state == 4)) detail += string.IsNullOrEmpty(detail) ? "异常打卡" : "，异常打卡";
                                if (a.Exists(m => m.state == 5)) detail += string.IsNullOrEmpty(detail) ? "缺卡" : "，缺卡";
                                if (a.Exists(m => m.state == 10)) detail += string.IsNullOrEmpty(detail) ? "旷工早退" : "，旷工早退";
                                if (a.Exists(m => m.state == 11)) detail += string.IsNullOrEmpty(detail) ? "旷工迟到" : "，旷工迟到";
                            }
                            else
                            {
                                detail = "正常";
                            }
                        }
                        //else
                        //{
                        //    if (i.DayOfWeek == DayOfWeek.Saturday || i.DayOfWeek == DayOfWeek.Sunday)
                        //    {
                        //        detail = "休息";
                        //    }
                        //    else
                        //    {
                        //        detail = "正常";
                        //    }
                        //}
                        obj.Add(i.ToString("yyyyMMdd"), detail);
                    }
                }
                r.datas.Add(obj);
            });

            r.total = r.datas.Count;
            r.page_index = request.page_index;
            r.page_size = request.page_size;

            if (request.page_index > 0 && request.page_size > 0)
            {
                r.datas = r.datas.Skip((request.page_index - 1) * request.page_size).Take(request.page_size).ToList();
            }
            return r;
        }

        private Dictionary<int, string> kq_state = new Dictionary<int, string>()
        {
            { 0,"未打卡"},
            { 1,"正常"},
            { 2,"迟到"},
            { 3,"早退"},
            { 4,"异常打卡"},
            { 5,"缺卡"},
            { 10,"旷工早退"},
            { 11,"旷工迟到"},
            { 12,"未计入考勤组"},
        };
    }
}
