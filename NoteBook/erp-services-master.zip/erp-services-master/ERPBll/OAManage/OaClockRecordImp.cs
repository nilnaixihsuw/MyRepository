﻿using AutoMapper;
using ERPCore.Entity;
using ERPCore.Enums;
using ERPCore.ORM;
using ERPDal;
using ERPDal.UserManage;
using ERPModel.Oamanage;
using ERPModel.Oamanage.OaClockRecords;
using ERPModel.Oamanage.OaKqbcs;
using ERPModel.Oamanage.OaKqDays;
using ERPModel.Oamanage.OaKqRecords;
using ERPModel.Oamanage.OaKqzs;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ERPBll.OAManage
{
    public class OaClockRecordImp : BusinessRespository<OaClockRecord, IOaClockRecordDataImp>, IOaClockRecordImp
    {
        private readonly IMapper _imapper;
        private readonly IOaKqzImp _kqzImp;
        private readonly IOaKqRecordImp _kqRecordImp;
        private readonly ISysPersonDataImp _iSysPersonDataImp;
        private readonly IOaRestAttendanceStatisticsImp _oaRestAttendanceStatisticsImp;

        public OaClockRecordImp(
             IMapper imapper, IOaKqzImp kqzImp,
             ISysPersonDataImp iSysPersonDataImp,
             IOaKqRecordImp kqRecordImp,
             IOaRestAttendanceStatisticsImp oaRestAttendanceStatisticsImp,
            IOaClockRecordDataImp dataImp) : base(dataImp)
        {
            _imapper = imapper;
            _kqzImp = kqzImp;
            _kqRecordImp = kqRecordImp;
            _oaRestAttendanceStatisticsImp = oaRestAttendanceStatisticsImp;
            _iSysPersonDataImp = iSysPersonDataImp;
        }
        public async Task<OaClockRecordDto> AddOaClockRecordAsync(string server_id, CreateOaClockRecord input)
        {
            using (var db = SqlSugarHelper.DBClient(server_id))
            {
                var info = _imapper.Map<CreateOaClockRecord, OaClockRecord>(input);
                info.id = Tools.GetEngineID(server_id);

                var kq = _imapper.Map<CreateOaClockRecord, KqClock>(input);

                //更新实际打卡
                var (res, msg) = await _kqRecordImp.UpdateAsync(server_id, kq);
                if (!res)
                {
                    info.state = 5;
                    info.state_name = msg;
                }
                await db.Insertable(info).ExecuteCommandAsync();

                return _imapper.Map<OaClockRecord, OaClockRecordDto>(info);
            }
        }

        public async Task<OaClockRecordDetailResponse> OaClockRecordDetailAsync(ClockRecordStatisticsRequest request)
        {
            using var db = SqlSugarHelper.DBClient(request.server_id);
            var r = new OaClockRecordDetailResponse();
            if (request.kqzs_id != null && request.kqzs_id.Count > 0)
            {
                var user_list = await db.Queryable<OaKqz>().Where(x => request.kqzs_id.Contains(x.id)).Includes(x => x.kqz_users).ToListAsync();
                var userids = new List<decimal> { };
                foreach (var item in user_list)
                {
                    item.kqz_users.ForEach(x =>
                    {
                        userids.Add(x.user_id);
                    });
                }
                if (userids.Count > 0)
                {
                    request.users_id = userids;
                }
            }
            var exp = Expressionable.Create<OaClockRecord>()
                                    .AndIF(request.date != null && request.date.Count == 2, it => it.kqri >= request.date[0] && it.kqri <= request.date[1])
                                    .AndIF(request.users_id != null && request.users_id.Count > 0, it => SqlFunc.ContainsArray(request.users_id, it.user_id));
            if (request.depts_id != null && request.depts_id.Count > 0)
            {
                var emps = await _iSysPersonDataImp.List(request.server_id, it => SqlFunc.ContainsArray(request.depts_id, it.i_department_base));
                if (emps.Count > 0)
                {
                    var ids = emps.Select(it => it.i_id).ToList();
                    exp.And(it => SqlFunc.ContainsArray(ids, it.user_id));
                }
                else
                {
                    exp.And(it => false);
                }
            }
            if (request.contain_dimission != null && !request.contain_dimission.Value)
            {
                var emps = await _iSysPersonDataImp.List(request.server_id, it => it.i_emp_state == 0 && SqlFunc.DateAdd(it.d_dimission_date.Value, 90) < DateTime.Now);
                if (emps.Count > 0)
                {
                    var ids = emps.Select(it => it.i_id).ToList();
                    exp.And(it => SqlFunc.ContainsArray(ids, it.user_id));
                }
                else
                {
                    exp.And(it => false);
                }
            }
            var list = await _dataImp.List(request.server_id, exp.ToExpression());
            list = await _dataImp.ExtList(request.server_id, list);
            list = list.OrderByDescending(x => x.kqri).OrderByDescending(x => x.dcsj).OrderBy(x => x.user_id).ToList();

            r.titles.Add("user_name", "姓名");
            r.titles.Add("kqz_name", "考勤组");
            r.titles.Add("dept_name", "部门");
            r.titles.Add("work_id", "工号");
            r.titles.Add("position", "岗位");
            r.titles.Add("kqri", "考勤日期");
            r.titles.Add("kqsj", "考勤时间");
            r.titles.Add("dksj", "打卡时间");
            r.titles.Add("state", "打卡结果");
            r.titles.Add("address", "打卡地址");
            r.titles.Add("remark", "打卡备注");
            var kqz_name = await db.Queryable<OaKqz>().Select(x => new { id = x.id, name = x.name }).ToListAsync();
            list.ForEach(item =>
            {
                var obj = new Dictionary<string, object>();
                obj.Add("user_name", item.user_name);
                obj.Add("kqz_name", kqz_name.FirstOrDefault(x => x.id == item.kqz_id)?.name);
                obj.Add("dept_name", item.dept_name);
                obj.Add("work_id", item.work_id);
                obj.Add("position", item.position);
                obj.Add("kqri", item.kqri.ToString("yyyy-MM-dd HH:mm:ss"));
                obj.Add("kqsj", item.kqsj.ToString("yyyy-MM-dd HH:mm:ss"));
                obj.Add("dksj", item.dcsj.ToString("yyyy-MM-dd HH:mm:ss"));
                obj.Add("state", item.state_name == null ? (item.state == 1 ? ((KqClockStateType)item.state).ToString() : ((KqClockStateType)item.state).ToString() + item.minutes + "分钟") : item.state_name);
                obj.Add("address", item.address);
                obj.Add("remark", item.remark);
                r.datas.Add(obj);
            });
            r.total = r.datas.Count;
            if (request.page_index > 0 && request.page_size > 0)
            {
                r.datas = r.datas.Skip((request.page_index - 1) * request.page_size).Take(request.page_size).ToList();
            }

            r.page_index = request.page_index;
            r.page_size = request.page_size;

            return r;
        }

        public async Task<OaClockRecordDetailResponse> OaClockRecordTimeAsync(ClockRecordStatisticsRequest request)
        {
            using var db = SqlSugarHelper.DBClient(request.server_id);
            var r = new OaClockRecordDetailResponse();
            if (request.kqzs_id != null && request.kqzs_id.Count > 0)
            {
                var user_list = await db.Queryable<OaKqz>().Where(x => request.kqzs_id.Contains(x.id)).Includes(x => x.kqz_users).ToListAsync();
                var userids = new List<decimal> { };
                foreach (var item in user_list)
                {
                    item.kqz_users.ForEach(x =>
                    {
                        userids.Add(x.user_id);
                    });
                }
                if (userids.Count > 0)
                {
                    request.users_id = userids;
                }
            }
            var exp = Expressionable.Create<OaClockRecord>()
                                    .AndIF(request.date != null && request.date.Count == 2, it => it.kqri >= request.date[0] && it.kqri <= request.date[1])
                                    .AndIF(request.users_id != null && request.users_id.Count > 0, it => SqlFunc.ContainsArray(request.users_id, it.user_id));

            if (request.depts_id != null && request.depts_id.Count > 0)
            {
                var emps = await _iSysPersonDataImp.List(request.server_id, it => SqlFunc.ContainsArray(request.depts_id, it.i_department_base));
                if (emps.Count > 0)
                {
                    var ids = emps.Select(it => it.i_id).ToList();
                    exp.And(it => SqlFunc.ContainsArray(ids, it.user_id));
                }
                else
                {
                    exp.And(it => false);
                }
            }
            if (request.contain_dimission != null && !request.contain_dimission.Value)
            {
                var emps = await _iSysPersonDataImp.List(request.server_id, it => it.i_emp_state == 0 && SqlFunc.DateAdd(it.d_dimission_date.Value, 90) < DateTime.Now);
                if (emps.Count > 0)
                {
                    var ids = emps.Select(it => it.i_id).ToList();
                    exp.And(it => !SqlFunc.ContainsArray(ids, it.user_id));
                }
                else
                {
                    exp.And(it => false);
                }
            }
            var list = await _dataImp.List(request.server_id, exp.ToExpression());
            list = await _dataImp.ExtList(request.server_id, list);
            list = list.OrderBy(x => x.kqri).ToList();
            r.titles.Add("user_name", "姓名");
            r.titles.Add("kqz_name", "考勤组");
            r.titles.Add("dept_name", "部门");
            r.titles.Add("work_id", "工号");
            r.titles.Add("position", "岗位");
            if (request.date[0] != null && request.date[1] != null)
            {
                for (var i = request.date[0]; i <= request.date[1]; i = i.AddDays(1))
                {
                    r.titles.Add(i.ToString("yyyyMMdd"), $"{(int)i.Month}-{i.Day}({(DayOfWeekEnumsSimple)i.DayOfWeek})");
                }
            }
            var users = await db.Queryable<OaKqz>().Where(x => x.is_delete == 0).Includes(x => x.kqz_users).ToListAsync();
            var usersid = new List<OaKqzUser>();
            foreach (var user in users.Select(x => x.kqz_users))
            {
                usersid.AddRange(user);
            }
            var kqz_ids = usersid.Select(x => new
            {
                user_id = x.user_id,
                kqz_id = x.kqz_id
            }).ToList();
            var kqz_name = await db.Queryable<OaKqz>().Select(x => new { id = x.id, name = x.name }).ToListAsync();
            list.GroupBy(x => new { x.user_name, x.user_id, x.dept_name, x.work_id, x.position }).ToList().ForEach(item =>
            {
                var obj = new Dictionary<string, object>();
                obj.Add("user_name", item.Key.user_name);
                obj.Add("kqz_name", kqz_name.FirstOrDefault(x => x.id == (kqz_ids.FirstOrDefault(x => x.user_id == item.Key.user_id) == null ? 0 : kqz_ids.FirstOrDefault(x => x.user_id == item.Key.user_id).kqz_id))?.name);
                obj.Add("dept_name", item.Key.dept_name);
                obj.Add("work_id", item.Key.work_id);
                obj.Add("position", item.Key.position);
                if (request.date != null && request.date.Count == 2 && request.date[0] <= request.date[1])
                {
                    for (var i = request.date[0]; i <= request.date[1]; i = i.AddDays(1))
                    {
                        var clock_detail = "";
                        if (list.Exists(it => it.kqri.ToString("yyyy-MM-dd") == i.ToString("yyyy-MM-dd") && it.user_id == item.Key.user_id))
                        {
                            var record = list.Where(it => it.kqri.ToString("yyyy-MM-dd") == i.ToString("yyyy-MM-dd") && it.user_id == item.Key.user_id).ToList().OrderBy(x => x.dcsj).ToList();
                            record.ForEach(item =>
                            {
                                clock_detail += " " + item.dcsj.ToString("HH:mm") + " (" + (item.state_name == null ? ((ClockStateType)item.state).ToString() : item.state_name) + ")";
                            });

                        }
                        else
                        {
                            if (i.DayOfWeek == DayOfWeek.Saturday || i.DayOfWeek == DayOfWeek.Sunday)
                            {
                                clock_detail = "休息";
                            }
                            else
                            {
                                clock_detail = "缺卡";
                            }
                        }
                        obj.Add(i.ToString("yyyyMMdd"), clock_detail);
                    }
                }
                r.datas.Add(obj);
            });
            r.total = r.datas.Count;
            if (request.page_index > 0 && request.page_size > 0)
            {
                r.datas = r.datas.Skip((request.page_index - 1) * request.page_size).Take(request.page_size).ToList();
            }

            r.page_index = request.page_index;
            r.page_size = request.page_size;

            return r;
        }
        public async Task<DayClockResponse> GetOaClockDetailAsync(GetClockDetailRequest input)
        {
            using var db = SqlSugarHelper.DBClient(input.server_id);
            var data = new DayClockResponse();
            var request = new RequestRest()
            {
                user_id = input.user_id,
                start_time = input.date.Value.Date,
                end_time = input.date.Value.AddDays(1).Date.AddMinutes(-1)
            };
            data.responseRests = await _oaRestAttendanceStatisticsImp.GetUserRestAsync(input.server_id, request);
            var info = await db.Queryable<OaKqRecord>().Where(x => x.user_id == input.user_id && x.kq_date.Date == input.date.Value.Date).OrderBy(x => x.ls_time).ToListAsync();
            var data_total = _imapper.Map<List<OaKqRecord>, List<OaKqRecordDto>>(info);
            var kqbc_child = await _kqzImp.GetKqbcAsync(input.server_id, input.user_id, (DateTime)input.date);
            if (kqbc_child.Count > 0)
            {
                var kqbc = await db.Queryable<OaKqbc>().FirstAsync(x => x.id == kqbc_child.First().main_id);
                data.kqbc += kqbc.name + ": ";
                foreach (var bc in kqbc_child)
                {
                    var down_time = info.Where(x => x.type == 2 && x.ls_time.Value.ToString("HH:mm") == bc.down_time.Value.ToString("HH:mm")).FirstOrDefault();
                    var up_time = info.Where(x => x.type == 1 && x.ls_time.Value.ToString("HH:mm") == bc.up_time.Value.ToString("HH:mm")).FirstOrDefault();
                    if (up_time != null && down_time != null && up_time.sj_time != null && down_time.sj_time != null)
                    {
                        data.total_hour += (down_time.sj_time - up_time.sj_time).Value.TotalHours;
                    }
                    data.kqbc += bc.up_time.Value.ToString("HH:mm") + "-" + bc.down_time.Value.ToString("HH:mm") + ",";
                }
                data.kqbc = data.kqbc.Remove(data.kqbc.Length - 1, 1);
            }
            data.count = data_total.Where(x => x.sj_time != null).ToList().Count;
            data.oaClockRecords = data_total;
            return data;
        }
        public async Task UpdateClockStateAsync(UpdateClockStateRequest input, ClientInformation client)
        {
            using var db = SqlSugarHelper.DBClient(input.server_id);
            var record = await db.Queryable<OaKqRecord>().FirstAsync(x => x.id == input.id);
            if (record == null)
            {
                throw new Exception("未找到该考勤记录");
            }
            if (input.state == 1)
            {
                record.sj_time = record.ls_time;
                record.state_name = $"管理员{client.c_name}将打卡结果修改为:{(KqClockStateType)input.state}";
            }
            else if (input.state == 2)
            {
                record.sj_time = record.ls_time.Value.AddMinutes((double)input.minutes);
                record.state_name = $"管理员{client.c_name}将打卡结果修改为:{(KqClockStateType)input.state}{input.minutes}分钟";
            }
            else if (input.state == 3)
            {
                record.sj_time = record.ls_time.Value.AddMinutes((double)-input.minutes);
                record.state_name = $"管理员{client.c_name}将打卡结果修改为:{(KqClockStateType)input.state}{input.minutes}分钟";
            }
            else if (input.state == 5)
            {
                record.state_name = $"管理员{client.c_name}将打卡结果修改为:{(KqClockStateType)input.state}";
            }
            if (input.state > 1 && input.state != 5)
            {
                await db.Updateable<OaKqDay>().SetColumns(it => it.is_yc == 1).Where(it => it.kq_code == record.kq_code).ExecuteCommandAsync();
            }
            else
            {
                var is_yc = await db.Queryable<OaKqRecord>().Where(x => x.kq_code == record.kq_code).ToListAsync();
                if (is_yc.Count(x => x.state == 1 || x.state == 0) == is_yc.Count)
                {
                    await db.Updateable<OaKqDay>().SetColumns(it => it.state == 1).Where(it => it.kq_code == record.kq_code).ExecuteCommandAsync();
                }
            }
            record.state = input.state;
            record.value = (int)input.minutes;
            await db.Updateable(record).ExecuteCommandAsync();
            if (input.state != 5)
            {
                var dk_data = new OaClockRecord()
                {
                    id = Tools.GetEngineID(input.server_id),
                    user_id = record.user_id,
                    kqz_id = (int)record.kqz_id,
                    kqri = record.kq_date,
                    kqsj = (DateTime)record.ls_time,
                    dcsj = (DateTime)record.sj_time,
                    type = (int)record.type,
                    state_name = record.state_name,
                    minutes = (input.minutes == null) ? 0 : (int)input.minutes,
                    state = input.state
                };
                await db.Insertable(dk_data).ExecuteCommandAsync();
            }
        }
        public async Task<List<MonthClockResponse>> GetOaClockAsync(GetOaClockRequest input)
        {
            using var db = SqlSugarHelper.DBClient(input.server_id);
            if (input.state != 7)
            {
                var record = await db.Queryable<OaKqRecord>()
                .WhereIF(input.state != 8 && input.state != 9 && input.state != 2 && input.state != 3, x => x.user_id == input.user_id && x.state == input.state && x.kq_date >= input.start_date && x.kq_date <= input.end_date)
                .WhereIF(input.state == (int)KqClockStateType.迟到, x => x.user_id == input.user_id && (x.state == 2 || x.state == 11) && x.kq_date >= input.start_date && x.kq_date <= input.end_date)
                .WhereIF(input.state == (int)KqClockStateType.早退, x => x.user_id == input.user_id && (x.state == 3 || x.state == 10) && x.kq_date >= input.start_date && x.kq_date <= input.end_date)
                .WhereIF(input.state == (int)KqClockStateType.上班缺卡, x => x.user_id == input.user_id && x.state == 5 && x.kq_date >= input.start_date && x.kq_date <= input.end_date && x.type == 1)
                .WhereIF(input.state == (int)KqClockStateType.下班缺卡, x => x.user_id == input.user_id && x.state == 5 && x.kq_date >= input.start_date && x.kq_date <= input.end_date && x.type == 2)
                .ToListAsync();
                if (record == null)
                {
                    return new List<MonthClockResponse>();
                }
                var data = record.Select(x => new MonthClockResponse()
                {
                    kqsj = x.ls_time.Value.ToString("yyyy-MM-dd HH:mm:ss"),
                    dksj = (x.sj_time == null) ? null : x.sj_time,
                    kqbc = GetKqbc(x.kqbc_id, db),
                    kq_result = x.value == 0 ? ((input.state == 8 || input.state == 9) ? ((KqClockStateType)input.state).ToString() : ((KqClockStateType)x.state).ToString()) :
                    (x.value >= 60 ? (x.value % 60 == 0 ? ((KqClockStateType)x.state).ToString() + x.value / 60 + "小时" : ((KqClockStateType)x.state).ToString() + x.value / 60 + "小时" + x.value % 60 + "分钟") :
                    ((KqClockStateType)x.state).ToString() + x.value + "分钟")
                }).ToList();
                return data;
            }
            else
            {
                //旷工
                //var users_kq = await db.Queryable<OaKqRecord>()
                //        .Where(x => x.user_id == input.user_id && x.state == 5 && x.kq_date >= input.start_date && x.kq_date <= input.end_date)
                //        .GroupBy(x => new { x.kq_code, x.state, x.kq_date, x.kqbc_id, })
                //        .Select(x => new { x.kq_code, x.state, x.kq_date, x.kqbc_id, count = SqlFunc.AggregateCount(x.state) })
                //        .ToListAsync();
                var users_kq = await db.Queryable<OaKqDay>().Where(x => x.user_id == input.user_id && x.state == 3 && x.kq_date >= input.start_date && x.kq_date <= input.end_date).ToListAsync();
                var kqbc = await db.Queryable<OaKqbcDay>().Where(x => x.user_id == input.user_id && x.kq_date >= input.start_date && x.kq_date <= input.end_date).ToListAsync();
                var kq_kg = users_kq.Select(x => new MonthClockResponse()
                {
                    kqsj = x.kq_date.ToString("yyyy-MM-dd"),
                    kqbc = GetKqbc(kqbc.First(x => x.kq_date.Date == x.kq_date.Date).kqbc_id, db),
                    kq_result = "旷工"
                }).ToList();
                return kq_kg;
            }
        }

        public string GetKqbc(int? id, SqlSugarClient db)
        {
            var bc = db.Queryable<OaKqbc>().Includes(x => x.child).First(x => x.id == id);
            if (bc == null)
            {
                return null;
            }
            var kqbc = bc.name + " (";
            foreach (var item in bc.child)
            {
                kqbc += item.up_time.Value.ToString("HH:mm") + "-" + item.down_time.Value.ToString("HH:mm") + " ";
            }
            kqbc = kqbc.Remove(kqbc.Length - 1, 1);
            kqbc += ")";
            return kqbc;
        }
    }
}
