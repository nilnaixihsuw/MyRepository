﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPModel.ApiModel.OAManage;
using ERPModel.Oamanage;
using ERPModel.OAManage;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.OAManage
{
    public interface IOaRestMainImp
    {
        Task<List<RestFormDataDto>> GetByPageAsync(string server_id, decimal? user_id, OaRestRequest request);

        Task<OaRestMain> AddAsymc(string server_id, ClientInformation client, RestFormData input, SqlSugarClient db);

        Task<RestTimeDetail> GetTimeDetail(string server_id, GetHourRequest request);
    }
}