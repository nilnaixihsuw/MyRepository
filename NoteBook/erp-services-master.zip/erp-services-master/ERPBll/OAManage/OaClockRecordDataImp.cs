﻿using ERPCore.ORM;
using ERPDal.UserManage;
using ERPModel.Oamanage.OaClockRecords;
using Microsoft.Extensions.Options;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.OAManage
{
    public class OaClockRecordDataImp : BaseDataRepository<OaClockRecord>, IOaClockRecordDataImp
    {
        private readonly ISysPersonDataImp _iSysPersonDataImp;

        ///<Summary>
        ///构造方法
        ///</Summary>
        public OaClockRecordDataImp(
            ISysPersonDataImp iSysPersonDataImp,
            IOptions<SugarOption> options) : base(options)
        {
            _iSysPersonDataImp = iSysPersonDataImp;
        }

        public override async Task<List<OaClockRecord>> ExtList(string serverId, List<OaClockRecord> list)
        {
            var emps = await _iSysPersonDataImp.ExtList(serverId,
                await _iSysPersonDataImp.List(serverId,
                    it => SqlFunc.ContainsArray(list.Select(it => it.user_id).ToList(), it.i_id),
                    new string[] { "I_ID", "C_NAME", "I_DEPARTMENT_BASE", "C_WORKER_ID", "I_POSITION_ID" }
                )
            );

            list.ForEach(item =>
            {
                if (emps.Count > 0 && emps.Exists(it => it.i_id == item.user_id))
                {
                    var emp = emps.Find(it => it.i_id == item.user_id);
                    item.user_name = emp.c_name;
                    item.dept_name = emp.department_main_name;
                    item.work_id = emp.c_worker_id;
                    item.position = emp.position_name;
                }
            });
            return list;
        }
    }
}