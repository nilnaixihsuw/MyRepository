﻿using ERPModel.Oamanage.OaGoodReceives;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.OAManage
{
    public interface IOaGoodReceiveImp
    {
        /// <summary>
        /// 获取详情
        /// </summary>
        Task<OaGoodReceiveDto> GetById(string server_id, decimal? user_id, int id);

        /// <summary>
        /// 提交物品领用
        /// </summary>
        Task<OaGoodReceiveDto> AddAsync(string server_id, decimal? user_id, GoodReceiveFormData input, SqlSugarClient db = null);
    }
}
