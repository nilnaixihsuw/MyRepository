﻿using AutoMapper;
using ERPBll.FlowManage.Contracts;
using ERPDal;
using ERPModel.FlowManage;
using ERPModel.FlowManage.FlowRecords;
using ERPModel.Oamanage.OaGoodReceives;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ERPBll.OAManage
{
    public class OaGoodReceiveImp : IOaGoodReceiveImp
    {
        private readonly IMapper _imapper;
        private readonly IErpFlowRecordImp _erpFlowRecordImp;

        public OaGoodReceiveImp(
            IMapper imapper,
            IErpFlowRecordImp erpFlowRecordImp)
        {
            _imapper = imapper;
            _erpFlowRecordImp = erpFlowRecordImp;
        }

        public async Task<OaGoodReceiveDto> GetById(string server_id, decimal? user_id, int id)
        {
            var query = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<OaGoodReceive>()
                                .Mapper(x => x.person_info, x => x.user_id)
                                .Mapper(x => x.dept_info, x => x.dept_id)
                                .Mapper(x => x.details, x => x.details.First().main_id)
                                .Mapper(x => x.files, x => x.files.First().main_id)
                                .FirstAsync(x => x.id == id);
            if (query == null || query.id < 1)
            {
                throw new Exception("未找到物品领用记录，id=" + id);
            }

            if (query.state == 1)//审核中
            {
                var all = await _erpFlowRecordImp.GetListAsync(server_id, user_id,
                  new FlowRecordQuery()
                  {
                      detail_ids = new List<int>() { query.id }
                  });

                var info = all.FirstOrDefault(x => x.detail_id == query.id);
                if (info != null)
                {
                    query.user_ids = info.state_child_id;
                    query.user_names = info.state_child_name;
                }
            }

            return _imapper.Map<OaGoodReceive, OaGoodReceiveDto>(query);
        }

        public async Task<OaGoodReceiveDto> AddAsync(string server_id, decimal? user_id, GoodReceiveFormData input, SqlSugarClient db = null)
        {
            if(db == null)
            {
                db = SqlSugarHelper.DBClient(server_id);
            }
            if (input.step_data == null || input.step_data.Count < 1)
            {
                throw new Exception("审批流程数据为空");
            }
            input.step_data.Where(x => x.oper_type == 1).ToList().ForEach(x =>
            {
                if (x.users.Count < 1)
                {
                    throw new Exception("审批节点人员不能为空");
                }
                if (x.users.Count > 15)
                {
                    throw new Exception("审批节点人员最多15人");
                }
            });

            var info = _imapper.Map<CreateOaGoodReceive, OaGoodReceive>(input.form_data);
            info.id = ERPBll.Tools.GetEngineID(server_id);
            info.created_id = user_id;
            info.created_date = DateTime.Now;

            //发起流程
            var flow = await _erpFlowRecordImp.StartAsync(server_id, user_id, input.step_data, db);
            if (flow == null)
            {
                throw new Exception("发起物品领用流程失败");
            }
            await _erpFlowRecordImp.UpdateAsync(server_id, flow.id, info.id, GoodReceiveMessage.GetContent(info), "", db);
            info.flow_id = flow.id;
            info.flow_code = flow.code;
            info.state = 1;

            await db.Insertable(info).ExecuteCommandAsync();

            //领用物品
            if (input.form_data.details != null && input.form_data.details.Count > 0)
            {
                await AddDetailAsync(server_id, user_id, info.id, input.form_data.details, db);
            }

            //附件
            if (input.form_data.files != null && input.form_data.files.Count > 0)
            {
                await AddFileAsync(server_id, user_id, info.id, input.form_data.files, db);
            }
            return _imapper.Map<OaGoodReceive, OaGoodReceiveDto>(info);
        }

        /// <summary>
        /// 新增物品领用明细
        /// </summary>
        public async Task AddDetailAsync(
            string server_id, decimal? user_id, int id, List<CreateOaGoodReceiveDetail> input, SqlSugarClient db = null)
        {
            var list = _imapper.Map<List<CreateOaGoodReceiveDetail>, List<OaGoodReceiveDetail>>(input);
            list.ForEach(x =>
            {
                x.id = ERPBll.Tools.GetEngineID(server_id);
                x.main_id = id;
                x.created_id = user_id;
                x.created_date = DateTime.Now;
            });

            await db.Insertable(list).ExecuteCommandAsync();
        }

        /// <summary>
        /// 新增物品领用附件
        /// </summary>
        public async Task AddFileAsync(
            string server_id, decimal? user_id, int id, List<OaGoodReceiveFile> input, SqlSugarClient db = null)
        {
            input.ForEach(x =>
            {
                x.id = ERPBll.Tools.GetEngineID(server_id);
                x.main_id = id;
                x.created_id = user_id;
                x.created_date = DateTime.Now;
            });

            await db.Insertable(input).ExecuteCommandAsync();
        }
    }
}
