﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.HangfireManage
{
    public interface IMaintMaintainRulePlanJobImp
    {
        Task Execute();

        /// <summary>
        /// 自动创建保养维修记录
        /// </summary>
        /// <param name="server_id"></param>
        /// <returns></returns>
        Task AddToRepair(string server_id);

    }
}
