﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ERPBll.HangfireManage
{
    public interface IVehicleCacheJobImp
    {
        void ExecuteJob();
    }
}
