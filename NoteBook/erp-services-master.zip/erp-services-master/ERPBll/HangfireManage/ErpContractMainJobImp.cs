﻿using ERPBll.EnterpriseManage.RentManage;
using ERPBll.RedisManage.Dicts;
using ERPBll.SystemManage;
using ERPBll.WorkPlace;
using ERPCore;
using ERPCore.Entity;
using ERPCore.ORM;
using ERPDal;
using ERPModel.EnterpriseManage.RentManage;
using ERPModel.Workplace;
using Microsoft.Extensions.Configuration;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.HangfireManage
{
    public class ErpContractMainJobImp : IErpContractMainJobImp
    {
        private readonly IErpContractMainImp _iErpContractMainImp;
        private readonly IConfiguration _configuration;
        private readonly IErpMessageRuleImp _iErpMessageRule;
        private readonly IErpMessageMainImp _iErpMessageMainImp;
        private readonly IDictRedisManageImp _iDictRedisManageImp;
        public ErpContractMainJobImp(IErpContractMainImp iErpContractMainImp,
            IDictRedisManageImp iDictRedisManageImp,
            IErpMessageRuleImp iErpMessageRule,
            IErpMessageMainImp iErpMessageMainImp,
            IConfiguration configuration)
        {
            _iErpContractMainImp = iErpContractMainImp;
            _iDictRedisManageImp = iDictRedisManageImp;
            _iErpMessageRule = iErpMessageRule;
            _iErpMessageMainImp = iErpMessageMainImp;
            _configuration = configuration;
        }
        public async Task Execute()
        {
            try
            {
                GlobalFunc.LogInfo(typeof(ErpContractMainJobImp), "开始检查合同记录!");
                //获取ServerIds
                var serverIds = _configuration.GetSection("Sugar").Get<SugarOption>().ProjectConfig.ConfigList["Server"].Select(it => it.Url).ToList();
                //var dic = await _iDictRedisManageImp.GetByKeyAsync("contract_state");
                foreach (var serverId in serverIds)
                {
                    var records = await _iErpContractMainImp.List(serverId, null);
                    var rules = await _iErpMessageRule.List(serverId, r => r.rule_type == 10 || r.rule_type == 20 && r.valid == 1);
                    if (records.Exists(r => r.end_date < DateTime.Now && r.state == 1))
                    {
                        var a = records.Where(r => r.end_date < DateTime.Now && r.state == 1).ToList();//超期状态未变更记录
                        a.ForEach(r => r.state = 2);
                        await _iErpContractMainImp.Update(serverId, a);

                        if (rules != null && rules.Count > 0 && !string.IsNullOrEmpty(rules[0].warn_person))
                        {
                            foreach (var item in a)
                            {
                                foreach (var item1 in rules[0].warn_person.Split(','))
                                {
                                    ErpMessageMain erpMessageMain = new ErpMessageMain();
                                    erpMessageMain.type = 2;
                                    erpMessageMain.model = (int)MessageModelDic.合同过期提醒;
                                    erpMessageMain.object_id = item.id.ToString();
                                    erpMessageMain.created_id = Convert.ToDecimal(item1);
                                    erpMessageMain.title = $"租房(广告)合同{item.name}于{DateTime.Now:yyyy-MM-dd}已过期，请及时查看";
                                    await _iErpMessageMainImp.AddErpMessageMain(serverId, erpMessageMain, new ClientInformation { i_id = 2000000 });
                                }
                            }
                        }
                    }

                    if (rules.Exists(r => r.rule_type == 10))
                    {
                        var rule = rules.Find(r => r.rule_type == 10 && r.message_type == 2);
                        var a = records.Where(r => r.end_date > DateTime.Now && r.state == 1).ToList();
                        if (rule != null && rule.warn_day != null && rule.warn_day > 0)
                        {
                            foreach (var item in a)
                            {
                                var start = item.end_date.AddDays(-Convert.ToDouble(rule.warn_day));
                                var b = start.ToString("yyyy-MM-dd") == DateTime.Now.ToString("yyyy-MM-dd");
                                var c = DateTime.Now > start && (DateTime.Now - start).Days % rule.interval_days == 0;
                                if (b || c)
                                {
                                    foreach (var item1 in rule.warn_person.Split(','))
                                    {
                                        ErpMessageMain erpMessageMain = new ErpMessageMain();
                                        erpMessageMain.type = 2;
                                        erpMessageMain.model = (int)MessageModelDic.合同到期提醒;
                                        erpMessageMain.object_id = item.id.ToString();
                                        erpMessageMain.created_id = Convert.ToDecimal(item1);
                                        erpMessageMain.title = $"租房(广告)合同{item.name}于{item.end_date:yyyy-MM-dd HH:mm:ss}到期，请及时查看";
                                        await _iErpMessageMainImp.AddErpMessageMain(serverId, erpMessageMain, new ClientInformation { i_id = 2000000 });
                                    }
                                }
                            }
                        }
                    }

                    if (rules.Exists(r => r.rule_type == 20))
                    {
                        var rule = rules.Find(r => r.rule_type == 20 && r.message_type == 2);
                        var a = records.Where(r => r.end_date > DateTime.Now && r.state == 1).ToList();
                        string year = DateTime.Now.Year.ToString();
                        var fee_records = await SqlSugarHelper.DBClient(serverId).Queryable<ErpContractFee>()
                            .Where(r => r.finish == 1 && SqlFunc.Oracle_ToChar(r.post_date, "yyyy") == year)
                            .ToListAsync();
                        a = a.Where(r => !fee_records.Select(m => m.main_id).Contains(r.id)).ToList();
                        if (rule != null && rule.warn_day != null && rule.warn_day > 0)
                        {
                            foreach (var item in a)
                            {
                                var ss = $"{DateTime.Now.Year}-{item.timer_date.Value.Month}-{item.timer_date.Value.Day}";
                                var start = Convert.ToDateTime(ss).AddDays(-Convert.ToDouble(rule.warn_day));
                                var b = start.ToString("yyyy-MM-dd") == DateTime.Now.ToString("yyyy-MM-dd");
                                var c = DateTime.Now > start && (DateTime.Now - start).Days % rule.interval_days == 0;
                                if (b || c)
                                {
                                    foreach (var item1 in rule.warn_person.Split(','))
                                    {
                                        ErpMessageMain erpMessageMain = new ErpMessageMain();
                                        erpMessageMain.type = 2;
                                        erpMessageMain.model = (int)MessageModelDic.合同缴费提醒;
                                        erpMessageMain.object_id = item.id.ToString();
                                        erpMessageMain.created_id = Convert.ToDecimal(item1);
                                        erpMessageMain.title = $"租房(广告)合同{item.name}于{ss}到缴费日期，请及时催收";
                                        await _iErpMessageMainImp.AddErpMessageMain(serverId, erpMessageMain, new ClientInformation { i_id = 2000000 });
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                GlobalFunc.LogError(typeof(ErpContractMainJobImp), "合同检查失败!", ex);
            }
        }

        public void  ExecuteJob()
        {
            Execute();
        }
    }
}
