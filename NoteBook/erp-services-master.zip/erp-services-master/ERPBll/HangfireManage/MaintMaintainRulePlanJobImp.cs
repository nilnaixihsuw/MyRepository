﻿using BusTools.JiGuang;
using BusTools.JiGuang.Contracts;
using ERPBll.MaintManage;
using ERPBll.SignalRs;
using ERPBll.UserManage;
using ERPBll.Vehicleinfomanage;
using ERPBll.WorkPlace;
using ERPCore;
using ERPCore.Entity;
using ERPCore.ORM;
using ERPDal;
using ERPDal.MaintManage;
using ERPModel.ApiModel;
using ERPModel.DataBase;
using ERPModel.MaintManage;
using ERPModel.Repairs;
using ERPModel.Vehicleinfomanage;
using ERPModel.Workplace;
using ERPWeb.Manager;
using Microsoft.Extensions.Configuration;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.HangfireManage
{
    public class MaintMaintainRulePlanJobImp : IMaintMaintainRulePlanJobImp
    {
        private readonly IMaintMaintainRulesImp _iMaintMaintainRulesImp;
        private readonly IMaintUpkeepPlanImp _iMaintUpkeepPlanImp;
        private readonly IVehicleInfoImp _iVehicleInfoImp;
        private readonly IConfiguration _configuration;
        private readonly JiGuangMessageConfig _jiGuangMessageConfig;
        private readonly IJSMSService _iJiGuangService;
        private readonly IServerHubImp _iServerHubImp;
        private readonly IErpMessageMainImp _iErpMessageMainImp;
        private readonly IMaintHintTemplateDataImp _iMaintHintTemplate;

        public MaintMaintainRulePlanJobImp(
            IServerHubImp iServerHubImp,
            IJSMSService iJiGuangService,
            IVehicleInfoImp iVehicleInfoImp,
            IConfiguration iConfiguration,
            IMaintUpkeepPlanImp iMaintUpkeepPlanImp,
            IMaintMaintainRulesImp iMaintMaintainRulesImp,
            IErpMessageMainImp iErpMessageMainImp,
            IMaintHintTemplateDataImp iMaintHintTemplate)
        {
            _iServerHubImp = iServerHubImp;
            _iJiGuangService = iJiGuangService;
            _iMaintMaintainRulesImp = iMaintMaintainRulesImp;
            _iMaintUpkeepPlanImp = iMaintUpkeepPlanImp;
            _configuration = iConfiguration;
            _iVehicleInfoImp = iVehicleInfoImp;
            _jiGuangMessageConfig = _configuration.GetSection("JiGuangMessageConfig").Get<JiGuangMessageConfig>();
            _iErpMessageMainImp = iErpMessageMainImp;
            _iMaintHintTemplate = iMaintHintTemplate;
        }

        public async Task Execute()
        {
            try
            {
                GlobalFunc.LogInfo(typeof(MaintMaintainRulePlanJobImp), "开始执行保养计划自动生成!");
                //获取ServerIds
                var serverIds = _configuration.GetSection("Sugar").Get<SugarOption>().ProjectConfig.ConfigList["Server"].Select(it => it.Url).ToList();
                foreach (var serverId in serverIds)
                {
                    var plans = new List<MaintUpkeepPlan>();
                    //获取规则
                    var rules = await _iMaintMaintainRulesImp.List(serverId, it => it.i_valid == 1);
                    GlobalFunc.LogInfo(typeof(MaintMaintainRulePlanJobImp), $"{serverId}当前有效规则条目数{rules.Count}");
                    var carInfos = _iVehicleInfoImp.List(serverId, it => true).Result;
                    GlobalFunc.LogInfo(typeof(MaintMaintainRulePlanJobImp), $"{serverId}当前有效车辆条目数{rules.Count}");
                    //已存计划
                    var existCheckPlans = _iMaintUpkeepPlanImp.List(serverId, it => true).Result;
                    //rules.ForEach(rule =>
                    //{
                    //    //根据规则生成保养计划
                    //    carInfos.ForEach(car =>
                    //    {
                    //        if (car.d_regist_certificate_date != null)
                    //        {
                    //            //一保
                    //            if (rule.c_rules_type == "1")
                    //            {
                    //                //指定周期
                    //                if (rule.i_condition_type == 1)
                    //                {
                    //                    Maintain1ByPeriod(rule, car, serverId, plans, existCheckPlans.Where(it => it.c_upkeep_type == "1" && it.i_condition_type == 1)?.ToList());
                    //                }
                    //                //指定里程
                    //                if (rule.i_condition_type == 2)
                    //                {
                    //                    Maintain1ByMile(rule, car, serverId, plans, existCheckPlans.Where(it => it.c_upkeep_type == "1" && it.i_condition_type == 2)?.ToList());
                    //                }
                    //            }

                    //            //二保
                    //            if (rule.c_rules_type == "2")
                    //            {
                    //                Maintain2(rule, car, serverId, plans, existCheckPlans.Where(it => it.c_upkeep_type == "2")?.ToList());
                    //            }
                    //        }
                    //    });

                    //});

                    GlobalFunc.LogInfo(typeof(MaintMaintainRulePlanJobImp), $"{serverId}当前有效计划条目数{plans.Count}");
                    if (plans.Count > 0)
                    {
                        var r = await _iMaintUpkeepPlanImp.Insert(serverId, plans);
                        if (!r)
                        {
                            GlobalFunc.LogInfo(typeof(MaintMaintainRulePlanJobImp), "保养记录插入失败!");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                GlobalFunc.LogError(typeof(MaintMaintainRulePlanJobImp), "生成保养计划失败!", ex);
            }

        }

        /// <summary>
        /// 二保
        /// </summary>
        /// <param name="rule"></param>
        /// <param name="car"></param>
        /// <param name="serverId"></param>
        /// <param name="plans"></param>
        /// <param name="existCheckPlans"></param>
        private void Maintain2(ERPModel.MaintManage.MaintMaintainRules rule, ErpVehicleInfo car, string serverId, List<MaintUpkeepPlan> plans, List<MaintUpkeepPlan> existCheckPlans)
        {
            //if (car.d_regist_certificate_date != null)
            //{
            //    var vhcAge = Math.Round(Convert.ToDecimal((DateTime.Now - car.d_regist_certificate_date.Value).Days / 365), 2);
            //    //是否需要生成保养计划
            //    if (existCheckPlans != null && existCheckPlans.Count() > 0)
            //    {
            //        var checkRuleRecord = existCheckPlans.Where(it => it.i_rule_id == rule.i_id && it.i_vehicle_id == car.i_id).ToList();
            //        var latestRecord = checkRuleRecord.Find(it => it.d_upkeep_plan_end == checkRuleRecord.Max(it => it.d_upkeep_plan_end));
            //        if (checkRuleRecord.Count > 0)
            //        {
            //            //本次未保养
            //            if (latestRecord.d_upkeep_plan_end <= DateTime.Now && latestRecord.d_upkeep_true == null)
            //            {
            //                //判断超期
            //                if (latestRecord.d_upkeep_plan_end <= DateTime.Now && (DateTime.Now - latestRecord.d_upkeep_plan_end.Value).Days >= _jiGuangMessageConfig.OverDay)
            //                {
            //                    //发送一保超期通知信息
            //                    SendNotification(rule.reminders, rule.i_warn_way.Value, car, "二保", latestRecord.d_upkeep_plan_end.Value, "已结束", (DateTime.Now - latestRecord.d_upkeep_plan_end.Value).Days);
            //                }
            //            }
            //            else
            //            {
            //                //生成新的计划
            //                if (vhcAge > rule.i_age_condition_min && vhcAge <= rule.i_age_condition_max)
            //                {
            //                    if (car.n_total_mile != null && car.n_last_total_mile != null && car.d_upkeep_date != null)
            //                    {
            //                        if (car.n_total_mile != null && car.n_last_total_mile != null)
            //                        {
            //                            //周期里程达到要求
            //                            if (car.n_total_mile - car.n_last_total_mile >= rule.i_condition_mile)
            //                            {
            //                                if (DateTime.Now.Day == rule.i_gen_play_day)
            //                                {
            //                                    if (!existCheckPlans.Exists(it => it.i_rule_id == rule.i_id
            //                                     && it.i_vehicle_id == car.i_id
            //                                     && it.d_last_keep_time2 == car.d_upkeep_date
            //                                    ))
            //                                    {
            //                                        //按照车龄,周期里程生成二保计划
            //                                        var plan = new MaintUpkeepPlan
            //                                        {
            //                                            i_id = _iMaintUpkeepPlanImp.GetId(serverId, "SEQ_ERP_CAR_INFO").Result,
            //                                            i_vehicle_id = car.i_id,
            //                                            c_upkeep_type = "2",
            //                                            n_total_mile = car.n_total_mile,
            //                                            n_time_mile = car.n_total_mile - car.n_last_total_mile,
            //                                            d_last_keep_time2 = car.d_upkeep_date,
            //                                            d_upkeep_plan_start = DateTime.Now.AddDays(-(int)rule.i_warn_days),
            //                                            d_upkeep_plan_end = DateTime.Now,
            //                                            i_rule_id = rule.i_id,
            //                                            c_remark = "按照车龄,周期里程生成二保计划",
            //                                            d_create = DateTime.Now.ToLocalTime(),
            //                                            i_create_user = 2000000,
            //                                            i_send_state = rule.i_auto_issu,
            //                                            i_receive_state = rule.i_auto_issu,
            //                                            i_create_type = "0"
            //                                        };
            //                                        plans.Add(plan);
            //                                        //发送二保通知信息
            //                                        SendNotification(rule.reminders, rule.i_warn_way.Value, car, "二保", plan.d_upkeep_plan_end.Value, "还有", (DateTime.Now - plan.d_upkeep_plan_end.Value).Days);
            //                                    }

            //                                }

            //                            }
            //                            else            //周期里程未达到则按定期保养
            //                            {
            //                                var planTime = car.d_check_date == null ? car.d_regist_certificate_date.Value : car.d_check_date.Value;
            //                                var mInterval = Math.Round(Convert.ToDecimal((DateTime.Now - planTime).Days / 30), 2);
            //                                if (mInterval >= rule.i_condition_month)
            //                                {
            //                                    if (DateTime.Now.Day == rule.i_gen_play_day)
            //                                    {
            //                                        while (true)
            //                                        {
            //                                            planTime = planTime.AddMonths((int)rule.i_condition_month.Value);
            //                                            if (planTime > DateTime.Now) break;
            //                                        }

            //                                        if (!existCheckPlans.Exists(it => it.i_rule_id == rule.i_id
            //                                            && it.i_vehicle_id == car.i_id
            //                                            && it.d_last_keep_time2 == car.d_upkeep_date
            //                                            ))
            //                                        {
            //                                            //按照车龄，定期生成二保计划
            //                                            var plan = new MaintUpkeepPlan
            //                                            {
            //                                                i_id = _iMaintUpkeepPlanImp.GetId(serverId, "SEQ_ERP_CAR_INFO").Result,
            //                                                i_vehicle_id = car.i_id,
            //                                                c_upkeep_type = "2",
            //                                                n_total_mile = car.n_total_mile,
            //                                                n_time_mile = car.n_total_mile - car.n_last_total_mile,
            //                                                d_last_keep_time2 = car.d_upkeep_date,
            //                                                d_upkeep_plan_start = planTime.AddDays(-(int)rule.i_warn_days),
            //                                                d_upkeep_plan_end = planTime,
            //                                                i_rule_id = rule.i_id,
            //                                                c_remark = "按照车龄，定期生成二保计划",
            //                                                d_create = DateTime.Now.ToLocalTime(),
            //                                                i_create_user = 2000000,
            //                                                i_send_state = rule.i_auto_issu,
            //                                                i_receive_state = rule.i_auto_issu,
            //                                                i_create_type = "0"
            //                                            };
            //                                            plans.Add(plan);
            //                                            //发送二保通知信息
            //                                            SendNotification(rule.reminders, rule.i_warn_way.Value, car, "二保", plan.d_upkeep_plan_end.Value, "还有", (DateTime.Now - plan.d_upkeep_plan_end.Value).Days);
            //                                        }
            //                                    }
            //                                }
            //                            }
            //                        }
            //                        else
            //                        {
            //                            var planTime = car.d_check_date == null ? car.d_regist_certificate_date.Value : car.d_check_date.Value;
            //                            var mInterval = Math.Round(Convert.ToDecimal((DateTime.Now - planTime).Days / 30), 2);
            //                            if (mInterval >= rule.i_condition_month)
            //                            {
            //                                if (DateTime.Now.Day == rule.i_gen_play_day)
            //                                {
            //                                    while (true)
            //                                    {
            //                                        planTime = planTime.AddMonths((int)rule.i_condition_month.Value);
            //                                        if (planTime > DateTime.Now) break;
            //                                    }

            //                                    if (!existCheckPlans.Exists(it => it.i_rule_id == rule.i_id
            //                                        && it.i_vehicle_id == car.i_id
            //                                        && it.d_last_keep_time2 == car.d_upkeep_date
            //                                        ))
            //                                    {
            //                                        //按照车龄，定期生成二保计划
            //                                        var plan = new MaintUpkeepPlan
            //                                        {
            //                                            i_id = _iMaintUpkeepPlanImp.GetId(serverId, "SEQ_ERP_CAR_INFO").Result,
            //                                            i_vehicle_id = car.i_id,
            //                                            c_upkeep_type = "2",
            //                                            n_total_mile = car.n_total_mile,
            //                                            n_time_mile = car.n_total_mile - car.n_last_total_mile,
            //                                            d_last_keep_time2 = car.d_upkeep_date,
            //                                            d_upkeep_plan_start = planTime.AddDays(-(int)rule.i_warn_days),
            //                                            d_upkeep_plan_end = planTime,
            //                                            i_rule_id = rule.i_id,
            //                                            c_remark = "按照车龄，定期生成二保计划",
            //                                            d_create = DateTime.Now.ToLocalTime(),
            //                                            i_create_user = 2000000,
            //                                            i_send_state = rule.i_auto_issu,
            //                                            i_receive_state = rule.i_auto_issu,
            //                                            i_create_type = "0"
            //                                        };
            //                                        plans.Add(plan);
            //                                        //发送二保通知信息
            //                                        SendNotification(rule.reminders, rule.i_warn_way.Value, car, "二保", plan.d_upkeep_plan_end.Value, "还有", (DateTime.Now - plan.d_upkeep_plan_end.Value).Days);
            //                                    }
            //                                }
            //                            }
            //                        }

            //                    }
            //                }
            //            }
            //        }
            //        else
            //        {
            //            plans = AddMaint2Record(rule, car, serverId, plans, vhcAge);
            //        }
            //    }
            //    else
            //    {
            //        plans = AddMaint2Record(rule, car, serverId, plans, vhcAge);
            //    }
            //}
        }

        private List<MaintUpkeepPlan> AddMaint2Record(ERPModel.MaintManage.MaintMaintainRules rule, ErpVehicleInfo car, string serverId, List<MaintUpkeepPlan> plans, decimal vhcAge)
        {
            return default;
            //该车生成第一条计划
            //if (vhcAge > rule.i_age_condition_min && vhcAge <= rule.i_age_condition_max)
            //{
            //    //周期里程达到要求
            //    if (car.n_total_mile != null && car.n_last_total_mile != null)
            //    {
            //        if (car.n_total_mile - car.n_last_total_mile >= rule.i_condition_mile)
            //        {
            //            if (DateTime.Now.Day == rule.i_gen_play_day)
            //            {
            //                //按照车龄,周期里程生成二保计划
            //                var plan = new MaintUpkeepPlan
            //                {
            //                    i_id = _iMaintUpkeepPlanImp.GetId(serverId, "SEQ_ERP_CAR_INFO").Result,
            //                    i_vehicle_id = car.i_id,
            //                    c_upkeep_type = "2",
            //                    n_total_mile = car.n_total_mile,
            //                    n_time_mile = car.n_total_mile - car.n_last_total_mile,
            //                    d_last_keep_time2 = car.d_upkeep_date,
            //                    d_upkeep_plan_start = DateTime.Now.AddDays(-(int)rule.i_warn_days),
            //                    d_upkeep_plan_end = DateTime.Now,
            //                    i_rule_id = rule.i_id,
            //                    c_remark = "按照车龄,周期里程生成二保计划",
            //                    d_create = DateTime.Now.ToLocalTime(),
            //                    i_create_user = 2000000,
            //                    i_send_state = rule.i_auto_issu,
            //                    i_receive_state = rule.i_auto_issu,
            //                    i_create_type = "0"
            //                };
            //                plans.Add(plan);

            //                //发送二保通知信息
            //                SendNotification(rule.reminders, rule.i_warn_way.Value, car, "二保", plan.d_upkeep_plan_end.Value, "还有", (DateTime.Now - plan.d_upkeep_plan_end.Value).Days);
            //            }

            //        }
            //        else            //周期里程未达到则按定期保养
            //        {
            //            FirstAdd2RecordByRegular(rule, car, serverId, plans);
            //        }
            //    }
            //    else            //周期里程未达到则按定期保养
            //    {
            //        FirstAdd2RecordByRegular(rule, car, serverId, plans);
            //    }
            //}

            //return plans;
        }

        /// <summary>
        /// 第一次添加2保按定期保养记录
        /// </summary>
        /// <param name="rule"></param>
        /// <param name="car"></param>
        /// <param name="serverId"></param>
        /// <param name="plans"></param>
        private void FirstAdd2RecordByRegular(ERPModel.MaintManage.MaintMaintainRules rule, ErpVehicleInfo car, string serverId, List<MaintUpkeepPlan> plans)
        {
            //var r = new MaintUpkeepPlan();
            //var planTime = car.d_check_date == null ? car.d_regist_certificate_date.Value : car.d_check_date.Value;
            //var mInterval = Math.Round(Convert.ToDecimal((DateTime.Now - planTime).Days / 30), 2);
            //if (mInterval >= rule.i_condition_month)
            //{
            //    if (DateTime.Now.Day == rule.i_gen_play_day)
            //    {
            //        while (true)
            //        {
            //            planTime = planTime.AddMonths((int)rule.i_condition_month.Value);
            //            if (planTime > DateTime.Now) break;
            //        }

            //        //按照车龄，定期生成二保计划
            //        var plan = new MaintUpkeepPlan
            //        {
            //            i_id = _iMaintUpkeepPlanImp.GetId(serverId, "SEQ_ERP_CAR_INFO").Result,
            //            i_vehicle_id = car.i_id,
            //            c_upkeep_type = "2",
            //            n_total_mile = car.n_total_mile,
            //            n_time_mile = car.n_total_mile - car.n_last_total_mile,
            //            d_last_keep_time2 = car.d_upkeep_date,
            //            d_upkeep_plan_start = planTime.AddDays(-(int)rule.i_warn_days),
            //            d_upkeep_plan_end = planTime,
            //            i_rule_id = rule.i_id,
            //            c_remark = "按照车龄，定期保养生成二保计划",
            //            d_create = DateTime.Now.ToLocalTime(),
            //            i_create_user = 2000000,
            //            i_send_state = rule.i_auto_issu,
            //            i_receive_state = rule.i_auto_issu,
            //            i_create_type = "0"
            //        };
            //        plans.Add(plan);
            //    }
            //}
        }

        /// <summary>
        /// 一保按里程
        /// </summary>
        /// <param name="rule"></param>
        /// <param name="car"></param>
        /// <param name="serverId"></param>
        /// <param name="plans"></param>
        /// <param name="existCheckPlans"></param>
        private void Maintain1ByMile(ERPModel.MaintManage.MaintMaintainRules rule, ErpVehicleInfo car, string serverId, List<MaintUpkeepPlan> plans, List<MaintUpkeepPlan> existCheckPlans)
        {
            //if (car.n_total_mile != null)
            //{
            //    //是否需要生成保养计划
            //    if (existCheckPlans != null && existCheckPlans.Count() > 0)
            //    {
            //        var checkRuleRecord = existCheckPlans.Where(it => it.i_rule_id == rule.i_id && it.i_vehicle_id == car.i_id).ToList();
            //        var latestRecord = checkRuleRecord.Find(it => it.d_upkeep_plan_end == checkRuleRecord.Max(it => it.d_upkeep_plan_end));
            //        if (checkRuleRecord.Count > 0)
            //        {
            //            if (latestRecord != null)
            //            {
            //                //本次未保养
            //                if (latestRecord.d_upkeep_plan_end <= DateTime.Now && latestRecord.d_upkeep_true == null)
            //                {
            //                    //判断超期
            //                    if (latestRecord.d_upkeep_plan_end <= DateTime.Now && (DateTime.Now - latestRecord.d_upkeep_plan_end.Value).Days >= _jiGuangMessageConfig.OverDay)
            //                    {
            //                        //发送一保超期通知信息
            //                        SendNotification(rule.reminders, rule.i_warn_way.Value, car, "一保", latestRecord.d_upkeep_plan_end.Value, "已结束", (DateTime.Now - latestRecord.d_upkeep_plan_end.Value).Days);
            //                    }
            //                }
            //            }
            //            else
            //            {
            //                //生成新的一保计划
            //                if (car.n_total_mile - car.n_last_total_mile >= rule.i_condition_mile)
            //                {
            //                    if (DateTime.Now.Day == rule.i_gen_play_day)
            //                    {
            //                        if (!existCheckPlans.Exists(it => it.i_rule_id == rule.i_id
            //                            && it.i_vehicle_id == car.i_id
            //                            && it.d_last_keep_time == car.d_upkeep_date
            //                           ))
            //                        {
            //                            //按照累计里程生成一保保养计划表
            //                            var plan = new MaintUpkeepPlan
            //                            {
            //                                i_id = _iMaintUpkeepPlanImp.GetId(serverId, "SEQ_ERP_CAR_INFO").Result,
            //                                i_vehicle_id = car.i_id,
            //                                c_upkeep_type = "1",
            //                                n_total_mile = car.n_total_mile,
            //                                n_time_mile = car.n_total_mile - car.n_last_total_mile,
            //                                d_last_keep_time = car.d_upkeep_date,
            //                                d_upkeep_plan_start = DateTime.Now.AddDays(-(int)rule.i_warn_days),
            //                                d_upkeep_plan_end = DateTime.Now,
            //                                i_rule_id = rule.i_id,
            //                                d_create = DateTime.Now.ToLocalTime(),
            //                                i_create_user = 2000000,
            //                                i_send_state = rule.i_auto_issu,
            //                                i_receive_state = rule.i_auto_issu,
            //                                i_create_type = "0",
            //                                i_condition_type = 2
            //                            };
            //                            plans.Add(plan);
            //                            SendNotification(rule.reminders, rule.i_warn_way.Value, car, "一保", plan.d_upkeep_plan_end.Value, "还有", (DateTime.Now - plan.d_upkeep_plan_end.Value).Days);

            //                        }
            //                    }
            //                }
            //            }
            //        }
            //        else
            //        {
            //            //该车第一次生成一保计划
            //            if (car.n_total_mile - car.n_last_total_mile >= rule.i_condition_mile)
            //            {
            //                if (DateTime.Now.Day == rule.i_gen_play_day)
            //                {
            //                    //按照累计里程生成一保保养计划表
            //                    var plan = new MaintUpkeepPlan
            //                    {
            //                        i_id = _iMaintUpkeepPlanImp.GetId(serverId, "SEQ_ERP_CAR_INFO").Result,
            //                        i_vehicle_id = car.i_id,
            //                        c_upkeep_type = "1",
            //                        n_total_mile = car.n_total_mile,
            //                        n_time_mile = car.n_total_mile - car.n_last_total_mile,
            //                        d_last_keep_time = car.d_upkeep_date,
            //                        d_upkeep_plan_start = DateTime.Now.AddDays(-(int)rule.i_warn_days),
            //                        d_upkeep_plan_end = DateTime.Now,
            //                        i_rule_id = rule.i_id,
            //                        d_create = DateTime.Now.ToLocalTime(),
            //                        i_create_user = 2000000,
            //                        i_send_state = rule.i_auto_issu,
            //                        i_receive_state = rule.i_auto_issu,
            //                        i_create_type = "0",
            //                        i_condition_type = 2
            //                    };
            //                    plans.Add(plan);
            //                    SendNotification(rule.reminders, rule.i_warn_way.Value, car, "一保", plan.d_upkeep_plan_end.Value, "还有", (DateTime.Now - plan.d_upkeep_plan_end.Value).Days);

            //                }
            //            }
            //        }
            //    }
            //    else
            //    {
            //        //计划表一保数据为空
            //        if (car.n_total_mile - car.n_last_total_mile >= rule.i_condition_mile)
            //        {
            //            if (DateTime.Now.Day == rule.i_gen_play_day)
            //            {
            //                //按照累计里程生成一保保养计划表
            //                var plan = new MaintUpkeepPlan
            //                {
            //                    i_id = _iMaintUpkeepPlanImp.GetId(serverId, "SEQ_ERP_CAR_INFO").Result,
            //                    i_vehicle_id = car.i_id,
            //                    c_upkeep_type = "1",
            //                    n_total_mile = car.n_total_mile,
            //                    n_time_mile = car.n_total_mile - car.n_last_total_mile,
            //                    d_last_keep_time = car.d_upkeep_date,
            //                    d_upkeep_plan_start = DateTime.Now.AddDays(-(int)rule.i_warn_days),
            //                    d_upkeep_plan_end = DateTime.Now,
            //                    i_rule_id = rule.i_id,
            //                    d_create = DateTime.Now.ToLocalTime(),
            //                    i_create_user = 2000000,
            //                    i_send_state = rule.i_auto_issu,
            //                    i_receive_state = rule.i_auto_issu,
            //                    i_create_type = "0",
            //                    i_condition_type = 2
            //                };
            //                plans.Add(plan);
            //                SendNotification(rule.reminders, rule.i_warn_way.Value, car, "一保", plan.d_upkeep_plan_end.Value, "还有", (DateTime.Now - plan.d_upkeep_plan_end.Value).Days);

            //            }
            //        }
            //    }
            //}

        }

        /// <summary>
        /// 一保按周期
        /// </summary>
        /// <param name="rule"></param>
        /// <param name="car"></param>
        /// <param name="serverId"></param>
        /// <param name="plans"></param>
        /// <param name="existCheckPlans"></param>
        private void Maintain1ByPeriod(ERPModel.MaintManage.MaintMaintainRules rule, ErpVehicleInfo car, string serverId, List<MaintUpkeepPlan> plans, List<MaintUpkeepPlan> existCheckPlans)
        {
            //是否需要生成保养计划
            //if (existCheckPlans != null && existCheckPlans.Count() > 0)
            //{
            //    var checkRuleRecord = existCheckPlans.Where(it => it.i_rule_id == rule.i_id && it.i_vehicle_id == car.i_id).ToList();
            //    var latestRecord = checkRuleRecord.Find(it => it.d_upkeep_plan_end == checkRuleRecord.Max(it => it.d_upkeep_plan_end));
            //    if (checkRuleRecord.Count > 0)
            //    {
            //        if (latestRecord != null)
            //        {
            //            //本次未保养
            //            if (latestRecord.d_upkeep_plan_end <= DateTime.Now && latestRecord.d_upkeep_true == null)
            //            {
            //                //判断超期
            //                if (latestRecord.d_upkeep_plan_end <= DateTime.Now && (DateTime.Now - latestRecord.d_upkeep_plan_end.Value).Days >= _jiGuangMessageConfig.OverDay)
            //                {
            //                    //发送一保超期通知信息
            //                    SendNotification(rule.reminders, rule.i_warn_way.Value, car, "一保", latestRecord.d_upkeep_plan_end.Value, "已结束", (DateTime.Now - latestRecord.d_upkeep_plan_end.Value).Days);
            //                }
            //            }
            //            else
            //            {
            //                //计划已执行需要生成新的一保计划
            //                //判断是否满足规则
            //                var mInterval = Math.Round(Convert.ToDecimal((DateTime.Now - latestRecord.d_upkeep_plan_end.Value).Days / 30), 2);
            //                if (mInterval >= rule.i_condition_month.Value)
            //                {
            //                    if (DateTime.Now.Day == rule.i_gen_play_day)
            //                    {
            //                        var planTime = latestRecord.d_upkeep_plan_end.Value;
            //                        while (true)
            //                        {
            //                            planTime = planTime.AddMonths((int)rule.i_condition_month.Value);
            //                            if (planTime > DateTime.Now) break;
            //                        }

            //                        if (!existCheckPlans.Exists(it => it.i_rule_id == rule.i_id
            //                             && it.i_vehicle_id == car.i_id
            //                             && it.d_last_keep_time == car.d_upkeep_date
            //                            ))
            //                        {
            //                            //按照指定周期生成一保保养计划表
            //                            var plan = new MaintUpkeepPlan
            //                            {
            //                                i_id = _iMaintUpkeepPlanImp.GetId(serverId, "SEQ_ERP_CAR_INFO").Result,
            //                                i_vehicle_id = car.i_id,
            //                                c_upkeep_type = "1",
            //                                n_total_mile = car.n_total_mile,
            //                                n_time_mile = car.n_total_mile - car.n_last_total_mile,
            //                                d_last_keep_time = car.d_upkeep_date,
            //                                d_upkeep_plan_start = planTime.AddDays(-(int)rule.i_warn_days),
            //                                d_upkeep_plan_end = planTime,
            //                                i_rule_id = rule.i_id,
            //                                d_create = DateTime.Now.ToLocalTime(),
            //                                i_create_user = 2000000,
            //                                i_send_state = rule.i_auto_issu,
            //                                i_receive_state = rule.i_auto_issu,
            //                                i_create_type = "0",
            //                                i_condition_type = 1
            //                            };
            //                            plans.Add(plan);

            //                            //发送一保通知信息
            //                            SendNotification(rule.reminders, rule.i_warn_way.Value, car, "一保", plan.d_upkeep_plan_end.Value, "还有", (DateTime.Now - plan.d_upkeep_plan_end.Value).Days);
            //                        }
            //                    }
            //                }
            //            }
            //        }
            //    }
            //    else
            //    {
            //        //该车第一次生成一保计划
            //        if (DateTime.Now.Day == rule.i_gen_play_day)
            //        {
            //            var planTime = car.d_check_date == null ? car.d_regist_certificate_date.Value : car.d_check_date.Value;
            //            while (true)
            //            {
            //                planTime = planTime.AddMonths((int)rule.i_condition_month.Value);
            //                if (planTime > DateTime.Now) break;
            //            }

            //            //按照指定周期生成一保保养计划表
            //            var plan = new MaintUpkeepPlan
            //            {
            //                i_id = _iMaintUpkeepPlanImp.GetId(serverId, "SEQ_ERP_CAR_INFO").Result,
            //                i_vehicle_id = car.i_id,
            //                c_upkeep_type = "1",
            //                n_total_mile = car.n_total_mile,
            //                n_time_mile = car.n_total_mile - car.n_last_total_mile,
            //                d_last_keep_time = car.d_upkeep_date,
            //                d_upkeep_plan_start = planTime.AddDays(-(int)rule.i_warn_days),
            //                d_upkeep_plan_end = planTime,
            //                i_rule_id = rule.i_id,
            //                d_create = DateTime.Now.ToLocalTime(),
            //                i_create_user = 2000000,
            //                i_send_state = rule.i_auto_issu,
            //                i_receive_state = rule.i_auto_issu,
            //                i_create_type = "0",
            //                i_condition_type = 1
            //            };
            //            plans.Add(plan);

            //            //发送一保通知信息
            //            SendNotification(rule.reminders, rule.i_warn_way.Value, car, "一保", plan.d_upkeep_plan_end.Value, "还有", (DateTime.Now - plan.d_upkeep_plan_end.Value).Days);

            //        }
            //    }
            //}
            //else
            //{
            //    //一保计划表为空
            //    if (DateTime.Now.Day == rule.i_gen_play_day)
            //    {
            //        var planTime = car.d_check_date == null ? car.d_regist_certificate_date.Value : car.d_check_date.Value;
            //        while (true)
            //        {
            //            planTime = planTime.AddMonths((int)rule.i_condition_month.Value);
            //            if (planTime > DateTime.Now) break;
            //        }

            //        //按照指定周期生成一保保养计划表
            //        var plan = new MaintUpkeepPlan
            //        {
            //            i_id = _iMaintUpkeepPlanImp.GetId(serverId, "SEQ_ERP_CAR_INFO").Result,
            //            i_vehicle_id = car.i_id,
            //            c_upkeep_type = "1",
            //            n_total_mile = car.n_total_mile,
            //            n_time_mile = car.n_total_mile - car.n_last_total_mile,
            //            d_last_keep_time = car.d_upkeep_date,
            //            d_upkeep_plan_start = planTime.AddDays(-(int)rule.i_warn_days),
            //            d_upkeep_plan_end = planTime,
            //            i_rule_id = rule.i_id,
            //            d_create = DateTime.Now.ToLocalTime(),
            //            i_create_user = 2000000,
            //            i_send_state = rule.i_auto_issu,
            //            i_receive_state = rule.i_auto_issu,
            //            i_create_type = "0",
            //            i_condition_type = 1
            //        };
            //        plans.Add(plan);

            //        //发送一保通知信息
            //        SendNotification(rule.reminders, rule.i_warn_way.Value, car, "一保", plan.d_upkeep_plan_end.Value, "还有", (DateTime.Now - plan.d_upkeep_plan_end.Value).Days);

            //    }
            //}

        }

        private void SendNotification(List<Reminder> reminders, decimal warn_way, ErpVehicleInfo car, string type, DateTime? upkeep_date, string condition, int? days)
        {
            //发送该辆车的信息提醒
            if (_jiGuangMessageConfig.Open)
            {
                var msg = $"{car.c_lincense_plate_number}距离{type}时间（{upkeep_date}）{condition}{days}天！";
                var dic = new Dictionary<string, string>();
                dic.Add("plate_number", car.c_lincense_plate_number);
                dic.Add("type", type);
                dic.Add("upkeep_date", upkeep_date.ToString());
                dic.Add("condition", condition);
                dic.Add("days", days.ToString());
                switch (warn_way)
                {
                    //系统消息
                    case 1:
                        SendSysMessage(reminders, msg);
                        break;
                    //app推送
                    case 2:
                        SendAppMessage(reminders);
                        break;
                    //短信通知
                    case 3:
                        SendMessage(reminders, dic);
                        break;
                    //1+2
                    case 4:
                        SendSysMessage(reminders, msg);
                        SendAppMessage(reminders);
                        break;
                    //1+3
                    case 5:
                        SendSysMessage(reminders, msg);
                        SendMessage(reminders, dic);
                        break;
                    //2+3
                    case 6:
                        SendAppMessage(reminders);
                        SendMessage(reminders, dic);
                        break;
                    //1+2+3
                    case 7:
                        SendSysMessage(reminders, msg);
                        SendAppMessage(reminders);
                        SendMessage(reminders, dic);
                        break;
                }
            }
        }

        /// <summary>
        /// 发送短信
        /// </summary>
        /// <param name="rule"></param>
        /// <param name="dic"></param>
        private void SendMessage(List<Reminder> reminders, Dictionary<string, string> dic)
        {
            reminders.ForEach(item =>
            {
                if (!string.IsNullOrEmpty(item.phone))
                {
                    var r = _iJiGuangService.SendMessage(item.phone, _jiGuangMessageConfig.SignId, _jiGuangMessageConfig.TempId["MaintMaintainRuleTemp"], dic).Result;
                    if (!r.is_send)
                    {
                        GlobalFunc.LogInfo(typeof(MaintCheckRulePlanJobImp), $"{dic["plate_number"]}发送短信失败!");
                    }
                }
            });
        }

        /// <summary>
        /// App推送
        /// </summary>
        /// <param name="rule"></param>
        private static void SendAppMessage(List<Reminder> reminders)
        {
            reminders.ForEach(item =>
            {
                //TODO
            });
        }

        /// <summary>
        /// 发送系统消息
        /// </summary>
        /// <param name="rule"></param>
        /// <param name="msg"></param>
        private void SendSysMessage(List<Reminder> reminder, string msg)
        {
            reminder.ForEach(item =>
            {
                _iServerHubImp.SendMessageByUserAsync(MessageType.DiscardRuleMessage, item.i_id.ToString(), msg);
            });
        }

        public void ExecuteJob()
        {
            //Execute();
            //AddMessage();
            _ = AddToRepair("60.191.59.11");
        }

        private async Task AddMessage()
        {
            string server_id = "60.191.59.11";
            var plans = await _iMaintUpkeepPlanImp.List(server_id, null);
            var rules = await _iMaintMaintainRulesImp.List(server_id, null);
            var users = await _iMaintHintTemplate.List(server_id, null);
            var vehicles = await _iVehicleInfoImp.List(server_id, null);
            List<MaintUpkeepPlan> list = new List<MaintUpkeepPlan>();
            foreach (var plan in plans)
            {
                var rule = rules.Find(r => r.i_id == plan.rule_id);
                if (rule.i_warn_days != null && plan.plan_date.Value < DateTime.Now.AddDays((int)rule.i_warn_days.Value)
                    && plan.state == 2)
                {
                    list.Add(plan);
                }
            }
            if (list.Count > 0)
            {
                var groups = list.GroupBy(r => r.rule_id);
                foreach (var group in groups)
                {
                    var user = users.Find(r => r.i_main_id == group.Key);
                    if (user.c_user_target_type == "1")
                    {
                        var temp = group.ToList();
                        var vehicle = vehicles.Find(r => r.i_id == temp[0].vehicle_id);
                        string notice = $"{vehicle.c_lincense_plate_number}...等{group.Count()}辆车带保养，请及时处理";

                        ErpMessageMain erpMessageMain = new ErpMessageMain();
                        erpMessageMain.type = 2;
                        erpMessageMain.model = 42;
                        erpMessageMain.object_id = string.Join(',', temp.Select(r => r.id));
                        erpMessageMain.created_id = user.i_user_target_id;
                        erpMessageMain.title = notice;
                        await _iErpMessageMainImp.AddErpMessageMain(server_id, erpMessageMain, new ClientInformation { i_id = 2000000 });
                    }
                    else
                    {
                        var user_ids = RoleInfoBll.GetRolePerson(server_id, (decimal)user.i_user_target_id);
                        foreach (var item in user_ids)
                        {
                            var temp = group.ToList();
                            var vehicle = vehicles.Find(r => r.i_id == temp[0].vehicle_id);
                            string notice = $"{vehicle.c_lincense_plate_number}...等{group.Count()}辆车待年检，请及时处理";

                            ErpMessageMain erpMessageMain = new ErpMessageMain();
                            erpMessageMain.type = 2;
                            erpMessageMain.model = 42;
                            erpMessageMain.object_id = string.Join(',', temp.Select(r => r.id));
                            erpMessageMain.created_id = item.user_id;
                            erpMessageMain.title = notice;
                            await _iErpMessageMainImp.AddErpMessageMain(server_id, erpMessageMain, new ClientInformation { i_id = 2000000 });
                        }
                    }
                }
            }
        }

        public async Task AddToRepair(string server_id)
        {
            var plans = await _iMaintUpkeepPlanImp.List(server_id, r => r.plan_date.Value.ToString("yyyy-MM-dd") == DateTime.Now.ToString("yyyy-MM-dd") && r.state == 3);
            if (plans != null && plans.Count > 0)
            {
                var DB = SqlSugarHelper.DBClient(server_id);
                var dic = DB.Queryable<SysCommonDictDetail>().ToList();
                var repair_id = Convert.ToInt32(_configuration["UpKeepRepairId"]);
                var dept = DB.Queryable<ErpMaintenanceDepartment>().First();
                var records = new List<MaintRepairRecord>();
                var origins = DB.Queryable<MaintRepairRecord>().ToList();
                var dt = DateTime.Now;
                foreach (var item in plans)
                {
                    dt = dt.AddMinutes(1);
                    var info = new MaintRepairRecord();
                    info.id = ERPBll.Tools.GetEngineID(server_id);
                    info.vehicle_id = (int)item.vehicle_id;
                    info.type = 1;
                    info.type_child = (int)(item.upkeep_type == 1 ? dic.Find(r => r.c_name == "一保").i_id : dic.Find(r => r.c_name == "二保").i_id);
                    info.repair_user_id = repair_id;
                    //info.repair_time = item.plan_date.Value;
                    info.repair_time = dt;
                    if (origins.Exists(r => r.type_child == info.type_child && r.vehicle_id == info.vehicle_id && r.repair_time == info.repair_time))
                    {
                        continue;
                    }
                    info.repair_describe = item.upkeep_type == 1 ? "一保" : "二保";
                    info.repair_address_id = (int)dept.i_id;
                    info.repair_address = dept.c_name;
                    info.SetCreate(200000);
                    records.Add(info);
                    item.repair_id = info.id;
                }
                await DB.Insertable(records).ExecuteCommandAsync();
                await DB.Updateable(plans).ExecuteCommandAsync();
            }
        }
    }
}
