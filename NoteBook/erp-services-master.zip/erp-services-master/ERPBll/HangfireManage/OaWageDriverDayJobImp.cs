﻿using ERPBll.PersonalManage;
using ERPBll.RedisManage.Users;
using ERPCore.Helpers;
using ERPCore.ORM;
using ERPDal;
using ERPModel.PersonalManage;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.HangfireManage
{
    /// <summary>
    /// 驾驶员日考勤薪资生成
    /// </summary>
    public class OaWageDriverDayJobImp : IOaWageDriverDayJobImp
    {
        private readonly IConfiguration _config;
        private readonly IUserRedisImp _userRedisImp;
        private readonly IOaWageSettingImp _oaWageSettingImp;
        private readonly IOaWageDriverDayImp _oaWageDriverDayImp;
        private readonly IOaWageDriverDayDetailImp _oaWageDriverDayDetailImp;

        public OaWageDriverDayJobImp(
            IConfiguration config,
            IUserRedisImp userRedisImp,
            IOaWageSettingImp oaWageSettingImp,
            IOaWageDriverDayImp oaWageDriverDayImp,
            IOaWageDriverDayDetailImp oaWageDriverDayDetailImp)
        {
            _config = config;
            _userRedisImp = userRedisImp;
            _oaWageSettingImp = oaWageSettingImp;
            _oaWageDriverDayImp = oaWageDriverDayImp;
            _oaWageDriverDayDetailImp = oaWageDriverDayDetailImp;
        }

        public async Task Execute(DateTime? begin_time = null, DateTime? end_time = null, string driver_name = "")
        {
            // TODO 定时执行请求获取司机每日大小版情况
            // 写入OA_WAGE_DRIVER_DAY_DETAIL和OA_WAGE_DRIVER_DAY表
            if (!begin_time.HasValue)
            {
                begin_time = DateTime.Now.AddDays(-1).Date;
            }
            if (!end_time.HasValue)
            {
                end_time = DateTime.Now.Date;
            }

            using (var db = SqlSugarHelper.DBClient("60.191.59.11"))
            {
                //删除已有数据，重新生成
                var ids = await db.Queryable<OaWageDriverDay>()
                            .Where(x => x.wage_date == begin_time)
                            .Select(x => x.id).ToListAsync();
                await db.Deleteable<OaWageDriverDay>().Where(x => ids.Contains(x.id)).ExecuteCommandAsync();
                await db.Deleteable<OaWageDriverDayDetail>().Where(x => ids.Contains(x.main_id)).ExecuteCommandAsync();

                //获取线路配置
                var lineSetDic = new Dictionary<(int, int), decimal>();
                var lineSetting = await _oaWageSettingImp.List("60.191.59.11", null);
                foreach (var item in lineSetting)
                {
                    foreach (var row in item.line_id)
                    {
                        int line_id = Convert.ToInt32(row);
                        int type = Convert.ToInt32(item.type.Value);
                        if (!lineSetDic.ContainsKey((line_id, type)))
                        {
                            lineSetDic.Add((line_id, type), item.fee);
                        }
                    }
                }
                var line_defalut = lineSetting.FirstOrDefault(x => x.line_ids == "0");

                var query = await GeWageDriverDay(begin_time.Value, end_time.Value, "");

                //获取所有用户
                var users = (await _userRedisImp.GetAllAsync()).Where(x => x.i_is_driver == 1).ToList();
                foreach(var user in users)
                {
                    Console.WriteLine($"开始计算{user.c_name}的{begin_time.Value.Date}工资");
                    var data = query.Where(x => x.driver_name == user.c_name).ToList();
                    if (data == null || data.Count < 1)
                    {
                        continue;
                    }

                    var day = new OaWageDriverDay()
                    {
                        id = Yitter.IdGenerator.YitIdHelper.NextId(),
                        wage_date = begin_time,
                        driver_id = user.i_id,
                        leave = data.Sum(x => x.qj_times),
                        ls_leave = data.Sum(x => x.lsqj_times),
                        big_class = data.Max(x => x.big_class),
                        small_class = data.Max(x => x.little_class)
                    };

                    var line_id = data.Count == 1 ? data.First().line_id : (await GetDriverLine(user.c_name)).FirstOrDefault().line_id;
                    //日基础薪资
                    int class_type = day.big_class > 0 ? 1 : 2;
                    var key = lineSetDic.ContainsKey((line_id, class_type)) ? (line_id, class_type) : (0, class_type);
                    day.day_base = lineSetDic[key] > day.day_base ? lineSetDic[key] : day.day_base;

                    //综合奖
                    day.synthesize = 0;

                    //餐补
                    key = lineSetDic.ContainsKey((line_id, 4)) ? (line_id, 4) : (0, 4);
                    day.meals = lineSetDic[key] > day.meals ? lineSetDic[key] : day.meals;

                    if (day.leave > 0)
                    {
                        //请假金额
                        key = lineSetDic.ContainsKey((line_id, 5)) ? (line_id, 5) : (0, 5);
                        day.deducted_fee = day.leave * lineSetDic[key];
                    }
                    if (day.ls_leave > 0)
                    {
                        //临时请假金额
                        key = lineSetDic.ContainsKey((line_id, 6)) ? (line_id, 6) : (0, 6);
                        day.deducted_fee = day.ls_leave * lineSetDic[key];
                    }

                    var detail_list = new List<OaWageDriverDayDetail>();
                    foreach (var item in data)
                    { 
                        var detail = new OaWageDriverDayDetail
                        {
                            id = Yitter.IdGenerator.YitIdHelper.NextId(),
                            main_id = day.id,
                            line_id = item.line_id,
                            type = item.big_class > 0 ? 1 : 2,
                            created_date = DateTime.Now
                        };
                        detail_list.Add(detail);
                     }
                    await _oaWageDriverDayImp.Insert("60.191.59.11", day);
                    await _oaWageDriverDayDetailImp.Insert("60.191.59.11", detail_list);
                    Console.WriteLine($"计算{user.c_name}的{begin_time.Value.Date}工资成功----------->");
                }
            }
        }

        public void ExecuteJob()
        {
            Execute();
        }

        public async Task<List<CreateWageDriverDay>> GeWageDriverDay(DateTime begin_time, DateTime end_time, string driver_name)
        {
            return await Task.Run((Func<List<CreateWageDriverDay>>)(() =>
            {
                //需要从调度系统调用api更新erp_engine_vehicle的随车行驶里程
                var config = _config.GetSection("Sugar").Get<SugarOption>().DispatchSys;
                string para = JsonConvert.SerializeObject(new
                {
                    head = new
                    {
                        cmd = "get_driver_attendance",
                        server_id = config.ServerId,
                        driver_name = string.IsNullOrWhiteSpace(driver_name) ? "所有司机" : driver_name
                    },
                    content = new
                    {
                        begin_time = begin_time.ToString("yyyy-MM-dd HH:mm:ss"),
                        end_time = end_time.ToString("yyyy-MM-dd HH:mm:ss")
                    }
                });
                var response = HttpHelper.HttpGet(config.Url + "?req=" + para, null);

                if (response != null)
                {
                    var res = JsonConvert.DeserializeObject<Dictionary<string, Dictionary<string, object>>>(response);
                    if (res.TryGetValue("content", out Dictionary<string, object> content) &&
                            content.TryGetValue("items", out object list))
                    {
                        var data = JsonConvert.DeserializeObject<List<CreateWageDriverDay>>(list.ToString());
                        return data;
                    }
                }
                return null;
            }));
        }

        //获取司机所属线路
        public async Task<List<DriverLine>> GetDriverLine(string driver_name)
        {
            return await Task.Run((Func<List<DriverLine>>)(() =>
            {
                //需要从调度系统调用api更新erp_engine_vehicle的随车行驶里程
                var config = _config.GetSection("Sugar").Get<SugarOption>().DispatchSys;
                string para = JsonConvert.SerializeObject(new
                {
                    head = new
                    {
                        cmd = "get_driverline",
                        server_id = config.ServerId
                    },
                    content = new
                    {
                        driver_name = driver_name
                    }
                });
                var response = HttpHelper.HttpGet(config.Url + "?req=" + para, null);

                if (response != null)
                {
                    var res = JsonConvert.DeserializeObject<Dictionary<string, Dictionary<string, object>>>(response);
                    if (res.TryGetValue("content", out Dictionary<string, object> content) &&
                            content.TryGetValue("items", out object list))
                    {
                        var data = JsonConvert.DeserializeObject<List<DriverLine>>(list.ToString());
                        return data;
                    }
                }
                return null;
            }));
        }
    }

    public class CreateWageDriverDay
    {
        /// <summary>
        /// 线路id
        /// </summary>
        public int line_id { get; set; }

        /// <summary>
        /// 线路名
        /// </summary>
        public string line_name { get; set; }

        /// <summary>
        /// 调度系统司机id
        /// </summary>
        public int driver_id { get; set; }

        /// <summary>
        /// 司机名称
        /// </summary>
        public string driver_name { get; set; }

        /// <summary>
        /// 大班次数
        /// </summary>
        public int big_class { get; set; }

        /// <summary>
        /// 小班次数
        /// </summary>
        public int little_class { get; set; }

        /// <summary>
        /// 请假次数
        /// </summary>
        public int qj_times { get; set; }

        /// <summary>
        /// 临时请假
        /// </summary>
        public int lsqj_times { get; set; }
    }

    public class DriverLine
    {
        /// <summary>
        /// 线路id
        /// </summary>
        public int line_id { get; set; }

        /// <summary>
        /// 线路名
        /// </summary>
        public string line_name { set; get; }

        /// <summary>
        /// 司机id
        /// </summary>
        public int driver_id { get; set; }

        /// <summary>
        /// 司机名
        /// </summary>

        public string driver_name { set; get; }
    }
}
