﻿using AutoMapper;
using BusTools.Redis;
using ERPBll.RedisManage;
using ERPBll.RedisManage.Lines;
using ERPBll.TicketManage;
using ERPCore;
using ERPCore.DI;
using ERPDal;
using ERPDal.TicketManage;
using ERPModel.CommonModel;
using ERPModel.TicketManage;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.HangfireManage
{
    public class AutoCheckCardDailyJobImp : IAutoCheckCardDailyJobImp
    {
        private readonly string _checkCardKey = "check_card";
        private readonly IMapper _imapper;
        private readonly IVehicleRedisManageImp _vehicleRedisManageImp;
        private readonly IErpCardVehicleDayImp _iErpCardVehicleDayImp;
        private readonly IErpCardVehicleDayInitImp _iErpCardVehicleDayInitImp;
        private readonly IPosDataDetailDataImp _iPosDataDetailDataImp;
        private readonly ILineRedisImp _lineRedisImp;
        private readonly CardMapping _cardMapping;
        private readonly IRedisService _redisService;

        public AutoCheckCardDailyJobImp(
            IMapper imapper,
            IVehicleRedisManageImp vehicleRedisManageImp,
            IRedisService redisService)
        {
            _imapper = imapper;
            _vehicleRedisManageImp = vehicleRedisManageImp;
            _iPosDataDetailDataImp = DIContainer.ServiceLocator.Instance.GetService<IPosDataDetailDataImp>();
            _iErpCardVehicleDayImp = DIContainer.ServiceLocator.Instance.GetService<IErpCardVehicleDayImp>();
            _iErpCardVehicleDayInitImp = DIContainer.ServiceLocator.Instance.GetService<IErpCardVehicleDayInitImp>();
            _lineRedisImp = DIContainer.ServiceLocator.Instance.GetService<ILineRedisImp>();
            _redisService = redisService;
        }

        public async Task Execute(string server_id = "60.191.59.11")
        {
            try
            {
                using (var db = SqlSugarHelper.DBClient(server_id))
                {
                    var vehilce_list = await _vehicleRedisManageImp.GetAllAsync();
                    var vehicle_name_list = vehilce_list.Select(x => x.i_id).ToList();
                    var vehLines = await _lineRedisImp.GetLineVehAsync();
                    for (DateTime i = DateTime.Now.AddDays(-4); i < DateTime.Now.AddDays(-1); i = i.AddDays(1))
                    {
                        var data = await db.Queryable<ErpCardVehicleDay>()
                            .Where(x => x.date.Value.Date == i.Date)
                            .Select(x => x.vehicle_id)
                            .Distinct()
                            .ToListAsync();
                        //找出未进行统计的车辆id
                        var diffData = data.Except(vehicle_name_list);
                        if (diffData.Count() > 0)
                        {
                            var list = await _iPosDataDetailDataImp.GetCreditCardConsumptionDetl(server_id, i, null, null, vehLines);
                            var inserts = list.Where(it => it.cardmaintype != "TAX" && diffData.Contains(it.vehicle_id))
                                              .Select(it => new { it.vehicle_id, it.swip_ymd, it.card_type, it.txnamtreal, it.line_id, it.line_name })
                                              .GroupBy(it => new { it.vehicle_id, it.swip_ymd, it.card_type, it.line_id, it.line_name })
                                              .Select(it => new ErpCardVehicleDay
                                              {
                                                  vehicle_id = it.Key.vehicle_id,
                                                  date = Convert.ToDateTime(it.Key.swip_ymd),
                                                  type = it.Key.card_type,
                                                  type_count = it.Count(),
                                                  type_fee = it.Sum(c => c.txnamtreal),
                                                  line_id = it.Key.line_id,
                                                  line_name = it.Key.line_name,
                                                  order = _cardMapping.Sort.IndexOf(it.Key.card_type)
                                              })
                                              .ToList();
                            var oriInserts = list.Where(it => it.cardmaintype != "TAX" && diffData.Contains(it.vehicle_id))
                                                 .Select(it => new { it.vehicle_id, it.swip_ymd, it.card_ori_type, it.txnamtreal, it.line_id, it.line_name })
                                                 .GroupBy(it => new { it.vehicle_id, it.swip_ymd, it.card_ori_type, it.line_id, it.line_name })
                                                 .Select(it => new ErpCardVehicleDayInit
                                                 {
                                                     vehicle_id = it.Key.vehicle_id,
                                                     date = Convert.ToDateTime(it.Key.swip_ymd),
                                                     type = it.Key.card_ori_type,
                                                     type_count = it.Count(),
                                                     type_fee = it.Sum(c => c.txnamtreal),
                                                     line_id = it.Key.line_id,
                                                     line_name = it.Key.line_name,
                                                     order = _cardMapping.OriSort.IndexOf(it.Key.card_ori_type)
                                                 }).ToList();
                            if (inserts != null && inserts.Count > 0)
                            {
                                GlobalFunc.LogInfo(typeof(AutoCheckCardDailyJobImp), $"发现整合类型{inserts.Count}条未统计数据");
                                var r = await _iErpCardVehicleDayImp.Insert(server_id, inserts);
                                if (!r)
                                {
                                    var contexts = JsonConvert.SerializeObject(inserts);
                                    await _redisService.HashSetAsync(_checkCardKey, DateTime.Now.ToString(), contexts);
                                    throw new Exception("插入营收统计记录失败!");
                                }
                            }
                            if (oriInserts != null && oriInserts.Count > 0)
                            {
                                GlobalFunc.LogInfo(typeof(AutoCheckCardDailyJobImp), $"发现原始类型{oriInserts.Count}条未统计数据");
                                var r = await _iErpCardVehicleDayInitImp.Insert(server_id, oriInserts);
                                if (!r)
                                {
                                    var contexts = JsonConvert.SerializeObject(oriInserts);
                                    await _redisService.HashSetAsync(_checkCardKey, DateTime.Now.ToString(), contexts);
                                    throw new Exception("插入营收统计原始记录失败!");
                                }
                            }
                        }
                    }
                    Console.WriteLine("检验营收统计是否正确完成");
                }
            }
            catch (Exception ex)
            {
                GlobalFunc.LogError(typeof(AutoCheckCardDailyJobImp), "插入营收统计记录失败!", ex);
            }
        }

        public void ExecuteJob()
        {
            Console.WriteLine($"开始执行检验营收统计是否正确!");
            Execute();
        }
    }
}
