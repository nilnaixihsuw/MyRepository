﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.HangfireManage
{
    public interface IOaWageDriverDayJobImp
    {
        Task Execute(DateTime? begin_time = null, DateTime? end_time = null, string driver_name = "");

        Task<List<DriverLine>> GetDriverLine(string driver_name);
    }
}
