﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ERPBll.OAManage;
using ERPBll.RedisManage.Users;
using ERPDal;
using ERPModel.Oamanage.OaKqDays;
using ERPModel.Oamanage.OaKqRecords;
using Serilog;

namespace ERPBll.HangfireManage
{
    public class AutoCheckKqImp : IAutoCheckKqImp
    {
        private readonly IOaKqzImp _oaKqzImps;
        private readonly IOaKqRecordImp _oaKqRecordImp;
        private readonly ILogger _logger = Log.Logger;
        public AutoCheckKqImp(
            IOaKqzImp oaKqzImps,
            IOaKqRecordImp oaKqRecordImp)
        {
            _oaKqzImps = oaKqzImps;
            _oaKqRecordImp = oaKqRecordImp;
        }
        public async Task Execute(DateTime kq_date, string server_id = "60.191.59.11")
        {
            var db = SqlSugarHelper.DBClient(server_id);
            try
            {
                //将打卡有效期已过且未打卡的状态改为缺卡
                var ids = await db.Queryable<OaKqRecord>().Where(x => x.state == 0 && x.end_time < kq_date).Select(x => x.id).ToListAsync();
                if (ids != null && ids.Count > 0)
                {
                    await db.Updateable<OaKqRecord>().SetColumns(it => it.state == 5).Where(it => ids.Contains(it.id)).ExecuteCommandAsync();
                }
                var yc_kq = await db.Queryable<OaKqRecord>().Where(x => x.state > 1 && x.state != 12).Select(x => x.kq_code).Distinct().ToListAsync();
                if (yc_kq != null && yc_kq.Count > 0)
                {
                    await db.Updateable<OaKqDay>().SetColumns(it => it.is_yc == 1).Where(it => yc_kq.Contains(it.kq_code)).ExecuteCommandAsync();
                }
                var users_kq = await db.Queryable<OaKqRecord>()
                    .GroupBy(x => new { x.kq_code, x.state })
                    .Select(x => new { x.kq_code, x.state })
                    .ToListAsync();

                var kq_codes = users_kq.Where(x => x.state == 5 && (users_kq.Count(y => y.kq_code == x.kq_code) == 1)).Select(x => x.kq_code).ToList();
                if (kq_codes != null && kq_codes.Count > 0)
                {
                    await db.Updateable<OaKqDay>().SetColumns(it => it.state == 3).Where(it => kq_codes.Contains(it.kq_code)).ExecuteCommandAsync();
                }

            }
            catch (Exception ex)
            {
                _logger.Information("生成考勤记录失败:@message", ex.ToString());
                throw;
            }
        }
        public void ExecuteJob()
        {
            Execute(DateTime.Now);
        }
    }
}
