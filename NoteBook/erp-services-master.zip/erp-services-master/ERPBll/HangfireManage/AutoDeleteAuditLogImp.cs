﻿using ERPBll.AuditLogs;
using ERPCore;
using ERPCore.ORM;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.HangfireManage
{
    public class AutoDeleteAuditLogImp : IAutoDeleteAuditLogImp
    {
        private readonly IAuditiLogImp _iAuditiLogImp;
        private readonly IConfiguration _configuration;

        public AutoDeleteAuditLogImp(
            IConfiguration configuration,
            IAuditiLogImp iAuditiLogImp)
        {
            _iAuditiLogImp = iAuditiLogImp;
            _configuration = configuration;
        }

        public async Task Execute()
        {
            try
            {
                Console.WriteLine($"开始删除审计日志!");

                var serverIds = _configuration.GetSection("Sugar").Get<SugarOption>().ProjectConfig.ConfigList["Server"].Select(it => it.Url).ToList();
                foreach (var serverId in serverIds)
                {
                    await _iAuditiLogImp.AutoDeleteAsync(serverId);
                }

                Console.WriteLine($"{DateTime.Now}删除审计日志成功!");
            }
            catch (Exception ex)
            {
                GlobalFunc.LogError(typeof(AutoOperateBusRequestImp), "删除审计日志失败!", ex);
            }
        }

        public void ExecuteJob()
        {
            Execute();
        }
    }
}
