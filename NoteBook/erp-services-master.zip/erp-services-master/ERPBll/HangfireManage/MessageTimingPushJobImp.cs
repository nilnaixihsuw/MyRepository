﻿using ERPBll.MaintManage;
using ERPBll.SignalRs;
using ERPBll.WorkPlace;
using ERPCore;
using ERPCore.ORM;
using ERPDal.WorkPlace;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusTools.JiGuang;
using BusTools.JiGuang.Contracts;
using BusTools.JiGuang.Model.Pushs;
using ERPCore.DI;
using ERPDal;
using ERPModel.Workplace;
using ERPModel.UserManage;
using ERPModel.FlowManage.ErpFlowChecks;
using ERPModel.FlowManage.FlowRecords;
using ERPBll.FlowManage.Contracts;

namespace ERPBll.HangfireManage
{
    public class MessageTimingPushJobImp : IMessageTimingPushJobImp
    {
        private readonly IConfiguration _configuration;
        private readonly IServerHubImp _iServerHubImp;
        private readonly IErpMessageMainImp _erpMessageMainImp;
        private readonly IErpFlowCheckImp _erpFlowCheckImp;

        public MessageTimingPushJobImp(
            IConfiguration iConfiguration,
            IServerHubImp iServerHubImp,
            IErpMessageMainImp erpMessageMainImp,
            IErpFlowCheckImp erpFlowCheckImp)
        {
            _configuration = iConfiguration;
            _iServerHubImp = iServerHubImp;
            _erpMessageMainImp = erpMessageMainImp;
            _erpFlowCheckImp = erpFlowCheckImp;
        }

        public async Task Execute(string server_id = "60.191.59.11")
        {
            var users = _iServerHubImp.GetAll().Select(x => x.user_id).Distinct().ToList();
            if (users != null && users.Count > 0)
            {
                using (var db = SqlSugarHelper.DBClient(server_id))
                {
                    foreach (var user in users)
                    {
                        await _erpMessageMainImp.PushNoReadCount(server_id, Convert.ToInt32(user));
                        await _erpFlowCheckImp.PushWaitCount(server_id, Convert.ToInt32(user));
                    }
                }
            }
        }

        public void ExecuteJob()
        {
            Execute();
        }
    }
}
