﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.HangfireManage
{
    public interface IAutoKqRecordImp
    {
        Task Execute(DateTime kq_date, string server_id = "60.191.59.11");
    }
}
