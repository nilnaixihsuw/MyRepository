﻿using ERPBll.EnterpriseManage.BusRequest;
using ERPCore;
using ERPCore.ORM;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.HangfireManage
{
    public class AutoOperateBusRequestImp : IAutoOperateBusRequestImp
    {
        private readonly IBusRequestImp _iBusRequestImp;
        private readonly IConfiguration _configuration;

        public AutoOperateBusRequestImp(
            IConfiguration configuration,
            IBusRequestImp iBusRequestImp)
        {
            _iBusRequestImp = iBusRequestImp;
            _configuration = configuration;
        }

        public async Task Execute()
        {
            try
            {
                Console.WriteLine($"开始处理公车预约记录!");

                var serverIds = _configuration.GetSection("Sugar").Get<SugarOption>().ProjectConfig.ConfigList["Server"].Select(it => it.Url).ToList();
                foreach (var serverId in serverIds)
                {
                    await _iBusRequestImp.AutoOperate(serverId);
                }

                Console.WriteLine($"{DateTime.Now}处理公车预约记录成功!");
            }
            catch (Exception ex)
            {
                GlobalFunc.LogError(typeof(AutoOperateBusRequestImp), "处理公车预约记录失败!", ex);
            }
        }

        public void ExecuteJob()
        {
            Execute();
        }
    }
}
