﻿using ERPBll.RedisManage.Lines;
using ERPBll.TicketManage;
using ERPCore;
using ERPCore.ORM;
using ERPDal.TicketManage;
using ERPModel.CommonModel;
using ERPModel.TicketManage;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.HangfireManage
{
    /// <summary>
    /// 刷卡每日汇总
    /// </summary>
    public class CardDailyJobImp: ICardDailyJobImp
    {
        private readonly IErpCardVehicleDayImp _iErpCardVehicleDayImp;
        private readonly IErpCardVehicleDayInitImp _iErpCardVehicleDayInitImp;
        private readonly IPosDataDetailDataImp _iPosDataDetailDataImp;
        private readonly IConfiguration _configuration;
        private readonly ILineRedisImp _lineRedisImp;
        private readonly CardMapping _cardMapping;

        public CardDailyJobImp(
            IErpCardVehicleDayImp iErpCardVehicleDayImp,
            IErpCardVehicleDayInitImp iErpCardVehicleDayInitImp,
            IPosDataDetailDataImp iPosDataDetailDataImp,
            IConfiguration configuration,
            ILineRedisImp lineRedisImp)
        {
            _configuration = configuration;
            _iPosDataDetailDataImp = iPosDataDetailDataImp;
            _iErpCardVehicleDayImp = iErpCardVehicleDayImp;
            _iErpCardVehicleDayInitImp = iErpCardVehicleDayInitImp;
            _lineRedisImp = lineRedisImp;
            _cardMapping = _configuration.GetSection("CardMapping").Get<CardMapping>();
        }

        public async Task Execute(DateTime? date = null)
        {
            try
            {
                Console.WriteLine($"开始生成刷卡记录!");
                var vehLines = await _lineRedisImp.GetLineVehAsync();
                //获取当天的记录
                var serverIds = _configuration.GetSection("Sugar").Get<SugarOption>().ProjectConfig.ConfigList["Server"].Select(it => it.Url).ToList();
                foreach (var serverId in serverIds)
                {
                    if (date == null)
                    {
                        date = DateTime.Now.AddDays(-1).Date;
                    }
                    // date = Convert.ToDateTime("2021-11-12");
                    var dayList = await _iErpCardVehicleDayImp.List(serverId, it => it.date == date);
                    if (dayList.Count > 0) await _iErpCardVehicleDayImp.Delete(serverId, dayList);
                    var dayInitList = await _iErpCardVehicleDayInitImp.List(serverId, it => it.date == date);
                    if (dayInitList.Count > 0) await _iErpCardVehicleDayInitImp.Delete(serverId, dayInitList);

                    var list = await _iPosDataDetailDataImp.GetCreditCardConsumptionDetl(serverId, date.Value, null, null, vehLines);
                    var inserts = list.Where(it => it.cardmaintype != "TAX")
                                      .Select(it => new { it.vehicle_id, it.swip_ymd, it.card_type, it.txnamtreal, it.line_id, it.line_name })
                                      .GroupBy(it => new { it.vehicle_id, it.swip_ymd, it.card_type, it.line_id, it.line_name })
                                      .Select(it => new ErpCardVehicleDay
                                      {
                                          vehicle_id = it.Key.vehicle_id,
                                          date = Convert.ToDateTime(it.Key.swip_ymd),
                                          type = it.Key.card_type,
                                          type_count = it.Count(),
                                          type_fee = it.Sum(c => c.txnamtreal),
                                          line_id = it.Key.line_id,
                                          line_name = it.Key.line_name,
                                          order = _cardMapping.Sort.IndexOf(it.Key.card_type),
                                          created_date = DateTime.Now
                                      })
                                      .ToList();
                    var oriInserts = list.Where(it => it.cardmaintype != "TAX")
                                         .Select(it => new { it.vehicle_id, it.swip_ymd, it.card_ori_type, it.txnamtreal, it.line_id, it.line_name })
                                         .GroupBy(it => new { it.vehicle_id, it.swip_ymd, it.card_ori_type, it.line_id, it.line_name })
                                         .Select(it => new ErpCardVehicleDayInit
                                         {
                                             vehicle_id = it.Key.vehicle_id,
                                             date = Convert.ToDateTime(it.Key.swip_ymd),
                                             type = it.Key.card_ori_type,
                                             type_count = it.Count(),
                                             type_fee = it.Sum(c => c.txnamtreal),
                                             line_id = it.Key.line_id,
                                             line_name = it.Key.line_name,
                                             order = _cardMapping.OriSort.IndexOf(it.Key.card_ori_type),
                                             created_date = DateTime.Now
                                         }).ToList();
                    if (inserts != null && inserts.Count > 0)
                    {
                        var r = await _iErpCardVehicleDayImp.Insert(serverId, inserts);
                        if (!r) throw new Exception("插入营收统计记录失败!");
                    }
                    if (oriInserts != null && oriInserts.Count > 0)
                    {
                        var r = await _iErpCardVehicleDayInitImp.Insert(serverId, oriInserts);
                        if (!r) throw new Exception("插入营收统计原始记录失败!");
                    }
                }
                Console.WriteLine($"{date}定时生成营收统计记录成功!");
            }
            catch (Exception ex)
            {
                GlobalFunc.LogError(typeof(CardDailyJobImp), "插入营收统计记录失败!", ex);
            }
        }

        public void ExecuteJob()
        {
            Console.WriteLine($"开始执行刷卡记录!");
            Execute();
        }
    }
}
