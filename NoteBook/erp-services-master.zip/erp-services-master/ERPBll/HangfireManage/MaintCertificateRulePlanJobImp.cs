﻿using ERPBll.WorkPlace;
using ERPCore;
using ERPCore.Entity;
using ERPCore.ORM;
using ERPDal;
using ERPModel.MaintManage.CertificateRules;
using ERPModel.UserManage;
using ERPModel.Workplace;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.HangfireManage
{
    public class MaintCertificateRulePlanJobImp
    {
        private readonly IConfiguration _configuration;
        private readonly IErpMessageMainImp _iErpMessageMainImp;
        public MaintCertificateRulePlanJobImp(
            IConfiguration configuration,
            IErpMessageMainImp iErpMessageMainImp)
        {
            _configuration = configuration;
            _iErpMessageMainImp = iErpMessageMainImp;
        }

        public async Task Execute()
        {
            try
            {
                Console.WriteLine($"开始检查司机驾驶证信息!");
                var serverIds = _configuration.GetSection("Sugar").Get<SugarOption>().ProjectConfig.ConfigList["Server"].Select(it => it.Url).ToList();
                foreach (var server_id in serverIds)
                {
                    var persons = await SqlSugarHelper.DBClient(server_id).Queryable<SysPerson>().ToListAsync();
                    var rule = await SqlSugarHelper.DBClient(server_id).Queryable<MaintCertificateRules>().Where(r => r.valid == 1).FirstAsync();
                    var list = new List<SysPerson>();
                    foreach (var plan in persons)
                    {
                        if (rule.warn_days != null && plan.d_latest_get_licence < DateTime.Now.AddDays(rule.warn_days.Value))
                        {
                            list.Add(plan);
                        }
                    }

                    if (list.Count > 0)
                    {
                        List<decimal> remain_ids = new List<decimal>();
                        if (string.IsNullOrWhiteSpace(rule.warn_person))
                        {
                            continue;
                        }
                        else if (rule.warn_person == "-1")
                        {
                            remain_ids = persons.Select(r => (decimal)r.i_id).ToList();
                        }
                        else
                        {
                            remain_ids = rule.warn_person.Split(",").Select(p => Convert.ToDecimal(p)).ToList();
                        }

                        foreach (var item1 in remain_ids)
                        {
                            var person = persons.Find(r => r.i_id == list[0].i_id);
                            string notice = $"{person.c_name}...等{list.Count()}等人的驾驶证即将到期，请及时处理";

                            ErpMessageMain erpMessageMain = new ErpMessageMain();
                            erpMessageMain.type = 42;
                            erpMessageMain.object_id = string.Join(',', list.Select(r => r.i_id));
                            erpMessageMain.created_id = item1;
                            erpMessageMain.title = notice;
                            await _iErpMessageMainImp.AddErpMessageMain(server_id, erpMessageMain, new ClientInformation { i_id = 2000000 });
                        }
                    }
                }


                Console.WriteLine($"{DateTime.Now}全部司机驾驶证信息记录检查完成!");
            }
            catch (Exception ex)
            {
                GlobalFunc.LogError(typeof(MaintInsuranceRulePlanJobImp), "全部司机驾驶证信息记录检查异常!", ex);
            }
        }

        public void ExecuteJob()
        {
            Execute();
        }
    }
}
