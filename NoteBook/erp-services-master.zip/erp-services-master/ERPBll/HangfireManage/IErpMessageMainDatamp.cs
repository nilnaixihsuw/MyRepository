﻿namespace ERPBll.HangfireManage
{
    internal interface IErpMessageMainDatamp
    {
    }
}