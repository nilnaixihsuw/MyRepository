﻿using ERPBll.OAManage;
using ERPDal;
using ERPModel.UserManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.HangfireManage
{
    public class LeaveBalanceJobImp
    {
        private readonly IOaLeaveBalanceImp _OaLeaveBalanceImp;

        public LeaveBalanceJobImp(
            IOaLeaveBalanceImp OaLeaveBalanceImp)
        {
            _OaLeaveBalanceImp = OaLeaveBalanceImp;
        }

        public async Task Execute(string server_id = "60.191.59.11")
        {
            await _OaLeaveBalanceImp.AddAsync(server_id);
        }

        public void ExecuteJob()
        {
            Execute();
        }
    }
}
