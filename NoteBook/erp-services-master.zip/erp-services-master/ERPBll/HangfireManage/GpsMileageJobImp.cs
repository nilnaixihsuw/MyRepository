﻿using AutoMapper;
using ERPBll.RedisManage;
using ERPCore.Helpers;
using ERPDal.MileManage;
using ERPModel.ApiModel;
using ERPModel.MileManage;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.HangfireManage
{
    public class GpsMileageJobImp : IGpsMileageJobImp
    {
        private readonly IMapper _imapper;
        private readonly IMaintOdometerDataImp _maintOdometerDataImp;
        private readonly IVehicleRedisManageImp _vehicleRedisManageImp;

        public GpsMileageJobImp(
            IMapper imapper,
            IMaintOdometerDataImp maintOdometerDataImp,
            IVehicleRedisManageImp vehicleRedisManageImp)
        {
            _imapper = imapper;
            _maintOdometerDataImp = maintOdometerDataImp;
            _vehicleRedisManageImp = vehicleRedisManageImp;
        }

        public async Task Execute()
        {
            //从缓存中获取所有车辆信息
            var list = await _vehicleRedisManageImp.GetAllAsync();
            var vehicle_name_list = list.Select(x => x.c_lincense_plate_number).ToList();

            ListHelper.ListSplit(20, vehicle_name_list, split =>
            {
                Task.Run(async () =>
                {
                    var query = new QueryGpsMile
                    {
                        begin_date = DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd"),
                        end_date = DateTime.Now.ToString("yyyy-MM-dd"),
                        vehicle_name_list = split
                    };

                    //获取车辆里程
                    var vehGpsMiles = await _maintOdometerDataImp.GetGpsMile(query);

                    if (vehGpsMiles != null)
                    {
                        vehGpsMiles.ForEach(async item =>
                        {
                            item.id = ERPBll.Tools.GetEngineID("60.191.59.11");
                            item.vehicle_id = list.FirstOrDefault(x => x.c_lincense_plate_number == item.vehicle_name)?.i_id;
                            item.date = DateTime.Now.AddDays(-1).Date;
                            item.create_id = 0;
                            item.create_date = DateTime.Now;
                        });
                    }

                    var maintOdometerDetail = _imapper.Map<List<GpsMileRepose>, List<MaintOdometerDetail>>(vehGpsMiles);

                    await _maintOdometerDataImp.InsertManyAsync("60.191.59.11", maintOdometerDetail);

                });
                return split;
            });
        }

        public void ExecuteJob()
        {
            Console.WriteLine($"开始执行gps里程!");
            Execute();
        }
    }
}
