﻿using ERPDal;
using ERPModel.PersonalManage;
using ERPModel.UserManage;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.HangfireManage
{
    /// <summary>
    /// 驾驶员综合奖核算任务（每月1号核算上月的综合奖）
    /// </summary>
    public class WageZhjJobImp: IWageZhjJobImp
    {
        private readonly IOaWageDriverDayJobImp _oaWageDriverDayJobImp;

        public WageZhjJobImp(IOaWageDriverDayJobImp oaWageDriverDayJobImp)
        {
            _oaWageDriverDayJobImp = oaWageDriverDayJobImp;
        }

        public async Task Execute(DateTime? begin_time = null, DateTime? end_time = null, string driver_name = "")
        {
            using (var db = SqlSugarHelper.DBClient("60.191.59.11"))
            {
                #region 获取综合奖设置

                var lineSetting = await db.Queryable<OaWageSetting>()
                                    .Where(x => x.type == 3)
                                    .Mapper(x => x.detail_items, x => x.detail_items.First().main_id)
                                    .ToListAsync();
                var lineSetDic = new Dictionary<int, List<OaWageSettingDetail>>();
                foreach (var item in lineSetting)
                {
                    var lineids = item.line_ids.Split(',');
                    foreach (var row in lineids)
                    {
                        int line_id = Convert.ToInt32(row);
                        if (!lineSetDic.ContainsKey(line_id))
                        {
                            lineSetDic.Add(line_id, item.detail_items);
                        }
                    }
                }

                #endregion

                #region 驾驶员线路出勤天数统计
                DateTime end = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);
                DateTime start = end.AddMonths(-1);
                if (begin_time.HasValue && end_time.HasValue)
                {
                    end = new DateTime(begin_time.Value.Year, begin_time.Value.Month, 1);
                    start = end.AddMonths(-1);
                }

                var query = await db.Queryable<OaWageDriverDay>()
                                    .LeftJoin<SysPerson>((x, y) => x.driver_id == y.i_id)
                                    .Where((x, y) => x.wage_date >= start && x.wage_date < end)
                                    .GroupBy((x, y) => new { x.driver_id, y.c_name })
                                    .Select((x, y) => new
                                    {
                                        driver_id = x.driver_id,
                                        driver_name = y.c_name,
                                        count = SqlFunc.AggregateCount(x.driver_id)
                                    })
                                    .ToListAsync();

                var lines = await _oaWageDriverDayJobImp.GetDriverLine("");
                foreach (var item in query)
                {
                    decimal fee = 0;
                    var line_id = lines.First(x => x.driver_name == item.driver_name).line_id;
                    if (lineSetDic.ContainsKey(line_id)) //线路是否有设置
                    {
                        var set = lineSetDic[line_id].FirstOrDefault(x => (x.min <= item.count && item.count <= x.max) ||
                                                                        (x.min <= item.count && x.max == -1));
                        if (set != null)
                        {
                            fee = set.value;
                        }
                    }
                    if (fee == 0) //使用默认设置
                    {
                        var set = lineSetDic[0].FirstOrDefault(x => (x.min <= item.count && item.count <= x.max) ||
                                                                       (x.min <= item.count && x.max == -1));
                        if (set != null)
                        {
                            fee = set.value;
                        }
                    }

                    await db.Updateable<OaWageDriverDay>().SetColumns(x => x.synthesize == fee).Where(x => x.driver_id == item.driver_id)
                             .ExecuteCommandAsync();
                }

                #endregion
            }
        }

        public void ExecuteJob()
        {
            Execute();
        }
    }
}
