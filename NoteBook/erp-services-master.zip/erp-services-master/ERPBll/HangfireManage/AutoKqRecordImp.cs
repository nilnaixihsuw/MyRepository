﻿using AutoMapper;
using ERPBll.OAManage;
using ERPBll.RedisManage.Users;
using ERPDal;
using ERPModel.Oamanage.OaKqbcs;
using ERPModel.Oamanage.OaKqDays;
using ERPModel.Oamanage.OaKqRecords;
using ERPModel.Oamanage.OaKqzs;
using Serilog;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.HangfireManage
{
    /// <summary>
    /// 生成每日考勤数据
    /// </summary>
    public class AutoKqRecordImp : IAutoKqRecordImp
    {
        private readonly IUserRedisImp _userRedisImp;
        private readonly IOaKqzImp _oaKqzImps;
        private readonly IOaKqRecordImp _oaKqRecordImp;
        private readonly ILogger _logger = Log.Logger;
        private readonly IMapper _imapper;

        public AutoKqRecordImp(
            IUserRedisImp userRedisImp,
            IOaKqzImp oaKqzImps,
            IOaKqRecordImp oaKqRecordImp,
            IMapper imapper)
        {
            _userRedisImp = userRedisImp;
            _oaKqzImps = oaKqzImps;
            _oaKqRecordImp = oaKqRecordImp;
            _imapper = imapper;
        }

        public async Task Execute(DateTime kq_date, string server_id = "60.191.59.11")
        {
            var db = SqlSugarHelper.DBClient(server_id);
            try
            {
                db.Ado.BeginTran();
                //var users = (await _userRedisImp.GetAllAsync()).Where(x => (x.i_emp_state == null || x.i_emp_state == 1) &&
                //    (x.i_is_driver == null || x.i_is_driver == 0)).Select(x => Convert.ToInt32(x.i_id)).ToList();
                var kqzs = await db.Queryable<OaKqz>().Where(x => x.is_delete == 0).Includes(x => x.kqz_users).ToListAsync();
                var users = new List<int>();
                foreach (var item in kqzs.Select(x => x.kqz_users))
                {
                    foreach (var user in item)
                    {
                        users.Add((int)user.user_id);
                    }
                }
                foreach (var userid in users)
                {
                    OaKqDay day = new OaKqDay()
                    {
                        kq_code = Tools.GetBusinessCode(),
                        user_id = userid,
                        kq_date = kq_date.Date
                    };
                    OaKqbcDay kqbc_day = new OaKqbcDay()
                    {
                        id = Tools.GetEngineID(server_id),
                        user_id = userid,
                        kq_date = kq_date.Date
                    };
                    var (kqbc_id, kqz_id) = await _oaKqzImps.GetDayKqbcAsync(server_id, userid, kq_date);
                    kqbc_day.kqbc_id = kqbc_id;
                    kqbc_day.kqz_id = (int)kqz_id;
                    if (kqbc_id == 0)
                    {
                        day.state = 0;
                        await db.Insertable(day).ExecuteCommandAsync();
                        continue;
                    }
                    await db.Insertable(kqbc_day).ExecuteCommandAsync();
                    var kqbc = await GetKqbcAsync(userid, kq_date, kqbc_day.kqbc_id, db);
                    List<CreateOaKqRecord> list = new List<CreateOaKqRecord>();
                    if (kqbc != null && kqbc.Count > 0)
                    {
                        day.state = 1;
                        foreach (var item in kqbc)
                        {
                            if (item.is_up == 1 && item.up_time.HasValue)
                            {
                                list.Add(new CreateOaKqRecord
                                {
                                    kq_code = day.kq_code,
                                    user_id = userid,
                                    kqz_id = item.kqz_id,
                                    kqbc_id = item.main_id,
                                    kq_date = kq_date.Date,
                                    start_time = kq_date.Date.AddHours(item.up_start.Value.Hour).AddMinutes(item.up_start.Value.Minute),
                                    end_time = kq_date.Date.AddHours(item.up_end.Value.Hour).AddMinutes(item.up_end.Value.Minute),
                                    type = 1,
                                    ls_time = kq_date.Date.AddHours(item.up_time.Value.Hour).AddMinutes(item.up_time.Value.Minute)
                                });
                            }
                            if (item.is_down == 1 && item.down_time.HasValue)
                            {
                                list.Add(new CreateOaKqRecord
                                {
                                    kq_code = day.kq_code,
                                    user_id = userid,
                                    kqz_id = item.kqz_id,
                                    kqbc_id = item.main_id,
                                    kq_date = kq_date.Date,
                                    start_time = kq_date.Date.AddHours(item.down_start.Value.Hour).AddMinutes(item.down_start.Value.Minute),
                                    end_time = kq_date.Date.AddHours(item.down_end.Value.Hour).AddMinutes(item.down_end.Value.Minute),
                                    type = 2,
                                    ls_time = kq_date.Date.AddHours(item.down_time.Value.Hour).AddMinutes(item.down_time.Value.Minute)
                                });
                            }
                        }
                    }
                    await db.Insertable(day).ExecuteCommandAsync();
                    await _oaKqRecordImp.AddAsync(server_id, list);                }
                db.Ado.CommitTran();
            }
            catch (Exception ex)
            {
                _logger.Information("生成考勤记录失败:@message", ex.ToString());
                db.Ado.RollbackTran();
            }
        }

        public void ExecuteJob()
        {
            Execute(DateTime.Now);
        }

        public async Task<List<OaKqbcChildDto>> GetKqbcAsync(int user_id, DateTime dt, int kqbc, SqlSugarClient db)
        {
            if (kqbc == 0) //休息不用打卡
            {
                return new List<OaKqbcChildDto>();
            }
            var kqzs = await db.Queryable<OaKqz>()
                               .Where(x => x.is_delete == 0)
                               .Includes(x => x.kqz_users)
                               .Includes(x => x.kqz_tsrqs)
                               .Includes(x => x.kqz_week)
                               .ToListAsync();

            var info = kqzs.FirstOrDefault(x => x.id == x.kqz_users.FirstOrDefault(y => y.user_id == user_id)?.kqz_id);
            var day_kqbc = await db.Queryable<OaKqbcChild>().Where(x => x.main_id == kqbc).ToListAsync();
            var user_data = _imapper.Map<List<OaKqbcChild>, List<OaKqbcChildDto>>(day_kqbc);
            user_data.ForEach(x => x.kqz_id = info.id);

            return user_data;
        }
    }
}
