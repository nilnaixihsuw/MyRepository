﻿using ERPBll.RedisManage.Trees;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.HangfireManage
{
    /// <summary>
    /// 车辆缓存
    /// </summary>
    public class VehicleCacheJobImp: IVehicleCacheJobImp
    {
        // redis车牌号树缓存key
        private readonly string _vehTreeKey = "vehicle_tree";
        private readonly string _vehOilTreeKey = "vehicle_oil_tree";
        private readonly string _vehEltricTreeKey = "vehicle_eltric_tree";
        // redis自编号树缓存key
        private readonly string _vehCodeTreeKey = "vehicle_code_tree";
        private readonly string _vehOilCodeTreeKey = "vehicle_oil_code_tree";
        private readonly string _vehEltricCodeTreeKey = "vehicle_eltric_code_tree";

        private readonly IVehicleTreeRedisImp _vehicleTreeRedisImp;

        public VehicleCacheJobImp(
            IVehicleTreeRedisImp vehicleTreeRedisImp)
        {
            _vehicleTreeRedisImp = vehicleTreeRedisImp;
        }

        public void ExecuteJob()
        {
            _vehicleTreeRedisImp.SetVehTreeRedisAsync("60.191.59.11", 0, _vehTreeKey).Wait();
            _vehicleTreeRedisImp.SetVehOilTreeRedisAsync("60.191.59.11", 0, _vehOilTreeKey).Wait();
            _vehicleTreeRedisImp.SetVehEletricTreeRedisAsync("60.191.59.11", 0, _vehEltricTreeKey).Wait();

            _vehicleTreeRedisImp.SetVehTreeRedisAsync("60.191.59.11", 1, _vehCodeTreeKey).Wait();
            _vehicleTreeRedisImp.SetVehOilTreeRedisAsync("60.191.59.11", 1, _vehOilCodeTreeKey).Wait();
            _vehicleTreeRedisImp.SetVehEletricTreeRedisAsync("60.191.59.11", 1, _vehEltricCodeTreeKey).Wait();
        }
    }
}
