﻿using BusTools.JiGuang;
using BusTools.JiGuang.Contracts;
using ERPBll.MaintManage;
using ERPBll.SignalRs;
using ERPBll.UserManage;
using ERPBll.Vehicleinfomanage;
using ERPBll.WorkPlace;
using ERPCore;
using ERPCore.Entity;
using ERPCore.ORM;
using ERPDal.MaintManage;
using ERPModel.ApiModel;
using ERPModel.Vehicleinfomanage;
using ERPModel.Workplace;
using ERPWeb.Manager;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.HangfireManage
{
    /// <summary>
    /// 年检计划每日生成
    /// </summary>
    public class MaintCheckRulePlanJobImp : IMaintCheckRulePlanJobImp
    {
        private readonly IMaintCheckRulesImp _maintCheckRulesImp;
        private readonly IMaintCheckPlanImp _maintCheckPlanImp;
        private readonly IVehicleInfoImp _vehicleInfoImp;
        private readonly IConfiguration _configuration;
        private readonly IErpVehicleStateWarnImp _erpVehicleStateWarnImp;
        private readonly IJSMSService _iJiGuangService;
        private readonly IServerHubImp _iServerHubImp;
        private readonly IConfiguration _iConfiguration;
        private readonly JiGuangMessageConfig _jiGuangMessageConfig;
        private readonly IErpMessageMainImp _iErpMessageMainImp;
        private readonly IMaintHintTemplateDataImp _iMaintHintTemplate;

        public MaintCheckRulePlanJobImp(
            IConfiguration iConfiguration,
            IServerHubImp iServerHubImp,
            IJSMSService iJiGuangService,
            IMaintCheckRulesImp maintCheckRulesImp,
            IMaintCheckPlanImp maintCheckPlanImp,
            IVehicleInfoImp vehicleInfoImp,
            IConfiguration configuration,
            IErpVehicleStateWarnImp erpVehicleStateWarnImp,
            IErpMessageMainImp iErpMessageMainImp,
            IMaintHintTemplateDataImp iMaintHintTemplate)
        {
            _iConfiguration = iConfiguration;
            _iServerHubImp = iServerHubImp;
            //_iJiGuangService = iJiGuangService;
            _maintCheckRulesImp = maintCheckRulesImp;
            _maintCheckPlanImp = maintCheckPlanImp;
            _vehicleInfoImp = vehicleInfoImp;
            _configuration = configuration;
            _erpVehicleStateWarnImp = erpVehicleStateWarnImp;
            _jiGuangMessageConfig = _iConfiguration.GetSection("JiGuangMessageConfig").Get<JiGuangMessageConfig>();
            _iErpMessageMainImp = iErpMessageMainImp;
            _iMaintHintTemplate = iMaintHintTemplate;
        }

        public async Task Execute()
        {
            try
            {
                GlobalFunc.LogInfo(typeof(MaintCheckRulePlanJobImp), "开始执行年检计划自动生成!");
                //获取ServerIds
                var serverIds = _configuration.GetSection("Sugar").Get<SugarOption>().ProjectConfig.ConfigList["Server"].Select(it => it.Url).ToList();
                foreach (var serverId in serverIds)
                {
                    var plans = new List<MaintCheckPlan>();
                    //获取规则
                    var rules = await _maintCheckRulesImp.List(serverId, it => it.i_valid == 1);
                    GlobalFunc.LogInfo(typeof(MaintCheckRulePlanJobImp), $"{serverId}当前有效规则条目数{rules.Count}");
                    var carInfos = _vehicleInfoImp.List(serverId, it => it.scrap == 0 || it.scrap == null).Result;
                    GlobalFunc.LogInfo(typeof(MaintCheckRulePlanJobImp), $"{serverId}当前有效车辆条目数{rules.Count}");
                    //已存计划
                    var existCheckPlans = _maintCheckPlanImp.List(serverId, it => true).Result;
                    rules.ForEach(rule =>
                    {
                        //根据规则生成年检计划
                        carInfos.ForEach(car =>
                        {
                            var vhcAge = (DateTime.Now - car.d_regist_certificate_date.Value).Days / Convert.ToDecimal(365);

                            //判断车辆是否需要生成年检计划
                            if (car.d_regist_certificate_date != null)
                            {
                                //是否需要生成年检计划
                                if (existCheckPlans.Count > 0)
                                {
                                    var checkRuleRecord = existCheckPlans.Where(it => it.i_rule_id == rule.i_id && it.i_vehicle_id == car.i_id).ToList();
                                    var latestRecord = checkRuleRecord.Find(it => it.d_check_time_plan == checkRuleRecord.Max(it => it.d_check_time_plan));
                                    if (checkRuleRecord.Count > 0)
                                    {
                                        if (latestRecord != null)
                                        {
                                            //本次未年检
                                            if (latestRecord.d_check_time_plan <= DateTime.Now && latestRecord.d_check_time_true == null)
                                            {
                                                //判断超期
                                                if (latestRecord.d_check_time_plan <= DateTime.Now && (DateTime.Now - latestRecord.d_check_time_plan.Value).Days >= _jiGuangMessageConfig.OverDay)
                                                {
                                                    //发送通知信息
                                                    SendNotification(rule.reminders, rule.i_warn_way.Value, car, latestRecord.d_check_time_plan.Value, "已结束");
                                                }
                                            }
                                            else
                                            {
                                                //计划已执行需要生成新的年检计划
                                                //判断是否满足规则
                                                if (vhcAge > rule.i_age_condition_min && vhcAge <= rule.i_age_condition_max)
                                                {
                                                    var planDate = latestRecord.d_check_time_plan.Value;
                                                    while (true)
                                                    {
                                                        if (rule.i_condition_type == 0)
                                                        {
                                                            planDate = planDate.AddMonths(6);
                                                        }
                                                        else
                                                        {
                                                            planDate = planDate.AddYears((int)rule.i_condition_type);
                                                        }
                                                        if (planDate > DateTime.Now) break;
                                                    }
                                                    //判断是否应生成计划
                                                    if (!existCheckPlans.Exists(it => it.i_rule_id == rule.i_id && it.i_vehicle_id == car.i_id && it.d_last_check_time == car.d_check_date))
                                                    {
                                                        //生成年检计划记录
                                                        var plan = new MaintCheckPlan
                                                        {
                                                            d_last_check_time = car.d_check_date,
                                                            d_check_time_plan = GetLastDayOfMonth(planDate),
                                                            i_vehicle_id = car.i_id,
                                                            i_rule_id = rule.i_id,
                                                            c_remark = "系统自动生成年检计划",
                                                            d_create = DateTime.Now.ToLocalTime(),
                                                            i_create_user = 200000,
                                                            i_approval_state = 0,
                                                            i_check_state = 0
                                                        };
                                                        plans.Add(plan);

                                                        //发送通知信息
                                                        SendNotification(rule.reminders, rule.i_warn_way.Value, car, plan.d_check_time_plan.Value, "还有");
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    else
                                    {
                                        //该车第一次生成年检计划
                                        //判断是否满足规则
                                        if (vhcAge > rule.i_age_condition_min && vhcAge <= rule.i_age_condition_max)
                                        {
                                            var planDate = car.d_check_date == null ? car.d_regist_certificate_date.Value : car.d_check_date.Value;
                                            while (true)
                                            {
                                                if (rule.i_condition_type == 0)
                                                {
                                                    planDate = planDate.AddMonths(6);
                                                }
                                                else
                                                {
                                                    planDate = planDate.AddYears((int)rule.i_condition_type);
                                                }
                                                if (planDate > DateTime.Now) break;
                                            }
                                            //生成年检计划记录
                                            var plan = new MaintCheckPlan
                                            {
                                                d_last_check_time = car.d_check_date,
                                                d_check_time_plan = GetLastDayOfMonth(planDate),
                                                i_vehicle_id = car.i_id,
                                                i_rule_id = rule.i_id,
                                                c_remark = "系统自动生成年检计划",
                                                d_create = DateTime.Now.ToLocalTime(),
                                                i_create_user = 200000,
                                                i_approval_state = 0,
                                                i_check_state = 0
                                            };
                                            plans.Add(plan);

                                            //发送通知信息
                                            SendNotification(rule.reminders, rule.i_warn_way.Value, car, plan.d_check_time_plan.Value, "还有");
                                        }
                                    }
                                }
                                else
                                {
                                    //年检计划表为空
                                    if (vhcAge > rule.i_age_condition_min && vhcAge <= rule.i_age_condition_max)
                                    {
                                        var planDate = car.d_check_date == null ? car.d_regist_certificate_date.Value : car.d_check_date.Value;
                                        while (true)
                                        {
                                            if (rule.i_condition_type == 0)
                                            {
                                                planDate = planDate.AddMonths(6);
                                            }
                                            else
                                            {
                                                planDate = planDate.AddYears((int)rule.i_condition_type);
                                            }
                                            if (planDate > DateTime.Now) break;
                                        }
                                        //生成年检计划记录
                                        var plan = new MaintCheckPlan
                                        {
                                            d_last_check_time = car.d_check_date,
                                            d_check_time_plan = GetLastDayOfMonth(planDate),
                                            i_vehicle_id = car.i_id,
                                            i_rule_id = rule.i_id,
                                            c_remark = "系统自动生成年检计划",
                                            d_create = DateTime.Now.ToLocalTime(),
                                            i_create_user = 200000,
                                            i_approval_state = 0,
                                            i_check_state = 0
                                        };
                                        plans.Add(plan);

                                        //发送通知信息
                                        SendNotification(rule.reminders, rule.i_warn_way.Value, car, plan.d_check_time_plan.Value, "还有");
                                    }
                                }
                            }
                        });

                    });
                    if (plans.Count > 0)
                    {
                        GlobalFunc.LogInfo(typeof(MaintCheckRulePlanJobImp), $"{serverId}当前有效计划条目数{plans.Count}");
                        var r = await _maintCheckPlanImp.Insert(serverId, plans);
                        if (!r)
                        {
                            GlobalFunc.LogInfo(typeof(MaintCheckRulePlanJobImp), "年检记录插入失败!");
                        }
                        else
                        {
                            List<ErpVehicleStateWarn> list = new List<ErpVehicleStateWarn>();
                            foreach (var item in plans)
                            {
                                //if (item.d_check_time_plan.Value.Year == DateTime.Now.Year && item.d_check_time_plan.Value.Month == DateTime.Now.Month)
                                //{
                                ErpVehicleStateWarn temp = new ErpVehicleStateWarn
                                {
                                    vehicle_id = item.i_vehicle_id,
                                    type = 1,
                                    end_time = item.d_check_time_plan,
                                    created_id = 200000,
                                    created_date = DateTime.Now.ToLocalTime()
                                };
                                list.Add(temp);
                                //}
                            }
                            if (list.Count > 0)
                            {
                                await _erpVehicleStateWarnImp.Insert(serverId, list);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                GlobalFunc.LogError(typeof(MaintCheckRulePlanJobImp), "生成年检计划失败!", ex);
            }

        }

        private void SendNotification(List<Reminder> reminders, decimal warn_way, ErpVehicleInfo car, DateTime check_time_plan, string type)
        {
            //发送该辆车的信息提醒
            if (_jiGuangMessageConfig.Open)
            {
                var days = (check_time_plan - DateTime.Now).Days;
                var msg = $"{car.c_lincense_plate_number}距离年检时间（{check_time_plan}）{type}{days}天！";
                var dic = new Dictionary<string, string>();
                dic.Add("plate_number", car.c_lincense_plate_number);
                dic.Add("check_time", check_time_plan.ToString());
                dic.Add("condition", "还有");
                dic.Add("day", days.ToString());
                switch (warn_way)
                {
                    //系统消息
                    case 1:
                        SendSysMessage(reminders, msg);
                        break;
                    //app推送
                    case 2:
                        SendAppMessage(reminders);
                        break;
                    //短信通知
                    case 3:
                        SendMessage(reminders, dic);
                        break;
                    //1+2
                    case 4:
                        SendSysMessage(reminders, msg);
                        SendAppMessage(reminders);
                        break;
                    //1+3
                    case 5:
                        SendSysMessage(reminders, msg);
                        SendMessage(reminders, dic);
                        break;
                    //2+3
                    case 6:
                        SendAppMessage(reminders);
                        SendMessage(reminders, dic);
                        break;
                    //1+2+3
                    case 7:
                        SendSysMessage(reminders, msg);
                        SendAppMessage(reminders);
                        SendMessage(reminders, dic);
                        break;
                }
            }
        }

        /// <summary>
        /// 发送短信
        /// </summary>
        /// <param name="rule"></param>
        /// <param name="dic"></param>
        private void SendMessage(List<Reminder> reminders, Dictionary<string, string> dic)
        {
            reminders.ForEach(item =>
            {
                if (!string.IsNullOrEmpty(item.phone))
                {
                    var r = _iJiGuangService.SendMessage(item.phone, _jiGuangMessageConfig.SignId, _jiGuangMessageConfig.TempId["MaintCheckRuleTemp"], dic).Result;
                    if (!r.is_send)
                    {
                        GlobalFunc.LogInfo(typeof(MaintCheckRulePlanJobImp), $"{dic["plate_number"]}发送短信失败!");
                    }
                }
            });
        }

        /// <summary>
        /// App推送
        /// </summary>
        /// <param name="rule"></param>
        private static void SendAppMessage(List<Reminder> reminders)
        {
            reminders.ForEach(item =>
            {
                //TODO
            });
        }

        /// <summary>
        /// 发送系统消息
        /// </summary>
        /// <param name="rule"></param>
        /// <param name="msg"></param>
        private void SendSysMessage(List<Reminder> reminder, string msg)
        {
            reminder.ForEach(item =>
            {
                _iServerHubImp.SendMessageByUserAsync(MessageType.MaintCheckRuleMessage, item.i_id.ToString(), msg);
            });
        }

        /// <summary>
        /// 获取当月最后一天
        /// </summary>
        /// <param name="dateTime"></param>
        /// <returns></returns>
        private DateTime GetLastDayOfMonth(DateTime dateTime)
        {
            //获取某年某月有多少天
            int monthDay = DateTime.DaysInMonth(dateTime.Year, dateTime.Month);
            DateTime date = new DateTime(dateTime.Year, dateTime.Month, monthDay);
            return date;
        }

        public void ExecuteJob()
        {
            Execute();
            AddMessage();
        }

        private async Task AddMessage()
        {
            string server_id = "60.191.59.11";
            //var messages = await _iErpMessageMainImp.List("60.191.59.11", null);
            var plans = await _maintCheckPlanImp.List(server_id, null);
            var rules = await _maintCheckRulesImp.List(server_id, null);
            var users = await _iMaintHintTemplate.List(server_id, null);
            var vehicles = await _vehicleInfoImp.List(server_id, null);
            List<MaintCheckPlan> list = new List<MaintCheckPlan>();
            foreach (var plan in plans)
            {
                var rule = rules.Find(r => r.i_id == plan.i_rule_id);
                if (rule.i_warn_days != null && plan.d_check_time_plan.Value < DateTime.Now.AddDays((int)rule.i_warn_days.Value)
                    && plan.i_check_state == 0)
                {
                    list.Add(plan);
                }
            }
            if (list.Count > 0)
            {
                var groups = list.GroupBy(r => r.i_rule_id);
                foreach (var group in groups)
                {
                    var user = users.Find(r => r.i_main_id == group.Key);
                    if (user.c_user_target_type == "1")
                    {
                        var temp = group.ToList();
                        var vehicle = vehicles.Find(r => r.i_id == temp[0].i_vehicle_id);
                        if(vehicle == null)
                        {
                            continue;
                        }
                        string notice = $"{vehicle.c_lincense_plate_number}...等{group.Count()}辆车待年检，请及时处理";

                        ErpMessageMain erpMessageMain = new ErpMessageMain();
                        erpMessageMain.type = 2;
                        erpMessageMain.model = (int)MessageType.MaintCheckNoticeMessage;
                        erpMessageMain.object_id = string.Join(',', temp.Select(r => r.i_id));
                        erpMessageMain.created_id = user.i_user_target_id;
                        erpMessageMain.title = notice;
                        await _iErpMessageMainImp.AddErpMessageMain(server_id, erpMessageMain, new ClientInformation { i_id = 2000000 });
                    }
                    else
                    {
                        var user_ids = RoleInfoBll.GetRolePerson(server_id, (decimal)user.i_user_target_id);
                        foreach (var item in user_ids)
                        {
                            var temp = group.ToList();
                            var vehicle = vehicles.Find(r => r.i_id == temp[0].i_vehicle_id);
                            string notice = $"{vehicle.c_lincense_plate_number}...等{group.Count()}辆车待年检，请及时处理";

                            ErpMessageMain erpMessageMain = new ErpMessageMain();
                            erpMessageMain.type = 2;
                            erpMessageMain.model = (int)MessageType.MaintCheckNoticeMessage;
                            erpMessageMain.object_id = string.Join(',', temp.Select(r => r.i_id));
                            erpMessageMain.created_id = item.user_id;
                            erpMessageMain.title = notice;
                            await _iErpMessageMainImp.AddErpMessageMain(server_id, erpMessageMain, new ClientInformation { i_id = 2000000 });
                        }
                    }
                }
            }
        }
    }
}
