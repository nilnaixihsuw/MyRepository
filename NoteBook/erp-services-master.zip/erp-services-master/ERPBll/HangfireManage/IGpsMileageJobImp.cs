﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.HangfireManage
{
    public interface IGpsMileageJobImp
    {
        /// <summary>
        /// 执行
        /// </summary>
        Task Execute();
    }
}
