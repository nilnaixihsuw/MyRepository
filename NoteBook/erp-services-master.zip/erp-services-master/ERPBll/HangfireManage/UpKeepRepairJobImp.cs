﻿using BusTools.JiGuang.Contracts;
using ERPBll.RedisManage.Users;
using ERPBll.Repairs.Contracts;
using ERPBll.WorkPlace;
using ERPCore.Entity;
using ERPDal;
using ERPModel.DataBase;
using ERPModel.Repairs;
using ERPModel.Repairs.MaintNoticeRule;
using ERPModel.Repairs.MaintRepairOrders;
using ERPModel.UserManage;
using ERPModel.Workplace;
using Microsoft.Extensions.Configuration;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.HangfireManage
{
    public class UpKeepRepairJobImp: IUpKeepRepairJobImp
    {
        private readonly IErpMessageMainImp _iErpMessageMainImp;
        private readonly IJSMSService _iJiGuangService;
        private readonly IUserRedisImp _userRedisImp;
        private readonly JiGuangMessageConfig _option;
        public UpKeepRepairJobImp(IErpMessageMainImp iErpMessageMainImp,
            IUserRedisImp userRedisImp,
            IConfiguration option,
            IJSMSService iJiGuangService)
        {
            _iErpMessageMainImp = iErpMessageMainImp;
            _iJiGuangService = iJiGuangService;
            _userRedisImp = userRedisImp;
            _option = option.GetSection("JiGuangMessageConfig").Get<JiGuangMessageConfig>();
        }
        public async Task Execute()
        {
            var DB = SqlSugarHelper.DBClient("60.191.59.11");
            var orders = DB.Queryable<MaintRepairOrder>().ToList();
            var records = await DB.Queryable<MaintRepairRecord, SysCommonDictDetail>((a, b) => new JoinQueryInfos(JoinType.Left, a.type_child == b.i_id))
                .Where((a, b) => b.c_name == "一保" || b.c_name == "二保")
                .Where((a, b) => SqlFunc.Oracle_ToChar(a.repair_time, "yyyy-MM-dd") == DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd"))
                .Where(a => orders.Select(m => m.repair_id).Contains(a.id))
                .Includes(a => a.vehicle_info)
                .ToListAsync();

            var rules = await DB.Queryable<MaintNoticeRule>()
                .Where(r => r.shop_id != null && records.Select(m => Convert.ToDecimal(m.repair_address_id)).Contains(r.shop_id.Value))
                .Where(r => r.type == 10 && r.enable == 1).ToListAsync();
            if (rules != null && rules.Count>0)
            {
                var rule_users = await DB.Queryable<MaintNoticeRuleUser>().ToListAsync();
                var dep_persons = await DB.Queryable<SysDepPerson>()
                              .Where(r => r.i_child_id >= 200000 && r.sign == 1).ToListAsync();
                var user_infos = await _userRedisImp.GetAllAsync();
                foreach (var rule in rules)
                {
                    var users = rule_users.Where(r => r.rule_id == rule.id).ToList();
                   
                    if (users != null && users.Count > 0)
                    {
                        var group = records.GroupBy(r => r.vehicle_info.c_crews_take);
                        foreach (var item1 in group)
                        {
                            var temp = item1.ToList();
                            var dic = new Dictionary<string, string>();
                            dic.Add("veh_code", temp[0].vehicle_info?.c_lincense_plate_number);
                            dic.Add("veh_count", temp.Count().ToString());
                            dic.Add("date", DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd"));
                            var persons = dep_persons.Where(r => r.i_group_id == Convert.ToDecimal(item1.Key)).ToList();
                            var user_ids = users.Select(r => r.user_id).Intersect(persons.Select(r => r.i_child_id.Value)).ToList();
                            foreach (var item2 in user_ids)
                            {
                                ErpMessageMain erpMessageMain = new ErpMessageMain();
                                erpMessageMain.type = 6;
                                erpMessageMain.model = (int)MessageModelDic.待检验消息;
                                erpMessageMain.object_id = string.Join(',', temp.Select(r => r.id));
                                erpMessageMain.created_id = item2;
                                erpMessageMain.title = $"【{temp[0].vehicle_info.c_lincense_plate_number}】等{temp.Count()}辆车【{DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd")}】未执行保养计划，请注意";
                                await _iErpMessageMainImp.AddErpMessageMain("60.191.59.11", erpMessageMain, new ClientInformation { i_id = 2000000 });

                                if (rule.receive_terminal.Contains("4"))
                                {
                                    var person = user_infos.Find(r => r.i_id == item2);
                                    if (person != null && !string.IsNullOrEmpty(person.c_phone))
                                    {
                                        await _iJiGuangService.SendMessage(person.c_phone, _option.SignId, _option.TempId["UpKeepRepairTemp"], dic);
                                    }
                                }
                            }
                        }
                       
                    }
                }
            }
        }

        public void ExecuteJob()
        {
            _ = Execute();
        }
    }
}
