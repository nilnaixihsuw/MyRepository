﻿using AutoMapper;
using ERPBll.WorkPlace;
using ERPCore;
using ERPCore.Entity;
using ERPCore.ORM;
using ERPDal;
using ERPModel.InsuranceManage;
using ERPModel.MaintManage.InsuranceRules;
using ERPModel.UserManage;
using ERPModel.Vehicleinfomanage;
using ERPModel.Workplace;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.HangfireManage
{
    public class MaintInsuranceRulePlanJobImp
    {
        private readonly IConfiguration _configuration;
        private readonly IMapper _imapper;
        private readonly IErpMessageMainImp _iErpMessageMainImp;
        public MaintInsuranceRulePlanJobImp(
            IConfiguration configuration,
            IMapper imapper,
            IErpMessageMainImp iErpMessageMainImp)
        {
            _configuration = configuration;
            _imapper = imapper;
            _iErpMessageMainImp = iErpMessageMainImp;
        }

        public async Task Execute()
        {
            try
            {
                Console.WriteLine($"开始检查保险记录!");
                var serverIds = _configuration.GetSection("Sugar").Get<SugarOption>().ProjectConfig.ConfigList["Server"].Select(it => it.Url).ToList();
                foreach (var server_id in serverIds)
                {
                    var plans = await SqlSugarHelper.DBClient(server_id).Queryable<ErpInsuranceMain>().ToListAsync();
                    var rule = await SqlSugarHelper.DBClient(server_id).Queryable<MaintInsuranceRules>().Where(r => r.valid == 1).FirstAsync();
                    var vehicles = await SqlSugarHelper.DBClient(server_id).Queryable<VehicleInfoNew>().ToListAsync();
                    var list = new List<ErpInsuranceMain>();
                    foreach (var plan in plans)
                    {
                        if (rule.warn_days != null && plan.insurance_end < DateTime.Now.AddDays(rule.warn_days.Value))
                        {
                            list.Add(plan);
                        }
                    }

                    if (list.Count > 0)
                    {
                        List<decimal> remain_ids = new List<decimal>();
                        if (string.IsNullOrWhiteSpace(rule.warn_person))
                        {
                            continue;
                        }
                        else if (rule.warn_person == "-1")
                        {
                            remain_ids = await SqlSugarHelper.DBClient(server_id)
                                                        .Queryable<SysPerson>()
                                                        .Select(r=>(decimal)r.i_id)
                                                        .ToListAsync();
                        }
                        else
                        {
                            remain_ids = rule.warn_person.Split(",").Select(p => Convert.ToDecimal(p)).ToList();
                        }

                        foreach (var item1 in remain_ids)
                        {
                            var vehicle = vehicles.Find(r => r.id == list[0].vehicle_id);
                            string notice = $"{vehicle.lp_num}...等{list.Count()}辆车保险即将到期，请及时处理";

                            ErpMessageMain erpMessageMain = new ErpMessageMain();
                            erpMessageMain.type = 2;
                            erpMessageMain.model = 42;
                            erpMessageMain.object_id = string.Join(',', list.Select(r => r.id));
                            erpMessageMain.created_id = item1;
                            erpMessageMain.title = notice;
                            await _iErpMessageMainImp.AddErpMessageMain(server_id, erpMessageMain, new ClientInformation { i_id = 2000000 });
                        }
                    }
                }


                Console.WriteLine($"{DateTime.Now}保险记录检查完成!");
            }
            catch (Exception ex)
            {
                GlobalFunc.LogError(typeof(MaintInsuranceRulePlanJobImp), "保险记录检查异常!", ex);
            }
        }

        public void ExecuteJob()
        {
            Execute();
        }
    }
}
