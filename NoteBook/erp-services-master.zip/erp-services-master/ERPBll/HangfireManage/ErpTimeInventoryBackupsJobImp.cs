﻿using AutoMapper;
using ERPBll.MaterialManage.InventoryManage;
using ERPCore;
using ERPCore.ORM;
using ERPModel.MaterialManage.InventoryManage;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.HangfireManage
{
    public class ErpTimeInventoryBackupsJobImp
    {
        private readonly IErpTimeInventoryBackupsImp _iErpTimeInventoryBackupsImp;
        private readonly IErpTimeInventoryImp _iErpTimeInventoryImp;
        private readonly IConfiguration _configuration;
        private readonly IMapper _imapper;
        public ErpTimeInventoryBackupsJobImp(IErpTimeInventoryBackupsImp iErpTimeInventoryBackupsImp,
            IErpTimeInventoryImp iErpTimeInventoryImp,
            IConfiguration configuration,
            IMapper imapper)
        {
            _iErpTimeInventoryBackupsImp = iErpTimeInventoryBackupsImp;
            _iErpTimeInventoryImp = iErpTimeInventoryImp;
            _configuration = configuration;
            _imapper = imapper;
        }

        public async Task Execute()
        {
            try
            {
                Console.WriteLine($"开始备份库存月结记录!");
                if (DateTime.Now.Day != 1)
                {
                    return;
                }
                var serverIds = _configuration.GetSection("Sugar").Get<SugarOption>().ProjectConfig.ConfigList["Server"].Select(it => it.Url).ToList();
                foreach (var serverId in serverIds)
                {
                    var origins = await _iErpTimeInventoryImp.List(serverId, null);
                    if (origins != null && origins.Count > 0)
                    {
                        var list = _imapper.Map<List<ErpTimeInventory>, List<ErpTimeInventoryBackups>>(origins);
                        list.ForEach(r =>
                        {
                            r.created_date = DateTime.Now;
                            r.created_id = 200000;
                            r.backup_date = DateTime.Now.AddDays(-1);
                        });
                        await _iErpTimeInventoryBackupsImp.Insert(serverId, list);
                    }
                }
                    

                Console.WriteLine($"{DateTime.Now}备份库存月结记录成功!");
            }
            catch (Exception ex)
            {
                GlobalFunc.LogError(typeof(ErpTimeInventoryBackupsJobImp), "插入库存月结记录失败!", ex);
            }
        }

        public void ExecuteJob()
        {
            Execute();
        }
    }
}
