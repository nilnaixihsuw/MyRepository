﻿using BusTools.JiGuang;
using BusTools.JiGuang.Contracts;
using ERPBll.MaintManage;
using ERPBll.SignalRs;
using ERPBll.UserManage;
using ERPBll.Vehicleinfomanage;
using ERPBll.WorkPlace;
using ERPCore;
using ERPCore.Entity;
using ERPCore.ORM;
using ERPDal.MaintManage;
using ERPModel.ApiModel;
using ERPModel.Vehicleinfomanage;
using ERPModel.Workplace;
using ERPWeb.Manager;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.HangfireManage
{
    public class MaintDiscardRulePlanJobImp : IMaintDiscardRulePlanJobImp
    {
        private readonly IMaintDiscardRulesImp _iMaintDiscardRulesImp;
        private readonly IMaintDiscardPlanImp _iMaintDiscardPlanImp;
        private readonly IVehicleInfoImp _iVehicleInfoImp;
        private readonly IConfiguration _configuration;
        private readonly IErpVehicleStateWarnImp _iErpVehicleStateWarnImp;
        private readonly JiGuangMessageConfig _jiGuangMessageConfig;
        private readonly IJSMSService _iJiGuangService;
        private readonly IServerHubImp _iServerHubImp;
        private readonly IErpMessageMainImp _iErpMessageMainImp;
        private readonly IMaintHintTemplateDataImp _iMaintHintTemplate;

        public MaintDiscardRulePlanJobImp(
            IServerHubImp iServerHubImp,
            IJSMSService iJiGuangService,
            IErpVehicleStateWarnImp iErpVehicleStateWarnImp,
            IConfiguration iConfiguration,
            IVehicleInfoImp iVehicleInfoImp,
            IMaintDiscardPlanImp iMaintDiscardPlanImp,
            IMaintDiscardRulesImp iMaintDiscardRulesImp,
            IErpMessageMainImp iErpMessageMainImp,
            IMaintHintTemplateDataImp iMaintHintTemplate)
        {
            _iServerHubImp = iServerHubImp;
            _iJiGuangService = iJiGuangService;
            _iMaintDiscardRulesImp = iMaintDiscardRulesImp;
            _iMaintDiscardPlanImp = iMaintDiscardPlanImp;
            _configuration = iConfiguration;
            _iVehicleInfoImp = iVehicleInfoImp;
            _iErpVehicleStateWarnImp = iErpVehicleStateWarnImp;
            _jiGuangMessageConfig = _configuration.GetSection("JiGuangMessageConfig").Get<JiGuangMessageConfig>();
            _iErpMessageMainImp = iErpMessageMainImp;
            _iMaintHintTemplate = iMaintHintTemplate;
        }

        public async Task Execute()
        {
            try
            {
                GlobalFunc.LogInfo(typeof(MaintDiscardRulePlanJobImp), "开始执行报废计划自动生成!");
                //获取ServerIds
                var serverIds = _configuration.GetSection("Sugar").Get<SugarOption>().ProjectConfig.ConfigList["Server"].Select(it => it.Url).ToList();
                foreach (var serverId in serverIds)
                {
                    var plans = new List<MaintDiscardPlan>();
                    //获取规则
                    var rules = await _iMaintDiscardRulesImp.List(serverId, it => it.i_valid == 1);
                    GlobalFunc.LogInfo(typeof(MaintDiscardRulePlanJobImp), $"{serverId}当前有效规则条目数{rules.Count}");
                    var carInfos = await _iVehicleInfoImp.List(serverId, r => r.scrap == null || r.scrap == 0);
                    GlobalFunc.LogInfo(typeof(MaintDiscardRulePlanJobImp), $"{serverId}当前有效车辆条目数{rules.Count}");
                    //已存计划
                    var existCheckPlans = _iMaintDiscardPlanImp.List(serverId, it => true).Result;
                    rules.ForEach(rule =>
                    {
                        //根据规则生成报废计划
                        carInfos.ForEach(car =>
                        {
                            if (car.d_regist_certificate_date != null)
                            {
                                //判断车龄条件是否匹配
                                var vhcAge = (DateTime.Now - car.d_regist_certificate_date.Value).Days / Convert.ToDecimal(365);
                                //判断是否满足规则
                                if (vhcAge > rule.i_age_condition_min.Value && vhcAge <= rule.i_age_condition_max.Value)
                                {
                                    if (!existCheckPlans.Exists(it => it.rule_id == rule.i_id && it.vehicle_id == car.i_id))
                                    {
                                        //生成报废计划记录
                                        var plan = new MaintDiscardPlan
                                        {
                                            vehicle_id = car.i_id,
                                            rule_id = rule.i_id,
                                            //d_plan_date = DateTime.Now.ToLocalTime().AddDays(-Convert.ToInt16(rule.i_warn_days)),
                                            reason = "满足报废规则",
                                            remark = "系统自动生成报废计划",
                                            create = DateTime.Now.ToLocalTime(),
                                            create_id = 2000000,
                                            //i_approval_state = 0,
                                            check_state = 0,
                                            state = 1
                                        };
                                        plans.Add(plan);

                                        //发送通知信息
                                        SendNotification(rule.reminders, rule.i_warn_way == null ? 1 : rule.i_warn_way.Value, car, (int)vhcAge);
                                    }
                                }
                            }
                        });

                    });

                    GlobalFunc.LogInfo(typeof(MaintDiscardRulePlanJobImp), $"{serverId}当前有效计划条目数{plans.Count}");
                    if (plans.Count > 0)
                    {
                        var r = await _iMaintDiscardPlanImp.Insert(serverId, plans);
                        if (!r)
                        {
                            GlobalFunc.LogInfo(typeof(MaintDiscardRulePlanJobImp), "报废记录插入失败!");
                        }
                        else
                        {
                            var records = await _iErpVehicleStateWarnImp.List(serverId, r => r.type == 4);
                            List<ErpVehicleStateWarn> list = new List<ErpVehicleStateWarn>();
                            foreach (var item in plans)
                            {
                                ErpVehicleStateWarn temp = new ErpVehicleStateWarn();
                                temp.vehicle_id = item.vehicle_id;
                                temp.type = 4;
                                //temp.end_time = item.plan_date;
                                temp.created_id = 200000;
                                temp.created_date = DateTime.Now.ToLocalTime();
                                list.Add(temp);
                            }
                            list = list.Where(r => !records.Select(m => m.vehicle_id).Contains(r.vehicle_id)).ToList();
                            await _iErpVehicleStateWarnImp.Insert(serverId, list);
                        }
                    }
                }
                Console.WriteLine("报废计划自动生成成功!");
            }
            catch (Exception ex)
            {
                GlobalFunc.LogError(typeof(MaintDiscardRulePlanJobImp), "生成报废计划失败!", ex);
            }

        }
        private void SendNotification(List<Reminder> reminders, decimal warn_way, ErpVehicleInfo car, int year)
        {
            //发送该辆车的信息提醒
            if (_jiGuangMessageConfig.Open)
            {
                var msg = $"{car.c_lincense_plate_number}车龄已超过{year}年，请相关人员及时进行报废处理!";
                var dic = new Dictionary<string, string>();
                dic.Add("plate_number", car.c_lincense_plate_number);
                dic.Add("year", year.ToString());
                switch (warn_way)
                {
                    //系统消息
                    case 1:
                        SendSysMessage(reminders, msg);
                        break;
                    //app推送
                    case 2:
                        SendAppMessage(reminders);
                        break;
                    //短信通知
                    case 3:
                        SendMessage(reminders, dic);
                        break;
                    //1+2
                    case 4:
                        SendSysMessage(reminders, msg);
                        SendAppMessage(reminders);
                        break;
                    //1+3
                    case 5:
                        SendSysMessage(reminders, msg);
                        SendMessage(reminders, dic);
                        break;
                    //2+3
                    case 6:
                        SendAppMessage(reminders);
                        SendMessage(reminders, dic);
                        break;
                    //1+2+3
                    case 7:
                        SendSysMessage(reminders, msg);
                        SendAppMessage(reminders);
                        SendMessage(reminders, dic);
                        break;
                }
            }
        }

        /// <summary>
        /// 发送短信
        /// </summary>
        /// <param name="rule"></param>
        /// <param name="dic"></param>
        private void SendMessage(List<Reminder> reminders, Dictionary<string, string> dic)
        {
            reminders.ForEach(item =>
            {
                if (!string.IsNullOrEmpty(item.phone))
                {
                    var r = _iJiGuangService.SendMessage(item.phone, _jiGuangMessageConfig.SignId, _jiGuangMessageConfig.TempId["DiscardRuleTemp"], dic).Result;
                    if (!r.is_send)
                    {
                        GlobalFunc.LogInfo(typeof(MaintCheckRulePlanJobImp), $"{dic["plate_number"]}发送短信失败!");
                    }
                }
            });
        }

        /// <summary>
        /// App推送
        /// </summary>
        /// <param name="rule"></param>
        private static void SendAppMessage(List<Reminder> reminders)
        {
            reminders.ForEach(item =>
            {
                //TODO
            });
        }

        /// <summary>
        /// 发送系统消息
        /// </summary>
        /// <param name="rule"></param>
        /// <param name="msg"></param>
        private void SendSysMessage(List<Reminder> reminder, string msg)
        {
            if (reminder != null && reminder.Count > 0)
            {
                reminder.ForEach(item =>
                {
                    _iServerHubImp.SendMessageByUserAsync(MessageType.DiscardRuleMessage, item.i_id.ToString(), msg);
                });
            }
        }
        public void ExecuteJob()
        {
            Execute();
            //AddMessage();
        }

        private async Task AddMessage()
        {
            string server_id = "60.191.59.11";
            var plans = await _iMaintDiscardPlanImp.List(server_id, null);
            var rules = await _iMaintDiscardRulesImp.List(server_id, null);
            var users = await _iMaintHintTemplate.List(server_id, null);
            var vehicles = await _iVehicleInfoImp.List(server_id, null);
            List<MaintDiscardPlan> list = new List<MaintDiscardPlan>();
            foreach (var plan in plans)
            {
                var rule = rules.Find(r => r.i_id == plan.rule_id);
                if (rule.i_warn_days != null && plan.plan_date.Value < DateTime.Now.AddDays((int)rule.i_warn_days.Value)
                    && plan.check_state == 0)
                {
                    list.Add(plan);
                }
            }
            if (list.Count > 0)
            {
                var groups = list.GroupBy(r => r.rule_id);
                foreach (var group in groups)
                {
                    var user = users.Find(r => r.i_main_id == group.Key);
                    if (user.c_user_target_type == "1")
                    {
                        var temp = group.ToList();
                        var vehicle = vehicles.Find(r => r.i_id == temp[0].vehicle_id);
                        string notice = $"{vehicle.c_lincense_plate_number}...等{group.Count()}辆车待报废，请及时处理";

                        ErpMessageMain erpMessageMain = new ErpMessageMain();
                        erpMessageMain.type = 42;
                        erpMessageMain.object_id = string.Join(',', temp.Select(r => r.id));
                        erpMessageMain.created_id = user.i_user_target_id;
                        erpMessageMain.title = notice;
                        await _iErpMessageMainImp.AddErpMessageMain(server_id, erpMessageMain, new ClientInformation { i_id = 2000000 });
                    }
                    else
                    {
                        var user_ids = RoleInfoBll.GetRolePerson(server_id, (decimal)user.i_user_target_id);
                        foreach (var item in user_ids)
                        {
                            var temp = group.ToList();
                            var vehicle = vehicles.Find(r => r.i_id == temp[0].vehicle_id);
                            string notice = $"{vehicle.c_lincense_plate_number}...等{group.Count()}辆车待年检，请及时处理";

                            ErpMessageMain erpMessageMain = new ErpMessageMain();
                            erpMessageMain.type = 42;
                            erpMessageMain.object_id = string.Join(',', temp.Select(r => r.id));
                            erpMessageMain.created_id = item.user_id;
                            erpMessageMain.title = notice;
                            await _iErpMessageMainImp.AddErpMessageMain(server_id, erpMessageMain, new ClientInformation { i_id = 2000000 });
                        }
                    }
                }
            }
        }
    }
}
