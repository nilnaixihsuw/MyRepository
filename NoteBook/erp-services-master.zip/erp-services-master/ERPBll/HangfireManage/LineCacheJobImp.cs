﻿using BusTools.Redis;
using ERPBll.RedisManage.Lines;
using ERPCore;
using ERPCore.DI;
using ERPCore.Helpers;
using ERPCore.ORM;
using ErpModel.CommonModel;
using ERPModel.CommonModel;
using ERPModel.SystemManage;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.HangfireManage
{
    public class LineCacheJobImp : ILineCacheJobImp
    {
        private readonly IRedisService _redisService;
        private readonly string _lineKey = "line";
        private readonly string _stationKey = "station";
        private readonly string _driverLineKey = "driver_line";
        private readonly DispatchSys _option;

        public LineCacheJobImp(IConfiguration options)
        {
            _redisService = new RedisService(1);
            _option = options.GetSection("Sugar").Get<SugarOption>().DispatchSys;
        }

        #region 线路
        public async Task ExecuteLine()
        {
            //Console.WriteLine($"开始更新线路信息!");
            var list = await GetLineByDispatchAsync();

            if (list != null && list.Count > 0)
            {
                //Console.WriteLine($"更新线路信息成功!");
                var res = _redisService.StringSet(_lineKey, list);
                if (!res)
                {
                    throw new Exception("更新线路信息失败!");
                }

                var _iLineRedisImp = DIContainer.ServiceLocator.Instance.GetService<ILineRedisImp>();
                _redisService.KeyDelete("line_vehicle");
                await _iLineRedisImp.GetLineVehAsync();
            }
        }
        #endregion

        #region 站点
        public async Task ExecuteStation()
        {
            //Console.WriteLine($"开始更新线路信息!");
            var list = await GetAllStationsAsync();

            if (list != null && list.Count > 0)
            {
                //Console.WriteLine($"更新站点信息成功!");
                _redisService.StringSet(_stationKey, list);
            }
        }

        public Task<List<Station>> GetAllStationsAsync()
        {
            try
            {
                var rep = new List<Station>();
                //获取线路信息
                var data = "req=" + JsonConvert.SerializeObject(new DispatchRequest
                {
                    head = new Head
                    {
                        cmd = "get_user_station_info",
                        user_id = _option.UserId,
                        server_id = _option.ServerId,
                        isCompress = false
                    },
                    content = new Content
                    {
                        //usable = 0
                    }
                });
                //Console.WriteLine("缓存请求站点信息:", _option.Url);
                GlobalFunc.LogInfo($"缓存请求站点信息:{ _option.Url},参数{data}");
                var repStr = HttpHelper.HttpPostFrom(_option.Url, data);
                if (!string.IsNullOrEmpty(repStr))
                {
                    var result = JsonConvert.DeserializeObject<DispatchStation>(repStr);
                    if (result.content.result == "200")
                    {
                        rep = result.content.items;
                    }
                    else
                    {
                        //记录错误日志
                    }
                }
                return Task.FromResult(rep);
            }
            catch (Exception ex)
            {
                GlobalFunc.LogError("获取站点错误", ex);
                return Task.FromResult(new List<Station>());
            }
        }
        #endregion

        #region 司机线路
        public async Task ExcuteDriverLine()
        {
            var list = await GetDriverLineByDispatchAsync();

            if (list != null && list.Count > 0)
            {
                var res = _redisService.StringSet(_driverLineKey, list);
                if (!res)
                {
                    throw new Exception("更新司机线路信息失败!");
                }
            }
        }
        #endregion

        public async Task<List<Line>> GetLineByDispatchAsync()
        {
            return await Task.Run(() =>
            {
                try
                {
                    var rep = new List<Line>();
                    //获取线路信息
                    var data = "req=" + JsonConvert.SerializeObject(new DispatchRequest
                    {
                        head = new Head
                        {
                            cmd = "get_route_data",
                            user_id = _option.UserId,
                            server_id = _option.ServerId,
                            isCompress = false
                        },
                        content = new Content
                        {
                            //usable = 0
                        }
                    });
                    //Console.WriteLine(DateTime.Now.ToString() + "缓存请求线路信息:" + _option.Url);
                    GlobalFunc.LogInfo($"缓存请求线路信息:{ _option.Url},参数{data}");
                    var repStr = HttpHelper.HttpPostFrom(_option.Url, data);
                    if (!string.IsNullOrEmpty(repStr))
                    {
                        var result = JsonConvert.DeserializeObject<DispatchResponse>(repStr);
                        if (result.head.result == "200")
                        {
                            rep = result.content.list;
                        }
                        else
                        {
                            //记录错误日志
                        }
                    }
                    return rep;
                }
                catch (Exception ex)
                {
                    GlobalFunc.LogError("获取线路错误", ex);
                    return null;
                }
            });
        }

        public async Task<List<Item>> GetDriverLineByDispatchAsync()
        {
            return await Task.Run(() =>
            {
                try
                {
                    var rep = new List<Item>();
                    //获取线路信息
                    var data = "req=" + JsonConvert.SerializeObject(new CommonDispatchRequest<object>
                    {
                        head = new Head
                        {
                            cmd = "get_driverline",
                            user_id = _option.UserId,
                            server_id = _option.ServerId,
                            isCompress = false
                        },
                        content = new
                        {
                            driver_name = ""
                        }
                    });
                    //Console.WriteLine(DateTime.Now.ToString() + "缓存请求线路信息:" + _option.Url);
                    GlobalFunc.LogInfo($"缓存请求司机线路信息:{ _option.Url},参数{data}");
                    var repStr = HttpHelper.HttpPostFrom(_option.Url, data);
                    if (!string.IsNullOrEmpty(repStr))
                    {
                        var result = JsonConvert.DeserializeObject<CommonDispatchResponse<Item>>(repStr);
                        if (result.content.result == "200")
                        {
                            rep = result.content.items;
                        }
                        else
                        {
                            //记录错误日志
                        }
                    }
                    return rep;
                }
                catch (Exception ex)
                {
                    GlobalFunc.LogError("获取线路错误", ex);
                    return null;
                }
            });
        }
        public void ExecuteJob()
        {
            ExecuteLine();
            ExecuteStation();
            ExcuteDriverLine();
        }
    }
}
