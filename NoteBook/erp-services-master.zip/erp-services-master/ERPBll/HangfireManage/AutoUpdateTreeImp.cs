﻿using ERPBll.RedisManage.Stations;
using ERPBll.RedisManage.Trees;
using ERPCore;
using ERPCore.ORM;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.HangfireManage
{
    public class AutoUpdateTreeImp : IAutoUpdateTreeImp
    {
        private readonly IDeptPersonRedisImp _deptPersonRedisImp;
        private readonly IDeptRedisImp _deptRedisImp;
        private readonly ILineTreeRedisImp _lineTreeRedisImp;
        private readonly IVehicleTreeRedisImp _vehicleTreeRedisImp;
        private readonly IStationRedisImp _stationRedisImp;
        private readonly IConfiguration _configuration;

        public AutoUpdateTreeImp(
            IDeptPersonRedisImp deptPersonRedisImp,
            IDeptRedisImp deptRedisImp,
            ILineTreeRedisImp lineTreeRedisImp,
            IVehicleTreeRedisImp vehicleTreeRedisImp,
            IStationRedisImp stationRedisImp,
        IConfiguration configuration)
        {
            _deptPersonRedisImp = deptPersonRedisImp;
            _deptRedisImp = deptRedisImp;
            _lineTreeRedisImp = lineTreeRedisImp;
            _vehicleTreeRedisImp = vehicleTreeRedisImp;
            _stationRedisImp = stationRedisImp;
            _configuration = configuration;
        }

        public async Task Execute()
        {
            try
            {
                Console.WriteLine($"开始更新下拉选择树!");

                await _stationRedisImp.AutoUpdateTree();

                var serverIds = _configuration.GetSection("Sugar").Get<SugarOption>().ProjectConfig.ConfigList["Server"].Select(it => it.Url).ToList();
                
                foreach (var serverId in serverIds)
                {
                    await _deptPersonRedisImp.AutoUpdateTree(serverId);
                    await _deptRedisImp.AutoUpdateTree(serverId);
                    await _lineTreeRedisImp.AutoUpdateTree(serverId);
                    await _vehicleTreeRedisImp.AutoUpdateTree(serverId);
                }

                Console.WriteLine($"{DateTime.Now}更新下拉选择树成功!");
            }
            catch (Exception ex)
            {
                GlobalFunc.LogError(typeof(AutoUpdateTreeImp), "更新下拉选择树失败!", ex);
            }
        }

        public void ExecuteJob()
        {
            Execute();
        }
    }
}
