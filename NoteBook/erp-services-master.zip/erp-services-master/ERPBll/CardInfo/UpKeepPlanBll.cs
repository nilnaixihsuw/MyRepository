﻿using ERPDal;
using ERPModel.MileManage;
using ERPModel.Vehicleinfomanage;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ERPBll.CardInfo
{
    public class UpKeepPlanBll
    {     
        /// <summary>
        /// 获取累积里程
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="date"></param>
        /// <returns></returns>
        public static decimal GetDistance(string serverID, DateTime date,decimal vehicle_id)
        {
            //return (double)SqlSugarHelper.DBClient(serverID)
            //    .Queryable<MaintOdometer, MaintOdometerDetail>((mo, mod) => new JoinQueryInfos(JoinType.Left, mo.id == mod.id))
            //    .Where((mo, mod) => mo.vehicle_id == vehicle_id)
            //    .Where((mo, mod) => mod.date <= date).Sum((mo, mod) => mod.mile);
            var list = SqlSugarHelper.DBClient(serverID).Queryable<MaintOdometerDetail>()
                .Where(r => r.vehicle_id == vehicle_id)
                .Where(r => r.date <= date).ToList();
            if (list != null && list.Count > 0)
            {
                return Math.Round(Convert.ToDecimal(list.Sum(r => r.mile)), 2, MidpointRounding.AwayFromZero);
            }
            else
                return 0;
        }    
    }
}
