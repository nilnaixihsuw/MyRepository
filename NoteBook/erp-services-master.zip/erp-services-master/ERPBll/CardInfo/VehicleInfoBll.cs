﻿using ERPBll.UserManage;
using ERPCore.ORM;
using ERPDal;
using ERPDal.SystemManage;
using ERPDal.VehiclInfo;
using ERPModel.DataBase;
using Microsoft.Extensions.Configuration;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using ERPModel.Vehicleinfomanage;
using ERPBll.RedisManage;
using ERPBll.RedisManage.Dicts;
using ERPModel.VehicleInfoManage;
using ERPModel.Repairs.MaintRepairOrders;
using BusTools.Redis;
using ERPModel.InsuranceManage;

namespace ERPBll.VehicleInfo
{
    public class VehicleInfoBll
    {
        /// <summary>
        /// 插入车辆信息
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="info"></param>
        /// <returns></returns>
        public static bool AddCInfo(string serverID, VehicleDetailInfo info)
        {
            return VehicleInfoDal.addCInfo(serverID, info);
        }
        /// <summary>
        /// 插入车辆信息
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="info"></param>
        /// <returns></returns>
        public static int AddCInfo(string serverID, VehicleInfoNew info)
        {
            return SqlSugarHelper.DBClient(serverID).Insertable(info).ExecuteCommand();
        }


        /// <summary>
        /// 导入许多车辆信息
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="infos"></param>
        /// <returns></returns>
        public static string AddManyCInfo(string serverID, List<VehicleDetailInfo> infos)
        {
            foreach (var item in infos)
            {
                if (VehicleInfoDal.getCInfoById(serverID, item.v_num).Rows.Count > 0)
                {
                    continue;
                }
                item.id = ERPBll.Tools.GetID(serverID);
                var r = VehicleInfoDal.addCInfo(serverID, item);
                if (!r)
                {
                    return item.v_num;
                }
            }
            return "success";
        }
        /// <summary>
        /// 导入许多车辆信息
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="infos"></param>
        /// <returns></returns>
        public static string AddManyCInfo(string serverID, List<ErpVehicleInfo> infos)
        {
            foreach (var item in infos)
            {
                if (SqlSugarHelper.DBClient(serverID).Queryable<ErpVehicleInfo>().Where(r => r.c_lincense_plate_number == item.c_lincense_plate_number).Count() > 0)
                {
                    continue;
                }
                else
                {
                    item.i_id = ERPBll.Tools.GetID(serverID);
                    SqlSugarHelper.DBClient(serverID).Insertable(item).ExecuteCommand();
                }
            }
            return "success";
        }

        /// <summary>
        /// 导入并更新许多车辆信息
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="infos"></param>
        /// <returns></returns>
        public static string AddOrUpdateManyCInfo(string serverID, List<VehicleDetailInfo> infos)
        {
            foreach (var item in infos)
            {
                if (VehicleInfoDal.getCInfoById(serverID, item.v_num).Rows.Count > 0)
                {
                    var r = VehicleInfoDal.updateCInfoByNum(serverID, item);
                    if (!r)
                    {
                        return item.v_num;
                    }
                }
                else
                {
                    item.id = ERPBll.Tools.GetID(serverID);
                    var r = VehicleInfoDal.addCInfo(serverID, item);
                    if (!r)
                    {
                        return item.v_num;
                    }
                }
            }
            return "success";
        }
        /// <summary>
        ///  导入并更新许多车辆信息
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="infos"></param>
        /// <returns></returns>
        public static string AddOrUpdateManyCInfo(string serverID, List<ErpVehicleInfo> infos)
        {
            var vehicles = SqlSugarHelper.DBClient(serverID).Queryable<ErpVehicleInfo>().ToList();
            foreach (var item in infos)
            {
                if (vehicles.Where(r => r.c_lincense_plate_number == item.c_lincense_plate_number).Count() > 0)
                {
                    SqlSugarHelper.DBClient(serverID).Updateable(item).WhereColumns(r => r.c_lincense_plate_number).IgnoreColumns(true, false, true).ExecuteCommand();
                }
                else
                {
                    if (string.IsNullOrEmpty(item.c_vehicle_number))
                    {
                        break;
                    }
                    item.i_id = ERPBll.Tools.GetID(serverID);
                    SqlSugarHelper.DBClient(serverID).Insertable(item).ExecuteCommand();
                }
            }
            return "success";
        }
        /// <summary>
        /// 删除车辆信息
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="vnum"></param>
        /// <returns></returns>
        public static bool DeleteCInfo(string serverID, string vnum)
        {
            return VehicleInfoDal.deleteCInfo(serverID, vnum);
        }
        /// <summary>
        /// 删除车辆信息
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="vnum"></param>
        /// <returns></returns>
        public static int DeleteCInfo1(string serverID, string vnum)
        {
            return SqlSugarHelper.DBClient(serverID).Deleteable<ErpVehicleInfo>().Where(r => r.c_vehicle_number == vnum).ExecuteCommand();
        }
        public static (int, string) DeleteCInfo1(string serverID, List<decimal?> ids)
        {
            var old_list = SqlSugarHelper.DBClient(serverID).Queryable<ErpVehicleInfo>().Where(r => ids.Contains(r.i_id)).ToList();

            var nums = string.Join(",", old_list.Select(x => x.c_lincense_plate_number).ToList().ToArray());

            return (SqlSugarHelper.DBClient(serverID).Deleteable<ErpVehicleInfo>().In(ids).ExecuteCommand(), nums);
        }
        /// <summary>
        /// 更新车辆信息
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="info"></param>
        /// <returns></returns>
        public static bool UpdateCInfo(string serverID, VehicleDetailInfo info)
        {
            return VehicleInfoDal.updateCInfoByID(serverID, info);
        }
        /// <summary>
        /// 更新车辆信息
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="info"></param>
        /// <returns></returns>
        public static (int, string) UpdateCInfo(string serverID, VehicleInfoNew info)
        {
            var old_info = SqlSugarHelper.DBClient(serverID).Queryable<VehicleInfoNew>().Where(r => r.id == info.id).First();

            var res = SqlSugarHelper.DBClient(serverID).Updateable(info).Where(r => r.id == info.id)
                .IgnoreColumns(new string[] { "scrap" }).ExecuteCommand();
            //.IgnoreColumns(true, false, true).ExecuteCommand();

            var str = "";
            if (res > 0)
            {
                str = Tools.CompareClass(old_info, info);
            }

            return (res, str);
        }

        public static int UpdateCarDept(string serverID, decimal vehicle_id,string dept_id)
        {
            return SqlSugarHelper.DBClient(serverID).Updateable<ErpVehicleInfo>().SetColumns(r => r.c_crews_take == dept_id)
                .Where(r => r.i_id == vehicle_id).ExecuteCommand();
        }
        /// <summary>
        /// 根据车辆ID更新车辆年检时间
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="id"></param>
        /// <param name="newCheckDate"></param>
        /// <returns></returns>
        public static int UpdateCheckDate(string serverID, decimal? id, DateTime? newCheckDate)
        {
            return SqlSugarHelper.DBClient(serverID).Updateable<ErpVehicleInfo>(r => r.d_check_date == newCheckDate).Where(r => r.i_id == id).ExecuteCommand();
        }

        /// <summary>
        /// 报废车辆
        /// </summary>
        /// <returns></returns>
        public static int ScrapVehicle(string serverID, decimal? id)
        {
            return SqlSugarHelper.DBClient(serverID).Updateable<ErpVehicleInfo>(r => r.scrap == 1).Where(r => r.i_id == id).ExecuteCommand();
        }
        public static int ScrapVehicle(string serverID, List<decimal?> ids)
        {
            return SqlSugarHelper.DBClient(serverID).Updateable<ErpVehicleInfo>(r => r.scrap == 1).Where(r => ids.Contains(r.i_id)).ExecuteCommand();
        }

        /// <summary>
        /// 根据指定条件获取车辆信息
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="cid">车型ID</param>
        /// <param name="kind">车辆类型</param>
        /// <param name="num">自编号/车牌号</param>
        /// <param name="group">所属组织ID</param>
        /// <returns></returns>
        public static List<VehicleDetailInfo> GetCInfoByCondition(string serverID, string cid,string kind,string num ,string group)
        {
            return default;
            //var dt = VehicleInfoDal.getCInfoByCondition(serverID, cid, kind, num,group);
            //List<VehicleDetailInfo> list = new List<VehicleDetailInfo>();
            //if (dt.Rows.Count>0)
            //{
            //    foreach (DataRow item in dt.Rows)
            //    {
            //        VehicleDetailInfo temp = new VehicleDetailInfo();
            //        temp.id = item["i_id"] is DBNull ? 0 : Convert.ToInt32(item["i_id"]);
            //        temp.cid = item["c_id"] is DBNull ? 0 : Convert.ToInt32(item["c_id"]);
            //        temp.name = item["c_name"] is DBNull ? "" : Convert.ToString(item["c_name"]);
            //        temp.v_num = item["c_vehicle_number"] is DBNull ? "" : Convert.ToString(item["c_vehicle_number"]);
            //        temp.lp_num = item["c_lincense_plate_number"] is DBNull ? "" : Convert.ToString(item["c_lincense_plate_number"]);
            //        temp.group = item["c_crews_take"] is DBNull ? "" : Convert.ToString(item["c_crews_take"]);
            //        temp.fra_num = item["c_frame_number"] is DBNull ? "" : Convert.ToString(item["c_frame_number"]);
            //        temp.reg_num = item["c_regist_certificate_number"] is DBNull ? "" : Convert.ToString(item["c_regist_certificate_number"]);
            //        temp.reg_date = item["d_regist_certificate_date"] is DBNull ? "" : Convert.ToDateTime(item["d_regist_certificate_date"]).ToString("yyyy-MM-dd HH:mm:ss");
            //        temp.lea_date = item["d_leave_factory_date"] is DBNull ? "" : Convert.ToDateTime(item["d_leave_factory_date"]).ToString("yyyy-MM-dd HH:mm:ss");
            //        temp.ins_date = item["d_insurance_date"] is DBNull ? "" : Convert.ToDateTime(item["d_insurance_date"]).ToString("yyyy-MM-dd HH:mm:ss");
            //        temp.up_date = item["d_upkeep_date"] is DBNull ? "" : Convert.ToDateTime(item["d_upkeep_date"]).ToString("yyyy-MM-dd HH:mm:ss");
            //        temp.check_date = item["d_check_date"] is DBNull ? "" : Convert.ToDateTime(item["d_check_date"]).ToString("yyyy-MM-dd HH:mm:ss");

            //        //temp.en_num = item["c_engine_number"] is DBNull ? "" : Convert.ToString(item["c_engine_number"]);
            //        //temp.en_type = item["c_engine_type"] is DBNull ? "" : Convert.ToString(item["c_engine_type"]);
            //        //temp.en_power = item["c_engine_power"] is DBNull ? "" : Convert.ToString(item["c_engine_power"]);
            //        //temp.en_date = item["d_engine_date"] is DBNull ? "" : Convert.ToDateTime(item["d_engine_date"]).ToString("yyyy-MM-dd HH:mm:ss");
            //        //temp.en_remark = item["c_engine_remark"] is DBNull ? "" : Convert.ToString(item["c_engine_remark"]);

            //        //temp.ti_num = item["c_tire_number"] is DBNull ? "" : Convert.ToString(item["c_tire_number"]);
            //        //temp.ti_type = item["c_tire_type"] is DBNull ? "" : Convert.ToString(item["c_tire_type"]);
            //        //temp.ti_price = item["c_tire_price"] is DBNull ? 0 : Convert.ToInt32(item["c_tire_price"]);
            //        //temp.ti_remark = item["c_tire_remark"] is DBNull ? "" : Convert.ToString(item["c_tire_remark"]);

            //        //temp.bat_num = item["c_battery_number"] is DBNull ? "" : Convert.ToString(item["c_battery_number"]);
            //        //temp.bat_type = item["c_battery_type"] is DBNull ? "" : Convert.ToString(item["c_battery_type"]);
            //        //temp.bat_brand = item["c_battery_brand"] is DBNull ? "" : Convert.ToString(item["c_battery_brand"]);
            //        //temp.bat_cc = item["c_battery_nominal_capacity"] is DBNull ? "" : Convert.ToString(item["c_battery_nominal_capacity"]);
            //        //temp.bat_range = item["c_battery_range"] is DBNull ? "" : Convert.ToString(item["c_battery_range"]);
            //        //temp.bat_remark = item["c_battery_remark"] is DBNull ? "" : Convert.ToString(item["c_battery_remark"]);

            //        temp.trans = item["c_transmission"] is DBNull ? "" : Convert.ToInt32(item["c_transmission"]);
            //        temp.floor_str = item["c_floor_struct"] is DBNull ? "" : Convert.ToString(item["c_floor_struct"]);
            //        temp.baffle = item["i_convenient_baffle"] is DBNull ? 0 : Convert.ToInt32(item["i_convenient_baffle"]);
            //        temp.protection = item["i_safety_protection"] is DBNull ? 1 : Convert.ToInt32(item["i_safety_protection"]);
            //        temp.air_brand = item["c_air_brand"] is DBNull ? "" : Convert.ToString(item["c_air_brand"]);

            //        temp.auto_sprink = item["i_automatic_sprinkler"] is DBNull ? 0 : Convert.ToInt32(item["i_automatic_sprinkler"]);
            //        temp.windows_str = item["c_windows_struct"] is DBNull ? "" : Convert.ToString(item["c_windows_struct"]);
            //        temp.slow_brand = item["c_slow_brand"] is DBNull ? "" : Convert.ToString(item["c_slow_brand"]);
            //        temp.lubrication = item["c_chassis_lubrication"] is DBNull ? "" : Convert.ToString(item["c_chassis_lubrication"]);

            //        temp.cool_sys = item["c_cool_system"] is DBNull ? "" : Convert.ToString(item["c_cool_system"]);
            //        temp.car_ter = item["c_car_terminal"] is DBNull ? "" : Convert.ToString(item["c_car_terminal"]);
            //        temp.video_mon = item["c_video_monitor"] is DBNull ? "" : Convert.ToString(item["c_video_monitor"]);
            //        temp.passenger_ana = item["c_passenger_analyzer"] is DBNull ? "" : Convert.ToString(item["c_passenger_analyzer"]);
            //        temp.safty_warn = item["c_safty_warn"] is DBNull ? "" : Convert.ToString(item["c_safty_warn"]);
            //        temp.dashcam = item["c_dashcam"] is DBNull ? "" : Convert.ToString(item["c_dashcam"]);
            //        temp.round_type = item["c_round_type"] is DBNull ? "" : Convert.ToString(item["c_round_type"]);

            //        temp.kind = item["c_kind"] is DBNull ? "" : Convert.ToString(item["c_kind"]);
            //        temp.factory = item["c_factory"] is DBNull ? "" : Convert.ToString(item["c_factory"]);
            //        temp.seats_num = item["i_seats_count"] is DBNull ? 0 : Convert.ToInt32(item["i_seats_count"]);
            //        temp.permit_num = item["i_permit_seat"] is DBNull ? 0 : Convert.ToInt32(item["i_permit_seat"]);
            //        temp.displacement = item["i_displacement"] is DBNull ? 0 : Convert.ToInt32(item["i_displacement"]);
            //        temp.standard = item["c_effluent_standard"] is DBNull ? "" : Convert.ToString(item["c_effluent_standard"]);
            //        temp.fuel = item["c_fuel"] is DBNull ? "" : Convert.ToString(item["c_fuel"]);
            //        temp.color = item["c_skin_color"] is DBNull ? "" : Convert.ToString(item["c_skin_color"]);
            //        temp.length = item["i_vehicle_length"] is DBNull ? 0 : Convert.ToInt32(item["i_vehicle_length"]);
            //        temp.width = item["i_vehicle_width"] is DBNull ? 0 : Convert.ToInt32(item["i_vehicle_width"]);
            //        temp.height = item["i_vehicle_height"] is DBNull ? 0 : Convert.ToInt32(item["i_vehicle_height"]);
            //        temp.wheel_space = item["i_wheel_space"] is DBNull ? 0 : Convert.ToInt32(item["i_wheel_space"]);
            //        temp.shaft_space = item["i_shaft_space"] is DBNull ? 0 : Convert.ToInt32(item["i_shaft_space"]);

            //        temp.permit_quality = item["i_permit_quality"] is DBNull ? 0 : Convert.ToInt32(item["i_permit_quality"]);
            //        temp.total_quality = item["i_total_quality"] is DBNull ? 0 : Convert.ToInt32(item["i_total_quality"]);
            //        temp.index = item["c_machine_index"] is DBNull ? "" : Convert.ToString(item["c_machine_index"]);
            //        temp.image_path = item["c_image_path"] is DBNull ? "" : Convert.ToString(item["c_image_path"]);
            //        list.Add(temp);
            //    }
            //}
            //return list;
        }

        /// <summary>
        /// 根据指定条件获取车辆信息
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="cid">车型ID</param>
        /// <param name="kind">车辆类型</param>
        /// <param name="num">自编号/车牌号</param>
        /// <param name="group_id">所属组织ID</param>
        /// <param name="page_index">页码</param>
        /// <param name="page_size">数据条数</param>
        /// <param name="is_scrap">是否报废 0：否，1：是</param>
        /// <returns></returns>
        public static Tuple<int, List<VehicleDetailInfo>> GetCInfoByCondition1(string serverID, string cid, string kind, string num, List<string> group_id,
            int page_index, int page_size, int is_scrap, List<decimal?> ids)
        {
            int total = 0;
            var dic = SqlSugarHelper.DBClient(serverID).Queryable<SysCommonDictDetail>().ToList();
            var list1 = DeptInfoBll.GetAllDeptments(serverID);
            var list = new List<VehicleDetailInfo>();
            if (page_index == 0)
            {
                list = SqlSugarHelper.DBClient(serverID)
              .Queryable<ErpVehicleInfo, MaintVehicleKind>((vi, mvk) => new JoinQueryInfos(JoinType.Left, vi.c_id == mvk.i_id))
              .WhereIF(!string.IsNullOrEmpty(cid), (vi, mvk) => vi.c_id == Convert.ToDecimal(cid))
              .WhereIF(!string.IsNullOrEmpty(kind), (vi, mvk) => mvk.c_kind == kind)
              .WhereIF(!string.IsNullOrEmpty(num), (vi, mvk) => vi.c_vehicle_number.Contains(num) || vi.c_lincense_plate_number.Contains(num))
              .WhereIF(group_id != null && group_id.Count > 0, (vi, mvk) => group_id.Contains(vi.c_crews_take))
              .WhereIF(is_scrap == 1, (vi, mvk) => vi.scrap == 1)
              .WhereIF(is_scrap == 0, (vi, mvk) => vi.scrap == 0 || vi.scrap == null)
              .WhereIF(ids != null && ids.Count > 0, vi => ids.Contains(vi.i_id))
              .OrderBy(vi => vi.c_lincense_plate_number)
              .Select((vi, mvk) => new VehicleDetailInfo
              {
                  id = Convert.ToInt32(vi.i_id),
                  cid = Convert.ToInt32(vi.c_id),

                  v_num = vi.c_vehicle_number,
                  lp_num = vi.c_lincense_plate_number,
                  group = string.IsNullOrWhiteSpace(vi.c_crews_take) ? 0 : Convert.ToInt32(vi.c_crews_take),
                  fra_num = vi.c_frame_number,
                  reg_num = vi.c_regist_certificate_number,
                  reg_date = ((DateTime)vi.d_regist_certificate_date).ToString("yyyy-MM-dd"),
                  lea_date = vi.d_leave_factory_date == null || vi.d_leave_factory_date == DateTime.MinValue ? "" : ((DateTime)vi.d_leave_factory_date).ToString("yyyy-MM-dd"),
                  ins_date = vi.d_insurance_date == null || vi.d_insurance_date == DateTime.MinValue ? "" : ((DateTime)vi.d_insurance_date).ToString("yyyy-MM-dd"),
                  up_date = vi.d_upkeep_date == null || vi.d_upkeep_date == DateTime.MinValue ? "" : ((DateTime)vi.d_upkeep_date).ToString("yyyy-MM-dd"),
                  check_date = vi.d_check_date == null || vi.d_check_date == DateTime.MinValue ? "" : ((DateTime)vi.d_check_date).ToString("yyyy-MM-dd"),

                  trans = string.IsNullOrWhiteSpace(vi.c_transmission) ? 0 : Convert.ToInt32(vi.c_transmission),
                  floor_str = string.IsNullOrWhiteSpace(vi.c_floor_struct) ? 0 : Convert.ToInt32(vi.c_floor_struct),
                  baffle = Convert.ToInt32(vi.i_convenient_baffle),
                  protection = Convert.ToInt32(vi.i_safety_protection),
                  air_brand = string.IsNullOrWhiteSpace(vi.c_air_brand) ? 0 : Convert.ToInt32(vi.c_air_brand),

                  auto_sprink = Convert.ToInt32(vi.i_automatic_sprinkler),
                  windows_str = string.IsNullOrWhiteSpace(vi.c_windows_struct) ? 0 : Convert.ToInt32(vi.c_windows_struct),
                  slow_brand = string.IsNullOrWhiteSpace(vi.c_slow_brand) ? 0 : Convert.ToInt32(vi.c_slow_brand),
                  lubrication = string.IsNullOrWhiteSpace(vi.c_chassis_lubrication) ? 0 : Convert.ToInt32(vi.c_chassis_lubrication),

                  cool_sys = string.IsNullOrWhiteSpace(vi.c_cool_system) ? 0 : Convert.ToInt32(vi.c_cool_system),
                  car_ter = string.IsNullOrWhiteSpace(vi.c_car_terminal) ? 0 : Convert.ToInt32(vi.c_car_terminal),
                  video_mon = string.IsNullOrWhiteSpace(vi.c_video_monitor) ? 0 : Convert.ToInt32(vi.c_video_monitor),
                  passenger_ana = string.IsNullOrWhiteSpace(vi.c_passenger_analyzer) ? 0 : Convert.ToInt32(vi.c_passenger_analyzer),
                  safty_warn = string.IsNullOrWhiteSpace(vi.c_safty_warn) ? 0 : Convert.ToInt32(vi.c_safty_warn),

                  dashcam = string.IsNullOrWhiteSpace(vi.c_dashcam) ? 0 : Convert.ToInt32(vi.c_dashcam),
                  round_type = string.IsNullOrWhiteSpace(vi.c_round_type) ? 0 : Convert.ToInt32(vi.c_round_type),
                  license_no = vi.c_business_license_no,
                  scrap = vi.scrap,

                  name = mvk.c_name,
                  kind = string.IsNullOrEmpty(mvk.c_kind) ? 0 : Convert.ToInt32(mvk.c_kind),
                  factory = mvk.c_factory,
                  seats_num = mvk.i_seats_count == null ? 0 : (int)mvk.i_seats_count,
                  permit_num = mvk.i_permit_seat == null ? 0 : (int)mvk.i_permit_seat,
                  displacement = Convert.ToInt32(mvk.i_displacement),
                  standard = string.IsNullOrEmpty(mvk.c_effluent_standard) ? 0 : Convert.ToInt32(mvk.c_effluent_standard),
                  fuel = string.IsNullOrEmpty(mvk.c_fuel) ? 0 : Convert.ToInt32(mvk.c_fuel),
                  color = mvk.c_skin_color,
                  length = Convert.ToInt32(mvk.i_vehicle_length),
                  width = Convert.ToInt32(mvk.i_vehicle_width),
                  height = Convert.ToInt32(mvk.i_vehicle_height),
                  wheel_space = (int)mvk.i_wheel_space,
                  shaft_space = (int)mvk.i_shaft_space,

                  permit_quality = (int)mvk.i_permit_quality,
                  total_quality = (int)mvk.i_total_quality,
                  index = mvk.c_machine_index,
                  image_path = mvk.c_image_path
              }).ToList();
                total = list.Count();
            }
            else
            {
                list = SqlSugarHelper.DBClient(serverID)
                  .Queryable<ErpVehicleInfo, MaintVehicleKind>((vi, mvk) => new JoinQueryInfos(JoinType.Left, vi.c_id == mvk.i_id))
                  .WhereIF(!string.IsNullOrEmpty(cid), (vi, mvk) => vi.c_id == Convert.ToDecimal(cid))
                  .WhereIF(!string.IsNullOrEmpty(kind), (vi, mvk) => mvk.c_kind == kind)
                  .WhereIF(!string.IsNullOrEmpty(num), (vi, mvk) => vi.c_vehicle_number.Contains(num) || vi.c_lincense_plate_number.Contains(num))
                  .WhereIF(group_id != null && group_id.Count > 0, (vi, mvk) => group_id.Contains(vi.c_crews_take))
                  .WhereIF(is_scrap == 1, (vi, mvk) => vi.scrap == 1)
                  .WhereIF(ids != null && ids.Count > 0, vi => ids.Contains(vi.i_id))
                  .OrderBy(vi => vi.c_lincense_plate_number)
                  .Select((vi, mvk) => new VehicleDetailInfo
                  {
                      id = Convert.ToInt32(vi.i_id),
                      cid = Convert.ToInt32(vi.c_id),

                      v_num = vi.c_vehicle_number,
                      lp_num = vi.c_lincense_plate_number,
                      group = string.IsNullOrWhiteSpace(vi.c_crews_take) ? 0 : Convert.ToInt32(vi.c_crews_take),
                      fra_num = vi.c_frame_number,
                      reg_num = vi.c_regist_certificate_number,
                      reg_date = ((DateTime)vi.d_regist_certificate_date).ToString("yyyy-MM-dd"),
                      lea_date = vi.d_leave_factory_date == null || vi.d_leave_factory_date == DateTime.MinValue ? "" : ((DateTime)vi.d_leave_factory_date).ToString("yyyy-MM-dd"),
                      ins_date = vi.d_insurance_date == null || vi.d_insurance_date == DateTime.MinValue ? "" : ((DateTime)vi.d_insurance_date).ToString("yyyy-MM-dd"),
                      up_date = vi.d_upkeep_date == null || vi.d_upkeep_date == DateTime.MinValue ? "" : ((DateTime)vi.d_upkeep_date).ToString("yyyy-MM-dd"),
                      check_date = vi.d_check_date == null || vi.d_check_date == DateTime.MinValue ? "" : ((DateTime)vi.d_check_date).ToString("yyyy-MM-dd"),

                      trans = string.IsNullOrWhiteSpace(vi.c_transmission) ? 0 : Convert.ToInt32(vi.c_transmission),
                      floor_str = string.IsNullOrWhiteSpace(vi.c_floor_struct) ? 0 : Convert.ToInt32(vi.c_floor_struct),
                      baffle = Convert.ToInt32(vi.i_convenient_baffle),
                      protection = Convert.ToInt32(vi.i_safety_protection),
                      air_brand = string.IsNullOrWhiteSpace(vi.c_air_brand) ? 0 : Convert.ToInt32(vi.c_air_brand),

                      auto_sprink = Convert.ToInt32(vi.i_automatic_sprinkler),
                      windows_str = string.IsNullOrWhiteSpace(vi.c_windows_struct) ? 0 : Convert.ToInt32(vi.c_windows_struct),
                      slow_brand = string.IsNullOrWhiteSpace(vi.c_slow_brand) ? 0 : Convert.ToInt32(vi.c_slow_brand),
                      lubrication = string.IsNullOrWhiteSpace(vi.c_chassis_lubrication) ? 0 : Convert.ToInt32(vi.c_chassis_lubrication),

                      cool_sys = string.IsNullOrWhiteSpace(vi.c_cool_system) ? 0 : Convert.ToInt32(vi.c_cool_system),
                      car_ter = string.IsNullOrWhiteSpace(vi.c_car_terminal) ? 0 : Convert.ToInt32(vi.c_car_terminal),
                      video_mon = string.IsNullOrWhiteSpace(vi.c_video_monitor) ? 0 : Convert.ToInt32(vi.c_video_monitor),
                      passenger_ana = string.IsNullOrWhiteSpace(vi.c_passenger_analyzer) ? 0 : Convert.ToInt32(vi.c_passenger_analyzer),
                      safty_warn = string.IsNullOrWhiteSpace(vi.c_safty_warn) ? 0 : Convert.ToInt32(vi.c_safty_warn),

                      dashcam = string.IsNullOrWhiteSpace(vi.c_dashcam) ? 0 : Convert.ToInt32(vi.c_dashcam),
                      round_type = string.IsNullOrWhiteSpace(vi.c_round_type) ? 0 : Convert.ToInt32(vi.c_round_type),
                      license_no = vi.c_business_license_no,
                      scrap = vi.scrap,

                      name = mvk.c_name,
                      kind = string.IsNullOrEmpty(mvk.c_kind) ? 0 : Convert.ToInt32(mvk.c_kind),
                      factory = mvk.c_factory,
                      seats_num = mvk.i_seats_count == null ? 0 : (int)mvk.i_seats_count,
                      permit_num = mvk.i_permit_seat == null ? 0 : (int)mvk.i_permit_seat,
                      displacement = Convert.ToInt32(mvk.i_displacement),
                      standard = string.IsNullOrEmpty(mvk.c_effluent_standard) ? 0 : Convert.ToInt32(mvk.c_effluent_standard),
                      fuel = string.IsNullOrEmpty(mvk.c_fuel) ? 0 : Convert.ToInt32(mvk.c_fuel),
                      color = mvk.c_skin_color,
                      length = Convert.ToInt32(mvk.i_vehicle_length),
                      width = Convert.ToInt32(mvk.i_vehicle_width),
                      height = Convert.ToInt32(mvk.i_vehicle_height),
                      wheel_space = (int)mvk.i_wheel_space,
                      shaft_space = (int)mvk.i_shaft_space,

                      permit_quality = (int)mvk.i_permit_quality,
                      total_quality = (int)mvk.i_total_quality,
                      index = mvk.c_machine_index,
                      image_path = mvk.c_image_path
                  }).ToPageList(page_index, page_size, ref total);
            }


            list.ForEach(m =>
            {
                m.trans_name = m.trans == 0 ? "" : dic.Where(r => r.i_id == m.trans).FirstOrDefault()?.c_name;
                m.floor_str_name = m.floor_str == 0 ? "" : dic.Where(r => r.i_id == m.floor_str).FirstOrDefault()?.c_name;
                m.windows_str_name = m.windows_str == 0 ? "" : dic.Where(r => r.i_id == m.floor_str).FirstOrDefault()?.c_name;
                m.air_brand_name = m.air_brand == 0 ? "" : dic.Where(r => r.i_id == m.air_brand).FirstOrDefault()?.c_name;
                m.slow_brand_name = m.slow_brand == 0 ? "" : dic.Where(r => r.i_id == m.slow_brand).FirstOrDefault()?.c_name;
                m.lubrication_name = m.lubrication == 0 ? "" : dic.Where(r => r.i_id == m.lubrication).FirstOrDefault()?.c_name;
                m.cool_sys_name = m.cool_sys == 0 ? "" : dic.Where(r => r.i_id == m.cool_sys).FirstOrDefault()?.c_name;
                m.car_ter_name = m.car_ter == 0 ? "" : dic.Where(r => r.i_id == m.car_ter).FirstOrDefault()?.c_name;
                m.video_mon_name = m.video_mon == 0 ? "" : dic.Where(r => r.i_id == m.video_mon).FirstOrDefault()?.c_name;
                m.passenger_ana_name = m.passenger_ana == 0 ? "" : dic.Where(r => r.i_id == m.passenger_ana).FirstOrDefault()?.c_name;
                m.safty_warn_name = m.safty_warn == 0 ? "" : dic.Where(r => r.i_id == m.safty_warn).FirstOrDefault()?.c_name;
                m.dashcam_name = m.dashcam == 0 ? "" : dic.Where(r => r.i_id == m.dashcam).FirstOrDefault()?.c_name;
                m.round_type_name = m.round_type == 0 ? "" : dic.Where(r => r.i_id == m.round_type).FirstOrDefault()?.c_name;
                m.kind_name = m.kind == 0 ? "" : dic.Where(r => r.i_id == m.kind).FirstOrDefault()?.c_name;
                m.fuel_name = m.fuel == 0 ? "" : dic.Where(r => r.i_id == m.fuel).FirstOrDefault()?.c_name;
                m.standard_name = m.standard == 0 ? "" : dic.Where(r => r.i_id == m.standard).FirstOrDefault()?.c_name;
                m.group_name = m.group == 0 ? "" : list1.Where(r => r.i_id == Convert.ToDecimal(m.group)).FirstOrDefault()?.c_name;
            });

            return new Tuple<int, List<VehicleDetailInfo>>(total, list);
        }

        /// <summary>
        /// 获取全部车辆信息
        /// </summary>
        /// <param name="serverID"></param>
        /// <returns></returns>
        public static List<VehicleDetailInfo> GetAllCInfo(string serverID)
        {
            return default;
            //var dt = VehicleInfoDal.getAllCInfo(serverID);
            //List<VehicleDetailInfo> list = new List<VehicleDetailInfo>();
            //if (dt.Rows.Count > 0)
            //{
            //    foreach (DataRow item in dt.Rows)
            //    {
            //        VehicleDetailInfo temp = new VehicleDetailInfo();
            //        temp.id = item["i_id"] is DBNull ? 0 : Convert.ToInt32(item["i_id"]);
            //        temp.cid = item["c_id"] is DBNull ? 0 : Convert.ToInt32(item["c_id"]);
            //        temp.name = item["c_name"] is DBNull ? "" : Convert.ToString(item["c_name"]);
            //        temp.v_num = item["c_vehicle_number"] is DBNull ? "" : Convert.ToString(item["c_vehicle_number"]);
            //        temp.lp_num = item["c_lincense_plate_number"] is DBNull ? "" : Convert.ToString(item["c_lincense_plate_number"]);
            //        temp.group = item["c_crews_take"] is DBNull ? "" : Convert.ToString(item["c_crews_take"]);
            //        temp.fra_num = item["c_frame_number"] is DBNull ? "" : Convert.ToString(item["c_frame_number"]);
            //        temp.reg_num = item["c_regist_certificate_number"] is DBNull ? "" : Convert.ToString(item["c_regist_certificate_number"]);
            //        temp.reg_date = item["d_regist_certificate_date"] is DBNull ? "" : Convert.ToDateTime(item["d_regist_certificate_date"]).ToString("yyyy-MM-dd HH:mm:ss");
            //        temp.lea_date = item["d_leave_factory_date"] is DBNull ? "" : Convert.ToDateTime(item["d_leave_factory_date"]).ToString("yyyy-MM-dd HH:mm:ss");
            //        temp.ins_date = item["d_insurance_date"] is DBNull ? "" : Convert.ToDateTime(item["d_insurance_date"]).ToString("yyyy-MM-dd HH:mm:ss");
            //        temp.up_date = item["d_upkeep_date"] is DBNull ? "" : Convert.ToDateTime(item["d_upkeep_date"]).ToString("yyyy-MM-dd HH:mm:ss");
            //        temp.check_date = item["d_check_date"] is DBNull ? "" : Convert.ToDateTime(item["d_check_date"]).ToString("yyyy-MM-dd HH:mm:ss");

            //        //temp.en_num = item["c_engine_number"] is DBNull ? "" : Convert.ToString(item["c_engine_number"]);
            //        //temp.en_type = item["c_engine_type"] is DBNull ? "" : Convert.ToString(item["c_engine_type"]);
            //        //temp.en_power = item["c_engine_power"] is DBNull ? "" : Convert.ToString(item["c_engine_power"]);
            //        //temp.en_date = item["d_engine_date"] is DBNull ? "" : Convert.ToDateTime(item["d_engine_date"]).ToString("yyyy-MM-dd HH:mm:ss");
            //        //temp.en_remark = item["c_engine_remark"] is DBNull ? "" : Convert.ToString(item["c_engine_remark"]);

            //        //temp.ti_num = item["c_tire_number"] is DBNull ? "" : Convert.ToString(item["c_tire_number"]);
            //        //temp.ti_type = item["c_tire_type"] is DBNull ? "" : Convert.ToString(item["c_tire_type"]);
            //        //temp.ti_price = item["c_tire_price"] is DBNull ? 0 : Convert.ToInt32(item["c_tire_price"]);
            //        //temp.ti_remark = item["c_tire_remark"] is DBNull ? "" : Convert.ToString(item["c_tire_remark"]);

            //        //temp.bat_num = item["c_battery_number"] is DBNull ? "" : Convert.ToString(item["c_battery_number"]);
            //        //temp.bat_type = item["c_battery_type"] is DBNull ? "" : Convert.ToString(item["c_battery_type"]);
            //        //temp.bat_brand = item["c_battery_brand"] is DBNull ? "" : Convert.ToString(item["c_battery_brand"]);
            //        //temp.bat_cc = item["c_battery_nominal_capacity"] is DBNull ? "" : Convert.ToString(item["c_battery_nominal_capacity"]);
            //        //temp.bat_range = item["c_battery_range"] is DBNull ? "" : Convert.ToString(item["c_battery_range"]);
            //        //temp.bat_remark = item["c_battery_remark"] is DBNull ? "" : Convert.ToString(item["c_battery_remark"]);

            //        temp.trans = item["c_transmission"] is DBNull ? "" : Convert.ToString(item["c_transmission"]);
            //        temp.floor_str = item["c_floor_struct"] is DBNull ? "" : Convert.ToString(item["c_floor_struct"]);
            //        temp.baffle = item["i_convenient_baffle"] is DBNull ? 0 : Convert.ToInt32(item["i_convenient_baffle"]);
            //        temp.protection = item["i_safety_protection"] is DBNull ? 1 : Convert.ToInt32(item["i_safety_protection"]);
            //        temp.air_brand = item["c_air_brand"] is DBNull ? "" : Convert.ToString(item["c_air_brand"]);

            //        temp.auto_sprink = item["i_automatic_sprinkler"] is DBNull ? 0 : Convert.ToInt32(item["i_automatic_sprinkler"]);
            //        temp.windows_str = item["c_windows_struct"] is DBNull ? "" : Convert.ToString(item["c_windows_struct"]);
            //        temp.slow_brand = item["c_slow_brand"] is DBNull ? "" : Convert.ToString(item["c_slow_brand"]);
            //        temp.lubrication = item["c_chassis_lubrication"] is DBNull ? "" : Convert.ToString(item["c_chassis_lubrication"]);

            //        temp.cool_sys = item["c_cool_system"] is DBNull ? "" : Convert.ToString(item["c_cool_system"]);
            //        temp.car_ter = item["c_car_terminal"] is DBNull ? "" : Convert.ToString(item["c_car_terminal"]);
            //        temp.video_mon = item["c_video_monitor"] is DBNull ? "" : Convert.ToString(item["c_video_monitor"]);
            //        temp.passenger_ana = item["c_passenger_analyzer"] is DBNull ? "" : Convert.ToString(item["c_passenger_analyzer"]);
            //        temp.safty_warn = item["c_safty_warn"] is DBNull ? "" : Convert.ToString(item["c_safty_warn"]);
            //        temp.dashcam = item["c_dashcam"] is DBNull ? "" : Convert.ToString(item["c_dashcam"]);
            //        temp.round_type = item["c_round_type"] is DBNull ? "" : Convert.ToString(item["c_round_type"]);

            //        temp.kind = item["c_kind"] is DBNull ? "" : Convert.ToString(item["c_kind"]);
            //        temp.factory = item["c_factory"] is DBNull ? "" : Convert.ToString(item["c_factory"]);
            //        temp.seats_num = item["i_seats_count"] is DBNull ? 0 : Convert.ToInt32(item["i_seats_count"]);
            //        temp.permit_num = item["i_permit_seat"] is DBNull ? 0 : Convert.ToInt32(item["i_permit_seat"]);
            //        temp.displacement = item["i_displacement"] is DBNull ? 0 : Convert.ToInt32(item["i_displacement"]);
            //        temp.standard = item["c_effluent_standard"] is DBNull ? "" : Convert.ToString(item["c_effluent_standard"]);
            //        temp.fuel = item["c_fuel"] is DBNull ? "" : Convert.ToString(item["c_fuel"]);
            //        temp.color = item["c_skin_color"] is DBNull ? "" : Convert.ToString(item["c_skin_color"]);
            //        temp.length = item["i_vehicle_length"] is DBNull ? 0 : Convert.ToInt32(item["i_vehicle_length"]);
            //        temp.width = item["i_vehicle_width"] is DBNull ? 0 : Convert.ToInt32(item["i_vehicle_width"]);
            //        temp.height = item["i_vehicle_height"] is DBNull ? 0 : Convert.ToInt32(item["i_vehicle_height"]);
            //        temp.wheel_space = item["i_wheel_space"] is DBNull ? 0 : Convert.ToInt32(item["i_wheel_space"]);
            //        temp.shaft_space = item["i_shaft_space"] is DBNull ? 0 : Convert.ToInt32(item["i_shaft_space"]);

            //        temp.permit_quality = item["i_permit_quality"] is DBNull ? 0 : Convert.ToInt32(item["i_permit_quality"]);
            //        temp.total_quality = item["i_total_quality"] is DBNull ? 0 : Convert.ToInt32(item["i_total_quality"]);
            //        temp.index = item["c_machine_index"] is DBNull ? "" : Convert.ToString(item["c_machine_index"]);
            //        temp.image_path = item["c_image_path"] is DBNull ? "" : Convert.ToString(item["c_image_path"]);
            //        list.Add(temp);
            //    }
            //}
            //return list;
        }
        /// <summary>
        /// 获取全部车辆信息
        /// </summary>
        /// <param name="serverID"></param>
        /// <returns></returns>
        public static List<VehicleDetailInfo> GetAllCInfo1(string serverID)
        {
            var dic = SqlSugarHelper.DBClient(serverID).Queryable<SysCommonDictDetail>().ToList();
            var list1 = DeptInfoBll.GetAllDeptments(serverID);
            //var list2 = SqlSugarHelper.DBClient(serverID).Queryable<VEHICLE_INFO>().ToList();
            var list = SqlSugarHelper.DBClient(serverID)
                 .Queryable<ErpVehicleInfo, MaintVehicleKind>((vi, mvk) => new JoinQueryInfos(JoinType.Left, vi.c_id == mvk.i_id))
                 .Select((vi, mvk) => new VehicleDetailInfo
                 {
                     id = Convert.ToInt32(vi.i_id),
                     cid = Convert.ToInt32(vi.c_id),

                     v_num = vi.c_vehicle_number,
                     lp_num = vi.c_lincense_plate_number,
                     group = string.IsNullOrWhiteSpace(vi.c_crews_take) ? 0 : Convert.ToInt32(vi.c_crews_take),
                     fra_num = vi.c_frame_number,
                     reg_num = vi.c_regist_certificate_number,
                     reg_date = ((DateTime)vi.d_regist_certificate_date).ToString("yyyy-MM-dd"),
                     lea_date = vi.d_leave_factory_date == null || vi.d_leave_factory_date == DateTime.MinValue ? "" : ((DateTime)vi.d_leave_factory_date).ToString("yyyy-MM-dd"),
                     ins_date = vi.d_insurance_date == null || vi.d_insurance_date == DateTime.MinValue ? "" : ((DateTime)vi.d_insurance_date).ToString("yyyy-MM-dd"),
                     up_date = vi.d_upkeep_date == null || vi.d_upkeep_date == DateTime.MinValue ? "" : ((DateTime)vi.d_upkeep_date).ToString("yyyy-MM-dd"),
                     check_date = vi.d_check_date == null || vi.d_check_date == DateTime.MinValue ? "" : ((DateTime)vi.d_check_date).ToString("yyyy-MM-dd"),

                     //en_num = vi.c_engine_number,
                     //en_type = vi.c_engine_type,
                     //en_power = vi.c_engine_power,
                     //en_date = vi.d_engine_date == null ? "" : ((DateTime)vi.d_engine_date).ToString("yyyy-MM-dd HH:mm:ss"),
                     //en_remark = vi.c_engine_remark,

                     //ti_num = vi.c_tire_number,
                     //ti_type = vi.c_tire_type,
                     //ti_price = Convert.ToInt32(vi.c_tire_price),
                     //ti_remark = vi.c_tire_remark,

                     //bat_num = vi.c_battery_number,
                     //bat_type = vi.c_battery_type,
                     //bat_brand = vi.c_battery_brand,
                     //bat_cc = vi.c_battery_nominal_capacity,
                     //bat_range = vi.c_battery_range,
                     //bat_remark = vi.c_battery_remark,

                     trans = string.IsNullOrWhiteSpace(vi.c_transmission) ? 0 : Convert.ToInt32(vi.c_transmission),
                     floor_str = string.IsNullOrEmpty(vi.c_floor_struct) ? 0 : Convert.ToInt32(vi.c_floor_struct),
                     baffle = Convert.ToInt32(vi.i_convenient_baffle),
                     protection = Convert.ToInt32(vi.i_safety_protection),
                     air_brand = string.IsNullOrWhiteSpace(vi.c_air_brand) ? 0 : Convert.ToInt32(vi.c_air_brand),

                     auto_sprink = Convert.ToInt32(vi.i_automatic_sprinkler),
                     windows_str = string.IsNullOrWhiteSpace(vi.c_windows_struct) ? 0 : Convert.ToInt32(vi.c_windows_struct),
                     slow_brand = string.IsNullOrWhiteSpace(vi.c_slow_brand) ? 0 : Convert.ToInt32(vi.c_slow_brand),
                     lubrication = string.IsNullOrWhiteSpace(vi.c_chassis_lubrication) ? 0 : Convert.ToInt32(vi.c_chassis_lubrication),

                     cool_sys = string.IsNullOrWhiteSpace(vi.c_cool_system) ? 0 : Convert.ToInt32(vi.c_cool_system),
                     car_ter = string.IsNullOrWhiteSpace(vi.c_car_terminal) ? 0 : Convert.ToInt32(vi.c_car_terminal),
                     video_mon = string.IsNullOrWhiteSpace(vi.c_video_monitor) ? 0 : Convert.ToInt32(vi.c_video_monitor),
                     passenger_ana = string.IsNullOrWhiteSpace(vi.c_passenger_analyzer) ? 0 : Convert.ToInt32(vi.c_passenger_analyzer),
                     safty_warn = string.IsNullOrWhiteSpace(vi.c_safty_warn) ? 0 : Convert.ToInt32(vi.c_safty_warn),

                     dashcam = string.IsNullOrWhiteSpace(vi.c_dashcam) ? 0 : Convert.ToInt32(vi.c_dashcam),
                     round_type = string.IsNullOrWhiteSpace(vi.c_round_type) ? 0 : Convert.ToInt32(vi.c_round_type),
                     license_no = vi.c_business_license_no,
                     scrap = vi.scrap,

                     name = mvk.c_name,
                     kind = string.IsNullOrEmpty(mvk.c_kind) ? 0 : Convert.ToInt32(mvk.c_kind),
                     factory = mvk.c_factory,
                     seats_num = mvk.i_seats_count == null ? 0 : (int)mvk.i_seats_count,
                     permit_num = mvk.i_permit_seat == null ? 0 : (int)mvk.i_permit_seat,
                     displacement = Convert.ToInt32(mvk.i_displacement),
                     standard = string.IsNullOrEmpty(mvk.c_effluent_standard) ? 0 : Convert.ToInt32(mvk.c_effluent_standard),
                     fuel = string.IsNullOrEmpty(mvk.c_fuel) ? 0 : Convert.ToInt32(mvk.c_fuel),
                     color = mvk.c_skin_color,
                     length = Convert.ToInt32(mvk.i_vehicle_length),
                     width = Convert.ToInt32(mvk.i_vehicle_width),
                     height = Convert.ToInt32(mvk.i_vehicle_height),
                     wheel_space = (int)mvk.i_wheel_space,
                     shaft_space = (int)mvk.i_shaft_space,

                     permit_quality = (int)mvk.i_permit_quality,
                     total_quality = (int)mvk.i_total_quality,
                     index = mvk.c_machine_index,
                     image_path = mvk.c_image_path
                 }).ToList();

            list.ForEach(m =>
            {
                m.trans_name = m.trans == 0 ? "" : dic.Where(r => r.i_id == m.trans).FirstOrDefault()?.c_name;
                m.floor_str_name = m.floor_str == 0 ? "" : dic.Where(r => r.i_id == m.floor_str).FirstOrDefault()?.c_name;
                m.windows_str_name = m.windows_str == 0 ? "" : dic.Where(r => r.i_id == m.floor_str).FirstOrDefault()?.c_name;
                m.air_brand_name = m.air_brand == 0 ? "" : dic.Where(r => r.i_id == m.air_brand).FirstOrDefault()?.c_name;
                m.slow_brand_name = m.slow_brand == 0 ? "" : dic.Where(r => r.i_id == m.slow_brand).FirstOrDefault()?.c_name;
                m.lubrication_name = m.lubrication == 0 ? "" : dic.Where(r => r.i_id == m.lubrication).FirstOrDefault()?.c_name;
                m.cool_sys_name = m.cool_sys == 0 ? "" : dic.Where(r => r.i_id == m.cool_sys).FirstOrDefault()?.c_name;
                m.car_ter_name = m.car_ter == 0 ? "" : dic.Where(r => r.i_id == m.car_ter).FirstOrDefault()?.c_name;
                m.video_mon_name = m.video_mon == 0 ? "" : dic.Where(r => r.i_id == m.video_mon).FirstOrDefault()?.c_name;
                m.passenger_ana_name = m.passenger_ana == 0 ? "" : dic.Where(r => r.i_id == m.passenger_ana).FirstOrDefault()?.c_name;
                m.safty_warn_name = m.safty_warn == 0 ? "" : dic.Where(r => r.i_id == m.safty_warn).FirstOrDefault()?.c_name;
                m.dashcam_name = m.dashcam == 0 ? "" : dic.Where(r => r.i_id == m.dashcam).FirstOrDefault()?.c_name;
                m.round_type_name = m.round_type == 0 ? "" : dic.Where(r => r.i_id == m.round_type).FirstOrDefault()?.c_name;
                m.kind_name = m.kind == 0 ? "" : dic.Where(r => r.i_id == m.kind).FirstOrDefault()?.c_name;
                m.fuel_name = m.fuel == 0 ? "" : dic.Where(r => r.i_id == m.fuel).FirstOrDefault()?.c_name;
                m.standard_name = m.standard == 0 ? "" : dic.Where(r => r.i_id == m.standard).FirstOrDefault()?.c_name;
                m.group_name = m.group == 0 ? "" : list1.Where(r => r.i_id == Convert.ToDecimal(m.group)).FirstOrDefault()?.c_name;
            });

            return list;
        }

        /// <summary>
        /// 获取车辆信息
        /// </summary>
        /// <param name="serverID"></param>
        /// <returns></returns>
        public static List<VehicleInfoNew> GetAllCInfo2(string serverID)
        {
            var list = SqlSugarHelper.DBClient(serverID).Queryable<VehicleInfoNew>().ToList();
            return list;
        }

        /// <summary>
        /// 根据车辆id获取车辆信息
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="id"></param>
        /// <returns></returns>
        public static List<VehicleDetailInfo> GetCInfoByVehicleID(string serverID, decimal? id)
        {
            var dic = SqlSugarHelper.DBClient(serverID).Queryable<SysCommonDictDetail>().ToList();
            var list1 = DeptInfoBll.GetAllDeptments(serverID);
            List<VehicleDetailInfo> list = SqlSugarHelper.DBClient(serverID)
                .Queryable<ErpVehicleInfo, MaintVehicleKind>((vi, mvk) => new JoinQueryInfos(JoinType.Left, vi.c_id == mvk.i_id))
                .Where((vi, mvk) => vi.i_id == id)
                 .Select((vi, mvk) => new VehicleDetailInfo
                 {
                     id = Convert.ToInt32(vi.i_id),
                     cid = Convert.ToInt32(vi.c_id),

                     v_num = vi.c_vehicle_number,
                     lp_num = vi.c_lincense_plate_number,
                     group = string.IsNullOrWhiteSpace(vi.c_crews_take) ? 0 : Convert.ToInt32(vi.c_crews_take),
                     fra_num = vi.c_frame_number,
                     reg_num = vi.c_regist_certificate_number,
                     reg_date = ((DateTime)vi.d_regist_certificate_date).ToString("yyyy-MM-dd"),
                     lea_date = vi.d_leave_factory_date == null || vi.d_leave_factory_date == DateTime.MinValue ? "" : ((DateTime)vi.d_leave_factory_date).ToString("yyyy-MM-dd"),
                     ins_date = vi.d_insurance_date == null || vi.d_insurance_date == DateTime.MinValue ? "" : ((DateTime)vi.d_insurance_date).ToString("yyyy-MM-dd"),
                     up_date = vi.d_upkeep_date == null || vi.d_upkeep_date == DateTime.MinValue ? "" : ((DateTime)vi.d_upkeep_date).ToString("yyyy-MM-dd"),
                     check_date = vi.d_check_date == null || vi.d_check_date == DateTime.MinValue ? "" : ((DateTime)vi.d_check_date).ToString("yyyy-MM-dd"),

                     trans = string.IsNullOrWhiteSpace(vi.c_transmission) ? 0 : Convert.ToInt32(vi.c_transmission),
                     floor_str = string.IsNullOrWhiteSpace(vi.c_floor_struct) ? 0 : Convert.ToInt32(vi.c_floor_struct),
                     baffle = Convert.ToInt32(vi.i_convenient_baffle),
                     protection = Convert.ToInt32(vi.i_safety_protection),
                     air_brand = string.IsNullOrWhiteSpace(vi.c_air_brand) ? 0 : Convert.ToInt32(vi.c_air_brand),

                     auto_sprink = Convert.ToInt32(vi.i_automatic_sprinkler),
                     windows_str = string.IsNullOrWhiteSpace(vi.c_windows_struct) ? 0 : Convert.ToInt32(vi.c_windows_struct),
                     slow_brand = string.IsNullOrWhiteSpace(vi.c_slow_brand) ? 0 : Convert.ToInt32(vi.c_slow_brand),
                     lubrication = string.IsNullOrWhiteSpace(vi.c_chassis_lubrication) ? 0 : Convert.ToInt32(vi.c_chassis_lubrication),

                     cool_sys = string.IsNullOrWhiteSpace(vi.c_cool_system) ? 0 : Convert.ToInt32(vi.c_cool_system),
                     car_ter = string.IsNullOrWhiteSpace(vi.c_car_terminal) ? 0 : Convert.ToInt32(vi.c_car_terminal),
                     video_mon = string.IsNullOrWhiteSpace(vi.c_video_monitor) ? 0 : Convert.ToInt32(vi.c_video_monitor),
                     passenger_ana = string.IsNullOrWhiteSpace(vi.c_passenger_analyzer) ? 0 : Convert.ToInt32(vi.c_passenger_analyzer),
                     safty_warn = string.IsNullOrWhiteSpace(vi.c_safty_warn) ? 0 : Convert.ToInt32(vi.c_safty_warn),

                     dashcam = string.IsNullOrWhiteSpace(vi.c_dashcam) ? 0 : Convert.ToInt32(vi.c_dashcam),
                     round_type = string.IsNullOrWhiteSpace(vi.c_round_type) ? 0 : Convert.ToInt32(vi.c_round_type),
                     license_no = vi.c_business_license_no,
                     scrap = vi.scrap,

                     name = mvk.c_name,
                     kind = string.IsNullOrEmpty(mvk.c_kind) ? 0 : Convert.ToInt32(mvk.c_kind),
                     factory = mvk.c_factory,
                     seats_num = mvk.i_seats_count == null ? 0 : (int)mvk.i_seats_count,
                     permit_num = mvk.i_permit_seat == null ? 0 : (int)mvk.i_permit_seat,
                     displacement = Convert.ToInt32(mvk.i_displacement),
                     standard = string.IsNullOrEmpty(mvk.c_effluent_standard) ? 0 : Convert.ToInt32(mvk.c_effluent_standard),
                     fuel = string.IsNullOrEmpty(mvk.c_fuel) ? 0 : Convert.ToInt32(mvk.c_fuel),
                     color = mvk.c_skin_color,
                     length = Convert.ToInt32(mvk.i_vehicle_length),
                     width = Convert.ToInt32(mvk.i_vehicle_width),
                     height = Convert.ToInt32(mvk.i_vehicle_height),
                     wheel_space = (int)mvk.i_wheel_space,
                     shaft_space = (int)mvk.i_shaft_space,

                     permit_quality = (int)mvk.i_permit_quality,
                     total_quality = (int)mvk.i_total_quality,
                     index = mvk.c_machine_index,
                     image_path = mvk.c_image_path
                 }).ToList();

            list.ForEach(m =>
            {
                m.trans_name = m.trans == 0 ? "" : dic.Where(r => r.i_id == m.trans).FirstOrDefault()?.c_name;
                m.floor_str_name = m.floor_str == 0 ? "" : dic.Where(r => r.i_id == m.floor_str).FirstOrDefault()?.c_name;
                m.windows_str_name = m.windows_str == 0 ? "" : dic.Where(r => r.i_id == m.floor_str).FirstOrDefault()?.c_name;
                m.air_brand_name = m.air_brand == 0 ? "" : dic.Where(r => r.i_id == m.air_brand).FirstOrDefault()?.c_name;
                m.slow_brand_name = m.slow_brand == 0 ? "" : dic.Where(r => r.i_id == m.slow_brand).FirstOrDefault()?.c_name;
                m.lubrication_name = m.lubrication == 0 ? "" : dic.Where(r => r.i_id == m.lubrication).FirstOrDefault()?.c_name;
                m.cool_sys_name = m.cool_sys == 0 ? "" : dic.Where(r => r.i_id == m.cool_sys).FirstOrDefault()?.c_name;
                m.car_ter_name = m.car_ter == 0 ? "" : dic.Where(r => r.i_id == m.car_ter).FirstOrDefault()?.c_name;
                m.video_mon_name = m.video_mon == 0 ? "" : dic.Where(r => r.i_id == m.video_mon).FirstOrDefault()?.c_name;
                m.passenger_ana_name = m.passenger_ana == 0 ? "" : dic.Where(r => r.i_id == m.passenger_ana).FirstOrDefault()?.c_name;
                m.safty_warn_name = m.safty_warn == 0 ? "" : dic.Where(r => r.i_id == m.safty_warn).FirstOrDefault()?.c_name;
                m.dashcam_name = m.dashcam == 0 ? "" : dic.Where(r => r.i_id == m.dashcam).FirstOrDefault()?.c_name;
                m.round_type_name = m.round_type == 0 ? "" : dic.Where(r => r.i_id == m.round_type).FirstOrDefault()?.c_name;
                m.kind_name = m.kind == 0 ? "" : dic.Where(r => r.i_id == m.kind).FirstOrDefault()?.c_name;
                m.fuel_name = m.fuel == 0 ? "" : dic.Where(r => r.i_id == m.fuel).FirstOrDefault()?.c_name;
                m.standard_name = m.standard == 0 ? "" : dic.Where(r => r.i_id == m.standard).FirstOrDefault()?.c_name;
                m.group_name = m.group == 0 ? "" : list1.Where(r => r.i_id == Convert.ToDecimal(m.group)).FirstOrDefault()?.c_name;
            });

            return list;
        }

        public static List<LifeCycle> GetVehicleLife(string serverID, decimal? id)
        {
            var vehicle = SqlSugarHelper.DBClient(serverID).Queryable<VehicleInfoNew>().Where(r => r.id == id).First();
            if (vehicle == null)
            {
                throw new Exception("该车不存在，请检查后重试");
            }
            var list = new List<LifeCycle>();
            list.Add(new LifeCycle { date = vehicle.reg_date.Value, type = 1, content = "购入" });
            if (vehicle.lea_date != null)
            {
                list.Add(new LifeCycle { date = vehicle.lea_date.Value, type = 2, content = "出厂" });
            }
          
            var changes = SqlSugarHelper.DBClient(serverID).Queryable<ErpVehicleDepartmentRd>()
                .Where(r => r.i_vehicle_id == id)
                .Mapper(r => r.old_department_info, r => r.i_old_department)
                .Mapper(r => r.new_department_info, r => r.i_new_department)
                .ToList();
            if (changes != null && changes.Count > 0)
            {
                changes.ForEach(r =>
                {
                    list.Add(new LifeCycle { date = r.d_created.Value, type = 3, content = $"{r.old_department_info?.c_name}调入{r.new_department_info?.c_name}" });
                });
            }

            var displan = SqlSugarHelper.DBClient(serverID).Queryable<MaintDiscardPlan>()
                .Where(r => r.vehicle_id == id && r.check_state == 1).First();
            if (displan != null)
            {
                list.Add(new LifeCycle { date = displan.plan_date.Value, type = 4, content = "报废" });
            }

            var check_plans = SqlSugarHelper.DBClient(serverID).Queryable<MaintCheckPlan>()
                .Where(r => r.i_vehicle_id == id && r.i_check_state == 1).ToList();
            if (check_plans != null && check_plans.Count > 0)
            {
                check_plans.ForEach(r =>
                {
                    list.Add(new LifeCycle { date = r.d_check_time_true.Value, type = 5, content = $"年检" });
                });
            }

            var repair_orders = SqlSugarHelper.DBClient(serverID).Queryable<MaintRepairOrder>()
                .Where(r => r.vehicle_id == id && r.state > 2)
                .Mapper(x => x.type_child_info, x => x.type_child).ToList();
            if (repair_orders != null && repair_orders.Count > 0)
            {
                repair_orders.ForEach(r =>
                {
                    list.Add(new LifeCycle { date = r.repair_time, type = 6, content = r.type_child_info?.c_name });
                });
            }

            var insurance_fee = SqlSugarHelper.DBClient(serverID)
                              .Queryable<ErpInsuranceMain>()
                              .Where(r => r.vehicle_id == id)
                              .Mapper(x =>
                              {
                                  x.type_name = string.Join(",", SqlSugarHelper.DBClient(serverID)
                                                          .Queryable<SysCommonDictDetail>()
                                                          .Where(i => x.types.ToList().Contains(i.i_id.Value))
                                                          .Select(x => x.c_name)
                                                          .ToList());
                              }).ToList();
            if (insurance_fee != null && insurance_fee.Count > 0)
            {
                insurance_fee.ForEach(r =>
                {
                    list.Add(new LifeCycle { date = r.insurance_start, type = 7, content = $"投保种类：{r.type_name}，投保金额：{r.insure_fee}" });
                });
            }

            return list.OrderBy(r=>r.date).ToList();
        }
    }
}
