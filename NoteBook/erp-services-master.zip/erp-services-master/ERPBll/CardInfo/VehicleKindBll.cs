﻿using ERPBll.VehicleInfo;
using ERPDal;
using ERPDal.VehiclInfo;
using ERPModel.CardInfo;
using ERPModel.DataBase;
using ERPModel.Vehicleinfomanage;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace ERPBll.Vehicleinfomanage
{
    public class VehicleKindBll
    {
        /// <summary>
        /// 新增车型信息
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="info"></param>
        /// <returns></returns>
        public static bool AddCKind(string serverID, VehicleKind info)
        {
            info.id = ERPBll.Tools.GetID(serverID).ToString();
            return VehicleKindDal.addCKind(serverID, info);
        }
        public static int AddCKind(string serverID, MaintVehicleKind1 info)
        {
            //info.id = ERPBll.Tools.GetID(serverID);
            return SqlSugarHelper.DBClient(serverID).Insertable(info).ExecuteCommand();
        }
        /// <summary>
        /// 导入许多车型信息
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="ticket_id"></param>
        /// <returns></returns>
        public static string AddManyCKind(string serverID, List<VehicleKind> infos)
        {
            foreach (var item in infos)
            {
                if (VehicleKindDal.getCKindByName(serverID, item.name).Rows.Count>0)
                {
                    continue;
                }
                item.id = ERPBll.Tools.GetID(serverID).ToString();
                var r = VehicleKindDal.addCKind(serverID, item);
                if (!r)
                {
                    return item.name;
                }
            }
            return "success";
        }
        public static string AddManyCKind(string serverID, List<MaintVehicleKind> infos)
        {
            foreach (var item in infos)
            {
                if (SqlSugarHelper.DBClient(serverID).Queryable<MaintVehicleKind>().Where(r => r.c_name == item.c_name).Count() > 0)
                {
                    continue;
                }
                else
                {
                    item.i_id = ERPBll.Tools.GetID(serverID);
                    SqlSugarHelper.DBClient(serverID).Insertable(item).ExecuteCommand();
                }
            }
            return "success";
        }

        /// <summary>
        /// 导入并更新许多车型信息
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="ticket_id"></param>
        /// <returns></returns>
        public static string AddOrUpdateManyCKind(string serverID, List<VehicleKind> infos)
        {
            foreach (var item in infos)
            {
                var dt = VehicleKindDal.getCKindByName(serverID, item.name);
                if (dt.Rows.Count > 0)
                {
                    item.id = dt.Rows[0]["i_id"].ToString();
                    var r = VehicleKindDal.updateCKind(serverID, item);
                    if (!r)
                    {
                        return item.name;
                    }
                }
                else
                {
                    item.id = ERPBll.Tools.GetID(serverID).ToString();
                    var r = VehicleKindDal.addCKind(serverID, item);
                    if (!r)
                    {
                        return item.name;
                    }
                }
            }
            return "success";
        }
        public static string AddOrUpdateManyCKind(string serverID, List<MaintVehicleKind> infos)
        {
            foreach (var item in infos)
            {
                if (SqlSugarHelper.DBClient(serverID).Queryable<MaintVehicleKind>().Where(r => r.c_name == item.c_name).Count() > 0)
                {
                    SqlSugarHelper.DBClient(serverID).Updateable(item).WhereColumns(r => r.c_name).IgnoreColumns(true, false, true).ExecuteCommand();
                }
                else
                {
                    item.i_id = ERPBll.Tools.GetID(serverID);
                    SqlSugarHelper.DBClient(serverID).Insertable(item).ExecuteCommand();
                }
            }
            return "success";
        }


        /// <summary>
        /// 删除车型信息
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="ticket_id"></param>
        /// <returns></returns>
        public static bool DeleteCKind(string serverID, string id)
        {
            return VehicleKindDal.deleteCKind(serverID, id);
        }
        public static int DeleteCKind(string serverID, decimal id)
        {
            return SqlSugarHelper.DBClient(serverID).Deleteable<MaintVehicleKind>().In(id).ExecuteCommand();
        }
        public static (int, string) DeleteCKind(string serverID, List<decimal> ids)
        {
            var list = SqlSugarHelper.DBClient(serverID).Queryable<MaintVehicleKind>().In(ids).ToList();
            var str = string.Join(",", list.Select(x => x.c_name).ToList());
            return (SqlSugarHelper.DBClient(serverID).Deleteable<MaintVehicleKind>().In(ids).ExecuteCommand(), str);
        }

        /// <summary>
        /// 更新车型信息
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="info">编辑信息</param>
        /// <returns></returns>
        public static bool UpdateCKind(string serverID, VehicleKind info)
        {
            return VehicleKindDal.updateCKind(serverID, info);
        }
        public static (int, string) UpdateCKind(string serverID, MaintVehicleKind1 info)
        {
            var old_info = SqlSugarHelper.DBClient(serverID).Queryable<MaintVehicleKind1>().Where(r => r.id == info.id).First();

            var res = SqlSugarHelper.DBClient(serverID).Updateable(info).ExecuteCommand();
                        //.Where(r => r.name == info.name).ExecuteCommand();

            var str = "";
            if (res > 0)
            {
                str = Tools.CompareClass(old_info, info);
            }

            return (res, str);
        }

        /// <summary>
        /// 获取全部车型信息
        /// </summary>
        /// <param name="serverID"></param>
        /// <returns></returns>
        public static List<VehicleKind> GetAllCKind(string serverID)
        {
            return default;
            //var dt = VehicleKindDal.getAllCKind(serverID);
            //List<VehicleKind> list = new List<VehicleKind>();
            //if (dt.Rows.Count>0)
            //{
            //    foreach (DataRow item in dt.Rows)
            //    {
            //        VehicleKind temp = new VehicleKind();
            //        temp.id = item["i_id"] is DBNull ? "" : Convert.ToString(item["i_id"]);
            //        temp.name = item["c_name"] is DBNull ? "" : Convert.ToString(item["c_name"]);
            //        temp.kind = item["c_kind"] is DBNull ? "" : Convert.ToString(item["c_kind"]);
            //        temp.factory = item["c_factory"] is DBNull ? "" : Convert.ToString(item["c_factory"]);
            //        temp.seats_num = item["i_seats_count"] is DBNull ? 0 : Convert.ToInt32(item["i_seats_count"]);
            //        temp.permit_num = item["i_permit_seat"] is DBNull ? 0 : Convert.ToInt32(item["i_permit_seat"]);
            //        temp.displacement = item["i_displacement"] is DBNull ? 0 : Convert.ToInt32(item["i_displacement"]);
            //        temp.standard = item["c_effluent_standard"] is DBNull ? "" : Convert.ToString(item["c_effluent_standard"]);
            //        temp.fuel = item["c_fuel"] is DBNull ? "" : Convert.ToString(item["c_fuel"]);
            //        temp.color = item["c_skin_color"] is DBNull ? "" : Convert.ToString(item["c_skin_color"]);
            //        temp.length = item["i_vehicle_length"] is DBNull ? 0 : Convert.ToInt32(item["i_vehicle_length"]);
            //        temp.width = item["i_vehicle_width"] is DBNull ? 0 : Convert.ToInt32(item["i_vehicle_width"]);
            //        temp.height = item["i_vehicle_height"] is DBNull ? 0 : Convert.ToInt32(item["i_vehicle_height"]);
            //        temp.wheel_space = item["i_wheel_space"] is DBNull ? 0 : Convert.ToInt32(item["i_wheel_space"]);
            //        temp.shaft_space = item["i_shaft_space"] is DBNull ? 0 : Convert.ToInt32(item["i_shaft_space"]);

            //        temp.permit_quality = item["i_permit_quality"] is DBNull ? 0 : Convert.ToInt32(item["i_permit_quality"]);
            //        temp.total_quality = item["i_total_quality"] is DBNull ? 0 : Convert.ToInt32(item["i_total_quality"]);
            //        temp.index = item["c_machine_index"] is DBNull ? "" : Convert.ToString(item["c_machine_index"]);
            //        temp.image_path = item["c_image_path"] is DBNull ? "" : Convert.ToString(item["c_image_path"]);
            //        list.Add(temp);
            //    }
            //}
            //return list;
        }
        public static List<VehicleKind> GetAllCKind1(string serverID)
        {
            var dic = SqlSugarHelper.DBClient(serverID).Queryable<SysCommonDictDetail>().ToList();
            List<VehicleKind> list = SqlSugarHelper.DBClient(serverID)
                .Queryable<MaintVehicleKind>().OrderBy(r => r.c_name, OrderByType.Desc)
                .Select(r => new VehicleKind
                {
                    id = r.i_id.ToString(),
                    name = r.c_name,
                    kind = string.IsNullOrEmpty(r.c_kind) ? 0 : Convert.ToInt32(r.c_kind),
                    factory = r.c_factory,
                    seats_num = r.i_seats_count,
                    permit_num = r.i_permit_seat,
                    displacement = r.i_displacement,
                    standard = string.IsNullOrEmpty(r.c_effluent_standard) ? 0 : Convert.ToInt32(r.c_effluent_standard),
                    fuel = string.IsNullOrEmpty(r.c_fuel) ? 0 : Convert.ToInt32(r.c_fuel),
                    color = r.c_skin_color,
                    length = r.i_vehicle_length,
                    width = r.i_vehicle_width,
                    height = r.i_vehicle_height,
                    wheel_space = r.i_wheel_space,
                    shaft_space = r.i_shaft_space,
                    permit_quality = r.i_permit_quality,
                    total_quality = r.i_total_quality,
                    index = r.c_machine_index,
                    image_path = r.c_image_path
                }).ToList();

            list.ForEach(m =>
            {
                m.kind_name = m.kind == 0 ? "" : dic.Where(r => r.i_id == m.kind).FirstOrDefault()?.c_name;
                m.fuel_name = m.fuel == 0 ? "" : dic.Where(r => r.i_id == m.fuel).FirstOrDefault()?.c_name;
                m.standard_name = m.standard == 0 ? "" : dic.Where(r => r.i_id == m.standard).FirstOrDefault()?.c_name;
            });
            return list;
        }

        /// <summary>
        /// 根据指定条件获取车型数据
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="name"></param>
        /// <param name="factory"></param>
        /// <param name="kind"></param>
        /// <param name="fuel"></param>
        /// <param name="seats_num"></param>
        /// <param name="permit_num"></param>
        /// <param name="displacement"></param>
        /// <param name="standard"></param>
        /// <returns></returns>
        public static List<VehicleKind> GetCKindByCondition(string serverID, string name, string factory, string kind, string fuel, 
            string seats_num, string permit_num, string displacement, string standard)
        {
            return default;
            //var dt = VehicleKindDal.getCKindByCondition(serverID, name, factory, kind, fuel, seats_num, permit_num, displacement, standard);
            //List<VehicleKind> list = new List<VehicleKind>();
            //if (dt.Rows.Count > 0)
            //{
            //    foreach (DataRow item in dt.Rows)
            //    {
            //        VehicleKind temp = new VehicleKind();
            //        temp.id = item["i_id"] is DBNull ? "" : Convert.ToString(item["i_id"]);
            //        temp.name = item["c_name"] is DBNull ? "" : Convert.ToString(item["c_name"]);
            //        temp.kind = item["c_kind"] is DBNull ? "" : Convert.ToString(item["c_kind"]);
            //        temp.factory = item["c_factory"] is DBNull ? "" : Convert.ToString(item["c_factory"]);
            //        temp.seats_num = item["i_seats_count"] is DBNull ? 0 : Convert.ToInt32(item["i_seats_count"]);
            //        temp.permit_num = item["i_permit_seat"] is DBNull ? 0 : Convert.ToInt32(item["i_permit_seat"]);
            //        temp.displacement = item["i_displacement"] is DBNull ? 0 : Convert.ToInt32(item["i_displacement"]);
            //        temp.standard = item["c_effluent_standard"] is DBNull ? "" : Convert.ToString(item["c_effluent_standard"]);
            //        temp.fuel = item["c_fuel"] is DBNull ? "" : Convert.ToString(item["c_fuel"]);
            //        temp.color = item["c_skin_color"] is DBNull ? "" : Convert.ToString(item["c_skin_color"]);
            //        temp.length = item["i_vehicle_length"] is DBNull ? 0 : Convert.ToInt32(item["i_vehicle_length"]);
            //        temp.width = item["i_vehicle_width"] is DBNull ? 0 : Convert.ToInt32(item["i_vehicle_width"]);
            //        temp.height = item["i_vehicle_height"] is DBNull ? 0 : Convert.ToInt32(item["i_vehicle_height"]);
            //        temp.wheel_space = item["i_wheel_space"] is DBNull ? 0 : Convert.ToInt32(item["i_wheel_space"]);
            //        temp.shaft_space = item["i_shaft_space"] is DBNull ? 0 : Convert.ToInt32(item["i_shaft_space"]);

            //        temp.permit_quality = item["i_permit_quality"] is DBNull ? 0 : Convert.ToInt32(item["i_permit_quality"]);
            //        temp.total_quality = item["i_total_quality"] is DBNull ? 0 : Convert.ToInt32(item["i_total_quality"]);
            //        temp.index = item["c_machine_index"] is DBNull ? "" : Convert.ToString(item["c_machine_index"]);
            //        temp.image_path = item["c_image_path"] is DBNull ? "" : Convert.ToString(item["c_image_path"]);
            //        list.Add(temp);
            //    }
            //}
            //return list;
        }
        public static Tuple<int, List<VehicleKind>> GetCKindByCondition1(string serverID, string name, string factory, string kind, string fuel, string seats_num,
            string permit_num, string displacement, string standard, int index, int size)
        {
            return default;
            int total = 0;
            var dic = SqlSugarHelper.DBClient(serverID).Queryable<SysCommonDictDetail>().ToList();
            var list = new List<VehicleKind>();
            if (index > 0)
            {
                list = SqlSugarHelper.DBClient(serverID).Queryable<MaintVehicleKind>()
                .WhereIF(!string.IsNullOrEmpty(name), r => r.c_name == name)
                .WhereIF(!string.IsNullOrEmpty(factory), r => r.c_factory == factory)
                .WhereIF(!string.IsNullOrEmpty(kind), r => r.c_kind == kind)
                .WhereIF(!string.IsNullOrEmpty(fuel), r => r.c_fuel == fuel)
                .WhereIF(!string.IsNullOrEmpty(seats_num), r => r.i_seats_count == Convert.ToInt32(seats_num))
                .WhereIF(!string.IsNullOrEmpty(permit_num), r => r.i_permit_seat == Convert.ToInt32(permit_num))
                .WhereIF(!string.IsNullOrEmpty(displacement), r => r.i_displacement == Convert.ToInt32(displacement))
                .WhereIF(!string.IsNullOrEmpty(standard), r => r.c_effluent_standard == standard)
                .OrderBy(r => r.c_name, OrderByType.Desc)
                .Select(r => new VehicleKind
                {
                    id = r.i_id.ToString(),
                    name = r.c_name,
                    kind = string.IsNullOrEmpty(r.c_kind) ? 0 : Convert.ToInt32(r.c_kind),
                    factory = r.c_factory,
                    seats_num = r.i_seats_count == null ? 0 : (int)r.i_seats_count,
                    permit_num = r.i_permit_seat == null ? 0 : (int)r.i_permit_seat,
                    displacement = r.i_displacement == null ? 0 : Convert.ToInt32(r.i_displacement),
                    standard = string.IsNullOrEmpty(r.c_effluent_standard) ? 0 : Convert.ToInt32(r.c_effluent_standard),
                    fuel = string.IsNullOrEmpty(r.c_fuel) ? 0 : Convert.ToInt32(r.c_fuel),
                    color = r.c_skin_color,
                    length = r.i_vehicle_length == null ? 0 : Convert.ToInt32(r.i_vehicle_length),
                    width = r.i_vehicle_width == null ? 0 : Convert.ToInt32(r.i_vehicle_width),
                    height = r.i_vehicle_height == null ? 0 : Convert.ToInt32(r.i_vehicle_height),
                    wheel_space = r.i_wheel_space == null ? 0 : (int)r.i_wheel_space,
                    shaft_space = r.i_shaft_space == null ? 0 : (int)r.i_shaft_space,

                    permit_quality = r.i_permit_quality == null ? 0 : (int)r.i_permit_quality,
                    total_quality = r.i_total_quality == null ? 0 : (int)r.i_total_quality,
                    index = r.c_machine_index,
                    image_path = r.c_image_path
                }).ToPageList(index, size, ref total);
            }
            else
            {
                list = SqlSugarHelper.DBClient(serverID).Queryable<MaintVehicleKind>()
                .WhereIF(!string.IsNullOrEmpty(name), r => r.c_name == name)
                .WhereIF(!string.IsNullOrEmpty(factory), r => r.c_factory == factory)
                .WhereIF(!string.IsNullOrEmpty(kind), r => r.c_kind == kind)
                .WhereIF(!string.IsNullOrEmpty(fuel), r => r.c_fuel == fuel)
                .WhereIF(!string.IsNullOrEmpty(seats_num), r => r.i_seats_count == Convert.ToInt32(seats_num))
                .WhereIF(!string.IsNullOrEmpty(permit_num), r => r.i_permit_seat == Convert.ToInt32(permit_num))
                .WhereIF(!string.IsNullOrEmpty(displacement), r => r.i_displacement == Convert.ToInt32(displacement))
                .WhereIF(!string.IsNullOrEmpty(standard), r => r.c_effluent_standard == standard)
                .OrderBy(r => r.c_name, OrderByType.Desc)
                .Select(r => new VehicleKind
                {
                    id = r.i_id.ToString(),
                    name = r.c_name,
                    kind = string.IsNullOrEmpty(r.c_kind) ? 0 : Convert.ToInt32(r.c_kind),
                    factory = r.c_factory,
                    seats_num = r.i_seats_count == null ? 0 : (int)r.i_seats_count,
                    permit_num = r.i_permit_seat == null ? 0 : (int)r.i_permit_seat,
                    displacement = r.i_displacement == null ? 0 : Convert.ToInt32(r.i_displacement),
                    standard = string.IsNullOrEmpty(r.c_effluent_standard) ? 0 : Convert.ToInt32(r.c_effluent_standard),
                    fuel = string.IsNullOrEmpty(r.c_fuel) ? 0 : Convert.ToInt32(r.c_fuel),
                    color = r.c_skin_color,
                    length = r.i_vehicle_length == null ? 0 : Convert.ToInt32(r.i_vehicle_length),
                    width = r.i_vehicle_width == null ? 0 : Convert.ToInt32(r.i_vehicle_width),
                    height = r.i_vehicle_height == null ? 0 : Convert.ToInt32(r.i_vehicle_height),
                    wheel_space = r.i_wheel_space == null ? 0 : (int)r.i_wheel_space,
                    shaft_space = r.i_shaft_space == null ? 0 : (int)r.i_shaft_space,

                    permit_quality = r.i_permit_quality == null ? 0 : (int)r.i_permit_quality,
                    total_quality = r.i_total_quality == null ? 0 : (int)r.i_total_quality,
                    index = r.c_machine_index,
                    image_path = r.c_image_path
                }).ToList();
                total = list.Count;
            }

            var list1 = VehicleInfoBll.GetAllCInfo1(serverID);
            list.ForEach(m =>
            {
                m.car_num = list1.Where(r => r.cid == Convert.ToInt32(m.id)).Count();
                m.kind_name = m.kind == 0 ? "" : dic.Where(r => r.i_id == m.kind).FirstOrDefault()?.c_name;
                m.fuel_name = m.fuel == 0 ? "" : dic.Where(r => r.i_id == m.fuel).FirstOrDefault()?.c_name;
                m.standard_name = m.standard == 0 ? "" : dic.Where(r => r.i_id == m.standard).FirstOrDefault()?.c_name;
            });
            return new Tuple<int, List<VehicleKind>>(total, list);
        }

        public static Tuple<int, List<VehicleKind>> GetCKindByCondition1(VehicleKindQuery request)
        {
            int total = 0;
            var dic = SqlSugarHelper.DBClient(request.server_id).Queryable<SysCommonDictDetail>().ToList();

            var list = SqlSugarHelper.DBClient(request.server_id).Queryable<MaintVehicleKind>()
                 .Where(request.ToExp())
                 .OrderBy(r => r.c_name, OrderByType.Desc)
             .Select(r => new VehicleKind
             {
                 id = r.i_id.ToString(),
                 name = r.c_name,
                 kind = string.IsNullOrEmpty(r.c_kind) ? 0 : Convert.ToInt32(r.c_kind),
                 factory = r.c_factory,
                 seats_num = r.i_seats_count,
                 permit_num = r.i_permit_seat,
                 displacement = r.i_displacement,
                 standard = string.IsNullOrEmpty(r.c_effluent_standard) ? 0 : Convert.ToInt32(r.c_effluent_standard),
                 fuel = string.IsNullOrEmpty(r.c_fuel) ? 0 : Convert.ToInt32(r.c_fuel),
                 color = r.c_skin_color,
                 length = r.i_vehicle_length,
                 width = r.i_vehicle_width,
                 height = r.i_vehicle_height,
                 wheel_space = r.i_wheel_space,
                 shaft_space = r.i_shaft_space,

                 permit_quality = r.i_permit_quality,
                 total_quality = r.i_total_quality,
                 index = r.c_machine_index,
                 image_path = r.c_image_path,
                 price = r.price
             }).ToPageList(request.page_index, request.page_size, ref total);

            var list1 = VehicleInfoBll.GetAllCInfo1(request.server_id);
            list.ForEach(m =>
            {
                m.car_num = list1.Where(r => r.cid == Convert.ToInt32(m.id) && r.scrap != 1).Count();
                m.kind_name = m.kind == 0 ? "" : dic.Where(r => r.i_id == m.kind).FirstOrDefault()?.c_name;
                m.fuel_name = m.fuel == 0 ? "" : dic.Where(r => r.i_id == m.fuel).FirstOrDefault()?.c_name;
                m.standard_name = m.standard == 0 ? "" : dic.Where(r => r.i_id == m.standard).FirstOrDefault()?.c_name;
            });
            return new Tuple<int, List<VehicleKind>>(total, list);
        }
        /// <summary>
        /// 根据车辆型号获取部分车型信息
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="name">车型名称</param>
        /// <returns></returns>
        public static List<VehicleKind> GetCKindByName(string serverID, string name)
        {
            return default;
            //var dt = VehicleKindDal.getCKindByName(serverID,name);
            //List<VehicleKind> list = new List<VehicleKind>();
            //if (dt.Rows.Count > 0)
            //{
            //    foreach (DataRow item in dt.Rows)
            //    {
            //        VehicleKind temp = new VehicleKind();
            //        temp.id = item["i_id"] is DBNull ? "" : Convert.ToString(item["i_id"]);
            //        temp.name = item["c_name"] is DBNull ? "" : Convert.ToString(item["c_name"]);
            //        temp.kind = item["c_kind"] is DBNull ? "" : Convert.ToString(item["c_kind"]);
            //        temp.factory = item["c_factory"] is DBNull ? "" : Convert.ToString(item["c_factory"]);
            //        temp.seats_num = item["i_seats_count"] is DBNull ? 0 : Convert.ToInt32(item["i_seats_count"]);
            //        temp.permit_num = item["i_permit_seat"] is DBNull ? 0 : Convert.ToInt32(item["i_permit_seat"]);
            //        temp.displacement = item["i_displacement"] is DBNull ? 0 : Convert.ToInt32(item["i_displacement"]);
            //        temp.standard = item["c_effluent_standard"] is DBNull ? "" : Convert.ToString(item["c_effluent_standard"]);
            //        temp.fuel = item["c_fuel"] is DBNull ? "" : Convert.ToString(item["c_fuel"]);
            //        temp.color = item["c_skin_color"] is DBNull ? "" : Convert.ToString(item["c_skin_color"]);
            //        temp.length = item["i_vehicle_length"] is DBNull ? 0 : Convert.ToInt32(item["i_vehicle_length"]);
            //        temp.width = item["i_vehicle_width"] is DBNull ? 0 : Convert.ToInt32(item["i_vehicle_width"]);
            //        temp.height = item["i_vehicle_height"] is DBNull ? 0 : Convert.ToInt32(item["i_vehicle_height"]);
            //        temp.wheel_space = item["i_wheel_space"] is DBNull ? 0 : Convert.ToInt32(item["i_wheel_space"]);
            //        temp.shaft_space = item["i_shaft_space"] is DBNull ? 0 : Convert.ToInt32(item["i_shaft_space"]);

            //        temp.permit_quality = item["i_permit_quality"] is DBNull ? 0 : Convert.ToInt32(item["i_permit_quality"]);
            //        temp.total_quality = item["i_total_quality"] is DBNull ? 0 : Convert.ToInt32(item["i_total_quality"]);
            //        temp.index = item["c_machine_index"] is DBNull ? "" : Convert.ToString(item["c_machine_index"]);
            //        temp.image_path = item["c_image_path"] is DBNull ? "" : Convert.ToString(item["c_image_path"]);
            //        list.Add(temp);
            //    }
            //}
            //return list;
        }
        public static List<MaintVehicleKind> GetCKindByName1(string serverID, string name)
        {
            List<MaintVehicleKind> list = SqlSugarHelper.DBClient(serverID).Queryable<MaintVehicleKind>()
              .WhereIF(!string.IsNullOrEmpty(name), r=>r.c_name == name)
              .OrderBy(r => r.i_id, OrderByType.Desc).ToList();

            return list;
        }

        /// <summary>
        /// 根据生产厂家获取部分车型信息
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="factory"></param>
        /// <returns></returns>
        public static List<VehicleKind> GetCKindByFac(string serverID, string factory)
        {
            return default;
            //var dt = VehicleKindDal.getCKindByFac(serverID,factory);
            //List<VehicleKind> list = new List<VehicleKind>();
            //if (dt.Rows.Count > 0)
            //{
            //    foreach (DataRow item in dt.Rows)
            //    {
            //        VehicleKind temp = new VehicleKind();
            //        temp.id = item["i_id"] is DBNull ? "" : Convert.ToString(item["i_id"]);
            //        temp.name = item["c_name"] is DBNull ? "" : Convert.ToString(item["c_name"]);
            //        temp.kind = item["c_kind"] is DBNull ? "" : Convert.ToString(item["c_kind"]);
            //        temp.factory = item["c_factory"] is DBNull ? "" : Convert.ToString(item["c_factory"]);
            //        temp.seats_num = item["i_seats_count"] is DBNull ? 0 : Convert.ToInt32(item["i_seats_count"]);
            //        temp.permit_num = item["i_permit_seat"] is DBNull ? 0 : Convert.ToInt32(item["i_permit_seat"]);
            //        temp.displacement = item["i_displacement"] is DBNull ? 0 : Convert.ToInt32(item["i_displacement"]);
            //        temp.standard = item["c_effluent_standard"] is DBNull ? "" : Convert.ToString(item["c_effluent_standard"]);
            //        temp.fuel = item["c_fuel"] is DBNull ? "" : Convert.ToString(item["c_fuel"]);
            //        temp.color = item["c_skin_color"] is DBNull ? "" : Convert.ToString(item["c_skin_color"]);
            //        temp.length = item["i_vehicle_length"] is DBNull ? 0 : Convert.ToInt32(item["i_vehicle_length"]);
            //        temp.width = item["i_vehicle_width"] is DBNull ? 0 : Convert.ToInt32(item["i_vehicle_width"]);
            //        temp.height = item["i_vehicle_height"] is DBNull ? 0 : Convert.ToInt32(item["i_vehicle_height"]);
            //        temp.wheel_space = item["i_wheel_space"] is DBNull ? 0 : Convert.ToInt32(item["i_wheel_space"]);
            //        temp.shaft_space = item["i_shaft_space"] is DBNull ? 0 : Convert.ToInt32(item["i_shaft_space"]);

            //        temp.permit_quality = item["i_permit_quality"] is DBNull ? 0 : Convert.ToInt32(item["i_permit_quality"]);
            //        temp.total_quality = item["i_total_quality"] is DBNull ? 0 : Convert.ToInt32(item["i_total_quality"]);
            //        temp.index = item["c_machine_index"] is DBNull ? "" : Convert.ToString(item["c_machine_index"]);
            //        temp.image_path = item["c_image_path"] is DBNull ? "" : Convert.ToString(item["c_image_path"]);
            //        list.Add(temp);
            //    }
            //}
            //return list;
        }
       
        /// <summary>
        /// 获取车型信息表不同的车型名称数据集
        /// </summary>
        /// <param name="serverID"></param>
        /// <returns></returns>
        public static List<string> GetCKName(string serverID)
        {
            var dt = VehicleKindDal.getCKName(serverID);
            List<string> list = new List<string>();
            List<VehicleKind> list1 = new List<VehicleKind>();
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow item in dt.Rows)
                {
                    VehicleKind temp = new VehicleKind();
                    temp.id = item["i_id"] is DBNull ? "" : Convert.ToString(item["i_id"]);
                    temp.name = item["c_name"] is DBNull ? "" : Convert.ToString(item["c_name"]);
                    list1.Add(temp);
                }
                list = list1.Select(r => r.name).Distinct().ToList();
            }
            return list;
        }
        /// <summary>
        /// 获取车型信息表不同的生产厂家数据集
        /// </summary>
        /// <param name="serverID"></param>
        /// <returns></returns>
        public static List<string> GetCKFactory(string serverID)
        {
            var dt = VehicleKindDal.getCKFactory(serverID);
            List<string> list = new List<string>();
            List<VehicleKind> list1 = new List<VehicleKind>();
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow item in dt.Rows)
                {
                    VehicleKind temp = new VehicleKind();
                    temp.id = item["i_id"] is DBNull ? "" : Convert.ToString(item["i_id"]);
                    temp.factory = item["c_factory"] is DBNull ? "" : Convert.ToString(item["c_factory"]);
                    list1.Add(temp);
                }
                list = list1.Select(r => r.factory).Distinct().ToList();
            }
            return list;
        }
        /// <summary>
        /// 获取车型信息表不同的车辆类型数据集
        /// </summary>
        /// <param name="serverID"></param>
        /// <returns></returns>
        public static List<string> GetCKKind(string serverID)
        {
            return default;
            //var dt = VehicleKindDal.getCKKind(serverID);
            //List<string> list = new List<string>();
            //List<VehicleKind> list1 = new List<VehicleKind>();
            //if (dt.Rows.Count > 0)
            //{
            //    foreach (DataRow item in dt.Rows)
            //    {
            //        VehicleKind temp = new VehicleKind();
            //        temp.id = item["i_id"] is DBNull ? "" : Convert.ToString(item["i_id"]);
            //        temp.kind = item["c_kind"] is DBNull ? "" : Convert.ToString(item["c_kind"]);
            //        list1.Add(temp);
            //    }
            //    list = list1.Select(r => r.kind).Distinct().ToList();
            //}
            //return list;
        }
    }
}
