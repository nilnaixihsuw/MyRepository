﻿using ERPDal;
using ERPModel.Vehicleinfomanage;
using System;
using System.Collections.Generic;
using System.Text;

namespace ERPBll.CardInfo
{
    public class VehicleRulesBll
    {
        public static int AddCheckRules(string serverID, MaintCheckRules rule)
        {
            return SqlSugarHelper.DBClient(serverID).Insertable(rule).ExecuteCommand();
        }
        public static int DeleteCheckRules(string serverID, int id)
        {
            return SqlSugarHelper.DBClient(serverID).Deleteable<MaintCheckRules>().In(id).ExecuteCommand();
        }
        public static int UpdateCheckRules(string serverID, MaintCheckRules rule)
        {
            return SqlSugarHelper.DBClient(serverID).Updateable(rule).ExecuteCommand();
        }
        public static List<MaintCheckRules> GetAllCheckRules(string serverID)
        {
            return SqlSugarHelper.DBClient(serverID).Queryable<MaintCheckRules>().ToList();
        }
        public static List<MaintCheckRules> GetCheckRulesById(string serverID,decimal id)
        {
            return SqlSugarHelper.DBClient(serverID).Queryable<MaintCheckRules>().Where(r => r.i_id == Convert.ToInt32(id)).ToList();
        }
        public static List<MaintMaintainRules> GetMaintainRules(string serverID)
        {
            return SqlSugarHelper.DBClient(serverID).Queryable<MaintMaintainRules>().Where(r => r.i_valid == 1).ToList();
        }
    }
}
