﻿using ERPDal;
using ErpModel;
using ErpModel.FormManage;
using ERPModel.UserManage;
using ERPModel.Vehicleinfomanage;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ERPBll.CardInfo
{
    public class CheckPlanBll
    {
        /// <summary>
        /// 新增年检计划
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="plan"></param>
        /// <returns></returns>
        public static decimal AddCheckPlan(string serverID, MaintCheckPlan plan)
        {
            return SqlSugarHelper.DBClient(serverID).Insertable(plan).ExecuteCommand();
        }
        /// <summary>
        /// 新增年检计划相关图片
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="pics"></param>
        /// <returns></returns>
        public static int AddCheckPic(string serverID, MaintCheckPlanPic pics)
        {
            return SqlSugarHelper.DBClient(serverID).Insertable(pics).ExecuteCommand();
        }
        /// <summary>
        /// 新增年检审核记录
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="appr"></param>
        /// <returns></returns>
        public static int AddCheckAppr(string serverID, MaintCheckPlanAppr appr)
        {
            return SqlSugarHelper.DBClient(serverID).Insertable(appr).ExecuteCommand();
        }
        /// <summary>
        /// 新增年检审核明细记录
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="details"></param>
        /// <returns></returns>
        public static int AddCheckDetail(string serverID, List<MaintCheckPlanDetail> details)
        {
            return SqlSugarHelper.DBClient(serverID).Insertable(details).ExecuteCommand();
        }
        /// <summary>
        /// 更新年检计划状态
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="state"></param>
        /// <param name="id"></param>
        /// <returns></returns>
        public static int UpdatePlanState(string serverID, int state, decimal id)
        {
            if (state == 3)
            {
                return SqlSugarHelper.DBClient(serverID)
                    .Updateable<MaintCheckPlan>(r => new MaintCheckPlan { i_approval_state = 3, i_check_state = 1 })
                    .Where(r => r.i_id == id).ExecuteCommand();
            }
            else if (state == 2 || state == 4)
            {
                return SqlSugarHelper.DBClient(serverID)
                    .Updateable<MaintCheckPlan>(r => new MaintCheckPlan { i_approval_state = (short)state })
                    .Where(r => r.i_id == id).ExecuteCommand();
            }
            else
            {
                return 0;
            }
        }
        /// <summary>
        /// 提交年检记录
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="plan">提交计划信息</param>
        /// <returns></returns>
        public static int SubmitPlan(string serverID, MaintCheckPlan plan)
        {
            return SqlSugarHelper.DBClient(serverID).Updateable(plan).ExecuteCommand();
                   //.Updateable<MaintCheckPlan>(r => new MaintCheckPlan
                   //{
                   //    c_remark = plan.c_remark,
                   //    i_submit_user = plan.i_submit_user,
                   //    d_check_time_true = plan.d_check_time_true,
                   //    i_approval_state = plan.i_approval_state,
                   //    d_submit = plan.d_submit,
                   //    c_title = plan.c_title
                   //})
                   //.Where(r => r.i_id == plan.i_id).ExecuteCommand();
        }
        /// <summary>
        /// 审核完成更新年检计划主表
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="plan"></param>
        /// <returns></returns>
        public static int UpdatePlan(string serverID, MaintCheckPlan plan)
        {
            return SqlSugarHelper.DBClient(serverID)
                   .Updateable<MaintCheckPlan>(r => new MaintCheckPlan
                   {
                       d_check_time_true = plan.d_check_time_true,
                       c_remark = plan.c_remark,
                       i_submit_user = plan.i_submit_user,
                       i_approval_state = 3,
                       i_check_state = 1
                   })
                   .Where(r => r.i_id == plan.i_id).ExecuteCommand();
        }
        /// <summary>
        /// 修改年检计划图片相关信息
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="pics"></param>
        /// <returns></returns>
        public static int UpdateCheckPic(string serverID, MaintCheckPlanPic pics)
        {
            return SqlSugarHelper.DBClient(serverID).Updateable(pics).ExecuteCommand();
        }
        /// <summary>
        /// 更新年检计划审核表
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="user_id">审核者ID</param>
        /// <param name="main_id">年检计划ID</param>
        /// <param name="result">审核结果：3：审核完成，4：拒绝,7:撤销</param>
        /// <param name="form_id">表单ID</param>
        /// <param name="remark"></param>
        /// <returns></returns>
        public static int UpdateCheckAppr(string serverID, decimal user_id, decimal main_id, int result, string remark, string form_id = "")
        {
            if (result == 7)
            {
                var record = SqlSugarHelper.DBClient(serverID).Queryable<MaintCheckPlanAppr>()
                               .Where(r => r.c_form_id == form_id && r.i_main_id == main_id && r.i_person_type == 4).First();
                if (record == null)
                {
                    return -3;
                }
                else
                {
                    if (record.i_approval_user != user_id)
                    {
                        return -1;
                    }
                    else
                    {
                        return SqlSugarHelper.DBClient(serverID)
                               .Updateable<MaintCheckPlanAppr>(r => new MaintCheckPlanAppr { i_approval_state = 7, c_remark = remark, d_approval_time = DateTime.Now })
                               .Where(r => r.i_id == record.i_id).ExecuteCommand();
                    }
                }
            }
            else
            {
                var record = SqlSugarHelper.DBClient(serverID).Queryable<MaintCheckPlanAppr>()
                    .Where(r => r.i_main_id == main_id && (r.i_approval_state == 1 || r.i_approval_state == 2))
                    .WhereIF(!string.IsNullOrEmpty(form_id), r => r.c_form_id == form_id)
                    .OrderBy(r => r.i_seq, OrderByType.Asc).First();
                if (record == null)
                {
                    return -3;
                }
                else
                {
                    if (record.i_type == 1)
                    {
                        if (record.i_approval_user != user_id)
                        {
                            return -1;
                        }
                        else
                        {
                            int res = 0;
                            if (result == 3)
                            {
                                res = SqlSugarHelper.DBClient(serverID).Updateable<MaintCheckPlanAppr>(r => new MaintCheckPlanAppr { i_approval_state = 3, 
                                    c_remark = remark, d_approval_time = DateTime.Now }).Where(r => r.i_id == record.i_id).ExecuteCommand();
                            }
                            else if (result == 4)
                            {
                                res = SqlSugarHelper.DBClient(serverID).Updateable<MaintCheckPlanAppr>(r => new MaintCheckPlanAppr { i_approval_state = 4, 
                                    c_remark = remark, d_approval_time = DateTime.Now }).Where(r => r.i_id == record.i_id).ExecuteCommand();
                            }
                            return res;
                        }
                    }
                    else
                    {
                        var details = SqlSugarHelper.DBClient(serverID).Queryable<MaintCheckPlanDetail>()
                            .Where(r => r.i_main_id == record.i_id && r.i_approval_state == 1).OrderBy(r => r.i_seq, OrderByType.Asc).ToList();
                        if ((record.i_type == 2 || record.i_type == 3) && !details.Exists(r => r.i_approval_user == user_id))
                        {
                            return -1;
                        }
                        else if (record.i_type == 4 && details.FirstOrDefault().i_approval_user != user_id)
                        {
                            return -1;
                        }
                        else
                        {
                            if (result == 3)
                            {
                                var res = SqlSugarHelper.DBClient(serverID).Updateable<MaintCheckPlanDetail>(r => new MaintCheckPlanDetail { i_approval_state = 3, 
                                    c_remark = remark, d_approval_time = DateTime.Now }).Where(r => r.i_main_id == record.i_id && r.i_approval_user == user_id).ExecuteCommand();
                                if (res > 0)
                                {
                                    if (record.i_type == 2 || record.i_type == 4)
                                    {
                                        var list = GetCheckDetail(serverID, record.i_id);
                                        if (list.Select(r=>r.i_seq).Max() == list.Where(r => r.i_approval_state == 3).Count())
                                        {
                                            res = SqlSugarHelper.DBClient(serverID)
                                                .Updateable<MaintCheckPlanAppr>(r => new MaintCheckPlanAppr { i_approval_state = 3, d_approval_time = DateTime.Now })
                                                    .Where(r => r.i_id == record.i_id).ExecuteCommand();
                                        }
                                        else
                                        {
                                            res = SqlSugarHelper.DBClient(serverID).Updateable<MaintCheckPlanAppr>(r => new MaintCheckPlanAppr { i_approval_state = 2 })
                                                        .Where(r => r.i_id == record.i_id).ExecuteCommand();
                                        }
                                    }
                                    else if (record.i_type == 3)
                                    {
                                        res = SqlSugarHelper.DBClient(serverID)
                                            .Updateable<MaintCheckPlanAppr>(r => new MaintCheckPlanAppr { i_approval_state = 3, d_approval_time = DateTime.Now })
                                                    .Where(r => r.i_id == record.i_id).ExecuteCommand();
                                    }
                                }
                                return res;
                            }
                            else if (result == 4)
                            {
                                var res = SqlSugarHelper.DBClient(serverID)
                                     .Updateable<MaintCheckPlanDetail>(r => new MaintCheckPlanDetail { i_approval_state = 4, c_remark = remark, d_approval_time = DateTime.Now })
                                      .Where(r => r.i_main_id == record.i_id && r.i_approval_user == user_id).ExecuteCommand();
                                res = SqlSugarHelper.DBClient(serverID)
                                    .Updateable<MaintCheckPlanAppr>(r => new MaintCheckPlanAppr { i_approval_state = 4, d_approval_time = DateTime.Now })
                                      .Where(r => r.i_id == record.i_id).ExecuteCommand();
                                return res;
                            }
                            else
                            {
                                return -4;
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// 回退，转交审批流程
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="user_id">审核者ID</param>
        /// <param name="main_id">年检计划ID</param>
        /// <param name="result">5：退回，6，转交</param>
        /// <param name="remark"></param>
        /// <returns></returns>
        public static int TransferCheckAppr(string serverID, decimal user_id, decimal main_id, int result, string remark, string target, string form_id)
        {
            var record = SqlSugarHelper.DBClient(serverID).Queryable<MaintCheckPlanAppr>()
                    .Where(r => r.i_main_id == main_id && (r.i_approval_state == 1 || r.i_approval_state == 2))
                    .WhereIF(!string.IsNullOrEmpty(form_id), r => r.c_form_id == form_id)
                    .OrderBy(r => r.i_seq, OrderByType.Asc).First();
            if (record == null)
            {
                return -3;
            }
            else
            {

                if (record.i_type == 1)
                {
                    if (record.i_approval_user != user_id)
                    {
                        return -1;
                    }
                    else
                    {
                        int res = 0;
                        if (result == 5)
                        {
                            record.i_approval_state = 5;
                            record.c_remark = remark;
                            record.d_approval_time = DateTime.Now;
                            res = SqlSugarHelper.DBClient(serverID).Updateable(record).ExecuteCommand();//更新当前节点状态
                            var list = SqlSugarHelper.DBClient(serverID).Queryable<MaintCheckPlanAppr>()
                                .Where(r => r.i_main_id == record.i_main_id && r.c_form_id == record.c_form_id)
                                .Where(r => r.i_seq >= Convert.ToDecimal(target) && r.i_seq <= record.i_seq).ToList();
                            list.ForEach(r => r.i_approval_state = 5);
                            res = SqlSugarHelper.DBClient(serverID).Updateable(list).ExecuteCommand();//更新回退节点状态

                            var list1 = new List<MaintCheckPlanDetail>();//新增的明细节点数据
                            var list2 = new List<MaintCheckPlanAppr>();//新增的回退节点数据
                            foreach (var item in list)
                            {
                                var temp = new MaintCheckPlanAppr();
                                temp = item;
                                temp.i_approval_state = 1;
                                temp.i_id = Tools.GetID(serverID);
                                temp.c_remark = string.Empty;
                                temp.d_approval_time = null;
                                list2.Add(temp);
                                if (item.i_type > 1)
                                {
                                    var aa = SqlSugarHelper.DBClient(serverID).Queryable<MaintCheckPlanDetail>().Where(r => r.i_main_id == item.i_id).ToList();
                                    aa.ForEach(r =>
                                    {
                                        r.i_id = Tools.GetID(serverID);
                                        r.i_main_id = temp.i_id;
                                        r.i_approval_state = 1;
                                        r.c_remark = null;
                                        r.d_approval_time = null;
                                    });
                                    list1.AddRange(aa);
                                }
                            }
                            if (list1.Count > 0)
                            {
                                res = SqlSugarHelper.DBClient(serverID).Insertable(list1).ExecuteCommand();
                            }
                            if (list2.Count>0)
                            {
                                res = SqlSugarHelper.DBClient(serverID).Insertable(list2).ExecuteCommand();
                            }
                        }
                        else if (result == 6)
                        {
                            record.i_approval_state = 6;
                            record.d_approval_time = DateTime.Now;
                            res = SqlSugarHelper.DBClient(serverID).Updateable(record).ExecuteCommand();
                            record.i_id = Tools.GetID(serverID);
                            record.i_approval_user = Convert.ToDecimal(target);
                            record.d_approval_time = null;
                            record.i_approval_state = 1;
                            res = SqlSugarHelper.DBClient(serverID).Insertable(record).ExecuteCommand();
                        }
                        return res;
                    }
                }
                else
                {
                    var details = SqlSugarHelper.DBClient(serverID).Queryable<MaintCheckPlanDetail>()
                        .Where(r => r.i_main_id == record.i_id && r.i_approval_state == 1).OrderBy(r => r.i_seq, OrderByType.Asc).ToList();
                    if ((record.i_type == 2 || record.i_type == 3) && !details.Exists(r => r.i_approval_user == user_id))
                    {
                        return -1;
                    }
                    else
                    {
                        int res = 0;
                        var record1 = details.Where(r => r.i_approval_user == user_id).First();
                        if (result == 5)
                        {
                            record.i_approval_state = 5;
                            record.d_approval_time = DateTime.Now;
                            res = SqlSugarHelper.DBClient(serverID).Updateable(record).ExecuteCommand();
                            record1.c_remark = remark;
                            res = SqlSugarHelper.DBClient(serverID).Updateable(record1).ExecuteCommand();
                            var list = SqlSugarHelper.DBClient(serverID).Queryable<MaintCheckPlanAppr>()
                                .Where(r => r.i_main_id == record.i_main_id && r.c_form_id == record.c_form_id)
                                .Where(r => r.i_seq >= Convert.ToDecimal(target) && r.i_seq <= record.i_seq).ToList();
                            list.ForEach(r => r.i_approval_state = 5);
                            res = SqlSugarHelper.DBClient(serverID).Updateable(list).ExecuteCommand();

                            var list1 = new List<MaintCheckPlanDetail>();//新增的明细节点数据
                            var list2 = new List<MaintCheckPlanAppr>();//新增的回退节点数据
                            foreach (var item in list)
                            {
                                int i_id = Tools.GetID(serverID);
                                if (item.i_type > 1)
                                {
                                    var aa = SqlSugarHelper.DBClient(serverID).Queryable<MaintCheckPlanDetail>().Where(r => r.i_main_id == item.i_id).ToList();
                                    aa.ForEach(r =>
                                    {
                                        r.i_id = Tools.GetID(serverID);
                                        r.i_main_id = i_id;
                                        r.i_approval_state = 1;
                                        r.c_remark = null;
                                        r.d_approval_time = null;
                                    });
                                    list1.AddRange(aa);
                                }

                                item.i_approval_state = 1;
                                item.c_remark = string.Empty;
                                item.d_approval_time = null;
                                item.i_id = i_id;
                                list2.Add(item);
                            }
                            if (list1.Count > 0)
                            {
                                res = SqlSugarHelper.DBClient(serverID).Insertable(list1).ExecuteCommand();
                            }
                            if (list2.Count > 0)
                            {
                                res = SqlSugarHelper.DBClient(serverID).Insertable(list2).ExecuteCommand();
                            }
                        }
                        else if (result == 6)
                        {
                            record1.i_approval_state = 6;
                            res = SqlSugarHelper.DBClient(serverID).Updateable(record1).ExecuteCommand();
                            record1.i_id = Tools.GetID(serverID);
                            record1.i_approval_user = Convert.ToDecimal(target);
                            record1.i_approval_state = 1;
                            res = SqlSugarHelper.DBClient(serverID).Insertable(record1).ExecuteCommand();
                        }
                        return res;
                    }
                }
            }
        
        }
        /// <summary>
        /// 获取全部年检计划
        /// </summary>
        /// <param name="serverID"></param>
        /// <returns></returns>
        public static List<MaintCheckPlan> GetAllCheckPlan(string serverID)
        {
            return SqlSugarHelper.DBClient(serverID).Queryable<MaintCheckPlan>().ToList();
        }

        /// <summary>
        /// 年检计划查询
        /// </summary>
        /// <param name="serverID">数据库连接</param>
        /// <param name="check_range">年检到期日范围</param>
        /// <param name="groups">分公司</param>
        /// <param name="plan_state">年检审核状态</param>
        /// <param name="check_state">年检状态(0:全部，1：已年检，2：未年检，3：已超期)</param>
        /// <param name="cid">车辆型号id</param>
        /// <param name="regist_range">登记时间范围</param>
        /// <param name="pageindex">页码</param>
        /// <param name="pagesize">每页的数据条数</param>
        /// <param name="vehicle_id">车辆ID</param>
        /// <param name="check_cycle">年检周期</param>
        /// <param name="last_range">上次年检日期范围</param>
        /// <param name="plan_id">计划ID</param>
        /// <returns></returns>
        public static Tuple<int, List<CheckPlanModel>> GetAllCheckPlan(string serverID, List<decimal?> ids, List<string> check_range, List<string> groups, string plan_state, int check_state,string cid, List<string> regist_range, int pageindex, int pagesize, List<decimal> vehicle_id, string check_cycle, List<string> last_range, decimal plan_id)
        {
            DateTime date1 = DateTime.Now;
            DateTime date2 = DateTime.Now;
            if (check_range.Count > 0)
            {
                date1 = Convert.ToDateTime(check_range[0]);
                date2 = Convert.ToDateTime(check_range[1]);
            }
            DateTime date3 = DateTime.Now;
            DateTime date4 = DateTime.Now;
            if (regist_range.Count > 0)
            {
                date3 = Convert.ToDateTime(regist_range[0]);
                date4 = Convert.ToDateTime(regist_range[1]);
            }
            DateTime date5 = DateTime.Now;
            DateTime date6 = DateTime.Now;
            if (last_range.Count > 0)
            {
                date5 = Convert.ToDateTime(last_range[0]);
                date6 = Convert.ToDateTime(last_range[1]);
            }
            int total = 0;
            var list = new List<CheckPlanModel>();

            list = SqlSugarHelper.DBClient(serverID).Queryable<MaintCheckPlan, ErpVehicleInfo, MaintVehicleKind, SysDepartment, MaintCheckRules, SysPerson>
              ((a, b, c, d, e, f) => new JoinQueryInfos(JoinType.Left, a.i_vehicle_id == b.i_id, JoinType.Left, b.c_id == c.i_id,
                          JoinType.Left, b.c_crews_take == d.i_id.ToString(), JoinType.Left, a.i_rule_id == e.i_id,
                          JoinType.Left, a.i_submit_user == f.i_id))
           .WhereIF(check_range.Count > 0, a => a.d_check_time_plan >= date1 && a.d_check_time_plan <= date2)
           .WhereIF(ids != null && ids.Count > 0, a => SqlFunc.ContainsArray(ids, a.i_id))
           .WhereIF(groups != null && groups.Count > 0, (a, b) => groups.Contains(b.c_crews_take))
           .WhereIF(!string.IsNullOrEmpty(plan_state), r => r.i_approval_state.ToString() == plan_state)
           .WhereIF(!string.IsNullOrEmpty(cid), (a, b, c) => c.i_id.ToString() == cid)
           .WhereIF(regist_range.Count > 0, (a, b) => b.d_regist_certificate_date >= date3 && b.d_regist_certificate_date <= date4)
           .WhereIF(vehicle_id != null && vehicle_id.Count>0, a => vehicle_id.Contains(a.i_vehicle_id.Value) )
           .WhereIF(check_state == 1, a => a.i_check_state == 1)
           .WhereIF(check_state == 2, a => a.i_check_state == 0 && a.d_check_time_plan >= DateTime.Now)
           .WhereIF(check_state == 3, a => a.d_check_time_plan < DateTime.Now && a.i_check_state == 0)
           .WhereIF(!string.IsNullOrEmpty(check_cycle), (a, b, c, d, e) => e.i_condition_type == Convert.ToDecimal(check_cycle))
           .WhereIF(last_range.Count > 0, a => a.d_last_check_time >= date5 && a.d_last_check_time <= date6)
           .WhereIF(plan_id != 0, a => a.i_id == plan_id)
           .Select((a, b, c, d, e, f) => new CheckPlanModel
           {
               id = a.i_id,
               vehicle_id = a.i_vehicle_id,
               v_num = b.c_vehicle_number,
               lp_num = b.c_lincense_plate_number,
               name = c.c_name,
               group = d.c_name,
               reg_date = b.d_regist_certificate_date == null ? "" : ((DateTime)b.d_regist_certificate_date).ToString("yyyy-MM-dd"),
               last_check_date = a.d_last_check_time == null ? "" : ((DateTime)a.d_last_check_time).ToString("yyyy-MM-dd"),
               check_endate = ((DateTime)a.d_check_time_plan).ToString("yyyy-MM-dd"),
               plan_state = a.i_approval_state.ToString(),
               current_date = a.d_check_time_true == null ? "" : ((DateTime)a.d_check_time_true).ToString("yyyy-MM-dd"),
               submit_person = f.c_name,
               submit_date = a.d_submit == null ? "" : ((DateTime)a.d_submit).ToString("yyyy-MM-dd"),
               submit_remark = a.c_remark,
               check_cycle = string.IsNullOrEmpty(e.i_condition_type.ToString()) ? "0" : e.i_condition_type.ToString(),
               check_state = a.i_check_state,
               engin_num = b.c_engine_number
           }).ToPageList(pageindex, pagesize, ref total);

            list.ForEach(r => r.check_state = (short?)(r.check_state == 1 ? 1 : r.check_state == 0 && Convert.ToDateTime(r.check_endate) >= DateTime.Now ? 2 : 3));
            return new Tuple<int, List<CheckPlanModel>>(total, list);
        }
        /// <summary>
        /// 根据主键ID获取年检计划
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="id"></param>
        /// <returns></returns>
        public static List<MaintCheckPlan> GetCheckPlanByID(string serverID, decimal id)
        {
            return SqlSugarHelper.DBClient(serverID).Queryable<MaintCheckPlan>().Where(r => r.i_id == id).ToList();
        }
        /// <summary>
        /// 根据车辆id获取年检计划
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="vehicle_id"></param>
        /// <returns></returns>
        public static List<MaintCheckPlan> GetCheckPlanByVID(string serverID, int vehicle_id)
        {
            return SqlSugarHelper.DBClient(serverID).Queryable<MaintCheckPlan>().Where(r => r.i_vehicle_id == vehicle_id).ToList();
        }
        /// <summary>
        /// 根据主表ID获取相关图片
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="id"></param>
        /// <returns></returns>
        public static List<MaintCheckPlanPic> GetCheckPic(string serverID, decimal id)
        {
            return SqlSugarHelper.DBClient(serverID).Queryable<MaintCheckPlanPic>().Where(r => r.i_main_id == id).ToList();
        }

        /// <summary>
        /// 获取全部图片记录
        /// </summary>
        /// <param name="serverID"></param>
        /// <returns></returns>
        public static List<MaintCheckPlanPic> GetAllCheckPic(string serverID)
        {
            return SqlSugarHelper.DBClient(serverID).Queryable<MaintCheckPlanPic>().ToList();
        }
        /// <summary>
        /// 根据主表ID获取相关审核记录
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="id">计划ID</param>
        /// <returns></returns>
        public static List<MaintCheckPlanAppr> GetCheckAppr(string serverID, decimal id, string form_id = "")
        {
            return SqlSugarHelper.DBClient(serverID).Queryable<MaintCheckPlanAppr>()
                .WhereIF(id != 0, r => r.i_main_id == id)
                .WhereIF(!string.IsNullOrEmpty(form_id), r => r.c_form_id == form_id)
                .OrderBy(r => r.i_id, OrderByType.Asc).ToList();
        }

        /// <summary>
        /// 获取关联记录
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="userid"></param>
        /// <param name="type">1:待处理，2：已处理，3：已发起，4：抄送人</param>
        /// <returns></returns>
        public static List<formRecord> GetRelateRecord(string serverID, decimal userid,int type)
        {
            if (type == 1)
            {
                var list = new List<formRecord>();
                //var list = SqlSugarHelper.DBClient(serverID)
                //.Queryable<MAINT_CHECK_PLAN_APPR, MAINT_CHECK_PLAN_DETAIL>((a, b) => new JoinQueryInfos(JoinType.Left, a.i_id == b.i_main_id))
                //.Where((a, b) => (a.i_approval_state == 1 && a.i_approval_user == userid) || (b.i_approval_state == 1 && b.i_approval_user == userid))
                //.OrderBy((a,b)=>a.i_id,OrderByType.Asc)
                //.Select((a, b) => new formRecord { mainid = (decimal)a.i_main_id, form_id = a.c_form_id }).ToList();
                var list1 = SqlSugarHelper.DBClient(serverID).Queryable<MaintCheckPlanAppr>().Where(r => r.i_approval_state == 1 || r.i_approval_state == 2).ToList();
                var list2 = SqlSugarHelper.DBClient(serverID).Queryable<MaintCheckPlanDetail>().ToList();
                foreach (var item in list1)
                {
                    if (item.i_type == 1 && item.i_approval_user == userid)
                    {
                        list.Add(new formRecord { mainid = (decimal)item.i_main_id, form_id = item.c_form_id });
                    }
                    else
                    {
                        var list3 = list2.Where(r => r.i_main_id == item.i_id).ToList();
                        if (item.i_type == 2 && list3.Exists(r => r.i_approval_user == userid && r.i_approval_state == 1))
                        {
                            list.Add(new formRecord { mainid = (decimal)item.i_main_id, form_id = item.c_form_id });
                        }
                        if (item.i_type == 3 && list3.Exists(r => r.i_approval_user == userid) && 
                            list3.Where(r => r.i_approval_state == 1).Count() == list3.Select(r => r.i_seq).Distinct().Count())
                        {
                            list.Add(new formRecord { mainid = (decimal)item.i_main_id, form_id = item.c_form_id });
                        }
                    }
                }
                return list.Distinct().ToList();
            }
            else if (type == 2)
            {
                var list = SqlSugarHelper.DBClient(serverID)
                    .Queryable<MaintCheckPlanAppr, MaintCheckPlanDetail>((a, b) => new JoinQueryInfos(JoinType.Left, a.i_id == b.i_main_id))
                    .Where((a, b) => (a.i_approval_user == userid && (a.i_approval_state == 3 || a.i_approval_state == 4 ))
                    || (b.i_approval_user == userid && (b.i_approval_state == 3 || b.i_approval_state == 4 )))
                    .OrderBy((a, b) => a.i_id, OrderByType.Asc)
                    .Select((a, b) => new formRecord { mainid = (decimal)a.i_main_id, form_id = a.c_form_id }).ToList();
                return list.Distinct().ToList();
            }
            else if (type == 3)
            {
                var list = SqlSugarHelper.DBClient(serverID)
                    .Queryable<MaintCheckPlanAppr, MaintCheckPlanDetail>((a, b) => new JoinQueryInfos(JoinType.Left, a.i_id == b.i_main_id))
                    .Where((a, b) => (a.i_person_type == 4 && a.i_approval_user == userid))
                    .OrderBy((a, b) => a.i_id, OrderByType.Asc)
                    .Select((a, b) => new formRecord { mainid = (decimal)a.i_main_id, form_id = a.c_form_id }).ToList();
                return list.Distinct().ToList();
            }
            else if (type == 4)
            {
                var list = SqlSugarHelper.DBClient(serverID)
                    .Queryable<MaintCheckPlanAppr, MaintCheckPlanDetail>((a, b) => new JoinQueryInfos(JoinType.Left, a.i_id == b.i_main_id))
                    .Where((a, b) => a.i_person_type == 3 && (a.i_approval_user == userid || b.i_approval_user == userid))
                    .OrderBy((a, b) => a.i_id, OrderByType.Asc)
                    .Select((a, b) => new formRecord { mainid = (decimal)a.i_main_id, form_id = a.c_form_id }).ToList();
                return list.Distinct().ToList();
            }
            else
            {
                var list = SqlSugarHelper.DBClient(serverID)
                    .Queryable<MaintCheckPlanAppr, MaintCheckPlanDetail>((a, b) => new JoinQueryInfos(JoinType.Left, a.i_id == b.i_main_id))
                    .OrderBy((a, b) => a.i_id, OrderByType.Asc)
                    .Select((a, b) => new formRecord { mainid = (decimal)a.i_main_id, form_id = a.c_form_id }).ToList();
                return list.Distinct().ToList();
            }
        }
        /// <summary>
        /// 根据审批主表获取明细数据
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="id">审批主表主键ID</param>
        /// <returns></returns>
        public static List<MaintCheckPlanDetail> GetCheckDetail(string serverID, decimal id)
        {
            return SqlSugarHelper.DBClient(serverID).Queryable<MaintCheckPlanDetail>().Where(r => r.i_main_id == id)
                .OrderBy(r => r.d_approval_time, OrderByType.Asc).ToList();
        }
    }
}
