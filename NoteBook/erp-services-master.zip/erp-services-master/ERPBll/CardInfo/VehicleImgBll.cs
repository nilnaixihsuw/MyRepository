﻿using ERPDal;
using ERPDal.VehiclInfo;
using ERPModel.Vehicleinfomanage;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace ERPBll.Vehicleinfomanage
{
    public class VehicleImgBll
    {
        /// <summary>
        /// 新增车辆相关证件图片
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="info"></param>
        /// <returns></returns>
        public static int AddCCert(string serverID, List<VehicleCert> info)
        {
            foreach (var item in info)
            {
                item.id = ERPBll.Tools.GetID(serverID);
            }
            return VehicleImgDal.addCCert(serverID, info);
        }
        /// <summary>
        /// 新增车辆相关证件图片
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="infos"></param>
        /// <returns></returns>
        public static int AddCCert(string serverID, List<VehicleCertificateInfo> infos)
        {
            List<VehicleCertificateInfo> temp = new List<VehicleCertificateInfo>();
            var db = SqlSugarHelper.DBClient(serverID);
            var images_origin = db.Queryable<VehicleCertificateInfo>().ToList();
            var vehicles = db.Queryable<VehicleInfoNew>().ToList();
            foreach (var item in infos)
            {
                if (!images_origin.Exists(r => r.c_image_path == item.c_image_path))
                {
                    item.i_id = ERPBll.Tools.GetID(serverID);
                    item.c_lincense_plate_number = vehicles.Find(r => r.v_num == item.c_vehicle_number)?.lp_num;
                    temp.Add(item);
                }
            }
            if (temp.Count == 0)
            {
                return 0;
            }
            else
            {
                return db.Insertable(temp).ExecuteCommand();
            }
        }
        /// <summary>
        /// 删除车辆相关证件图片
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="info"></param>
        /// <returns></returns>
        public static bool DeleteCCert(string serverID, List<VehicleCert> info)
        {
            return VehicleImgDal.deleteCCert(serverID, info);
        }

        public static int DeleteCCert(string serverID, List<decimal> ids)
        {
            return SqlSugarHelper.DBClient(serverID).Deleteable<VehicleCertificateInfo>().In(ids).ExecuteCommand();
        }
        /// <summary>
        /// 删除车辆相关证件图片
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="info"></param>
        /// <returns></returns>
        public static int DeleteCCert(string serverID, List<VehicleCertificateInfo> info)
        {
            return SqlSugarHelper.DBClient(serverID).Deleteable(info).ExecuteCommand();
        }
        /// <summary>
        /// 更新车辆相关证件图片信息
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="info"></param>
        /// <returns></returns>
        public static bool UpdateCCert(string serverID, List<VehicleCert> info)
        {
            return VehicleImgDal.updateCCert(serverID, info);
        }
        /// <summary>
        /// 更新车辆相关证件图片信息
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="info"></param>
        /// <returns></returns>
        public static int UpdateCCert(string serverID, List<VehicleCertificateInfo> info)
        {
            return SqlSugarHelper.DBClient(serverID).Updateable(info).ExecuteCommand();
        }
        /// <summary>
        /// 获取车辆相关证件图片信息
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="vnum"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        public static List<VehicleCert> GetCCert(string serverID, string vnum, string type)
        {
            var dt = VehicleImgDal.getCCert(serverID, vnum, type);
            List<VehicleCert> list = new List<VehicleCert>();
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow item in dt.Rows)
                {
                    VehicleCert temp = new VehicleCert();
                    temp.id = item["i_id"] is DBNull ? 0 : Convert.ToDecimal(item["i_id"]);
                    temp.v_num = item["c_vehicle_number"] is DBNull ? "" : Convert.ToString(item["c_vehicle_number"]);
                    temp.image_path = item["c_image_path"] is DBNull ? "" : Convert.ToString(item["c_image_path"]);
                    temp.image_type = (short?)(item["c_image_type"] is DBNull ? 0 : Convert.ToInt16(item["c_image_type"]));
                    list.Add(temp);
                }
            }
            return list;
        }
        /// <summary>
        /// 获取车辆相关证件图片信息
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="vnum"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        public static List<VehicleCert> GetCCert1(string serverID, string vnum, string type)
        {
            var list = SqlSugarHelper.DBClient(serverID).Queryable<VehicleCertificateInfo>()
                .WhereIF(!string.IsNullOrEmpty(vnum), r => r.c_vehicle_number == vnum)
                .WhereIF(!string.IsNullOrEmpty(type), r => r.c_image_type.ToString() == type)
                .Select(r => new VehicleCert
                {
                    id = r.i_id,
                    v_num = r.c_vehicle_number,
                    image_path = r.c_image_path,
                    image_type = r.c_image_type
                }).ToList();
            return list;
        }
    }
}
