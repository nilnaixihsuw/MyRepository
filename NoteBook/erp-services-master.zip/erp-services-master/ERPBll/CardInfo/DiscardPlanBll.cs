﻿using ERPDal;
using ERPModel.UserManage;
using ERPModel.Vehicleinfomanage;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ERPBll.CardInfo
{
    public class DiscardPlanBll
    {
        /// <summary>
        /// 插入报废计划相关图片
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="pics"></param>
        /// <returns></returns>
        public static int AddDiscardPic(string serverID, MaintDiscardPlanPic pics)
        {
            return SqlSugarHelper.DBClient(serverID).Insertable(pics).ExecuteCommand();
        }
        /// <summary>
        /// 插入报废审核记录
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="appr"></param>
        /// <returns></returns>
        public static int AddDiscardAppr(string serverID, MaintDiscardPlanAppr appr)
        {
            appr.i_id = ERPBll.Tools.GetID(serverID);
            return SqlSugarHelper.DBClient(serverID).Insertable(appr).ExecuteCommand();
        }
        /// <summary>
        /// 更新报废计划状态
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="state"></param>
        /// <param name="id"></param>
        /// <returns></returns>
        public static int UpdatePlanState(string serverID, int state, decimal id)
        {
            return 0;
            //if (state == 3)
            //{
            //    return SqlSugarHelper.DBClient(serverID)
            //        .Updateable<MaintDiscardPlan>(r => new MaintDiscardPlan { i_approval_state = 3, check_state = 1 })
            //        .Where(r => r.id == id).ExecuteCommand();
            //}
            //else if (state == 2 || state == 4)
            //{
            //    return SqlSugarHelper.DBClient(serverID)
            //        .Updateable<MaintDiscardPlan>(r => new MaintDiscardPlan { i_approval_state = (short)state })
            //        .Where(r => r.id == id).ExecuteCommand();
            //}
            //else
            //{
            //    return 0;
            //}
        }
        /// <summary>
        /// 提交报废计划
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="id"></param>
        /// <param name="reason"></param>
        /// <param name="submitid"></param>
        /// <param name="plan_date"></param>
        /// <returns></returns>
        public static int SubmitPlan(string serverID, MaintDiscardPlan plan)
        {
            return SqlSugarHelper.DBClient(serverID).Updateable(plan).ExecuteCommand();
                   //.Updateable<MaintDiscardPlan>(r => new MaintDiscardPlan
                   //{
                   //    c_reason = reason,
                   //    i_submit_user = submitid,
                   //    d_plan_date = plan_date,
                   //    d_submit = DateTime.Now,
                   //    i_approval_state = 1
                   //})
                   //.Where(r => r.i_id == id).ExecuteCommand();
        }
        /// <summary>
        /// 更新报废计划审核状态
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="plan"></param>
        /// <returns></returns>
        public static int UpdatePlan(string serverID, MaintDiscardPlan plan)
        {
            return SqlSugarHelper.DBClient(serverID)
                   .Updateable<MaintDiscardPlan>(r => new MaintDiscardPlan
                   {
                       plan_date = plan.plan_date,
                       remark = plan.remark,
                       //i_submit_user = plan.i_submit_user,
                       //i_approval_state = 3,
                       check_state = 1
                   })
                   .Where(r => r.id == plan.id).ExecuteCommand();
        }
        public static int UpdateDiscardPic(string serverID, MaintDiscardPlanPic pics)
        {
            return SqlSugarHelper.DBClient(serverID).Updateable(pics).ExecuteCommand();
        }
        public static int UpdateDiscardAppr(string serverID, decimal checker, decimal main_id, int result, string remark)
        {
            if (result == 3)
            {
                return SqlSugarHelper.DBClient(serverID)
                    .Updateable<MaintDiscardPlanAppr>(r => new MaintDiscardPlanAppr { i_approval_state = 3, c_remark = remark, d_approval_time = DateTime.Now })
                    .Where(r => r.i_main_id == main_id)
                    .Where(r => r.i_approval_user == checker).ExecuteCommand();
            }
            else if (result == 4)
            {
                return SqlSugarHelper.DBClient(serverID)
                    .Updateable<MaintDiscardPlanAppr>(r => new MaintDiscardPlanAppr { i_approval_state = 4, c_remark = remark })
                    .Where(r => r.i_main_id == main_id)
                    .Where(r => r.i_approval_user == checker).ExecuteCommand();
            }
            else
            {
                return 0;
            }
        } 
        /// <summary>
        /// 获取全部报废计划
        /// </summary>
        /// <param name="serverID"></param>
        /// <returns></returns>
        public static List<MaintDiscardPlan> GetAllDiscardPlan(string serverID)
        {
            return SqlSugarHelper.DBClient(serverID).Queryable<MaintDiscardPlan>().ToList();
        }
        public static Tuple<int, List<DiscardPlanDto>> GetAllDiscardPlan(string serverID, List<string> dis_range, List<string> group_ids, int page_index, int page_size,
            int dis_state, decimal plan_id, string ids)
        {
            DateTime date1 = DateTime.Now;
            DateTime date2 = DateTime.Now;
            if (dis_range.Count > 0)
            {
                date1 = Convert.ToDateTime(dis_range[0]);
                date2 = Convert.ToDateTime(dis_range[1]);
            }
            int total = 0;
            var aa = new List<decimal?>();
            if (!string.IsNullOrEmpty(ids))
            {
                ids.Split(',').ToList().ForEach(r => aa.Add(Convert.ToDecimal(r)));
            }

            var vehicles = SqlSugarHelper.DBClient(serverID).Queryable<VehicleInfoNew, MaintVehicleKind>((a, b) =>
                       new JoinQueryInfos(JoinType.Left, a.cid == b.i_id))
               .WhereIF(group_ids != null && group_ids.Count > 0, (a, b) => group_ids.Contains(a.group))
               .Mapper(a => a.group_info, a => a.group)
               .Mapper(a => a.vehicle_kind_info, a => a.cid)
               .ToList();

            var records = SqlSugarHelper.DBClient(serverID).Queryable<MaintDiscardPlan>()
                .WhereIF(dis_range.Count > 0, a => a.plan_date > date1 && a.plan_date < date2)
           //.WhereIF(group_ids != null && group_ids.Count > 0, (a, b) => group_ids.Contains(b.group))
           //.WhereIF(!string.IsNullOrEmpty(group_id), (a, b) => b.group == group_id)
                .WhereIF(dis_state == 1, a => a.check_state == 1)
                .WhereIF(dis_state == 2, a => a.check_state == 0)
                .WhereIF(plan_id != 0, a => a.id == plan_id)
                .WhereIF(aa != null && aa.Count > 0, a => aa.Contains(a.id))
                .Where(r => vehicles.Select(m => m.id).Contains(r.vehicle_id))
                .ToPageList(page_index, page_size, ref total);
            //.Select(a => new DiscardPlanDto
            // {
            //     id = (int)a.id,
            //     v_num = b.v_num,
            //     lp_num = b.lp_num,
            //     group = c.c_name,
            //     reg_date = b.reg_date == null ? "" : ((DateTime)b.reg_date).ToString("yyyy-MM-dd"),
            //     name = d.c_name,
            //     //plan_state = a.i_approval_state.ToString(),
            //     dis_date = a.plan_date == null ? "" : ((DateTime)a.plan_date).ToString("yyyy-MM-dd"),
            //     reason = a.reason,
            //     //submit_person = e.c_name,
            //     //submit_date = a.d_submit == null ? "" : ((DateTime)a.d_submit).ToString("yyyy-MM-dd"),
            //     check_state = (int)a.check_state,
            //     state = a.state,
            //     flow_id = a.flow_id
            // })
            //.ToPageList(page_index, page_size, ref total);

            var list = new List<DiscardPlanDto>();
            var persons = SqlSugarHelper.DBClient(serverID).Queryable<SysPerson>().ToList();
            foreach (var item in records)
            {
                var temp = new DiscardPlanDto();
                temp.id = item.id;
                temp.dis_date = item.plan_date == null ? "" : item.plan_date.Value.ToString("yyyy-MM-dd");
                temp.check_state = (int)item.check_state;
                temp.reason = item.reason;
                var vehicle = vehicles.Find(r => r.id == item.vehicle_id);
                if (vehicle != null)
                {
                    temp.v_num = vehicle.v_num;
                    temp.lp_num = vehicle.lp_num;
                    temp.group = vehicle.group_info?.c_name;
                    temp.reg_date = vehicle.reg_date == null ? "" : vehicle.reg_date.Value.ToString("yyyy-MM-dd");
                    temp.name = vehicle.vehicle_kind_info?.c_name;
                }
                list.Add(temp);
            }

            return new Tuple<int, List<DiscardPlanDto>>(total, list);
        }

        public static List<MaintDiscardPlan> GetDiscardPlanByID(string serverID, decimal id)
        {
            return SqlSugarHelper.DBClient(serverID).Queryable<MaintDiscardPlan>().Where(r => r.id == id).ToList();
        }
        public static List<MaintDiscardPlan> GetDiscardPlanByVID(string serverID, int vehicle_id)
        {
            return SqlSugarHelper.DBClient(serverID).Queryable<MaintDiscardPlan>().Where(r => r.vehicle_id == vehicle_id).ToList();
        }
        public static List<MaintDiscardPlanPic> GetDiscardPic(string serverID, decimal id)
        {
            return SqlSugarHelper.DBClient(serverID).Queryable<MaintDiscardPlanPic>().Where(r => r.i_main_id == id).ToList();
        }
        /// <summary>
        /// 获取报废计划审核相关记录
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="id"></param>
        /// <returns></returns>
        public static List<MaintDiscardPlanAppr> GetDiscardAppr(string serverID, decimal id)
        {
            return SqlSugarHelper.DBClient(serverID).Queryable<MaintDiscardPlanAppr>().Where(r => r.i_main_id == id).ToList();
        }
       
    }
}
