﻿using ERPCore.Entity;
using ERPModel.ApprovalForm;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.ApprovalForm.Contracts
{
    /// <summary>
    /// 出差单
    /// </summary>
    public interface IOaTripRecordImp
    {
        /// <summary>
        /// 查询
        /// </summary>
        Task<List<OaTripRecordDto>> GetListAsync(string server_id, decimal? user_id, OaTripRecordQuery query);

        /// <summary>
        /// 获取出差单详情
        /// </summary>
        Task<OaTripRecordDto> LookDetailAsync(string server_id, decimal? user_id, decimal id);

        /// <summary>
        /// 获取自己保存的草稿
        /// </summary>
        Task<OaTripRecordDto> GetByUserAsync(string server_id, decimal? user_id);

        /// <summary>
        /// 新增(保存草稿/提交)
        /// </summary>
        Task<OaTripRecordDto> CreateOrUpdateAsync(string server_id, ClientInformation client, TripRecordFormData input);

        /// <summary>
        /// 出差时长汇总
        /// </summary>
        Task<TripRecordSummary> GetSummaryByUserAsync(OaTripRecordByUserQuery query);

        /// <summary>
        /// 计算出差时长(单位：天)
        /// </summary>
        Task<RecordTimeDetail> GetTripDays(GetTimeRequest request);

        /// <summary>
        /// 根据时间段计算天数
        /// </summary>
        /// <returns></returns>
        Task<RecordTimeDetail> GetDays(string server_id, int user_id, DateTime start, DateTime end);
    }
}
