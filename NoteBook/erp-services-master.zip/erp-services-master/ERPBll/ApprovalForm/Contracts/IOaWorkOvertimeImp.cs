﻿using ERPCore.Entity;
using ERPModel.ApprovalForm;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.ApprovalForm.Contracts
{
    public interface IOaWorkOvertimeImp
    {
        /// <summary>
        /// 查询
        /// </summary>
        Task<List<OaWorkOvertimeDto>> GetListAsync(string server_id, decimal? user_id, OaWorkOvertimeQuery query);

        /// <summary>
        /// 获取加班申请详情
        /// </summary>
        Task<OaWorkOvertimeDto> LookDetailAsync(string server_id, decimal? user_id, decimal id);

        /// <summary>
        /// 获取自己保存的草稿
        /// </summary>
        Task<OaWorkOvertimeDto> GetByUserAsync(string server_id, decimal? user_id);

        /// <summary>
        /// 新增加班申请
        /// </summary>
        Task<OaWorkOvertimeDto> CreateOrUpdateAsync(string server_id, ClientInformation  client, WorkOvertimeFormData input);

        /// <summary>
        /// 提交
        /// </summary>
        Task<OaWorkOvertimeDto> SubmitAsync(string server_id, UpdateOaWorkOvertimeState input);

        /// <summary>
        /// 获取指定人员加班统计
        /// </summary>
        /// <param name="user_id"></param>
        /// <param name="start"></param>
        /// <param name="end"></param>
        /// <param name="server_id"></param>
        /// <returns></returns>
        Task<WorkOvertimeCount> GetTimesCount(decimal user_id, DateTime start, DateTime end, string server_id);

        /// <summary>
        /// 获取指定人员加班单数据
        /// </summary>
        /// <param name="user_id"></param>
        /// <param name="type">1工作日 2休息日 3节假日</param>
        /// <param name="start">起始时间</param>
        /// <param name="end">截止时间</param>
        /// <param name="server_id"></param>
        /// <returns></returns>
        Task<OvertimeDoc> GetTimesData(decimal user_id, int type, DateTime start, DateTime end, string server_id);
    }
}
