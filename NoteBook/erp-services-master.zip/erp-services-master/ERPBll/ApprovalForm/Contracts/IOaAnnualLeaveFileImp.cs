﻿using ERPModel.ApprovalForm;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.ApprovalForm.Contracts
{
    public interface IOaAnnualLeaveFileImp
    {
        /// <summary>
        /// 上传附件
        /// </summary>
        Task<bool> CreateAsync(string server_id, List<OaAnnualLeaveFile> list);

        /// <summary>
        /// 根据年休申请id删除附件
        /// </summary>
        Task<bool> DeleteAsync(string server_id, List<decimal> annual_ids);

        /// <summary>
        /// 获取附件列表
        /// </summary>
        Task<List<OaAnnualLeaveFile>> GetListAsync(string server_id, decimal annual_id);
    }
}
