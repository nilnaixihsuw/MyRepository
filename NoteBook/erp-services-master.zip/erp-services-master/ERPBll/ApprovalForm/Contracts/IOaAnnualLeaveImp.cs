﻿using ERPModel.ApprovalForm;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.ApprovalForm.Contracts
{
    public interface IOaAnnualLeaveImp
    {
        /// <summary>
        /// 查询
        /// </summary>
        Task<List<OaAnnualLeaveDto>> GetListAsync(string server_id, decimal? user_id, OaAnnualLeaveQuery query);

        /// <summary>
        /// 获取年休申请详情
        /// </summary>
        Task<OaAnnualLeaveDto> LookDetailAsync(string server_id, decimal? user_id, decimal id);

        /// <summary>
        /// 获取自己保存的草稿
        /// </summary>
        Task<OaAnnualLeaveDto> GetByUserAsync(string server_id, decimal? user_id);

        /// <summary>
        /// 新增/编辑草稿
        /// </summary>
        Task<OaAnnualLeaveDto> CreateOrUpdateAsync(string server_id, decimal? user_id, CreateOrUpdateOaAnnualLeave input);

        /// <summary>
        /// 提交
        /// </summary>
        Task<OaAnnualLeaveDto> SubmitAsync(string server_id, UpdateOaAnnualLeaveState input);
    }
}
