﻿using AutoMapper;
using ERPBll.ApprovalForm.Contracts;
using ERPDal;
using ERPModel.ApprovalForm;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.ApprovalForm.Services
{
    public class OaAnnualLeaveFileImp : IOaAnnualLeaveFileImp
    {
        private readonly IMapper _imapper;

        public OaAnnualLeaveFileImp(IMapper imapper)
        {
            _imapper = imapper;
        }

        /// <summary>
        /// 上传附件
        /// </summary>
        public async Task<bool> CreateAsync(
            string server_id, List<OaAnnualLeaveFile> list)

        {
            //删除旧附件
            SqlSugarHelper.DelByExp<OaAnnualLeaveFile>(server_id, x => x.annual_id == list.First().annual_id);

            return await SqlSugarHelper.DBClient(server_id)
                            .Insertable(list)
                            .ExecuteCommandAsync() > 0;
        }

        /// <summary>
        /// 根据年休申请id删除附件
        /// </summary>
        public async Task<bool> DeleteAsync(
            string server_id, List<decimal> annual_ids)

        {
            return SqlSugarHelper.DelByExp<OaAnnualLeaveFile>(server_id, x => annual_ids.Contains(x.annual_id));
        }

        /// <summary>
        /// 获取附件列表
        /// </summary>
        public async Task<List<OaAnnualLeaveFile>> GetListAsync(
            string server_id, decimal annual_id)

        {
            return await SqlSugarHelper.DBClient(server_id)
                            .Queryable<OaAnnualLeaveFile>()
                            .Where(x => x.annual_id == annual_id)
                            .ToListAsync();
        }
    }
}
