﻿using AutoMapper;
using ERPBll.ApprovalForm.Contracts;
using ERPBll.FlowManage.Contracts;
using ERPBll.OAManage;
using ERPCore.Entity;
using ERPCore.Enums;
using ERPDal;
using ERPModel.ApprovalForm;
using ERPModel.DataBase;
using ERPModel.FlowManage;
using ERPModel.FlowManage.FlowRecords;
using ERPModel.Oamanage.OaKqbcs;
using ERPModel.PersonalManage;
using ERPModel.SystemManage;
using ERPModel.UserManage;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.ApprovalForm.Services
{
    /// <summary>
    /// 出差单
    /// </summary>
    public class OaTripRecordImp : IOaTripRecordImp
    {
        private readonly IMapper _imapper;
        private readonly IErpFlowRecordImp _iErpFlowRecordImp;
        private readonly IOaKqzImp _iOaKqzImp;

        public OaTripRecordImp(
            IMapper imapper,
            IErpFlowRecordImp iErpFlowRecordImp,
            IOaKqzImp iOaKqzImp)
        {
            _imapper = imapper;
            _iErpFlowRecordImp = iErpFlowRecordImp;
            _iOaKqzImp = iOaKqzImp;
        }

        /// <summary>
        /// 查询
        /// </summary>
        public async Task<List<OaTripRecordDto>> GetListAsync(
            string server_id, decimal? user_id, OaTripRecordQuery query)
        {
            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<OaTripRecord>()
                                .Where(query.ToExp())
                                .Mapper(x => x.user_info, x => x.user_id)
                                .Mapper(x => x.created_info, x => x.created_id)
                                .ToListAsync();
            if (list.Count > 0)
            {
                var all = await _iErpFlowRecordImp.GetListAsync(server_id, user_id,
                new FlowRecordQuery()
                {
                    detail_ids = list.Select(x => (int)x.id).ToList()
                });
                foreach (var item in list)
                {
                    if (item.state == 1)//审核中
                    {
                        var info = all.FirstOrDefault(x => x.detail_id == item.id);
                        if (info != null)
                        {
                            item.user_ids = info.state_child_id;
                            item.user_names = info.state_child_name;
                        }
                    }
                }
            }

            var data = _imapper.Map<List<OaTripRecord>, List<OaTripRecordDto>>(list);

            return data;
        }

        /// <summary>
        /// 出差时长汇总
        /// </summary>
        public async Task<TripRecordSummary> GetSummaryByUserAsync(OaTripRecordByUserQuery query)
        {
            var summary = new TripRecordSummary();

            using (var db = SqlSugarHelper.DBClient(query.server_id))
            {
                var kq_list = await db.Queryable<OaAttendanceRecord>()
                    .Where(x => x.type == 3)
                    .WhereIF(query.user_id.HasValue && query.user_id > 0, x => x.user_id == query.user_id)
                    .WhereIF(query.start.HasValue && query.end.HasValue, x => x.date >= query.start.Value.Date && 
                        x.date <= query.end.Value.Date)
                    .ToListAsync();

                if (kq_list.Count > 0)
                {
                    var ids = kq_list.Select(x => x.main_id).Distinct().ToList();
                    //查询
                    var list = await SqlSugarHelper.DBClient(query.server_id)
                                        .Queryable<OaTripRecord>()
                                        .Where(x => SqlFunc.ContainsArray(ids, x.id))
                                        .Mapper(x => x.user_info, x => x.user_id)
                                        .Mapper(x => x.created_info, x => x.created_id)
                                        .ToListAsync();

                    summary.summary_days = (double)kq_list.Sum(x => x.duration);
                    summary.kq_record_list = kq_list;
                    summary.record_list = _imapper.Map<List<OaTripRecord>, List<OaTripRecordDto>>(list);
                }
            }

            return summary;
        }

        /// <summary>
        /// 获取出差单详情
        /// </summary>
        public async Task<OaTripRecordDto> LookDetailAsync(
            string server_id, decimal? user_id, decimal id)
        {

            //查询
            var info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<OaTripRecord>()
                                .Where(x => x.id == id)
                                .Mapper(x => x.created_info, x => x.created_id)
                                .Mapper(x => x.flow_record, x => x.flow_id)
                                .Mapper(x =>
                                {
                                    x.user_info = SqlSugarHelper.DBClient(server_id)
                                                    .Queryable<SysPerson>()
                                                    .Where(y => y.i_id == x.user_id)
                                                    .First();
                                    if (x.user_info != null)
                                    {
                                        x.user_dep_info = SqlSugarHelper.DBClient(server_id)
                                                    .Queryable<SysDepartment>()
                                                    .Where(y => y.i_id == x.user_info.i_department_base)
                                                    .First();
                                    }

                                    x.file_list = SqlSugarHelper.DBClient(server_id)
                                                    .Queryable<SysFileRecord>()
                                                    .Where(y => y.object_id == x.id)
                                                    .ToList();
                                    if (x.file_list.Count > 0)
                                    {
                                        x.files = x.file_list.Select(y => y.url).ToList();
                                    }
                                })
                                .FirstAsync();

            var ids = new List<int>();
            ids.Add(Convert.ToInt32(info.id));

            var all = await _iErpFlowRecordImp.GetListAsync(server_id, user_id,
                new FlowRecordQuery()
                {
                    detail_ids = ids
                });

            if (info.state == 1)//审核中
            {
                var flow_info = all.FirstOrDefault(x => x.detail_id == info.id);
                if (flow_info != null)
                {
                    info.user_ids = flow_info.state_child_id;
                    info.user_names = flow_info.state_child_name;
                }
            }
            var data = _imapper.Map<OaTripRecord, OaTripRecordDto>(info);

            return data;
        }

        /// <summary>
        /// 获取自己保存的草稿
        /// </summary>
        public async Task<OaTripRecordDto> GetByUserAsync(
            string server_id, decimal? user_id)
        {

            //查询
            var info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<OaTripRecord>()
                                .Mapper(x => x.created_info, x => x.created_id)
                                .Mapper(x =>
                                {
                                    x.user_info = SqlSugarHelper.DBClient(server_id)
                                                    .Queryable<SysPerson>()
                                                    .Where(y => y.i_id == x.user_id)
                                                    .First();
                                    if (x.user_info != null)
                                    {
                                        x.user_dep_info = SqlSugarHelper.DBClient(server_id)
                                                    .Queryable<SysDepartment>()
                                                    .Where(y => y.i_id == x.user_info.i_department_base)
                                                    .First();
                                    }

                                    x.file_list = SqlSugarHelper.DBClient(server_id)
                                                    .Queryable<SysFileRecord>()
                                                    .Where(y => y.object_id == x.id)
                                                    .ToList();
                                    if (x.file_list.Count > 0)
                                    {
                                        x.files = x.file_list.Select(y => y.url).ToList();
                                    }
                                })
                                .Where(x => x.created_id == user_id && x.state == 0)
                                .FirstAsync();

            var data = _imapper.Map<OaTripRecord, OaTripRecordDto>(info);

            return data;
        }

        /// <summary>
        /// 新增(保存草稿/提交)
        /// </summary>
        public async Task<OaTripRecordDto> CreateOrUpdateAsync(
            string server_id, ClientInformation client, TripRecordFormData input)
        {
            using (var db = SqlSugarHelper.DBClient(server_id))
            {
                if (input.form_data.start_date > input.form_data.end_date)
                {
                    throw new Exception("开始日期不能大于结束日期");
                }
                if (input.form_data.start_date == input.form_data.end_date && input.form_data.start_time > input.form_data.end_time)
                {
                    throw new Exception("开始时间不能大于结束时间");
                }
                if (input.form_data.files.Count > 9)
                {
                    throw new Exception("最多选择9张图片");
                }

                var list = await db.Queryable<OaTripRecord>()
                       .Where(x => x.user_id == input.form_data.user_id && (x.state == 1 || x.state == 2))
                       .WhereIF(input.form_data.start_date.HasValue && input.form_data.end_date.HasValue &&
                            input.form_data.start_date != input.form_data.end_date, r =>
                        (input.form_data.start_date <= r.start_date && input.form_data.end_date >= r.start_date) ||
                        (input.form_data.start_date >= r.start_date && input.form_data.end_date <= r.end_date) ||
                        (input.form_data.start_date <= r.end_date && input.form_data.end_date >= r.end_date))
                       .WhereIF(input.form_data.start_date.HasValue && input.form_data.end_date.HasValue &&
                            input.form_data.start_date == input.form_data.end_date, r =>
                        input.form_data.start_date == r.start_date && input.form_data.end_date == r.end_date &&
                        (input.form_data.start_time == r.start_time || input.form_data.end_time == r.end_time))
                       .ToListAsync();

                if (list != null && list.Count > 0)
                {
                    throw new Exception("当前时间段已有出差记录");
                }

                if (input.type == 2)//提交
                {
                    if (input.step_data == null || input.step_data.Count < 1)
                    {
                        throw new Exception("审批流程数据为空");
                    }
                    input.step_data.Where(x => x.oper_type == 1).ToList().ForEach(x =>
                    {
                        if (x.users.Count < 1)
                        {
                            throw new Exception("审批节点人员不能为空");
                        }
                        if (x.users.Count > 15)
                        {
                            throw new Exception("审批节点人员最多15人");
                        }
                    });

                    bool is_add = true;
                    var info = new OaTripRecord();
                    if (input.form_data.id.HasValue && input.form_data.id > 0)
                    {
                        info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<OaTripRecord>()
                                .Where(x => x.id == input.form_data.id)
                                .FirstAsync();

                        if (info == null)
                        {
                            throw new Exception($"未找到出差单草稿,id={input.form_data.id}");
                        }
                        if (info.state != 0)
                        {
                            throw new Exception($"只允许草稿状态提交");
                        }

                        is_add = false;
                    }
                    else
                    {
                        info = _imapper.Map<CreateOrUpdateOaTripRecord, OaTripRecord>(input.form_data);
                        info.id = Tools.GetEngineID(server_id);
                        info.ways = string.Join(",", input.form_data.way_ids);
                        info.SetCreate(client.i_id);
                    }

                    //发起流程
                    var flow = await _iErpFlowRecordImp.StartAsync(server_id, client.i_id, input.step_data);
                    if (flow == null)
                    {
                        throw new Exception("发起出差流程失败");
                    }


                    await _iErpFlowRecordImp.UpdateAsync(server_id, flow.id, Convert.ToInt32(info.id),
                            TripRecordMessage.GetContent(client.c_name, info), "", db);

                    info.flow_id = flow.id;
                    info.state = 1;

                    #region 上传图片
                    await db.Deleteable<SysFileRecord>().Where(x => x.object_id == info.id).ExecuteCommandAsync();
                    var file_list = new List<SysFileRecord>();
                    if (input.form_data.files != null && input.form_data.files.Count > 0)
                    {
                        input.form_data.files.ForEach(x => {
                            var file = new SysFileRecord()
                            {
                                model = (int)FileRecordType.TRIPRECORD,
                                object_id = info.id,
                                type = 1,
                                url = x,
                                created_id = client.i_id,
                                created_date = DateTime.Now
                            };
                            file_list.Add(file);
                        });

                        await db.Insertable(file_list).ExecuteCommandAsync();
                    }
                    #endregion

                    if (is_add)
                    {
                        await db.Insertable(info).ExecuteCommandAsync();
                    }
                    else
                    {
                        await db.Updateable(info).ExecuteCommandAsync();
                    }

                    return _imapper.Map<OaTripRecord, OaTripRecordDto>(info);
                }
                else//保存草稿
                {
                    await db.Deleteable<OaTripRecord>().Where(x => x.state == 0 && x.created_id == client.i_id).ExecuteCommandAsync();

                    var info = _imapper.Map<CreateOrUpdateOaTripRecord, OaTripRecord>(input.form_data);
                    info.id = Tools.GetEngineID(server_id);
                    info.ways = string.Join(",", input.form_data.way_ids);
                    info.state = 0;
                    info.SetCreate(client.i_id);

                    #region 上传图片
                    await db.Deleteable<SysFileRecord>().Where(x => x.object_id == info.id).ExecuteCommandAsync();
                    var file_list = new List<SysFileRecord>();
                    if (input.form_data.files != null && input.form_data.files.Count > 0)
                    {
                        input.form_data.files.ForEach(x => {
                            var file = new SysFileRecord()
                            {
                                model = (int)FileRecordType.TRIPRECORD,
                                object_id = info.id,
                                type = 1,
                                url = x,
                                created_id = client.i_id,
                                created_date = DateTime.Now
                            };
                            file_list.Add(file);
                        });

                        await db.Insertable(file_list).ExecuteCommandAsync();
                    }
                    #endregion

                    await db.Insertable(info).ExecuteCommandAsync();

                    return _imapper.Map<OaTripRecord, OaTripRecordDto>(info);
                }
            }
        }

        /// <summary>
        /// 计算出差时长(单位：天)
        /// </summary>
        public async Task<RecordTimeDetail> GetTripDays(GetTimeRequest request)
        {
            if (request.start_time == 1)
            {
                request.start_date = request.start_date.Date;
            }
            if (request.start_time == 2)
            {
                request.start_date = request.start_date.Date.AddHours(12);
            }
            if (request.end_time == 1)
            {
                request.end_date = request.end_date.Date.AddHours(12);
            }
            if (request.end_time == 2)
            {
                request.end_date = request.end_date.Date.AddHours(24);
            }

            return await GetDays(request.server_id, request.user_id, request.start_date, request.end_date);
        }

        /// <summary>
        /// 根据时间段计算天数
        /// </summary>
        /// <returns></returns>
        public async Task<RecordTimeDetail> GetDays(string server_id, int user_id, DateTime start, DateTime end)
        {
            var details = new List<DayDetails>();
            double total_time = 0;
            if (start.Date == end.Date)//日期相同
            {
                var kqbc = await _iOaKqzImp.GetKqbcAsync(server_id, user_id, start.Date);
                if (kqbc == null)
                {
                    kqbc = await _iOaKqzImp.GetDefaultKqbcAsync(server_id, start.Date);
                }
                if (kqbc != null && kqbc.Count > 0)
                {
                    total_time += end.Hour - start.Hour;

                    details.Add(new DayDetails() {
                        day = start.Date,
                        day_duration = (double)(end.Hour - start.Hour) / 24
                    });
                }
            }
            else//跨天
            {
                //第一天
                var kqbc = await _iOaKqzImp.GetKqbcAsync(server_id, user_id, start.Date);
                if (kqbc == null)
                {
                    kqbc = await _iOaKqzImp.GetDefaultKqbcAsync(server_id, start.Date);
                }
                if (kqbc != null && kqbc.Count > 0)
                {
                    total_time += 24 - start.Hour;

                    details.Add(new DayDetails()
                    {
                        day = start.Date,
                        day_duration = (double)(24 - start.Hour) / 24
                    });
                }

                for (DateTime i = start.Date.AddDays(1); i <= end.Date; i = i.AddDays(1))
                {
                    kqbc = await _iOaKqzImp.GetKqbcAsync(server_id, user_id, i.Date);
                    if (kqbc == null)
                    {
                        kqbc = await _iOaKqzImp.GetDefaultKqbcAsync(server_id, i.Date);
                    }
                    if (kqbc != null && kqbc.Count > 0)
                    {
                        if (i.Date == end.Date) //最后一天
                        {
                            if (end.Hour != 0)
                            {
                                total_time += end.Hour;

                                details.Add(new DayDetails()
                                {
                                    day = i.Date,
                                    day_duration = (double)end.Hour / 24
                                });
                            }
                        }
                        else
                        {
                            total_time += 24;

                            details.Add(new DayDetails()
                            {
                                day = i.Date,
                                day_duration = 1
                            });
                        }
                    }
                }
            }
            return new RecordTimeDetail()
            {
                total_duration = total_time / 24,
                str_total_duration = $"{total_time / 24}天",
                day_details = details
            };
        } 
    }
}
