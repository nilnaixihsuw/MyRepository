﻿using AutoMapper;
using DotNetCore.CAP;
using ERPBll.ApprovalForm.Contracts;
using ERPBll.Caps;
using ERPBll.FlowManage.Contracts;
using ERPBll.OAManage;
using ERPCore.Entity;
using ERPCore.Enums;
using ERPDal;
using ERPModel.ApprovalForm;
using ERPModel.FlowManage;
using ERPModel.FlowManage.FlowRecords;
using ERPModel.Oamanage.OaKqbcs;
using ERPModel.Oamanage.OaKqzs;
using ERPModel.PersonalManage.AttentSetting;
using ERPModel.SystemManage;
using ERPModel.UserManage;
using SqlSugar;
using SqlSugar.DistributedSystem.Snowflake;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.ApprovalForm.Services
{
    public class OaWorkOvertimeImp : IOaWorkOvertimeImp
    {
        private readonly IMapper _imapper;
        private readonly IErpFlowRecordImp _iErpFlowRecordImp;
        private readonly IErpFlowRecordImp _erpFlowRecordImp;

        public OaWorkOvertimeImp(
            IMapper imapper,
            IErpFlowRecordImp iErpFlowRecordImp,
            IErpFlowRecordImp erpFlowRecordImp)
        {
            _imapper = imapper;
            _iErpFlowRecordImp = iErpFlowRecordImp;
            _erpFlowRecordImp = erpFlowRecordImp;
        }

        /// <summary>
        /// 查询
        /// </summary>
        public async Task<List<OaWorkOvertimeDto>> GetListAsync(
            string server_id, decimal? user_id, OaWorkOvertimeQuery query)
        {
            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<OaWorkOvertime>()
                                .Where(query.ToExp())
                                .Mapper(x => x.user_info, x => x.user_id)
                                .Mapper(x => x.created_info, x => x.created_id)
                                .ToListAsync();
            if (list.Count > 0)
            {
                var all = await _iErpFlowRecordImp.GetListAsync(server_id, user_id,
                new FlowRecordQuery()
                {
                    detail_ids = list.Select(x => (int)x.id).ToList()
                });
                foreach (var item in list)
                {
                    if (item.state == 1)//审核中
                    {
                        var info = all.FirstOrDefault(x => x.detail_id == item.id);
                        if (info != null)
                        {
                            item.user_ids = info.state_child_id;
                            item.user_names = info.state_child_name;
                        }
                    }
                }
            }

            var data = _imapper.Map<List<OaWorkOvertime>, List<OaWorkOvertimeDto>>(list);

            return data;
        }

        /// <summary>
        /// 获取加班申请详情
        /// </summary>
        public async Task<OaWorkOvertimeDto> LookDetailAsync(
            string server_id, decimal? user_id, decimal id)
        {

            //查询
            var info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<OaWorkOvertime>()
                                .Where(x => x.id == id)
                                .Mapper(x => x.created_info, x => x.created_id)
                                .Mapper(x => x.flow_record, x => x.flow_id)
                                .Mapper(x =>
                                {
                                    x.user_info = SqlSugarHelper.DBClient(server_id)
                                                    .Queryable<SysPerson>()
                                                    .Where(y => y.i_id == x.user_id)
                                                    .First();
                                    if (x.user_info != null)
                                    {
                                        x.user_dep_info = SqlSugarHelper.DBClient(server_id)
                                                    .Queryable<SysDepartment>()
                                                    .Where(y => y.i_id == x.user_info.i_department_base)
                                                    .First();
                                    }
                                    x.file_list = SqlSugarHelper.DBClient(server_id)
                                                    .Queryable<SysFileRecord>()
                                                    .Where(y => y.object_id == x.id)
                                                    .ToList();
                                    if (x.file_list.Count > 0)
                                    {
                                        x.files = x.file_list.Select(y => y.url).ToList();
                                    }
                                })
                                .FirstAsync();

            var ids = new List<int>();
            ids.Add(Convert.ToInt32(info.id));

            var all = await _iErpFlowRecordImp.GetListAsync(server_id, user_id,
                new FlowRecordQuery()
                {
                    detail_ids = ids
                });

            if (info.state == 1)//审核中
            {
                var flow_info = all.FirstOrDefault(x => x.detail_id == info.id);
                if (flow_info != null)
                {
                    info.user_ids = flow_info.state_child_id;
                    info.user_names = flow_info.state_child_name;
                }
            }
            var data = _imapper.Map<OaWorkOvertime, OaWorkOvertimeDto>(info);

            return data;
        }

        /// <summary>
        /// 获取自己保存的草稿
        /// </summary>
        public async Task<OaWorkOvertimeDto> GetByUserAsync(
            string server_id, decimal? user_id)
        {

            //查询
            var info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<OaWorkOvertime>()
                                .Mapper(x => x.user_info, x => x.user_id)
                                .Where(x => x.created_id == user_id && x.state == 0)
                                .FirstAsync();

            var data = _imapper.Map<OaWorkOvertime, OaWorkOvertimeDto>(info);

            return data;
        }

        /// <summary>
        /// 新增
        /// </summary>
        public async Task<OaWorkOvertimeDto> CreateOrUpdateAsync(
            string server_id, ClientInformation client, WorkOvertimeFormData input)
        {
            if (input.step_data == null || input.step_data.Count < 1)
            {
                throw new Exception("审批流程数据为空");
            }
            input.step_data.Where(x => x.oper_type == 1).ToList().ForEach(x =>
            {
                if (x.users.Count < 1)
                {
                    throw new Exception("审批节点人员不能为空");
                }
                if (x.users.Count > 15)
                {
                    throw new Exception("审批节点人员最多15人");
                }
            });

            using (var db = SqlSugarHelper.DBClient(server_id))
            {
                var list = await db.Queryable<OaWorkOvertime>()
                                   .Where(x => x.user_id == input.form_data.user_id && (x.state == 1 || x.state == 2))
                                   .WhereIF(input.form_data.start_time.HasValue && input.form_data.end_time.HasValue, r =>
                                    (input.form_data.start_time <= r.start_time && input.form_data.end_time >= r.start_time) ||
                                    (input.form_data.start_time >= r.start_time && input.form_data.end_time <= r.end_time) ||
                                    (input.form_data.start_time <= r.end_time && input.form_data.end_time >= r.end_time))
                                   .ToListAsync();

                if (list != null && list.Count > 0)
                {
                    throw new Exception("当前时间段已有加班记录");
                }
                var rule = await db.Queryable<OaJbgz, OaKqz, OaKqzUser>((a, b, c) => new JoinQueryInfos(JoinType.Left, a.id == b.overtime_id,
                        JoinType.Left, b.id == c.kqz_id))
                     .Where((a, b, c) => c.user_id == input.form_data.user_id).FirstAsync();
                var records = await db.Queryable<OaWorkOvertime>()
                    .Where(r => SqlFunc.Oracle_ToChar(r.start_time, "yyyy-MM") == SqlFunc.Oracle_ToChar(input.form_data.start_time.Value, "yyyy-MM") && r.state == 2)
                    .ToListAsync();
                if (rule?.max_fee > 0 && rule?.max_fee <= records.Sum(r => r.fee) + input.form_data.fee)
                {
                    throw new Exception("超过管理员设置上限");
                }

                var info = _imapper.Map<CreateOrUpdateOaWorkOvertime, OaWorkOvertime>(input.form_data);
                info.id = Tools.GetEngineID(server_id);
                if (info.fee == null || info.fee == 0)
                {
                    info.fee = Math.Round(Convert.ToDecimal(info.standard) *
                        Convert.ToDecimal(info.end_time.Subtract(info.start_time).TotalHours), 2);
                }
                info.SetCreate(client.i_id);

                //发起流程
                var flow = await _erpFlowRecordImp.StartAsync(server_id, client.i_id, input.step_data);
                if (flow == null)
                {
                    throw new Exception("发起加班流程失败");
                }
                await _erpFlowRecordImp.UpdateAsync(server_id, flow.id, Convert.ToInt32(info.id),
                        WorkOvertimeMessage.GetContent(client.c_name, info), "", db);
                info.flow_id = flow.id;
                info.flow_code = flow.code;
                info.state = 1;

                var file_list = new List<SysFileRecord>();
                if (input.form_data.files != null && input.form_data.files.Count > 0)
                {
                    input.form_data.files.ForEach(x => {
                        var file = new SysFileRecord()
                        {
                            model = (int)FileRecordType.OAWORKOVERTIME,
                            object_id = info.id,
                            type = 1,
                            url = x,
                            created_id = client.i_id,
                            created_date = DateTime.Now
                        };
                        file_list.Add(file);
                    });

                    await db.Insertable(file_list).ExecuteCommandAsync();
                }

                await db.Insertable(info).ExecuteCommandAsync();

                return _imapper.Map<OaWorkOvertime, OaWorkOvertimeDto>(info);
            }
        }

        /// <summary>
        /// 提交
        /// </summary>
        public async Task<OaWorkOvertimeDto> SubmitAsync(string server_id, UpdateOaWorkOvertimeState input)
        {
            var info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<OaWorkOvertime>()
                                .FirstAsync(x => x.id == input.id);

            if (info == null)
            {
                throw new Exception($"未找到申请记录，id={input.id}");
            }

            if (info.state != 1)
            {
                throw new Exception($"状态错误，只允许草稿状态提交");
            }

            if (string.IsNullOrWhiteSpace(input.flow_code) || input.flow_id == 0)
            {
                throw new Exception($"流程id和流程编号不能为空");
            }

            info.flow_id = input.flow_id;
            info.flow_code = input.flow_code;
            info.state = 2;

            await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync();

            await _iErpFlowRecordImp.UpdateAsync(server_id, Convert.ToInt32(info.flow_id), Convert.ToInt32(info.id), "");

            return _imapper.Map<OaWorkOvertime, OaWorkOvertimeDto>(info);
        }

        [CapSubscribe(EventMessages.WorkOvertimeFinish, Group = "OaWorkOvertime")]
        public async Task UpdateStateAsync(UpdateErpFlowRecordState input)
        {
            var info = await SqlSugarHelper.DBClient("60.191.59.11")
                                .Queryable<OaWorkOvertime>()
                                .FirstAsync(x => x.flow_id == input.flow_id);
            if (info != null)
            {

                Console.WriteLine("加班申请通过");

                if (input.state == FlowRecordState.审核通过)
                {
                    info.state = 3;
                }
                else if (input.state == FlowRecordState.审核拒绝)
                {
                    info.state = 4;
                }
                else if (input.state == FlowRecordState.已撤销)
                {
                    info.state = 5;
                }

                await SqlSugarHelper.DBClient("60.191.59.11").Updateable(info).ExecuteCommandAsync();
            }
        }

        public async Task<WorkOvertimeCount> GetTimesCount(decimal user_id, DateTime start, DateTime end, string server_id)
        {
            var records = await SqlSugarHelper.DBClient(server_id).Queryable<OaWorkOvertime>()
                .Where(r => r.state == 2)
                .Where(r => r.user_id == user_id)
                .Where(r => r.start_time >= start && r.end_time <= end).ToListAsync();

            var result = new WorkOvertimeCount();
            result.work_hours = records.Where(r => r.type == 3).Sum(r => r.hour);
            result.work_fee = records.Where(r => r.type == 3).Sum(r => r.fee);
            result.holiday_hours = records.Where(r => r.type == 1).Sum(r => r.hour);
            result.holiday_fee = records.Where(r => r.type == 1).Sum(r => r.fee);
            result.rest_hours = records.Where(r => r.type == 2).Sum(r => r.hour);
            result.rest_fee = records.Where(r => r.type == 2).Sum(r => r.fee);

            return result;
        }

        public async Task<OvertimeDoc> GetTimesData(decimal user_id, int type, DateTime start, DateTime end, string server_id)
        {
            var DB = SqlSugarHelper.DBClient(server_id);
            var kqz = await DB.Queryable<OaKqz, OaKqzUser>((a, b) => new JoinQueryInfos(JoinType.Left, a.id == b.kqz_id))
                .Where((a, b) => b.user_id == user_id && a.is_delete == 0).FirstAsync();
            var result = new OvertimeDoc();
            var records = await DB.Queryable<OaWorkOvertime>()
                .Where(r => r.user_id == user_id)
                .Where(r => SqlFunc.Oracle_ToChar(r.start_time, "yyyy-MM") == SqlFunc.Oracle_ToChar(start, "yyyy-MM") && r.state == 2)
                .ToListAsync();
            result.total_work_fee = Math.Round(Convert.ToDouble(records.Sum(r => r.fee)), 2);

            if (kqz != null)
            {
                var jb_type = await SqlSugarHelper.DBClient(server_id).Queryable<OaJbgzType>()
                    .Includes(r => r.fees)
                    .Where(r => r.main_id == kqz.overtime_id)
                    .Where(r => r.type == type)
                    .FirstAsync();
                if (jb_type != null)
                {
                    result.work_hours = Math.Round((end - start).TotalHours, 2);
                    var max_fee = jb_type.fees.Find(r => r.max == -1);
                    if (max_fee != null && max_fee.min <= result.work_hours)
                    {
                        result.work_fee = max_fee.value;
                    }
                    else
                    {
                        var fee = jb_type.fees.Find(r => r.min <= result.work_hours && r.max > result.work_hours);
                        if (fee != null)
                        {
                            result.work_fee = Math.Round(Convert.ToDouble(fee.value * result.work_hours), 2);
                        }
                    }
                }
            }
            return result;
        }
    }
}
