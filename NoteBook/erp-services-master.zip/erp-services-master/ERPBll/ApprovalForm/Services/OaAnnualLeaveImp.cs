﻿using AutoMapper;
using DotNetCore.CAP;
using ERPBll.ApprovalForm.Contracts;
using ERPBll.Caps;
using ERPBll.FlowManage.Contracts;
using ERPDal;
using ERPModel.ApprovalForm;
using ERPModel.FlowManage;
using ERPModel.FlowManage.FlowRecords;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.ApprovalForm.Services
{
    public class OaAnnualLeaveImp : IOaAnnualLeaveImp
    {
        private readonly IMapper _imapper;
        private readonly IOaAnnualLeaveFileImp _iOaAnnualLeaveFileImp;
        private readonly IErpFlowRecordImp _iErpFlowRecordImp;

        public OaAnnualLeaveImp(
            IMapper imapper,
            IOaAnnualLeaveFileImp iOaAnnualLeaveFileImp,
            IErpFlowRecordImp iErpFlowRecordImp)
        {
            _imapper = imapper;
            _iOaAnnualLeaveFileImp = iOaAnnualLeaveFileImp;
            _iErpFlowRecordImp = iErpFlowRecordImp;
        }

        /// <summary>
        /// 查询
        /// </summary>
        public async Task<List<OaAnnualLeaveDto>> GetListAsync(
            string server_id, decimal? user_id, OaAnnualLeaveQuery query)
        {
            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<OaAnnualLeave>()
                                .Where(query.ToExp())
                                .Mapper(x => x.user_info, x => x.user_id)
                                .Mapper(x => x.created_info, x => x.created_id)
                                .Mapper(async x =>
                                {
                                    x.files = await _iOaAnnualLeaveFileImp.GetListAsync(server_id, x.id);
                                })
                                .ToListAsync();
            if (list.Count > 0)
            {
                var all = await _iErpFlowRecordImp.GetListAsync(server_id, user_id,
                new FlowRecordQuery()
                {
                    detail_ids = list.Select(x => (int)x.id).ToList()
                });
                foreach (var item in list)
                {
                    if (item.state == 2)//审核中
                    {
                        var info = all.FirstOrDefault(x => x.detail_id == item.id);
                        if (info != null)
                        {
                            item.user_ids = info.state_child_id;
                            item.user_names = info.state_child_name;
                        }
                    }
                }
            }

            var data = _imapper.Map<List<OaAnnualLeave>, List<OaAnnualLeaveDto>>(list);

            return data;
        }

        /// <summary>
        /// 获取年休申请详情
        /// </summary>
        public async Task<OaAnnualLeaveDto> LookDetailAsync(
            string server_id, decimal? user_id, decimal id)
        {

            //查询
            var info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<OaAnnualLeave>()
                                .Where(x => x.id == id)
                                .Mapper(x => x.user_info, x => x.user_id)
                                .Mapper(x => x.created_info, x => x.created_id)
                                .Mapper(async x =>
                                {
                                    x.files = await _iOaAnnualLeaveFileImp.GetListAsync(server_id, x.id);
                                })
                                .FirstAsync();

            var ids = new List<int>();
            ids.Add(Convert.ToInt32(info.id));

            var all = await _iErpFlowRecordImp.GetListAsync(server_id, user_id,
                new FlowRecordQuery()
                {
                    detail_ids = ids
                });

            if (info.state == 2)//审核中
            {
                var flow_info = all.FirstOrDefault(x => x.detail_id == info.id);
                if (flow_info != null)
                {
                    info.user_ids = flow_info.state_child_id;
                    info.user_names = flow_info.state_child_name;
                }
            }
            var data = _imapper.Map<OaAnnualLeave, OaAnnualLeaveDto>(info);

            return data;
        }

        /// <summary>
        /// 获取自己保存的草稿
        /// </summary>
        public async Task<OaAnnualLeaveDto> GetByUserAsync(
            string server_id, decimal? user_id)
        {

            //查询
            var info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<OaAnnualLeave>()
                                .Mapper(x => x.user_info, x => x.user_id)
                                .Where(x => x.created_id == user_id && x.state == 1)
                                .Mapper(async x =>
                                {
                                    x.files = await _iOaAnnualLeaveFileImp.GetListAsync(server_id, x.id);
                                })
                                .FirstAsync();

            var data = _imapper.Map<OaAnnualLeave, OaAnnualLeaveDto>(info);

            return data;
        }

        /// <summary>
        /// 新增/编辑草稿
        /// </summary>
        public async Task<OaAnnualLeaveDto> CreateOrUpdateAsync(
            string server_id, decimal? user_id, CreateOrUpdateOaAnnualLeave input)
        {
            var info = new OaAnnualLeave();
            if (input.id.HasValue && input.id != 0)
            {
                info = await SqlSugarHelper.DBClient(server_id)
                       .Queryable<OaAnnualLeave>()
                       .FirstAsync(x => x.id == input.id);
                if (info == null)
                {
                    throw new Exception($"未找到年休申请信息，id={input.id}");
                }

                _imapper.Map<CreateOrUpdateOaAnnualLeave, OaAnnualLeave>(input, info);

                info.SetUpdate(user_id);

                await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync();

            }
            else
            {
                info = _imapper.Map<CreateOrUpdateOaAnnualLeave, OaAnnualLeave>(input);
                info.id = ERPBll.Tools.GetEngineID(server_id);
                info.SetCreate(user_id);

                await SqlSugarHelper.DBClient(server_id).Insertable(info).ExecuteCommandAsync();

            }

            //上传附件
            if (input.files != null && input.files.Count > 0)
            {
                input.files.ForEach(r =>
                {
                    r.id = ERPBll.Tools.GetEngineID(server_id);
                    r.SetCreate(user_id, info.id);
                });
                await _iOaAnnualLeaveFileImp.CreateAsync(server_id, input.files);
            }

            return _imapper.Map<OaAnnualLeave, OaAnnualLeaveDto>(info);
        }

        /// <summary>
        /// 提交
        /// </summary>
        public async Task<OaAnnualLeaveDto> SubmitAsync(string server_id, UpdateOaAnnualLeaveState input)
        {
            var info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<OaAnnualLeave>()
                                .FirstAsync(x => x.id == input.id);

            if (info == null)
            {
                throw new Exception($"未找到申请记录，id={input.id}");
            }

            if (info.state != 1)
            {
                throw new Exception($"状态错误，只允许草稿状态提交");
            }

            if (string.IsNullOrWhiteSpace(input.flow_code) || input.flow_id == 0)
            {
                throw new Exception($"流程id和流程编号不能为空");
            }

            info.flow_id = input.flow_id;
            info.flow_code = input.flow_code;
            info.state = 2;

            await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync();

            await _iErpFlowRecordImp.UpdateAsync(server_id, Convert.ToInt32(info.flow_id), Convert.ToInt32(info.id), "");

            return _imapper.Map<OaAnnualLeave, OaAnnualLeaveDto>(info);
        }
    }
}
