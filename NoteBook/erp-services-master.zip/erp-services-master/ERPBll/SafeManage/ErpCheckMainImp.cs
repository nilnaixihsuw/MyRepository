﻿using ERPCore.ORM;
using ERPDal.SafeManage;
using ERPModel.SafeManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;

namespace ERPBll.SafeManage
{
    public class ErpCheckMainImp : BusinessRespository<ErpCheckMain, IErpCheckMainDataImp>, IBusinessRepository<ErpCheckMain>, IErpCheckMainImp
    {
        public ErpCheckMainImp(IErpCheckMainDataImp dataImp): base(dataImp)
        {

        }

        //protected override Func<string,List<ERP_CHECK_MAIN>, List<ERP_CHECK_MAIN>> _fieldsExtension => (serverId,list) => list;
    }
}