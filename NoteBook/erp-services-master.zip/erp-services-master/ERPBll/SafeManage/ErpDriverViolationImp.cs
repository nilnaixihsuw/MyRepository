﻿using ERPCore.ORM;
using ERPDal.SafeManage;
using ERPModel.SafeManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using ERPBll.UserManage;
using ERPDal;
using ERPModel.UserManage;
using ERPModel.DataBase;
using ERPModel.Vehicleinfomanage;
using ERPBll.RedisManage.Lines;
using ERPBll.FlowManage.Contracts;
using ERPModel.FlowManage.FlowRecords;
using ERPModel.SystemManage;
using ERPCore.Enums;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;
using NPOI.HSSF.UserModel;
using NPOI.HSSF.Util;
using NPOI.SS.UserModel;
using NPOI.SS.Util;
using System.IO;
using System.Text.RegularExpressions;
using ERPModel.ApiModel.ServiceManage;
using Quartz.Util;
using System.Net;

namespace ERPBll.SafeManage
{
    public class ErpDriverViolationImp : BusinessRespository<ErpDriverViolation, IErpDriverViolationDataImp>, IErpDriverViolationImp
    {
        private readonly ISysDepartmentImp _sysDepartmentImp;
        private readonly ILineRedisImp _iLineRedisImp;
        private readonly IErpFlowRecordImp _iErpFlowRecordImp;
        public ErpDriverViolationImp(ISysDepartmentImp sysDepartmentImp,
            ILineRedisImp iLineRedisImp,
            IErpDriverViolationDataImp dataImp,
            IErpFlowRecordImp iErpFlowRecordImp) : base(dataImp)
        {
            _sysDepartmentImp = sysDepartmentImp;
            _iLineRedisImp = iLineRedisImp;
            _iErpFlowRecordImp = iErpFlowRecordImp;
        }

        /// <summary>
        /// 连表获取违规记录
        /// </summary>
        /// <param name="serverID"></param>
        /// <param name="query">查询条件</param>
        /// <returns></returns>
        public async Task<Tuple<int, List<DriverVioRecord>>> GetRecord(DriverVioQuery query, decimal user_id)
        {
            RefAsync<int> total = 0;
            var depts = await _sysDepartmentImp.List(query.server_id, null);
            var dic = await SqlSugarHelper.DBClient(query.server_id).Queryable<SysCommonDictDetail>().ToListAsync();

            var list = await SqlSugarHelper.DBClient(query.server_id)
                .Queryable<ErpDriverViolation, ErpVehicleInfo, ErpCheckItem, SysPerson, SysDepartment>((a, b, c, d, e) =>
                    new JoinQueryInfos(
                        JoinType.Left, a.i_vehicle_id == b.i_id,
                        JoinType.Left, a.i_check_id == c.i_id,
                        JoinType.Left, a.i_driver_id == d.i_id,
                        JoinType.Left, e.i_id == a.i_department_id))
                .WhereIF(query.group_id != null, (a, b, c, d) => query.group_id.Contains((decimal)d.i_department_base))
                .Where(query.ToExp())
                .Select((a, b, c, d, e) => new DriverVioRecord
                {
                    i_id = a.i_id.Value,
                    i_vehicle_id = b.i_id.Value,
                    v_num = b.c_vehicle_number,
                    lp_num = b.c_lincense_plate_number,
                    group = string.IsNullOrEmpty(b.c_crews_take) ? 0 : Convert.ToInt32(b.c_crews_take),
                    i_line_id = a.i_line_id,
                    d_violation_date = a.d_violation_date.Value,
                    i_driver_id = a.i_driver_id,
                    driver_name = d.c_name,
                    c_source = string.IsNullOrEmpty(a.c_source) ? 0 : Convert.ToInt32(a.c_source),
                    i_department_id = a.i_department_id,
                    department = e.c_name,
                    c_violation_item = string.IsNullOrEmpty(a.c_violation_item) ? 0 : Convert.ToInt32(a.c_violation_item),
                    i_check_id = a.i_check_id,
                    check_item = c.c_name,
                    check_amount = a.check_amount,
                    check_core = a.check_core,
                    c_remark = a.c_remark,
                    flow_id = a.flow_id,
                    state = a.state,
                    service_code = a.service_code,
                    cancel_star = a.cancel_star
                })
                .OrderBy(a => a.d_violation_date, OrderByType.Desc)
                .ToPageListAsync(query.page_index, query.page_size, total);

            var lin_veh = await _iLineRedisImp.GetLineVehAsync();
            if (list.Count > 0)
            {
                var all = await _iErpFlowRecordImp.GetListAsync(query.server_id, null, new FlowRecordQuery()
                {
                    detail_ids = list.Select(x => (int)x.i_id).ToList()
                });
                var files = await SqlSugarHelper.DBClient(query.server_id).Queryable<SysFileRecord>().ToListAsync();
                list.ForEach(r =>
                {
                    r.group_name = r.group == 0 ? "" : depts.Find(m => m.i_id == r.group)?.c_name;
                    // r.department = r.i_department_id == null ? "" : depts.Where(m => m.i_id.ToString() == r.department).FirstOrDefault()?.c_name;
                    r.source_name = r.c_source == 0 ? "" : dic.Find(m => m.i_id == r.c_source)?.c_name;
                    r.violation_item_name = r.c_violation_item == 0 ? "" : dic.Find(m => m.i_id == r.c_violation_item)?.c_name;
                    r.line_name = lin_veh.Find(m => m.line_id == r.i_line_id)?.line_name;
                    r.files = files.Where(m => m.model == (int)FileRecordType.DriverViolation && m.object_id == r.i_id && m.type == 2)
                        .Select(r => new file_dto { file_name = r.file_name, url = r.url }).ToList();
                    r.images = files.Where(m => m.model == (int)FileRecordType.DriverViolation && m.object_id == r.i_id && m.type == 1)
                        .Select(r => new file_dto { file_name = r.file_name, url = r.url }).ToList();
                    if (r.state == 2)//处理中
                    {
                        var info = all.FirstOrDefault(x => x.detail_id == r.i_id);
                        if (info != null)
                        {
                            r.flow_code = info.code;
                            r.user_ids = info.state_child_id;
                            r.user_names = info.state_child_name;
                            r.created_id = info.created_id;
                        }
                    }
                });
            }

            return new Tuple<int, List<DriverVioRecord>>(total, list);
        }

        public Stream Export(string fileName, Dictionary<string, string> title, List<DriverVioRecord> list, string excel_name = "") 
        {
            HSSFWorkbook hssfworkbook = new HSSFWorkbook();
            ISheet sheet1 = hssfworkbook.CreateSheet(fileName);

            IFont font = hssfworkbook.CreateFont();
            font.IsBold = true;
            font.FontHeightInPoints = 11;

            //设置单元格的样式：水平垂直对齐居中
            ICellStyle cellStyle = hssfworkbook.CreateCellStyle();
            cellStyle.Alignment = HorizontalAlignment.Center;
            cellStyle.VerticalAlignment = VerticalAlignment.Center;
            cellStyle.BorderBottom = BorderStyle.Thin;
            cellStyle.BorderLeft = BorderStyle.Thin;
            cellStyle.BorderRight = BorderStyle.Thin;
            cellStyle.BorderTop = BorderStyle.Thin;
            cellStyle.BottomBorderColor = HSSFColor.Black.Index;
            cellStyle.LeftBorderColor = HSSFColor.Black.Index;
            cellStyle.RightBorderColor = HSSFColor.Black.Index;
            cellStyle.TopBorderColor = HSSFColor.Black.Index;

            cellStyle.WrapText = true;//自动换行

            //设置表头的样式：水平垂直对齐居中，加粗
            ICellStyle titleCellStyle = hssfworkbook.CreateCellStyle();
            titleCellStyle.Alignment = HorizontalAlignment.Center;
            titleCellStyle.VerticalAlignment = VerticalAlignment.Center;
            titleCellStyle.FillForegroundColor = NPOI.HSSF.Util.HSSFColor.Grey25Percent.Index; //图案颜色
            titleCellStyle.FillPattern = FillPattern.SparseDots; //图案样式
            titleCellStyle.FillBackgroundColor = NPOI.HSSF.Util.HSSFColor.Grey25Percent.Index; //背景颜色
            //设置边框
            titleCellStyle.BorderBottom = BorderStyle.Thin;
            titleCellStyle.BorderLeft = BorderStyle.Thin;
            titleCellStyle.BorderRight = BorderStyle.Thin;
            titleCellStyle.BorderTop = BorderStyle.Thin;
            titleCellStyle.BottomBorderColor = HSSFColor.Black.Index;
            titleCellStyle.LeftBorderColor = HSSFColor.Black.Index;
            titleCellStyle.RightBorderColor = HSSFColor.Black.Index;
            titleCellStyle.TopBorderColor = HSSFColor.Black.Index;
            //设置字体
            titleCellStyle.SetFont(font);

            IRow rowHeader = sheet1.CreateRow(0);

            //生成excel标题
            var index = 0;

            //foreach (var p in title)
            //{
            //    rowHeader.CreateCell(index).SetCellValue(p.Value);
            //    index++;
            //}

            if (!string.IsNullOrWhiteSpace(excel_name))
            {
                //标题
                IRow titleRow = sheet1.CreateRow(index++);
                titleRow.HeightInPoints = 25;
                _ = sheet1.AddMergedRegion(new CellRangeAddress(0, 0, 0, title.Values.Count - 1));
                //标题样式
                ICellStyle styletitle = hssfworkbook.CreateCellStyle();
                //设置单元格的样式：水平对齐居中
                styletitle.Alignment = HorizontalAlignment.Center;
                styletitle.VerticalAlignment = VerticalAlignment.Center;

                //新建一个字体样式对象
                IFont fonttitle = hssfworkbook.CreateFont();
                fonttitle.FontHeight = 15 * 15;
                styletitle.SetFont(fonttitle);
                titleRow.CreateCell(0).SetCellValue(excel_name);
                titleRow.GetCell(0).CellStyle = styletitle;
            }

            IRow headRow = sheet1.CreateRow(index++);
            headRow.HeightInPoints = 25;
            var arrHead = title.Values.ToList();
            for (int i = 0; i < arrHead.Count; i++)
            {
                string value = arrHead[i].ToString();
                int len = value.Length > 20 ? 20 : value.Length;
                if (ContainChinese(value))
                {
                    if (len * 1024 > sheet1.GetColumnWidth(i))
                    {
                        sheet1.SetColumnWidth(i, len * 1024);
                    }
                }
                else
                {
                    if (len * 512 > sheet1.GetColumnWidth(i))
                    {
                        sheet1.SetColumnWidth(i, len * 512);
                    }
                }
                headRow.CreateCell(i).SetCellValue(arrHead[i]);
                headRow.GetCell(i).CellStyle = titleCellStyle;
            }

            for (int i = 0; i < list.Count; i++)
            {
                IRow row = sheet1.CreateRow(i + index);
                row.HeightInPoints = 50;
                //循环列赋值
                int j = 0;
                foreach (var p in title)
                {
                    //var value = list[i].GetType().GetProperty(p.Key).GetValue(list[i], null).ToString();
                    string value = string.Empty;

                    if (p.Key == "images")
                    {
                        var images = list[i].images;
                        if (images != null && images.Count > 0)
                        {
                            sheet1.SetColumnWidth(j, 20 * 256);
                            int index1 = 1;
                            foreach (var item in images)
                            {
                                AddPieChart(sheet1, hssfworkbook, item.url, i + index, j, index1);
                                index1++;
                            }
                            //row.GetCell(j).CellStyle = cellStyle;
                        }
                        else
                        {
                            row.CreateCell(j).SetCellValue("暂无图片");
                            row.GetCell(j).CellStyle = cellStyle;
                        }   
                    }
                    else
                    {
                        var propertys = list[i].GetType().GetProperty(p.Key);
                        var obj = list[i].GetType().GetProperty(p.Key).GetValue(list[i]);
                        var type = list[i].GetType().GetProperty(p.Key).PropertyType;
                        if (typeof(DateTime?) == type)
                        {
                            value = obj == null ? "" : Convert.ToDateTime(obj).ToString("yyyy-MM-dd HH:mm:ss");
                        }
                        else
                        {
                            value = obj == null ? "" : obj.ToString();
                        }

                        if (value.Length > 255)
                        {
                            sheet1.SetColumnWidth(j, 255 * 256);
                        }
                        else
                        {
                            if (ContainChinese(value))
                            {
                                var l = sheet1.GetColumnWidth(j);
                                if (value.Length * 700 > sheet1.GetColumnWidth(j))
                                {
                                    sheet1.SetColumnWidth(j, value.Length * 700 > 255 * 256 ? 255 * 256 : value.Length * 700);
                                }
                            }
                            else
                            {
                                if (value.Length * 400 > sheet1.GetColumnWidth(j))
                                {
                                    sheet1.SetColumnWidth(j, value.Length * 400 > 255 * 256 ? 255 * 256 : value.Length * 400);
                                }
                            }
                        }
                        row.CreateCell(j).SetCellValue(value);
                        row.GetCell(j).CellStyle = cellStyle;
                    }
                    j++;
                }
            };

            MemoryStream file = new MemoryStream();
            hssfworkbook.Write(file);
            file.Seek(0, SeekOrigin.Begin);
            return file;
        }

        private void AddPieChart(ISheet sheet, IWorkbook workbook, string fileurl, int row, int col,int num)
        {
            try
            {
                if (!string.IsNullOrEmpty(fileurl))
                {
                    HttpWebRequest request = (HttpWebRequest)WebRequest.Create(fileurl);
                    request.Timeout = 5000; //请求超时时间
                    request.Method = "GET";
                    HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                    if (response.StatusCode != HttpStatusCode.OK)
                    {
                        return;
                    }
                    Stream s = response.GetResponseStream();
                    int len = 1024;
                    byte[] bytes = new byte[len];
                    MemoryStream ms = new MemoryStream();
                    int count = 0;
                    while ((count = s.Read(bytes, 0, len)) > 0)
                    {
                        ms.Write(bytes, 0, count);
                    }
                    //s.Seek(0, SeekOrigin.Begin);
                    var buffer = ms.ToArray();
                    //s.Read(buffer, 0, buffer.Length);

                    int pictureIdx = workbook.AddPicture(buffer, NPOI.SS.UserModel.PictureType.JPEG);
                    HSSFPatriarch patriarch = (HSSFPatriarch)sheet.CreateDrawingPatriarch();
                    //patriarch.set
                    HSSFClientAnchor anchor = new HSSFClientAnchor(0, 0, 0  , 0, col, row, col + 1, row + 1);
                    //##处理照片位置，【图片左上角为（col, row）第row+1行col+1列，右下角为（ col +1, row +1）第 col +1+1行row +1+1列，宽为100，高为50
                    HSSFPicture pict = (HSSFPicture)patriarch.CreatePicture(anchor, pictureIdx);
                    //pict.Resize(8,8); //这句话一定不要，这是用图片原始大小来显示

                    ms.Close();
                    response.Close();
                }
                //}

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }
        private bool ContainChinese(string input)
        {
            string pattern = "[\u4e00-\u9fbb]";
            return Regex.IsMatch(input, pattern);
        }
    }
}