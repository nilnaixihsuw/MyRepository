﻿using ERPCore.ORM;
using ERPDal.SafeManage;
using ERPModel.SafeManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;

namespace ERPBll.SafeManage
{
    public class ErpCheckItemImp : BusinessRespository<ErpCheckItem, IErpCheckItemDataImp>, IBusinessRepository<ErpCheckItem>, IErpCheckItemImp
    {
        public ErpCheckItemImp(IErpCheckItemDataImp dataImp): base(dataImp)
        {

        }

        public async Task<bool> GroupSort(string server_id, List<ErpCheckItem> context)
        {
            return await _dataImp.Updatetable(server_id, context, new string[] { "I_ORDER" });
        }
    }
}