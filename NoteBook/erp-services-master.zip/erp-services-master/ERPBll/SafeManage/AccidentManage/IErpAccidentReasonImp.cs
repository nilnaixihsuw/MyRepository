﻿using ERPCore.ORM;
using ERPModel.AccidentManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.AccidentManage
{
    public interface IErpAccidentReasonImp : IBusinessRepository<ErpAccidentReason>
    {
    }
}