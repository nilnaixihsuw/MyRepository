﻿using ERPCore.ORM;
using ERPDal.AccidentManage;
using ERPModel.AccidentManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;

namespace ERPBll.AccidentManage
{
    public class ErpAccidentReasonImp : BusinessRespository<ErpAccidentReason, IErpAccidentReasonDataImp>, IErpAccidentReasonImp
    {
        public ErpAccidentReasonImp(IErpAccidentReasonDataImp dataImp): base(dataImp)
        {

        }
    }
}