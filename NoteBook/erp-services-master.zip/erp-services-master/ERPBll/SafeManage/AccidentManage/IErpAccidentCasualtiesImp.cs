﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPModel.AccidentManage;
using ERPModel.ApiModel;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.AccidentManage
{
    public interface IErpAccidentCasualtiesImp : IBusinessRepository<ErpAccidentCasualties>
    {
        Task<bool> AddCasualties(string server_id, ErpAccidentCasualties context, ClientInformation client);
        Task<(bool, string)> EditCasualties(string server_id, ErpAccidentCasualties context, ClientInformation client);
        Task<Tuple<List<ErpAccidentCasualties>, int>> ListCasualties(string server_id, ErpAccidentCasualtiesRequest request, string v, int page_size, int page_index, string orderby);
        Task<List<ErpAccidentCasualties>> ListCasualties(string server_id, ErpAccidentCasualtiesRequest request, string v, string orderby);
    }
}