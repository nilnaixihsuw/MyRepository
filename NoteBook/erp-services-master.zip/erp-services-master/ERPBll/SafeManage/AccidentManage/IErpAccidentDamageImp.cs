﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPModel.AccidentManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.AccidentManage
{
    public interface IErpAccidentDamageImp : IBusinessRepository<ErpAccidentDamage>
    {
        Task<bool> AddDamage(string server_id, ErpAccidentDamage context, ClientInformation client);
        Task<(bool, string)> EditDamage(string server_id, ErpAccidentDamage context, ClientInformation client);
    }
}