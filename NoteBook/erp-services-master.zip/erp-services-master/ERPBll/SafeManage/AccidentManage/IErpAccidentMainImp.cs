﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPModel.AccidentManage;
using ERPModel.ApiModel;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.AccidentManage
{
    public interface IErpAccidentMainImp : IBusinessRepository<ErpAccidentMain>
    {
        Task<bool> Add(string server_id, AddAccident context, IClientInformation client);
        Task<bool> Edit(string server_id, AddAccident context, IClientInformation client);
        Task<bool> BatchDelete(string server_id, List<decimal> context);
        //Task<List<AccidentSummary>> GetAccidentSummary(string server_id, DateTime? begin, DateTime? end, IClientInformation client);
        Task<List<AccidentSummary>> GetAccidentSummary(AccidentRequest request, IClientInformation client);
        Task<List<AccidentAnalysisItem>> GetAccidentDutyAnalysis(string server_id, DateTime? begin, DateTime? end, IClientInformation client);
        Task<List<AccidentAnalysisItem>> GetAccidentReasonAnalysis(string server_id, DateTime? begin, DateTime? end, IClientInformation client);
        Task<AccidentDriverAnalysis> GetAccidentDriverAnalysis(string server_id, DateTime? begin, DateTime? end, IClientInformation client);
        Task<List<AccidentAnalysisItem>> GetAccidentTimeAnalysis(string server_id, DateTime? begin, DateTime? end, IClientInformation client);
        Task<List<AccidentAnalysisItem>> GetAccidentRoadAnalysis(string server_id, DateTime? begin, DateTime? end, IClientInformation client);
        Task<List<AccidentSlim>> QueryAccidentInfo(string server_id, decimal id);
        Task<List<ErpAccidentMain>> GetAccidentList(string server_id, ErpAccidentMainRequest request, string v, string orderby, IClientInformation client);
        Task<Tuple<List<ErpAccidentMain>, int>> GetAccidentList(string server_id, ErpAccidentMainRequest request, string v, int page_size, int page_index, string orderby, IClientInformation client);
        Task<List<AccidentSummaryQueryModel>> AccidentStatistics(AccidentReportStaQueryParam context);
        Task<AccidentFee> GetAccidentFee(string server_id, decimal id, ClientInformation client);
        Task<List<AccidentSummarySta>> AccidentSummary(AccidentReportQueryParam context);
        Task<bool> InvalidAccident(string server_id, List<decimal> context, ClientInformation client);
        Task<ErpAccidentMain> Detail(string server_id, decimal id, ClientInformation client);

        Task<bool> UpdateRepairFee(string server_id, decimal id, double actual_fee, IClientInformation client);
    }
}