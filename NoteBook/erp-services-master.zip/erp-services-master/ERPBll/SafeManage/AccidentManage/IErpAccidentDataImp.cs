﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPModel.AccidentManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.AccidentManage
{
    public interface IErpAccidentDataImp : IBusinessRepository<ErpAccidentData>
    {
        Task<bool> AddAccidentData(string server_id, ErpAccidentData context, ClientInformation client);
        Task<List<ErpAccidentData>> QueryAccidentData(string server_id,decimal id, int type);
        Task<bool> BatchDelete(string server_id, List<decimal> context);
    }
}