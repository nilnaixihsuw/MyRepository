﻿using ERPCore.ORM;
using ERPDal.AccidentManage;
using ERPModel.AccidentManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using ERPModel.ApiModel;
using ERPCore.Entity;
using ERPCore;
using AutoMapper;
using ERPDal.DataBase;
using System.Linq.Expressions;
using ERPBll.UserManage;
using ERPDal.Vehicleinfomanage;
using ERPDal;
using ERPModel.FlowManage.FlowRecords;
using ERPBll.FlowManage.Contracts;
using DotNetCore.CAP;
using ERPBll.Caps;
using ERPModel.FlowManage;
using ERPBll.RedisManage.Lines;
using ERPBll.RedisManage.Users;
using ERPBll.RedisManage;
using ERPBll.RedisManage.Dicts;
using BusTools.Redis;
using Microsoft.AspNetCore.Http;
using ERPDal.UserManage;

namespace ERPBll.AccidentManage
{
    public class ErpAccidentMainImp : BusinessRespository<ErpAccidentMain, IErpAccidentMainDataImp>, IErpAccidentMainImp, ICapSubscribe
    {
        private readonly IMapper _iMapper;
        private readonly IErpAccidentReasonDataImp _iErpAccidentReasonDataImp;
        private readonly IErpAccidentCasualtiesDataImp _iErpAccidentCasualtiesDataImp;
        private readonly IErpAccidentDataDataImp _iErpAccidentDataDataImp;
        private readonly IErpAccidentDamageImp _iErpAccidentDamageImp;
        private readonly ISysCommonDictDataImp _iSysCommonDictDataImp;
        private readonly IVehicleInfoDataImp _iVehicleInfoDataImp;
        private readonly IErpAccidentCostDataImp _iErpAccidentCostDataImp;
        private readonly IErpFlowRecordImp _iErpFlowRecordImp;
        private readonly ILineRedisImp _lineRedisImp;
        private readonly IUserRedisImp _userRedisImp;
        private readonly IVehicleRedisManageImp _vehicleRedisManageImp;
        private readonly IDictRedisManageImp _dictRedisManageImp;
        private readonly IErpAccidentDamageDataImp _iErpAccidentDamageDataImp;
        private readonly IRedisService _redisService;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly ISysPersonDataImp _iSysPersonDataImp;
        private readonly ISysCommonDictDetailDataImp _iSysCommonDictDetailDataImp;

        public ErpAccidentMainImp(
            ISysPersonDataImp iSysPersonDataImp,
            IErpFlowRecordImp iErpFlowRecordImp,
            IErpAccidentCostDataImp iErpAccidentCostDataImp,
            IVehicleInfoDataImp iVehicleInfoDataImp,
            IMapper iMapper,
            IErpAccidentDamageImp iErpAccidentDamageImp,
            IErpAccidentDataDataImp iErpAccidentDataDataImp,
            IErpAccidentCasualtiesDataImp iErpAccidentCasualtiesDataImp,
            IErpAccidentReasonDataImp iErpAccidentReasonDataImp,
            ISysCommonDictDataImp iSysCommonDictDataImp,
            IErpAccidentMainDataImp dataImp,
            ILineRedisImp lineRedisImp,
            IUserRedisImp userRedisImp,
            IVehicleRedisManageImp vehicleRedisManageImp,
            IDictRedisManageImp dictRedisManageImp,
            IErpAccidentDamageDataImp iErpAccidentDamageDataImp,
            IRedisService redisService,
            ISysCommonDictDetailDataImp iSysCommonDictDetailDataImp,
            IHttpContextAccessor httpContextAccessor) : base(dataImp)
        {
            _iSysPersonDataImp = iSysPersonDataImp;
            _iErpFlowRecordImp = iErpFlowRecordImp;
            _iErpAccidentCostDataImp = iErpAccidentCostDataImp;
            _iVehicleInfoDataImp = iVehicleInfoDataImp;
            _iMapper = iMapper;
            _iErpAccidentReasonDataImp = iErpAccidentReasonDataImp;
            _iErpAccidentCasualtiesDataImp = iErpAccidentCasualtiesDataImp;
            _iErpAccidentDataDataImp = iErpAccidentDataDataImp;
            _iErpAccidentDamageImp = iErpAccidentDamageImp;
            _iSysCommonDictDataImp = iSysCommonDictDataImp;
            _lineRedisImp = lineRedisImp;
            _userRedisImp = userRedisImp;
            _vehicleRedisManageImp = vehicleRedisManageImp;
            _dictRedisManageImp = dictRedisManageImp;
            _iErpAccidentDamageDataImp = iErpAccidentDamageDataImp;
            _redisService = redisService;
            _iSysCommonDictDetailDataImp = iSysCommonDictDetailDataImp;
            _httpContextAccessor = httpContextAccessor;
        }

        /// <summary>
        /// 修改维修费用
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="id"></param>
        /// <param name="actual_fee"></param>
        /// <param name="client"></param>
        /// <returns></returns>
        public async Task<bool> UpdateRepairFee(string server_id, decimal id, double actual_fee, IClientInformation client)
        {
            var old = await _dataImp.Get(server_id, id);
            old.n_actual_fee = actual_fee;
            old.d_update = DateTime.Now;
            old.i_update = client.i_id;
            return await _dataImp.Update(server_id, old);
        }

        public async Task<bool> Add(string server_id, AddAccident context, IClientInformation client)
        {
            var accident = _iMapper.Map<AddAccident, ErpAccidentMain>(context);

            if (context.i_id != null && context.i_id > 0)
            {
                //编辑
                var old = await _dataImp.Get(server_id, context.i_id);
                accident.i_created = old.i_created;
                accident.d_created = old.d_created;
                accident.c_accident_code = old.c_accident_code;
                accident.state = old.state;
                accident.i_update = client.i_id;
                accident.d_update = DateTime.Now;
                var reasons = context.accident_reasons.Select(it => new ErpAccidentReason
                {
                    i_id = _dataImp.GetId(server_id, "SEQ_COMMON").Result,
                    i_main_id = accident.i_id.ToString(),
                    i_reason = it
                }).ToList();

                if (accident.flow_id != null && context.is_start_flow && (accident.state == 1 || accident.state == 4 || accident.state == 5))
                {
                    accident.state = 2;
                    accident.i_created = client.i_id;
                    accident.d_created = DateTime.Now;
                    await _iErpFlowRecordImp.UpdateAsync(server_id, Convert.ToInt32(accident.flow_id), Convert.ToInt32(accident.i_id), "");
                }

                //事故资料
                if (accident.accident_datas != null && accident.accident_datas.Count > 0)
                {
                    accident.accident_datas.ForEach(it =>
                    {
                        it.i_id = _dataImp.GetId(server_id, "SEQ_COMMON").Result;
                        it.i_main_id = accident.i_id;
                    });
                }
                if (context.is_save_file)
                {
                    accident.accident_datas = await _iErpAccidentDataDataImp.List(server_id, it => it.i_main_id == context.i_id);
                }

                var res = await _dataImp.Edit(server_id, accident, reasons, accident.accident_datas);

                var str = "";
                if (res)
                {
                    str = Tools.CompareClass(_iMapper.Map<ErpAccidentMain, CompareErpAccidentMain>(old), _iMapper.Map<ErpAccidentMain, CompareErpAccidentMain>(accident));
                }
                var httpContextAccessorTemp = (HttpContextAccessor)_httpContextAccessor;
                //http请求添加编辑标记
                httpContextAccessorTemp.HttpContext.Items.Add("type", 2);
                var guid = "";
                if (httpContextAccessorTemp != null && httpContextAccessorTemp.HttpContext.Items.ContainsKey("guid"))
                    guid = httpContextAccessorTemp.HttpContext.Items["guid"].ToString();
                await _redisService.StringSetAsync(guid, str, TimeSpan.FromMinutes(2));

                return res;
            }
            else
            {
                //新增
                accident.i_id = await _dataImp.GetId(server_id, "SEQ_COMMON");
                accident.i_created = client.i_id;
                accident.d_created = DateTime.Now;
                accident.state = 1;
                //事故编号
                accident.c_accident_code = await _dataImp.GetCustomCode(server_id, it => it.c_accident_code != null, it => long.Parse(it.c_accident_code));
                var reasons = context.accident_reasons.Select(it => new ErpAccidentReason
                {
                    i_id = _dataImp.GetId(server_id, "SEQ_COMMON").Result,
                    i_main_id = accident.i_id.ToString(),
                    i_reason = it
                }).ToList();
                //事故资料
                if (accident.accident_datas != null && accident.accident_datas.Count > 0)
                {
                    accident.accident_datas.ForEach(it =>
                    {
                        it.i_id = _dataImp.GetId(server_id, "SEQ_COMMON").Result;
                        it.i_main_id = accident.i_id;
                    });
                }

                //车辆信息
                var vehicles = await _iVehicleInfoDataImp.ExtList(server_id, await _iVehicleInfoDataImp.List(server_id, it => it.i_id == accident.i_vehicle_id));
                //驾驶员信息
                var drvers = await _iSysPersonDataImp.List(server_id
                    , it => it.i_id == accident.i_driver_id
                    , new string[] { "I_ID", "D_BIRTHDAY", "D_FIRST_GET_LICENCE", "D_JOIN_COMPANY", "C_NAME" }
                );

                var veh_code = vehicles != null && vehicles.Count > 0 ? vehicles.FirstOrDefault().c_lincense_plate_number : "";
                var driver_name = drvers != null && drvers.Count > 0 ? drvers.FirstOrDefault().c_name : "";

                var httpContextAccessorTemp = (HttpContextAccessor)_httpContextAccessor;
                //http请求添加新增标记
                httpContextAccessorTemp.HttpContext.Items.Add("type", 1);
                var str = @"新增事故记录：事故编号为" + accident.c_accident_code +
                    " <br/>  车牌号为" + veh_code + "," + " <br/>  驾驶员为" + driver_name;
                var guid = "";
                if (httpContextAccessorTemp != null && httpContextAccessorTemp.HttpContext.Items.ContainsKey("guid"))
                    guid = httpContextAccessorTemp.HttpContext.Items["guid"].ToString();
                await _redisService.StringSetAsync(guid, str, TimeSpan.FromMinutes(2));

                return await _dataImp.Add(server_id, accident, reasons, accident.accident_datas);
            }
        }

        public async Task<bool> Edit(string server_id, AddAccident context, IClientInformation client)
        {
            var accident = _iMapper.Map<AddAccident, ErpAccidentMain>(context);

            //编辑
            var old = await _dataImp.Get(server_id, context.i_id);
            accident.i_created = old.i_created;
            accident.d_created = old.d_created;
            accident.c_accident_code = old.c_accident_code;
            accident.state = old.state;
            accident.i_update = client.i_id;
            accident.d_update = DateTime.Now;
            var reasons = context.accident_reasons.Select(it => new ErpAccidentReason
            {
                i_id = _dataImp.GetId(server_id, "SEQ_COMMON").Result,
                i_main_id = accident.i_id.ToString(),
                i_reason = it
            }).ToList();

            if (accident.flow_id != null && context.is_start_flow && (accident.state == 1 || accident.state == 4 || accident.state == 5))
            {
                accident.state = 2;
                accident.i_created = client.i_id;
                accident.d_created = DateTime.Now;
                await _iErpFlowRecordImp.UpdateAsync(server_id, Convert.ToInt32(accident.flow_id), Convert.ToInt32(accident.i_id), "");
            }

            //事故资料
            if (accident.accident_datas != null && accident.accident_datas.Count > 0)
            {
                accident.accident_datas.ForEach(it =>
                {
                    it.i_id = _dataImp.GetId(server_id, "SEQ_COMMON").Result;
                    it.i_main_id = accident.i_id;
                });
            }
            if (context.is_save_file)
            {
                accident.accident_datas = await _iErpAccidentDataDataImp.List(server_id, it => it.i_main_id == context.i_id);
            }

            var res = await _dataImp.Edit(server_id, accident, reasons, accident.accident_datas);

            var str = "";
            if (res)
            {
                str = Tools.CompareClass(_iMapper.Map<ErpAccidentMain, CompareErpAccidentMain>(old), _iMapper.Map<ErpAccidentMain, CompareErpAccidentMain>(accident));
            }
            var httpContextAccessorTemp = (HttpContextAccessor)_httpContextAccessor;
            //http请求添加编辑标记
            httpContextAccessorTemp.HttpContext.Items.Add("type", 2);
            var guid = "";
            if (httpContextAccessorTemp != null && httpContextAccessorTemp.HttpContext.Items.ContainsKey("guid"))
                guid = httpContextAccessorTemp.HttpContext.Items["guid"].ToString();
            await _redisService.StringSetAsync(guid, str, TimeSpan.FromMinutes(2));

            return res;
        }

        public async Task<bool> BatchDelete(string server_id, List<decimal> context)
        {
            //事故记录
            var sgList = await _dataImp.List(server_id, it => SqlFunc.ContainsArray(context, it.i_id));

            //车辆信息
            var vehicles = await _iVehicleInfoDataImp.ExtList(server_id, await _iVehicleInfoDataImp.List(server_id, it => SqlFunc.ContainsArray(sgList.Select(it => it.i_vehicle_id).ToList(), it.i_id)));
            //驾驶员信息
            var drvers = await _iSysPersonDataImp.List(server_id
                , it => SqlFunc.ContainsArray(sgList.Select(it => it.i_driver_id).ToList()
                , it.i_id)
                , new string[] { "I_ID", "D_BIRTHDAY", "D_FIRST_GET_LICENCE", "D_JOIN_COMPANY", "C_NAME" }
            );
            //事故责任
            var acDutys = await _iSysCommonDictDetailDataImp.List(server_id, it => SqlFunc.ContainsArray(sgList.Select(it => it.i_accident_duty).ToList(), it.i_id));

            //事故原因
            var reasons = await _iErpAccidentReasonDataImp.List(server_id, it => SqlFunc.ContainsArray(context, it.i_main_id));
            //伤亡记录
            var swLIst = await _iErpAccidentCasualtiesDataImp.List(server_id, it => SqlFunc.ContainsArray(context, it.i_main_id));
            //事故资料
            var dataList = await _iErpAccidentDataDataImp.List(server_id, it => SqlFunc.ContainsArray(context, it.i_main_id));
            //车损记录
            var csList = await _iErpAccidentDamageImp.List(server_id, it => SqlFunc.ContainsArray(context, it.i_main_id));

            var res = await _dataImp.BatchDelete(server_id, sgList, reasons, swLIst, dataList, csList);

            if (res)
            {
                var str = "删除事故记录：事故编号为" + string.Join(",", sgList.Select(x => x.c_accident_code).ToList().ToArray()) + ";<br/>";
                str += "车牌号为" + string.Join(",", vehicles.Select(x => x.c_lincense_plate_number).ToList().ToArray()) + ";<br/>";
                str += "驾驶员为" + string.Join(",", drvers.Select(x => x.c_name).ToList().ToArray()) + ";<br/>";
                str += "事故时间为" + string.Join(",", sgList.Select(x => x.d_accident_date).ToList().ToArray()) + ";<br/>";
                str += "事故责任为" + string.Join(",", acDutys.Select(x => x.c_name).ToList().ToArray()) + ";<br/>";
                str += "事故描述为" + string.Join(",", sgList.Select(x => x.c_describe).ToList().ToArray());

                var httpContextAccessorTemp = (HttpContextAccessor)_httpContextAccessor;
                var guid = "";
                if (httpContextAccessorTemp != null && httpContextAccessorTemp.HttpContext.Items.ContainsKey("guid"))
                    guid = httpContextAccessorTemp.HttpContext.Items["guid"].ToString();
                await _redisService.StringSetAsync(guid, str, TimeSpan.FromMinutes(2));
            }

            return res;
        }

        public async Task<List<AccidentSummary>> GetAccidentSummary(AccidentRequest request, IClientInformation client)
        {
            string server_id = request.server_id;
            var orgs = RoleInfoBll.GetGroupID(server_id, client.i_id);
            var exp = Expressionable.Create<ErpAccidentMain>();
            //.AndIF(begin != null, it => it.d_accident_date >= begin)
            //.AndIF(end != null, it => it.d_accident_date <= end);

            if (orgs != null)
            {
                if (orgs.Count > 0)
                {
                    var cars = await _iVehicleInfoDataImp.List(server_id, it => SqlFunc.ContainsArray(orgs.Select(it => it.ToString()).ToList(), it.c_crews_take));
                    if (cars != null && cars.Count > 0)
                    {
                        exp.And(it => SqlFunc.ContainsArray(cars.Select(it => it.i_id).ToList(), it.i_vehicle_id));
                    }
                    else
                    {
                        exp.And(it => false);
                    }
                }
                else
                {
                    exp.And(it => false);
                }
            }
            else
            {
                exp.And(it => true);
            }

            var list = await _dataImp.List(server_id, request.ToExp(new List<Expression<Func<ErpAccidentMain, bool>>>() { exp.ToExpression() }));
            var accidents = await _dataImp.ExtList(server_id, list);
            //事故总数
            var total = accidents.Count;
            //有责事故
            var yzList = accidents.Where(it => !string.IsNullOrEmpty(it.accident_duty) && it.accident_duty != "无责").ToList();
            var yzTotal = yzList.Count;
            //无责次数
            var wzList = accidents.Where(it => !string.IsNullOrEmpty(it.accident_duty) && it.accident_duty == "无责").ToList();
            var wzTotal = wzList.Count;
            //伤亡人数
            var swTotal = accidents.Sum(it => it.casualties == null ? 0 : it.casualties.Select(it => it.i_person_id).Distinct().Count());
            //扣除安全里程
            var kcTotal = accidents.Sum(it => it.n_result_mile);
            //损失金额
            var sxTotal = accidents.Sum(it =>
                (it.accident_total_fee.HasValue ? it.accident_total_fee.Value : 0)
                + (it.n_actual_fee.HasValue ? it.n_actual_fee.Value : 0)
                - (it.n_insurance_pay_fee.HasValue ? it.n_insurance_pay_fee.Value : 0)
                - (it.n_personal_fee.HasValue ? it.n_personal_fee.Value : 0)
            );
            var r = new AccidentSummary[] {
                new AccidentSummary
                {
                   title="事故总数",
                   count=total
                },
                new AccidentSummary
                {
                   title="有责事故",
                   count=yzTotal,
                },
                new AccidentSummary
                {
                   title="无责次数",
                   count=wzTotal,
                },
                new AccidentSummary
                {
                   title="人伤人数",
                   count=swTotal
                },
                new AccidentSummary
                {
                   title="扣除安全里程",
                   count= kcTotal
                },
                new AccidentSummary
                {
                   title="损失金额",
                   count= sxTotal
                },
            }.ToList();
            return r;
        }

        public async Task<List<AccidentAnalysisItem>> GetAccidentDutyAnalysis(string server_id, DateTime? begin, DateTime? end, IClientInformation client)
        {
            var result = new List<AccidentAnalysisItem>();
            var exp = Expressionable.Create<ErpAccidentMain>()
                                    .AndIF(begin != null, it => it.d_accident_date >= begin)
                                    .AndIF(end != null, it => it.d_accident_date <= end);
            var orgs = RoleInfoBll.GetGroupID(server_id, client.i_id);
            if (orgs != null)
            {
                if (orgs.Count > 0)
                {
                    var cars = await _iVehicleInfoDataImp.List(server_id, it => SqlFunc.ContainsArray(orgs.Select(it => it.ToString()).ToList(), it.c_crews_take));
                    if (cars != null && cars.Count > 0)
                    {
                        exp.And(it => SqlFunc.ContainsArray(cars.Select(it => it.i_id).ToList(), it.i_vehicle_id));
                    }
                    else
                    {
                        exp.And(it => false);
                    }
                }
                else
                {
                    exp.And(it => false);
                }
            }
            else
            {
                exp.And(it => true);
            }
            var list = await _dataImp.List(server_id, exp.ToExpression());
            if (list != null && list.Count > 0)
            {
                var accidents = await _dataImp.ExtList(server_id, list);
                //事故责任类型
                var sgList = await _iSysCommonDictDataImp.List(server_id, it => it.c_name == "事故责任");
                var sgType = await _iSysCommonDictDataImp.ExtList(server_id, sgList);
                if (sgType != null && sgType.Count == 1)
                {
                    result = sgType[0].dic_detls.Select(it => new AccidentAnalysisItem
                    {
                        name = it.c_name,
                        value = accidents.Where(c => c.i_accident_duty == it.c_code).ToList().Count
                    }).ToList();
                }
            }
            return result.Where(it => it.value != null && it.value != 0).ToList();
        }

        public async Task<List<AccidentAnalysisItem>> GetAccidentReasonAnalysis(string server_id, DateTime? begin, DateTime? end, IClientInformation client)
        {
            var result = new List<AccidentAnalysisItem>();
            var exp = Expressionable.Create<ErpAccidentMain>()
                                    .AndIF(begin != null, it => it.d_accident_date >= begin)
                                    .AndIF(end != null, it => it.d_accident_date <= end);
            var orgs = RoleInfoBll.GetGroupID(server_id, client.i_id);
            if (orgs != null)
            {
                if (orgs.Count > 0)
                {
                    var cars = await _iVehicleInfoDataImp.List(server_id, it => SqlFunc.ContainsArray(orgs.Select(it => it.ToString()).ToList(), it.c_crews_take));
                    if (cars != null && cars.Count > 0)
                    {
                        exp.And(it => SqlFunc.ContainsArray(cars.Select(it => it.i_id).ToList(), it.i_vehicle_id));
                    }
                    else
                    {
                        exp.And(it => false);
                    }
                }
                else
                {
                    exp.And(it => false);
                }
            }
            else
            {
                exp.And(it => true);
            }
            var list = await _dataImp.List(server_id, exp.ToExpression());
            if (list != null && list.Count > 0)
            {
                var accidents = await _dataImp.ExtList(server_id, list);
                var reasons = new List<ErpAccidentReason>();
                accidents.ForEach(item =>
                {
                    if (item.reasons != null)
                        reasons.AddRange(item.reasons);
                });

                //事故原因类型
                var sgList = await _iSysCommonDictDataImp.List(server_id, it => it.c_name == "事故原因");
                var sgType = await _iSysCommonDictDataImp.ExtList(server_id, sgList);
                var accidentReasons = accidents.Select(it => it.reasons).ToList();

                if (sgType != null && sgType.Count == 1)
                {
                    result = sgType[0].dic_detls.Select(it => new AccidentAnalysisItem
                    {
                        name = it.c_name,
                        value = reasons.Where(c => c.i_reason == it.c_code).ToList().Count
                    }).ToList();
                }
            }

            return result.Where(it => it.value != null && it.value != 0).OrderByDescending(it => it.value).ToList();
        }

        public async Task<AccidentDriverAnalysis> GetAccidentDriverAnalysis(string server_id, DateTime? begin, DateTime? end, IClientInformation client)
        {
            var result = new AccidentDriverAnalysis();
            var exp = Expressionable.Create<ErpAccidentMain>()
                                    .AndIF(begin != null, it => it.d_accident_date >= begin)
                                    .AndIF(end != null, it => it.d_accident_date <= end);
            var orgs = RoleInfoBll.GetGroupID(server_id, client.i_id);
            if (orgs != null)
            {
                if (orgs.Count > 0)
                {
                    var cars = await _iVehicleInfoDataImp.List(server_id, it => SqlFunc.ContainsArray(orgs.Select(it => it.ToString()).ToList(), it.c_crews_take));
                    if (cars != null && cars.Count > 0)
                    {
                        exp.And(it => SqlFunc.ContainsArray(cars.Select(it => it.i_id).ToList(), it.i_vehicle_id));
                    }
                    else
                    {
                        exp.And(it => false);
                    }
                }
                else
                {
                    exp.And(it => false);
                }
            }
            else
            {
                exp.And(it => true);
            }
            var list = await _dataImp.List(server_id, exp.ToExpression());
            if (list != null && list.Count > 0)
            {
                var accidents = await _dataImp.ExtList(server_id, list);
                var accidentDrivers = accidents.Where(it => it.driver_msg != null).Select(it => it.driver_msg).ToList();
                if (accidentDrivers != null && accidentDrivers.Count > 0)
                {
                    var driving_years = accidentDrivers.Select(it => it.driving_year.GetValueOrDefault()).ToList();
                    var ages = accidentDrivers.Select(it => it.age.GetValueOrDefault()).ToList();
                    var working_years = accidentDrivers.Select(it => it.working_year.GetValueOrDefault()).ToList();
                    result.driving_years = new AccidentDriverGroupAnalysis
                    {
                        average = Math.Round(driving_years.Sum() / accidentDrivers.Count),
                        summary = TransformItem(driving_years, TransformYear).Where(it => !string.IsNullOrEmpty(it.name)).ToList()
                    };
                    result.ages = new AccidentDriverGroupAnalysis
                    {
                        average = Math.Round(ages.Sum() / accidentDrivers.Count),
                        summary = TransformItem(ages, TransformYear, 1).Where(it => !string.IsNullOrEmpty(it.name)).ToList()
                    };
                    result.working_years = new AccidentDriverGroupAnalysis
                    {
                        average = Math.Round(working_years.Sum() / accidentDrivers.Count),
                        summary = TransformItem(working_years, TransformYear).Where(it => !string.IsNullOrEmpty(it.name)).ToList()
                    };
                }
            }

            return result;
        }

        public List<AccidentAnalysisItem> TransformItem(List<decimal> year, Func<decimal, int, string> transform, int type = 0)
        {
            var result = new List<AccidentAnalysisItem>();
            var yearTypes = year.Select(it => TransformYear(it, type)).Distinct().ToList();
            if (yearTypes != null && yearTypes.Count > 0)
            {
                yearTypes.ForEach(item =>
                {
                    result.Add(new AccidentAnalysisItem()
                    {
                        name = item,
                        value = year.Count(it => transform(it, type) == item)
                    });
                });
            }
            return result;
        }

        public string TransformYear(decimal year, int type)
        {
            var result = "";
            switch (type)
            {
                case 0:
                    if (year < 1)
                    {
                        result = "1年以内";
                    }
                    if (year >= 1 && year < 3)
                    {
                        result = "1-3年";
                    }
                    if (year >= 3 && year < 5)
                    {
                        result = "3-5年";
                    }
                    if (year >= 5 && year < 10)
                    {
                        result = "5-10年";
                    }
                    if (year > 10)
                    {
                        result = "10年以上";
                    }
                    break;
                case 1:
                    if (year < 20)
                    {
                        result = "20岁以下";
                    }
                    if (year >= 20 && year < 30)
                    {
                        result = "20-30岁";
                    }
                    if (year >= 30 && year < 40)
                    {
                        result = "30-40岁";
                    }
                    if (year >= 40 && year < 50)
                    {
                        result = "40-50岁";
                    }
                    if (year > 50)
                    {
                        result = "50岁以上";
                    }
                    break;
                default:
                    break;
            }

            return result;
        }

        public async Task<List<AccidentAnalysisItem>> GetAccidentTimeAnalysis(string server_id, DateTime? begin, DateTime? end, IClientInformation client)
        {
            var result = new List<AccidentAnalysisItem>();
            var exp = Expressionable.Create<ErpAccidentMain>()
                                    .AndIF(begin != null, it => it.d_accident_date >= begin)
                                    .AndIF(end != null, it => it.d_accident_date <= end);
            var orgs = RoleInfoBll.GetGroupID(server_id, client.i_id);
            if (orgs != null)
            {
                if (orgs.Count > 0)
                {
                    var cars = await _iVehicleInfoDataImp.List(server_id, it => SqlFunc.ContainsArray(orgs.Select(it => it.ToString()).ToList(), it.c_crews_take));
                    if (cars != null && cars.Count > 0)
                    {
                        exp.And(it => SqlFunc.ContainsArray(cars.Select(it => it.i_id).ToList(), it.i_vehicle_id));
                    }
                    else
                    {
                        exp.And(it => false);
                    }
                }
                else
                {
                    exp.And(it => false);
                }
            }
            else
            {
                exp.And(it => true);
            }
            var list = await _dataImp.List(server_id, exp.ToExpression());
            if (list != null && list.Count > 0)
            {
                //list.Select(it => string.Format("{0:t}", it.d_accident_date)).Distinct().ToList().ForEach(item =>
                //{
                //    result.Add(new AccidentAnalysisItem
                //    {
                //        name = item,
                //        value = list.Where(it => string.Format("{0:t}", it.d_accident_date) == item).ToList().Count
                //    });
                //});
                for (var i = 0; i < 25; i++)
                {
                    result.Add(new AccidentAnalysisItem
                    {
                        name = (i < 10 ? "0" : "") + i + ":00",
                        value = list.Where(it => it.d_accident_date.GetValueOrDefault().Hour == i).Count()
                    });
                }
            }

            return result;
        }

        public async Task<List<AccidentAnalysisItem>> GetAccidentRoadAnalysis(string server_id, DateTime? begin, DateTime? end, IClientInformation client)
        {
            var result = new List<AccidentAnalysisItem>();
            var exp = Expressionable.Create<ErpAccidentMain>()
                                    .AndIF(begin != null, it => it.d_accident_date >= begin)
                                    .AndIF(end != null, it => it.d_accident_date <= end);
            var orgs = RoleInfoBll.GetGroupID(server_id, client.i_id);
            if (orgs != null)
            {
                if (orgs.Count > 0)
                {
                    var cars = await _iVehicleInfoDataImp.List(server_id, it => SqlFunc.ContainsArray(orgs.Select(it => it.ToString()).ToList(), it.c_crews_take));
                    if (cars != null && cars.Count > 0)
                    {
                        exp.And(it => SqlFunc.ContainsArray(cars.Select(it => it.i_id).ToList(), it.i_vehicle_id));
                    }
                    else
                    {
                        exp.And(it => false);
                    }
                }
                else
                {
                    exp.And(it => false);
                }
            }
            else
            {
                exp.And(it => true);
            }
            var list = await _dataImp.List(server_id, exp.ToExpression());
            if (list != null && list.Count > 0)
            {
                list.Select(it => it.c_accident_address).Distinct().ToList().ForEach(item =>
                {
                    result.Add(new AccidentAnalysisItem
                    {
                        name = item,
                        value = list.Where(it => it.c_accident_address == item).ToList().Count
                    });
                });
            }

            return result.Where(it => it.value != null && it.value != 0).ToList();
        }

        public async Task<List<AccidentSlim>> QueryAccidentInfo(string server_id, decimal id)
        {
            var r = new List<AccidentSlim>();
            var list = await _dataImp.List(server_id, it => it.i_vehicle_id == id);
            if (list != null && list.Count > 0)
            {
                var sgList = await _dataImp.ExtList(server_id, list);
                if (sgList != null && sgList.Count > 0)
                {
                    sgList.ForEach(item =>
                    {
                        r.Add(_iMapper.Map<ErpAccidentMain, AccidentSlim>(item));
                    });
                }
            }
            return r;
        }

        public async Task<List<ErpAccidentMain>> GetAccidentList(string server_id, ErpAccidentMainRequest request, string v, string orderby, IClientInformation client)
        {
            var exp = await ExtQueryParam(request);
            var q = await SqlSugarHelper.DBClient(server_id).Queryable<ErpAccidentMain>()
                                                            .WhereIF(request.ToExp(exp) != null, request.ToExp(exp))
                                                            .WhereIF(!string.IsNullOrEmpty(v), v)
                                                            .OrderByIF(!string.IsNullOrEmpty(orderby), orderby)
                                                            .ToListAsync();
            var list = await ExtList(server_id, q);
            if (list != null && list.Count > 0)
            {
                var all = await _iErpFlowRecordImp.GetListAsync(server_id, client.i_id,
                    new FlowRecordQuery()
                    {
                        detail_ids = list.Select(x => (int)x.i_id).ToList()
                    }
                );
                foreach (var item in list)
                {
                    if (item.state == 2)//处理中
                    {
                        var info = all.FirstOrDefault(x => x.detail_id == item.i_id);
                        if (info != null)
                        {
                            item.user_ids = info.state_child_id;
                            item.user_names = info.state_child_name;
                            if (item.flow_id != null && item.user_ids.Contains(client.i_id.Value))
                            {
                                item.ex_can_dispose = 1;
                                item.ex_can_cancel = 1;
                            }
                        }
                    }
                }
            }

            return list;
        }

        public async Task<Tuple<List<ErpAccidentMain>, int>> GetAccidentList(string server_id, ErpAccidentMainRequest request, string v, int page_size, int page_index, string orderby, IClientInformation client)
        {
            var exp = await ExtQueryParam(request);
            RefAsync<int> total = 0;
            var q = await SqlSugarHelper.DBClient(server_id).Queryable<ErpAccidentMain>()
                                                            .WhereIF(request.ToExp(exp) != null, request.ToExp(exp))
                                                            .WhereIF(!string.IsNullOrEmpty(v), v)
                                                            .OrderByIF(!string.IsNullOrEmpty(orderby), orderby)
                                                            .ToPageListAsync(page_index, page_size, total);
            var list = await ExtList(server_id, q);
            if (list != null && list.Count > 0)
            {
                var all = await _iErpFlowRecordImp.GetListAsync(server_id, client.i_id,
                    new FlowRecordQuery()
                    {
                        detail_ids = list.Select(x => (int)x.i_id).ToList()
                    }
                );

                foreach (var item in list)
                {
                    if (item.state == 2)//处理中
                    {
                        var info = all.FirstOrDefault(x => x.detail_id == item.i_id);
                        if (info != null)
                        {
                            item.user_ids = info.state_child_id;
                            item.user_names = info.state_child_name;
                            if (item.flow_id != null && item.user_ids.Contains(client.i_id.Value))
                            {
                                item.ex_can_dispose = 1;
                            }
                            if (item.flow_id != null && info.created_id == client.i_id)
                            {
                                item.ex_can_cancel = 1;
                            }
                        }

                    }
                }
            }

            return new Tuple<List<ErpAccidentMain>, int>(list, total);
        }

        /// <summary>
        /// 扩展条件
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        private async Task<List<Expression<Func<ErpAccidentMain, bool>>>> ExtQueryParam(ErpAccidentMainRequest request)
        {
            var r = new List<Expression<Func<ErpAccidentMain, bool>>>();
            //角色部门权限
            if (request.orgs != null)
            {
                if (request.orgs.Count > 0)
                {
                    var cars = await _iVehicleInfoDataImp.List(request.server_id, it => SqlFunc.ContainsArray(request.orgs.Select(it => it.ToString()).ToList(), it.c_crews_take));
                    if (cars != null && cars.Count > 0)
                    {
                        r.Add(it => SqlFunc.ContainsArray(cars.Select(it => it.i_id).ToList(), it.i_vehicle_id));
                    }
                }
                else
                {
                    r.Add(it => false);
                }
            }
            else
            {
                r.Add(it => true);
            }

            //事故责任类型
            var sgList = await _iSysCommonDictDataImp.List(request.server_id, it => it.c_name == "事故责任");
            var sgType = await _iSysCommonDictDataImp.ExtList(request.server_id, sgList);

            //责任状态
            if (request.state != null)
            {
                //有责记录
                if (request.state == 1)
                {
                    var accidentDutyIds = sgType.Select(it => it.dic_detls.Find(c => c.c_name != "无责")).Select(it => it.c_code).ToList();
                    r.Add(it => SqlFunc.ContainsArray(accidentDutyIds, it.i_accident_duty));
                }
                //无责记录
                if (request.state == 0)
                {
                    var accidentDutyIds = sgType.Select(it => it.dic_detls.Find(c => c.c_name == "无责")).Select(it => it.c_code).ToList();
                    r.Add(it => SqlFunc.ContainsArray(accidentDutyIds, it.i_accident_duty));
                }
                //显示有伤亡的记录
                if (request.state == 2)
                {
                    var list = await _iErpAccidentCasualtiesDataImp.List(request.server_id, it => true);
                    if (list != null)
                    {
                        r.Add(it => SqlFunc.ContainsArray(list.Select(it => it.i_main_id).ToList(), it.i_id));
                    }
                }
            }
            //事故责任
            if (!string.IsNullOrEmpty(request.accident_duty))
            {
                var accidentDutyId = sgType.Select(it => it.dic_detls.Find(c => c.c_name == request.accident_duty)).Select(it => it.c_code).FirstOrDefault();
                r.Add(it => it.i_accident_duty == accidentDutyId);
            }

            //事故发生时间
            if (!string.IsNullOrEmpty(request.accident_hour))
            {
                var hour = request.accident_hour.Split(":")[0];
                r.Add(it => SqlFunc.Oracle_ToChar(SqlFunc.ToDate(it.d_accident_date), "hh24") == hour);
            }
            return r;
        }

        public async Task<AccidentFee> GetAccidentFee(string server_id, decimal id, ClientInformation client)
        {
            var r = new AccidentFee();
            var casualties = await _iErpAccidentCasualtiesDataImp.List(server_id, it => it.i_main_id == id);
            var damages = await _iErpAccidentDamageImp.List(server_id, it => it.i_main_id == id);
            var costs = await _iErpAccidentCostDataImp.List(server_id, it => it.accident_id == id);
            r.n_medical_fee = casualties?.Where(it => it.n_medical_fee != null)?.Sum(it => it.n_medical_fee);
            r.n_missed_fee = casualties?.Where(it => it.n_missed_fee != null)?.Sum(it => it.n_missed_fee);
            r.n_nursing_fee = casualties?.Where(it => it.n_missed_fee != null)?.Sum(it => it.n_nursing_fee);
            r.n_food_fee = casualties?.Where(it => it.n_missed_fee != null)?.Sum(it => it.n_food_fee);
            r.n_traffic_fee = casualties?.Where(it => it.n_missed_fee != null)?.Sum(it => it.n_traffic_fee);
            r.n_actual_fee = damages?.Where(it => it.n_actual_fee != null)?.Sum(it => it.n_actual_fee);
            r.n_insurance_post_fee = costs?.Where(it => it.insurance_fee != null)?.Sum(it => it.insurance_fee);
            r.n_insurance_pay_fee = costs?.Where(it => it.actual_fee != null && it.state == 3)?.Sum(it => it.actual_fee);
            return r;
        }

        public async Task<List<AccidentSummaryQueryModel>> AccidentStatistics(AccidentReportStaQueryParam context)
        {
            var exp = Expressionable.Create<ErpAccidentMain>()
                                    .AndIF(context.begin != null, it => it.d_accident_date >= context.begin)
                                    .AndIF(context.end != null, it => it.d_accident_date <= context.end)
                                    .AndIF(context.i_vehicle_id != null && context.i_vehicle_id.Count > 0, it => SqlFunc.ContainsArray(context.i_vehicle_id, it.i_vehicle_id))
                                    .AndIF(context.i_accident_duty != null, it => it.i_accident_duty == context.i_accident_duty)
                                    .ToExpression();
            var list = await _dataImp.ExtList(context.server_id, await _dataImp.List(context.server_id, exp));
            var r = list.Select(it =>
                            new
                            {
                                it.department_name
                                ,
                                it.vehicle_number
                                ,
                                it.lincense_plate_number
                                ,
                                it.line
                                ,
                                it.driver_name
                                ,
                                it.d_accident_date
                                ,
                                it.c_accident_address
                                ,
                                it.accident_duty
                                ,
                                it.accident_reason
                                ,
                                it.accident_total_fee
                                ,
                                it.n_insurance_pay_fee
                                ,
                                it.n_personal_fee
                                ,
                                it.n_loss_fee
                            }
                        )
                        .GroupBy(it => new { it.department_name, it.vehicle_number, it.lincense_plate_number, it.line, it.driver_name, it.d_accident_date, it.c_accident_address, it.accident_duty, it.accident_reason })
                        .Select(it => new AccidentSummaryQueryModel
                        {
                            department_name = it.Key.department_name,
                            vehicle_number = it.Key.vehicle_number,
                            lincense_plate_number = it.Key.lincense_plate_number,
                            line = it.Key.line,
                            driver_name = it.Key.driver_name,
                            d_accident_date = it.Key.d_accident_date,
                            accident_duty = it.Key.accident_duty,
                            accident_reason = it.Key.accident_reason,
                            c_accident_address = it.Key.c_accident_address,
                            accident_total_fee = it.Where(it => it.accident_total_fee != null)?.ToList().Sum(it => it.accident_total_fee),
                            n_insurance_pay_fee = it.Where(it => it.n_insurance_pay_fee != null)?.ToList().Sum(it => it.n_insurance_pay_fee),
                            n_personal_fee = it.Where(it => it.n_personal_fee != null)?.ToList().Sum(it => it.n_personal_fee),
                            n_loss_fee = it.Where(it => it.n_loss_fee != null)?.ToList().Sum(it => it.n_loss_fee),
                        }).OrderBy(it => it.d_accident_date).ToList();
            return r;
        }

        public async Task<List<AccidentSummarySta>> AccidentSummary(AccidentReportQueryParam context)
        {
            var exp = Expressionable.Create<ErpAccidentMain>()
                                   .AndIF(context.begin != null, it => it.d_accident_date >= context.begin)
                                   .AndIF(context.end != null, it => it.d_accident_date <= context.end)
                                   .AndIF(context.i_vehicle_id != null && context.i_vehicle_id.Count > 0, it => SqlFunc.ContainsArray(context.i_vehicle_id, it.i_vehicle_id))
                                   .AndIF(context.i_driver_id != null && context.i_driver_id.Count > 0, it => SqlFunc.ContainsArray(context.i_driver_id, it.i_driver_id))
                                   .AndIF(context.i_line_id != null && context.i_line_id.Count > 0, it => SqlFunc.ContainsArray(context.i_line_id, it.i_line_id));
            if (context.i_org_id != null && context.i_org_id.Count > 0)
            {
                var vehicles = await _iVehicleInfoDataImp.List(context.server_id, it => SqlFunc.ContainsArray(context.i_org_id, it.c_crews_take));
                if (vehicles.Count > 0)
                {
                    exp.And(it => SqlFunc.ContainsArray(vehicles.Select(it => it.i_id).ToList(), it.i_vehicle_id));
                }
                else
                {
                    exp.And(it => false);
                }
            }
            var list = await _dataImp.ExtList(context.server_id, await _dataImp.List(context.server_id, exp.ToExpression()));
            var r = new List<AccidentSummarySta>();
            switch (context.type)
            {
                case 1:
                    r = list.Select(it =>
                            new
                            {
                                it.department_name
                                ,
                                it.accident_duty
                                ,
                                it.accident_total_fee
                                ,
                                it.n_insurance_pay_fee
                                ,
                                it.n_personal_fee
                                ,
                                it.n_loss_fee
                            }
                        )
                        .GroupBy(it => new { it.department_name })
                        .Select(it => new AccidentSummarySta
                        {
                            department_name = it.Key.department_name,
                            accident_total = it.ToList().Count,
                            duty_total = it.Where(it => it.accident_duty != "无责").Count(),
                            unduty_total = it.Where(it => it.accident_duty == "无责").Count(),
                            accident_total_fee = it.Where(it => it.accident_total_fee != null)?.ToList().Sum(it => it.accident_total_fee),
                            n_insurance_pay_fee = it.Where(it => it.n_insurance_pay_fee != null)?.ToList().Sum(it => it.n_insurance_pay_fee),
                            n_personal_fee = it.Where(it => it.n_personal_fee != null)?.ToList().Sum(it => it.n_personal_fee),
                            n_loss_fee = it.Where(it => it.n_loss_fee != null)?.ToList().Sum(it => it.n_loss_fee),
                        }).ToList();
                    break;
                case 2:
                    r = list.Select(it =>
                            new
                            {
                                it.driver_name,
                                it.line,
                                it.vehicle_number
                                ,
                                it.i_vehicle_id,
                                it.lincense_plate_number
                                ,
                                it.department_name
                                ,
                                it.accident_duty
                                ,
                                it.accident_total_fee
                                ,
                                it.n_insurance_pay_fee
                                ,
                                it.n_personal_fee
                                ,
                                it.n_loss_fee
                            }
                        )
                        .GroupBy(it => new
                        {
                            it.i_vehicle_id,
                            it.driver_name,
                            it.line,
                            it.vehicle_number,
                            it.lincense_plate_number,
                            it.department_name
                        })
                        .Select(it => new AccidentSummarySta
                        {
                            vehicle_id = it.Key.i_vehicle_id,
                            driver_name = it.Key.driver_name,
                            line = it.Key.line,
                            lincense_plate_number = it.Key.lincense_plate_number,
                            vehicle_number = it.Key.vehicle_number,
                            department_name = it.Key.department_name,
                            accident_total = it.ToList().Count,
                            duty_total = it.Where(it => it.accident_duty != "无责").Count(),
                            unduty_total = it.Where(it => it.accident_duty == "无责").Count(),
                            accident_total_fee = it.Where(it => it.accident_total_fee != null)?.ToList().Sum(it => it.accident_total_fee),
                            n_insurance_pay_fee = it.Where(it => it.n_insurance_pay_fee != null)?.ToList().Sum(it => it.n_insurance_pay_fee),
                            n_personal_fee = it.Where(it => it.n_personal_fee != null)?.ToList().Sum(it => it.n_personal_fee),
                            n_loss_fee = it.Where(it => it.n_loss_fee != null)?.ToList().Sum(it => it.n_loss_fee),
                        }).OrderBy(it => it.lincense_plate_number).ToList();
                    break;
                case 3:
                    r = list.Select(it =>
                        new
                        {
                            it.line
                            ,
                            it.department_name
                            ,
                            it.accident_duty
                            ,
                            it.accident_total_fee
                            ,
                            it.n_insurance_pay_fee
                            ,
                            it.n_personal_fee
                            ,
                            it.n_loss_fee
                        }
                    )
                    .GroupBy(it => new { it.line, it.department_name })
                    .Select(it => new AccidentSummarySta
                    {
                        line = it.Key.line,
                        department_name = it.Key.department_name,
                        accident_total = it.ToList().Count,
                        duty_total = it.Where(it => it.accident_duty != "无责").Count(),
                        unduty_total = it.Where(it => it.accident_duty == "无责").Count(),
                        accident_total_fee = it.Where(it => it.accident_total_fee != null)?.ToList().Sum(it => it.accident_total_fee),
                        n_insurance_pay_fee = it.Where(it => it.n_insurance_pay_fee != null)?.ToList().Sum(it => it.n_insurance_pay_fee),
                        n_personal_fee = it.Where(it => it.n_personal_fee != null)?.ToList().Sum(it => it.n_personal_fee),
                        n_loss_fee = it.Where(it => it.n_loss_fee != null)?.ToList().Sum(it => it.n_loss_fee),
                    }).ToList();
                    break;
                case 4:
                    r = list.Select(it =>
                            new
                            {
                                it.i_driver_id,
                                it.vehicle_number,
                                it.lincense_plate_number,
                                it.line,
                                it.driver_name
                                ,
                                it.department_name
                                ,
                                it.accident_duty
                                ,
                                it.accident_total_fee
                                ,
                                it.n_insurance_pay_fee
                                ,
                                it.n_personal_fee
                                ,
                                it.n_loss_fee
                            }
                        )
                        .GroupBy(it => new
                        {
                            it.i_driver_id,
                            it.vehicle_number,
                            it.lincense_plate_number,
                            it.line,
                            it.driver_name,
                            it.department_name
                        })
                        .Select(it => new AccidentSummarySta
                        {
                            driver_id = it.Key.i_driver_id,
                            vehicle_number = it.Key.vehicle_number,
                            lincense_plate_number = it.Key.lincense_plate_number,
                            line = it.Key.line,
                            driver_name = it.Key.driver_name,
                            department_name = it.Key.department_name,
                            accident_total = it.ToList().Count,
                            duty_total = it.Where(it => it.accident_duty != "无责").Count(),
                            unduty_total = it.Where(it => it.accident_duty == "无责").Count(),
                            accident_total_fee = it.Where(it => it.accident_total_fee != null)?.ToList().Sum(it => it.accident_total_fee),
                            n_insurance_pay_fee = it.Where(it => it.n_insurance_pay_fee != null)?.ToList().Sum(it => it.n_insurance_pay_fee),
                            n_personal_fee = it.Where(it => it.n_personal_fee != null)?.ToList().Sum(it => it.n_personal_fee),
                            n_loss_fee = it.Where(it => it.n_loss_fee != null)?.ToList().Sum(it => it.n_loss_fee),
                        }).OrderBy(it => it.driver_name).ToList();
                    break;
            }
            return r;
        }

        public async Task<bool> InvalidAccident(string server_id, List<decimal> context, ClientInformation client)
        {
            var list = await _dataImp.List(server_id, it => SqlFunc.ContainsArray(context, it.i_id));
            list.ForEach(item =>
            {
                item.i_update = client.i_id;
                item.d_update = DateTime.Now;
                item.state = 5;
            });
            return await _dataImp.Updatetable(server_id, list);
            throw new NotImplementedException();
        }

        public async Task<List<ErpAccidentMain>> ExtList(string serverId, List<ErpAccidentMain> list)
        {
            //车辆信息
            var vehicles = await _iVehicleInfoDataImp.ExtList(serverId, await _iVehicleInfoDataImp.List(serverId, it => SqlFunc.ContainsArray(list.Select(it => it.i_vehicle_id).ToList(), it.i_id)));
            //驾驶员信息
            var drvers = await _iSysPersonDataImp.List(serverId
                , it => SqlFunc.ContainsArray(list.Select(it => it.i_driver_id).ToList()
                , it.i_id)
                , new string[] { "I_ID", "D_BIRTHDAY", "D_FIRST_GET_LICENCE", "D_JOIN_COMPANY", "C_NAME" }
            );
            //线路信息
            var lines = await _lineRedisImp.GetAllAsync();
            //字典
            var dic = await _dictRedisManageImp.GetAllAsync();
            //事故原因
            var accidentReasons = await _iErpAccidentReasonDataImp.ExtList(serverId, await _iErpAccidentReasonDataImp.List(serverId, it => SqlFunc.ContainsArray(list.Select(it => it.i_id).ToList(), it.i_main_id)));
            //伤亡
            var casualties = await _iErpAccidentCasualtiesDataImp.ExtList(serverId, await _iErpAccidentCasualtiesDataImp.List(serverId, it => SqlFunc.ContainsArray(list.Select(it => it.i_id).ToList(), it.i_main_id)));
            //车损
            var damages = await _iErpAccidentDamageDataImp.ExtList(serverId, await _iErpAccidentDamageDataImp.List(serverId, it => SqlFunc.ContainsArray(list.Select(it => it.i_id).ToList(), it.i_main_id)));
            //事故资料
            var accidentDatas = await _iErpAccidentDataDataImp.ExtList(serverId, await _iErpAccidentDataDataImp.List(serverId, it => SqlFunc.ContainsArray(list.Select(it => it.i_id).ToList(), it.i_main_id)));
            //事故理赔
            var accidentCosts = await _iErpAccidentCostDataImp.List(serverId, it => SqlFunc.ContainsArray(list.Select(it => it.i_id).ToList(), it.accident_id));
            //事故地点类别
            //var acAdressTypes = await _iSysCommonDictDetailDataImp.List(serverId, it => SqlFunc.ContainsArray(list.Select(it => it.i_accident_address_type).ToList(), it.i_id));
            //事故类别
            //var acTypes = await _iSysCommonDictDetailDataImp.List(serverId, it => SqlFunc.ContainsArray(list.Select(it => it.i_accident_category).ToList(), it.i_id));
            //事故性质
            //var acNatures = await _iSysCommonDictDetailDataImp.List(serverId, it => SqlFunc.ContainsArray(list.Select(it => it.i_accident_nature).ToList(), it.i_id));
            //事故类型
            //var accidentTypes = await _iSysCommonDictDetailDataImp.List(serverId, it => SqlFunc.ContainsArray(list.Select(it => it.i_accident_type).ToList(), it.i_id));
            //事故责任
            //var acDutys = await _iSysCommonDictDetailDataImp.List(serverId, it => SqlFunc.ContainsArray(list.Select(it => it.i_accident_duty).ToList(), it.i_id));
            //经办人
            var persons = await _iSysPersonDataImp.List(serverId, it => SqlFunc.ContainsArray(list.Select(it => it.i_result_person).ToList(), it.i_id));
            //处理人
            var personDisposers = await _iSysPersonDataImp.List(serverId, it => SqlFunc.ContainsArray(list.Select(it => it.i_disposer_person).ToList(), it.i_id));
            //事故天气
            //var weathers = await _iSysCommonDictDetailDataImp.List(serverId, it => SqlFunc.ContainsArray(list.Select(it => it.i_accident_weather).ToList(), it.i_id));


            list.ForEach(item =>
            {
                if (vehicles.Count > 0 && vehicles.Exists(it => it.i_id == item.i_vehicle_id))
                {
                    var vehicle = vehicles.Find(it => it.i_id == item.i_vehicle_id);
                    item.vehicle_number = vehicle?.c_vehicle_number;
                    item.lincense_plate_number = vehicle?.c_lincense_plate_number;
                    item.department_name = vehicle?.department_name;
                    item.orgs = vehicle?.orgs;
                }
                if (drvers.Count > 0 && drvers.Exists(it => it.i_id == item.i_driver_id))
                {
                    var drver = drvers.Find(it => it.i_id == item.i_driver_id);
                    item.driver_name = drver?.c_name;
                    item.driver_msg = new DriverSlimMsg
                    {
                        age = drver?.age,
                        driving_year = drver?.driving_year,
                        working_year = drver?.work_year
                    };
                }
                if (lines != null && lines.Count > 0 && lines.Exists(it => it.id == item.i_line_id))
                {
                    item.line = lines.Find(it => it.id == item.i_line_id)?.name;
                }
                if (accidentReasons.Count > 0 && accidentReasons.Exists(it => it.i_main_id == item.i_id.ToString()))
                {
                    item.reasons = accidentReasons.Where(it => it.i_main_id == item.i_id.ToString()).ToList();
                    item.accident_reason = string.Join(",", accidentReasons.Where(it => it.i_main_id == item.i_id.ToString()).ToList().Select(it => it.reason));
                }
                if (casualties.Count > 0 && casualties.Exists(it => it.i_main_id == item.i_id))
                {
                    item.casualties = casualties.Where(it => it.i_main_id == item.i_id).ToList();
                }
                if (damages.Count > 0 && damages.Exists(it => it.i_main_id == item.i_id))
                {
                    item.damages = damages.Where(it => it.i_main_id == item.i_id).ToList();
                }
                if (accidentDatas.Count > 0 && accidentDatas.Exists(it => it.i_main_id == item.i_id))
                {
                    item.accident_datas = accidentDatas.Where(it => it.i_main_id == item.i_id && it.i_type == 2).ToList();
                    item.accident_imgs = accidentDatas.Where(it => it.i_main_id == item.i_id && it.i_type == 1).ToList();
                }
                if (accidentCosts.Count > 0 && accidentCosts.Exists(it => it.accident_id == item.i_id))
                {
                    item.accident_costs = accidentCosts.Where(it => it.accident_id == item.i_id && it.state == 3).ToList();
                    item.actual_fee = item.accident_costs?.Sum(it => it.actual_fee);
                }
                if (dic.Exists(it => it.i_id == item.i_accident_address_type))
                {
                    item.accident_address_type = dic.Find(it => it.i_id == item.i_accident_address_type)?.c_name;
                }
                if (dic.Exists(it => it.i_id == item.i_accident_category))
                {
                    item.accident_category = dic.Find(it => it.i_id == item.i_accident_category)?.c_name;
                }
                if (dic.Exists(it => it.i_id == item.i_accident_nature))
                {
                    item.accident_nature = dic.Find(it => it.i_id == item.i_accident_nature)?.c_name;
                }
                if (dic.Exists(it => it.i_id == item.i_accident_type))
                {
                    item.accident_type = dic.Find(it => it.i_id == item.i_accident_type)?.c_name;
                }
                if (dic.Exists(it => it.i_id == item.i_accident_duty))
                {
                    item.accident_duty = dic.Find(it => it.i_id == item.i_accident_duty)?.c_name;
                }
                if (persons.Exists(it => it.i_id == item.i_result_person))
                {
                    item.agent = persons.Find(it => it.i_id == item.i_result_person)?.c_name;
                }
                if (personDisposers.Exists(it => it.i_id == item.i_disposer_person))
                {
                    item.disposer = personDisposers.Find(it => it.i_id == item.i_disposer_person)?.c_name;
                }
                if (dic.Exists(it => it.i_id == item.i_accident_weather))
                {
                    item.accident_weather = dic.Find(it => it.i_id == item.i_accident_weather)?.c_name;
                }
            });

            return list;
        }

        public async Task<ErpAccidentMain> Detail(string server_id, decimal id, ClientInformation client)
        {
            var r = new ErpAccidentMain();
            var list = await List(server_id, it => it.i_id == id);
            if (list.Count > 0)
            {
                var all = await _iErpFlowRecordImp.GetListAsync(server_id, client.i_id,
                   new FlowRecordQuery()
                   {
                       detail_ids = list.Select(x => (int)x.i_id).ToList()
                   }
                );
                foreach (var item in list)
                {
                    if (item.state == 2)//处理中
                    {
                        var info = all.FirstOrDefault(x => x.detail_id == item.i_id);
                        if (info != null)
                        {
                            item.user_ids = info.state_child_id;
                            item.user_names = info.state_child_name;
                            if (item.flow_id != null && item.user_ids.Contains(client.i_id.Value))
                            {
                                item.ex_can_dispose = 1;
                            }
                            if (item.flow_id != null && info.created_id == client.i_id)
                            {
                                item.ex_can_cancel = 1;
                            }
                        }

                    }
                }
            }
            if (list.Count > 0)
            {
                r = list.FirstOrDefault();
            }
            return r;
        }
    }
}