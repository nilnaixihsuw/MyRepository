﻿using ERPCore.ORM;
using ERPDal.AccidentManage;
using ERPModel.AccidentManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using ERPCore.Entity;
using ERPCore;

namespace ERPBll.AccidentManage
{
    public class ErpAccidentDamageImp : BusinessRespository<ErpAccidentDamage, IErpAccidentDamageDataImp>, IErpAccidentDamageImp
    {
        public ErpAccidentDamageImp(IErpAccidentDamageDataImp dataImp) : base(dataImp)
        {

        }

        public async Task<bool> AddDamage(string server_id, ErpAccidentDamage context, ClientInformation client)
        {
            if (context.i_id != null && context.i_id > 0)
            {
                //编辑
                var old = await _dataImp.Get(server_id, context.i_id);
                context.i_created = old.i_created;
                context.d_created = old.d_created;
                context.i_update = client.i_id;
                context.d_update = DateTime.Now;
                return await _dataImp.Update(server_id, context);
            }
            else
            {
                //新增
                context.i_id = await _dataImp.GetId(server_id, "SEQ_COMMON");
                context.i_created = client.i_id;
                context.d_created = DateTime.Now;
                return await _dataImp.Insert(server_id, context);
            }

        }

        public async Task<(bool, string)> EditDamage(string server_id, ErpAccidentDamage context, ClientInformation client)
        {
            //编辑
            var old = await _dataImp.Get(server_id, context.i_id);
            context.i_created = old.i_created;
            context.d_created = old.d_created;
            context.i_update = client.i_id;
            context.d_update = DateTime.Now;
            var res = await _dataImp.Update(server_id, context);
            var str = "";
            if (res)
            {
                str = Tools.CompareClass(old, context);
            }

            return (res, str);
        }
    }
}