﻿using ERPCore.ORM;
using ERPDal.SafeManage;
using ERPModel.SafeManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using ERPModel.AccidentManage;
using ERPDal.AccidentManage;

namespace ERPBll.AccidentManage
{
    public class ErpInsuranceMainImp : BusinessRespository<ErpInsuranceMain, IErpInsuranceMainDataImp>, IErpInsuranceMainImp
    {
        public ErpInsuranceMainImp(IErpInsuranceMainDataImp dataImp): base(dataImp)
        {

        }
    }
}