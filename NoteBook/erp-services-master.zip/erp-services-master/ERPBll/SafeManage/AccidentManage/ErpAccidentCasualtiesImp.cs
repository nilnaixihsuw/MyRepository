﻿using ERPCore.ORM;
using ERPDal.AccidentManage;
using ERPModel.AccidentManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using ERPCore.Entity;
using ERPCore;
using ERPModel.ApiModel;
using System.Linq.Expressions;
using ERPDal.UserManage;

namespace ERPBll.AccidentManage
{
    public class ErpAccidentCasualtiesImp : BusinessRespository<ErpAccidentCasualties, IErpAccidentCasualtiesDataImp>, IErpAccidentCasualtiesImp
    {
        private readonly ISysPersonDataImp _iSysPersonDataImp;
        public ErpAccidentCasualtiesImp(
            ISysPersonDataImp iSysPersonDataImp,
            IErpAccidentCasualtiesDataImp dataImp) : base(dataImp)
        {
            _iSysPersonDataImp = iSysPersonDataImp;
        }

        public async Task<bool> AddCasualties(string server_id, ErpAccidentCasualties context, ClientInformation client)
        {
            if (context.i_id != null && context.i_id > 0)
            {
                //编辑
                var old = await _dataImp.Get(server_id, context.i_id);
                context.i_created = old.i_created;
                context.d_created = old.d_created;
                context.i_update = client.i_id;
                context.d_update = DateTime.Now;
                return await _dataImp.Update(server_id, context);
            }
            else
            {
                //新增
                context.i_id = await _dataImp.GetId(server_id, "SEQ_COMMON");
                context.i_created = client.i_id;
                context.d_created = DateTime.Now;
                return await _dataImp.Insert(server_id, context);
            }
        }

        public async Task<(bool, string)> EditCasualties(string server_id, ErpAccidentCasualties context, ClientInformation client)
        {
            //编辑
            var old = await _dataImp.Get(server_id, context.i_id);
            context.i_created = old.i_created;
            context.d_created = old.d_created;
            context.i_update = client.i_id;
            context.d_update = DateTime.Now;
            var res = await _dataImp.Update(server_id, context);

            var str = "";
            if (res)
            {
                str = Tools.CompareClass(old, context);
            }

            return (res, str);
        }

        public async Task<Tuple<List<ErpAccidentCasualties>, int>> ListCasualties(string server_id, ErpAccidentCasualtiesRequest request, string v, int page_size, int page_index, string orderby)
        {
            //var exp = await GetExp(request);
            return await ExtensionList(server_id, request.ToExp(), v, page_size, page_index, orderby);
        }

        private async Task<List<Expression<Func<ErpAccidentCasualties, bool>>>> GetExp(ErpAccidentCasualtiesRequest request)
        {
            var r = new List<Expression<Func<ErpAccidentCasualties, bool>>>();
            if (request.orgs != null)
            {
                if (request.orgs.Count > 0)
                {
                    var emps = await _iSysPersonDataImp.List(request.server_id, it => SqlFunc.ContainsArray(request.orgs.Select(it => it.ToString()).ToList(), it.i_department_base));
                    if (emps != null && emps.Count > 0)
                    {
                        r.Add(it => SqlFunc.ContainsArray(emps.Select(it => it.i_id).ToList(), it.i_person_id));
                    }
                }
                else
                {
                    r.Add(it => false);
                }
            }
            else
            {
                r.Add(it => true);
            }
            return r;
        }

        public async Task<List<ErpAccidentCasualties>> ListCasualties(string server_id, ErpAccidentCasualtiesRequest request, string v, string orderby)
        {
            //var exp = await GetExp(request);
            return await ExtensionList(server_id, request.ToExp(), v, orderby);
        }
    }
}