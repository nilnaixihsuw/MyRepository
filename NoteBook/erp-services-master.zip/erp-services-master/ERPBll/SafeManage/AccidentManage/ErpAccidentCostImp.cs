﻿using ERPCore.ORM;
using ERPDal.SafeManage;
using ERPModel.SafeManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using ERPCore.Entity;
using ERPDal.AccidentManage;
using ERPModel.AccidentManage;

namespace ERPBll.AccidentManage
{
    public class ErpAccidentCostImp : BusinessRespository<ErpAccidentCost, IErpAccidentCostDataImp>, IErpAccidentCostImp
    {
        public ErpAccidentCostImp(IErpAccidentCostDataImp dataImp): base(dataImp)
        {

        }

        public async Task<bool> AddCost(string server_id, ErpAccidentCost context, ClientInformation client)
        {
            if (context.id != null && context.id > 0)
            {
                //编辑
                context.update_id = client.i_id;
                context.update_date = DateTime.Now;
                var old = await Get(server_id, context.id);
                context.created_date = old.created_date;
                context.created_id = old.created_id;
                return await _dataImp.Update(server_id, context);
            }
            else
            {
                //新增
                context.id = await _dataImp.GetId(server_id, "SEQ_COMMON");
                context.created_id = client.i_id;
                context.created_date = DateTime.Now;
                return await _dataImp.Insert(server_id, context);
            }
        }

        public async Task<(bool, string)> EditCost(string server_id, ErpAccidentCost context, ClientInformation client)
        {
            //编辑
            context.update_id = client.i_id;
            context.update_date = DateTime.Now;
            var old = await Get(server_id, context.id);
            context.created_date = old.created_date;
            context.created_id = old.created_id;

            var res = await _dataImp.Update(server_id, context);
            var str = "";
            if (res)
            {
                str = Tools.CompareClass(old, context);
            }
            return (res, str);
        }
    }
}