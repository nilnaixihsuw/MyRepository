﻿using ERPCore.ORM;
using ERPModel.AccidentManage;
using ERPModel.SafeManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.AccidentManage
{
    public interface IErpInsuranceMainImp : IBusinessRepository<ErpInsuranceMain>
    {
    }
}