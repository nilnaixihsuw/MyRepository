﻿using ERPCore.ORM;
using ERPDal.AccidentManage;
using ERPModel.AccidentManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using ERPCore.Entity;
using ERPCore;

namespace ERPBll.AccidentManage
{
    public class ErpAccidentDataImp : BusinessRespository<ErpAccidentData, IErpAccidentDataDataImp>, IErpAccidentDataImp
    {
        public ErpAccidentDataImp(IErpAccidentDataDataImp dataImp) : base(dataImp)
        {

        }

        public async Task<bool> AddAccidentData(string server_id, ErpAccidentData context, ClientInformation client)
        {
            context.i_id = await _dataImp.GetId(server_id, "SEQ_COMMON");
            return await _dataImp.Insert(server_id, context);
        }

        public async Task<bool> BatchDelete(string server_id, List<decimal> context)
        {
            var list = await _dataImp.List(server_id, it => SqlFunc.ContainsArray(context, it.i_id));
            return await _dataImp.Deletetable(server_id, list);
        }

        public async Task<List<ErpAccidentData>> QueryAccidentData(string server_id, decimal id, int type)
        {
            var exp = Expressionable.Create<ErpAccidentData>()
                                    .AndIF(type > 0, it => it.i_type == type)
                                    .AndIF(id > 0, it => it.i_main_id == id)
                                    .ToExpression();
            var list = await _dataImp.List(server_id, exp);
            var r = await _dataImp.ExtList(server_id, list);
            return r;
        }
    }
}