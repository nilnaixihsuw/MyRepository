﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPModel.AccidentManage;
using ERPModel.SafeManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.AccidentManage
{
    public interface IErpAccidentCostImp : IBusinessRepository<ErpAccidentCost>
    {
        Task<bool> AddCost(string server_id, ErpAccidentCost context, ClientInformation client);

        Task<(bool, string)> EditCost(string server_id, ErpAccidentCost context, ClientInformation client);
    }
}