﻿using ERPDal.Repository;
using ERPModel.Repairs.MaintOrderMaterials;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.Repairs.Contracts
{
    public interface IMaintRepairRefundImp : IBaseBusiness<MaintRepairRefund>
    {
        Task<Tuple<int, List<RepairRefundDto>>> GetByPage(RepairRefundRequest request);
    }
}
