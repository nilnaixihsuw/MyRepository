﻿using ERPDal.Repository;
using ERPModel.Repairs.MaintNoticeRule;
using System;
using System.Collections.Generic;
using System.Text;

namespace ERPBll.Repairs.Contracts
{
    public interface IMaintNoticeRuleImp : IBaseBusiness<MaintNoticeRule>
    {

    }
}
