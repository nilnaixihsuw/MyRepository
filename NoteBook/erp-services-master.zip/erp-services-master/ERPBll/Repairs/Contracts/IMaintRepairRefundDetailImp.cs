﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using ERPDal.Repository;
using ERPModel.Repairs.MaintOrderMaterials;

namespace ERPBll.Repairs.Contracts
{
    public interface IMaintRepairRefundDetailImp : IBaseBusiness<MaintRepairRefundDetail>
    {
        Task<List<MaintRepairRefundDetail>> GetData(string server_id, Expression<Func<MaintRepairRefundDetail, bool>> expression);
    }
}
