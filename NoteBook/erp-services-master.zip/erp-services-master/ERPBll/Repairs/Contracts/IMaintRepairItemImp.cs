﻿using ERPModel.Repairs.MaintRepairHours;
using ERPModel.Repairs.MaintRepairItems;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.Repairs.Contracts
{
    /// <summary>
    /// 维修项目
    /// </summary>
    public interface IMaintRepairItemImp
    {
        /// <summary>
        /// 获取工单维修项目
        /// </summary>
        Task<List<MaintRepairItem>> GetByOrderId(string server_id, int order_id);

        /// <summary>
        /// 获取平阳工单维修项目
        /// </summary>
        Task<List<MaintRepairDispatch>> GetItems(string server_id, int order_id);

        /// <summary>
        /// 新增
        /// </summary>
        Task<List<MaintRepairItemDto>> AddAsync(
            string server_id, decimal? user_id, List<CreateOrUpdateMaintRepairItem> input);

        /// <summary>
        /// 追加
        /// </summary>
        Task<MaintRepairItemDto> AddToAsync(
            string server_id, decimal? user_id, CreateOrUpdateMaintRepairItem input);

        /// <summary>
        /// 修改
        /// </summary>
        Task<MaintRepairItemDto> UpdateAsync(
           string server_id, decimal? user_id, CreateOrUpdateMaintRepairItem input);

        /// <summary>
        /// 根据id删除
        /// </summary>
        Task<int> DeleteByIdsAsync(string server_id, List<int> ids);

        /// <summary>
        /// 根据工单删除
        /// </summary>
        Task<int> DeleteByOrderAsync(string server_id, List<int> order_ids);

        /// <summary>
        /// 获取工时统计报表数据--丽水
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        Task<List<HourReportDto>> GetHourReport(HourReportQuery request);

        /// <summary>
        /// 获取工时统计报表明细数据--丽水
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        Task<Tuple<int, List<HourDetailDto>>> GetHourDetail(HourDetailQuery request);

        /// <summary>
        /// 获取全部维修人员
        /// </summary>
        /// <param name="server_id"></param>
        /// <returns></returns>
        Task<List<RepairPerson>> GetPersons(string server_id);
    }
}
