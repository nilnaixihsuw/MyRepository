﻿using ERPDal.Repository;
using ERPModel.Repairs;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.Repairs.Contracts
{
    public interface IMaintRepairHourRulesImp: IBaseBusiness<MaintRepairHourRules>
    {
        /// <summary>
        /// 删除全部记录
        /// </summary>
        /// <param name="serverId"></param>
        /// <returns></returns>
        Task<bool> Delete(string serverId);
    }
}
