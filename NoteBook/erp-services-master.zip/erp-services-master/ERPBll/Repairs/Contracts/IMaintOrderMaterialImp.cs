﻿using ERPDal.Repository;
using ERPModel.Repairs.MaintOrderMaterials;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.Repairs.Contracts
{
    public interface IMaintOrderMaterialImp:IBaseBusiness<MaintOrderMaterial>
    {
        /// <summary>
        /// 获取车辆出库单记录
        /// </summary>
        Task<List<string>> GetByVehIdAsync(string server_id, DateTime? start_date, DateTime? end_date, string lp_num);

        /// <summary>
        /// 获取出库单详情
        /// </summary>
        Task<List<MaintOrderMaterialDto>> GetByLeaveNumAsync(string server_id, string leave_num);

        /// <summary>
        /// 获取工单物料
        /// </summary>
        Task<List<MaintOrderMaterialDto>> GetByWorkCodeAsync(string server_id, string work_code);

        /// <summary>
        /// 保存工单物料
        /// </summary>
        Task AddAsync(string server_id, decimal? user_id, CreateMaintOrderMaterial input);

        /// <summary>
        /// 删除
        /// </summary>
        Task<int> DeleteAsync(string server_id, string work_code);
    }
}
