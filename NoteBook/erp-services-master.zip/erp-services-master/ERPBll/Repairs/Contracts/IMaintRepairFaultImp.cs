﻿using ERPModel.Repairs.MaintRepairFaults;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.Repairs.Contracts
{
    /// <summary>
    /// 维修故障
    /// </summary>
    public interface IMaintRepairFaultImp
    {
        /// <summary>
        /// 获取故障
        /// </summary>
        Task<List<MaintRepairFault>> GetByRepairId(string server_id, int repair_id);

        /// <summary>
        /// 新增
        /// </summary>
        Task<List<int>> AddAsync(string server_id, decimal? user_id, int repair_id, List<int> fault_ids);

        /// <summary>
        /// 删除
        /// </summary>
        Task<int> DeleteAsync(string server_id, decimal repair_id);
    }
}
