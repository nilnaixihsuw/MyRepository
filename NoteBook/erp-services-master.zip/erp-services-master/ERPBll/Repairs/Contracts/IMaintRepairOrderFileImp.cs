﻿using ERPDal.Repository;
using ERPModel.Repairs.MaintRepairOrderFiles;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.Repairs.Contracts
{
    /// <summary>
    /// 维修工单资料
    /// </summary>
    public interface IMaintRepairOrderFileImp : IBaseBusiness<MaintRepairOrderFile>
    {
        /// <summary>
        /// 获取工单资料
        /// </summary>
        Task<List<MaintRepairOrderFileDto>> GetByOrderIdAsync(string server_id, int order_id);

        /// <summary>
        /// 新增
        /// </summary>
        Task<List<MaintRepairOrderFileDto>> AddAsync(
            string server_id, decimal? user_id, List<CreateMaintRepairOrderFile> input);

        /// <summary>
        /// 删除
        /// </summary>
        Task<int> DeleteAsync(string server_id, List<int> order_ids);
    }
}
