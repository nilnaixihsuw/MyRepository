﻿using ERPModel.Repairs.MaintRegisterImgs;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.Repairs
{
    /// <summary>
    /// 报修相关图片
    /// </summary>
    public interface IMaintRegisterImgImp
    {
        /// <summary>
        /// 新增
        /// </summary>
        Task<List<string>> AddAsync(
            string server_id, decimal? user_id, int repair_id, List<string> imgs);

        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="repair_id"></param>
        /// <returns></returns>
        Task<int> DeleteAsync(string server_id, decimal repair_id);
    }
}
