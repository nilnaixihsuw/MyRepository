﻿using ERPModel.Repairs.MaintStatistics;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.Repairs.Contracts
{
    /// <summary>
    /// 维修统计
    /// </summary>
    public interface IMaintStatisticsImp
    {
        /// <summary>
        /// 维修类型统计
        /// </summary>
        Task<(List<RepairTypeCountDto>, int)> GetRepairTypeCountAsync(RepairCountQuery query);

        /// <summary>
        /// 故障类型统计
        /// </summary>
        Task<(List<RepairFaultCountDto>, int)> GetRepairFaultCountAsync(RepairCountQuery query);

        /// <summary>
        /// 根据车型统计
        /// </summary>
        Task<(List<RepairVehKindCountDto>, int)> GetRepairVehKindCountAsync(RepairCountQuery query);

        /// <summary>
        /// 根据分公司统计
        /// </summary>
        Task<(List<RepairDepCountDto>, int)> GetRepairDepCountAsync(RepairCountQuery query);

        /// <summary>
        /// 根据维修厂统计
        /// </summary>
        Task<(List<RepairMaintDepCountDto>, int)> GetRepairMaintDepCountAsync(RepairCountQuery query);

        /// <summary>
        /// 根据接修人统计
        /// </summary>
        Task<(List<RepairPersonCountDto>, int)> GetRepairPersonCountAsync(RepairCountQuery query);
    }
}
