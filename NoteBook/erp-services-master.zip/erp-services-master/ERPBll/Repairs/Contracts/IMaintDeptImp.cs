﻿using ERPModel.UserManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.Repairs.Contracts
{
    public interface IMaintDeptImp
    {
        /// <summary>
        /// 获取维修组织
        /// </summary>
        Task<object> GetDepartmentAsync(string server_id, decimal? user_id);

        /// <summary>
        /// 获取维修班组
        /// </summary>
        Task<object> GetShopAsync(string server_id, decimal? user_id, decimal? dept_id);

        /// <summary>
        /// 获取维修人员
        /// </summary>
        Task<object> GetPersonAsync(string server_id, decimal? user_id, decimal? dept_id, decimal? shop_id);

        /// <summary>
        /// 获取维修项目
        /// </summary>
        Task<object> GetItemAsync(string server_id, decimal? user_id, decimal? group_id);

        /// <summary>
        /// 调整班组排序
        /// </summary>
        /// <param name="request"></param>
        /// <param name="server_id"></param>
        /// <returns></returns>
        Task<bool> ChangeShopSort(List<ChangeSortDetail> request, string server_id);
    }
}
