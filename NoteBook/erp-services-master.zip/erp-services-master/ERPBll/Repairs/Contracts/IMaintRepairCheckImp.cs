﻿using ERPModel.Repairs.MaintRepairChecks;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.Repairs.Contracts
{
    /// <summary>
    /// 维修检验
    /// </summary>
    public interface IMaintRepairCheckImp
    {
        /// <summary>
        /// 获取检验信息
        /// </summary>
        Task<MaintRepairCheck> GetByRepairIdAsync(string server_id, int repair_id);

        /// <summary>
        /// 新增
        /// </summary>
        Task<MaintRepairCheckDto> AddAsync(string server_id, decimal? user_id, CreateOrUpdateMaintRepairCheck input);

        /// <summary>
        /// 编辑
        /// </summary>
        Task<MaintRepairCheckDto> UpdateAsync(string server_id, decimal? user_id, CreateOrUpdateMaintRepairCheck input);

        /// <summary>
        /// 删除
        /// </summary>
        Task<int> DeleteAsync(string server_id, decimal repair_id);
    }
}
