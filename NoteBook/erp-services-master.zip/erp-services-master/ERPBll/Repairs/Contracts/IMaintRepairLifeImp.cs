﻿using ERPModel.Repairs.MaintRepairLifes;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.Repairs.Contracts
{
    public interface IMaintRepairLifeImp
    {
        Task<List<MaintRepairLifeDto>> GetByRepairIdAsync(string server_id, int repair_id, int order_id);
    }
}
