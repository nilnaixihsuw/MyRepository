﻿using ERPDal.Repository;
using ERPModel.Repairs.MaintRepairOrders;
using System;
using System.Collections.Generic;
using System.Text;

namespace ERPBll.Repairs.Contracts
{
    public interface IErpCompleteJobHistoryImp : IBaseBusiness<ErpCompleteJobHistory>
    {

    }
}
