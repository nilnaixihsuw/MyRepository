﻿using ERPDal.Repository;
using ERPModel.Repairs.MaintOrderMaterials;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.Repairs.Contracts
{
    public interface IMaintRepairPickImp : IBaseBusiness<MaintRepairPick>
    {
        Task<Tuple<int, List<RepairPickDto>>> GetByPage(RepairPickRequest request);
    }
}
