﻿using ERPDal.Repository;
using ERPModel.Repairs.MaintRepairPackage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.Repairs.Contracts
{
    public interface IMaintRepairPackageImp : IBaseBusiness<MaintRepairPackage>
    {
        Task<Tuple<int, List<MaintRepairPackageDto>>> GetByPageAsync(MaintRepairPackageQuery request);
    }
}
