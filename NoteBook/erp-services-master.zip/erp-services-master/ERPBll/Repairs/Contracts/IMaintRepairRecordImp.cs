﻿using ERPDal.Repository;
using ERPModel.Repairs;
using ERPModel.Repairs.MaintRepairChecks;
using ERPModel.Repairs.MaintRepairOrders;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.Repairs
{
    /// <summary>
    /// 维修记录
    /// </summary>
    public interface IMaintRepairRecordImp : IBaseBusiness<MaintRepairRecord>
    {
        /// <summary>
        /// 分页获取
        /// </summary>
        Task<(List<MaintRepairRecordDto>, int)> GetByPageAsync(
            string server_id, decimal? user_id, MaintRepairRecordQuery query);

        /// <summary>
        /// 获取报修信息
        /// </summary>
        Task<MaintRepairRecordDto> GetByIdAsync(string server_id, int id);

        /// <summary>
        /// 新增
        /// </summary>
        Task<MaintRepairRecordDto> AddAsync(
            string server_id, decimal? user_id, CreateOrUpdateMaintRepairRecord input);

        /// <summary>
        /// 编辑
        /// </summary>
        Task<MaintRepairRecordDto> UpdateAsync(
            string server_id, decimal? user_id, CreateOrUpdateMaintRepairRecord input);

        /// <summary>
        /// 删除
        /// </summary>
        Task<List<MaintRepairRecord>> DeleteManyAsync(string server_id, List<decimal> ids);

        /// <summary>
        /// 导出报修单
        /// </summary>
        /// <param name="fileName">文件名</param>
        /// <param name="savePath">文件地址</param>
        /// <param name="context">文件内容</param>
        /// <returns></returns>
        Task SaveRepairTable(string fileName, string savePath, MaintRepairRecordDto context);

        void UpdateRepairCodeMessage(MaintRepairCheck data);

        void UpdateStateMessage(MaintRepairOrder data);
    }
}
