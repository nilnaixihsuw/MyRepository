﻿using ERPModel.Repairs.MaintRepairFees;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using static ERPModel.ApiModel.TicketManage.RevenueSummary;

namespace ERPBll.Repairs.Contracts
{
    /// <summary>
    /// 工单结算
    /// </summary>
    public interface IMaintRepairFeeImp
    {
        /// <summary>
        /// 获取工单信息
        /// </summary>
        Task<MaintRepairFeeDto> GetByOrderIdAsync(string server_id, int order_id);

        /// <summary>
        ///  新增
        /// </summary>
        Task<MaintRepairFeeDto> AddAsync(string server_id, decimal? user_id, CreateOrUpdateMaintRepairFee input);

        /// <summary>
        /// 编辑
        /// </summary>
        Task<MaintRepairFeeDto> UpdateAsync(string server_id, decimal? user_id, CreateOrUpdateMaintRepairFee input);

        /// <summary>
        /// 结算
        /// </summary>
        Task<List<MaintRepairFeeDto>> UpdateStateAsync(string server_id, decimal? user_id, UpdateState input);

        /// <summary>
        /// 按车辆汇总维修费用
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        Task<List<VehicleRepairFeeDto>> GetRepairFeeByVehicle(VehicleRepairFeeQuery request);

        /// <summary>
        /// 获取表头
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="summary_type">统计类型(1.按线路 2.按车辆)</param>
        /// <param name="type">区分类型(1.显示供应商 2.不显示供应商)</param>
        /// <returns></returns>
        Task<List<RevenueTitle>> GetTitle(string server_id, int summary_type, int type);

        /// <summary>
        /// 根据车辆统计
        /// </summary>
        /// <param name="server_id"></param>
        /// <returns></returns>
        Task<List<Dictionary<string, object>>> GetTotalByVehicleAsync(VehicleRepairFeeQuery request);

        /// <summary>
        /// 根据线路统计
        /// </summary>
        /// <param name="server_id"></param>
        /// <returns></returns>
        Task<List<Dictionary<string, object>>> GetTotalByLineAsync(LineRepairFeeQuery request);
    }
}
