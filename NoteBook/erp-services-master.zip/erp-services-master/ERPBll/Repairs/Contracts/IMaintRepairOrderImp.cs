﻿using ERPDal.Repository;
using ERPModel.Repairs.MaintRepairChecks;
using ERPModel.Repairs.MaintRepairOrders;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.Repairs.Contracts
{
    /// <summary>
    /// 工单管理
    /// </summary>
    public interface IMaintRepairOrderImp : IBaseBusiness<MaintRepairOrder>
    {
        /// <summary>
        /// 分页获取
        /// </summary>
        Task<(List<MaintRepairOrderDto>, int)> GetByPageAsync(
            string server_id, decimal? user_id, MaintRepairOrderQuery query);

        /// <summary>
        /// 获取统计数
        /// </summary>
        Task<Count> GetCount(string server_id, decimal? user_id, MaintRepairOrderQuery query);

        /// <summary>
        /// 获取工单进度
        /// </summary>
        Task<List<MaintRepairOrderStepDto>> GetStepByIdAsync(string server_id, int id);

        /// <summary>
        /// 导出结算单
        /// </summary>
        /// <param name="fileName">文件名称</param>
        /// <param name="savePath">文件地址</param>
        /// <param name="context">打印内容</param>
        /// <returns></returns>
        Task SaveRepairTable(string fileName, string savePath, MaintRepairOrderDto context);

        /// <summary>
        /// 工单统计
        /// </summary>
        Task<int> GetOrderTotalData(string server_id, decimal? user_id, MaintRepairOrderQuery query);

        /// <summary>
        /// 维修平均时长
        /// </summary>
        Task<double> GetOrderAvgTime(string server_id, decimal? user_id, MaintRepairOrderQuery query);

        /// <summary>
        /// 生成工单
        /// </summary>
        void AddRepairOrderMessage(MaintRepairCheck input);

        /// <summary>
        /// 编辑
        /// </summary>
        Task<MaintRepairOrderDto> UpdateAsync(string server_id, decimal? user_id, UpdateMaintRepairOrder input);

        /// <summary>
        /// 更改状态
        /// </summary>
        Task<MaintRepairOrderDto> UpdateStateAsync(
            string server_id, decimal? user_id, UpdateMaintRepairOrderState input);

        /// <summary>
        /// 报废
        /// </summary>
        Task<List<MaintRepairOrderDto>> UpdateScrapAsync(string server_id, decimal? user_id, List<int> ids);

        /// <summary>
        /// 分页获取无流程工单
        /// </summary>
        Task<(List<MaintRepairOrderSimpleDto>, int)> GetByPageSimpleAsync(
            string server_id, decimal? user_id, MaintRepairOrderQuery query);

        /// <summary>
        /// 新增无流程工单
        /// </summary>
        Task<MaintRepairOrderSimpleDto> AddSimpleAsync(
            string server_id, decimal? user_id, CreateMaintRepairOrder input);

        /// <summary>
        /// 修改无流程工单
        /// </summary>
        Task<MaintRepairOrderSimpleDto> UpdateSimpleAsync(
            string server_id, decimal? user_id, CreateMaintRepairOrder input);

        /// <summary>
        /// 删除工单
        /// </summary>
        Task DeleteManyAsync(string server_id, List<decimal> ids);

        /// <summary>
        /// 获取工单简要信息
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        Task<List<MaintRepairOrderDto>> GetDataAsync(MaintRepairOrderQuery query);

        /// <summary>
        /// 获取最近10天的简要工单信息
        /// </summary>
        /// <param name="server_id"></param>
        /// <returns></returns>
        Task<List<MaintRepairOrderDto>> GetSimpleDataAsync(DateTime? start, DateTime? end, string server_id = "60.191.59.11");
    }
}
