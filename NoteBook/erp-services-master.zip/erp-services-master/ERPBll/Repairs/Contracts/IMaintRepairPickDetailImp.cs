﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using ERPDal.Repository;
using ERPModel.Repairs.MaintOrderMaterials;

namespace ERPBll.Repairs.Contracts
{
    public interface IMaintRepairPickDetailImp : IBaseBusiness<MaintRepairPickDetail>
    {
        /// <summary>
        /// 获取明细物料信息
        /// </summary>
        Task<List<MaintRepairPickDetail>> GetData(string server_id, Expression<Func<MaintRepairPickDetail, bool>> expression);
    }
}
