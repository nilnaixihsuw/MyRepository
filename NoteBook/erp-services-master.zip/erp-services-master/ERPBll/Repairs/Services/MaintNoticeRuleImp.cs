﻿using ERPDal.Repository;
using ERPModel.Repairs.MaintNoticeRule;
using System;
using System.Collections.Generic;
using System.Text;

namespace ERPBll.Repairs.Contracts
{
    public class MaintNoticeRuleImp : BaseBusiness<MaintNoticeRule>, IMaintNoticeRuleImp
    {

    }
}
