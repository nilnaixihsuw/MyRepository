﻿using AutoMapper;
using ERPBll.Repairs.Contracts;
using ERPDal;
using ERPDal.Repository;
using ERPModel.MaterialManage.BaseinfoManage;
using ERPModel.MaterialManage.InventoryManage;
using ERPModel.Repairs.MaintOrderMaterials;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.Repairs.Services
{
    /// <summary>
    /// 工单物料
    /// </summary>
    public class MaintOrderMaterialImp: BaseBusiness<MaintOrderMaterial>, IMaintOrderMaterialImp
    {
        private readonly IMapper _imapper;

        public MaintOrderMaterialImp(
            IMapper imapper)
        {
            _imapper = imapper;
        }

        public async Task<List<string>> GetByVehIdAsync(string server_id, DateTime? start_date, DateTime? end_date, string lp_num)
        {
            var query = await SqlSugarHelper.DBClient(server_id)
                              .Queryable<ErpLeaveInventoryRecord>()
                              .Where(x => x.lp_num == lp_num)
                              .WhereIF(start_date.HasValue && end_date.HasValue, x => x.leave_date >= start_date && x.leave_date <= end_date)
                              .Select(x => x.leave_num)
                              .ToListAsync();

            return query;
        }

        public async Task<List<MaintOrderMaterialDto>> GetByLeaveNumAsync(string server_id, string leave_num)
        {
            var query = await SqlSugarHelper.DBClient(server_id)
                              .Queryable<ErpLeaveInventoryRecord>()
                              .Where(x => x.leave_num == leave_num)
                              .Mapper(x => x.pick_info, x => x.pick_id)
                              .Mapper(x => x.house_info, x => x.house_id)
                              .Mapper(async x =>
                              {
                                  x.details = await SqlSugarHelper.DBClient(server_id)
                                               .Queryable<ErpLeaveInventory>()
                                               .Where(i => i.main_id == x.id)
                                               .Mapper(async i =>
                                               {
                                                   i.material_info = await SqlSugarHelper.DBClient(server_id)
                                                             .Queryable<ErpMaterialMain>()
                                                             .Mapper(x => x.measure_unit_info, x => x.measure_unit)
                                                             .FirstAsync(t => t.id == i.material_id);

                                                   i.details = await SqlSugarHelper.DBClient(server_id)
                                                             .Queryable<ErpLeaveInventoryDetail>()
                                                             .Where(t => t.main_id == i.id)
                                                             .ToListAsync();
                                               })
                                               .ToListAsync();
                              })
                              .ToListAsync();

            var list = new List<MaintOrderMaterialDto>();
            foreach (var item in query)
            {
                foreach (var child in item.details)
                {
                    var info = _imapper.Map<ErpLeaveInventoryRecord, MaintOrderMaterialDto>(item);
                    _imapper.Map<ErpLeaveInventory, MaintOrderMaterialDto>(child, info);

                    foreach (var detail in child.details)
                    {
                        _imapper.Map<ErpLeaveInventoryDetail, MaintOrderMaterialDto>(detail, info);
                        
                    }
                    list.Add(info);
                } 
            }

            return list.OrderBy(x => x.leave_num).ThenBy(x => x.material_id).ToList();
        }

        public async Task<List<MaintOrderMaterialDto>> GetByWorkCodeAsync(string server_id, string work_code)
        {
            var nums = await SqlSugarHelper.DBClient(server_id)
                              .Queryable<MaintOrderMaterial>()
                              .Where(x => x.work_code == work_code)
                              .Select(x => x.leave_num)
                              .ToListAsync();

            var query = await SqlSugarHelper.DBClient(server_id)
                              .Queryable<ErpLeaveInventoryRecord>()
                              .Where(x => nums.Contains(x.leave_num))
                              .Mapper(x => x.pick_info, x => x.pick_id)
                              .Mapper(x => x.house_info, x => x.house_id)
                              .Mapper(async x =>
                              {
                                  x.details = await SqlSugarHelper.DBClient(server_id)
                                               .Queryable<ErpLeaveInventory>()
                                               .Where(i => i.main_id == x.id)
                                               .Mapper(i => i.details, i => i.details.First().main_id)
                                               .Mapper(async i =>
                                               {
                                                   i.material_info = await SqlSugarHelper.DBClient(server_id)
                                                             .Queryable<ErpMaterialMain>()
                                                             .Mapper(x => x.measure_unit_info, x => x.measure_unit)
                                                             .FirstAsync(t => t.id == i.material_id);
                                               })
                                               .ToListAsync();
                              })
                              .ToListAsync();

            var list = new List<MaintOrderMaterialDto>();
            foreach (var item in query)
            {
                foreach (var child in item.details)
                {
                    var info = _imapper.Map<ErpLeaveInventoryRecord, MaintOrderMaterialDto>(item);
                    _imapper.Map<ErpLeaveInventory, MaintOrderMaterialDto>(child, info);

                    foreach (var detail in child.details)
                    {
                        _imapper.Map<ErpLeaveInventoryDetail, MaintOrderMaterialDto>(detail, info);

                    }
                    list.Add(info);
                }
            }

            return list.OrderBy(x => x.leave_num).ThenBy(x => x.material_id).ToList();
        }

        public async Task AddAsync(string server_id, decimal? user_id, CreateMaintOrderMaterial input)
        {
            await DeleteAsync(server_id, input.work_code);

            if (input.leave_nums != null && input.leave_nums.Count > 0)
            {
                var list = new List<MaintOrderMaterial>();
                input.leave_nums.ForEach(x =>
                {
                    var info = new MaintOrderMaterial();
                    info.SetCreate(input.work_code, x, user_id);
                    list.Add(info);
                });

                await SqlSugarHelper.DBClient(server_id).Insertable(list).ExecuteCommandAsync();
            }
        }

        public async Task<int> DeleteAsync(string server_id, string work_code)
        {
            return await SqlSugarHelper.DBClient(server_id)
                    .Deleteable<MaintOrderMaterial>()
                    .Where(x => x.work_code == work_code)
                    .ExecuteCommandAsync();
        }
    }
}
