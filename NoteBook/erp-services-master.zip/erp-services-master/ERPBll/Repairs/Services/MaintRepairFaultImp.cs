﻿using AutoMapper;
using ERPBll.Repairs.Contracts;
using ERPDal;
using ERPModel.MaintManage;
using ERPModel.Repairs.MaintRepairFaults;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.Repairs.Services
{
    public class MaintRepairFaultImp: IMaintRepairFaultImp
    {
        public async Task<List<MaintRepairFault>> GetByRepairId(string server_id, int repair_id)
        {
            var query = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<MaintRepairFault>()
                                .Mapper(async x =>
                                {
                                    x.fault_info = await SqlSugarHelper.DBClient(server_id)
                                        .Queryable<ErpFaultItem>()
                                        .Mapper(async i =>
                                        {
                                            i.group_name = (await SqlSugarHelper.DBClient(server_id)
                                                .Queryable<ErpFaultItemGroup>()
                                                .FirstAsync(t => t.i_id == i.i_group_id))?.c_name;
                                        })
                                        .FirstAsync(i => i.i_id == x.fault_id);
                                })
                                .Where(t => t.repair_id == repair_id)
                                .ToListAsync();
            return query;
        }

        public async Task<List<int>> AddAsync(
            string server_id, decimal? user_id, int repair_id, List<int> fault_ids)
        {
            var list = new List<MaintRepairFault>();
            foreach (var item in fault_ids)
            {
                var info = new MaintRepairFault()
                {
                    id = Tools.GetEngineID(server_id),
                    repair_id = repair_id,
                    fault_id = item,
                    created_id = user_id,
                    created_date = DateTime.Now
                };
                list.Add(info);
            }

            await SqlSugarHelper.DBClient(server_id).Insertable(list).ExecuteCommandAsync();

            return fault_ids;
        }

        public async Task<int> DeleteAsync(string server_id, decimal repair_id)
        {
            return await SqlSugarHelper.DBClient(server_id)
                .Deleteable<MaintRepairFault>()
                .Where(x => x.repair_id == repair_id).ExecuteCommandAsync();
        }
    }
}
