﻿using AutoMapper;
using ERPBll.RedisManage.Dicts;
using ERPBll.RedisManage.Lines;
using ERPBll.Repairs.Contracts;
using ERPDal;
using ERPDal.Repository;
using ERPModel.MaterialManage.BaseinfoManage;
using ERPModel.MaterialManage.InventoryManage;
using ERPModel.Repairs.MaintOrderMaterials;
using ERPModel.Repairs.MaintRepairOrders;
using ERPModel.Vehicleinfomanage;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.Repairs.Services
{
    public class MaintRepairPickImp : BaseBusiness<MaintRepairPick>, IMaintRepairPickImp
    {
        private readonly IMapper _imapper;
        private readonly ILineRedisImp _iLineRedisImp;
        private readonly IDictRedisManageImp _iDictRedisManageImp;
        private readonly IMaintRepairPickDetailImp _iMaintRepairPickDetailImp;
        public MaintRepairPickImp(IMapper imapper,
            ILineRedisImp iLineRedisImp,
            IDictRedisManageImp iDictRedisManageImp,
            IMaintRepairPickDetailImp iMaintRepairPickDetailImp)
        {
            _imapper = imapper;
            _iLineRedisImp = iLineRedisImp;
            _iDictRedisManageImp = iDictRedisManageImp;
            _iMaintRepairPickDetailImp = iMaintRepairPickDetailImp;
        }

        public async Task<Tuple<int, List<RepairPickDto>>> GetByPage(RepairPickRequest request)
        {
            var ids = new List<decimal>();
            if (string.IsNullOrEmpty(request.material_name) && string.IsNullOrEmpty(request.material_code) && string.IsNullOrEmpty(request.specification))
            {
                ids = null;
            }
            else
            {
                var details = await SqlSugarHelper.DBClient(request.server_id).Queryable<MaintRepairPickDetail, ErpMaterialMain>((a, b) =>
                        new JoinQueryInfos(JoinType.Left, a.material_id == b.id))
                    .WhereIF(!string.IsNullOrEmpty(request.material_name), (a, b) => b.name.Contains(request.material_name))
                    .WhereIF(!string.IsNullOrEmpty(request.material_code), (a, b) => b.code.Contains(request.material_code))
                    .WhereIF(!string.IsNullOrEmpty(request.specification), (a, b) => b.specification.Contains(request.specification))
                    .ToListAsync();
                ids = details == null || details.Count == 0 ? new List<decimal>() : details.Select(r => r.pick_id).ToList();
            }
            var lp_nums = new List<string>();
            if (request.type != 2 || request.vehicle_ids == null || request.vehicle_ids.Count() == 0)
            {
                lp_nums = null;
            }
            else
            {
                var details = await SqlSugarHelper.DBClient(request.server_id).Queryable<VehicleInfoNew>()
                    .Where(r => request.vehicle_ids.Contains(r.id))
                    .ToListAsync();
                lp_nums = details == null || details.Count == 0 ? new List<string>() : details.Select(r => r.lp_num).ToList();
            }

            RefAsync<int> totalNumber = 0;
            var records = await SqlSugarHelper.DBClient(request.server_id).Queryable<MaintRepairPick, MaintRepairOrder, ErpLeaveInventoryRecord>((a, b, c) =>
                        new JoinQueryInfos(JoinType.Left, a.order_id == b.id,
                        JoinType.Left, a.out_code == c.leave_num))
                .WhereIF(ids != null, (a, b, c) => ids.Contains(a.id.Value))
                .Where(request.ToExp())
                .WhereIF(request.type == 1 && !string.IsNullOrEmpty(request.relate_num), (a, b, c) => b.work_code.Contains(request.relate_num))
                .WhereIF(request.type == 2 && !string.IsNullOrEmpty(request.relate_num), (a, b, c) => c.leave_num.Contains(request.relate_num))
                .WhereIF(request.type == 1 && request.vehicle_ids != null && request.vehicle_ids.Count() > 0, (a, b, c) => request.vehicle_ids.Contains(b.vehicle_id))
                .WhereIF(lp_nums != null, (a, b, c) => lp_nums.Contains(c.lp_num) && c.out_vehicle == 2)
                .Mapper(async a => a.details = await _iMaintRepairPickDetailImp.GetData(request.server_id, r => r.pick_id == a.id))
                .Mapper(a => a.warenhouse_info, a => a.warenhouse_id)
                .Mapper(a => a.pick_user_info, a => a.pick_user)
                .Mapper(async a => a.order_info = await SqlSugarHelper.DBClient(request.server_id).Queryable<MaintRepairOrder>()
                     .Where(r => r.id == a.order_id)
                     .Mapper(r => r.vehicle_info, r => r.vehicle_id).FirstAsync())
                .ToPageListAsync(request.page_index, request.page_size, totalNumber);

            List<RepairPickDto> list = new List<RepairPickDto>();
            var dic = await _iDictRedisManageImp.GetAllAsync();
            foreach (var item in records)
            {
                var temp = _imapper.Map<MaintRepairPick, RepairPickDto>(item);
                temp.lp_num = item.order_info?.vehicle_info?.c_lincense_plate_number;
                temp.pick_user_name = item.pick_user_info?.c_name;
                temp.warenhouse_name = item.warenhouse_info?.name;
                //temp.work_code = item.order_info?.work_code;
                if (item.details != null && item.details.Count() > 0)
                {
                    foreach (var item1 in item.details)
                    {
                        var temp1 = Tools.DeepCopy(temp);
                        temp1.material_id = item1.material_id;
                        temp1.count = item1.count;
                        temp1.material_code = item1.material_info?.code;
                        temp1.material_name = item1.material_info?.name;
                        temp1.specification = item1.material_info?.specification;
                        temp1.measure_unit_name = dic.Find(r => r.i_id == item1.material_info?.measure_unit)?.c_name;
                        list.Add(temp1);
                    }

                    //temp.pick_details = new List<RepairPickDetails>();
                    //foreach (var item1 in item.details)
                    //{
                    //    RepairPickDetails detail = _imapper.Map<MaintRepairPickDetail, RepairPickDetails>(item1);
                    //    detail.material_code = item1.material_info?.code;
                    //    detail.material_name = item1.material_info?.name;
                    //    detail.specification = item1.material_info?.specification;
                    //    detail.measure_unit_name = dic.Find(r => r.i_id == item1.material_info?.measure_unit)?.c_name;
                    //    temp.pick_details.Add(detail);
                    //}
                }
                else
                {
                    list.Add(temp);
                }
            }
            return new Tuple<int, List<RepairPickDto>>(totalNumber, list);
        }
    }
}
