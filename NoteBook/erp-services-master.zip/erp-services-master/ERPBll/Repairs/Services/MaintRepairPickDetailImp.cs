﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using ERPBll.Repairs.Contracts;
using ERPDal;
using ERPDal.Repository;
using ERPModel.MaterialManage.BaseinfoManage;
using ERPModel.Repairs.MaintOrderMaterials;

namespace ERPBll.Repairs.Services
{
    public class MaintRepairPickDetailImp : BaseBusiness<MaintRepairPickDetail>, IMaintRepairPickDetailImp
    {
        public async Task<List<MaintRepairPickDetail>> GetData(string server_id, Expression<Func<MaintRepairPickDetail, bool>> expression)
        {
            return await SqlSugarHelper.DBClient(server_id).Queryable<MaintRepairPickDetail>()
                .WhereIF(expression != null, expression)
                .Mapper(async r => r.material_info = await SqlSugarHelper.DBClient(server_id).Queryable<ErpMaterialMain>()
                     .Where(m => m.id == r.material_id)
                     .Mapper(m => m.measure_unit_info, m => m.measure_unit)
                     .FirstAsync())
                .ToListAsync();
        }
    }
}
