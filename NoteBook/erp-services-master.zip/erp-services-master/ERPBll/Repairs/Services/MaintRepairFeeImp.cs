﻿using AutoMapper;
using DotNetCore.CAP;
using ERPBll.RedisManage.Lines;
using ERPBll.RedisManage.Users;
using ERPBll.Repairs.Contracts;
using ERPDal;
using ERPModel.MaterialManage.BaseinfoManage;
using ERPModel.MaterialManage.InventoryManage;
using ERPModel.Repairs.MaintRepairFees;
using ERPModel.Vehicleinfomanage;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static ERPModel.ApiModel.TicketManage.RevenueSummary;

namespace ERPBll.Repairs.Services
{
    /// <summary>
    /// 工单结算
    /// </summary>
    public class MaintRepairFeeImp: IMaintRepairFeeImp
    {
        private readonly IMapper _imapper;
        private readonly ILineRedisImp _iLineRedisImp;

        public MaintRepairFeeImp(
            ILineRedisImp iLineRedisImp,
           IMapper imapper)
        {
            _imapper = imapper;
            _iLineRedisImp = iLineRedisImp;
        }

        public async Task<MaintRepairFeeDto> GetByOrderIdAsync(string server_id, int order_id)
        {
            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<MaintRepairFee>()
                                .Mapper(x => x.dept_info, x => x.dept_id)
                                .Where(x => x.order_id == order_id)
                                .Mapper(x => x.settlement_info, x => x.settlement)
                                .FirstAsync();

            var result = _imapper.Map<MaintRepairFee, MaintRepairFeeDto>(list);
            if (result != null)
            {
                result.material = list.material.HasValue ? list.material.Value.ToString("0.00") : "0.00";
                result.management = list.management.HasValue ? list.management.Value.ToString("0.00") : "0.00";
                result.ingredients = list.ingredients.HasValue ? list.ingredients.Value.ToString("0.00") : "0.00";
                result.hour = list.hour.HasValue ? list.hour.Value.ToString("0.00") : "0.00";
                result.overtime = list.overtime.HasValue ? list.overtime.Value.ToString("0.00") : "0.00";
                result.sale = list.sale.HasValue ? list.sale.Value.ToString("0.00") : "0.00";
                result.total = list.total.HasValue ? list.total.Value.ToString("0.00") : "0.00";
                result.pay_fee = list.pay_fee.HasValue ? list.pay_fee.Value.ToString("0.00") : "0.00";
            }

            return result;
        }

        public async Task<MaintRepairFeeDto> AddAsync(
           string server_id, decimal? user_id, CreateOrUpdateMaintRepairFee input)
        {
            var info = _imapper.Map<CreateOrUpdateMaintRepairFee, MaintRepairFee>(input);
            info.id = ERPBll.Tools.GetEngineID(server_id);
            info.SetCreate(user_id);

            await SqlSugarHelper.DBClient(server_id).Insertable(info).ExecuteCommandAsync();

            return _imapper.Map<MaintRepairFee, MaintRepairFeeDto>(info);
        }

        public async Task<MaintRepairFeeDto> UpdateAsync(
            string server_id, decimal? user_id, CreateOrUpdateMaintRepairFee input)
        {
            var info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<MaintRepairFee>().FirstAsync(x => x.id == input.id);
            if (info == null)
            {
                throw new Exception($"未找到结算记录，id={input.id}");
            }

            _imapper.Map<CreateOrUpdateMaintRepairFee, MaintRepairFee>(input, info);
            info.SetUpdate(user_id);

            await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync();

            return _imapper.Map<MaintRepairFee, MaintRepairFeeDto>(info);
        }

        public async Task<List<MaintRepairFeeDto>> UpdateStateAsync(string server_id, decimal? user_id, UpdateState input)
        {
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<MaintRepairFee>()
                                .Where(x => input.ids.Contains(x.id))
                                .ToListAsync();
            if (list == null || list.Count < 1)
            {
                throw new Exception($"未找到结算记录");
            }

            list.ForEach(x =>
            {
                x.SetUpdate(user_id);
                x.state = input.state;
            });

            await SqlSugarHelper.DBClient(server_id).Updateable(list).ExecuteCommandAsync();

            return _imapper.Map<List<MaintRepairFee>, List<MaintRepairFeeDto>>(list);
        }

        public async Task<List<VehicleRepairFeeDto>> GetRepairFeeByVehicle(VehicleRepairFeeQuery request)
        {
            var vehicles = await SqlSugarHelper.DBClient(request.server_id).Queryable<VehicleInfoNew>()
                .Mapper(r => r.group_info, r => r.group).ToListAsync();
            var lines = await _iLineRedisImp.GetLineVehAsync();
            var leave_records = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpLeaveInventoryRecord>()
                .Mapper(r => r.details, r => r.details.First().main_id).ToListAsync();
            var list = new List<VehicleRepairFeeDto>();
            foreach (var vehicle in vehicles)
            {
                var temp = new VehicleRepairFeeDto();
                temp.vehicle_id = vehicle.id;
                temp.v_num = vehicle.v_num;
                temp.lp_num = vehicle.lp_num;
                temp.line_name = lines.Find(r => r.vehicle_id_erp == vehicle.id)?.line_name;
                List<ErpLeaveInventory> details=new List<ErpLeaveInventory>();
                //leave_records.Where(r => r.out_vehicle == 2 && r.lp_num == vehicle.lp_num).ToList().ForEach();
            }
            return list;
        }

        /// <summary>
        /// 获取表头
        /// </summary>
        /// <returns></returns>
        public async Task<List<RevenueTitle>> GetTitle(string server_id, int summary_type, int type)
        {
            var r = new List<RevenueTitle>();
            int index = 1;
            if (summary_type == 2)
            {
                r.Add(new RevenueTitle
                {
                    id = index++,
                    label = "自编号",
                    prop = "v_num",
                    width = "110",
                    align = "center",
                    signIndex = index,
                    sortable = true,
                });
                r.Add(new RevenueTitle
                {
                    id = index++,
                    label = "车牌号",
                    prop = "lp_num",
                    width = "110",
                    align = "center",
                    signIndex = index,
                    sortable = true,
                });
                r.Add(new RevenueTitle
                {
                    id = index++,
                    label = "所属组织",
                    prop = "dept_name",
                    width = "130",
                    align = "center",
                    signIndex = index,
                    sortable = true,
                });
            }
            r.Add(new RevenueTitle
            {
                id = index++,
                label = "线路",
                prop = "line_name",
                width = "110",
                align = "center",
                signIndex = index,
                sortable = true,
            });

            if (type == 1)
            {
                var proveders = await SqlSugarHelper.DBClient(server_id).Queryable<ErpProviderMain>()
               .Where(r => r.usable == 1).OrderBy(r => r.id).ToListAsync();
                int col = 0;
                foreach (var item in proveders)
                {
                    r.Add(new RevenueTitle
                    {
                        id = index++,
                        label = item.name,
                        prop = "col_" + col++,
                        width = ((item.name.Length + 2) * 30 > 150 ? 150 : (item.name.Length + 2) * 30).ToString(),
                        align = "center",
                        signIndex = index,
                        sortable = true,
                    });
                }
            }
            r.Add(new RevenueTitle
            {
                id = index++,
                label = "物料费用合计",
                prop = "total_fee",
                width = "150",
                align = "center",
                signIndex = index,
                sortable = true,
            });
            return r;
        }

        /// <summary>
        /// 根据车辆统计
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public async Task<List<Dictionary<string, object>>> GetTotalByVehicleAsync(VehicleRepairFeeQuery request)
        {
            var vehicles = await SqlSugarHelper.DBClient(request.server_id).Queryable<VehicleInfoNew>()
                .WhereIF(request.vehicle_ids != null && request.vehicle_ids.Count > 0, r => request.vehicle_ids.Contains(r.id))
                //.WhereIF(request.type == 2 && !string.IsNullOrEmpty(request.num), r => r.lp_num.Contains(request.num))
                .Mapper(r => r.group_info, r => r.group).ToListAsync();
            var line_vehs = await _iLineRedisImp.GetLineVehAsync();

            var leave_records = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpLeaveInventoryRecord>()
                .Where(r => r.state == 2 && r.out_vehicle == 2)
                .WhereIF(request.leave_start != null, r => r.leave_date >= request.leave_start && r.leave_date <= request.leave_end)
                /*.Mapper(r => r.details, r => r.details.First().main_id)*/.ToListAsync();
            var leave_materials = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpLeaveInventory>()
                .Where(r => leave_records.Select(m => m.id).Contains(r.main_id)).ToListAsync();
            var leave_details = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpLeaveInventoryDetail>()
                .Where(r => leave_materials.Select(m => m.id).Contains(r.main_id)).ToListAsync();
            var providers = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpProviderMain>()
                //.WhereIF(request.ids != null && request.ids.Count > 0, r => request.ids.Contains((decimal)r.id))
                .Where(r => r.usable == 1).OrderBy(r => r.id).ToListAsync();

            Dictionary<string, object> dic = new Dictionary<string, object>();
            List<Dictionary<string, object>> res = new List<Dictionary<string, object>>();
            foreach (var item in vehicles)
            {
                dic.Add("v_num", item.v_num);
                dic.Add("lp_num", item.lp_num);
                dic.Add("dept_name", item.group_info?.c_name);
                dic.Add("line_name", line_vehs.Find(r => r.vehicle_id_erp == item.id)?.line_name);
                var ids = leave_records.Where(r => r.lp_num == item.lp_num).Select(r => r.id).ToList();
                var leave_materials1 = leave_materials.Where(r => ids.Contains(r.main_id)).ToList();
                if (ids != null && ids.Count > 0)
                {
                    var fee = leave_materials1.Sum(r => r.total_price);
                    dic.Add($"total_fee", fee);
                }
                else
                {
                    dic.Add($"total_fee", 0);
                }

                int col = 0;
                bool is_add = true;
                var main_ids1 = leave_materials1.Select(r => r.id).ToList();
                foreach (var item1 in providers)
                {
                    var leave_details1 = leave_details.Where(r => r.provider_id == item1.id && main_ids1.Contains(r.main_id)).ToList();
                    if (leave_details1 != null && leave_details1.Count > 0)
                    {
                        decimal fee = 0;
                        leave_details1.ForEach(r =>
                        {
                            double price = leave_materials1.Find(m => m.id == r.main_id).price;
                            fee += Math.Round(Convert.ToDecimal(price) * r.count, 2, MidpointRounding.AwayFromZero);
                        });
                        if (fee == 0 && request.ids != null && request.ids.Count > 0 && request.ids.Contains(item1.id))
                        {
                            is_add = false;
                            break;
                        }
                        dic.Add($"col_{col}", fee);
                    }
                    else
                    {
                        if (request.ids != null && request.ids.Count > 0 && request.ids.Contains(item1.id))
                        {
                            is_add = false;
                            break;
                        }
                        dic.Add($"col_{col}", 0);
                    }
                    col++;
                }
                if (is_add)
                {
                    res.Add(dic);
                    dic = new Dictionary<string, object>();
                }
                else
                {
                    dic = new Dictionary<string, object>();
                }
            }
            return res;
        }

        /// <summary>
        /// 根据线路统计
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public async Task<List<Dictionary<string, object>>> GetTotalByLineAsync(LineRepairFeeQuery request)
        {
            var lines = await _iLineRedisImp.GetAllAsync();
            //var line_veh = await _iLineRedisImp.GetLineVehAsync();
            if (request.line_ids != null && request.line_ids.Count > 0)
            {
                lines = lines.Where(r => request.line_ids.Contains(r.id)).ToList();
            }

            var leave_records = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpLeaveInventoryRecord>()
                .Where(r => r.state == 2 && r.out_vehicle == 2)
                .WhereIF(request.leave_start != null, r => r.leave_date >= request.leave_start && r.leave_date <= request.leave_end)
                .WhereIF(request.line_ids != null && request.line_ids.Count > 0, r => SqlFunc.ContainsArray(request.line_ids, r.line_id))
                /*.Mapper(r => r.details, r => r.details.First().main_id)*/.ToListAsync();
            var leave_materials = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpLeaveInventory>()
                .Where(r => leave_records.Select(m => m.id).Contains(r.main_id)).ToListAsync();
            var leave_details = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpLeaveInventoryDetail>()
                .Where(r => leave_materials.Select(m => m.id).Contains(r.main_id)).ToListAsync();
            var proveders = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpProviderMain>()
                //.WhereIF(request.ids != null && request.ids.Count > 0, r => request.ids.Contains((decimal)r.id))
                .Where(r => r.usable == 1).OrderBy(r => r.id).ToListAsync();

            Dictionary<string, object> dic = new Dictionary<string, object>();
            List<Dictionary<string, object>> res = new List<Dictionary<string, object>>();
            foreach (var item in lines)
            {
                dic.Add("line_name", item.name);
                var ids = leave_records.Where(r => r.line_id == item.id).Select(r => r.id).ToList();
                var leave_materials1 = leave_materials.Where(r => ids.Contains(r.main_id)).ToList();
                if (ids != null && ids.Count > 0)
                {
                    var fee = leave_materials1.Sum(r => r.total_price);
                    dic.Add($"total_fee", fee);
                }
                else
                {
                    dic.Add($"total_fee", 0);
                }

                int col = 0;
                bool is_add = true;
                var main_ids1 = leave_materials1.Select(r => r.id).ToList();
                foreach (var item1 in proveders)
                {
                    var leave_details1 = leave_details.Where(r => r.provider_id == item1.id && main_ids1.Contains(r.main_id)).ToList();
                    if (leave_details1 != null && leave_details1.Count > 0)
                    {
                        decimal fee = 0;
                        leave_details1.ForEach(r =>
                        {
                            double price = leave_materials1.Find(m => m.id == r.main_id).price;
                            fee += Math.Round(Convert.ToDecimal(price) * r.count, 2, MidpointRounding.AwayFromZero);
                        });
                        if (fee == 0 && request.ids != null && request.ids.Count > 0 && request.ids.Contains(item1.id))
                        {
                            is_add = false;
                            break;
                        }
                        dic.Add($"col_{col}", fee);
                    }
                    else
                    {
                        if (request.ids != null && request.ids.Count > 0 && request.ids.Contains(item1.id))
                        {
                            is_add = false;
                            break;
                        }
                        dic.Add($"col_{col}", 0);
                    }
                    col++;
                }
                if (is_add)
                {
                    res.Add(dic);
                    dic = new Dictionary<string, object>();
                }
                else
                {
                    dic = new Dictionary<string, object>();
                }
            }
            return res;
        }
    }
}
