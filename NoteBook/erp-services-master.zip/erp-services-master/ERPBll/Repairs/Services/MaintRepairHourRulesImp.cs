﻿using ERPBll.Repairs.Contracts;
using ERPDal;
using ERPDal.Repository;
using ERPModel.Repairs;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.Repairs.Services
{
    public class MaintRepairHourRulesImp: BaseBusiness<MaintRepairHourRules>, IMaintRepairHourRulesImp
    {
        public async Task<bool> Delete(string serverId)
        {
            var res = await SqlSugarHelper.DBClient(serverId).Deleteable<MaintRepairHourRules>().ExecuteCommandAsync();
            return res > 0;
        }
    }
}
