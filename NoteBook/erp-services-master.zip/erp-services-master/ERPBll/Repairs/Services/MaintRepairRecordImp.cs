﻿using AutoMapper;
using BusTools.Redis;
using DotNetCore.CAP;
using ERPBll.Caps;
using ERPBll.RedisManage.Lines;
using ERPBll.RedisManage.Users;
using ERPBll.Repairs.Contracts;
using ERPBll.SignalRs;
using ERPCore.Helpers;
using ERPDal;
using ERPDal.Repository;
using ERPModel.AccidentManage;
using ERPModel.DataBase;
using ERPModel.Repairs;
using ERPModel.Repairs.MaintRepairChecks;
using ERPModel.Repairs.MaintRepairLifes;
using ERPModel.Repairs.MaintRepairOrders;
using ERPModel.Vehicleinfomanage;
using Microsoft.AspNetCore.SignalR;
using Newtonsoft.Json;
using Serilog;
using Spire.Doc;
using Spire.Doc.Documents;
using Spire.Doc.Fields;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static ERPCore.Helpers.WordExportHelper;

namespace ERPBll.Repairs
{
    /// <summary>
    /// 维修记录
    /// </summary>
    public class MaintRepairRecordImp : BaseBusiness<MaintRepairRecord>, IMaintRepairRecordImp, ICapSubscribe
    {
        private readonly IMapper _imapper;
        private readonly ICapPublisher _publisher;
        private readonly IMaintRegisterImgImp _maintRegisterImgImp;
        private readonly IMaintRepairCheckImp _maintRepairCheckImp;
        private readonly IUserRedisImp _userRedisImp;
        private readonly ILineRedisImp _iLineRedisImp;
        private readonly ILogger _logger = Log.Logger;

        public MaintRepairRecordImp(
           IMapper imapper,
           ICapPublisher publisher,
           IMaintRegisterImgImp maintRegisterImgImp,
           IMaintRepairCheckImp maintRepairCheckImp,
           IUserRedisImp userRedisImp,
           ILineRedisImp iLineRedisImp)
        {
            _imapper = imapper;
            _publisher = publisher;
            _maintRegisterImgImp = maintRegisterImgImp;
            _maintRepairCheckImp = maintRepairCheckImp;
            _userRedisImp = userRedisImp;
            _iLineRedisImp = iLineRedisImp;
        }

        public async Task<(List<MaintRepairRecordDto>, int)> GetByPageAsync(
            string server_id, decimal? user_id, MaintRepairRecordQuery query)
        {
            RefAsync<int> totalCount = 0;

            List<decimal> vehicle_ids = new List<decimal>();
            if (query.group_id != null && query.group_id.Count > 0)
            {
                var vehicles = await SqlSugarHelper.DBClient(server_id).Queryable<VehicleInfoNew>()
                    .Where(r => query.group_id.Contains(Convert.ToInt32(r.group))).ToListAsync();
                vehicle_ids = vehicles.Select(r => r.id.Value).ToList();
            }

            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<MaintRepairRecord, MaintRepairCheck>((x, y) => new JoinQueryInfos(
                                    JoinType.Left, x.id == y.repair_id
                                    ))
                                .Where(query.ToExp())
                                .WhereIF(vehicle_ids.Count > 0, x => vehicle_ids.Contains(x.vehicle_id))
                                .Mapper(x => x.type_child_info, x => x.type_child)
                                .Mapper(x => x.state_child_info, x => x.state_child)
                                .Mapper(x => x.repair_user_info, x => x.repair_user_id)
                                .Mapper(x => x.driver_info, x => x.driver_id)
                                .Mapper(x => x.register_imgs, x => x.register_imgs.First().repair_id)
                                .Mapper(async x =>
                                {
                                    x.vehicle_info = await SqlSugarHelper.DBClient(server_id)
                                                            .Queryable<ErpVehicleInfo>()
                                                            .Mapper(x => x.department_info, x => x.c_crews_take)
                                                            .Mapper(x => x.kind_info, x => x.c_id)
                                                            .FirstAsync(t => t.i_id == x.vehicle_id);

                                    x.repair_check = await _maintRepairCheckImp.GetByRepairIdAsync(server_id, x.id);
                                })
                                .OrderBy(x => x.repair_time, OrderByType.Desc)
                                .ToPageListAsync(query.page_index, query.page_size, totalCount);

            var data = _imapper.Map<List<MaintRepairRecord>, List<MaintRepairRecordDto>>(list);
            return (data, totalCount);
        }

        public async Task<MaintRepairRecordDto> GetByIdAsync(string server_id, int id)
        {
            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<MaintRepairRecord>()
                                .Where(x => x.id == id)
                                .Mapper(x => x.type_child_info, x => x.type_child)
                                .Mapper(x => x.state_child_info, x => x.state_child)
                                .Mapper(x => x.repair_user_info, x => x.repair_user_id)
                                .Mapper(x => x.driver_info, x => x.driver_id)
                                .Mapper(x => x.register_imgs, x => x.register_imgs.First().repair_id)
                                .Mapper(async x =>
                                {
                                    x.vehicle_info = await SqlSugarHelper.DBClient(server_id)
                                                            .Queryable<ErpVehicleInfo>()
                                                            .Mapper(x => x.department_info, x => x.c_crews_take)
                                                            .Mapper(x => x.kind_info, x => x.c_id)
                                                            .FirstAsync(t => t.i_id == x.vehicle_id);

                                    x.repair_check = await _maintRepairCheckImp.GetByRepairIdAsync(server_id, x.id);
                                })
                                .OrderBy(x => x.repair_time, OrderByType.Desc)
                                .FirstAsync();

            return _imapper.Map<MaintRepairRecord, MaintRepairRecordDto>(list);
        }

        public async Task<MaintRepairRecordDto> AddAsync(
            string server_id, decimal? user_id, CreateOrUpdateMaintRepairRecord input)
        {
            var info = _imapper.Map<CreateOrUpdateMaintRepairRecord, MaintRepairRecord>(input);
            info.id = ERPBll.Tools.GetEngineID(server_id);
            info.SetCreate(user_id);

            await SqlSugarHelper.DBClient(server_id).Insertable(info).ExecuteCommandAsync();

            //相关图片
            if (input.imgs != null && input.imgs.Count > 0)
            {
                await _maintRegisterImgImp.AddAsync(server_id, user_id, info.id, input.imgs);
            }

            string userName = await _userRedisImp.GetNameByIdAsync(input.repair_user_id.ToString());
            string title = input.accident_id.HasValue || string.IsNullOrWhiteSpace(input.accident_code) ? 
                            MaintRepairLifeTxt.AddAccidentRepairRecord : 
                            MaintRepairLifeTxt.AddRepairRecord;
            _publisher.Publish(EventMessages.RepairLifeUpdate, 
                new CreateMaintRepairLife()
                {
                    repair_id = info.id,
                    title = string.Format(title, userName),
                    date = input.repair_time,
                    created_id = user_id
                });

            if (input.type == 2 && input.accident_id.HasValue && input.accident_id > 0)
            {
                var damage = await SqlSugarHelper.DBClient(server_id).Queryable<ErpAccidentDamage>()
                    .Where(r => r.i_main_id == input.accident_id && r.i_type == 2).FirstAsync();
                if (damage != null)
                {
                    damage.c_describe = input.c_describe;
                    damage.n_actual_fee = input.n_actual_fee;
                    await SqlSugarHelper.DBClient(server_id).Updateable(damage).ExecuteCommandAsync();
                }
                else
                {
                    damage = new ErpAccidentDamage();
                    damage.i_id = Tools.GetSeqCommonID(server_id);
                    var vehicle = await SqlSugarHelper.DBClient(server_id).Queryable<VehicleInfoNew>().FirstAsync(r => r.id == input.vehicle_id);
                    damage.c_vehicle_number = vehicle?.lp_num;
                    damage.i_vehicle_id = vehicle?.id;
                    var dic = await SqlSugarHelper.DBClient(server_id).Queryable<SysCommonDictDetail>().FirstAsync(r => r.c_name == "公交");
                    damage.i_main_id = input.accident_id;
                    damage.i_vehicle_type = dic?.i_id;
                    damage.c_describe = input.c_describe;
                    damage.n_actual_fee = input.n_actual_fee;
                    damage.i_type = 2;
                    await SqlSugarHelper.DBClient(server_id).Insertable(damage).ExecuteCommandAsync();
                }
            }

            return _imapper.Map<MaintRepairRecord, MaintRepairRecordDto>(info);
        }

        public async Task<MaintRepairRecordDto> UpdateAsync(
            string server_id, decimal? user_id, CreateOrUpdateMaintRepairRecord input)
        {
            var info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<MaintRepairRecord>().FirstAsync(x => x.id == input.id);
            if (info == null)
            {
                throw new Exception($"未找到报修记录，id={input.id}");
            }
            //本次修改内容
            var str = Tools.CompareClass<MaintRepairRecord, CreateOrUpdateMaintRepairRecord>(info, input);

            _imapper.Map<CreateOrUpdateMaintRepairRecord, MaintRepairRecord>(input, info);
            info.SetUpdate(user_id);

            await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync();

            //相关图片
            if (input.imgs != null && input.imgs.Count > 0)
            {
                await _maintRegisterImgImp.DeleteAsync(server_id, info.id);
                await _maintRegisterImgImp.AddAsync(server_id, user_id, info.id, input.imgs);
            }

            string userName = await _userRedisImp.GetNameByIdAsync(((int)user_id.Value).ToString());
            _publisher.Publish(EventMessages.RepairLifeUpdate,
                new CreateMaintRepairLife()
                {
                    repair_id = info.id,
                    title = string.Format(MaintRepairLifeTxt.UpdateRepair, userName),
                    content = str,
                    date = DateTime.Now,
                    created_id = user_id
                });

            if (input.type == 2 && input.accident_id.HasValue && input.accident_id > 0)
            {
                var damage = await SqlSugarHelper.DBClient(server_id).Queryable<ErpAccidentDamage>()
                    .Where(r => r.i_main_id == input.accident_id && r.i_type == 2).FirstAsync();
                if (damage != null)
                {
                    damage.c_describe = input.c_describe;
                    damage.n_actual_fee = input.n_actual_fee;
                    await SqlSugarHelper.DBClient(server_id).Updateable(damage).ExecuteCommandAsync();
                }
                else
                {
                    damage = new ErpAccidentDamage();
                    damage.i_id = Tools.GetSeqCommonID(server_id);
                    var vehicle = await SqlSugarHelper.DBClient(server_id).Queryable<VehicleInfoNew>().FirstAsync(r => r.id == input.vehicle_id);
                    damage.c_vehicle_number = vehicle?.lp_num;
                    damage.i_vehicle_id = vehicle?.id;
                    var dic = await SqlSugarHelper.DBClient(server_id).Queryable<SysCommonDictDetail>().FirstAsync(r => r.c_name == "公交");
                    damage.i_main_id = input.accident_id;
                    damage.i_vehicle_type = dic?.i_id;
                    damage.c_describe = input.c_describe;
                    damage.n_actual_fee = input.n_actual_fee;
                    damage.i_type = 2;
                    await SqlSugarHelper.DBClient(server_id).Insertable(damage).ExecuteCommandAsync();
                }
            }
            return _imapper.Map<MaintRepairRecord, MaintRepairRecordDto>(info);
        }

        public async Task<List<MaintRepairRecord>> DeleteManyAsync(string server_id, List<decimal> ids)
        {
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<MaintRepairRecord>()
                                .Includes(x => x.vehicle_info)
                                .Includes(x => x.state_child_info)
                                .Where(x => ids.Contains(x.id))
                                .ToListAsync();
            if (list == null)
            {
                throw new Exception($"未找到报修记录");
            }
            list.ForEach(x => x.is_delete = 1);
            await SqlSugarHelper.DBClient(server_id).Updateable(list).ExecuteCommandAsync();
            return list;
        }

        [CapSubscribe(EventMessages.RepairCheck, Group = "RepairRecord")]
        public void UpdateRepairCodeMessage(MaintRepairCheck data)
        {

            var info = SqlSugarHelper.DBClient("60.191.59.11")
                                .Queryable<MaintRepairRecord>()
                                .First(x => x.id == data.repair_id);
            if (info == null)
            {
                throw new Exception($"未找到报修记录，id={data.repair_id}");
            }
            info.work_code = data.work_code;
            info.state = (int)MainRepairOrderState.待接修;

            SqlSugarHelper.DBClient("60.191.59.11").Updateable(info).ExecuteCommand();
        }

        [CapSubscribe(EventMessages.OrderStateUpdate, Group = "RepairRecord")]
        public void UpdateStateMessage(MaintRepairOrder data)
        {
            var info = SqlSugarHelper.DBClient("60.191.59.11")
                                .Queryable<MaintRepairRecord>()
                                .First(x => x.id == data.repair_id);
            if (info == null)
            {
                throw new Exception($"未找到报修记录，id={data.repair_id}");
            }
            info.state = data.state;
            info.state_child = data.state_child;
            SqlSugarHelper.DBClient("60.191.59.11").Updateable(info).ExecuteCommand();
        }

        public async Task GetAccidentAsync(string server_id)
        {
            var query = await SqlSugarHelper.DBClient(server_id)
                        .Queryable<ErpAccidentMain>()
                        .ToListAsync();
        }

        public async Task SaveRepairTable(string fileName, string savePath, MaintRepairRecordDto context)
        {
            if (!Directory.Exists(savePath))
            {
                Directory.CreateDirectory(savePath);
            }
            var line_vehs = await _iLineRedisImp.GetLineVehAsync();
            fileName = $"{fileName}.docx";
            //实例化一个Document对象,并添加section
            Spire.Doc.Document doc = new Spire.Doc.Document();
            Section sec = doc.AddSection();
            SetParagraph(sec, HorizontalAlignment.Center, new WordText()
            {
                text = $"{context.vehicle_info?.department_name}车辆报修表",
                font_name = "楷体_GB2312",
                font_size = 26,
                is_blod = true
            });
            SetParagraph(sec, HorizontalAlignment.Left, new WordText() { text = "" });
           
            Table table = sec.AddTable(true);
            table.ResetCells(6, 6);

            table.ApplyHorizontalMerge(1, 1, 3);
            table.ApplyHorizontalMerge(2, 0, 5);
            table.ApplyHorizontalMerge(3, 0, 5);
            //table.ApplyVerticalMerge(0, 3, 4);
            table.ApplyHorizontalMerge(4, 0, 5);
            table.ApplyHorizontalMerge(5, 0, 2);
            table.ApplyHorizontalMerge(5, 4, 5);

            //设置自定义样式
            ParagraphStyle style = new ParagraphStyle(doc);
            style.Name = "TableStyle";
            style.CharacterFormat.FontSize = 12;
            style.CharacterFormat.FontName = "宋体";
            style.CharacterFormat.Bold = false;
            //将自定义样式添加到文档
            doc.Styles.Add(style);

            //表格填充数据
            TextRange range = table[0, 0].AddParagraph().AppendText("车牌号");
            table[0, 0].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Center;
            table[0, 0].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
            table[0, 0].Paragraphs[0].ApplyStyle(style.Name);

            range = table[0, 1].AddParagraph().AppendText(context.vehicle_info?.vehicle_name);
            table[0, 1].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Center;
            table[0, 1].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
            table[0, 1].Paragraphs[0].ApplyStyle(style.Name);

            range = table[0, 2].AddParagraph().AppendText("班线");
            table[0, 2].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Center;
            table[0, 2].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
            table[0, 2].Paragraphs[0].ApplyStyle(style.Name);

            range = table[0, 3].AddParagraph().AppendText(line_vehs.Find(r => r.lp_num == context.vehicle_info?.vehicle_name)?.line_name);
            table[0, 3].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Center;
            table[0, 3].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
            table[0, 3].Paragraphs[0].ApplyStyle(style.Name);

            //range = table[0, 4].AddParagraph().AppendText("主 副 代 班");
            //table[0, 4].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Center;
            //table[0, 4].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
            //table[0, 4].Paragraphs[0].ApplyStyle(style.Name);

            range = table[0, 4].AddParagraph().AppendText("驾驶员");
            table[0, 4].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Center;
            table[0, 4].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
            table[0, 4].Paragraphs[0].ApplyStyle(style.Name);

            range = table[0, 5].AddParagraph().AppendText(context.driver_name);
            table[0, 5].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Center;
            table[0, 5].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
            table[0, 5].Paragraphs[0].ApplyStyle(style.Name);

            range = table[1, 0].AddParagraph().AppendText("派车时间");
            table[1, 0].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Center;
            table[1, 0].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
            table[1, 0].Paragraphs[0].ApplyStyle(style.Name);

            range = table[1, 1].AddParagraph().AppendText("  年  月  日  点  分");
            table[1, 1].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Center;
            table[1, 1].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
            table[1, 1].Paragraphs[0].ApplyStyle(style.Name);

            range = table[1, 4].AddParagraph().AppendText("调度员");
            table[1, 4].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Center;
            table[1, 4].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
            table[1, 4].Paragraphs[0].ApplyStyle(style.Name);

            //range = table[1, 3].AddParagraph().AppendText("");
            //table[1, 3].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Center;
            //table[1, 3].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
            //table[1, 3].Paragraphs[0].ApplyStyle(style.Name);

            range = table[2, 0].AddParagraph().AppendText($"报修项目：{context.repair_describe}");
            table[2, 0].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Left;
            table[2, 0].CellFormat.VerticalAlignment = VerticalAlignment.Top;
            table[2, 0].Paragraphs[0].ApplyStyle(style.Name);

            range = table[3, 0].AddParagraph().AppendText("修理项目：");
            table[3, 0].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Left;
            table[3, 0].CellFormat.VerticalAlignment = VerticalAlignment.Top;
            table[3, 0].Paragraphs[0].ApplyStyle(style.Name);

            var pr2 = table[4, 0].AddParagraph();
            SetParagraph(pr2, HorizontalAlignment.Justify, new WordText()
            {
                text = "维修工（签名）：",
                font_name = "宋体",
                font_size = 12
            });
            table[4, 0].Paragraphs[0].ApplyStyle(style.Name);

            var pr3 = table[4, 0].AddParagraph();
            string str = " ".PadLeft(45);
            SetParagraph(pr3, HorizontalAlignment.Left, new WordText()
            {
                text = str + "驾驶员（签名）：",
                font_name = "宋体",
                font_size = 12
            });
            table[4, 0].Paragraphs[0].ApplyStyle(style.Name);

            range = table[5, 0].AddParagraph().AppendText("车间机务员意见及签名：");
            table[5, 0].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Left;
            table[5, 0].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
            table[5, 0].Paragraphs[0].ApplyStyle(style.Name);

            range = table[5, 3].AddParagraph().AppendText("出厂时间");
            table[5, 3].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Left;
            table[5, 3].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
            table[5, 3].Paragraphs[0].ApplyStyle(style.Name);

            var pr5 = table[5, 4].AddParagraph();
            SetParagraph(pr5, HorizontalAlignment.Center, new WordText()
            {
                text = "  年  月  日  点  分",
                font_name = "宋体",
                font_size = 12
            });
            table[5, 4].Paragraphs[0].ApplyStyle(style.Name);

            table.Rows[0].Height = 36;
            table.Rows[1].Height = 36;
            table.Rows[2].Height = 148;
            table.Rows[3].Height = 148;
            table.Rows[4].Height = 36;
            table.Rows[5].Height = 36;

            string remark = "注：车间机务员同意后城乡调度员方可派车；早班和途中抛锚、轮胎损坏的车辆按集团公司相关规定追究责任人。";
            SetParagraph(sec, HorizontalAlignment.Left, new WordText()
            {
                text = remark,
                font_name = "宋体",
                font_size = 12,
            });

            doc.SaveToFile(Path.Combine(savePath, fileName));
        }
    }
}
