﻿using AutoMapper;
using DotNetCore.CAP;
using ERPBll.Caps;
using ERPBll.RedisManage.Extension;
using ERPBll.RedisManage.Users;
using ERPBll.Repairs.Contracts;
using ERPCore.DI;
using ERPDal;
using ERPModel.MaintManage;
using ERPModel.Repairs;
using ERPModel.Repairs.MaintRepairChecks;
using ERPModel.Repairs.MaintRepairItems;
using ERPModel.Repairs.MaintRepairLifes;
using ERPModel.Vehicleinfomanage;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.Repairs.Services
{
    /// <summary>
    /// 维修检验
    /// </summary>
    public class MaintRepairCheckImp : IMaintRepairCheckImp, ICapSubscribe
    {
        private readonly IMapper _imapper;
        private readonly IMaintRepairFaultImp _maintRepairFaultImp;
        private readonly ICapPublisher _publisher;
        private readonly IUserRedisImp _userRedisImp;
        private readonly IWarehouseRedisManageImp _iWarehouseRedisManageImp;
        private readonly ILogger _logger = Log.Logger;
        private IMaintRepairOrderImp _iMaintRepairOrderImp;
        private IMaintRepairRecordImp _iMaintRepairRecordImp;

        public MaintRepairCheckImp(
           IMapper imapper,
           IMaintRepairFaultImp maintRepairFaultImp,
           ICapPublisher publisher,
           IUserRedisImp userRedisImp,
           IWarehouseRedisManageImp iWarehouseRedisManageImp)
        {
            _imapper = imapper;
            _maintRepairFaultImp = maintRepairFaultImp;
            _publisher = publisher;
            _userRedisImp = userRedisImp;
            _iWarehouseRedisManageImp = iWarehouseRedisManageImp;
        }

        public async Task<MaintRepairCheck> GetByRepairIdAsync(string server_id, int repair_id)
        {
            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<MaintRepairCheck>()
                                .Mapper(x => x.check_info, x => x.check_id)
                                .Mapper(x => x.maint_dept_info, x => x.maint_dept)
                                .Mapper(async x =>
                                {
                                    x.repair_faults = await _maintRepairFaultImp.GetByRepairId(server_id, x.repair_id);
                                })
                                .FirstAsync(x => x.repair_id == repair_id);

            return list;
        }

        public async Task<MaintRepairCheckDto> AddAsync(
            string server_id, decimal? user_id, CreateOrUpdateMaintRepairCheck input)
        {
            await DeleteAsync(server_id, input.repair_id);

            var info = _imapper.Map<CreateOrUpdateMaintRepairCheck, MaintRepairCheck>(input);
            info.id = Tools.GetEngineID(server_id);
            //info.work_code = Tools.GetBusinessCode();
            string work_code = await _iWarehouseRedisManageImp.GetBatno(DateTime.Now, 5);
            if (string.IsNullOrEmpty(work_code))
            {
                info.work_code = "WX" + DateTime.Now.ToString("yyyyMMdd") + "0001";
                await _iWarehouseRedisManageImp.SetBatno(DateTime.Now, 1, 5);
            }
            else
            {
                info.work_code = "WX" + work_code;
            }
            info.SetCreate(user_id);

            await SqlSugarHelper.DBClient(server_id).Insertable(info).ExecuteCommandAsync();

            //相关故障
            if (input.fault_ids != null && input.fault_ids.Count > 0)
            {
                await _maintRepairFaultImp.AddAsync(server_id, user_id, info.repair_id, input.fault_ids);
            }

            if (input.state == (int)MainRepairCheckState.已检验)
            {
                _logger.Information("发布维修检验完成事件：{@info}", info);
                //_publisher.Publish(EventMessages.RepairCheck, info);
                _iMaintRepairOrderImp = DIContainer.ServiceLocator.Instance.GetService<IMaintRepairOrderImp>();
                _iMaintRepairRecordImp = DIContainer.ServiceLocator.Instance.GetService<IMaintRepairRecordImp>();
                _iMaintRepairOrderImp.AddRepairOrderMessage(info);
                _iMaintRepairRecordImp.UpdateRepairCodeMessage(info);

                //保养生成报修记录，检验通过自动派工
                //var plan = await SqlSugarHelper.DBClient(server_id).Queryable<MaintUpkeepPlan>()
                //    .Where(r => r.repair_id == info.repair_id)
                //    .Mapper(r => r.repair_persons, r => r.repair_persons.First().upkeep_id)
                //    .FirstAsync();
                //if (plan != null && plan.repair_persons != null && plan.repair_persons.Count > 0)
                //{
                //    var persons = await SqlSugarHelper.DBClient(server_id).Queryable<ErpMaintenancePerson>()
                //        .Where(r => r.i_type == 2).ToListAsync();
                //    var order = await _iMaintRepairOrderImp.Get(server_id, r => r.repair_id == info.repair_id);
                //    if (order != null)
                //    {
                //        var inserts = new List<MaintRepairItem>();
                //        foreach (var item in plan.repair_persons)
                //        {
                //            MaintRepairItem temp = new MaintRepairItem();
                //            temp.order_id = order.id;
                //            var person = persons.Find(r => r.i_person_id == item.user_id);
                //            temp.shop_id = person?.i_main_id == null ? 0 : (int)person.i_main_id;
                //            temp.person_id = (int)item.user_id;
                //            temp.count = 1;

                //            temp.created_id = user_id;
                //            temp.created_date = DateTime.Now;
                //            temp.item_name = plan.upkeep_type == 1 ? "一保" : "二保";
                //            inserts.Add(temp);
                //        }
                //        await SqlSugarHelper.DBClient(server_id).Insertable(inserts).ExecuteCommandAsync();
                //    }
                //}
            }

            string userName = await _userRedisImp.GetNameByIdAsync(input.check_id.ToString());
            _publisher.Publish(EventMessages.RepairLifeUpdate,
                new CreateMaintRepairLife()
                {
                    repair_id = info.repair_id,
                    title = string.Format(input.state == (int)MainRepairCheckState.已检验 ?
                        MaintRepairLifeTxt.AddRepairCheckPass : MaintRepairLifeTxt.AddRepairCheckFail, userName),
                    date = input.check_time,
                    created_id = user_id
                });

            return _imapper.Map<MaintRepairCheck, MaintRepairCheckDto>(info);
        }

        public async Task<MaintRepairCheckDto> UpdateAsync(
            string server_id, decimal? user_id, CreateOrUpdateMaintRepairCheck input)
        {
            var info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<MaintRepairCheck>().FirstAsync(x => x.id == input.id);
            if (info == null)
            {
                throw new Exception($"未找到维修检验记录，id={input.id}");
            }
            _imapper.Map<CreateOrUpdateMaintRepairCheck, MaintRepairCheck>(input, info);
            info.SetUpdate(user_id);

            await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync();

            //相关故障
            if (input.fault_ids != null && input.fault_ids.Count > 0)
            {
                await _maintRepairFaultImp.DeleteAsync(server_id, info.id);
                await _maintRepairFaultImp.AddAsync(server_id, user_id, info.id, input.fault_ids);
            }
            return _imapper.Map<MaintRepairCheck, MaintRepairCheckDto>(info);
        }

        public async Task<int> DeleteAsync(string server_id, decimal repair_id)
        {
            return await SqlSugarHelper.DBClient(server_id)
                .Deleteable<MaintRepairCheck>()
                .Where(x => x.repair_id == repair_id)
                .ExecuteCommandAsync();
        }
    }
}
