﻿using AutoMapper;
using ERPBll.Repairs.Contracts;
using ERPDal;
using ERPDal.Repository;
using ERPModel.Repairs.MaintRepairOrderFiles;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.Repairs.Services
{
    /// <summary>
    /// 维修工单资料
    /// </summary>
    public class MaintRepairOrderFileImp : BaseBusiness<MaintRepairOrderFile>, IMaintRepairOrderFileImp
    {
        private readonly IMapper _imapper;

        public MaintRepairOrderFileImp(IMapper imapper)
        {
            _imapper = imapper;
        }

        public async Task<List<MaintRepairOrderFileDto>> GetByOrderIdAsync(string server_id, int order_id)
        {
            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<MaintRepairOrderFile>()
                                .Where(x => x.order_id == order_id)
                                .ToListAsync();

            return _imapper.Map<List<MaintRepairOrderFile>, List<MaintRepairOrderFileDto>>(list);
        }

        public async Task<List<MaintRepairOrderFileDto>> AddAsync(
            string server_id, decimal? user_id, List<CreateMaintRepairOrderFile> input)
        {
            await DeleteAsync(server_id, input.Select(x => x.order_id).Distinct().ToList());

            var list = _imapper.Map<List<CreateMaintRepairOrderFile>, List<MaintRepairOrderFile>>(input);
            list.ForEach(x =>
            {
                x.created_id = user_id;
                x.created_date = DateTime.Now;
            });

            await SqlSugarHelper.DBClient(server_id).Insertable(list).ExecuteCommandAsync();

            return _imapper.Map<List<MaintRepairOrderFile>, List<MaintRepairOrderFileDto>>(list);
        }

        public async Task<int> DeleteAsync(string server_id, List<int> order_ids)
        {
            return await SqlSugarHelper.DBClient(server_id)
                .Deleteable<MaintRepairOrderFile>()
                .Where(x => order_ids.Contains(x.order_id))
                .ExecuteCommandAsync();
        }
    }
}
