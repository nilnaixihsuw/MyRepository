﻿using AutoMapper;
using ERPBll.Repairs.Contracts;
using ERPDal;
using ERPModel.MaintManage;
using ERPModel.UserManage;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.Repairs.Services
{
    public class MaintDeptImp: IMaintDeptImp
    {

        public async Task<object> GetDepartmentAsync(string server_id, decimal? user_id)
        {
            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpMaintenanceDepartment>()
                                .OrderBy(x => x.i_id, OrderByType.Desc)
                                .Select(x => new
                                {
                                    id = x.i_id,
                                    name = x.c_name
                                })
                                .ToListAsync();
            return list;
        }

        public async Task<object> GetShopAsync(string server_id, decimal? user_id, decimal? dept_id)
        {
            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpMaintenanceShop>()
                                .Where(x => x.i_main_id == dept_id)
                                //.OrderBy(x => x.i_id, OrderByType.Desc)
                                .OrderBy(x => x.sort)
                                .Select(x => new
                                {
                                    id = x.i_id,
                                    name = x.c_name
                                })
                                .ToListAsync();
            return list;
        }

        public async Task<object> GetPersonAsync(string server_id, decimal? user_id, decimal? dept_id, decimal? shop_id)
        {
            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpMaintenancePerson>()
                                .Where(x => x.i_main_id == shop_id)
                                .Mapper(async x =>
                                {
                                    x.emp_name = (await SqlSugarHelper.DBClient(server_id)
                                                    .Queryable<SysPerson>()
                                                    .FirstAsync(i => i.i_id == x.i_person_id))?.c_name;
                                })
                                .OrderBy(x => x.i_person_id, OrderByType.Desc)
                                .ToListAsync();

            return list.Select(x => new { id = x.i_person_id, name = x.emp_name }).ToList();
        }

        public async Task<object> GetItemAsync(string server_id, decimal? user_id, decimal? group_id)
        {
            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpMaintenanceItem>()
                                .WhereIF(group_id.HasValue, x => x.i_group_id == group_id)
                                .OrderBy(x => x.i_id, OrderByType.Desc)
                                .Select(x => new
                                {
                                    id = x.i_id,
                                    name = x.c_name
                                })
                                .ToListAsync();
            return list;
        }

        public async Task<bool> ChangeShopSort(List<ChangeSortDetail> request, string server_id)
        {
            var list = await SqlSugarHelper.DBClient(server_id).Queryable<ErpMaintenanceShop>()
                .Where(r => request.Select(m => m.id).Contains((int)r.i_id)).ToListAsync();
            list.ForEach(r => r.sort = request.Find(m => m.id == r.i_id).sort);
            return await SqlSugarHelper.DBClient(server_id).Updateable(list).ExecuteCommandAsync() > 0;
        }
    }
}
