﻿using AutoMapper;
using ERPBll.RedisManage.Dicts;
using ERPBll.RedisManage.Lines;
using ERPBll.Repairs.Contracts;
using ERPDal;
using ERPDal.Repository;
using ERPModel.MaterialManage.BaseinfoManage;
using ERPModel.MaterialManage.InventoryManage;
using ERPModel.Repairs.MaintOrderMaterials;
using ERPModel.Repairs.MaintRepairOrders;
using ERPModel.Vehicleinfomanage;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.Repairs.Services
{
    public class MaintRepairRefundImp : BaseBusiness<MaintRepairRefund>, IMaintRepairRefundImp
    {
        private readonly IMapper _imapper;
        private readonly ILineRedisImp _iLineRedisImp;
        private readonly IDictRedisManageImp _iDictRedisManageImp;
        private readonly IMaintRepairRefundDetailImp _iMaintRepairRefundDetailImp;
        public MaintRepairRefundImp(IMapper imapper,
            ILineRedisImp iLineRedisImp,
            IDictRedisManageImp iDictRedisManageImp,
            IMaintRepairRefundDetailImp iMaintRepairRefundDetailImp)
        {
            _imapper = imapper;
            _iLineRedisImp = iLineRedisImp;
            _iDictRedisManageImp = iDictRedisManageImp;
            _iMaintRepairRefundDetailImp = iMaintRepairRefundDetailImp;
        }

        public async Task<Tuple<int, List<RepairRefundDto>>> GetByPage(RepairRefundRequest request)
        {
            var ids = new List<decimal>();
            if (string.IsNullOrEmpty(request.material_name) && string.IsNullOrEmpty(request.material_code) && string.IsNullOrEmpty(request.specification))
            {
                ids = null;
            }
            else
            {
                var details = await SqlSugarHelper.DBClient(request.server_id).Queryable<MaintRepairPickDetail, ErpMaterialMain>((a, b) =>
                        new JoinQueryInfos(JoinType.Left, a.material_id == b.id))
                    .WhereIF(!string.IsNullOrEmpty(request.material_name), (a, b) => b.name.Contains(request.material_name))
                    .WhereIF(!string.IsNullOrEmpty(request.material_code), (a, b) => b.code.Contains(request.material_code))
                    .WhereIF(!string.IsNullOrEmpty(request.specification), (a, b) => b.specification.Contains(request.specification))
                    .ToListAsync();
                ids = details == null || details.Count == 0 ? new List<decimal>() : details.Select(r => r.pick_id).ToList();
            }
           
            RefAsync<int> totalNumber = 0;
            var records = await SqlSugarHelper.DBClient(request.server_id).Queryable<MaintRepairRefund>()
                .WhereIF(ids != null, a => ids.Contains(a.id.Value))
                .Where(request.ToExp())
                .Mapper(async a => a.details = await _iMaintRepairRefundDetailImp.GetData(request.server_id, r => r.refund_id == a.id))
                .Mapper(async a => a.pick_info = await SqlSugarHelper.DBClient(request.server_id).Queryable<MaintRepairPick>()
                     .Where(r => r.code == a.pick_code)
                     .Mapper(r => r.warenhouse_info, r => r.warenhouse_id).FirstAsync())
                .Mapper(a => a.created_info, a => a.created_id)
                .Mapper(async a => a.order_info = await SqlSugarHelper.DBClient(request.server_id).Queryable<MaintRepairOrder>()
                     .Where(r => r.id == a.order_id)
                     .Mapper(r => r.vehicle_info, r => r.vehicle_id).FirstAsync())
                .ToPageListAsync(request.page_index, request.page_size, totalNumber);

            List<RepairRefundDto> list = new List<RepairRefundDto>();
            var dic = await _iDictRedisManageImp.GetAllAsync();
            foreach (var item in records)
            {
                var temp = _imapper.Map<MaintRepairRefund, RepairRefundDto>(item);
                temp.lp_num = item.order_info?.vehicle_info?.c_lincense_plate_number;
                temp.created_name = item.created_info?.c_name;
                temp.warenhouse_name = item.pick_info?.warenhouse_info?.name;
                //temp.work_code = item.order_info?.work_code;
                temp.warenhouse_id = item.pick_info?.warenhouse_id;
                if (item.details != null && item.details.Count() > 0)
                {
                    foreach (var item1 in item.details)
                    {
                        var temp1 = Tools.DeepCopy(temp);
                        temp1.material_id = item1.material_id;
                        temp1.count = item1.count.Value;
                        temp1.material_code = item1.material_info?.code;
                        temp1.material_name = item1.material_info?.name;
                        temp1.specification = item1.material_info?.specification;
                        temp1.measure_unit_name = dic.Find(r => r.i_id == item1.material_info?.measure_unit)?.c_name;
                        list.Add(temp1);
                    }

                    //temp.refund_details = new List<RepairRefundDetails>();
                    //foreach (var item1 in item.details)
                    //{
                    //    RepairRefundDetails detail = _imapper.Map<MaintRepairRefundDetail, RepairRefundDetails>(item1);
                    //    detail.material_code = item1.material_info?.code;
                    //    detail.material_name = item1.material_info?.name;
                    //    detail.specification = item1.material_info?.specification;
                    //    detail.measure_unit_name = dic.Find(r => r.i_id == item1.material_info?.measure_unit)?.c_name;
                    //    temp.refund_details.Add(detail);
                    //}
                }
                else
                {
                    list.Add(temp);
                }
            }
            return new Tuple<int, List<RepairRefundDto>>(totalNumber, list);
        }
    }
}
