﻿using AutoMapper;
using ERPBll.RedisManage.Lines;
using ERPBll.Repairs.Contracts;
using ERPDal;
using ERPDal.Repository;
using ERPModel.Repairs.MaintRepairPackage;
using ERPModel.UserManage;
using ERPModel.Vehicleinfomanage;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.Repairs.Services
{
    public class MaintRepairPackageImp: BaseBusiness<MaintRepairPackage>, IMaintRepairPackageImp
    {
        private readonly IMapper _imapper;
        private readonly ILineRedisImp _iLineRedisImp;
        public MaintRepairPackageImp(IMapper imapper,
            ILineRedisImp iLineRedisImp)
        {
            _imapper = imapper;
            _iLineRedisImp = iLineRedisImp;
        }
        public async Task<Tuple<int, List<MaintRepairPackageDto>>> GetByPageAsync(MaintRepairPackageQuery request)
        {
            RefAsync<int> total = 0;
            if (request.group_id != null && request.group_id.Count > 0)
            {
                var vehicles = await SqlSugarHelper.DBClient(request.server_id).Queryable<VehicleInfoNew>()
                    .Where(r => request.group_id.Contains(Convert.ToInt32(r.group))).ToListAsync();
                if (request.vehicle_ids == null || request.vehicle_ids.Count == 0)
                {
                    request.vehicle_ids = vehicles.Select(r => r.id.Value).ToList();
                }
                else
                {
                    request.vehicle_ids.AddRange(vehicles.Select(r => r.id.Value).ToList());
                }
            }

            var records = await SqlSugarHelper.DBClient(request.server_id).Queryable<MaintRepairPackage>()
                .Where(request.ToExp())
                .Mapper(async r => r.vehicle_info = await SqlSugarHelper.DBClient(request.server_id).Queryable<VehicleInfoNew>()
                                            .Where(m => m.id == r.vehicle_id)
                                            .Mapper(m => m.vehicle_kind_info, m => m.cid)
                                            .Mapper(m => m.group_info, m => m.group).FirstAsync())
                .Mapper(r => r.vender_info, r => r.vender_id)
                .OrderBy(r => r.repair_date, OrderByType.Desc)
                .OrderBy(r => r.created_date, OrderByType.Desc)
                .ToPageListAsync(request.page_index, request.page_size, total);

            var persons = await SqlSugarHelper.DBClient(request.server_id).Queryable<SysPerson>().ToListAsync();
            var line_vehicles = await _iLineRedisImp.GetLineVehAsync();
            var list = new List<MaintRepairPackageDto>();
            foreach (var item in records)
            {
                var temp = _imapper.Map<MaintRepairPackage, MaintRepairPackageDto>(item);
                temp.lp_num = item.vehicle_info?.lp_num;
                temp.group_name = item.vehicle_info?.group_info?.c_name;
                temp.v_num = item.vehicle_info?.v_num;
                temp.line_name = line_vehicles.Find(r => r.lp_num == temp.lp_num)?.line_name;
                temp.vehicle_kind = item.vehicle_info?.vehicle_kind_info?.c_name;
                temp.vender_name = item.vender_info?.c_name;
                temp.repair_name = persons.Find(r => r.i_id == item.repair_id)?.c_name;
                temp.check_name = persons.Find(r => r.i_id == item.check_id)?.c_name;
                temp.created_name = persons.Find(r => r.i_id == item.created_id)?.c_name;
                list.Add(temp);
            }
            return new Tuple<int, List<MaintRepairPackageDto>>(total, list);
        }
    }
}
