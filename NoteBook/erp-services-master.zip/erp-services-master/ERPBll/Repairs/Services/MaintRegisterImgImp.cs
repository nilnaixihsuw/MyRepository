﻿using AutoMapper;
using ERPDal;
using ERPModel.Repairs.MaintRegisterImgs;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.Repairs
{
    /// <summary>
    /// 报修相关图片
    /// </summary>
    public class MaintRegisterImgImp : IMaintRegisterImgImp
    {
        private readonly IMapper _imapper;

        public MaintRegisterImgImp(
           IMapper imapper)
        {
            _imapper = imapper;
        }

        public async Task<List<string>> AddAsync(
            string server_id, decimal? user_id, int repair_id, List<string> imgs)
        {
            var list = new List<MaintRegisterImg>();
            foreach (var item in imgs)
            {
                var info = new MaintRegisterImg()
                {
                    repair_id = repair_id,
                    url = item,
                    created_id = user_id,
                    created_date = DateTime.Now
                };
                list.Add(info);
            }

            await SqlSugarHelper.DBClient(server_id).Insertable(list).ExecuteCommandAsync();

            return imgs;
        }

        public async Task<int> DeleteAsync(string server_id, decimal repair_id)
        {
            return await SqlSugarHelper.DBClient(server_id)
                .Deleteable<MaintRegisterImg>()
                .Where(x => x.repair_id == repair_id).ExecuteCommandAsync();
        }
    }
}
