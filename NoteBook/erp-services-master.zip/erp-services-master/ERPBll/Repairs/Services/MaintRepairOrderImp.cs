﻿using AutoMapper;
using DotNetCore.CAP;
using ERPBll.Caps;
using ERPBll.RedisManage;
using ERPBll.RedisManage.Extension;
using ERPBll.RedisManage.Lines;
using ERPBll.RedisManage.Users;
using ERPBll.Repairs.Contracts;
using ERPBll.Vehicleinfomanage;
using ERPCore.DI;
using ERPDal;
using ERPDal.Repository;
using ERPModel.MaintManage;
using ERPModel.Repairs;
using ERPModel.Repairs.MaintRepairChecks;
using ERPModel.Repairs.MaintRepairItems;
using ERPModel.Repairs.MaintRepairLifes;
using ERPModel.Repairs.MaintRepairOrders;
using ERPModel.Vehicleinfomanage;
using Microsoft.Extensions.DependencyInjection;
using Serilog;
using Spire.Doc;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using ERPCore.Helpers;
using Spire.Doc.Documents;
using Spire.Doc.Fields;
using static ERPCore.Helpers.WordExportHelper;
using ERPModel.Repairs.MaintRepairFees;
using ERPModel.Repairs.MaintRepairFaults;
using ERPModel.UserManage;
using ERPModel.Workplace;
using ERPBll.WorkPlace;
using ERPCore.Entity;
using ERPModel.Repairs.MaintNoticeRule;
using BusTools.JiGuang.Contracts;
using Microsoft.Extensions.Configuration;
using ERPDal.DataBase;

namespace ERPBll.Repairs.Services
{
    /// <summary>
    /// 工单管理
    /// </summary>
    public class MaintRepairOrderImp : BaseBusiness<MaintRepairOrder>, IMaintRepairOrderImp, ICapSubscribe
    {
        private readonly IMapper _imapper;
        private readonly ICapPublisher _publisher;
        private readonly IMaintRepairRecordImp _maintRepairRecordImp;
        private readonly IMaintRepairItemImp _maintRepairItemImp;
        private readonly IMaintRepairCheckImp _maintRepairCheckImp;
        private readonly IMaintRepairFeeImp _maintRepairFeeImp;
        private readonly IMaintOrderMaterialImp _maintOrderMaterialImp;
        private readonly IUserRedisImp _userRedisImp;
        private readonly IWarehouseRedisManageImp _iWarehouseRedisManageImp;
        private readonly IErpVehicleStateWarnImp _iErpVehicleStateWarnImp;
        private readonly ILogger _logger = Log.Logger;
        private readonly ILineRedisImp _iLineRedisImp;
        private readonly IJSMSService _iJiGuangService;
        private readonly JiGuangMessageConfig _option;

        public MaintRepairOrderImp(
           IMapper imapper,
           ICapPublisher publisher,
           IMaintRepairRecordImp maintRepairRecordImp,
           IMaintRepairItemImp maintRepairItemImp,
           //IMaintRepairCheckImp maintRepairCheckImp,
           IMaintRepairFeeImp maintRepairFeeImp,
           IMaintOrderMaterialImp maintOrderMaterialImp,
           IWarehouseRedisManageImp iWarehouseRedisManageImp,
           IUserRedisImp userRedisImp,
           ILineRedisImp iLineRedisImp,
           IJSMSService iJiGuangService,
           IConfiguration option,
           IErpVehicleStateWarnImp iErpVehicleStateWarnImp)
        {
            _imapper = imapper;
            _publisher = publisher;
            _maintRepairRecordImp = maintRepairRecordImp;
            _maintRepairItemImp = maintRepairItemImp;
            _maintRepairCheckImp = DIContainer.ServiceLocator.Instance.GetService<IMaintRepairCheckImp>();
            _maintRepairFeeImp = maintRepairFeeImp;
            _maintOrderMaterialImp = maintOrderMaterialImp;
            _userRedisImp = userRedisImp;
            _iWarehouseRedisManageImp = iWarehouseRedisManageImp;
            _iLineRedisImp = iLineRedisImp;
            _iErpVehicleStateWarnImp = iErpVehicleStateWarnImp;
            _iJiGuangService = iJiGuangService;
            _option = option.GetSection("JiGuangMessageConfig").Get<JiGuangMessageConfig>();
        }

        public async Task<(List<MaintRepairOrderDto>, int)> GetByPageAsync(
            string server_id, decimal? user_id, MaintRepairOrderQuery query)
        {
            RefAsync<int> totalCount = 0;

            var exp = await DoQueryAsync(server_id, user_id, query);
            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<MaintRepairOrder>()
                                .Where(exp)
                                .Mapper(x => x.type_child_info, x => x.type_child)
                                .Mapper(x => x.state_child_info, x => x.state_child)
                                .Mapper(x => x.maint_dept_info, x => x.maint_dept)
                                .Mapper(x => x.dispatch_info, x => x.dispatch_id)
                                .Mapper(x => x.receive_info, x => x.receive_id)
                                .Mapper(x => x.finish_info, x => x.finish_id)
                                .Mapper(x => x.finish_check_info, x => x.finish_check_id)
                                .Mapper(x => x.out_info, x => x.out_id)
                                .Mapper(async x =>
                                {
                                    x.vehicle_info = await SqlSugarHelper.DBClient(server_id)
                                                            .Queryable<ErpVehicleInfo>()
                                                            .Mapper(x => x.department_info, x => x.c_crews_take)
                                                            .Mapper(x => x.kind_info, x => x.c_id)
                                                            .FirstAsync(t => t.i_id == x.vehicle_id);

                                    x.repair_check = await _maintRepairCheckImp.GetByRepairIdAsync(server_id, x.repair_id);

                                    x.repair_items = await _maintRepairItemImp.GetByOrderId(server_id, x.id);

                                    //x.repair_dispatchs = await _maintRepairItemImp.GetItems(server_id, x.id);

                                    x.repair_fee = await _maintRepairFeeImp.GetByOrderIdAsync(server_id, x.id);

                                    x.repair_materials = await _maintOrderMaterialImp.GetByWorkCodeAsync(server_id, x.work_code);
                                })
                                .OrderBy(x => x.repair_time, OrderByType.Desc)
                                .ToPageListAsync(query.page_index, query.page_size, totalCount);

            //var list = await SqlSugarHelper.DBClient(server_id)
            //                .Queryable<MaintRepairOrder>()
            //                .Where(exp)
            //                .Includes(x => x.type_child_info)
            //                .Includes(x => x.state_child_info)
            //                .Includes(x => x.maint_dept_info)
            //                .Includes(x => x.dispatch_info)
            //                .Includes(x => x.receive_info)
            //                .Includes(x => x.finish_info)
            //                .Includes(x => x.finish_check_info)
            //                .Includes(x => x.out_info)
            //                .Includes(x => x.vehicle_info, vi => vi.department_info)
            //                .Includes(x => x.vehicle_info, vi => vi.kind_info)
            //                .Includes(x => x.repair_check.MappingField(y => y.repair_id, () => x.repair_id).ToList())
            //                .Mapper(async x => x.repair_fee = await _maintRepairFeeImp.GetByOrderIdAsync(server_id, x.id))
            //                .OrderBy(x => x.repair_time, OrderByType.Desc)
            //                .ToPageListAsync(query.page_index, query.page_size, totalCount);

            var data = _imapper.Map<List<MaintRepairOrder>, List<MaintRepairOrderDto>>(list);
            var repair_records = await SqlSugarHelper.DBClient(server_id).Queryable<MaintRepairRecord>().ToListAsync();
            data.ForEach(r => r.repair_describe = repair_records.Find(m => m.id == r.repair_id)?.repair_describe);
            return (data, totalCount);
        }

        public async Task<Count> GetCount(string server_id, decimal? user_id, MaintRepairOrderQuery query)
        {
            RefAsync<int> totalCount = 0;

            var exp = await DoQueryAsync(server_id, user_id, query);
            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<MaintRepairOrder>()
                                .Where(exp).ToListAsync();
            var result = new Count();
            result.pre_repair = list.Where(r => r.state == 1).Count();
            result.repairing = list.Where(r => r.state == 2).Count();
            result.end_repair = list.Where(r => r.state == 3).Count();
            return result;
        }

        public async Task<List<MaintRepairOrderDto>> GetDataAsync(MaintRepairOrderQuery query)
        {
            var list = await SqlSugarHelper.DBClient(query.server_id)
                              .Queryable<MaintRepairOrder>()
                              .WhereIF(query.date_type == 3 && query.start_date.HasValue && query.end_date.HasValue, //完工时间查询
                                    x => x.finish_time >= query.start_date.Value && x.finish_time <= query.end_date.Value)
                              .Where(x => x.state > 2)
                              .Mapper(async x =>
                              {
                                  x.vehicle_info = await SqlSugarHelper.DBClient(query.server_id)
                                                          .Queryable<ErpVehicleInfo>()
                                                          .Mapper(x => x.department_info, x => x.c_crews_take)
                                                          .Mapper(x => x.kind_info, x => x.c_id)
                                                          .FirstAsync(t => t.i_id == x.vehicle_id);
                              }).ToListAsync();

            var data = _imapper.Map<List<MaintRepairOrder>, List<MaintRepairOrderDto>>(list);
            return data;
        }

        public async Task SaveRepairTable(string fileName, string savePath, MaintRepairOrderDto context)
        {
            if (!Directory.Exists(savePath))
            {
                Directory.CreateDirectory(savePath);
            }
            var line_vehs = await _iLineRedisImp.GetLineVehAsync();
            var records = await SqlSugarHelper.DBClient("60.191.59.11")
                                .Queryable<MaintRepairRecord>()
                                .Mapper(x => x.repair_user_info, x => x.repair_user_id)
                                .ToListAsync();
            var repairFee = await SqlSugarHelper.DBClient("60.191.59.11")
                               .Queryable<MaintRepairFee>()
                               .Mapper(x => x.dept_info, x => x.dept_id)
                               .Where(x => x.order_id == context.id)
                               .Mapper(x => x.settlement_info, x => x.settlement)
                               .FirstAsync();

            fileName = $"{fileName}.docx";
            //实例化一个Document对象,并添加section
            Spire.Doc.Document doc = new Spire.Doc.Document();
            Section sec = doc.AddSection();
            SetParagraph(sec, HorizontalAlignment.Center, new WordText()
            {
                text = $"温州长安集团有限公司汽车大修厂结算单",
                font_name = "楷体_GB2312",
                font_size = 20,
                is_blod = true
            });
            SetParagraph(sec, HorizontalAlignment.Left, new WordText() { text = "" });

            string out_time = context.out_time.HasValue ? context.out_time.Value.ToString("yyyy-MM-dd") : "";
            string end_date = context.repair_fee?.end_date.ToString("yyyy-MM-dd") ;
            string title = $"单号：{context.work_code}\t进场日期：{context.repair_time.ToString("yyyy-MM-dd")}\t出厂日期：{out_time}\t结算日期：{end_date}";
            SetParagraph(sec, HorizontalAlignment.Left, new WordText()
            {
                text = title,
                font_name = "宋体",
                font_size = 9,
                is_blod = false
            });

            //设置自定义样式
            ParagraphStyle style = new ParagraphStyle(doc);
            style.Name = "TableStyle";
            style.CharacterFormat.FontSize = 10;
            style.CharacterFormat.FontName = "宋体";
            style.CharacterFormat.Bold = false;
            //将自定义样式添加到文档
            doc.Styles.Add(style);

            ParagraphStyle style1 = new ParagraphStyle(doc);
            style1.Name = "TableStyle1";
            style1.CharacterFormat.FontSize = 8;
            style1.CharacterFormat.FontName = "宋体";
            style1.CharacterFormat.Bold = false;
            //将自定义样式添加到文档
            doc.Styles.Add(style1);

            //表格填充数据
            Table table = sec.AddTable(true);
            table.ResetCells(5, 6);
            table.Rows[0].Height = 26;
            table.Rows[1].Height = 26;
            table.Rows[2].Height = 20;
            table.Rows[3].Height = 20;
            table.Rows[4].Height = 20;
            table.ColumnWidth = new float[6] { 30, 30, 30, 30, 30, 30 };
            TextRange range = table[0, 0].AddParagraph().AppendText("车牌：");
            table[0, 0].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Center;
            table[0, 0].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
            table[0, 0].Paragraphs[0].ApplyStyle(style.Name);

            range = table[0, 1].AddParagraph().AppendText(context.vehicle_info?.vehicle_name);
            table[0, 1].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Center;
            table[0, 1].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
            table[0, 1].Paragraphs[0].ApplyStyle(style.Name);

            range = table[0, 2].AddParagraph().AppendText("车  型：");
            table[0, 2].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Center;
            table[0, 2].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
            table[0, 2].Paragraphs[0].ApplyStyle(style.Name);

            range = table[0, 3].AddParagraph().AppendText(context.vehicle_info?.vehicle_kind_name);
            table[0, 3].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Center;
            table[0, 3].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
            table[0, 3].Paragraphs[0].ApplyStyle(style.Name);

            range = table[0, 4].AddParagraph().AppendText("线路：");
            table[0, 4].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Center;
            table[0, 4].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
            table[0, 4].Paragraphs[0].ApplyStyle(style.Name);

            range = table[0, 5].AddParagraph().AppendText(line_vehs.Find(r => r.lp_num == context.vehicle_info?.vehicle_name)?.line_name);
            table[0, 5].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Center;
            table[0, 5].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
            table[0, 5].Paragraphs[0].ApplyStyle(style.Name);

            range = table[1, 0].AddParagraph().AppendText("车主：");
            table[1, 0].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Center;
            table[1, 0].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
            table[1, 0].Paragraphs[0].ApplyStyle(style.Name);

            range = table[1, 1].AddParagraph().AppendText("");
            table[1, 1].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Center;
            table[1, 1].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
            table[1, 1].Paragraphs[0].ApplyStyle(style.Name);

            range = table[1, 2].AddParagraph().AppendText("报修人：");
            table[1, 2].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Center;
            table[1, 2].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
            table[1, 2].Paragraphs[0].ApplyStyle(style.Name);

            range = table[1, 3].AddParagraph().AppendText(records.Find(r => r.id == context.repair_id)?.repair_user_info?.c_name);
            table[1, 3].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Center;
            table[1, 3].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
            table[1, 3].Paragraphs[0].ApplyStyle(style.Name);

            range = table[1, 4].AddParagraph().AppendText("报修类别：");
            table[1, 4].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Center;
            table[1, 4].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
            table[1, 4].Paragraphs[0].ApplyStyle(style.Name);

            range = table[1, 5].AddParagraph().AppendText(context.type_child_name);
            table[1, 5].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Center;
            table[1, 5].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
            table[1, 5].Paragraphs[0].ApplyStyle(style.Name);

            #region 维修项目
            table.ApplyHorizontalMerge(2, 0, 4);
            table.ApplyHorizontalMerge(3, 0, 4);
            table.ApplyHorizontalMerge(4, 0, 4);
            TextRange range1 = table[2, 0].AddParagraph().AppendText("维修项目");
            table[2, 0].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Center;
            table[2, 0].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
            table[2, 0].Paragraphs[0].ApplyStyle(style1.Name);

            range1 = table[2, 5].AddParagraph().AppendText("费用");
            table[2, 5].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Center;
            table[2, 5].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
            table[2, 5].Paragraphs[0].ApplyStyle(style1.Name);
            if (context.repair_items != null && context.repair_items.Count > 0)
            {
                int count = context.repair_items.Count;
                string item_names = string.Empty;
                string fees = string.Empty;
                for (int i = 0; i < count; i++)
                {
                    item_names += $"{i + 1}.{context.repair_items[i].item_name}\n";
                    fees += $"{context.repair_items[i].actual_fee:0.00}\n";
                }
                range1 = table[3, 0].AddParagraph().AppendText(item_names);
                table[3, 0].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Left;
                table[3, 0].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
                table[3, 0].Paragraphs[0].ApplyStyle(style1.Name);

                range1 = table[3, 5].AddParagraph().AppendText(fees);
                table[3, 5].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Right;
                table[3, 5].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
                table[3, 5].Paragraphs[0].ApplyStyle(style1.Name);

                range1 = table[4, 0].AddParagraph().AppendText("合计：");
                table[4, 0].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Right;
                table[4, 0].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
                table[4, 0].Paragraphs[0].ApplyStyle(style1.Name);

                range1 = table[4, 5].AddParagraph().AppendText(context.repair_items.Sum(r => r.actual_fee).ToString("0.00"));
                table[4, 5].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Right;
                table[4, 5].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
                table[4, 5].Paragraphs[0].ApplyStyle(style1.Name);
            }
            else
            {
                range1 = table[4, 0].AddParagraph().AppendText("合计：");
                table[4, 0].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Right;
                table[4, 0].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
                table[4, 0].Paragraphs[0].ApplyStyle(style1.Name);

                range1 = table[4, 5].AddParagraph().AppendText("0");
                table[4, 5].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Right;
                table[4, 5].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
                table[4, 5].Paragraphs[0].ApplyStyle(style1.Name);
            }
            #endregion

            #region 材料项目
            Table table2 = sec.AddTable(true);
            int row2 = 3;
            if (context.repair_materials != null && context.repair_items.Count > 0) row2 += context.repair_items.Count / 2;
            table2.ResetCells(row2, 10);
            //table2.Rows[0].Height = 20;
            //table2.Rows[1].Height = 20;
            //table2.Rows[row2 - 1].Height = 20;
            //table2.ColumnWidth = new float[10] { 10, 50, 10, 10, 10, 10, 50, 10, 10, 10 };
            float c = 28;
            float d = 136;
            for (int i = 0; i < table2.Rows.Count; i++)
            {
                table2.Rows[i].Height = 20;
                table2.Rows[i].Cells[0].Width = c;
                table2.Rows[i].Cells[1].Width = d;
                table2.Rows[i].Cells[2].Width = c;
                table2.Rows[i].Cells[3].Width = c;
                table2.Rows[i].Cells[4].Width = c;
                table2.Rows[i].Cells[5].Width = c;
                table2.Rows[i].Cells[6].Width = d;
                table2.Rows[i].Cells[7].Width = c;
                table2.Rows[i].Cells[8].Width = c;
                table2.Rows[i].Cells[9].Width = c;
            }
            table2.ApplyHorizontalMerge(row2 - 1, 0, 8);

            TextRange range2 = table2[0, 0].AddParagraph().AppendText("序号");
            table2[0, 0].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Center;
            table2[0, 0].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
            table2[0, 0].Paragraphs[0].ApplyStyle(style1.Name);

            range2 = table2[0, 1].AddParagraph().AppendText("材料项目");
            table2[0, 1].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Center;
            table2[0, 1].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
            table2[0, 1].Paragraphs[0].ApplyStyle(style1.Name);

            range2 = table2[0, 2].AddParagraph().AppendText("数量");
            table2[0, 2].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Center;
            table2[0, 2].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
            table2[0, 2].Paragraphs[0].ApplyStyle(style1.Name);

            range2 = table2[0, 3].AddParagraph().AppendText("单价");
            table2[0, 3].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Center;
            table2[0, 3].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
            table2[0, 3].Paragraphs[0].ApplyStyle(style1.Name);

            range2 = table2[0, 4].AddParagraph().AppendText("金额");
            table2[0, 4].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Center;
            table2[0, 4].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
            table2[0, 4].Paragraphs[0].ApplyStyle(style1.Name);

            range2 = table2[0, 5].AddParagraph().AppendText("序号");
            table2[0, 5].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Center;
            table2[0, 5].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
            table2[0, 5].Paragraphs[0].ApplyStyle(style1.Name);

            range2 = table2[0, 6].AddParagraph().AppendText("材料项目");
            table2[0, 6].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Center;
            table2[0, 6].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
            table2[0, 6].Paragraphs[0].ApplyStyle(style1.Name);

            range2 = table2[0, 7].AddParagraph().AppendText("数量");
            table2[0, 7].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Center;
            table2[0, 7].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
            table2[0, 7].Paragraphs[0].ApplyStyle(style1.Name);

            range2 = table2[0, 8].AddParagraph().AppendText("单价");
            table2[0, 8].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Center;
            table2[0, 8].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
            table2[0, 8].Paragraphs[0].ApplyStyle(style1.Name);

            range2 = table2[0, 9].AddParagraph().AppendText("金额");
            table2[0, 9].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Center;
            table2[0, 9].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
            table2[0, 9].Paragraphs[0].ApplyStyle(style1.Name);
            if (context.repair_materials != null && context.repair_materials.Count > 0)
            {
                int count = context.repair_materials.Count;
                for (int i = 0; i < count; i++)
                {
                    int a = i / 2;
                    int b = i % 2;
                    if (b == 0)
                    {
                        range2 = table2[1 + a, 0].AddParagraph().AppendText((i + 1).ToString());
                        table2[1 + a, 0].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Center;
                        table2[1 + a, 0].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
                        table2[1 + a, 0].Paragraphs[0].ApplyStyle(style1.Name);

                        range2 = table2[1 + a, 1].AddParagraph().AppendText(context.repair_materials[i].material_name);
                        table2[1 + a, 1].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Center;
                        table2[1 + a, 1].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
                        table2[1 + a, 1].Paragraphs[0].ApplyStyle(style1.Name);

                        range2 = table2[1 + a, 2].AddParagraph().AppendText(context.repair_materials[i].count.ToString());
                        table2[1 + a, 2].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Center;
                        table2[1 + a, 2].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
                        table2[1 + a, 2].Paragraphs[0].ApplyStyle(style1.Name);

                        range2 = table2[1 + a, 3].AddParagraph().AppendText(context.repair_materials[i].price.ToString("0.00"));
                        table2[1 + a, 3].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Center;
                        table2[1 + a, 3].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
                        table2[1 + a, 3].Paragraphs[0].ApplyStyle(style1.Name);

                        range2 = table2[1 + a, 4].AddParagraph().AppendText(context.repair_materials[i].total_price.ToString("0.00"));
                        table2[1 + a, 4].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Center;
                        table2[1 + a, 4].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
                        table2[1 + a, 4].Paragraphs[0].ApplyStyle(style1.Name);
                    }
                    else
                    {
                        range2 = table2[1 + a, 5].AddParagraph().AppendText((i + 1).ToString());
                        table2[1 + a, 5].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Center;
                        table2[1 + a, 5].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
                        table2[1 + a, 5].Paragraphs[0].ApplyStyle(style1.Name);

                        range2 = table2[1 + a, 6].AddParagraph().AppendText(context.repair_materials[i].material_name);
                        table2[1 + a, 6].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Center;
                        table2[1 + a, 6].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
                        table2[1 + a, 6].Paragraphs[0].ApplyStyle(style1.Name);

                        range2 = table2[1 + a, 7].AddParagraph().AppendText(context.repair_materials[i].count.ToString());
                        table2[1 + a, 7].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Center;
                        table2[1 + a, 7].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
                        table2[1 + a, 7].Paragraphs[0].ApplyStyle(style1.Name);

                        range2 = table2[1 + a, 8].AddParagraph().AppendText(context.repair_materials[i].price.ToString("0.00"));
                        table2[1 + a, 8].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Center;
                        table2[1 + a, 8].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
                        table2[1 + a, 8].Paragraphs[0].ApplyStyle(style1.Name);

                        range2 = table2[1 + a, 9].AddParagraph().AppendText(context.repair_materials[i].total_price.ToString("0.00"));
                        table2[1 + a, 9].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Center;
                        table2[1 + a, 9].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
                        table2[1 + a, 9].Paragraphs[0].ApplyStyle(style1.Name);
                    }
                }
                range2 = table2[row2 - 1, 0].AddParagraph().AppendText("合计：");
                table2[row2 - 1, 0].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Right;
                table2[row2 - 1, 0].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
                table2[row2 - 1, 0].Paragraphs[0].ApplyStyle(style1.Name);

                range2 = table2[row2 - 1, 9].AddParagraph().AppendText(context.repair_materials.Sum(r => r.total_price).ToString("0.00"));
                table2[row2 - 1, 9].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Right;
                table2[row2 - 1, 9].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
                table2[row2 - 1, 9].Paragraphs[0].ApplyStyle(style1.Name);
            }
            else
            {
                range2 = table2[row2 - 1, 0].AddParagraph().AppendText("合计：");
                table2[row2 - 1, 0].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Right;
                table2[row2 - 1, 0].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
                table2[row2 - 1, 0].Paragraphs[0].ApplyStyle(style1.Name);

                range2 = table2[row2 - 1, 9].AddParagraph().AppendText("0");
                table2[row2 - 1, 9].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Right;
                table2[row2 - 1, 9].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
                table2[row2 - 1, 9].Paragraphs[0].ApplyStyle(style1.Name);
            }
            #endregion

            #region 末尾
            Table table3 = sec.AddTable(true);
            table3.ResetCells(2, 3);
            table3.ApplyHorizontalMerge(0, 0, 1);
            table3.Rows[0].Height = 26;
            table3.Rows[1].Height = 26;
            table3.ColumnWidth = new float[3] { 60, 60, 60 };

            decimal total = 0;
            if (context.repair_materials != null) total += context.repair_materials.Sum(r => r.total_price);
            if (context.repair_items != null) total += context.repair_items.Sum(r => r.actual_fee);
            string left = $"大写:\t{NumberToUpper.ToUpper(total)}";
            TextRange range3 = table3[0, 0].AddParagraph().AppendText(left);
            table3[0, 0].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Left;
            table3[0, 0].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
            table3[0, 0].Paragraphs[0].ApplyStyle(style.Name);

            string right = $"总计：\t{total.ToString("0.00")}";
            range3 = table3[0, 2].AddParagraph().AppendText(right);
            table3[0, 2].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Right;
            table3[0, 2].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
            table3[0, 2].Paragraphs[0].ApplyStyle(style.Name);

            left = $"支付方式：\t{repairFee?.settlement_info?.c_name}";
            range3 = table3[1, 0].AddParagraph().AppendText(left);
            table3[1, 0].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Left;
            table3[1, 0].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
            table3[1, 0].Paragraphs[0].ApplyStyle(style.Name);

            string m = repairFee?.total == null ? "0" : repairFee.total.Value.ToString("0.00");
            string middle = $"应收金额:\t{m}";
            range3 = table3[1, 1].AddParagraph().AppendText(middle);
            table3[1, 1].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Right;
            table3[1, 1].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
            table3[1, 1].Paragraphs[0].ApplyStyle(style.Name);

            string r = repairFee?.pay_fee == null ? "0" : repairFee.pay_fee.Value.ToString("0.00");
            right = $"本次收款：\t{r}";
            range3 = table3[1, 2].AddParagraph().AppendText(right);
            table3[1, 2].Paragraphs[0].Format.HorizontalAlignment = HorizontalAlignment.Center;
            table3[1, 2].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
            table3[1, 2].Paragraphs[0].ApplyStyle(style.Name);

            #endregion

            SetParagraph(sec, HorizontalAlignment.Left, new WordText()
            {
                text = "客户验收及签署:",
                font_name = "宋体",
                font_size = 16,
                is_blod = true
            });
            SetParagraph(sec, HorizontalAlignment.Right, new WordText()
            {
                text = $"操作员：{context.receive_name}",
                font_name = "宋体",
                font_size = 12,
            });
            //SetParagraph(sec, HorizontalAlignment.Right, new WordText()
            //{
            //    text = "地址：敖江大道310号",
            //    font_name = "宋体",
            //    font_size = 12,
            //});
            doc.SaveToFile(Path.Combine(savePath, fileName));
        }

        public async Task<List<MaintRepairOrderDto>> GetSimpleDataAsync(DateTime? start, DateTime? end, string server_id = "60.191.59.11")
        {
            var list = await SqlSugarHelper.DBClient(server_id)
                                     .Queryable<MaintRepairOrder>()
                                     //.Where(r => r.created_date >= DateTime.Now.AddDays(-10))
                                     .WhereIF(start != null && end != null, r => r.created_date >= start && r.created_date <= end)
                                     .Mapper(r => r.vehicle_info, r => r.vehicle_id).ToListAsync();

            var data = _imapper.Map<List<MaintRepairOrder>, List<MaintRepairOrderDto>>(list);
            return data;
        }

        //工单统计
        public async Task<int> GetOrderTotalData(string server_id, decimal? user_id, MaintRepairOrderQuery query)
        {
            var exp = await DoQueryAsync(server_id, user_id, query);
            return await SqlSugarHelper.DBClient(server_id)
                                .Queryable<MaintRepairOrder>()
                                .CountAsync(exp);
        }

        //维修平均时长
        public async Task<double> GetOrderAvgTime(string server_id, decimal? user_id, MaintRepairOrderQuery query)
        {
            var exp = await DoQueryAsync(server_id, user_id, query);
            var data = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<MaintRepairOrder>()
                                .Where(exp)
                                .Where(x => x.finish_check_time.HasValue && x.receive_time.HasValue)
                                .ToListAsync();
            return data.Count > 0 ? System.Math.Round(data.Average(x => (x.finish_check_time.Value - x.receive_time.Value).TotalHours), 2) : 0;
        }

        public async Task<List<MaintRepairOrderStepDto>> GetStepByIdAsync(string server_id, int id)
        {
            //查询
            var info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<MaintRepairOrder>()
                                .Where(x => x.id == id)
                                .Mapper(x => x.type_child_info, x => x.type_child)
                                .Mapper(x => x.state_child_info, x => x.state_child)
                                .Mapper(x => x.maint_dept_info, x => x.maint_dept)
                                .Mapper(x => x.dispatch_info, x => x.dispatch_id)
                                .Mapper(x => x.receive_info, x => x.receive_id)
                                .Mapper(x => x.finish_info, x => x.finish_id)
                                .Mapper(x => x.finish_check_info, x => x.finish_check_id)
                                .Mapper(x => x.out_info, x => x.out_id)
                                .Mapper(async x =>
                                {
                                    x.vehicle_info = await SqlSugarHelper.DBClient(server_id)
                                                            .Queryable<ErpVehicleInfo>()
                                                            .Mapper(x => x.department_info, x => x.c_crews_take)
                                                            .Mapper(x => x.kind_info, x => x.c_id)
                                                            .FirstAsync(t => t.i_id == x.vehicle_id);

                                    x.repair_record = await _maintRepairRecordImp.GetByIdAsync(server_id, x.repair_id);

                                    x.repair_check = await _maintRepairCheckImp.GetByRepairIdAsync(server_id, x.repair_id);

                                    x.repair_items = await _maintRepairItemImp.GetByOrderId(server_id, x.id);

                                    x.repair_materials = await _maintOrderMaterialImp.GetByWorkCodeAsync(server_id, x.work_code);

                                    x.repair_fee = await _maintRepairFeeImp.GetByOrderIdAsync(server_id, x.id);
                                })
                                .FirstAsync();

            List<MaintRepairOrderStepDto> list = new List<MaintRepairOrderStepDto>();
            int i = 0;
            foreach (var item in Enum.GetValues(typeof(MainRepairStateStep)))
            {
                MaintRepairOrderStepDto temp = new MaintRepairOrderStepDto();
                int step = (int)item;
                temp.index = i++;
                temp.step_name = item.ToString();
                temp.is_finish = step <= info.state;
                if (step <= info.state)
                {
                    temp.step_name = ((MainRepairStateStepFinish)step).ToString();
                }
                switch (item)
                {
                    case MainRepairStateStep.提交报修:
                        temp.date = info.repair_time;
                        temp.user_name = info.repair_record?.repair_user_name;
                        temp.is_finish = true;
                        break;
                    case MainRepairStateStep.进厂检验:
                        temp.date = info.repair_check?.check_time;
                        temp.user_name = info.repair_check?.check_info?.c_name;
                        temp.is_finish = true;
                        break;
                    case MainRepairStateStep.待接修:
                        temp.step_name = info.state > (int)MainRepairOrderState.待接修 ?
                            ((MainRepairStateStepFinish)step).ToString() : item.ToString();
                        temp.date = info.receive_time;
                        temp.user_name = info.receive_info?.c_name;
                        temp.is_finish = info.state > (int)MainRepairOrderState.待接修;
                        break;
                    case MainRepairStateStep.待完工检验:
                        temp.step_name = info.state > (int)MainRepairOrderState.维修中 ?
                            ((MainRepairStateStepFinish)step).ToString() : item.ToString();
                        temp.date = info.finish_check_time;
                        temp.user_name = info.finish_check_info?.c_name;
                        temp.is_finish = info.state > (int)MainRepairOrderState.维修中;
                        break;
                    case MainRepairStateStep.待出厂:
                        temp.step_name = info.state > (int)MainRepairOrderState.待出厂 ?
                            ((MainRepairStateStepFinish)step).ToString() : item.ToString();
                        temp.date = info.out_time;
                        temp.user_name = info.out_info?.c_name;
                        temp.is_finish = info.state > (int)MainRepairOrderState.待出厂;
                        break;
                }
                if (info.state_child > 0 && info.state_child_info != null)
                {
                    temp.step_name += $"({info.state_child_info.c_name})";
                }
                list.Add(temp);
            }
            return list;
        }

        [CapSubscribe(EventMessages.RepairCheck, Group = "RepairOrder")]
        public void AddRepairOrderMessage(MaintRepairCheck input)
        {
            try
            {
                var info = SqlSugarHelper.DBClient("60.191.59.11")
                                .Queryable<MaintRepairOrder>()
                                .First(x => x.repair_id == input.repair_id);
                if (info != null)
                {
                    return;
                }

                var record = SqlSugarHelper.DBClient("60.191.59.11")
                                .Queryable<MaintRepairRecord>()
                                .First(x => x.id == input.repair_id);
                if (record == null)
                {
                    throw new Exception($"未找到报修记录，id={input.repair_id}");
                }

                info = _imapper.Map<MaintRepairCheck, MaintRepairOrder>(input);
                info.id = Tools.GetEngineID("60.191.59.11");
                info.vehicle_id = record.vehicle_id;
                info.repair_time = record.repair_time;
                info.type = record.type;
                info.type_child = record.type_child;
             
                SqlSugarHelper.DBClient("60.191.59.11").Insertable(info).ExecuteCommand();

                ErpVehicleStateWarn temp = new ErpVehicleStateWarn
                {
                    vehicle_id = info.vehicle_id,
                    type = 3,
                    end_time = null,
                    created_id = 200000,
                    created_date = DateTime.Now.ToLocalTime()
                };
                _iErpVehicleStateWarnImp.Insert("60.191.59.11", temp);
            }
            catch (Exception ex)
            {
                Console.WriteLine("生成工单失败：" + ex.Message);
            }
        }

        public async Task<MaintRepairOrderDto> UpdateAsync(
            string server_id, decimal? user_id, UpdateMaintRepairOrder input)
        {
            var info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<MaintRepairOrder>()
                                .FirstAsync(x => x.id == input.id);
            if (info == null)
            {
                throw new Exception($"未找到工单记录，id={input.id}");
            }
            //本次修改内容
            var str = Tools.CompareClass<MaintRepairOrder, UpdateMaintRepairOrder>(info, input);

            _imapper.Map<UpdateMaintRepairOrder, MaintRepairOrder>(input, info);
            info.SetUpdate(user_id);

            await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync();

            //维修生命周期变更
            string userName = await _userRedisImp.GetNameByIdAsync(((int)user_id.Value).ToString());
            _publisher.Publish(EventMessages.RepairLifeUpdate,
                new CreateMaintRepairLife()
                {
                    repair_id = info.id,
                    title = string.Format(MaintRepairLifeTxt.UpdateRepair, userName),
                    content = str,
                    date = DateTime.Now,
                    created_id = user_id
                });

            return _imapper.Map<MaintRepairOrder, MaintRepairOrderDto>(info);
        }

        public async Task<MaintRepairOrderDto> UpdateStateAsync(
            string server_id, decimal? user_id, UpdateMaintRepairOrderState input)
        {
            var info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<MaintRepairOrder>()
                                .FirstAsync(x => x.id == input.order_id);
            if (info == null)
            {
                throw new Exception($"未找到工单记录，id={input.order_id}");
            }
            if (info.state > input.state)
            {
                throw new Exception($"工单状态错误:{((MainRepairOrderState)info.state).ToString()}->{((MainRepairOrderState)input.state).ToString()}");
            }

            info.SetUpdateState(input, user_id.Value);
            await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync();

            if (input.state == 4)
            {
                var record = await _iErpVehicleStateWarnImp.List(server_id, r => r.vehicle_id == info.vehicle_id && r.type == 3);
                if (record != null && record.Count > 0)
                {
                    await _iErpVehicleStateWarnImp.DeleteBatch(server_id, record);
                }
            }
            //更新报修状态
            //_publisher.Publish(EventMessages.OrderStateUpdate, info);
            _maintRepairRecordImp.UpdateStateMessage(info);
            //维修生命周期变更
            await PublishRepairLifeUpdateAsync(user_id, info);

            if (input.state == 4)
            {
                var rule = await SqlSugarHelper.DBClient(server_id).Queryable<MaintNoticeRule>()
                    .Where(r => r.shop_id == info.maint_dept && r.type == 9 && r.enable == 1).FirstAsync();
                var vehicles = await SqlSugarHelper.DBClient(server_id).Queryable<VehicleInfoNew>().ToListAsync();
                if (rule != null)
                {
                    var users = await SqlSugarHelper.DBClient(server_id).Queryable<MaintNoticeRuleUser>()
                        .Where(r => r.rule_id == rule.id).ToListAsync();
                    var vehicle = vehicles.Find(r => r.id == info.vehicle_id);
                    var persons = await SqlSugarHelper.DBClient(server_id).Queryable<SysDepPerson>()
                        .Where(r => r.i_group_id == Convert.ToDecimal(vehicle.group))
                        .Where(r => r.i_child_id >= 200000 && r.sign == 1).ToListAsync();
                    var user_ids = users.Select(r => r.user_id).Intersect(persons.Select(r => r.i_child_id.Value)).ToList();
                    if (user_ids != null && user_ids.Count() > 0)
                    {
                        var _iErpMessageMainImp = DIContainer.ServiceLocator.Instance.GetService<IErpMessageMainImp>();
                        ClientInformation client = new ClientInformation() { i_id = user_id };
                        var record = await SqlSugarHelper.DBClient(server_id).Queryable<MaintRepairRecord>()
                            .Mapper(r => r.type_child_info, r => r.type_child)
                            .Where(r => r.id == info.repair_id).FirstAsync();
                        var user_infos = await _userRedisImp.GetAllAsync();
                        var dic = new Dictionary<string, string>();
                        dic.Add("veh_code", vehicle?.lp_num);
                        dic.Add("type", record.type_child_info?.c_name);
                        dic.Add("describe", record.repair_describe);
                        foreach (var item in user_ids)
                        {
                            ErpMessageMain erpMessageMain = new ErpMessageMain();
                            erpMessageMain.type = 6;
                            erpMessageMain.model = (int)MessageModelDic.维修中消息;
                            erpMessageMain.object_id = info.id.ToString();
                            erpMessageMain.created_id = item;
                            erpMessageMain.title = $"您的车辆已完成维修<br/>车牌号：{vehicle?.lp_num}<br/>报修类型：{record.type_child_info?.c_name}<br/>报修描述：{record.repair_describe}";
                            await _iErpMessageMainImp.AddErpMessageMain(server_id, erpMessageMain, client);

                            if (rule.receive_terminal.Contains("4"))
                            {
                                var person = user_infos.Find(r => r.i_id == item);
                                if (person != null && !string.IsNullOrEmpty(person.c_phone))
                                {
                                    await _iJiGuangService.SendMessage(person.c_phone, _option.SignId, _option.TempId["CheckPassTemp"], dic);
                                }
                            }
                        }
                    }
                }
            }
            return _imapper.Map<MaintRepairOrder, MaintRepairOrderDto>(info);
        }

        public async Task<List<MaintRepairOrderDto>> UpdateScrapAsync(
            string server_id, decimal? user_id, List<int> ids)
        {
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<MaintRepairOrder>()
                                .Where(x => ids.Contains(x.id))
                                .ToListAsync();

            if (list == null || list.Count < 1)
            {
                throw new Exception($"未找到工单记录");
            }
            list.ForEach(x =>
            {
                x.state = (int)MainRepairOrderState.已作废;
                x.state_child = null;
                x.SetUpdate(user_id);

                //更新报修状态
                //_publisher.Publish(EventMessages.OrderStateUpdate, x);
                if (x.repair_id > 0)
                    _maintRepairRecordImp.UpdateStateMessage(x);
            });

            await SqlSugarHelper.DBClient(server_id).Updateable(list).ExecuteCommandAsync();

            await SqlSugarHelper.DBClient(server_id).Deleteable<ErpVehicleStateWarn>().Where(r => r.type == 3 &&
                        list.Select(m => m.vehicle_id).ToList().Contains((int)r.vehicle_id)).ExecuteCommandAsync();
            return _imapper.Map<List<MaintRepairOrder>, List<MaintRepairOrderDto>>(list);
        }

        private async Task PublishRepairLifeUpdateAsync(decimal? user_id, MaintRepairOrder input)
        {
            string userName = "";
            switch ((MainRepairOrderUpdateState)input.state)
            {
                case MainRepairOrderUpdateState.接修:
                    userName = await _userRedisImp.GetNameByIdAsync(input.receive_id.ToString());
                    _publisher.Publish(EventMessages.RepairLifeUpdate,
                       new CreateMaintRepairLife()
                       {
                           repair_id = input.repair_id,
                           title = string.Format(MaintRepairLifeTxt.UpdateOrderReceive, userName),
                           date = input.receive_time.Value,
                           created_id = user_id
                       });
                    break;

                case MainRepairOrderUpdateState.完工:
                    userName = await _userRedisImp.GetNameByIdAsync(input.finish_id.ToString());
                    _publisher.Publish(EventMessages.RepairLifeUpdate,
                       new CreateMaintRepairLife()
                       {
                           repair_id = input.repair_id,
                           title = string.Format(MaintRepairLifeTxt.UpdateOrderFinish, userName),
                           date = input.finish_time.Value,
                           created_id = user_id
                       });
                    break;

                case MainRepairOrderUpdateState.完工检验通过:
                    userName = await _userRedisImp.GetNameByIdAsync(input.finish_check_id.ToString());
                    _publisher.Publish(EventMessages.RepairLifeUpdate,
                       new CreateMaintRepairLife()
                       {
                           repair_id = input.repair_id,
                           title = string.Format(MaintRepairLifeTxt.UpdateOrderFinishCheckPass, userName),
                           date = input.finish_check_time.Value,
                           created_id = user_id
                       });
                    break;
                case MainRepairOrderUpdateState.完工检验未通过:
                    userName = await _userRedisImp.GetNameByIdAsync(input.finish_check_id.ToString());
                    _publisher.Publish(EventMessages.RepairLifeUpdate,
                       new CreateMaintRepairLife()
                       {
                           repair_id = input.repair_id,
                           title = string.Format(MaintRepairLifeTxt.UpdateOrderFinishCheckFail, userName),
                           date = input.finish_check_time.Value,
                           created_id = user_id
                       });
                    break;

                case MainRepairOrderUpdateState.接车:
                    userName = await _userRedisImp.GetNameByIdAsync(input.out_id.ToString());
                    _publisher.Publish(EventMessages.RepairLifeUpdate,
                       new CreateMaintRepairLife()
                       {
                           repair_id = input.repair_id,
                           title = string.Format(MaintRepairLifeTxt.UpdateOrderOut, userName),
                           date = input.out_time.Value,
                           created_id = user_id
                       });
                    break;
            }
        }

        #region 无流程工单

        public async Task<(List<MaintRepairOrderSimpleDto>, int)> GetByPageSimpleAsync(
            string server_id, decimal? user_id, MaintRepairOrderQuery query)
        {
            RefAsync<int> totalCount = 0;

            var exp = await DoQueryAsync(server_id, user_id, query);

            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<MaintRepairOrder>()
                                .Where(exp)
                                .Mapper(x => x.type_child_info, x => x.type_child)
                                .Mapper(x => x.state_child_info, x => x.state_child)
                                .Mapper(x => x.maint_dept_info, x => x.maint_dept)
                                .Mapper(x => x.finish_check_info, x => x.finish_check_id)
                                .Mapper(x => x.create_info, x => x.created_id)
                                .Mapper(async x =>
                                {
                                    x.vehicle_info = await SqlSugarHelper.DBClient(server_id)
                                                            .Queryable<ErpVehicleInfo>()
                                                            .Mapper(x => x.department_info, x => x.c_crews_take)
                                                            .Mapper(x => x.kind_info, x => x.c_id)
                                                            .FirstAsync(t => t.i_id == x.vehicle_id);

                                    x.repair_items = await _maintRepairItemImp.GetByOrderId(server_id, x.id);

                                    x.repair_dispatchs = await _maintRepairItemImp.GetItems(server_id, x.id);

                                    x.repair_materials = await _maintOrderMaterialImp.GetByWorkCodeAsync(server_id, x.work_code);

                                    x.repair_fee = await _maintRepairFeeImp.GetByOrderIdAsync(server_id, x.id);
                                })
                                .OrderBy(x => x.repair_time, OrderByType.Desc)
                                .ToPageListAsync(query.page_index, query.page_size, totalCount);

            var data = _imapper.Map<List<MaintRepairOrder>, List<MaintRepairOrderSimpleDto>>(list);
            var records = await SqlSugarHelper.DBClient(server_id).Queryable<MaintRepairRecord>().ToListAsync();
            data.ForEach(r =>
            {
                if (r.repair_dispatchs != null && r.repair_dispatchs.Count > 0)
                {
                    foreach (var item in r.repair_dispatchs)
                    {
                        if (item.shop_info != null && item.shop_info.c_name.Contains("电工"))
                        {
                            r.elc_hours = item.hours ?? 0;
                            r.elc_name = item.item_names;
                            r.elc_person = item.person_names;
                        }
                        if (item.shop_info != null && item.shop_info.c_name.Contains("胎工"))
                        {
                            r.tire_hours = item.hours ?? 0;
                            r.tire_name = item.item_names;
                            r.tire_person = item.person_names;
                        }
                        if (item.shop_info != null && item.shop_info.c_name.Contains("装配工"))
                        {
                            r.ins_hours = item.hours ?? 0;
                            r.ins_name = item.item_names;
                            r.ins_person = item.person_names;
                        }
                    }
                }
                r.describe = records.Find(m => m.work_code == r.work_code)?.repair_describe;
            });
            return (data, totalCount);
        }

        public async Task<MaintRepairOrderSimpleDto> AddSimpleAsync(
            string server_id, decimal? user_id, CreateMaintRepairOrder input)
        {
            var info = _imapper.Map<CreateMaintRepairOrder, MaintRepairOrder>(input);
            info.id = ERPBll.Tools.GetEngineID(server_id);
            //info.work_code = ERPBll.Tools.GetBusinessCode();
            string work_code = await _iWarehouseRedisManageImp.GetBatno(DateTime.Now, 5);
            if (string.IsNullOrEmpty(work_code))
            {
                info.work_code = "WX" + DateTime.Now.ToString("yyyyMMdd") + "0001";
                await _iWarehouseRedisManageImp.SetBatno(DateTime.Now, 1, 5);
            }
            else
            {
                info.work_code = "WX" + work_code;
            }
            info.receive_time = info.repair_time;
            info.SetCreate(user_id);
            info.type = 4;

            await SqlSugarHelper.DBClient(server_id).Insertable(info).ExecuteCommandAsync();

            if (input.repair_dispatchs != null && input.repair_dispatchs.Count > 0)
            {
                input.repair_dispatchs.ForEach(async r =>
                {
                    r.id = ERPBll.Tools.GetEngineID(server_id);
                    r.order_id = info.id;
                    r.created_id = user_id;
                    r.created_date = DateTime.Now;
                    if (r.person_ids != null && r.person_ids.Count > 0)
                    {
                        r.details = new List<MaintRepairDispatchPersons>();
                        foreach (var item in r.person_ids)
                        {
                            MaintRepairDispatchPersons temp = new MaintRepairDispatchPersons();
                            temp.order_id = info.id;
                            temp.main_id = r.id;
                            temp.person_id = item;
                            temp.hours = r.hours;
                            temp.created_id = user_id;
                            temp.created_date = DateTime.Now;
                            r.details.Add(temp);
                        }
                        await SqlSugarHelper.DBClient(server_id).Insertable(r.details).ExecuteCommandAsync();
                    }
                });
                await SqlSugarHelper.DBClient(server_id).Insertable(input.repair_dispatchs).ExecuteCommandAsync();
            }

            info.vehicle_info = await SqlSugarHelper.DBClient(server_id)
                                            .Queryable<ErpVehicleInfo>()
                                            .Mapper(x => x.department_info, x => x.c_crews_take)
                                            .Mapper(x => x.kind_info, x => x.c_id)
                                            .FirstAsync(t => t.i_id == info.vehicle_id);

            var data = _imapper.Map<MaintRepairOrder, MaintRepairOrderSimpleDto>(info);

            //维修生命周期变更
            string userName = await _userRedisImp.GetNameByIdAsync(((int)user_id.Value).ToString());
            _publisher.Publish(EventMessages.RepairLifeUpdate,
                new CreateMaintRepairLife()
                {
                    repair_id = info.id,
                    title = string.Format(MaintRepairLifeTxt.AddOrder, userName),
                    content = "",
                    date = DateTime.Now,
                    created_id = user_id
                });

            return data;
        }

        public async Task<MaintRepairOrderSimpleDto> UpdateSimpleAsync(
            string server_id, decimal? user_id, CreateMaintRepairOrder input)
        {
            var info = await SqlSugarHelper.DBClient(server_id)
                               .Queryable<MaintRepairOrder>()
                               .Mapper(async x =>
                               {
                                   x.vehicle_info = await SqlSugarHelper.DBClient(server_id)
                                                           .Queryable<ErpVehicleInfo>()
                                                           .Mapper(x => x.department_info, x => x.c_crews_take)
                                                           .Mapper(x => x.kind_info, x => x.c_id)
                                                           .FirstAsync(t => t.i_id == x.vehicle_id);
                               })
                               .FirstAsync(x => x.id == input.id);
            if (info == null)
            {
                throw new Exception($"未找到工单记录，id={input.id}");
            }
            _imapper.Map<CreateMaintRepairOrder, MaintRepairOrder>(input, info);
            info.SetUpdate(user_id);

            await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync();

            await SqlSugarHelper.DBClient(server_id).Deleteable<MaintRepairDispatch>().Where(r => r.order_id == info.id).ExecuteCommandAsync();
            await SqlSugarHelper.DBClient(server_id).Deleteable<MaintRepairDispatchPersons>().Where(r => r.order_id == info.id).ExecuteCommandAsync();
            if (input.repair_dispatchs != null && input.repair_dispatchs.Count > 0)
            {
                input.repair_dispatchs.ForEach(async r =>
                {
                    r.id = ERPBll.Tools.GetEngineID(server_id);
                    r.order_id = info.id;
                    r.created_id = user_id;
                    r.created_date = DateTime.Now;
                    if (r.person_ids != null && r.person_ids.Count > 0)
                    {
                        r.details = new List<MaintRepairDispatchPersons>();
                        foreach (var item in r.person_ids)
                        {
                            MaintRepairDispatchPersons temp = new MaintRepairDispatchPersons();
                            temp.order_id = info.id;
                            temp.main_id = r.id;
                            temp.person_id = item;
                            temp.hours = r.hours;
                            temp.created_id = user_id;
                            temp.created_date = DateTime.Now;
                            r.details.Add(temp);
                        }
                        await SqlSugarHelper.DBClient(server_id).Insertable(r.details).ExecuteCommandAsync();
                    }
                });
                await SqlSugarHelper.DBClient(server_id).Insertable(input.repair_dispatchs).ExecuteCommandAsync();
            }

            return _imapper.Map<MaintRepairOrder, MaintRepairOrderSimpleDto>(info);
        }

        public async Task DeleteManyAsync(string server_id, List<decimal> ids)
        {
            await SqlSugarHelper.DBClient(server_id)
                                .Deleteable<MaintRepairOrder>()
                                .Where(x => ids.Contains(x.id))
                                .ExecuteCommandAsync();

            await SqlSugarHelper.DBClient(server_id).Deleteable<MaintRepairDispatch>().Where(r => ids.Contains(r.order_id)).ExecuteCommandAsync();
            await SqlSugarHelper.DBClient(server_id).Deleteable<MaintRepairDispatchPersons>().Where(r => ids.Contains(r.order_id)).ExecuteCommandAsync();
        }
        #endregion

        /// <summary>
        /// 处理查询条件
        /// </summary>
        /// <returns></returns>
        private async Task<Expression<Func<MaintRepairOrder, bool>>> DoQueryAsync(
            string server_id, decimal? user_id, MaintRepairOrderQuery query)
        {
            if (query.group_id != null && query.group_id.Count > 0)
            {
                var vehicles = await SqlSugarHelper.DBClient(server_id).Queryable<VehicleInfoNew>()
                    .Where(r => query.group_id.Contains(Convert.ToInt32(r.group))).ToListAsync();
                if (query.vehicle_ids == null || query.vehicle_ids.Count == 0)
                {
                    query.vehicle_ids = vehicles.Select(r => r.id).ToList();
                }
                else
                {
                    query.vehicle_ids = query.vehicle_ids.Intersect(vehicles.Select(r => r.id)).ToList();
                }
            }

            if (query.hour_min.HasValue || query.hour_max.HasValue)
            {
                var hours = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<MaintRepairItem>()
                                .GroupBy(x => x.order_id)
                                .Select(x => new
                                {
                                    x.order_id,
                                    count = SqlFunc.AggregateSum(x.actual_hours * x.count)
                                }).ToListAsync();
                if (query.ids == null || query.ids.Count == 0)
                {
                    query.ids = new List<int>();
                    if (!query.hour_max.HasValue) //只查询最小工时
                    {
                        query.ids.AddRange(hours.Where(x => x.count >= query.hour_min).Select(x => x.order_id));
                    }
                    else if (!query.hour_min.HasValue)//只查询最大工时
                    {
                        query.ids.AddRange(hours.Where(x => x.count <= query.hour_max).Select(x => x.order_id));
                    }
                    else //工时范围查询
                    {
                        query.ids.AddRange(hours.Where(x => x.count >= query.hour_min && x.count <= query.hour_max).Select(x => x.order_id));
                    }
                }
                else
                {
                    if (!query.hour_max.HasValue) //只查询最小工时
                    {
                        query.ids = query.ids.Intersect(hours.Where(x => x.count >= query.hour_min).Select(x => x.order_id)).ToList();
                    }
                    else if (!query.hour_min.HasValue)//只查询最大工时
                    {
                        query.ids = query.ids.Intersect(hours.Where(x => x.count <= query.hour_max).Select(x => x.order_id)).ToList();
                    }
                    else //工时范围查询
                    {
                        query.ids = query.ids.Intersect(hours.Where(x => x.count >= query.hour_min && x.count <= query.hour_max).Select(x => x.order_id)).ToList();
                    }
                }
            }

            if (query.veh_type.HasValue)
            {
                var vehIds = await SqlSugarHelper.DBClient(server_id)
                               .Queryable<ErpVehicleInfo>()
                               .Where(x => x.c_id == query.veh_type)
                               .Select(x => x.i_id)
                               .ToListAsync();
                if (query.vehicle_ids == null || query.vehicle_ids.Count == 0)
                {
                    query.vehicle_ids = vehIds;
                }
                else
                {
                    query.vehicle_ids = vehIds.Intersect(query.vehicle_ids).ToList();
                }
                //query.vehicle_ids.AddRange(vehIds);
            }
            return query.ToExp();
        }
    }
}
