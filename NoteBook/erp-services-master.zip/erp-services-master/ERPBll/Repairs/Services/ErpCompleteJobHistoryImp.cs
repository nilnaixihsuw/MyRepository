﻿using ERPBll.Repairs.Contracts;
using ERPDal.Repository;
using ERPModel.Repairs.MaintRepairOrders;
using System;
using System.Collections.Generic;
using System.Text;

namespace ERPBll.Repairs.Services
{
    public class ErpCompleteJobHistoryImp: BaseBusiness<ErpCompleteJobHistory>, IErpCompleteJobHistoryImp
    {

    }
}
