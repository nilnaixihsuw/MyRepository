﻿using AutoMapper;
using DotNetCore.CAP;
using ERPBll.Caps;
using ERPBll.Repairs.Contracts;
using ERPDal;
using ERPModel.Repairs.MaintRepairLifes;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.Repairs.Services
{
    public class MaintRepairLifeImp : IMaintRepairLifeImp, ICapSubscribe
    {
        private readonly IMapper _imapper;

        public MaintRepairLifeImp(
           IMapper imapper)
        {
            _imapper = imapper;
        }

        public async Task<List<MaintRepairLifeDto>> GetByRepairIdAsync(string server_id, int repair_id, int order_id)
        {
            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<MaintRepairLife>()
                                .Where(x => repair_id > 0 && (x.repair_id == repair_id || x.repair_id == order_id))
                                .OrderBy(x => x.date, OrderByType.Desc)
                                .ToListAsync();

            return _imapper.Map<List<MaintRepairLife>, List<MaintRepairLifeDto>>(list);
        }

        [CapSubscribe(EventMessages.RepairLifeUpdate, Group = "RepairLife")]
        public void RepairLifeUpdate(CreateMaintRepairLife input)
        {
            try
            {
                var info = _imapper.Map<CreateMaintRepairLife, MaintRepairLife>(input);
                info.id = ERPBll.Tools.GetEngineID("60.191.59.11");

                var res = SqlSugarHelper.DBClient("60.191.59.11").Insertable(info).ExecuteCommand();
            }
            catch(Exception ex)
            {
                throw new Exception("维修生命周期更新失败：" + ex.Message);
            }
        }
    }
}
