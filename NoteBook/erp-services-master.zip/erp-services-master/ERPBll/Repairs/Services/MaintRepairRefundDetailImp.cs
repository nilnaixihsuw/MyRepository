﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using ERPBll.Repairs.Contracts;
using ERPDal;
using ERPDal.Repository;
using ERPModel.Repairs.MaintOrderMaterials;

namespace ERPBll.Repairs.Services
{
    public class MaintRepairRefundDetailImp : BaseBusiness<MaintRepairRefundDetail>, IMaintRepairRefundDetailImp
    {
        public async Task<List<MaintRepairRefundDetail>> GetData(string server_id, Expression<Func<MaintRepairRefundDetail, bool>> expression)
        {
            return await SqlSugarHelper.DBClient(server_id).Queryable<MaintRepairRefundDetail>()
                .WhereIF(expression != null, expression)
                .Mapper(r => r.material_info, r => r.material_id)
                .ToListAsync();
        }
    }
}
