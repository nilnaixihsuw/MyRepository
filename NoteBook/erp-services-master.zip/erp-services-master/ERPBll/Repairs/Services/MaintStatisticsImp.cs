﻿using ERPBll.Repairs.Contracts;
using ERPDal;
using ERPModel.DataBase;
using ERPModel.MaintManage;
using ERPModel.Repairs.MaintRepairFaults;
using ERPModel.Repairs.MaintRepairOrders;
using ERPModel.Repairs.MaintStatistics;
using ERPModel.UserManage;
using ERPModel.Vehicleinfomanage;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.Repairs.Services
{
    /// <summary>
    /// 维修统计
    /// </summary>
    public class MaintStatisticsImp : IMaintStatisticsImp
    {
        /// <summary>
        /// 维修类型统计
        /// </summary>
        public async Task<(List<RepairTypeCountDto>, int)> GetRepairTypeCountAsync(RepairCountQuery query)
        {
            var list = await SqlSugarHelper.DBClient(query.server_id)
                    .Queryable<SysCommonDictDetail, MaintRepairOrder>(
                        (x, y) => new JoinQueryInfos(
                            JoinType.Left, x.i_id == y.type_child
                     ))
                    .Where((x, y) => y.is_delete == 0 && y.state > 2)
                    .WhereIF(query.begin.HasValue && query.end.HasValue,
                        (x, y) => y.finish_time > query.begin && y.finish_time < query.end)
                    .GroupBy((x, y) => new { x.i_id, x.c_name, y.type_child })
                    .Select((x, y) => new RepairTypeCountDto
                    {
                        type_id = x.i_id,
                        type_name = x.c_name,
                        count = SqlFunc.AggregateCount(y.id)
                    })
                    .Distinct()
                    .ToListAsync();

            return (list, list.Sum(x => x.count));
        }

        /// <summary>
        /// 根据接修人统计
        /// </summary>
        public async Task<(List<RepairPersonCountDto>, int)> GetRepairPersonCountAsync(RepairCountQuery query)
        {
            var list = await SqlSugarHelper.DBClient(query.server_id)
                    .Queryable<SysPerson, MaintRepairOrder>(
                        (x, y) => new JoinQueryInfos(
                            JoinType.Left, x.i_id == y.receive_id
                     ))
                    .Where((x, y) => y.is_delete == 0 && y.state > 2)
                    .WhereIF(query.begin.HasValue && query.end.HasValue,
                        (x, y) => y.finish_time > query.begin && y.finish_time < query.end)
                    .GroupBy((x, y) => new { x.i_id, x.c_name, y.receive_id })
                    .Select((x, y) => new RepairPersonCountDto
                    {
                        person_id = x.i_id,
                        person_name = x.c_name,
                        count = SqlFunc.AggregateCount(y.id)
                    })
                    .Distinct()
                    .ToListAsync();
            return (list, list.Sum(x => x.count));
        }

        /// <summary>
        /// 故障类型统计
        /// </summary>
        public async Task<(List<RepairFaultCountDto>, int)> GetRepairFaultCountAsync(RepairCountQuery query)
        {
            var list = await SqlSugarHelper.DBClient(query.server_id)
                    .Queryable<MaintRepairFault>()
                    .WhereIF(query.begin.HasValue && query.end.HasValue,
                        x => x.created_date > query.begin && x.created_date < query.end)
                    .GroupBy(x => new { x.fault_id })
                    .Mapper(x => x.fault_info, x => x.fault_id)
                    .Select(x => new RepairFaultCountDto
                    {
                        fault_id = x.fault_id,
                        fault_name = x.fault_info.c_name,
                        count = SqlFunc.AggregateCount(x.id)
                    })
                    .Distinct()
                    .ToListAsync();
            return (list, list.Sum(x => x.count));
        }

        /// <summary>
        /// 根据车型统计
        /// </summary>
        public async Task<(List<RepairVehKindCountDto>, int)> GetRepairVehKindCountAsync(RepairCountQuery query)
        {
            var list = await SqlSugarHelper.DBClient(query.server_id)
                    .Queryable<MaintRepairOrder, ErpVehicleInfo>(
                        (a, b) => new JoinQueryInfos(
                            JoinType.Left, a.vehicle_id == b.i_id
                     ))
                    .Where((a, b) => a.is_delete == 0 && a.state > 2)
                    .WhereIF(query.begin.HasValue && query.end.HasValue,
                        (a, b) => a.finish_time > query.begin && a.finish_time < query.end)
                    .GroupBy((a, b) => new { b.c_id })
                    .Select((a, b) => new RepairVehKindCountDto
                    {
                        count = SqlFunc.AggregateCount(a.id),
                        kind_id = b.c_id
                    })
                    .Distinct()
                    .ToListAsync();

            if (list != null && list.Count > 0)
            {
                var kind_ids = list.Select(x => x.kind_id).Distinct().ToList();

                var kind_list = await SqlSugarHelper.DBClient(query.server_id)
                    .Queryable<MaintVehicleKind>()
                    .Where(x => kind_ids.Contains(x.i_id))
                    .ToListAsync();

                list.ForEach(x => {
                    var kind_info = kind_list.Where(y => y.i_id == x.kind_id).FirstOrDefault();
                    x.kind_name = kind_info == null ? "" : kind_info.c_name;
                });
            }

            return (list, list.Sum(x => x.count));
        }

        /// <summary>
        /// 根据分公司统计
        /// </summary>
        public async Task<(List<RepairDepCountDto>, int)> GetRepairDepCountAsync(RepairCountQuery query)
        {
            var list = await SqlSugarHelper.DBClient(query.server_id)
                    .Queryable<MaintRepairOrder, ErpVehicleInfo>(
                        (a, b) => new JoinQueryInfos(
                            JoinType.Left, a.vehicle_id == b.i_id
                     ))
                    .Where((a, b) => a.is_delete == 0 && a.state > 2)
                    .WhereIF(query.begin.HasValue && query.end.HasValue,
                        (a, b) => a.finish_time > query.begin && a.finish_time < query.end)
                    .GroupBy((a, b) => new { b.c_crews_take })
                    .Select((a, b) => new RepairDepCountDto
                    {
                        count = SqlFunc.AggregateCount(a.id),
                        dep_id = Convert.ToInt32(b.c_crews_take)
                    })
                    .Distinct()
                    .ToListAsync();

            if (list != null && list.Count > 0)
            {
                var dep_ids = list.Select(x => x.dep_id).Distinct().ToList();

                var dep_list = await SqlSugarHelper.DBClient(query.server_id)
                    .Queryable<SysDepartment>()
                    .Where(x => dep_ids.Contains(x.i_id))
                    .ToListAsync();

                list.ForEach(x =>
                {
                    var dep_info = dep_list.Where(y => y.i_id == x.dep_id).FirstOrDefault();
                    x.dep_name = dep_info == null ? "" : dep_info.c_name;
                });
            }

            return (list, list.Sum(x => x.count));
        }

        /// <summary>
        /// 根据维修厂统计
        /// </summary>
        public async Task<(List<RepairMaintDepCountDto>, int)> GetRepairMaintDepCountAsync(RepairCountQuery query)
        {
            var list = await SqlSugarHelper.DBClient(query.server_id)
                    .Queryable<MaintRepairOrder, ErpMaintenanceDepartment>(
                        (a, b) => new JoinQueryInfos(
                            JoinType.Left, a.maint_dept == b.i_id
                     ))
                    .Where((a, b) => a.is_delete == 0 && a.state > 2)
                    .WhereIF(query.begin.HasValue && query.end.HasValue,
                        (a, b) => a.finish_time > query.begin && a.finish_time < query.end)
                    .GroupBy((a, b) => new { b.i_department_id })
                    .Select((a, b) => new RepairMaintDepCountDto
                    {
                        count = SqlFunc.AggregateCount(a.id),
                        dep_id = b.i_department_id
                    })
                    .Distinct()
                    .ToListAsync();

            if (list != null && list.Count > 0)
            {
                var dep_ids = list.Select(x => x.dep_id).Distinct().ToList();

                var dep_list = await SqlSugarHelper.DBClient(query.server_id)
                    .Queryable<SysDepartment>()
                    .Where(x => dep_ids.Contains(x.i_id))
                    .ToListAsync();

                list.ForEach(x =>
                {
                    var dep_info = dep_list.Where(y => y.i_id == x.dep_id).FirstOrDefault();
                    x.dep_name = dep_info == null ? "" : dep_info.c_name;
                });
            }

            return (list, list.Sum(x => x.count));
        }
    }
}
