﻿using AutoMapper;
using ERPBll.MaintManage;
using ERPBll.Repairs.Contracts;
using ERPDal;
using ERPModel.MaintManage;
using ERPModel.Repairs.MaintRepairHours;
using ERPModel.Repairs.MaintRepairItems;
using ERPModel.Repairs.MaintRepairOrders;
using ERPModel.UserManage;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.Repairs.Services
{
    /// <summary>
    /// 工单维修项目
    /// </summary>
    public class MaintRepairItemImp: IMaintRepairItemImp
    {
        private readonly IMapper _imapper;
        private readonly IMaintDeptImp _maintDeptImp;

        public MaintRepairItemImp(
           IMapper imapper,
           IMaintDeptImp maintDeptImp)
        {
            _imapper = imapper;
            _maintDeptImp = maintDeptImp;
        }

        public async Task<List<MaintRepairItem>> GetByOrderId(string server_id, int order_id)
        {
            var query = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<MaintRepairItem>()
                                .Mapper(async x =>
                                {
                                    x.item_info = await SqlSugarHelper.DBClient(server_id)
                                                    .Queryable<ErpMaintenanceItem>()
                                                    .Mapper(async x =>
                                                    {
                                                        x.group_name = (await SqlSugarHelper.DBClient(server_id)
                                                                        .Queryable<ErpMaintenanceItemGroup>()
                                                                        .FirstAsync(i => i.i_id == x.i_group_id))?.c_name;
                                                    })
                                                    .FirstAsync(i => i.i_id == x.item_id);
                                    x.persons = await _maintDeptImp.GetPersonAsync(server_id, null, null, x.shop_id);
                                })
                                .Mapper(x => x.shop_info, x => x.shop_id)
                                .Mapper(x => x.person_info, x => x.person_id)
                                .Where(t => t.order_id == order_id)
                                .ToListAsync();
            return query;
        }

        public async Task<List<MaintRepairDispatch>> GetItems(string server_id, int order_id)
        {
            var list = await SqlSugarHelper.DBClient(server_id).Queryable<MaintRepairDispatch>()
                .Where(r => r.order_id == order_id)
                .Mapper(r => r.shop_info, r => r.type)
                .Mapper(async r => r.details = await SqlSugarHelper.DBClient(server_id).Queryable<MaintRepairDispatchPersons>()
                                .Where(m => m.main_id == r.id)
                                .Mapper(r => r.person_info, r => r.person_id).ToListAsync())
                .ToListAsync();

            if (list != null && list.Count > 0)
            {
                list.ForEach(x =>
                {
                    x.person_ids = x.details.Select(r => r.person_id).ToList();
                    x.person_names = string.Join(',', x.details.Select(r => r.person_info?.c_name));
                    if (x.total_hours.HasValue && x.details.Count > 0)
                        x.hours = Math.Round(Convert.ToDecimal(x.total_hours.Value / x.details.Count()), 2, MidpointRounding.AwayFromZero);
                });
            }
           
            return list;
        }

        public async Task<List<MaintRepairItemDto>> AddAsync(
            string server_id, decimal? user_id, List<CreateOrUpdateMaintRepairItem> input)
        {
            await DeleteByOrderAsync(server_id, input.Select(x => x.order_id).Distinct().ToList());

            var info = _imapper.Map<List<CreateOrUpdateMaintRepairItem>, List<MaintRepairItem>>(input);

            info.ForEach(x => x.created_id = user_id);
            await SqlSugarHelper.DBClient(server_id).Insertable(info).ExecuteCommandAsync();

            return _imapper.Map<List<MaintRepairItem>, List<MaintRepairItemDto>>(info);
        }

        public async Task<MaintRepairItemDto> AddToAsync(
          string server_id, decimal? user_id, CreateOrUpdateMaintRepairItem input)
        {
            //await DeleteAsync(server_id, input.Select(x => x.order_id).Distinct().ToList());

            var info = _imapper.Map<CreateOrUpdateMaintRepairItem, MaintRepairItem>(input);

            info.created_id = user_id;
            await SqlSugarHelper.DBClient(server_id).Insertable(info).ExecuteCommandAsync();

            return _imapper.Map<MaintRepairItem, MaintRepairItemDto>(info);
        }

        public async Task<MaintRepairItemDto> UpdateAsync(
           string server_id, decimal? user_id, CreateOrUpdateMaintRepairItem input)
        {
            var info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<MaintRepairItem>().FirstAsync(x => x.id == input.id);
            if (info == null)
            {
                throw new Exception($"未找到派工记录，id={input.id}");
            }
            info = _imapper.Map<MaintRepairItem>(input);
            await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync();
            return _imapper.Map<MaintRepairItem, MaintRepairItemDto>(info);
        }

        public async Task<int> DeleteByIdsAsync(string server_id, List<int> ids)
        {
            return await SqlSugarHelper.DBClient(server_id)
                    .Deleteable<MaintRepairItem>()
                    .Where(x => ids.Contains(x.id))
                    .ExecuteCommandAsync();
        }

        public async Task<int> DeleteByOrderAsync(string server_id, List<int> order_ids)
        {
            return await SqlSugarHelper.DBClient(server_id)
                    .Deleteable<MaintRepairItem>()
                    .Where(x => order_ids.Contains(x.order_id))
                    .ExecuteCommandAsync();
        }

        public async Task<List<HourReportDto>> GetHourReport(HourReportQuery request)
        {
            var list = new List<HourReportDto>();
            List<decimal> order_ids = new List<decimal>();
            string repair_date_show = "";
            var orders = await SqlSugarHelper.DBClient(request.server_id).Queryable<MaintRepairOrder>().ToListAsync();
            if (request.repair_date != null)
            {
                DateTime start = Convert.ToDateTime($"{request.repair_date.Value.Year}-{request.repair_date.Value.Month}-01");
                DateTime end = Convert.ToDateTime($"{request.repair_date.Value.Year}-{request.repair_date.Value.Month + 1}-01");
                repair_date_show = $"{start:yyyy-MM-dd}至{end.AddDays(-1):yyyy-MM-dd}";
                orders = orders.Where(r => r.repair_time >= start && r.repair_time < end).ToList();
                order_ids = orders.Select(r => (decimal)r.id).ToList();
            }

            var shop_ids = new List<decimal?>();
            if (request.shop_id > 0 && request.type == 1)
            {
                var aa = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpMaintenanceShop>()
                    .Where(r => r.i_main_id == request.shop_id)
                    .ToListAsync();
                shop_ids = aa.Select(r => r.i_id).ToList();
            }
            else
            {
                shop_ids = null;
            }
            var records = await SqlSugarHelper.DBClient(request.server_id).Queryable<MaintRepairDispatch>()
               .WhereIF(order_ids.Count > 0, r => order_ids.Contains((int)r.order_id))
               .WhereIF(request.shop_id > 0 && request.type == 2, r => r.type == request.shop_id)
               .WhereIF(shop_ids != null, r => shop_ids.Contains(r.type))
               .Mapper(async r => r.shop_info = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpMaintenanceShop>()
                                .Where(m => m.i_id == r.type)
                                .Mapper(m => m.dept_info, m => m.i_main_id).FirstAsync())
               .ToListAsync();
            //records.RemoveAll(r => r.details == null || r.details.Count == 0);

            var details = await SqlSugarHelper.DBClient(request.server_id).Queryable<MaintRepairDispatchPersons>()
                .Where(m => records.Select(r => r.id).Contains(m.main_id))
                .WhereIF(request.person_id > 0, m => m.person_id == request.person_id)
                .Mapper(m => m.person_info, m => m.person_id).ToListAsync();

            foreach (var item in details.Select(r=>r.person_id).Distinct())
            {
                var all = details.FindAll(r => r.person_id == item);
                var main_ids = all.Select(r => r.main_id).ToList();
                var item_records = records.Where(r => main_ids.Contains(r.id)).ToList();
                var temp = new HourReportDto();
                temp.repair_date = request.repair_date;
                temp.repair_date_show = repair_date_show;
                temp.repair_id = all[0].person_info?.i_id;
                temp.repair_name = all[0].person_info?.c_name;
                temp.dept_name = string.Join(',', item_records.Select(r => r.shop_info?.dept_info?.c_name).Distinct());
                temp.shop_name = string.Join(',', item_records.Select(r => r.shop_info?.c_name).Distinct());
                temp.attent_days = orders.FindAll(r => all.Select(r => r.order_id).Contains(r.id)).Select(r => r.repair_time.ToString("yyyyMMdd")).Distinct().Count();
                temp.hours = Math.Round(all.Sum(r => (decimal)r.hours), 2, MidpointRounding.AwayFromZero);
                list.Add(temp);
            }
            return list;
        }

        public async Task<Tuple<int,List<HourDetailDto>>> GetHourDetail(HourDetailQuery request)
        {
            RefAsync<int> totalNumber = 0;
            DateTime? start = null;
            DateTime? end = null;
            if (request.repair_date != null)
            {
                start = Convert.ToDateTime($"{request.repair_date.Value.Year}-{request.repair_date.Value.Month}-01");
                end = Convert.ToDateTime($"{request.repair_date.Value.Year}-{request.repair_date.Value.Month + 1}-01");
            }
            var records = await SqlSugarHelper.DBClient(request.server_id).Queryable<MaintRepairDispatch>().ToListAsync();
            var details = await SqlSugarHelper.DBClient(request.server_id).Queryable<MaintRepairDispatchPersons>()
                              .Where(m => m.person_id == request.user_id).ToListAsync();
            var orders = await SqlSugarHelper.DBClient(request.server_id).Queryable<MaintRepairOrder>()
              .WhereIF(start != null, r => r.repair_time >= start && r.repair_time < end)
              .Where(r => details.Select(m => m.order_id).Contains(r.id))
              .Mapper(r => r.vehicle_info, r => r.vehicle_id)
              .Mapper(x => x.type_child_info, x => x.type_child)
              .ToPageListAsync(request.page_index, request.page_size, totalNumber);
            List<HourDetailDto> list = new List<HourDetailDto>();
            foreach (var order in orders)
            {
                HourDetailDto temp = new HourDetailDto();
                temp.repair_date = order.repair_time.ToString("yyyy-MM-dd");
                temp.v_num = order.vehicle_info?.c_vehicle_number;
                temp.lp_num = order.vehicle_info?.c_lincense_plate_number;
                temp.type_child_name = order.type_child_info?.c_name;
                temp.work_code = order.work_code;
                var info = details.Find(r => r.order_id == order.id);
                temp.hours = info.hours;
                temp.pro_name = records.Find(r => r.id == info.main_id).item_names;
                list.Add(temp);
            }
            return new Tuple<int, List<HourDetailDto>>(totalNumber, list);
        }

        public async Task<List<RepairPerson>> GetPersons(string server_id)
        {
            var records = await SqlSugarHelper.DBClient(server_id).Queryable<ErpMaintenancePerson>().Where(r => r.i_type == 2).ToListAsync();
            var ids = records.Select(r => r.i_person_id).Distinct().ToList();
            return await SqlSugarHelper.DBClient(server_id).Queryable<SysPerson>()
                .Where(r => ids.Contains(r.i_id))
                .Select(r => new RepairPerson
                {
                    id = r.i_id,
                    name = r.c_name
                }).ToListAsync();
        }
    }
}
