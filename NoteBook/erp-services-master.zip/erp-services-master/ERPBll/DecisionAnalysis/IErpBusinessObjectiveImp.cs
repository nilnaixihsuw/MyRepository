﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPModel.DecisionAnalysis;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.DecisionAnalysis
{
    public interface IErpBusinessObjectiveImp : IBusinessRepository<ErpBusinessObjective>
    {
        Task<bool> AddErpBusinessObjective(string server_id, ErpBusinessObjective context, ClientInformation client);
        Task<Tuple<List<ErpBusinessObjective>,int>> QueryErpBusinessObjectivePageList(string server_id, BaseRequest<ErpBusinessObjective> request, string v);
        Task<List<ErpBusinessObjective>> QueryErpBusinessObjectiveList(string server_id, BaseRequest<ErpBusinessObjective> request, string v);
        Task<bool> BatchDelete(string server_id, List<decimal> context);
    }
}