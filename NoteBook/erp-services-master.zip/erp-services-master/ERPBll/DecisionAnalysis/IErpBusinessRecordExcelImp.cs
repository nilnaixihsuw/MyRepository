﻿using ERPCore.ORM;
using ERPModel.DecisionAnalysis;
using System;
using System.Collections.Generic;
using System.Text;

namespace ERPBll.DecisionAnalysis
{
    public interface IErpBusinessRecordExcelImp : IExcelImportRepository<ErpBusinessRecord>
    {

    }
}
