﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPDal.DecisionAnalysis;
using ERPModel.DecisionAnalysis;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using System.Linq.Expressions;
using System.IO;
using ERPCore;
using ERPCore.Extensions;
using System.Data;
using ERPModel.ApiModel.DecisionAnalysis;

namespace ERPBll.DecisionAnalysis
{
    public class ErpBusinessRecordImp : BusinessRespository<ErpBusinessRecord, IErpBusinessRecordDataImp>, IErpBusinessRecordImp
    {
        private readonly IErpBusinessObjectiveDataImp _iErpBusinessObjectiveDataImp;

        public ErpBusinessRecordImp(
            IErpBusinessObjectiveDataImp iErpBusinessObjectiveDataImp,
            IErpBusinessRecordDataImp dataImp) : base(dataImp)
        {
            _iErpBusinessObjectiveDataImp = iErpBusinessObjectiveDataImp;
        }

        public async Task<bool> AddErpBusinessRecord(string server_id, ErpBusinessRecord context, ClientInformation client)
        {
            if (context.id > 0)
            {
                var old = await _dataImp.Get(server_id, context.id);
                context.created_id = old.created_id;
                context.created_date = old.created_date;
                return await _dataImp.Update(server_id, context);
            }
            else
            {
                context.created_date = DateTime.Now;
                context.created_id = client.i_id;
                return await _dataImp.Insert(server_id, context);
            }
        }

        public async Task<Tuple<List<ErpBusinessRecord>, int>> QueryErpBusinessRecordPageList(string server_id, BaseRequest<ErpBusinessRecord> request, string v)
        {
            var exp = await GetExp(request);
            return await ExtensionList(server_id, request.ToExp(exp), v, request.page_size, request.page_index, request.orderby);
        }

        public async Task<List<ErpBusinessRecord>> QueryErpBusinessRecordList(string server_id, BaseRequest<ErpBusinessRecord> request, string v)
        {
            var exp = await GetExp(request);
            return await ExtensionList(server_id, request.ToExp(exp), v, request.orderby);
        }

        public async Task<bool> BatchDelete(string server_id, List<decimal> context)
        {
            var list = await _dataImp.List(server_id, it => SqlFunc.ContainsArray(context, it.id));
            return await _dataImp.Deletetable(server_id, list);
        }

        private async Task<List<Expression<Func<ErpBusinessRecord, bool>>>> GetExp(BaseRequest<ErpBusinessRecord> request)
        {
            var r = new List<Expression<Func<ErpBusinessRecord, bool>>>();

            return r;
        }

        /// <summary>
        /// 查询财务分析
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public async Task<(List<FinanceSummaryQueryBody>, List<FinanceAnalysisItem>)> QueryFinanceList(ErpBusinessRecordRequest request)
        {
            var r = new List<FinanceSummaryQueryBody>();
            var s = new List<FinanceAnalysisItem>();

            // 本年本月财务记录,指标
            var list = await _dataImp.List(request.server_id, it => it.month == request.month && it.dept_id == request.org_id);
            var indexs = await _iErpBusinessObjectiveDataImp.List(request.server_id, it => SqlFunc.Oracle_ToChar(request.month.Value, "yyyy") == it.year.ToString());

            // 去年本月财务记录
            var oMonth = request.month.Value.AddYears(-1);
            var oldRecords = await _dataImp.List(request.server_id, it => it.month == oMonth && it.dept_id == request.org_id);

            // 本年累计记录
            var cMonth = new DateTime(request.month.Value.Year, 1, 1);
            var totalList = await _dataImp.List(request.server_id, it => it.month <= request.month && it.month >= cMonth);

            // 去年累计记录
            var lMonth = new DateTime(request.month.Value.Year - 1, 1, 1);
            var rMonth = new DateTime(request.month.Value.Year - 1, request.month.Value.Month, 1);
            var lastTotalList = await _dataImp.List(request.server_id, it => it.month <= rMonth && it.month >= lMonth);

            if (list.Count > 0)
            {
                var record = list.FirstOrDefault();
                var index = indexs.FirstOrDefault() == null ? new ErpBusinessObjective() : indexs.FirstOrDefault();
                var oldRecord = new ErpBusinessRecord();
                // 去年同期数
                if (oldRecords.Count > 0)
                {
                    oldRecord = oldRecords.FirstOrDefault();
                }

                // 收入
                var e = new FinanceSummaryQueryBody
                {
                    type = "收入",
                    project = "票款收入",
                    index = index.fare_income,
                    cur_month = record.fare_income,
                    type_sum = Math.Round(record.fare_income + record.income_other, 2),
                    last_year = oldRecord.fare_income,
                    cur_year_total = Math.Round(totalList.Sum(it => it.fare_income), 2),
                    last_year_total = Math.Round(lastTotalList.Sum(it => it.fare_income))
                };
                r.Add(e);
                e = new FinanceSummaryQueryBody
                {
                    type = "收入",
                    project = "其他收入",
                    index = index.income_other,
                    cur_month = record.income_other,
                    type_sum = Math.Round(record.fare_income + record.income_other, 2),
                    last_year = oldRecord.income_other,
                    cur_year_total = Math.Round(totalList.Sum(it => it.income_other), 2),
                    last_year_total = Math.Round(lastTotalList.Sum(it => it.income_other), 2)
                };
                r.Add(e);
                e = new FinanceSummaryQueryBody
                {
                    type = "收入",
                    project = "小计",
                    index = Math.Round(index.fare_income + index.income_other, 2),
                    cur_month = Math.Round(record.fare_income + record.income_other, 2),
                    last_year = Math.Round(oldRecord.fare_income + oldRecord.income_other, 2),
                    cur_year_total = Math.Round(totalList.Sum(it => it.fare_income + it.income_other), 2),
                    last_year_total = Math.Round(lastTotalList.Sum(it => it.fare_income + it.income_other), 2)
                };
                s.Add(new FinanceAnalysisItem
                {
                    total = e.cur_month,
                    rate = e.year_on_year
                });
                r.Add(e);

                // 成本
                e = new FinanceSummaryQueryBody
                {
                    type = "成本",
                    project = "主营成本",
                    index = index.main_cost,
                    cur_month = record.main_cost,
                    type_sum = Math.Round(record.main_cost + record.finance_cost + record.manage_cost + record.finance_cost, 2),
                    last_year = oldRecord.main_cost,
                    cur_year_total = Math.Round(totalList.Sum(it => it.main_cost), 2),
                    last_year_total = Math.Round(lastTotalList.Sum(it => it.main_cost), 2)
                };
                r.Add(e);
                e = new FinanceSummaryQueryBody
                {
                    type = "成本",
                    project = "税金及附加",
                    index = index.tax_additional,
                    cur_month = record.tax_additional,
                    type_sum = Math.Round(record.main_cost + record.tax_additional + record.manage_cost + record.finance_cost, 2),
                    last_year = oldRecord.tax_additional,
                    cur_year_total = Math.Round(totalList.Sum(it => it.tax_additional), 2),
                    last_year_total = Math.Round(lastTotalList.Sum(it => it.tax_additional), 2)
                };
                r.Add(e);
                e = new FinanceSummaryQueryBody
                {
                    type = "成本",
                    project = "管理费用",
                    index = index.manage_cost,
                    cur_month = record.manage_cost,
                    type_sum = Math.Round(record.main_cost + record.finance_cost + record.manage_cost + record.finance_cost, 2),
                    last_year = oldRecord.manage_cost,
                    cur_year_total = Math.Round(totalList.Sum(it => it.manage_cost), 2),
                    last_year_total = Math.Round(lastTotalList.Sum(it => it.manage_cost), 2)
                };
                r.Add(e);
                e = new FinanceSummaryQueryBody
                {
                    type = "成本",
                    project = "财务费用",
                    index = index.finance_cost,
                    cur_month = record.finance_cost,
                    type_sum = Math.Round(record.main_cost + record.finance_cost + record.manage_cost + record.finance_cost, 2),
                    last_year = oldRecord.finance_cost,
                    cur_year_total = Math.Round(totalList.Sum(it => it.finance_cost), 2),
                    last_year_total = Math.Round(lastTotalList.Sum(it => it.finance_cost), 2)
                };
                r.Add(e);
                e = new FinanceSummaryQueryBody
                {
                    type = "成本",
                    project = "小计",
                    index = Math.Round(index.main_cost + index.tax_additional + index.manage_cost + index.finance_cost, 2),
                    cur_month = Math.Round(record.main_cost + record.tax_additional + record.manage_cost + record.finance_cost, 2),
                    last_year = Math.Round(oldRecord.main_cost + oldRecord.tax_additional + oldRecord.manage_cost + oldRecord.finance_cost, 2),
                    cur_year_total = Math.Round(totalList.Sum(it => it.main_cost + it.tax_additional + it.manage_cost + it.finance_cost), 2),
                    last_year_total = Math.Round(lastTotalList.Sum(it => it.main_cost + it.tax_additional + it.manage_cost + it.finance_cost), 2)
                };
                s.Add(new FinanceAnalysisItem
                {
                    total = e.cur_month,
                    rate = e.year_on_year
                });
                r.Add(e);
                // 营业外收支
                e = new FinanceSummaryQueryBody
                {
                    type = "营业外收支",
                    project = "政府补亏",
                    index = index.government_bk,
                    cur_month = record.government_bk,
                    type_sum = Math.Round(record.government_bk + record.rebates + record.oil_electric + record.old_repo + record.punishment + record.scrappage_loss + record.revenue_other, 2),
                    last_year = oldRecord.government_bk,
                    cur_year_total = Math.Round(totalList.Sum(it => it.government_bk), 2),
                    last_year_total = Math.Round(lastTotalList.Sum(it => it.government_bk), 2)
                };
                r.Add(e);
                e = new FinanceSummaryQueryBody
                {
                    type = "营业外收支",
                    project = "购车补贴",
                    index = index.rebates,
                    cur_month = record.rebates,
                    type_sum = Math.Round(record.government_bk + record.rebates + record.oil_electric + record.old_repo + record.punishment + record.scrappage_loss + record.revenue_other, 2),
                    last_year = oldRecord.rebates,
                    cur_year_total = Math.Round(totalList.Sum(it => it.rebates), 2),
                    last_year_total = Math.Round(lastTotalList.Sum(it => it.rebates), 2)
                };
                r.Add(e);
                e = new FinanceSummaryQueryBody
                {
                    type = "营业外收支",
                    project = "油、电补",
                    index = index.oil_electric,
                    cur_month = record.oil_electric,
                    type_sum = Math.Round(record.government_bk + record.rebates + record.oil_electric + record.old_repo + record.punishment + record.scrappage_loss + record.revenue_other, 2),
                    last_year = oldRecord.oil_electric,
                    cur_year_total = Math.Round(totalList.Sum(it => it.oil_electric), 2),
                    last_year_total = Math.Round(lastTotalList.Sum(it => it.oil_electric), 2)
                };
                r.Add(e);
                e = new FinanceSummaryQueryBody
                {
                    type = "营业外收支",
                    project = "旧车回购",
                    index = index.old_repo,
                    cur_month = record.old_repo,
                    type_sum = Math.Round(record.government_bk + record.rebates + record.oil_electric + record.old_repo + record.punishment + record.scrappage_loss + record.revenue_other, 2),
                    last_year = oldRecord.old_repo,
                    cur_year_total = Math.Round(totalList.Sum(it => it.old_repo), 2),
                    last_year_total = Math.Round(lastTotalList.Sum(it => it.old_repo), 2)
                };
                r.Add(e);
                e = new FinanceSummaryQueryBody
                {
                    type = "营业外收支",
                    project = "处罚",
                    index = index.punishment,
                    cur_month = record.punishment,
                    type_sum = Math.Round(record.government_bk + record.rebates + record.oil_electric + record.old_repo + record.punishment + record.scrappage_loss + record.revenue_other, 2),
                    last_year = oldRecord.punishment,
                    cur_year_total = Math.Round(totalList.Sum(it => it.punishment), 2),
                    last_year_total = Math.Round(lastTotalList.Sum(it => it.punishment), 2)
                };
                r.Add(e);
                e = new FinanceSummaryQueryBody
                {
                    type = "营业外收支",
                    project = "车辆报废损失",
                    index = index.scrappage_loss,
                    cur_month = record.scrappage_loss,
                    type_sum = Math.Round(record.government_bk + record.rebates + record.oil_electric + record.old_repo + record.punishment + record.scrappage_loss + record.revenue_other, 2),
                    last_year = oldRecord.scrappage_loss,
                    cur_year_total = Math.Round(totalList.Sum(it => it.scrappage_loss), 2),
                    last_year_total = Math.Round(lastTotalList.Sum(it => it.scrappage_loss), 2)
                };
                r.Add(e);
                e = new FinanceSummaryQueryBody
                {
                    type = "营业外收支",
                    project = "其他",
                    index = index.revenue_other,
                    cur_month = record.revenue_other,
                    type_sum = Math.Round(record.government_bk + record.rebates + record.oil_electric + record.old_repo + record.punishment + record.scrappage_loss + record.revenue_other, 2),
                    last_year = oldRecord.revenue_other,
                    cur_year_total = Math.Round(totalList.Sum(it => it.revenue_other), 2),
                    last_year_total = Math.Round(lastTotalList.Sum(it => it.revenue_other), 2)
                };
                r.Add(e);
                e = new FinanceSummaryQueryBody
                {
                    type = "营业外收支",
                    project = "小计",
                    index = Math.Round(index.government_bk + index.rebates + index.oil_electric + index.old_repo + index.punishment + index.scrappage_loss + index.revenue_other, 2),
                    cur_month = Math.Round(record.government_bk + record.rebates + record.oil_electric + record.old_repo + record.punishment + record.scrappage_loss + record.revenue_other, 2),
                    last_year = Math.Round(oldRecord.government_bk + oldRecord.rebates + oldRecord.oil_electric + oldRecord.old_repo + oldRecord.punishment + oldRecord.scrappage_loss + oldRecord.revenue_other, 2),
                    cur_year_total = Math.Round(totalList.Sum(it => it.government_bk + it.rebates + it.oil_electric + it.old_repo + it.punishment + it.scrappage_loss + it.revenue_other), 2),
                    last_year_total = Math.Round(lastTotalList.Sum(it => it.government_bk + it.rebates + it.oil_electric + it.old_repo + it.punishment + it.scrappage_loss + it.revenue_other), 2)
                };
                s.Add(new FinanceAnalysisItem
                {
                    total = e.cur_month,
                    rate = e.year_on_year
                });
                r.Add(e);

                // 利润总额
                e = new FinanceSummaryQueryBody
                {
                    type = "利润总额",
                    index = Math.Round(index.fare_income + index.income_other + index.main_cost + index.tax_additional + index.manage_cost + index.finance_cost + index.government_bk + index.rebates + index.oil_electric + index.old_repo + index.punishment + index.scrappage_loss + index.revenue_other, 2),
                    cur_month = Math.Round(record.fare_income + record.income_other + record.main_cost + record.tax_additional + record.manage_cost + record.finance_cost + record.government_bk + record.rebates + record.oil_electric + record.old_repo + record.punishment + record.scrappage_loss + record.revenue_other, 2),
                    cur_year_total = Math.Round(totalList.Sum(it => it.fare_income + it.income_other + it.main_cost + it.tax_additional + it.manage_cost + it.finance_cost + it.government_bk + it.rebates + it.oil_electric + it.old_repo + it.punishment + it.scrappage_loss + it.revenue_other), 2),
                    last_year_total = Math.Round(lastTotalList.Sum(it => it.fare_income + it.income_other + it.main_cost + it.tax_additional + it.manage_cost + it.finance_cost + it.government_bk + it.rebates + it.oil_electric + it.old_repo + it.punishment + it.scrappage_loss + it.revenue_other), 2),
                };
                s.Add(new FinanceAnalysisItem
                {
                    total = e.cur_year_total,
                    rate = e.last_year_on_year
                });
                r.Add(e);

            }
            return (r, s);
        }

        /// <summary>
        /// 查看管理费用明细
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public async Task<List<FinanceSummaryQueryBody>> ManageFeeList(ErpBusinessRecordRequest request)
        {
            var r = new List<FinanceSummaryQueryBody>();

            // 本年本月财务记录,指标
            var list = await _dataImp.List(request.server_id, it => it.month == request.month && it.dept_id == request.org_id);
            var indexs = await _iErpBusinessObjectiveDataImp.List(request.server_id, it => SqlFunc.Oracle_ToChar(request.month.Value, "yyyy") == it.year.ToString());

            // 去年本月财务记录
            var oMonth = request.month.Value.AddYears(-1);
            var oldRecords = await _dataImp.List(request.server_id, it => it.month == oMonth && it.dept_id == request.org_id);

            // 本年累计记录
            var cMonth = new DateTime(request.month.Value.Year, 1, 1);
            var totalList = await _dataImp.List(request.server_id, it => it.month <= request.month && it.month >= cMonth);

            // 去年累计记录
            var lMonth = new DateTime(request.month.Value.Year - 1, 1, 1);
            var rMonth = new DateTime(request.month.Value.Year - 1, request.month.Value.Month, 1);
            var lastTotalList = await _dataImp.List(request.server_id, it => it.month <= rMonth && it.month >= lMonth);

            if (list.Count > 0 && indexs.Count > 0)
            {
                var record = list.FirstOrDefault();
                var index = indexs.FirstOrDefault() == null ? new ErpBusinessObjective() : indexs.FirstOrDefault();
                var oldRecord = new ErpBusinessRecord();
                // 去年同期数
                if (oldRecords.Count > 0)
                {
                    oldRecord = oldRecords.FirstOrDefault();
                }

                // 管理费用明细
                var e = new FinanceSummaryQueryBody
                {
                    type = "管理费用",
                    project = "管理人员工资",
                    index = index.manage_person_wage,
                    cur_month = record.manage_person_wage,
                    type_sum = record.manage_cost,
                    last_year = oldRecord.manage_person_wage,
                    cur_year_total = Math.Round(totalList.Sum(it => it.manage_person_wage), 2),
                    last_year_total = Math.Round(lastTotalList.Sum(it => it.manage_person_wage), 2)
                };
                r.Add(e);
                e = new FinanceSummaryQueryBody
                {
                    type = "管理费用",
                    project = "派遣人员费用",
                    index = index.send_person_wage,
                    cur_month = record.send_person_wage,
                    type_sum = record.manage_cost,
                    last_year = oldRecord.send_person_wage,
                    cur_year_total = Math.Round(totalList.Sum(it => it.send_person_wage), 2),
                    last_year_total = Math.Round(lastTotalList.Sum(it => it.send_person_wage), 2)
                };
                r.Add(e);
                e = new FinanceSummaryQueryBody
                {
                    type = "管理费用",
                    project = "五险一金",
                    index = index.five_insurance,
                    cur_month = record.five_insurance,
                    type_sum = record.manage_cost,
                    last_year = oldRecord.five_insurance,
                    cur_year_total = Math.Round(totalList.Sum(it => it.five_insurance), 2),
                    last_year_total = Math.Round(lastTotalList.Sum(it => it.five_insurance), 2)
                };
                r.Add(e);
                e = new FinanceSummaryQueryBody
                {
                    type = "管理费用",
                    project = "公什费",
                    index = index.company_cost,
                    cur_month = record.company_cost,
                    type_sum = record.manage_cost,
                    last_year = oldRecord.company_cost,
                    cur_year_total = Math.Round(totalList.Sum(it => it.company_cost), 2),
                    last_year_total = Math.Round(lastTotalList.Sum(it => it.company_cost), 2)
                };
                r.Add(e);
                e = new FinanceSummaryQueryBody
                {
                    type = "管理费用",
                    project = "印刷费",
                    index = index.printing_cost,
                    cur_month = record.printing_cost,
                    type_sum = record.manage_cost,
                    last_year = oldRecord.printing_cost,
                    cur_year_total = Math.Round(totalList.Sum(it => it.printing_cost), 2),
                    last_year_total = Math.Round(lastTotalList.Sum(it => it.printing_cost), 2)
                };
                r.Add(e);
                e = new FinanceSummaryQueryBody
                {
                    type = "管理费用",
                    project = "通讯费",
                    index = index.connect_cost,
                    cur_month = record.connect_cost,
                    type_sum = record.manage_cost,
                    last_year = oldRecord.connect_cost,
                    cur_year_total = Math.Round(totalList.Sum(it => it.connect_cost), 2),
                    last_year_total = Math.Round(lastTotalList.Sum(it => it.connect_cost), 2)
                };
                r.Add(e);
                e = new FinanceSummaryQueryBody
                {
                    type = "管理费用",
                    project = "水电费",
                    index = index.hydroelectric_cost,
                    cur_month = record.hydroelectric_cost,
                    type_sum = record.manage_cost,
                    last_year = oldRecord.hydroelectric_cost,
                    cur_year_total = Math.Round(totalList.Sum(it => it.hydroelectric_cost), 2),
                    last_year_total = Math.Round(lastTotalList.Sum(it => it.hydroelectric_cost), 2)
                };
                r.Add(e);
                e = new FinanceSummaryQueryBody
                {
                    type = "管理费用",
                    project = "公务车费用",
                    index = index.official_cost,
                    cur_month = record.official_cost,
                    type_sum = record.manage_cost,
                    last_year = oldRecord.official_cost,
                    cur_year_total = Math.Round(totalList.Sum(it => it.official_cost), 2),
                    last_year_total = Math.Round(lastTotalList.Sum(it => it.official_cost), 2)
                };
                r.Add(e);
                e = new FinanceSummaryQueryBody
                {
                    type = "管理费用",
                    project = "维修费",
                    index = index.repair_cost,
                    cur_month = record.repair_cost,
                    type_sum = record.manage_cost,
                    last_year = oldRecord.repair_cost,
                    cur_year_total = Math.Round(totalList.Sum(it => it.repair_cost), 2),
                    last_year_total = Math.Round(lastTotalList.Sum(it => it.repair_cost), 2)
                };
                r.Add(e);
                e = new FinanceSummaryQueryBody
                {
                    type = "管理费用",
                    project = "租金",
                    index = index.rent_cost,
                    cur_month = record.rent_cost,
                    type_sum = record.manage_cost,
                    last_year = oldRecord.rent_cost,
                    cur_year_total = Math.Round(totalList.Sum(it => it.rent_cost), 2),
                    last_year_total = Math.Round(lastTotalList.Sum(it => it.rent_cost), 2)
                };
                r.Add(e);
                e = new FinanceSummaryQueryBody
                {
                    type = "管理费用",
                    project = "审计、诉讼、咨询",
                    index = index.audit_cost,
                    cur_month = record.audit_cost,
                    type_sum = record.manage_cost,
                    last_year = oldRecord.audit_cost,
                    cur_year_total = Math.Round(totalList.Sum(it => it.audit_cost), 2),
                    last_year_total = Math.Round(lastTotalList.Sum(it => it.audit_cost), 2)
                };
                r.Add(e);
                e = new FinanceSummaryQueryBody
                {
                    type = "管理费用",
                    project = "卫生费",
                    index = index.health_cost,
                    cur_month = record.health_cost,
                    type_sum = record.manage_cost,
                    last_year = oldRecord.health_cost,
                    cur_year_total = Math.Round(totalList.Sum(it => it.health_cost), 2),
                    last_year_total = Math.Round(lastTotalList.Sum(it => it.health_cost), 2)
                };
                r.Add(e);
                e = new FinanceSummaryQueryBody
                {
                    type = "管理费用",
                    project = "差旅费",
                    index = index.travel_cost,
                    cur_month = record.travel_cost,
                    type_sum = record.manage_cost,
                    last_year = oldRecord.travel_cost,
                    cur_year_total = Math.Round(totalList.Sum(it => it.travel_cost), 2),
                    last_year_total = Math.Round(lastTotalList.Sum(it => it.travel_cost), 2)
                };
                r.Add(e);
                e = new FinanceSummaryQueryBody
                {
                    type = "管理费用",
                    project = "招待费",
                    index = index.entertain_cost,
                    cur_month = record.entertain_cost,
                    type_sum = record.manage_cost,
                    last_year = oldRecord.entertain_cost,
                    cur_year_total = Math.Round(totalList.Sum(it => it.entertain_cost), 2),
                    last_year_total = Math.Round(lastTotalList.Sum(it => it.entertain_cost), 2)
                };
                r.Add(e);
                e = new FinanceSummaryQueryBody
                {
                    type = "管理费用",
                    project = "员工培训费",
                    index = index.employee_training_cost,
                    cur_month = record.employee_training_cost,
                    type_sum = record.manage_cost,
                    last_year = oldRecord.employee_training_cost,
                    cur_year_total = Math.Round(totalList.Sum(it => it.employee_training_cost), 2),
                    last_year_total = Math.Round(lastTotalList.Sum(it => it.employee_training_cost), 2)
                };
                r.Add(e);
                e = new FinanceSummaryQueryBody
                {
                    type = "管理费用",
                    project = "残保金",
                    index = index.residual_protect_cost,
                    cur_month = record.residual_protect_cost,
                    type_sum = record.manage_cost,
                    last_year = oldRecord.residual_protect_cost,
                    cur_year_total = Math.Round(totalList.Sum(it => it.residual_protect_cost), 2),
                    last_year_total = Math.Round(lastTotalList.Sum(it => it.residual_protect_cost), 2)
                };
                r.Add(e);
                e = new FinanceSummaryQueryBody
                {
                    type = "管理费用",
                    project = "折旧、摊销",
                    index = index.depreciation_cost,
                    cur_month = record.depreciation_cost,
                    type_sum = record.manage_cost,
                    last_year = oldRecord.depreciation_cost,
                    cur_year_total = Math.Round(totalList.Sum(it => it.depreciation_cost), 2),
                    last_year_total = Math.Round(lastTotalList.Sum(it => it.depreciation_cost), 2)
                };
                r.Add(e);
                e = new FinanceSummaryQueryBody
                {
                    type = "管理费用",
                    project = "老人卡、IC卡",
                    index = index.ic_cost,
                    cur_month = record.ic_cost,
                    type_sum = record.manage_cost,
                    last_year = oldRecord.ic_cost,
                    cur_year_total = Math.Round(totalList.Sum(it => it.ic_cost), 2),
                    last_year_total = Math.Round(lastTotalList.Sum(it => it.ic_cost), 2)
                };
                r.Add(e);
                e = new FinanceSummaryQueryBody
                {
                    type = "管理费用",
                    project = "点钞工资",
                    index = index.cunting_wage,
                    cur_month = record.cunting_wage,
                    type_sum = record.manage_cost,
                    last_year = oldRecord.cunting_wage,
                    cur_year_total = Math.Round(totalList.Sum(it => it.cunting_wage), 2),
                    last_year_total = Math.Round(lastTotalList.Sum(it => it.cunting_wage), 2)
                };
                r.Add(e);
                e = new FinanceSummaryQueryBody
                {
                    type = "管理费用",
                    project = "工会经费",
                    index = index.union_funds_cost,
                    cur_month = record.union_funds_cost,
                    type_sum = record.manage_cost,
                    last_year = oldRecord.union_funds_cost,
                    cur_year_total = Math.Round(totalList.Sum(it => it.union_funds_cost), 2),
                    last_year_total = Math.Round(lastTotalList.Sum(it => it.union_funds_cost), 2)
                };
                r.Add(e);
                e = new FinanceSummaryQueryBody
                {
                    type = "管理费用",
                    project = "代发工资",
                    index = index.payroll,
                    cur_month = record.payroll,
                    type_sum = record.manage_cost,
                    last_year = oldRecord.payroll,
                    cur_year_total = Math.Round(totalList.Sum(it => it.payroll), 2),
                    last_year_total = Math.Round(lastTotalList.Sum(it => it.payroll), 2)
                };
                r.Add(e);
                e = new FinanceSummaryQueryBody
                {
                    type = "管理费用",
                    project = "党建费用",
                    index = index.party_cost,
                    cur_month = record.party_cost,
                    type_sum = record.manage_cost,
                    last_year = oldRecord.party_cost,
                    cur_year_total = Math.Round(totalList.Sum(it => it.party_cost), 2),
                    last_year_total = Math.Round(lastTotalList.Sum(it => it.party_cost), 2)
                };
                r.Add(e);
                e = new FinanceSummaryQueryBody
                {
                    type = "管理费用",
                    project = "其他",
                    index = index.other_income,
                    cur_month = record.manage_person_wage,
                    type_sum = record.manage_cost,
                    last_year = oldRecord.manage_person_wage,
                    cur_year_total = Math.Round(totalList.Sum(it => it.manage_person_wage), 2),
                    last_year_total = Math.Round(lastTotalList.Sum(it => it.manage_person_wage), 2)
                };
                r.Add(e);
                e = new FinanceSummaryQueryBody
                {
                    type = "管理费用",
                    project = "福利费",
                    index = index.welfare_cost,
                    cur_month = record.welfare_cost,
                    type_sum = record.manage_cost,
                    last_year = oldRecord.welfare_cost,
                    cur_year_total = Math.Round(totalList.Sum(it => it.welfare_cost), 2),
                    last_year_total = Math.Round(lastTotalList.Sum(it => it.welfare_cost), 2)
                };
                r.Add(e);
                e = new FinanceSummaryQueryBody
                {
                    type = "管理费用",
                    project = "公车费用",
                    index = index.bus_cost,
                    cur_month = record.bus_cost,
                    type_sum = record.manage_cost,
                    last_year = oldRecord.bus_cost,
                    cur_year_total = Math.Round(totalList.Sum(it => it.bus_cost), 2),
                    last_year_total = Math.Round(lastTotalList.Sum(it => it.bus_cost), 2)
                };
                r.Add(e);
                e = new FinanceSummaryQueryBody
                {
                    type = "管理费用",
                    project = "合计",
                    index = index.manage_cost,
                    cur_month = record.manage_cost,
                    cur_year_total = Math.Round(totalList.Sum(it => it.manage_cost), 2),
                };
                r.Add(e);
            }
            return r;
        }
    }
}