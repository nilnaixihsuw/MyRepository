﻿using ERPCore;
using ERPCore.Entity;
using ERPCore.Extensions;
using ERPCore.ORM;
using ERPDal.DecisionAnalysis;
using ERPModel.DecisionAnalysis;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.DecisionAnalysis
{
    public class ErpBusinessRecordExcelImp : ExcelImportRepository<ErpBusinessRecord>, IErpBusinessRecordExcelImp
    {
        private readonly IErpBusinessRecordDataImp _iErpBusinessRecordDataImp;

        public ErpBusinessRecordExcelImp(IErpBusinessRecordDataImp iErpBusinessRecordDataImp)
        {
            _iErpBusinessRecordDataImp = iErpBusinessRecordDataImp;
        }
        /// <summary>
        /// 导入源数据处理
        /// </summary>
        protected override Func<MemoryStream, DataTable> DisposeDTFunc => ms => ExcelImportHelper.ReadStreamToDataTable(ms);

        /// <summary>
        /// 数据转化为LIST
        /// </summary>
        /// <returns></returns>
        protected override ExcelImportRepository<ErpBusinessRecord> TranToList()
        {
            try
            {
                var list = _dt.ToDataList<ImportFinaceInfo>();
                var record = new ErpBusinessRecord
                {
                    dept_id = _info.org_id,
                    month = _info.month,
                    created_id = _client.i_id,
                    created_date = DateTime.Now
                };
                list.ForEach(item =>
                {
                    if (item.project == "票款收入")
                    {
                        record.fare_income = item.count;
                    }
                    if (item.project == "其他收入")
                    {
                        record.income_other = item.count;
                    }
                    if (item.project == "主营成本")
                    {
                        record.main_cost = item.count;
                    }
                    if (item.project == "税金及附加")
                    {
                        record.tax_additional = item.count;
                    }
                    if (item.project == "财务费用")
                    {
                        record.finance_cost = item.count;
                    }
                    if (item.project == "政府补亏")
                    {
                        record.government_bk = item.count;
                    }
                    if (item.project == "购车补贴")
                    {
                        record.rebates = item.count;
                    }
                    if (item.project == "油、电补")
                    {
                        record.oil_electric = item.count;
                    }
                    if (item.project == "旧车回购")
                    {
                        record.old_repo = item.count;
                    }
                    if (item.project == "处罚")
                    {
                        record.punishment = item.count;
                    }
                    if (item.project == "车辆报废损失")
                    {
                        record.scrappage_loss = item.count;
                    }
                    if (item.project == "其他")
                    {
                        record.revenue_other = item.count;
                    }
                    if (item.project == "管理人员工资")
                    {
                        record.manage_person_wage = item.count;
                    }
                    if (item.project == "派遣人员费用")
                    {
                        record.send_person_wage = item.count;
                    }
                    if (item.project == "五险一金")
                    {
                        record.five_insurance = item.count;
                    }
                    if (item.project == "公什费")
                    {
                        record.company_cost = item.count;
                    }
                    if (item.project == "印刷费")
                    {
                        record.printing_cost = item.count;
                    }
                    if (item.project == "通讯费")
                    {
                        record.connect_cost = item.count;
                    }
                    if (item.project == "水电费")
                    {
                        record.hydroelectric_cost = item.count;
                    }
                    if (item.project == "公务车费用")
                    {
                        record.official_cost = item.count;
                    }
                    if (item.project == "维修费")
                    {
                        record.repair_cost = item.count;
                    }
                    if (item.project == "租金")
                    {
                        record.rent_cost = item.count;
                    }
                    if (item.project == "审计、诉讼、咨询")
                    {
                        record.audit_cost = item.count;
                    }
                    if (item.project == "购置费")
                    {
                        record.but_cost = item.count;
                    }
                    if (item.project == "卫生费")
                    {
                        record.health_cost = item.count;
                    }
                    if (item.project == "差旅费")
                    {
                        record.travel_cost = item.count;
                    }
                    if (item.project == "招待费")
                    {
                        record.entertain_cost = item.count;
                    }
                    if (item.project == "员工培训费")
                    {
                        record.employee_training_cost = item.count;
                    }
                    if (item.project == "残保金")
                    {
                        record.residual_protect_cost = item.count;
                    }
                    if (item.project == "折旧、摊销")
                    {
                        record.depreciation_cost = item.count;
                    }
                    if (item.project == "老人卡、IC卡")
                    {
                        record.ic_cost = item.count;
                    }
                    if (item.project == "点钞工资")
                    {
                        record.cunting_wage = item.count;
                    }
                    if (item.project == "工会经费")
                    {
                        record.union_funds_cost = item.count;
                    }
                    if (item.project == "代发工资")
                    {
                        record.payroll = item.count;
                    }
                    if (item.project == "党建费用")
                    {
                        record.party_cost = item.count;
                    }
                    if (item.project == "其他")
                    {
                        record.other_income = item.count;
                    }
                    if (item.project == "福利费")
                    {
                        record.welfare_cost = item.count;
                    }
                    if (item.project == "公车费用")
                    {
                        record.bus_cost = item.count;
                    }
                    record.manage_cost = record.manage_person_wage
                        + record.send_person_wage
                        + record.five_insurance
                        + record.company_cost
                        + record.printing_cost
                        + record.connect_cost
                        + record.hydroelectric_cost
                        + record.official_cost
                        + record.repair_cost
                        + record.rent_cost
                        + record.audit_cost
                        + record.health_cost
                        + record.travel_cost
                        + record.entertain_cost
                        + record.employee_training_cost
                        + record.residual_protect_cost
                        + record.depreciation_cost
                        + record.ic_cost
                        + record.cunting_wage
                        + record.union_funds_cost
                        + record.payroll
                        + record.party_cost
                        + record.other_income
                        + record.welfare_cost
                        + record.bus_cost;
                });

                this._list = new List<ErpBusinessRecord>() { record };
                _task.insert_count = _list.Count;
                return this;
            }
            catch (Exception ex)
            {
                throw new Exception("转化成LIST<T>" + ex.Message);
            }

        }

        /// <summary>
        /// 单行检测
        /// </summary>
        protected override Dictionary<string, Func<ErpBusinessRecord, Tuple<bool, string>>> SelfDefinedCheckFunc => new Dictionary<string, Func<ErpBusinessRecord, Tuple<bool, string>>>
        {
            //{ "判空检测", (e)=>{
            //    if (e.dept_id == null)
            //    {

            //    }
            //    return new Tuple<bool, string>(false,"报告日期格式不正确");
            //}}
        };

        /// <summary>
        /// 整体检测
        /// </summary>
        protected override Dictionary<string, Func<List<ErpBusinessRecord>, Tuple<bool, string>>> SelfDefinedCheckFuncPlus => new Dictionary<string, Func<List<ErpBusinessRecord>, Tuple<bool, string>>>
        {
            //{ "报告日期检测", (e)=>{
            //    return new Tuple<bool, string>(false,"报告日期格式不正确");
            //}},
        };

        /// <summary>
        /// 保存数据
        /// </summary>
        protected override Func<List<ErpBusinessRecord>, Task<bool>> SaveRecord => async list =>
        {
            var olds = await _iErpBusinessRecordDataImp.List(_info.server_id, it => it.month == _info.month && it.dept_id == _info.org_id);
            if (olds.Count > 0)
            {
                if (_info.type == 1)    //覆盖
                {
                    var old = olds.FirstOrDefault();
                    _list[0].id = old.id;
                    _task.update_count++;
                    _task.insert_count--;
                    return await _iErpBusinessRecordDataImp.Update(_info.server_id, _list[0]);
                }
                //保持原数据
                if (_info.type == 0)
                {
                    _list = new List<ErpBusinessRecord>();
                    _task.insert_count = 0;
                }
            }
            else
            {
                return await _iErpBusinessRecordDataImp.Insertable(_info.server_id, _list);
            }

            return true;
        };

        /// <summary>
        /// 汇总信息
        /// </summary>
        protected override Func<List<ErpBusinessRecord>, string> GetSummary => list =>
        {
            string msg = string.Format("本次导入数据{0}条,覆盖{1}条", _task.insert_count, _task.update_count);
            return msg;
        };
    }
}
