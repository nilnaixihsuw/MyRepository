﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPModel.ApiModel.DecisionAnalysis;
using ERPModel.DecisionAnalysis;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.DecisionAnalysis
{
    public interface IErpBusinessRecordImp : IBusinessRepository<ErpBusinessRecord>
    {
        Task<bool> AddErpBusinessRecord(string server_id, ErpBusinessRecord context, ClientInformation client);
        Task<Tuple<List<ErpBusinessRecord>, int>> QueryErpBusinessRecordPageList(string server_id, BaseRequest<ErpBusinessRecord> request, string v);
        Task<List<ErpBusinessRecord>> QueryErpBusinessRecordList(string server_id, BaseRequest<ErpBusinessRecord> request, string v);
        Task<bool> BatchDelete(string server_id, List<decimal> context);
        Task<(List<FinanceSummaryQueryBody>, List<FinanceAnalysisItem>)> QueryFinanceList(ErpBusinessRecordRequest request);
        Task<List<FinanceSummaryQueryBody>> ManageFeeList(ErpBusinessRecordRequest request);
    }
}