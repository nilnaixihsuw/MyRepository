﻿using ERPDal.Repository;
using ERPModel.ApiModel.MaterialManage.ReportManage;
using ERPModel.MaterialManage.BaseinfoManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.MaterialManage
{
    public interface IMateialReportImp 
    {
        /// <summary>
        /// 单车维修费用统计
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        Task<List<VehicleRepairDto>> GetMaterialFee(VehicleRepairRequest request);
    }
}
