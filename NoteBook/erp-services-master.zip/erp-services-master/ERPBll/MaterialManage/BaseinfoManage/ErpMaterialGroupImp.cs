﻿using ERPCore.ORM;
using ERPDal.MaterialManage.BaseinfoManage;
using ERPModel.MaterialManage.BaseinfoManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using ERPDal.Repository;

namespace ERPBll.MaterialManage.BaseinfoManage
{
    public class ErpMaterialGroupImp : BaseBusiness<ErpMaterialGroup>, IErpMaterialGroupImp
    {
        public ErpMaterialGroupImp(IErpMaterialGroupDataImp dataImp)
        {

        }
    }
}