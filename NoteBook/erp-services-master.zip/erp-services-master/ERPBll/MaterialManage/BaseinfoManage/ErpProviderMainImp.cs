﻿using ERPCore.ORM;
using ERPDal.MaterialManage.BaseinfoManage;
using ERPModel.MaterialManage.BaseinfoManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;

namespace ERPBll.MaterialManage.BaseinfoManage
{
    public class ErpProviderMainImp : BusinessRespository<ErpProviderMain, IErpProviderMainDataImp>, IErpProviderMainImp
    {
        public ErpProviderMainImp(IErpProviderMainDataImp dataImp): base(dataImp)
        {

        }
    }
}