﻿using ERPCore.ORM;
using ERPDal.Repository;
using ERPModel.MaterialManage.BaseinfoManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.MaterialManage.BaseinfoManage
{
    public interface IErpMaterialGroupImp : IBaseBusiness<ErpMaterialGroup>
    {
    }
}