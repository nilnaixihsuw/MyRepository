﻿using ERPCore.ORM;
using ERPDal.MaterialManage.BaseinfoManage;
using ERPModel.MaterialManage.BaseinfoManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using ERPModel.ApiModel.MaterialManage.BaseinfoManage;
using ERPBll.RedisManage.Dicts;
using AutoMapper;
using ERPDal;
using ERPModel.Vehicleinfomanage;
using ERPBll.WorkPlace;
using System.Text;
using ERPModel.Workplace;
using ERPModel.SystemManage;
using ERPCore.Entity;
using Yitter.IdGenerator;
using ERPDal.Repository;

namespace ERPBll.MaterialManage.BaseinfoManage
{
    public class ErpMaterialMainImp : BaseBusiness<ErpMaterialMain>, IErpMaterialMainImp
    {
        private readonly IMapper _imapper;
        private readonly IDictRedisManageImp _iDictRedisManageImp;
        private readonly IErpImportRecordImp _iErpImportRecordImp;
        private readonly IErpMessageMainImp _iErpMessageMainImp;

        public ErpMaterialMainImp(
            IMapper imapper,
            IDictRedisManageImp iDictRedisManageImp,
            IErpImportRecordImp iErpImportRecordImp,
            IErpMessageMainImp iErpMessageMainImp) 
        {
            _imapper = imapper;
            _iDictRedisManageImp = iDictRedisManageImp;
            _iErpImportRecordImp = iErpImportRecordImp;
            _iErpMessageMainImp = iErpMessageMainImp;
        }

        public async Task Import(List<MaterialDto> list, decimal id, decimal user_id, string type,string server_id)
        {
            int index = 1;
            var groups = await SqlSugarHelper.DBClient(server_id).Queryable<ErpMaterialGroup>().ToListAsync();
            var materials = await SqlSugarHelper.DBClient(server_id).Queryable<ErpMaterialMain>().ToListAsync();
            var vehicle_kind = await SqlSugarHelper.DBClient(server_id).Queryable<MaintVehicleKind1>().ToListAsync();
            var record = await _iErpImportRecordImp.Get(server_id, r => r.id == id);//导入过程记录
            double schedule = 0.1;
            List<string> errors = new List<string>();
            foreach (var item in list)
            {
                index++;
                if (string.IsNullOrEmpty(item.code)) errors.Add($"第{index}行物料编号为空，数据非法，请检查后重试");
                if (string.IsNullOrEmpty(item.name)) errors.Add($"第{index}行物料名称为空，数据非法，请检查后重试");
                if (materials.Exists(r => r.code == item.code)) errors.Add($"第{index}行物料编号已存在，请检查后重试");
                if (!string.IsNullOrEmpty(item.measure_unit_name) &&
                    !_iDictRedisManageImp.GetByKeyAsync("material_unit").Result.Exists(r => r.c_name == item.measure_unit_name))
                    errors.Add($"第{index}行计量单位不存在，请检查后重试");

                item.main_id = groups.Exists(r => r.name == item.main_name) ? groups.First(r => r.name == item.main_name).id : groups.First(r => r.name == "未分组").id;

                item.measure_unit = string.IsNullOrEmpty(item.measure_unit_name) ? null :
                    _iDictRedisManageImp.GetByKeyAsync("material_unit").Result.FirstOrDefault(r => r.c_name == item.measure_unit_name)?.i_id;

                item.material_property = string.IsNullOrEmpty(item.material_property_name) ?
                    _iDictRedisManageImp.GetByKeyAsync("matetial_property").Result.FirstOrDefault(r => r.c_name == "外购")?.i_id
                    : _iDictRedisManageImp.GetByKeyAsync("matetial_property").Result.FirstOrDefault(r => r.c_name == item.material_property_name)?.i_id;
                if (!string.IsNullOrEmpty(item.vehicle_kind_names))
                {
                    foreach (var item1 in item.vehicle_kind_names.Split(','))
                    {
                        if (vehicle_kind.Exists(r => r.name == item1))
                        {
                            item.vehicle_kind_ids += $"{vehicle_kind.First(r => r.name == item1).id},";
                        }
                        else
                        {
                            errors.Add($"第{index}行车型数据录入有误，数据非法，请检查后重试");
                        }
                    }
                    item.vehicle_kind_ids = item.vehicle_kind_ids[0..^1];
                }

                if (record != null && (double)index / (double)list.Count >= schedule)
                {
                    record.state_child = Encoding.UTF8.GetBytes($"{index}/{list.Count}已验证");
                    await _iErpImportRecordImp.Update(server_id, record);
                    schedule += 0.1;
                }
            }

            ErpMessageMain context = new ErpMessageMain();
            context.id = Tools.GetSeqCommonID(server_id);
            context.created_id = user_id;
            context.type = 5;
            context.object_id = id.ToString();
            context.model = (int)MessageModelDic.导入导出消息;
            var menus = await SqlSugarHelper.DBClient(server_id).Queryable<SysMenuMain>().ToListAsync();
            string menu_name = string.Empty;
            Tools.LoopToAppendName(menus, record.menu_code, ref menu_name);
            if (errors != null && errors.Count > 0)
            {
                record.finish_time = DateTime.Now;
                record.state = 3;
                record.state_child = Encoding.UTF8.GetBytes(string.Join('\t', errors));
                await _iErpImportRecordImp.Update(server_id, record);

                context.title = $"导入导出提醒<br/>您有一个文件倒入失败<br/>功能为{menu_name}<br/>失败原因：{errors[0]}等，具体见详情";
                ClientInformation client = new ClientInformation() { i_id = user_id };
                await _iErpMessageMainImp.AddErpMessageMain(server_id, context, client);
            }
            else
            {
                var records = _imapper.Map<List<MaterialDto>, List<ErpMaterialMain>>(list);
                if (type == "0")
                {
                    var inList = records.Where(r => !materials.Select(r => r.code).Contains(r.code)).ToList();
                    inList.ForEach(r =>
                    {
                        r.id = YitIdHelper.NextId();
                        r.usable = 1;
                        r.created_id = user_id;
                        r.created_date = DateTime.Now;
                    });
                    await SqlSugarHelper.DBClient(server_id).Fastest<ErpMaterialMain>().BulkCopyAsync(inList);
                }
                if (type == "1")
                {
                    var updateList = records.Where(r => materials.Select(r => r.code).Contains(r.code)).ToList();
                    updateList.ForEach(r =>
                    {
                        var record = materials.First(m => m.code == r.code);
                        r.id = record.id;
                        r.barcode = record.barcode;
                        r.barcode_rule = record.barcode_rule;
                        r.batchno_rule = record.batchno_rule;
                        r.temp_meterial = record.temp_meterial;
                        r.usable = record.usable;
                        r.usable = 1;
                        r.created_id = record.created_id;
                        r.created_date = record.created_date;
                        r.update_id = user_id;
                        r.update_date = DateTime.Now;
                    });
                    await SqlSugarHelper.DBClient(server_id).Fastest<ErpMaterialMain>().BulkUpdateAsync(updateList);

                    var inList = records.Where(r => !materials.Select(r => r.code).Contains(r.code)).ToList();
                    inList.ForEach(r =>
                    {
                        r.id = YitIdHelper.NextId();
                        r.created_id = user_id;
                        r.created_date = DateTime.Now;
                    });
                    await SqlSugarHelper.DBClient(server_id).Fastest<ErpMaterialMain>().BulkCopyAsync(inList);
                }

                var timeSpan = record.finish_time - record.start_time;
                var deal_time = $"{timeSpan.Value.Hours}:{timeSpan.Value.Minutes}:{timeSpan.Value.Seconds}";
                context.title = $"导入导出提醒<br/>您有一个文件导入成功<br/>功能为{menu_name}<br/>共计用时{deal_time}";
                ClientInformation client = new ClientInformation() { i_id = user_id };
                await _iErpMessageMainImp.AddErpMessageMain(server_id, context, client);
            }
        }

        public async Task<Tuple<int, List<MaterialDto>>> GetData(MaterialRequest request)
        {
            RefAsync<int> totalCount = 0;
            var records = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpMaterialMain>()
                .Where(request.ToExp())
                .OrderBy(r => r.code)
                .ToPageListAsync(request.page_index, request.page_size, totalCount);
            var list = _imapper.Map<List<ErpMaterialMain>, List<MaterialDto>>(records);
            return new Tuple<int, List<MaterialDto>>(totalCount, list);
        }
    }
}