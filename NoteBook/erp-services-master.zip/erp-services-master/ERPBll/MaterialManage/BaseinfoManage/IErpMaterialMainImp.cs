﻿using ERPCore.ORM;
using ERPDal.Repository;
using ERPModel.ApiModel.MaterialManage.BaseinfoManage;
using ERPModel.MaterialManage.BaseinfoManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.MaterialManage.BaseinfoManage
{
    public interface IErpMaterialMainImp : IBaseBusiness<ErpMaterialMain>
    {
        /// <summary>
        /// 大数据导入
        /// </summary>
        Task Import(List<MaterialDto> list, decimal id, decimal user_id, string type, string server_id);

        /// <summary>
        /// 获取物料数据
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        Task<Tuple<int, List<MaterialDto>>> GetData(MaterialRequest request);
    }
}