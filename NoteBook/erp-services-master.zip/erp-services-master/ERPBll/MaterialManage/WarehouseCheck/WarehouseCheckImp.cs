﻿using AutoMapper;
using ERPBll.RedisManage.Extension;
using ERPDal;
using ERPModel.ApiModel.MaterialManage.InventoryManage;
using ERPModel.DataBase;
using ERPModel.MaterialManage.BaseinfoManage;
using ERPModel.MaterialManage.InventoryManage;
using ERPModel.MaterialManage.WarehouseCheck;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.MaterialManage.WarehouseCheck
{
    public class WarehouseCheckImp : IWarehouseCheckImp
    {
        private readonly IMapper _imapper;
        private readonly IWarehouseRedisManageImp _iWarehouseRedisManageImp;
        public WarehouseCheckImp(
            IWarehouseRedisManageImp iWarehouseRedisManageImp,
            IMapper imapper)
        {
            _imapper = imapper;
            _iWarehouseRedisManageImp = iWarehouseRedisManageImp;
        }

        /// <summary>
        /// 分页查询主表
        /// </summary>
        public async Task<(List<ErpWarehouseCheckDto>, int)> GetByPageAsync(ErpWarehouseCheckQuery query)
        {
            RefAsync<int> totalCount = 0;

            var list = await SqlSugarHelper.DBClient(query.server_id)
                                .Queryable<ErpWarehouseCheck>()
                                .Mapper(x => x.check_info, x => x.check_id)
                                .Mapper(x => x.warehouse_info, x => x.warehouse_id)
                                .Mapper(x => {
                                    x.details = SqlSugarHelper.DBClient(query.server_id)
                                                    .Queryable<ErpWarehouseCheckDetail>()
                                                    .Where(y => y.check_id == x.id)
                                                    .Mapper(y =>
                                                    {
                                                        y.material_info = SqlSugarHelper.DBClient(query.server_id)
                                                                            .Queryable<ErpMaterialMain>()
                                                                            .Where(z => z.id == y.material_id)
                                                                            .First();

                                                        if (y.material_info != null)
                                                        {
                                                            y.unit_info = SqlSugarHelper.DBClient(query.server_id)
                                                                            .Queryable<SysCommonDictDetail>()
                                                                            .Where(z => z.i_id == y.material_info.measure_unit)
                                                                            .First();
                                                        }
                                                    })
                                                    .ToList();
                                })
                                .Where(query.ToExp())
                                .ToPageListAsync(query.page_index, query.page_size, totalCount);

            var data = _imapper.Map<List<ErpWarehouseCheck>, List<ErpWarehouseCheckDto>>(list);
            return (data, totalCount);
        }

        /// <summary>
        /// 分页查询明细
        /// </summary>
        public async Task<(List<ErpWarehouseCheckDetailDto>, int)> GetDetailByPageAsync(ErpWarehouseCheckDetailQuery query)
        {
            RefAsync<int> totalCount = 0;

            var list = await SqlSugarHelper.DBClient(query.server_id)
                                .Queryable<ErpWarehouseCheckDetail, ErpMaterialMain>(
                                    (a, b) => new JoinQueryInfos(
                                        JoinType.Left, a.material_id == b.id
                                     ))
                                .Where(query.ToExp())
                                .Mapper(x =>
                                {
                                    x.material_info = SqlSugarHelper.DBClient(query.server_id)
                                                            .Queryable<ErpMaterialMain>()
                                                            .Where(y => y.id == x.material_id)
                                                            .First();
                                    if (x.material_info != null)
                                    {
                                        x.unit_info = SqlSugarHelper.DBClient(query.server_id)
                                                            .Queryable<SysCommonDictDetail>()
                                                            .Where(y => y.i_id == x.material_info.measure_unit)
                                                            .First();
                                    }
                                })
                                .Mapper(x => x.material_info, x => x.material_id)
                                .ToPageListAsync(query.page_index, query.page_size, totalCount);

            var data = _imapper.Map<List<ErpWarehouseCheckDetail>, List<ErpWarehouseCheckDetailDto>>(list);
            return (data, totalCount);
        }

        /// <summary>
        /// 新增/编辑
        /// </summary>
        public async Task<ErpWarehouseCheckDto> CreateOrUpdateAsync(
            string server_id, decimal? user_id, CreateOrUpdateErpWarehouseCheck input)
        {
            if (input.id.HasValue && input.id != 0)
            {
                var info = await SqlSugarHelper.DBClient(server_id)
                   .Queryable<ErpWarehouseCheck>()
                   .FirstAsync(x => x.id == input.id);

                if (info == null)
                {
                    throw new Exception($"未找到回收废料信息，id={input.id}");
                }

                _imapper.Map(input, info);
                info.SetUpdate(user_id);

                //删除旧盘点明细
                await SqlSugarHelper.DBClient(server_id).Deleteable<ErpWarehouseCheckDetail>()
                            .Where(x => x.check_id == input.id).ExecuteCommandAsync();

                //添加盘点明细
                if (info.details != null && info.details.Count > 0)
                {
                    info.details.ForEach(r =>
                    {
                        r.id = Tools.GetEngineID(server_id);
                        r.SetCreate(user_id, info.id);
                    });
                    await SqlSugarHelper.DBClient(server_id).Insertable(info.details).ExecuteCommandAsync();
                }

                await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync();

                return _imapper.Map<ErpWarehouseCheck, ErpWarehouseCheckDto>(info);
            }
            else
            {
                var info = _imapper.Map<CreateOrUpdateErpWarehouseCheck, ErpWarehouseCheck>(input);
                info.id = Tools.GetEngineID(server_id);
                info.state = 1;
                info.SetCreate(user_id);

                //添加盘点明细
                if (info.details != null && info.details.Count > 0)
                {
                    info.details.ForEach(r =>
                    {
                        r.id = Tools.GetEngineID(server_id);
                        r.SetCreate(user_id, info.id);
                    });
                    await SqlSugarHelper.DBClient(server_id).Insertable(info.details).ExecuteCommandAsync();
                }

                await SqlSugarHelper.DBClient(server_id).Insertable(info).ExecuteCommandAsync();

                return _imapper.Map<ErpWarehouseCheck, ErpWarehouseCheckDto>(info);
            }
        }

        /// <summary>
        /// 删除
        /// </summary>
        public async Task<bool> DeleteAsync(string server_id, List<decimal> ids)
        {
            //删除主表信息
            var res = await SqlSugarHelper.DBClient(server_id)
                            .Deleteable<ErpWarehouseCheck>()
                            .Where(x => ids.Contains(x.id))
                            .ExecuteCommandAsync() > 0;

            //删除子表信息
            await SqlSugarHelper.DBClient(server_id)
                            .Deleteable<ErpWarehouseCheckDetail>()
                            .Where(x => ids.Contains(x.check_id))
                            .ExecuteCommandAsync();

            return res;
        }

        public async Task<bool> ReviewRecord(string server_id, Review_Result request, decimal user_id)
        {
            using var DB = SqlSugarHelper.DBClient(server_id);
            var records = await DB.Queryable<ErpWarehouseCheck>()
                .Includes(r => r.details)
                .Where(r => request.ids.Contains(r.id))
                .ToListAsync();
            records.ForEach(r => r.state = request.result);
            //await DB.Updateable(records).ExecuteCommandAsync();
            var time_records = await DB.Queryable<ErpTimeInventory>().ToListAsync();
            var enter_records = await DB.Queryable<ErpEnterInventoryRecord>()
                .Includes(r => r.details).ToListAsync();
            var leave_record = await DB.Queryable<ErpLeaveInventoryRecord>()
                .Includes(r => r.details).ToListAsync();
            var leave_inv_details = await DB.Queryable<ErpLeaveInventoryDetail>().ToListAsync();
            leave_record.ForEach(r => r.details.ForEach(m => m.details = leave_inv_details.Where(n => n.main_id == m.id).ToList()));
            foreach (var item in records)
            {
                var enter_details = item.details.Where(r => r.state == 1).ToList();
                var leave_details = item.details.Where(r => r.state == 2).ToList();
                if (enter_details != null && enter_details.Count > 0)
                {
                    if (request.result == 2)
                    {
                        var enter = new ErpEnterInventoryRecord();
                        string enter_num = await _iWarehouseRedisManageImp.GetBatno(DateTime.Now, 0);
                        if (string.IsNullOrEmpty(enter_num))
                        {
                            enter.enter_num = "PYRK" + DateTime.Now.ToString("yyyyMMdd") + "0001";
                            await _iWarehouseRedisManageImp.SetBatno(DateTime.Now, 1, 0);
                        }
                        else
                        {
                            enter.enter_num = "PYRK" + enter_num;
                        }
                        enter.id = Tools.GetSeqCommonID(server_id);
                        enter.state = 2;
                        enter.SetCreate((int)user_id);
                        enter.enter_date = DateTime.Now;
                        enter.enter_type = "PYRK";
                        enter.house_id = item.warehouse_id.HasValue ? item.warehouse_id.Value : 0;
                        enter.review_date = DateTime.Now;
                        enter.review_id = user_id;
                        await DB.Insertable(enter).ExecuteCommandAsync();
                        item.enter_num = enter.enter_num;
                        await DB.Updateable(item).ExecuteCommandAsync();

                        enter.details = new List<ErpEnterInventory>();
                        var times = new List<ErpTimeInventory>();
                        foreach (var item1 in enter_details)
                        {
                            var temp1 = new ErpEnterInventory();
                            temp1.main_id = enter.id;
                            temp1.material_id = item1.material_id;
                            temp1.count = (decimal)item1.difference;
                            var a = time_records.Where(r => r.material_id == item1.material_id).ToList();
                            temp1.price = a.Sum(r => r.price) == 0 ? 0 : a.Sum(r => r.total_price) / a.Sum(r => r.price);
                            temp1.total_price = temp1.price * Convert.ToDouble(temp1.count);
                            temp1.cost_price = a.Sum(r => r.cost_price) == 0 ? 0 : a.Sum(r => r.cost_total_price) / a.Sum(r => r.cost_price);
                            temp1.cost_total_price = temp1.cost_price * Convert.ToDouble(temp1.count);
                            temp1.created_id = user_id;
                            temp1.created_date = DateTime.Now;

                            var batno = await _iWarehouseRedisManageImp.GetBatno(enter.enter_date, 1);
                            if (string.IsNullOrEmpty(batno))
                            {
                                batno = $"{enter.enter_date.ToString("yyyyMMdd")}0001";
                                temp1.batch_no = batno;
                                enter.details.Add(temp1);
                                await _iWarehouseRedisManageImp.SetBatno(enter.enter_date, 1, 1);
                            }
                            else
                            {
                                temp1.batch_no = batno;
                                enter.details.Add(temp1);
                            }

                            var time_record = new ErpTimeInventory();
                            time_record.house_id = item.warehouse_id ?? 0;
                            time_record.count = temp1.count;
                            time_record.total_price = temp1.total_price;
                            time_record.price = temp1.price;
                            time_record.cost_total_price = temp1.cost_total_price;
                            time_record.cost_price = temp1.cost_price;
                            time_record.batch_no = temp1.batch_no;
                            time_record.material_id = temp1.material_id;
                            time_record.created_date = DateTime.Now;
                            time_record.created_id = user_id;
                            times.Add(time_record);
                        }
                        await DB.Insertable(enter.details).ExecuteCommandAsync();
                        await DB.Insertable(times).ExecuteCommandAsync();
                    }
                    if (request.result == 3)
                    {
                        var enter = enter_records.Find(r => r.enter_num == item.enter_num);
                        await DB.Deleteable(enter).ExecuteCommandAsync();
                        await DB.Deleteable(enter.details).ExecuteCommandAsync();
                        await DB.Deleteable<ErpTimeInventory>().Where(r => enter.details.Select(m => m.batch_no).Contains(r.batch_no)).ExecuteCommandAsync();
                        item.enter_num = "";
                        await DB.Updateable(item).ExecuteCommandAsync();
                    }
                }
                if (leave_details != null && leave_details.Count > 0)
                {
                    if (request.result == 2)
                    {
                        var leave = new ErpLeaveInventoryRecord();
                        string leave_num = await _iWarehouseRedisManageImp.GetBatno(DateTime.Now, 2);
                        if (string.IsNullOrEmpty(leave_num))
                        {
                            leave.leave_num = "PKCK" + DateTime.Now.ToString("yyyyMMdd") + "0001";
                            await _iWarehouseRedisManageImp.SetBatno(DateTime.Now, 1, 0);
                        }
                        else
                        {
                            leave.leave_num = "PKCK" + leave;
                        }
                        leave.id = Tools.GetSeqCommonID(server_id);
                        leave.state = 2;
                        leave.SetCreate((int)user_id);
                        leave.leave_date = DateTime.Now;
                        leave.leave_type = "PKCK";
                        leave.house_id = item.warehouse_id ?? 0;
                        leave.review_date = DateTime.Now;
                        leave.review_id = user_id;
                        await DB.Insertable(leave).ExecuteCommandAsync();
                        item.leave_num = leave.leave_num;
                        await DB.Updateable(item).ExecuteCommandAsync();

                        leave.details = new List<ErpLeaveInventory>();
                        foreach (var item1 in leave_details)
                        {
                            var temp1 = new ErpLeaveInventory();
                            temp1.main_id = leave.id;
                            temp1.material_id = item1.material_id;
                            temp1.count = Convert.ToDecimal(Math.Abs(item1.difference.Value));
                            var a = time_records.Where(r => r.material_id == item1.material_id).ToList();
                            temp1.price = a.Sum(r => r.price) == 0 ? 0 : a.Sum(r => r.total_price) / a.Sum(r => r.price);
                            temp1.total_price = temp1.price * Convert.ToDouble(temp1.count);
                            temp1.created_id = user_id;
                            temp1.created_date = DateTime.Now;
                            leave.details.Add(temp1);
                        }
                        await DB.Insertable(leave.details).ExecuteCommandAsync();

                        var b = await DB.Queryable<ErpLeaveInventory>().Where(r => r.main_id == leave.id).ToListAsync();
                        var details = new List<ErpLeaveInventoryDetail>();
                        var times = new List<ErpTimeInventory>();
                        foreach (var item1 in b)
                        {
                            var time_record = time_records.Where(r => r.material_id == item1.material_id).ToList();
                            decimal count = 0;
                            foreach (var item2 in time_records)
                            {
                                count += item2.count;
                                var temp2 = new ErpLeaveInventoryDetail();
                                temp2.main_id = item2.id;
                                if (count >= item1.count)
                                {
                                    temp2.count = item1.count - count + item2.count;
                                    temp2.price = item2.price;
                                    temp2.total_price = item2.price * Convert.ToDouble(item2.count);
                                    temp2.batch_no = item2.batch_no;
                                    temp2.cost_price = item2.cost_price;
                                    temp2.cost_total_price = item2.cost_price * Convert.ToDouble(item2.count);
                                    details.Add(temp2);
                                    item2.count -= temp2.count;
                                    times.Add(item2);
                                    break;
                                }
                                else
                                {
                                    temp2.count = item2.count;
                                    temp2.price = item2.price;
                                    temp2.total_price = item2.price * Convert.ToDouble(item2.count);
                                    temp2.batch_no = item2.batch_no;
                                    temp2.cost_price = item2.cost_price;
                                    temp2.cost_total_price = item2.cost_price * Convert.ToDouble(item2.count);
                                    details.Add(temp2);
                                    item2.count = 0;
                                    times.Add(item2);
                                }
                            }
                        }
                        await DB.Updateable(times).ExecuteCommandAsync();
                        await DB.Insertable(details).ExecuteCommandAsync();
                    }
                    if (request.result == 3)
                    {
                        var leave = leave_record.Find(r => r.leave_num == item.leave_num);
                        await DB.Deleteable(leave).ExecuteCommandAsync();
                        await DB.Deleteable(leave.details).ExecuteCommandAsync();

                        var details = new List<ErpLeaveInventoryDetail>();
                        leave.details.ForEach(r => details.AddRange(r.details));
                        await DB.Deleteable(details).ExecuteCommandAsync();
                        foreach (var item1 in details)
                        {
                            var time_record = time_records.Find(r => r.batch_no == item1.batch_no);
                            time_record.count += item1.count;
                            time_record.total_price += item1.total_price;
                            if (item1.cost_total_price != null)
                            {
                                time_record.total_price += (double)item1.cost_total_price;
                            }
                            time_record.update_date = DateTime.Now;
                            time_record.update_id = user_id;
                            await DB.Updateable(time_record).ExecuteCommandAsync();
                        }
                        item.leave_num = "";
                        await DB.Updateable(item).ExecuteCommandAsync();
                    }
                }
            }

            return true;
        }
    }
}
