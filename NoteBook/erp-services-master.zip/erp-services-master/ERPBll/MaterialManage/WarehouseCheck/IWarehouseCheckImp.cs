﻿using ERPModel.ApiModel.MaterialManage.InventoryManage;
using ERPModel.MaterialManage.WarehouseCheck;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.MaterialManage.WarehouseCheck
{
    public interface IWarehouseCheckImp
    {
        /// <summary>
        /// 分页查询主表
        /// </summary>
        Task<(List<ErpWarehouseCheckDto>, int)> GetByPageAsync(ErpWarehouseCheckQuery query);

        /// <summary>
        /// 分页查询明细
        /// </summary>
        Task<(List<ErpWarehouseCheckDetailDto>, int)> GetDetailByPageAsync(ErpWarehouseCheckDetailQuery query);

        /// <summary>
        /// 新增/编辑
        /// </summary>
        Task<ErpWarehouseCheckDto> CreateOrUpdateAsync(string server_id, decimal? user_id, CreateOrUpdateErpWarehouseCheck input);

        /// <summary>
        /// 删除
        /// </summary>
        Task<bool> DeleteAsync(string server_id, List<decimal> ids);

        /// <summary>
        /// 审核、反审核记录
        /// </summary>
        /// <param name="server_id"></param>
        /// <param name="result"></param>
        /// <returns></returns>
        Task<bool> ReviewRecord(string server_id, Review_Result result, decimal user_id);
    }
}
