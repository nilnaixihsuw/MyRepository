﻿using ERPBll.MaterialManage.InventoryManage;
using ERPBll.RedisManage;
using ERPBll.RedisManage.Lines;
using ERPCore.DI;
using ERPDal;
using ERPDal.Repository;
using ERPModel.ApiModel.MaterialManage.ReportManage;
using ERPModel.MaintManage;
using ERPModel.MaterialManage.BaseinfoManage;
using ERPModel.MaterialManage.InventoryManage;
using ERPModel.MileManage;
using ERPModel.Repairs.MaintRepairItems;
using ERPModel.Repairs.MaintRepairOrders;
using ERPModel.UserManage;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.MaterialManage
{
    public class MateialReportImp : IMateialReportImp
    {
        private IVehicleRedisManageImp _iVehicleRedisManageImp;
        private ILineRedisImp _iLineRedisImp;
        public MateialReportImp(
            IVehicleRedisManageImp iVehicleRedisManageImp,
            ILineRedisImp iLineRedisImp)
        {
            _iVehicleRedisManageImp = iVehicleRedisManageImp;
            _iLineRedisImp = iLineRedisImp;
        }

        public async Task<List<VehicleRepairDto>> GetMaterialFee(VehicleRepairRequest request)
        {
            var vehicles = await _iVehicleRedisManageImp.GetAll1Async();
            var lines = await _iLineRedisImp.GetAllAsync();
            var orders = await SqlSugarHelper.DBClient(request.server_id).Queryable<MaintRepairOrder>()
                .Mapper(x => x.repair_items, x => x.repair_items.First().order_id)
                .Where(r => r.state != 7)
                .WhereIF(request.start != null && request.end != null, r => r.created_date >= request.start && r.created_date <= request.end)
                .ToListAsync();

            var leave_records = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpLeaveInventoryRecord>()
                .Mapper(r => r.details, r => r.details.First().main_id)
                .Where(r => r.state == 2)
                .WhereIF(request.start != null && request.end != null, r => r.created_date >= request.start && r.created_date <= request.end)
                .ToListAsync();
            var leave_detail = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpLeaveInventoryDetail>().ToListAsync();

            var od_meters = await SqlSugarHelper.DBClient(request.server_id).Queryable<MaintOdometerDetail>()
                .WhereIF(request.start != null && request.end != null, r => r.date >= request.start && r.date <= request.end)
                .ToListAsync();
            var list = new List<VehicleRepairDto>();

            if (request.ids != null && request.ids.Count > 0)
            {
                vehicles = vehicles.Where(r => request.ids.Contains(r.id)).ToList();
            }
            if (request.line_ids != null && request.line_ids.Count > 0)
            {
                vehicles = vehicles.Where(r => request.line_ids.Contains(r.line_id)).ToList();
            }
            if (vehicles == null)
            {
                return new List<VehicleRepairDto>();
            }
            vehicles = vehicles.Where(r => r.scrap == 0 || r.scrap == null).ToList();
            foreach (var item in vehicles)
            {
                var temp = new VehicleRepairDto();
                temp.id = item.id;
                temp.line_id = item.line_id;
                temp.line_name = lines.Find(r => r.id == temp.line_id)?.name;
                temp.v_num = item.v_num;
                temp.lp_num = item.lp_num;
                temp.group = Convert.ToInt32(item.group);
                temp.group_name = item.group_info?.c_name;

                var vehicle_orders = orders.Where(r => r.vehicle_id == temp.id).ToList();
                if (request.count == 0 && vehicle_orders.Count() > 0) continue;
                if (request.count == 1 && vehicle_orders.Count() == 0) continue;

                temp.count = vehicle_orders.Count();
                vehicle_orders.ForEach(r =>
                {
                    if (r.repair_items.Count > 0)
                    {
                        temp.hour_fee += r.repair_items.Sum(m => m.actual_fee);
                    }
                });
                var vehicle_materials = leave_records.Where(r => r.leave_type == "WXCK" && vehicle_orders.Select(m => m.work_code).Contains(r.relate_num)).ToList();
                if (vehicle_materials.Count() > 0)
                {
                    vehicle_materials.ForEach(r =>
                    {
                        if (r.details.Count() > 0)
                        {
                            temp.material_fee += Math.Round(Convert.ToDecimal(r.details.Sum(m => m.total_price)), 2);
                            var cost = leave_detail.Where(m => r.details.Select(n => n.id).Contains(m.main_id)).Sum(m => m.cost_total_price);
                            temp.gross_profit += Math.Round(temp.material_fee - Convert.ToDecimal(cost), 2);
                        }
                    });
                }
                temp.total = Math.Round(temp.material_fee + temp.hour_fee, 2);
                temp.miles = Math.Round(od_meters.Where(r => r.vehicle_id == temp.id).Sum(r => r.mile), 2);
                if (temp.miles > 0)
                {
                    temp.kilo_material_fee = Math.Round(temp.total / temp.miles * 1000, 2);
                }
                list.Add(temp);
            }
            list = list.OrderBy(r => r.group_name).ThenBy(r => r.line_name).ThenBy(r => r.lp_num).ToList();
            list = Tools.Sort(list, request.sort, request.ase).ToList();

            if ((request.ids == null || request.ids.Count == 0) && (request.line_ids == null || request.line_ids.Count == 0))
            {
                var group_ids = list.Select(r => r.group).Distinct().ToList();
                foreach (var item in group_ids)
                {
                    var temp = new VehicleRepairDto();
                    temp.id = -1;
                    temp.line_id = -1;
                    //temp.line_name = lines.Find(r => r.id == temp.line_id)?.name;
                    temp.v_num = "备用件";
                    temp.lp_num = "备用件";
                    temp.group = item;
                    temp.group_name = list.Find(r => r.group == item).group_name;

                    var vehicle_materials = leave_records.Where(r => r.leave_type == "WXCK" && r.pick_depatment_id == item && string.IsNullOrEmpty(r.lp_num)).ToList();
                    if (vehicle_materials.Count() > 0)
                    {
                        vehicle_materials.ForEach(r =>
                        {
                            if (r.details.Count() > 0)
                            {
                                temp.material_fee += Math.Round(Convert.ToDecimal(r.details.Sum(m => m.total_price)), 2);
                                var cost = leave_detail.Where(m => r.details.Select(n => n.id).Contains(m.main_id)).Sum(m => m.cost_total_price);
                                temp.gross_profit += Math.Round(temp.material_fee - Convert.ToDecimal(cost), 2);
                            }
                        });
                    }
                    temp.total = temp.material_fee;
                    int index = list.FindLastIndex(r => r.group == item);
                    list.Insert(index + 1, temp);
                }
            }

            return list;
        }
    }
}
