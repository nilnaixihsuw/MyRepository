﻿using AutoMapper;
using DotNetCore.CAP;
using ERPBll.Caps;
using ERPBll.FlowManage.Contracts;
using ERPBll.RedisManage.Extension;
using ERPBll.RedisManage.Users;
using ERPCore.Entity;
using ERPDal;
using ERPModel.DataBase;
using ERPModel.FlowManage;
using ERPModel.FlowManage.FlowRecords;
using ERPModel.MaterialManage.BaseinfoManage;
using ERPModel.MaterialManage.PurchaseOrder;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.MaterialManage.PurchaseOrder
{
    public class PurchaseOrderImp : IPurchaseOrderImp
    {
        private readonly IMapper _imapper;
        private readonly IErpFlowRecordImp _iErpFlowRecordImp;
        private readonly IWarehouseRedisManageImp _iWarehouseRedisManageImp;
        private readonly IUserRedisImp _iUserRedisImp;

        public PurchaseOrderImp(
            IMapper imapper,
            IErpFlowRecordImp iErpFlowRecordImp,
            IUserRedisImp iUserRedisImp,
            IWarehouseRedisManageImp iWarehouseRedisManageImp)
        {
            _imapper = imapper;
            _iErpFlowRecordImp = iErpFlowRecordImp;
            _iUserRedisImp = iUserRedisImp;
            _iWarehouseRedisManageImp = iWarehouseRedisManageImp;
        }

        /// <summary>
        /// 分页查询全部
        /// </summary>
        public async Task<(List<ErpPurchaseOrderDto>, int)> GetByPageAsync(
            string server_id, decimal? user_id, ErpPurchaseOrderQuery input)
        {
            RefAsync<int> totalCount = 0;

            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpPurchaseOrder>()
                                .Where(input.ToExp())
                                .OrderBy(x => x.state, OrderByType.Asc)
                                .OrderBy(x => x.purchase_code, OrderByType.Desc)
                                .Mapper(x => x.created_info, x => x.created_id)
                                .Mapper(x => x.purchase_user_info, x => x.purchase_user)
                                .Mapper(x => x.purchase_dept_info, x => x.purchase_dept)
                                .Mapper(x =>
                                {
                                    x.details = SqlSugarHelper.DBClient(server_id)
                                                        .Queryable<ErpPurchaseOrderDetail>()
                                                        .Mapper(y =>
                                                        {
                                                            y.material_info = SqlSugarHelper.DBClient(server_id)
                                                                                .Queryable<ErpMaterialMain>()
                                                                                .Where(z => z.id == y.material_id)
                                                                                .First();
                                                            if (y.material_info != null)
                                                            {
                                                                y.unit_info = SqlSugarHelper.DBClient(server_id)
                                                                                .Queryable<SysCommonDictDetail>()
                                                                                .Where(z => z.i_id == y.material_info.measure_unit)
                                                                                .First();
                                                            }
                                                        })
                                                        .Where(y => y.order_id == x.id)
                                                        .ToList();

                                    x.total_fee = x.details.Sum(y => y.fee);

                                    x.files = SqlSugarHelper.DBClient(server_id)
                                                        .Queryable<ErpPurchaseOrderFile>()
                                                        .Where(y => y.order_id == x.id)
                                                        .ToList();
                                })
                                .ToPageListAsync(input.page_index, input.page_size, totalCount);

            if (list != null && list.Count > 0)
            {
                var all = await _iErpFlowRecordImp.GetListAsync(server_id, user_id,
                                        new FlowRecordQuery()
                                        {
                                            detail_ids = list.Select(x => (int)x.id).ToList()
                                        });
                foreach (var item in list)
                {
                    if (item.state == 2)//审核中
                    {
                        var info = all.FirstOrDefault(x => x.detail_id == item.id);
                        if (info != null)
                        {
                            item.user_ids = info.state_child_id;
                            item.user_names = info.state_child_name;
                        }
                    }
                }
            }

            var data = _imapper.Map<List<ErpPurchaseOrder>, List<ErpPurchaseOrderDto>>(list);

            return (data, totalCount);
        }

        /// <summary>
        /// 分页查询自己的待提交
        /// </summary>
        public async Task<(List<ErpPurchaseOrderDto>, int)> GetNoSubmitByPageAsync(
            string server_id, decimal? user_id, ErpPurchaseOrderQuery input)
        {
            RefAsync<int> totalCount = 0;

            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpPurchaseOrder>()
                                .Where(input.ToNoSubmitExp())
                                .Where(x => x.created_id == user_id)
                                .OrderBy(x => x.purchase_code, OrderByType.Desc)
                                .Mapper(x => x.created_info, x => x.created_id)
                                .Mapper(x => x.purchase_user_info, x => x.purchase_user)
                                .Mapper(x => x.purchase_dept_info, x => x.purchase_dept)
                                .Mapper(x =>
                                {
                                    x.details = SqlSugarHelper.DBClient(server_id)
                                                        .Queryable<ErpPurchaseOrderDetail>()
                                                        .Mapper(y =>
                                                        {
                                                            y.material_info = SqlSugarHelper.DBClient(server_id)
                                                                                .Queryable<ErpMaterialMain>()
                                                                                .Where(z => z.id == y.material_id)
                                                                                .First();
                                                            if (y.material_info != null)
                                                            {
                                                                y.unit_info = SqlSugarHelper.DBClient(server_id)
                                                                                .Queryable<SysCommonDictDetail>()
                                                                                .Where(z => z.i_id == y.material_info.measure_unit)
                                                                                .First();
                                                            }
                                                        })
                                                        .Where(y => y.order_id == x.id)
                                                        .ToList();

                                    x.total_fee = x.details.Sum(y => y.fee);

                                    x.files = SqlSugarHelper.DBClient(server_id)
                                                        .Queryable<ErpPurchaseOrderFile>()
                                                        .Where(y => y.order_id == x.id)
                                                        .ToList();
                                })
                                .ToPageListAsync(input.page_index, input.page_size, totalCount);

            var data = _imapper.Map<List<ErpPurchaseOrder>, List<ErpPurchaseOrderDto>>(list);

            return (data, totalCount);
        }

        /// <summary>
        /// 分页查询待我处理
        /// </summary>
        public async Task<(List<ErpPurchaseOrderDto>, int)> GetWaitMeByPageAsync(
            string server_id, decimal? user_id, ErpPurchaseOrderQuery input)
        {
            RefAsync<int> totalCount = 0;
            var wait = await _iErpFlowRecordImp.GetAllWaitAsync(server_id, user_id,
                            new FlowRecordQuery() { 
                                object_id = Convert.ToInt32(FormType.采购订单)
                            });

            var wait_ids = wait.Select(x => x.id).ToList();

            if (wait_ids == null || wait_ids.Count < 1)
            {
                return (new List<ErpPurchaseOrderDto>(), 0);
            }

            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpPurchaseOrder>()
                                .Where(input.ToWaitMeExp())
                                .Where(x => wait_ids.Contains(Convert.ToInt32(x.flow_id)))
                                .OrderBy(x => x.purchase_code, OrderByType.Desc)
                                .Mapper(x => x.created_info, x => x.created_id)
                                .Mapper(x => x.purchase_user_info, x => x.purchase_user)
                                .Mapper(x => x.purchase_dept_info, x => x.purchase_dept)
                                .Mapper(x =>
                                {
                                    x.details = SqlSugarHelper.DBClient(server_id)
                                                        .Queryable<ErpPurchaseOrderDetail>()
                                                        .Mapper(y =>
                                                        {
                                                            y.material_info = SqlSugarHelper.DBClient(server_id)
                                                                                .Queryable<ErpMaterialMain>()
                                                                                .Where(z => z.id == y.material_id)
                                                                                .First();
                                                            if (y.material_info != null)
                                                            {
                                                                y.unit_info = SqlSugarHelper.DBClient(server_id)
                                                                                .Queryable<SysCommonDictDetail>()
                                                                                .Where(z => z.i_id == y.material_info.measure_unit)
                                                                                .First();
                                                            }
                                                        })
                                                        .Where(y => y.order_id == x.id)
                                                        .ToList();

                                    x.total_fee = x.details.Sum(y => y.fee);

                                    x.files = SqlSugarHelper.DBClient(server_id)
                                                        .Queryable<ErpPurchaseOrderFile>()
                                                        .Where(y => y.order_id == x.id)
                                                        .ToList();
                                })
                                .ToPageListAsync(input.page_index, input.page_size, totalCount);

            foreach (var item in list)
            {
                if (item.state == 2)//审核中
                {
                    var info = wait.FirstOrDefault(x => x.detail_id == item.id);
                    if (info != null && info.wait_flow_step != null && info.wait_flow_step.wait_users != null)
                    {
                        item.user_ids = info.wait_flow_step.wait_users.Select(x => x.check_id).ToList();
                        item.user_names = string.Join(',', info.wait_flow_step.wait_users.Select(x => x.check_name).ToList());
                    }
                }
            }
            var data = _imapper.Map<List<ErpPurchaseOrder>, List<ErpPurchaseOrderDto>>(list);

            return (data, totalCount);
        }

        /// <summary>
        /// 分页查询我已处理
        /// </summary>
        public async Task<(List<ErpPurchaseOrderDto>, int)> GetFinishByPageAsync(
            string server_id, decimal? user_id, ErpPurchaseOrderQuery input)
        {
            RefAsync<int> totalCount = 0;
            var flows = await _iErpFlowRecordImp.GetAllFinishAsync(server_id, user_id,
                                    new FlowRecordQuery()
                                    {
                                        object_id = Convert.ToInt32(FormType.采购订单)
                                    });

            var flow_ids = flows.Select(x => x.id).ToList();

            if (flow_ids == null || flow_ids.Count < 1)
            {
                return (new List<ErpPurchaseOrderDto>(), 0);
            }

            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpPurchaseOrder>()
                                .Where(input.ToMyAlreadyExp())
                                .Where(x => flow_ids.Contains(Convert.ToInt32(x.flow_id)))
                                .OrderBy(x => x.state, OrderByType.Asc)
                                .OrderBy(x => x.purchase_code, OrderByType.Desc)
                                .Mapper(x => x.created_info, x => x.created_id)
                                .Mapper(x => x.purchase_user_info, x => x.purchase_user)
                                .Mapper(x => x.purchase_dept_info, x => x.purchase_dept)
                                .Mapper(x =>
                                {
                                    x.details = SqlSugarHelper.DBClient(server_id)
                                                        .Queryable<ErpPurchaseOrderDetail>()
                                                        .Mapper(y =>
                                                        {
                                                            y.material_info = SqlSugarHelper.DBClient(server_id)
                                                                                .Queryable<ErpMaterialMain>()
                                                                                .Where(z => z.id == y.material_id)
                                                                                .First();
                                                            if (y.material_info != null)
                                                            {
                                                                y.unit_info = SqlSugarHelper.DBClient(server_id)
                                                                                .Queryable<SysCommonDictDetail>()
                                                                                .Where(z => z.i_id == y.material_info.measure_unit)
                                                                                .First();
                                                            }
                                                        })
                                                        .Where(y => y.order_id == x.id)
                                                        .ToList();

                                    x.total_fee = x.details.Sum(y => y.fee);

                                    x.files = SqlSugarHelper.DBClient(server_id)
                                                        .Queryable<ErpPurchaseOrderFile>()
                                                        .Where(y => y.order_id == x.id)
                                                        .ToList();
                                })
                                .ToPageListAsync(input.page_index, input.page_size, totalCount);

            foreach (var item in list)
            {
                if (item.state == 2)//审核中
                {
                    var info = flows.FirstOrDefault(x => x.detail_id == item.id);
                    if (info != null && info.wait_flow_step != null && info.wait_flow_step.wait_users != null)
                    {
                        item.user_ids = info.wait_flow_step.wait_users.Select(x => x.check_id).ToList();
                        item.user_names = string.Join(',', info.wait_flow_step.wait_users.Select(x => x.check_name).ToList());
                    }
                }
            }
            var data = _imapper.Map<List<ErpPurchaseOrder>, List<ErpPurchaseOrderDto>>(list);

            return (data, totalCount);
        }

        /// <summary>
        /// 分页查询我提交的
        /// </summary>
        public async Task<(List<ErpPurchaseOrderDto>, int)> GetSubmitByPageAsync(
            string server_id, decimal? user_id, ErpPurchaseOrderQuery input)
        {
            RefAsync<int> totalCount = 0;

            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpPurchaseOrder>()
                                .Where(input.ToMySubmitExp())
                                .Where(x => x.created_id == user_id)
                                .OrderBy(x => x.state, OrderByType.Asc)
                                .OrderBy(x => x.purchase_code, OrderByType.Desc)
                                .Mapper(x => x.created_info, x => x.created_id)
                                .Mapper(x => x.purchase_user_info, x => x.purchase_user)
                                .Mapper(x => x.purchase_dept_info, x => x.purchase_dept)
                                .Mapper(x =>
                                {
                                    x.details = SqlSugarHelper.DBClient(server_id)
                                                        .Queryable<ErpPurchaseOrderDetail>()
                                                        .Mapper(y =>
                                                        {
                                                            y.material_info = SqlSugarHelper.DBClient(server_id)
                                                                                .Queryable<ErpMaterialMain>()
                                                                                .Where(z => z.id == y.material_id)
                                                                                .First();
                                                            if (y.material_info != null)
                                                            {
                                                                y.unit_info = SqlSugarHelper.DBClient(server_id)
                                                                                .Queryable<SysCommonDictDetail>()
                                                                                .Where(z => z.i_id == y.material_info.measure_unit)
                                                                                .First();
                                                            }
                                                        })
                                                        .Where(y => y.order_id == x.id)
                                                        .ToList();

                                    x.total_fee = x.details.Sum(y => y.fee);

                                    x.files = SqlSugarHelper.DBClient(server_id)
                                                        .Queryable<ErpPurchaseOrderFile>()
                                                        .Where(y => y.order_id == x.id)
                                                        .ToList();
                                })
                                .ToPageListAsync(input.page_index, input.page_size, totalCount);

            if (list != null && list.Count > 0)
            {
                var all = await _iErpFlowRecordImp.GetListAsync(server_id, user_id,
                                    new FlowRecordQuery()
                                    {
                                        detail_ids = list.Select(x => (int)x.id).ToList()
                                    });
                foreach (var item in list)
                {
                    if (item.state == 2)//审核中
                    {
                        var info = all.FirstOrDefault(x => x.detail_id == item.id);
                        if (info != null)
                        {
                            item.user_ids = info.state_child_id;
                            item.user_names = info.state_child_name;
                        }
                    }
                }
            }

            var data = _imapper.Map<List<ErpPurchaseOrder>, List<ErpPurchaseOrderDto>>(list);

            return (data, totalCount);
        }

        /// <summary>
        /// 查看详情
        /// </summary>
        public async Task<ErpPurchaseOrderDto> LookDetailAsync(
            string server_id, decimal? user_id, decimal id)
        {

            //查询
            var info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpPurchaseOrder>()
                                .Where(x => x.id == id)
                                .Mapper(x => x.created_info, x => x.created_id)
                                .Mapper(x => x.purchase_user_info, x => x.purchase_user)
                                .Mapper(x => x.purchase_dept_info, x => x.purchase_dept)
                                .Mapper(x =>
                                {
                                    x.details = SqlSugarHelper.DBClient(server_id)
                                                        .Queryable<ErpPurchaseOrderDetail>()
                                                        .Mapper(y =>
                                                        {
                                                            y.material_info = SqlSugarHelper.DBClient(server_id)
                                                                                .Queryable<ErpMaterialMain>()
                                                                                .Where(z => z.id == y.material_id)
                                                                                .First();
                                                            if (y.material_info != null)
                                                            {
                                                                y.unit_info = SqlSugarHelper.DBClient(server_id)
                                                                                .Queryable<SysCommonDictDetail>()
                                                                                .Where(z => z.i_id == y.material_info.measure_unit)
                                                                                .First();
                                                            }
                                                        })
                                                        .Where(y => y.order_id == x.id)
                                                        .ToList();

                                    x.total_fee = x.details.Sum(y => y.fee);

                                    x.files = SqlSugarHelper.DBClient(server_id)
                                                        .Queryable<ErpPurchaseOrderFile>()
                                                        .Where(y => y.order_id == x.id)
                                                        .ToList();
                                })
                                .FirstAsync();

            if (info == null)
            {
                throw new Exception($"未找到采购单信息，id={id}");
            }


            var ids = new List<int>();

            ids.Add(Convert.ToInt32(info.id));

            var all = await _iErpFlowRecordImp.GetListAsync(server_id, user_id,
                new FlowRecordQuery()
                {
                    detail_ids = ids
                });

            if (info.state == 2)//审核中
            {
                var flow_info = all.FirstOrDefault(x => x.detail_id == info.id);
                if (flow_info != null)
                {
                    info.user_ids = flow_info.state_child_id;
                    info.user_names = flow_info.state_child_name;
                }
            }
            var data = _imapper.Map<ErpPurchaseOrder, ErpPurchaseOrderDto>(info);

            return data;
        }

        /// <summary>
        /// 新增/编辑草稿
        /// </summary>
        public async Task<ErpPurchaseOrderDto> CreateOrUpdateAsync(
            string server_id, decimal? user_id, CreateOrUpdateErpPurchaseOrder input)
        {
            if (!input.purchase_dept.HasValue || input.purchase_dept == 0 || !input.purchase_date.HasValue ||
                !input.purchase_user.HasValue || input.purchase_user == 0 || string.IsNullOrWhiteSpace(input.supplier_name) || 
                !input.type.HasValue || input.type == 0 || input.details == null || input.details.Count < 1)
            {
                throw new Exception("请填写必填项");
            }

            if (input.id.HasValue && input.id != 0)
            {
                var info = await SqlSugarHelper.DBClient(server_id)
                   .Queryable<ErpPurchaseOrder>()
                   .FirstAsync(x => x.id == input.id);

                if (info == null)
                {
                    throw new Exception($"未找到采购订单信息，id={input.id}");
                }

                _imapper.Map(input, info);
                info.SetUpdate(user_id);

                //删除旧明细
                await SqlSugarHelper.DBClient(server_id).Deleteable<ErpPurchaseOrderDetail>()
                            .Where(x => x.order_id == input.id).ExecuteCommandAsync();

                //添加明细
                if (info.details != null && info.details.Count > 0)
                {
                    info.details.ForEach(r =>
                    {
                        r.id = Tools.GetEngineID(server_id);
                        r.SetCreate(user_id, info.id);
                    });
                    await SqlSugarHelper.DBClient(server_id).Insertable(info.details).ExecuteCommandAsync();
                }

                //删除旧附件
                await SqlSugarHelper.DBClient(server_id).Deleteable<ErpPurchaseOrderFile>()
                            .Where(x => x.order_id == input.id).ExecuteCommandAsync();

                //添加附件
                if (info.files != null && info.files.Count > 0)
                {
                    info.files.ForEach(r =>
                    {
                        r.id = Tools.GetEngineID(server_id);
                        r.SetCreate(user_id, info.id);
                    });
                    await SqlSugarHelper.DBClient(server_id).Insertable(info.files).ExecuteCommandAsync();
                }

                await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync();

                return _imapper.Map<ErpPurchaseOrder, ErpPurchaseOrderDto>(info);
            }
            else
            {
                var info = _imapper.Map<CreateOrUpdateErpPurchaseOrder, ErpPurchaseOrder>(input);
                info.id = Tools.GetEngineID(server_id);
                info.state = 1;
                info.SetCreate(user_id);

                string code = await _iWarehouseRedisManageImp.GetBatno(DateTime.Now, 6);
                if (string.IsNullOrWhiteSpace(code))
                {
                    code = DateTime.Now.ToString("yyyyMMdd") + "0001";
                    await _iWarehouseRedisManageImp.SetBatno(DateTime.Now, 1, 6);
                }
                info.purchase_code = code;

                //添加明细
                if (info.details != null && info.details.Count > 0)
                {
                    info.details.ForEach(r =>
                    {
                        r.id = Tools.GetEngineID(server_id);
                        r.SetCreate(user_id, info.id);
                    });
                    await SqlSugarHelper.DBClient(server_id).Insertable(info.details).ExecuteCommandAsync();
                }

                //添加附件
                if (info.files != null && info.files.Count > 0)
                {
                    info.files.ForEach(r =>
                    {
                        r.id = Tools.GetEngineID(server_id);
                        r.SetCreate(user_id, info.id);
                    });
                    await SqlSugarHelper.DBClient(server_id).Insertable(info.files).ExecuteCommandAsync();
                }

                await SqlSugarHelper.DBClient(server_id).Insertable(info).ExecuteCommandAsync();

                return _imapper.Map<ErpPurchaseOrder, ErpPurchaseOrderDto>(info);
            }
        }

        /// <summary>
        /// 删除草稿
        /// </summary>
        public async Task<bool> DeleteAsync(string server_id, List<decimal> ids)
        {
            var res = await SqlSugarHelper.DBClient(server_id)
                    .Deleteable<ErpPurchaseOrder>()
                    .Where(x => ids.Contains(x.id) &&
                            x.state == 1)
                    .ExecuteCommandAsync() > 0;

            return res;
        }

        /// <summary>
        /// 获取各状态数量
        /// </summary>
        public async Task<Dictionary<string, object>> GetCountAsync(string server_id, decimal? user_id)
        {
            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpPurchaseOrder>()
                                .ToListAsync();

            var allFlows = new List<ErpFlowRecordDto>();
            var waitFlows = new List<ErpFlowRecordDto>();
            var finishFlows = new List<ErpFlowRecordDto>();
            if (list != null && list.Count > 0)
            {
                allFlows = await _iErpFlowRecordImp.GetListAsync(server_id, user_id,
                                    new FlowRecordQuery()
                                    {
                                        object_id = Convert.ToInt32(FormType.采购订单),
                                        detail_ids = list.Select(x => (int)x.id).ToList()
                                    });
                waitFlows = await _iErpFlowRecordImp.GetAllWaitAsync(server_id, user_id,
                                    new FlowRecordQuery()
                                    {
                                        object_id = Convert.ToInt32(FormType.采购订单)
                                    });
                finishFlows = await _iErpFlowRecordImp.GetAllFinishAsync(server_id, user_id,
                                    new FlowRecordQuery()
                                    {
                                        object_id = Convert.ToInt32(FormType.采购订单)
                                    });
            }

            var wait_ids = waitFlows.Select(x => x.id).ToList();
            var finish_ids = finishFlows.Select(x => x.id).ToList();
            var all_ids = allFlows.Where(x => x.state == 0).Select(x => x.id).ToList();

            //待我处理数量
            var wait_me = list.Where(x => wait_ids.Contains(Convert.ToInt32(x.flow_id))).Count();
            //我已处理数量
            var finish_me = list.Where(x => finish_ids.Contains(Convert.ToInt32(x.flow_id))).Count();
            //我已处理(审核通过)数量
            var finish_me_already = list.Where(x => x.state == 3 && finish_ids.Contains(Convert.ToInt32(x.flow_id))).Count();
            //我已处理(审核拒绝)数量
            var finish_me_refuse = list.Where(x => x.state == 4 && finish_ids.Contains(Convert.ToInt32(x.flow_id))).Count();
            //我已处理(审核中)数量
            var finish_me_in = list.Where(x => x.state == 2 && finish_ids.Contains(Convert.ToInt32(x.flow_id))).Count();
            //我已处理(已撤销)数量
            var finish_me_revoke = list.Where(x => x.state == 5 && finish_ids.Contains(Convert.ToInt32(x.flow_id))).Count();
            //我提交的数量
            var submit_me = list.Where(x => x.created_id == user_id && x.state != 1).Count();
            //我提交的(审核通过)数量
            var submit_me_already = list.Where(x => x.state == 3 && x.created_id == user_id).Count();
            //我提交的(审核拒绝)数量
            var submit_me_refuse = list.Where(x => x.state == 4 && x.created_id == user_id).Count();
            //我提交的(审核中)数量
            var submit_me_in = list.Where(x => x.state == 2 && x.created_id == user_id).Count();
            //我提交的(已撤销)数量
            var submit_me_revoke = list.Where(x => x.state == 5 && x.created_id == user_id).Count();
            //待提交数量
            var noSubmit = list.Where(x => x.state == 1).Count();

            var dic = new Dictionary<string, object>();
            dic.Add("wait_me", Convert.ToDecimal(wait_me));
            dic.Add("finish_me", Convert.ToDecimal(finish_me));
            dic.Add("finish_me_already", Convert.ToDecimal(finish_me_already));
            dic.Add("finish_me_refuse", Convert.ToDecimal(finish_me_refuse));
            dic.Add("finish_me_in", Convert.ToDecimal(finish_me_in));
            dic.Add("finish_me_revoke", Convert.ToDecimal(finish_me_revoke));
            dic.Add("submit_me", Convert.ToDecimal(submit_me));
            dic.Add("submit_me_already", Convert.ToDecimal(submit_me_already));
            dic.Add("submit_me_refuse", Convert.ToDecimal(submit_me_refuse));
            dic.Add("submit_me_in", Convert.ToDecimal(submit_me_in));
            dic.Add("submit_me_revoke", Convert.ToDecimal(submit_me_revoke));
            dic.Add("noSubmit", Convert.ToDecimal(noSubmit));

            return dic;
        }

        /// <summary>
        /// 获取自己保存的草稿
        /// </summary>
        public async Task<ErpPurchaseOrderDto> GetByUserAsync(
            string server_id, decimal? user_id)
        {

            //查询
            var info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpPurchaseOrder>()
                                .Where(x => x.created_id == user_id && x.state == 1)
                                .Mapper(x => x.created_info, x => x.created_id)
                                .Mapper(x => x.purchase_user_info, x => x.purchase_user)
                                .Mapper(x => x.purchase_dept_info, x => x.purchase_dept)
                                .Mapper(async x =>
                                {
                                    x.details = await SqlSugarHelper.DBClient(server_id)
                                                        .Queryable<ErpPurchaseOrderDetail>()
                                                        .Mapper(async y => 
                                                        {
                                                            y.material_info = await SqlSugarHelper.DBClient(server_id)
                                                                                .Queryable<ErpMaterialMain>()
                                                                                .Where(z => z.id == y.material_id)
                                                                                .FirstAsync();
                                                            if (y.material_info != null)
                                                            {
                                                                y.unit_info = await SqlSugarHelper.DBClient(server_id)
                                                                                .Queryable<SysCommonDictDetail>()
                                                                                .Where(z => z.i_id == y.material_info.measure_unit)
                                                                                .FirstAsync();
                                                            }
                                                        })
                                                        .Where(y => y.order_id == x.id)
                                                        .ToListAsync();

                                    x.total_fee = x.details.Sum(y => y.fee);

                                    x.files = await SqlSugarHelper.DBClient(server_id)
                                                        .Queryable<ErpPurchaseOrderFile>()
                                                        .Where(y => y.order_id == x.id)
                                                        .ToListAsync();
                                })
                                .FirstAsync();

            var data = _imapper.Map<ErpPurchaseOrder, ErpPurchaseOrderDto>(info);

            return data;
        }

        /// <summary>
        /// 提交审核
        /// </summary>
        public async Task<ErpPurchaseOrderDto> SubmitAsync(string server_id, ClientInformation client, PurchaseFormData input)
        {
            var info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpPurchaseOrder>()
                                .FirstAsync(x => x.id == input.form_data.id);
            if (info == null)
            {
                throw new Exception($"未找到采购单记录，id={input.form_data.id}");
            }

            if (info.state != 1)
            {
                throw new Exception($"状态错误，只允许草稿状态提交");
            }

            //更改流程状态
            await _iErpFlowRecordImp.UpdateAsync(server_id, Convert.ToInt32(input.form_data.flow_id), Convert.ToInt32(info.id),
                    PurchaseOrderMessage.GetContent(client.c_name, info));

            info.flow_id = input.form_data.flow_id;
            info.flow_code = input.form_data.flow_code;
            info.state = 2;

            await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync();

            return _imapper.Map<ErpPurchaseOrder, ErpPurchaseOrderDto>(info);
        }

        //[CapSubscribe(EventMessages.PurchaseOrderFinish, Group = "PurchaseOrder")]
        //public async Task UpdateStateAsync(UpdateErpFlowRecordState input)
        //{
        //    var info = await SqlSugarHelper.DBClient("60.191.59.11")
        //                        .Queryable<ErpPurchaseOrder>()
        //                        .FirstAsync(x => x.flow_id == input.flow_id);
        //    if (info != null)
        //    {

        //        Console.WriteLine("采购单审核通过");

        //        if (input.state == FlowRecordState.审核通过)
        //        {
        //            info.state = 3;
        //        }
        //        else if (input.state == FlowRecordState.审核拒绝)
        //        {
        //            info.state = 4;
        //        }
        //        else if (input.state == FlowRecordState.已撤销)
        //        {
        //            info.state = 5;
        //        }

        //        await SqlSugarHelper.DBClient("60.191.59.11").Updateable(info).ExecuteCommandAsync();
        //    }
        //}
    }
}
