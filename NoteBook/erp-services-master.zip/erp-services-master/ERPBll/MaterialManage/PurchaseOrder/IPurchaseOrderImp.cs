﻿using ERPCore.Entity;
using ERPModel.MaterialManage.PurchaseOrder;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.MaterialManage.PurchaseOrder
{
    public interface IPurchaseOrderImp
    {
        /// <summary>
        /// 分页查询全部
        /// </summary>
        Task<(List<ErpPurchaseOrderDto>, int)> GetByPageAsync(string server_id, decimal? user_id, ErpPurchaseOrderQuery input);

        /// <summary>
        /// 分页查询待我处理
        /// </summary>
        Task<(List<ErpPurchaseOrderDto>, int)> GetWaitMeByPageAsync(string server_id, decimal? user_id, ErpPurchaseOrderQuery input);

        /// <summary>
        /// 分页查询我已处理
        /// </summary>
        Task<(List<ErpPurchaseOrderDto>, int)> GetFinishByPageAsync(string server_id, decimal? user_id, ErpPurchaseOrderQuery input);

        /// <summary>
        /// 分页查询我提交的
        /// </summary>
        Task<(List<ErpPurchaseOrderDto>, int)> GetSubmitByPageAsync(string server_id, decimal? user_id, ErpPurchaseOrderQuery input);

        /// <summary>
        /// 分页查询自己的待提交
        /// </summary>
        Task<(List<ErpPurchaseOrderDto>, int)> GetNoSubmitByPageAsync(string server_id, decimal? user_id, ErpPurchaseOrderQuery input);

        /// <summary>
        /// 查看详情
        /// </summary>
        Task<ErpPurchaseOrderDto> LookDetailAsync(string server_id, decimal? user_id, decimal id);

        /// <summary>
        /// 新增/编辑草稿
        /// </summary>
        Task<ErpPurchaseOrderDto> CreateOrUpdateAsync(string server_id, decimal? user_id, CreateOrUpdateErpPurchaseOrder input);

        /// <summary>
        /// 删除草稿
        /// </summary>
        Task<bool> DeleteAsync(string server_id, List<decimal> ids);

        /// <summary>
        /// 获取各状态数量
        /// </summary>
        Task<Dictionary<string, object>> GetCountAsync(string server_id, decimal? user_id);

        /// <summary>
        /// 获取自己保存的草稿
        /// </summary>
        Task<ErpPurchaseOrderDto> GetByUserAsync(string server_id, decimal? user_id);

        /// <summary>
        /// 提交审核
        /// </summary>
        Task<ErpPurchaseOrderDto> SubmitAsync(string server_id, ClientInformation client, PurchaseFormData input);
    }
}
