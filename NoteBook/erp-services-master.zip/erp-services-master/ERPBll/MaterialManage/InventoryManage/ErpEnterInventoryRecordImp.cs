﻿using AutoMapper;
using ERPBll.RedisManage.Dicts;
using ERPCore.ORM;
using ERPDal;
using ERPDal.Repository;
using ErpModel.CommonModel;
using ERPModel.ApiModel.MaterialManage.InventoryManage;
using ERPModel.MaterialManage.BaseinfoManage;
using ERPModel.MaterialManage.InventoryManage;
using ERPModel.UserManage;
using Microsoft.Extensions.Options;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.MaterialManage.InventoryManage
{
    public class ErpEnterInventoryRecordImp : BaseBusiness<ErpEnterInventoryRecord>, IErpEnterInventoryRecordImp
    {
        private readonly IMapper _imapper;
        private readonly IDictRedisManageImp _iDictRedisManageImp;
        public ErpEnterInventoryRecordImp(IMapper imapper,
            IDictRedisManageImp iDictRedisManageImp) 
        {
            _imapper = imapper;
            _iDictRedisManageImp = iDictRedisManageImp;
        }

        public async Task<EditEnterInventoryDto> GetDetails(string server_id, decimal id,string enter_num)
        {
            var record = await SqlSugarHelper.DBClient(server_id)
                             .Queryable<ErpEnterInventoryRecord>()
                             .WhereIF(id > 0, a => a.id == id)
                             .WhereIF(!string.IsNullOrEmpty(enter_num), a => a.enter_num == enter_num)
                             .Mapper(a => a.house_info, a => a.house_id)
                             .Mapper(async a =>
                             {
                                 a.details = await SqlSugarHelper.DBClient(server_id).Queryable<ErpEnterInventory>()
                                   .Where(r => r.main_id == a.id)
                                   .Mapper(m => m.material_info, m => m.material_id)
                                   .Mapper(m => m.provider_info, m => m.provider_id).ToListAsync();
                             }).FirstAsync();

            if (record == null)
            {
                return default;
            }
            var persons = await SqlSugarHelper.DBClient(server_id).Queryable<SysPerson>().ToListAsync();
            var dic = await _iDictRedisManageImp.GetAllAsync();
            var result = _imapper.Map<ErpEnterInventoryRecord, EditEnterInventoryDto>(record);
            result.buyer_name = persons.Find(r => r.i_id == result.buyer_id)?.c_name;
            result.storage_name = persons.Find(r => r.i_id == result.storage_id)?.c_name;
            result.created_name = persons.Find(r => r.i_id == record.created_id)?.c_name;
            result.review_name = persons.Find(r => r.i_id == record.review_id)?.c_name;
            switch (record.state)
            {
                case 1:
                    result.state_name = "未审核";
                    break;
                case 2:
                    result.state_name = "已审核";
                    break;
                case 3:
                    result.state_name = "取消审核";
                    break;
            }
            result.house_name = record.house_info?.name;
            result.details = new List<Enter_Detail>();
            if (record.details != null && record.details.Count > 0)
            {
                foreach (var item in record.details)
                {
                    Enter_Detail detail = _imapper.Map<ErpEnterInventory, Enter_Detail>(item);
                    detail.provider_name = item.provider_info?.name;
                    detail.material_code = item.material_info?.code;
                    detail.material_name = item.material_info?.name;
                    detail.specification = item.material_info?.specification;
                    detail.brand = item.material_info?.brand;
                    detail.measure_unit_name = dic.Find(r => r.i_id == item.material_info?.measure_unit)?.c_name;
                    result.details.Add(detail);
                }
            }
            return result;
        }

        public async Task<Tuple<int, List<EnterInventoryDto>>> GetRecords(EnterInventoryRequest request)
        {
            var ids = new List<decimal>();
            if (string.IsNullOrEmpty(request.material_name) && string.IsNullOrEmpty(request.material_code) && string.IsNullOrEmpty(request.specification))
            {
                ids = null;
            }
            else
            {
                var details = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpEnterInventory, ErpMaterialMain>((a, b) =>
                        new JoinQueryInfos(JoinType.Left, a.material_id == b.id))
                    .WhereIF(!string.IsNullOrEmpty(request.material_name), (a, b) => b.name.Contains(request.material_name))
                    .WhereIF(!string.IsNullOrEmpty(request.material_code), (a, b) => b.code.Contains(request.material_code))
                    .WhereIF(!string.IsNullOrEmpty(request.specification), (a, b) => b.specification.Contains(request.specification))
                    .ToListAsync();
                ids = details == null || details.Count == 0 ? new List<decimal>() : details.Select(r => r.main_id).ToList();
            }
            
            RefAsync<int> totalCount = 0;
            var records = await SqlSugarHelper.DBClient(request.server_id)
                             .Queryable<ErpEnterInventoryRecord>()
                             .Where(request.ToExp())
                             .WhereIF(ids != null, a => ids.Contains(a.id))
                             .Mapper(a => a.house_info, a => a.house_id)
                             .Mapper(async a =>
                             {
                                 a.details = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpEnterInventory>()
                                      .Where(m => m.main_id == a.id)
                                      .Mapper(m => m.material_info, m => m.material_id)
                                      .Mapper(m => m.provider_info, m => m.provider_id).ToListAsync();
                             }).OrderBy(a => a.enter_date, OrderByType.Desc)
                             .OrderBy(a => a.created_date, OrderByType.Desc).ToPageListAsync(request.page_index, request.page_size, totalCount);

            var list = new List<EnterInventoryDto>();
            var persons = await SqlSugarHelper.DBClient(request.server_id).Queryable<SysPerson>().ToListAsync();
            var dic = await _iDictRedisManageImp.GetAllAsync();
            //if (!string.IsNullOrEmpty(request.material_name))
            //{
            //    records.RemoveAll(r => r.details == null || r.details.Count == 0);
            //    records.RemoveAll(r => !r.details.Exists(m => m.material_info.name.Contains(request.material_name)));
            //}
            //if (!string.IsNullOrEmpty(request.material_code))
            //{
            //    records.RemoveAll(r => r.details == null || r.details.Count == 0);
            //    records.RemoveAll(r => !r.details.Exists(m => m.material_info.code.Contains(request.material_code)));
            //}
            //if (!string.IsNullOrEmpty(request.specification))
            //{
            //    records.RemoveAll(r => r.details == null || r.details.Count == 0);
            //    records.RemoveAll(r => r.details.Exists(m => string.IsNullOrEmpty(m.material_info.specification)) || !r.details.Exists(m => m.material_info.specification.Contains(request.specification)));
            //}
            //totalCount = records.Count;
            //if (request.page_index > 0)
            //{
            //    records = records.Skip((request.page_index - 1) * request.page_size).Take(request.page_size).ToList();
            //}
            foreach (var item in records)
            {
                var temp = _imapper.Map<ErpEnterInventoryRecord, EnterInventoryDto>(item);
                temp.buyer_name = persons.Find(r => r.i_id == item.buyer_id)?.c_name;
                temp.storage_name = persons.Find(r => r.i_id == item.storage_id)?.c_name;
                temp.review_name = persons.Find(r => r.i_id == item.review_id)?.c_name;
                temp.house_name = item.house_info?.name;
                switch (item.state)
                {
                    case 1:
                        temp.state_name = "未审核";
                        break;
                    case 2:
                        temp.state_name = "已审核";
                        break;
                    case 3:
                        temp.state_name = "取消审核";
                        break;
                }
                if (item.details != null && item.details.Count > 0)
                {
                    temp.material_type_num = item.details.Count;
                    temp.material_num = (int)item.details.Sum(r => r.count);
                    if (request.is_query && item.details.Count > 5)
                    {
                        item.details = item.details.OrderBy(r => r.id).Take(5).ToList();
                    }
                    foreach (var item1 in item.details)
                    {
                        var temp1 = Tools.DeepCopy(temp);
                        temp1.provider_name = item1.provider_info?.name;
                        temp1.material_code = item1.material_info?.code;
                        temp1.material_name = item1.material_info?.name;
                        temp1.specification = item1.material_info?.specification;
                        temp1.measure_unit_name = dic.Find(r => r.i_id == item1.material_info?.measure_unit)?.c_name;
                        temp1.count = item1.count;
                        temp1.price = item1.price;
                        temp1.total_price = item1.total_price;
                        temp1.batch_no = item1.batch_no;
                        temp1.cost_price = item1.cost_price;
                        temp1.cost_total_price = item1.cost_total_price;
                        list.Add(temp1);
                    }
                    continue;
                }
                list.Add(temp);
            }
            return new Tuple<int, List<EnterInventoryDto>>(totalCount, list);
        }

        public async Task<int> ReviewRecord(string server_id, decimal id, int user_id, int result)
        {
            string[] columns = new string[] { "state", "review_id", "review_date" };
            var res = await SqlSugarHelper.DBClient(server_id).Updateable(new ErpEnterInventoryRecord
            {
                state = result,
                review_id = user_id,
                review_date = DateTime.Now
            }).UpdateColumns(columns).ExecuteCommandAsync();
            return res;
        }

    }
}
