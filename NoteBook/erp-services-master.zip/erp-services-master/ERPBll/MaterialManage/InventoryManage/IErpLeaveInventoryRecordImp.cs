﻿using ERPCore.ORM;
using ERPDal.Repository;
using ERPModel.ApiModel.MaterialManage.InventoryManage;
using ERPModel.ApiModel.MaterialManage.ReportManage;
using ERPModel.MaterialManage.InventoryManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.MaterialManage.InventoryManage
{
    public interface IErpLeaveInventoryRecordImp : IBaseBusiness<ErpLeaveInventoryRecord>
    {
        Task<Tuple<int, List<LeaveInventoryDto>>> GetRecords(LeaveInventoryRequest request);

        Task<EditLeaveInventoryDto> GetDetails(string server_id, decimal id, string leave_num);

        Task<int> ReviewRecord(string server_id, decimal id, int user_id, int result);

        Task<Tuple<int, List<TireDetailDto>>> GetTireDetail(TireDetatailRequest request);
    }
}
