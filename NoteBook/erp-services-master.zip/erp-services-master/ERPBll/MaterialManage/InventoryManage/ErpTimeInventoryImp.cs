﻿using AutoMapper;
using ERPBll.RedisManage.Dicts;
using ERPDal;
using ERPDal.Repository;
using ERPModel.ApiModel.MaterialManage.InventoryManage;
using ERPModel.MaterialManage.BaseinfoManage;
using ERPModel.MaterialManage.InventoryManage;
using ERPModel.Vehicleinfomanage;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.MaterialManage.InventoryManage
{
    public class ErpTimeInventoryImp: BaseBusiness<ErpTimeInventory>, IErpTimeInventoryImp
    {
        private readonly IMapper _imapper;
        private readonly IDictRedisManageImp _iDictRedisManageImp;
        private readonly IErpLeaveInventoryImp _iErpLeaveInventoryImp;
        public ErpTimeInventoryImp(IMapper imapper,
            IDictRedisManageImp iDictRedisManageImp,
            IErpLeaveInventoryImp iErpLeaveInventoryImp)
        {
            _imapper = imapper;
            _iDictRedisManageImp = iDictRedisManageImp;
            _iErpLeaveInventoryImp = iErpLeaveInventoryImp;
        }
        public async Task<List<ErpTimeInventory>> GetData(string server_id, Expression<Func<ErpTimeInventory, bool>> expression)
        {
            return await SqlSugarHelper.DBClient(server_id).Queryable<ErpTimeInventory>()
                .WhereIF(expression != null, expression)
                .Mapper(a => a.material_info, a => a.material_id)
                .Mapper(a => a.provider_info, a => a.provider_id)
                .Mapper(a => a.house_info, a => a.house_id)
                .OrderBy(a => a.batch_no)
                .ToListAsync();
        }

        public async Task<Tuple<int, int, double, List<TimerInventoryDto>>> GetRecords(TimerInventoryRequest request)
        {
            RefAsync<int> totalCount = 0;
            var records = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpTimeInventory, ErpMaterialMain>(
                    (a, b) => new JoinQueryInfos(JoinType.Left, a.material_id == b.id))
                    .Where(request.ToExp1())
                    .Includes(a => a.material_info)
                    .Includes(a => a.provider_info)
                    .Includes(a => a.house_info)
                    .OrderBy(a => a.update_date)
                    .ToPageListAsync(request.page_index, request.page_size, totalCount);

            var records1 = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpTimeInventory, ErpMaterialMain>((a, b) =>
                      new JoinQueryInfos(JoinType.Left, a.material_id == b.id))
                  .Where(request.ToExp1())
                  .ToListAsync();
            int total_count = (int)records1.Sum(r => r.count);
            double total_money = Math.Round(records1.Sum(r => r.total_price), 2, MidpointRounding.AwayFromZero);

            var list = new List<TimerInventoryDto>();
            var dic = await _iDictRedisManageImp.GetAllAsync();
            var groups = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpMaterialGroup>().ToListAsync();
            var enter_records = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpEnterInventory>().ToListAsync();
            var vehicle_kind = await SqlSugarHelper.DBClient(request.server_id).Queryable<MaintVehicleKind>().ToListAsync();
            foreach (var item in records)
            {
                var temp = _imapper.Map<ErpTimeInventory, TimerInventoryDto>(item);
                temp.house_name = item.house_info?.name;
                if (item.material_info != null)
                {
                    temp.material_code = item.material_info.code;
                    temp.material_name = item.material_info.name;
                    temp.specification = item.material_info.specification;
                    temp.brand = item.material_info.brand;
                    temp.vehicle_kind_ids = item.material_info.vehicle_kind_ids;
                    temp.measure_unit_name = dic.Find(r => r.i_id == item.material_info.measure_unit)?.c_name;
                    temp.group_id = (decimal)item.material_info.main_id;
                    temp.group_name = groups.Find(r => r.id == temp.group_id)?.name;
                }
              
                if (!string.IsNullOrEmpty(temp.vehicle_kind_ids))
                {
                    foreach (var item1 in temp.vehicle_kind_ids.Split(','))
                    {
                        temp.vehicle_kind_names += $"{vehicle_kind.Find(m => m.i_id.ToString() == item1)?.c_name},";
                    }
                    temp.vehicle_kind_names = string.IsNullOrEmpty(temp.vehicle_kind_names) ? "" : temp.vehicle_kind_names[0..^1];
                }      
                temp.count = (int)item.count;
                temp.price = item.price;
                temp.total_price = item.total_price;
                temp.provider_name = item.provider_info?.name;
                temp.position = enter_records.Find(r => r.batch_no == item.batch_no)?.position;
                list.Add(temp);
            }
            return new Tuple<int, int, double, List<TimerInventoryDto>>(totalCount,total_count,total_money, list);
        }

        public async Task<Tuple<int, double, List<TimerInventoryDto>>> GetAllRecords(TimerInventoryRequest request)
        {
            RefAsync<int> totalCount = 0;
            int total_count = 0;
            double total_money = 0;
            var records = new List<ErpTimeInventory>();
            await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpTimeInventory, ErpMaterialMain>(
                    (a, b) => new JoinQueryInfos(JoinType.Left, a.material_id == b.id))
                    .Where(request.ToExp2())
                    .Includes(a => a.material_info)
                    .Includes(a => a.provider_info)
                    .Includes(a => a.house_info)
                    .ForEachAsync(it => { records.Add(it); }, 200);

            var list = new List<TimerInventoryDto>();
            var dic = await _iDictRedisManageImp.GetAllAsync();
            var groups = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpMaterialGroup>().ToListAsync();
            var enter_records = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpEnterInventory>().ToListAsync();
            var vehicle_kind = await SqlSugarHelper.DBClient(request.server_id).Queryable<MaintVehicleKind>().ToListAsync();
            foreach (var item in records)
            {
                if (item == null)
                {
                    continue;
                }

                var temp = _imapper.Map<ErpTimeInventory, TimerInventoryDto>(item);
                temp.house_name = item.house_info?.name;
                temp.material_code = item.material_info?.code;
                temp.material_name = item.material_info?.name;
                temp.specification = item.material_info?.specification;
                temp.brand = item.material_info?.brand;
                temp.vehicle_kind_ids = item.material_info?.vehicle_kind_ids;
                if (!string.IsNullOrEmpty(temp.vehicle_kind_ids))
                {
                    foreach (var item1 in temp.vehicle_kind_ids.Split(','))
                    {
                        temp.vehicle_kind_names += $"{vehicle_kind.Find(m => m.i_id.ToString() == item1)?.c_name},";
                    }
                    temp.vehicle_kind_names = string.IsNullOrEmpty(temp.vehicle_kind_names) ? "" : temp.vehicle_kind_names[0..^1];
                }
                if (item.material_info != null)
                {
                    temp.measure_unit_name = dic.Find(r => r.i_id == item.material_info?.measure_unit)?.c_name;
                    temp.group_id = (decimal)item.material_info?.main_id;
                    temp.group_name = groups.Find(r => r.id == temp.group_id)?.name;
                }
                temp.count = (int)item.count;
                temp.price = item.price;
                temp.total_price = item.total_price;
                temp.provider_name = item.provider_info?.name;

                temp.position = enter_records.Find(r => r.batch_no == item.batch_no)?.position;

                temp.cost_price = item.cost_price;
                temp.cost_total_price = item.cost_total_price;
                list.Add(temp);
            }

            total_count = (int)records.Sum(r => r.count);
            total_money = Math.Round(records.Sum(r => r.total_price), 2, MidpointRounding.AwayFromZero);
            return new Tuple<int, double, List<TimerInventoryDto>>(total_count, total_money, list);
        }

        public async Task<Tuple<int, List<TimerInventoryDetailDto>>> GetEnterDetails(TimerInventoryDetailRequest request)
        {
            RefAsync<int> total = 0;
            var records = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpEnterInventoryRecord, ErpEnterInventory>(
                (a, b) => new JoinQueryInfos(JoinType.Left, a.id == b.main_id))
                .Where((a, b) => a.state == 2 && a.house_id == request.house_id && b.material_id == request.material_id)
                .WhereIF(request.start != null, a => a.enter_date >= request.start && a.enter_date <= request.end)
                .Mapper(async a =>
                {
                    a.details = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpEnterInventory>()
                         .Where(m => m.main_id == a.id && m.material_id == request.material_id)
                         .Mapper(m => m.material_info, m => m.material_id).ToListAsync();
                })
                .OrderBy(a => a.enter_date)
                .ToListAsync();

            var list = new List<TimerInventoryDetailDto>();
            var dic = await _iDictRedisManageImp.GetAllAsync();
            foreach (var item in records)
            {
                var temp = new TimerInventoryDetailDto();
                temp.id = item.id;
                temp.relate_num = item.relate_num;
                temp.date = item.enter_date;
                temp.type = 1;
                temp.enter_leave_num = item.enter_num;
                temp.enter_leave_type = enter_type[item.enter_type];
                if (item.details != null && item.details.Count > 0)
                {
                    var detail = item.details[0];
                    temp.material_name = detail.material_info.name;
                    temp.material_code = detail.material_info.code;
                    temp.specification = detail.material_info.specification;
                    temp.measure_unit_name = dic.Find(r => r.i_id == detail.material_info.measure_unit)?.c_name;
                    temp.enter_num = detail.count;
                    temp.price = detail.price;
                    temp.total_price = detail.total_price;
                    temp.batch_no = detail.batch_no;
                }
                list.Add(temp);
            }

            return new Tuple<int, List<TimerInventoryDetailDto>>(total, list);
        }

        public async Task<Tuple<int, List<TimerInventoryDetailDto>>> GetLeaveDetails(TimerInventoryDetailRequest request)
        {
            RefAsync<int> total = 0;
            var records = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpLeaveInventoryRecord, ErpLeaveInventory>(
                (a, b) => new JoinQueryInfos(JoinType.Left, a.id == b.main_id))
                .Where((a, b) => a.state == 2 && a.house_id == request.house_id && b.material_id == request.material_id)
                .WhereIF(request.start != null, a => a.leave_date >= request.start && a.leave_date <= request.end)
                .Mapper(async a =>
                {
                    a.details = await _iErpLeaveInventoryImp.GetDetail(request.server_id, r => r.main_id == a.id);
                })
                .ToListAsync();
              
            var list = new List<TimerInventoryDetailDto>();
            var dic = await _iDictRedisManageImp.GetAllAsync();
            var vehicles = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpVehicleInfo>().ToListAsync();
            foreach (var item in records)
            {
                var temp = new TimerInventoryDetailDto();
                temp.id = item.id;
                temp.relate_num = item.relate_num;
                temp.date = item.leave_date;
                temp.type = 2;
                temp.enter_leave_num = item.leave_num;
                temp.enter_leave_type = leave_type[item.leave_type];
                temp.lp_num = item.lp_num;
                if (item.out_vehicle == 2)
                {
                    temp.v_nun = vehicles.Find(r => r.c_lincense_plate_number == item.lp_num)?.c_vehicle_number;
                }
                if (item.details != null && item.details.Count > 0)
                {
                    var detail = item.details.Find(r => r.material_id == request.material_id);
                    temp.material_name = detail.material_info.name;
                    temp.material_code = detail.material_info.code;
                    temp.specification = detail.material_info.specification;
                    temp.measure_unit_name = dic.Find(r => r.i_id == detail.material_info.measure_unit)?.c_name;
                    temp.leave_num = detail.count;
                    temp.price = detail.price;
                    temp.total_price = detail.total_price;
                    temp.batch_no = string.Join(',', detail.details.Where(r => r.main_id == detail.id).Select(r => r.batch_no));
                }
                list.Add(temp);
            }

            return new Tuple<int, List<TimerInventoryDetailDto>>(total, list);
        }

        public async Task<Tuple<int, List<TimerInventoryDto>>> GetGroupRecords(TimerInventoryRequest request)
        {
            return default;
        }

        public async Task<Tuple<int, double, List<TimerInventoryDto>>> GetGroupAllRecords(TimerInventoryRequest request)
        {
            return default;
        }

        private Dictionary<string, string> enter_type = new Dictionary<string, string>()
        {
            { "YBRK","一般入库"},
            { "CGRK","采购单入库"},
            { "DBRK","调拨入库"},
            { "PYRK","盘盈入库"},
            { "HCRK","红冲入库"},
            { "TLRK","退料入库"},
        };

        private Dictionary<string, string> leave_type = new Dictionary<string, string>()
        {
            { "YBCK","一般出库"},
            { "WXCK","维修出库"},
            { "DBCK","调拨出库"},
            { "PYCK","盘盈出库"},
            { "HCCK","红冲出库"},
        };
    }
}
