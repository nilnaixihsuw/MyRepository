﻿using ERPBll.RedisManage;
using ERPBll.RedisManage.Lines;
using ERPDal;
using ERPDal.Repository;
using ERPModel.ApiModel.MaterialManage.ReportManage;
using ERPModel.MaterialManage.InventoryManage;
using ERPModel.Vehicleinfomanage;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.MaterialManage.InventoryManage
{
    public class ErpLeaveInventoryImp : BaseBusiness<ErpLeaveInventory>, IErpLeaveInventoryImp
    {
        private readonly ILineRedisImp _iLineRedisImp;
        private readonly IVehicleRedisManageImp _iVehicleRedisManageImp;
        public ErpLeaveInventoryImp(
            ILineRedisImp iLineRedisImp,
            IVehicleRedisManageImp iVehicleRedisManageImp)
        {
            _iLineRedisImp = iLineRedisImp;
            _iVehicleRedisManageImp = iVehicleRedisManageImp;
        }

        public async Task<List<ErpLeaveInventory>> GetDetail(string server_id, Expression<Func<ErpLeaveInventory, bool>> expression)
        {
            return await SqlSugarHelper.DBClient(server_id).Queryable<ErpLeaveInventory>()
                         .WhereIF(expression != null, expression)
                         //.Mapper(m => m.details, m => m.details.First().main_id)
                         .Mapper(async m => m.details = await SqlSugarHelper.DBClient(server_id).Queryable<ErpLeaveInventoryDetail>()
                             .Where(r => r.main_id == m.id).ToListAsync())
                         .Mapper(m => m.material_info, m => m.material_id).ToListAsync();
        }

        public async Task<Tuple<int, decimal, double, List<RepairPartsDto>>> GetRepairParts(RepairPartsRequest request)
        {
            var list = new List<RepairPartsDto>();
            var vehicles = await _iVehicleRedisManageImp.GetAll1Async();
            var lines = await _iLineRedisImp.GetLineVehAsync();
            var records = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpLeaveInventoryRecord>()
                .WhereIF(request.start_date != null, r => r.leave_date >= request.start_date && r.leave_date <= request.end_date)
                .WhereIF(request.vehicle_ids != null && request.vehicle_ids.Count > 0,
                    r => vehicles.Where(m => request.vehicle_ids.Contains(m.id.Value)).Select(m => m.lp_num).Contains(r.lp_num) && r.out_vehicle == 2)
                .Where(r => r.leave_type == "WXCK" && r.state == 2).ToListAsync();

            var details = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpLeaveInventory>()
                .WhereIF(request.material_id > 0, r => r.material_id == request.material_id)
                .Where(r => records.Select(m => m.id).Contains(r.main_id))
                .Includes(r => r.material_info, m => m.measure_unit_info)
                .ToListAsync();
            var total_count = details.Sum(r => r.count);
            var total_money = details.Sum(r => r.total_price);
            int total = details.Count();
            if (request.page_index > 0)
            {
                details = details.Skip((request.page_index - 1) * request.page_size).Take(request.page_size).ToList();
            }

            foreach (var item in details)
            {
                var temp = new RepairPartsDto();
                temp.id = item.id;
                temp.material_id = item.material_id;
                temp.material_code = item.material_info?.code;
                temp.material_name = item.material_info?.name;
                temp.specification = item.material_info?.specification;
                temp.measure_unit_name = item.material_info?.measure_unit_info?.c_name;
                temp.count = item.count;
                temp.price = item.price;
                temp.total_price = item.total_price;

                var record = records.Find(m => m.id == item.main_id);
                temp.leave_date = record.leave_date.ToString("yyyy-MM-dd");
                temp.leave_num = record.leave_num;
                if (vehicles.Exists(m => m.lp_num == record.lp_num))
                {
                    var vehicle = vehicles.Find(m => m.lp_num == record.lp_num);
                    temp.vehicle_id = vehicle.id.Value;
                    temp.v_num = vehicle.v_num;
                    temp.lp_num = vehicle.lp_num;
                    temp.dept_name = vehicle.group_info?.c_name;
                    temp.line_id = vehicle.line_id;
                    temp.line_name = lines.Find(r => r.line_id == temp.line_id)?.line_name;
                }
                list.Add(temp);
            }
            return new Tuple<int, decimal, double, List<RepairPartsDto>>(total, total_count, total_money, list);
        }
    }
}
