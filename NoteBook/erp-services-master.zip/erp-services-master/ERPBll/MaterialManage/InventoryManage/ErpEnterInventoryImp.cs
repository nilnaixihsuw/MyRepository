﻿using ERPDal;
using ERPDal.Repository;
using ERPModel.MaterialManage.InventoryManage;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.MaterialManage.InventoryManage
{
    public class ErpEnterInventoryImp : BaseBusiness<ErpEnterInventory>, IErpEnterInventoryImp
    {
        public async Task<List<ErpEnterInventory>> GetData(string server_id, Expression<Func<ErpEnterInventory, bool>> expression)
        {
            return await SqlSugarHelper.DBClient(server_id).Queryable<ErpEnterInventory>()
                .WhereIF(expression != null, expression)
                .Mapper(r => r.material_info, r => r.material_id)
                .Mapper(r => r.provider_info, r => r.provider_id)
                .ToListAsync();
        }
    }
}
