﻿using AutoMapper;
using ERPBll.RedisManage.Dicts;
using ERPDal;
using ERPDal.Repository;
using ERPModel.ApiModel.MaterialManage.InventoryManage;
using ERPModel.MaterialManage.BaseinfoManage;
using ERPModel.MaterialManage.InventoryManage;
using ERPModel.Vehicleinfomanage;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.MaterialManage.InventoryManage
{
    public class ErpTimeInventoryBackupsImp : BaseBusiness<ErpTimeInventoryBackups>, IErpTimeInventoryBackupsImp
    {
        private readonly IMapper _imapper;
        private readonly IDictRedisManageImp _iDictRedisManageImp;
        private readonly IErpLeaveInventoryImp _iErpLeaveInventoryImp;
        public ErpTimeInventoryBackupsImp(IMapper imapper,
            IDictRedisManageImp iDictRedisManageImp,
            IErpLeaveInventoryImp iErpLeaveInventoryImp)
        {
            _imapper = imapper;
            _iDictRedisManageImp = iDictRedisManageImp;
            _iErpLeaveInventoryImp = iErpLeaveInventoryImp;
        }
        public async Task<List<ErpTimeInventoryBackups>> GetData(string server_id, DateTime backup_date, decimal house_id, decimal material_id)
        {
            var ids = new List<decimal>();
            var aa = await SqlSugarHelper.DBClient(server_id).Queryable<ErpTimeInventoryBackups>().ToListAsync();
            aa = aa.FindAll(r => r.backup_date.Value.ToString("yyyyMM") == backup_date.ToString("yyyyMM"));
            if (aa != null && aa.Count > 0)
            {
                ids.AddRange(aa.Select(r => r.id).ToList());
            }

            return await SqlSugarHelper.DBClient(server_id).Queryable<ErpTimeInventoryBackups>()
                .Where(r => ids.Contains(r.id))
                .Where(r => r.house_id == house_id && r.material_id == material_id)
                .Mapper(r => r.material_info, r => r.material_id)
                .Mapper(r => r.provider_info, r => r.provider_id)
                .Mapper(r => r.house_info, r => r.house_id)
                .OrderBy(r => r.batch_no)
                .ToListAsync();
        }

        public async Task<Tuple<int, int, double, List<TimerInventoryBackupDto>>> GetRecords(TimerInventoryBackupRequest request)
        {
            request.backup_date = request.backup_date == null ? DateTime.Now : request.backup_date;
            //var aa = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpTimeInventoryBackups>().ToListAsync();
            //aa = aa.FindAll(r => r.backup_date.Value.ToString("yyyyMM") == request.backup_date.Value.ToString("yyyyMM"));
            //var ids = aa.Select(r => r.id).ToList();

            RefAsync<int> totalCount = 0;
            var records = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpTimeInventoryBackups, ErpMaterialMain>((a, b) =>
                        new JoinQueryInfos(JoinType.Left, a.material_id == b.id))
                    .Where(request.ToExp1())
                    .Where(a => SqlFunc.Oracle_ToChar(a.backup_date.Value, "yyyy-MM") == SqlFunc.Oracle_ToChar(request.backup_date.Value, "yyyy-MM"))
                    .Mapper(a => a.material_info, a => a.material_id)
                    .Mapper(a => a.provider_info, a => a.provider_id)
                    .Mapper(a => a.house_info, a => a.house_id)
                    .ToPageListAsync(request.page_index, request.page_size, totalCount);

            var records1 = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpTimeInventoryBackups, ErpMaterialMain>((a, b) =>
                       new JoinQueryInfos(JoinType.Left, a.material_id == b.id))
                   .Where(request.ToExp1())
                   .Where(a => SqlFunc.Oracle_ToChar(a.backup_date.Value, "yyyy-MM") == SqlFunc.Oracle_ToChar(request.backup_date.Value, "yyyy-MM"))
                   .ToListAsync();
            int total_count = (int)records1.Sum(r => r.count);
            double total_money = Math.Round(records1.Sum(r => r.total_price), 2, MidpointRounding.AwayFromZero);

            var list = new List<TimerInventoryBackupDto>();
            var dic = await _iDictRedisManageImp.GetAllAsync();
            var groups = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpMaterialGroup>().ToListAsync();
            var enter_records = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpEnterInventory>().ToListAsync();
            var vehicle_kind = await SqlSugarHelper.DBClient(request.server_id).Queryable<MaintVehicleKind>().ToListAsync();
            foreach (var item in records)
            {
                var temp = _imapper.Map<ErpTimeInventoryBackups, TimerInventoryBackupDto>(item);
                temp.house_name = item.house_info?.name;
                if (item.material_info != null)
                {
                    temp.material_code = item.material_info.code;
                    temp.material_name = item.material_info.name;
                    temp.specification = item.material_info.specification;
                    temp.brand = item.material_info.brand;
                    temp.vehicle_kind_ids = item.material_info.vehicle_kind_ids;
                    temp.measure_unit_name = dic.Find(r => r.i_id == item.material_info.measure_unit)?.c_name;
                    temp.group_id = (decimal)item.material_info.main_id;
                    temp.group_name = groups.Find(r => r.id == temp.group_id)?.name;
                }

                if (!string.IsNullOrEmpty(temp.vehicle_kind_ids))
                {
                    foreach (var item1 in temp.vehicle_kind_ids.Split(','))
                    {
                        temp.vehicle_kind_names += $"{vehicle_kind.Find(m => m.i_id.ToString() == item1)?.c_name},";
                    }
                    temp.vehicle_kind_names = string.IsNullOrEmpty(temp.vehicle_kind_names) ? "" : temp.vehicle_kind_names[0..^1];
                }
                temp.count = (int)item.count;
                temp.price = item.price;
                temp.total_price = item.total_price;
                temp.provider_name = item.provider_info?.name;
                temp.position = enter_records.Find(r => r.batch_no == item.batch_no)?.position;
                list.Add(temp);
            }
            return new Tuple<int, int, double, List<TimerInventoryBackupDto>>(totalCount, total_count, total_money, list);
        }

        public async Task<Tuple<int, double, List<TimerInventoryBackupDto>>> GetAllRecords(TimerInventoryBackupRequest request)
        {
            request.backup_date = request.backup_date == null ? DateTime.Now : request.backup_date;
            RefAsync<int> totalCount = 0;
            int total_count = 0;
            double total_money = 0;
            var records = new List<ErpTimeInventoryBackups>();
            await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpTimeInventoryBackups, ErpMaterialMain>((a, b) =>
                      new JoinQueryInfos(JoinType.Left, a.material_id == b.id))
                  .Where(request.ToExp2())
                  .Where(a => SqlFunc.Oracle_ToChar(a.backup_date.Value, "yyyy-MM") == SqlFunc.Oracle_ToChar(request.backup_date.Value, "yyyy-MM"))
                  .Mapper(a => a.material_info, a => a.material_id)
                  .Mapper(a => a.provider_info, a => a.provider_id)
                  .Mapper(a => a.house_info, a => a.house_id)
                  .ForEachAsync(it => { records.Add(it); }, 200);

            var list = new List<TimerInventoryBackupDto>();
            var dic = await _iDictRedisManageImp.GetAllAsync();
            var groups = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpMaterialGroup>().ToListAsync();
            var enter_records = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpEnterInventory>().ToListAsync();
            var vehicle_kind = await SqlSugarHelper.DBClient(request.server_id).Queryable<MaintVehicleKind>().ToListAsync();
            foreach (var item in records)
            {
                if (item == null)
                {
                    continue;
                }

                var temp = _imapper.Map<ErpTimeInventoryBackups, TimerInventoryBackupDto>(item);
                temp.house_name = item.house_info?.name;
                temp.material_code = item.material_info?.code;
                temp.material_name = item.material_info?.name;
                temp.specification = item.material_info?.specification;
                temp.brand = item.material_info?.brand;
                temp.vehicle_kind_ids = item.material_info?.vehicle_kind_ids;
                if (!string.IsNullOrEmpty(temp.vehicle_kind_ids))
                {
                    foreach (var item1 in temp.vehicle_kind_ids.Split(','))
                    {
                        temp.vehicle_kind_names += $"{vehicle_kind.Find(m => m.i_id.ToString() == item1)?.c_name},";
                    }
                    temp.vehicle_kind_names = string.IsNullOrEmpty(temp.vehicle_kind_names) ? "" : temp.vehicle_kind_names[0..^1];
                }
                if (item.material_info != null)
                {
                    temp.measure_unit_name = dic.Find(r => r.i_id == item.material_info?.measure_unit)?.c_name;
                    temp.group_id = (decimal)item.material_info?.main_id;
                    temp.group_name = groups.Find(r => r.id == temp.group_id)?.name;
                }
                temp.count = (int)item.count;
                temp.price = item.price;
                temp.total_price = item.total_price;
                temp.provider_name = item.provider_info?.name;

                temp.position = enter_records.Find(r => r.batch_no == item.batch_no)?.position;

                temp.cost_price = item.cost_price;
                temp.cost_total_price = item.cost_total_price;
                list.Add(temp);
            }

            total_count = (int)records.Sum(r => r.count);
            total_money = Math.Round(records.Sum(r => r.total_price), 2, MidpointRounding.AwayFromZero);
            return new Tuple<int, double, List<TimerInventoryBackupDto>>(total_count, total_money, list);

        }

        public async Task<Tuple<int, List<TimerInventoryDetailDto>>> GetEnterDetails(TimerInventoryDetailRequest request)
        {
            RefAsync<int> total = 0;
            var records = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpEnterInventoryRecord, ErpEnterInventory>(
                (a, b) => new JoinQueryInfos(JoinType.Left, a.id == b.main_id))
                .Where((a, b) => a.state == 2 && a.house_id == request.house_id && b.material_id == request.material_id)
                .WhereIF(request.start != null, a => a.enter_date >= request.start && a.enter_date <= request.end)
                .Mapper(async a =>
                {
                    a.details = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpEnterInventory>()
                         .Where(m => m.main_id == a.id && m.material_id == request.material_id)
                         .Mapper(m => m.material_info, m => m.material_id).ToListAsync();
                })
                .OrderBy(a => a.enter_date)
                .ToListAsync();

            var list = new List<TimerInventoryDetailDto>();
            var dic = await _iDictRedisManageImp.GetAllAsync();
            foreach (var item in records)
            {
                var temp = new TimerInventoryDetailDto();
                temp.id = item.id;
                temp.relate_num = item.relate_num;
                temp.date = item.enter_date;
                temp.type = 1;
                temp.enter_leave_num = item.enter_num;
                temp.enter_leave_type = enter_type[item.enter_type];
                if (item.details != null && item.details.Count > 0)
                {
                    var detail = item.details[0];
                    temp.material_name = detail.material_info.name;
                    temp.material_code = detail.material_info.code;
                    temp.specification = detail.material_info.specification;
                    temp.measure_unit_name = dic.Find(r => r.i_id == detail.material_info.measure_unit)?.c_name;
                    temp.enter_num = detail.count;
                    temp.price = detail.price;
                    temp.total_price = detail.total_price;
                    temp.batch_no = detail.batch_no;
                }
                list.Add(temp);
            }

            return new Tuple<int, List<TimerInventoryDetailDto>>(total, list);
        }

        public async Task<Tuple<int, List<TimerInventoryDetailDto>>> GetLeaveDetails(TimerInventoryDetailRequest request)
        {
            RefAsync<int> total = 0;
            var records = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpLeaveInventoryRecord, ErpLeaveInventory>(
                (a, b) => new JoinQueryInfos(JoinType.Left, a.id == b.main_id))
                .Where((a, b) => a.state == 2 && a.house_id == request.house_id && b.material_id == request.material_id)
                .WhereIF(request.start != null, a => a.leave_date >= request.start && a.leave_date <= request.end)
                .Mapper(async a =>
                {
                    a.details = await _iErpLeaveInventoryImp.GetDetail(request.server_id, r => r.main_id == a.id);
                })
                .ToListAsync();

            var list = new List<TimerInventoryDetailDto>();
            var dic = await _iDictRedisManageImp.GetAllAsync();
            var vehicles = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpVehicleInfo>().ToListAsync();
            foreach (var item in records)
            {
                var temp = new TimerInventoryDetailDto();
                temp.id = item.id;
                temp.relate_num = item.relate_num;
                temp.date = item.leave_date;
                temp.type = 2;
                temp.enter_leave_num = item.leave_num;
                temp.enter_leave_type = leave_type[item.leave_type];
                temp.lp_num = item.lp_num;
                if (item.out_vehicle == 2)
                {
                    temp.v_nun = vehicles.Find(r => r.c_lincense_plate_number == item.lp_num)?.c_vehicle_number;
                }
                if (item.details != null && item.details.Count > 0)
                {
                    var detail = item.details.Find(r => r.material_id == request.material_id);
                    temp.material_name = detail.material_info.name;
                    temp.material_code = detail.material_info.code;
                    temp.specification = detail.material_info.specification;
                    temp.measure_unit_name = dic.Find(r => r.i_id == detail.material_info.measure_unit)?.c_name;
                    temp.leave_num = detail.count;
                    temp.price = detail.price;
                    temp.total_price = detail.total_price;
                    temp.batch_no = string.Join(',', detail.details.Where(r => r.main_id == detail.id).Select(r => r.batch_no));
                }
                list.Add(temp);
            }

            return new Tuple<int, List<TimerInventoryDetailDto>>(total, list);
        }

        private Dictionary<string, string> enter_type = new Dictionary<string, string>()
        {
            { "YBRK","一般入库"},
            { "CGRK","采购单入库"},
            { "DBRK","调拨入库"},
            { "PYRK","盘盈入库"},
            { "HCRK","红冲入库"},
            { "TLRK","退料入库"},
        };

        private Dictionary<string, string> leave_type = new Dictionary<string, string>()
        {
            { "YBCK","一般出库"},
            { "WXCK","维修出库"},
            { "DBCK","调拨出库"},
            { "PYCK","盘盈出库"},
            { "HCCK","红冲出库"},
        };
    }
}
