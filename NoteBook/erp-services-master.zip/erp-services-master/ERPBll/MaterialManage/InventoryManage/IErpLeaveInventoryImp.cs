﻿using ERPDal.Repository;
using ERPModel.ApiModel.MaterialManage.ReportManage;
using ERPModel.MaterialManage.InventoryManage;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.MaterialManage.InventoryManage
{
    public interface IErpLeaveInventoryImp : IBaseBusiness<ErpLeaveInventory>
    {
        Task<List<ErpLeaveInventory>> GetDetail(string server_id, Expression<Func<ErpLeaveInventory, bool>> expression);

        /// <summary>
        /// 获取维修配件出库明细
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        Task<Tuple<int, decimal, double, List<RepairPartsDto>>> GetRepairParts(RepairPartsRequest request);
    }
}
