﻿using ERPDal.Repository;
using ERPModel.MaterialManage.InventoryManage;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.MaterialManage.InventoryManage
{
    public interface IErpEnterInventoryImp : IBaseBusiness<ErpEnterInventory>
    {
        Task<List<ErpEnterInventory>> GetData(string server_id, Expression<Func<ErpEnterInventory, bool>> expression);
    }
}
