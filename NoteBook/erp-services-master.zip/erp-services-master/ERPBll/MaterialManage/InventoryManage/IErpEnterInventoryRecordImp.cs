﻿using ERPCore.ORM;
using ERPDal.Repository;
using ERPModel.ApiModel.MaterialManage.InventoryManage;
using ERPModel.MaterialManage.InventoryManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.MaterialManage.InventoryManage
{
    public interface IErpEnterInventoryRecordImp : IBaseBusiness<ErpEnterInventoryRecord>
    {
        Task<Tuple<int, List<EnterInventoryDto>>> GetRecords(EnterInventoryRequest request);

        Task<EditEnterInventoryDto> GetDetails(string server_id, decimal id, string enter_num);

        Task<int> ReviewRecord(string server_id, decimal id, int user_id, int result);

    }
}
