﻿using ERPDal.Repository;
using ERPModel.ApiModel.MaterialManage.InventoryManage;
using ERPModel.MaterialManage.InventoryManage;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.MaterialManage.InventoryManage
{
    public interface IErpTimeInventoryImp: IBaseBusiness<ErpTimeInventory>
    {
        Task<List<ErpTimeInventory>> GetData(string server_id, Expression<Func<ErpTimeInventory, bool>> expression);

        Task<Tuple<int, int, double, List<TimerInventoryDto>>> GetRecords(TimerInventoryRequest request);

        Task<Tuple<int,List<TimerInventoryDetailDto>>> GetEnterDetails(TimerInventoryDetailRequest request);

        Task<Tuple<int, List<TimerInventoryDetailDto>>> GetLeaveDetails(TimerInventoryDetailRequest request);

        Task<Tuple<int,double, List<TimerInventoryDto>>> GetAllRecords(TimerInventoryRequest request);

        Task<Tuple<int, List<TimerInventoryDto>>> GetGroupRecords(TimerInventoryRequest request);

        Task<Tuple<int, double, List<TimerInventoryDto>>> GetGroupAllRecords(TimerInventoryRequest request);
    }
}
