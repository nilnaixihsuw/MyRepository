﻿using ERPDal.Repository;
using ERPModel.ApiModel.MaterialManage.InventoryManage;
using ERPModel.MaterialManage.InventoryManage;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.MaterialManage.InventoryManage
{
    public interface IErpTimeInventoryBackupsImp : IBaseBusiness<ErpTimeInventoryBackups>
    {
        Task<List<ErpTimeInventoryBackups>> GetData(string server_id, DateTime backup_date, decimal house_id, decimal material_id);

        Task<Tuple<int, int, double, List<TimerInventoryBackupDto>>> GetRecords(TimerInventoryBackupRequest request);

        Task<Tuple<int,List<TimerInventoryDetailDto>>> GetEnterDetails(TimerInventoryDetailRequest request);

        Task<Tuple<int, List<TimerInventoryDetailDto>>> GetLeaveDetails(TimerInventoryDetailRequest request);

        Task<Tuple<int,double, List<TimerInventoryBackupDto>>> GetAllRecords(TimerInventoryBackupRequest request);

    }
}
