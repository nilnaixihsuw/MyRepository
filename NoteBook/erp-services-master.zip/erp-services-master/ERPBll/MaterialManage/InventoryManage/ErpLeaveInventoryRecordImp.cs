﻿using AutoMapper;
using ERPBll.RedisManage.Dicts;
using ERPBll.RedisManage.Lines;
using ERPCore.ORM;
using ERPDal;
using ERPDal.Repository;
using ERPModel.ApiModel.MaterialManage.InventoryManage;
using ERPModel.ApiModel.MaterialManage.ReportManage;
using ERPModel.MaterialManage.BaseinfoManage;
using ERPModel.MaterialManage.InventoryManage;
using ERPModel.UserManage;
using ERPModel.Vehicleinfomanage;
using Microsoft.Extensions.Options;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.MaterialManage.InventoryManage
{
    public class ErpLeaveInventoryRecordImp : BaseBusiness<ErpLeaveInventoryRecord>, IErpLeaveInventoryRecordImp
    {
        private readonly IMapper _imapper;
        private readonly IDictRedisManageImp _iDictRedisManageImp;
        private readonly IErpLeaveInventoryImp _iErpLeaveInventoryImp;
        private readonly ILineRedisImp _iLineRedisImp;
        public ErpLeaveInventoryRecordImp(IMapper imapper,
            IDictRedisManageImp iDictRedisManageImp,
            ILineRedisImp iLineRedisImp,
            IErpLeaveInventoryImp iErpLeaveInventoryImp) 
        {
            _imapper = imapper;
            _iDictRedisManageImp = iDictRedisManageImp;
            _iErpLeaveInventoryImp = iErpLeaveInventoryImp;
            _iLineRedisImp = iLineRedisImp;
        }

        public async Task<EditLeaveInventoryDto> GetDetails(string server_id, decimal id,string leave_num)
        {
            var record = await SqlSugarHelper.DBClient(server_id)
                             .Queryable<ErpLeaveInventoryRecord>()
                             .WhereIF(id > 0, a => a.id == id)
                             .WhereIF(!string.IsNullOrEmpty(leave_num), a => a.leave_num == leave_num)
                             .Mapper(a => a.house_info, a => a.house_id)
                             .Mapper(a => a.pick_depatment_info, a => a.pick_depatment_id)
                             .Mapper(async a =>
                             {
                                 a.details = await _iErpLeaveInventoryImp.GetDetail(server_id, r => r.main_id == a.id);
                             }).FirstAsync();

            if (record == null)
            {
                return default;
            }
            var persons = await SqlSugarHelper.DBClient(server_id).Queryable<SysPerson>().ToListAsync();
            var dic = await _iDictRedisManageImp.GetAllAsync();
            var result = _imapper.Map<ErpLeaveInventoryRecord, EditLeaveInventoryDto>(record);
            result.pick_name = persons.Find(r => r.i_id == result.pick_id)?.c_name;
            result.storage_name = persons.Find(r => r.i_id == result.storage_id)?.c_name;
            result.created_name = persons.Find(r => r.i_id == record.created_id)?.c_name;
            result.review_name = persons.Find(r => r.i_id == record.review_id)?.c_name;
            if (result.out_vehicle == 2)
            {
                var vehicle = await SqlSugarHelper.DBClient(server_id).Queryable<VehicleInfoNew>().Where(r => r.lp_num == result.lp_num).FirstAsync();
                result.v_num = vehicle?.v_num;
            }
            switch (record.state)
            {
                case 1:
                    result.state_name = "未审核";
                    break;
                case 2:
                    result.state_name = "已审核";
                    break;
                case 3:
                    result.state_name = "取消审核";
                    break;
            }
            result.house_name = record.house_info?.name;
            result.pick_depatment_name = record.pick_depatment_info?.c_name;
            result.use_way_name = dic.Find(r => r.i_id == record.use_way)?.c_name;
            result.line_name = _iLineRedisImp.GetLineVehAsync().Result.Find(r => r.line_id == result.line_id)?.line_name;
            result.details = new List<Leave_Detail>();
            var timer_records = await SqlSugarHelper.DBClient(server_id).Queryable<ErpTimeInventory>().ToListAsync();
            if (record.details != null && record.details.Count > 0)
            {
                foreach (var item in record.details)
                {
                    Leave_Detail detail = _imapper.Map<ErpLeaveInventory, Leave_Detail>(item);
                    detail.material_code = item.material_info?.code;
                    detail.material_name = item.material_info?.name;
                    detail.specification = item.material_info?.specification;
                    detail.brand = item.material_info?.brand;
                    detail.measure_unit_name = dic.Find(r => r.i_id == item.material_info?.measure_unit)?.c_name;
                    if (item.details != null && item.details.Count > 0)
                    {
                        detail.batch_no = string.Join(',', item.details.Select(r => r.batch_no).ToList());
                    }
                    detail.current_inventory = timer_records.Where(r => r.material_id == item.material_id && r.house_id == record.house_id).Sum(r => r.count);
                    detail.total_inventory = timer_records.Where(r => r.material_id == item.material_id).Sum(r => r.count);
                    //detail.provider_names = string.Join(',', item.details.Select(r => r.provider_info?.name).ToList());
                    result.details.Add(detail);
                }
            }
            return result;
        }

        public async Task<Tuple<int, List<LeaveInventoryDto>>> GetRecords(LeaveInventoryRequest request)
        {
            var ids = new List<decimal>();
            if (string.IsNullOrEmpty(request.material_name) && string.IsNullOrEmpty(request.material_code) && string.IsNullOrEmpty(request.specification))
            {
                ids = null;
            }
            else
            {
                var details = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpLeaveInventory, ErpMaterialMain>((a, b) =>
                        new JoinQueryInfos(JoinType.Left, a.material_id == b.id))
                    .WhereIF(!string.IsNullOrEmpty(request.material_name), (a, b) => b.name.Contains(request.material_name))
                    .WhereIF(!string.IsNullOrEmpty(request.material_code), (a, b) => b.code.Contains(request.material_code))
                    .WhereIF(!string.IsNullOrEmpty(request.specification), (a, b) => b.specification.Contains(request.specification))
                    .ToListAsync();
                ids = details == null || details.Count == 0 ? new List<decimal>() : details.Select(r => r.main_id).ToList();
            }
            var vehicles = await SqlSugarHelper.DBClient(request.server_id).Queryable<VehicleInfoNew>().ToListAsync();
            var lp_nums = new List<string>();
            if (request.vehicle_ids != null && request.vehicle_ids.Count > 0)
            {
                lp_nums = vehicles.Where(r => request.vehicle_ids.Contains(r.id)).Select(r => r.lp_num).ToList();
            }
            else
            { 
                lp_nums = null;
            }
            RefAsync<int> totalCount = 0;
            var records = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpLeaveInventoryRecord>()
                             .Where(request.ToExp())
                             .WhereIF(ids != null, a => ids.Contains(a.id))
                             .WhereIF(lp_nums != null, a => lp_nums.Contains(a.lp_num) && a.out_vehicle == 2)
                             .Mapper(a => a.pick_depatment_info, a => a.pick_depatment_id)
                             .Mapper(a => a.house_info, a => a.house_id)
                             //.OrderBy(r => r.leave_date, OrderByType.Desc)
                             .OrderBy(r => r.created_date, OrderByType.Desc).ToPageListAsync(request.page_index, request.page_size, totalCount);

            var details1 = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpLeaveInventory>()
               .Mapper(m => m.material_info, m => m.material_id).ToListAsync();
            var inventort_details = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpLeaveInventoryDetail>()
                .Mapper(m => m.provider_info, m => m.provider_id).ToListAsync();

            var list = new List<LeaveInventoryDto>();
            var persons = await SqlSugarHelper.DBClient(request.server_id).Queryable<SysPerson>().ToListAsync();
            var dic = await _iDictRedisManageImp.GetAllAsync();
            var line_vehicles = await _iLineRedisImp.GetLineVehAsync();          
            foreach (var item in records)
            {
                var temp = _imapper.Map<ErpLeaveInventoryRecord, LeaveInventoryDto>(item);
               
                temp.pick_name = persons.Find(r => r.i_id == item.pick_id)?.c_name;
                temp.storage_name = persons.Find(r => r.i_id == item.storage_id)?.c_name;
                temp.review_name = persons.Find(r => r.i_id == item.review_id)?.c_name;
                temp.house_name = item.house_info?.name;
                temp.pick_depatment_name = item.pick_depatment_info?.c_name;
                temp.use_way_name = dic.Find(r => r.i_id == item.use_way)?.c_name;
                temp.line_name = line_vehicles.Find(r => r.line_id == temp.line_id)?.line_name;
                temp.v_num = item.out_vehicle == 2 ? vehicles.Find(r => r.lp_num == temp.lp_num)?.v_num : "";
                switch (item.state)
                {
                    case 1:
                        temp.state_name = "未审核";
                        break;
                    case 2:
                        temp.state_name = "已审核";
                        break;
                    case 3:
                        temp.state_name = "取消审核";
                        break;
                }
                item.details = details1.FindAll(r => r.main_id == item.id);
                if (item.details != null && item.details.Count > 0)
                {
                    temp.material_type_num = item.details.Count;
                    temp.material_num = (int)item.details.Sum(r => r.count);
                    if (request.is_query && item.details.Count > 5)
                    {
                        item.details = item.details.OrderBy(r => r.id).Take(5).ToList();
                    }
                    foreach (var item1 in item.details)
                    {
                        var temp1 = Tools.DeepCopy(temp);
                        temp1.material_code = item1.material_info?.code;
                        temp1.material_name = item1.material_info?.name;
                        temp1.specification = item1.material_info?.specification;
                        temp1.measure_unit_name = dic.Find(r => r.i_id == item1.material_info?.measure_unit)?.c_name;
                        temp1.count = item1.count;
                        temp1.price = item1.price;
                        temp1.total_price = item1.total_price;
                        item1.details = inventort_details.FindAll(r => r.main_id == item1.id);
                        if (item1.details != null && item1.details.Count > 0)
                        {
                            temp1.batch_no = string.Join(',', item1.details.Select(r => r.batch_no).ToList());
                            temp1.provider_names = string.Join(',', item1.details.Select(r => r.provider_info?.name).Distinct().ToList());
                        }
                        list.Add(temp1);
                    }
                    continue;
                }
                list.Add(temp);
            }
            return new Tuple<int, List<LeaveInventoryDto>>(totalCount, list);
        }

        public async Task<int> ReviewRecord(string server_id, decimal id, int user_id, int result)
        {
            string[] columns = new string[] { "state", "review_id", "review_date" };
            var res = await SqlSugarHelper.DBClient(server_id).Updateable(new ErpLeaveInventoryRecord
            {
                state = result,
                review_id = user_id,
                review_date = DateTime.Now
            }).UpdateColumns(columns).ExecuteCommandAsync();
            return res;
        }

        public async Task<Tuple<int, List<TireDetailDto>>> GetTireDetail(TireDetatailRequest request)
        {
            var ids = new List<decimal>();
            var details = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpLeaveInventory, ErpMaterialMain>((a, b) =>
                         new JoinQueryInfos(JoinType.Left, a.material_id == b.id))
                     .Where((a, b) => request.material_ids.Contains(b.id))
                     .Mapper(a => a.material_info, a => a.material_id)
                     .ToListAsync();
            ids = details == null || details.Count == 0 ? new List<decimal>() : details.Select(r => r.main_id).ToList();

            var vehicles = await SqlSugarHelper.DBClient(request.server_id).Queryable<VehicleInfoNew>()
                .Mapper(r => r.group_info, r => r.group).ToListAsync();
            var lp_nums = new List<string>();
            if (request.vehicle_ids != null && request.vehicle_ids.Count > 0)
            {
                lp_nums = vehicles.Where(r => request.vehicle_ids.Contains(r.id)).Select(r => r.lp_num).ToList();
            }
            else
            {
                lp_nums = null;
            }
            RefAsync<int> totalCount = 0;
            var records = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpLeaveInventoryRecord>()
                           .Where(a => a.state == 2)
                           .Where(a => ids.Contains(a.id))
                           .WhereIF(lp_nums != null, a => lp_nums.Contains(a.lp_num) && a.out_vehicle == 2)
                           .WhereIF(request.leave_date_start != null, a => a.leave_date >= request.leave_date_start && a.leave_date <= request.leave_date_end)
                           .ToListAsync();

            var inventort_details = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpLeaveInventoryDetail>().ToListAsync();

            var list = new List<TireDetailDto>();
            var line_vehicles = await _iLineRedisImp.GetLineVehAsync();
            var enter_details = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpEnterInventory>().ToListAsync();
            foreach (var item in records)
            {
                var temp = new TireDetailDto();
                temp.leave_date = item.leave_date.ToString("yyyy-MM-dd");
                temp.line_id = item.line_id;
                temp.line_name = line_vehicles.Find(r => r.line_id == temp.line_id)?.line_name;
                temp.lp_num = item.lp_num;
                temp.v_num = item.out_vehicle == 2 ? vehicles.Find(r => r.lp_num == temp.lp_num)?.v_num : "";
                temp.group_name = item.out_vehicle == 2 ? vehicles.Find(r => r.lp_num == temp.lp_num)?.group_info?.c_name : "";

                var detail = details?.Find(r => r.main_id == item.id);
                temp.material_name = detail.material_info?.name;
                temp.count = detail.count;
                temp.price = detail.price;
                temp.total_price = detail.total_price;
                detail.details = inventort_details.FindAll(r => r.main_id == detail.id);
                if (detail.details != null && detail.details.Count > 0)
                {
                    //temp.cost_total_price = detail.details.Sum(r => r.total_price);
                    temp.cost_total_price = detail.details.Sum(r => r.cost_total_price);
                    if (temp.cost_total_price != null)
                    {
                        temp.cost_price = temp.cost_total_price / Convert.ToDouble(temp.count);
                        temp.gross_profit = temp.total_price - (double)temp.cost_total_price;
                    }
                }
                list.Add(temp);
            }
            return new Tuple<int, List<TireDetailDto>>(totalCount, list);
        }
    }
}
