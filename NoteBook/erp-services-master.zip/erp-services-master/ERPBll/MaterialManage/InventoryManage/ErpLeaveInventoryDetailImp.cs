﻿using ERPDal.Repository;
using ERPModel.MaterialManage.InventoryManage;
using System;
using System.Collections.Generic;
using System.Text;

namespace ERPBll.MaterialManage.InventoryManage
{
    public class ErpLeaveInventoryDetailImp : BaseBusiness<ErpLeaveInventoryDetail>, IErpLeaveInventoryDetailImp
    {

    }
}
