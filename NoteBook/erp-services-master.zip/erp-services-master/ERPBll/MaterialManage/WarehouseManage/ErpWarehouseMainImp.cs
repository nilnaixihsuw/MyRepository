﻿using ERPCore.ORM;
using ERPDal.MaterialManage.WarehouseManage;
using ERPModel.MaterialManage.WarehouseManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using ERPModel.ApiModel.MaterialManage.WarehouseManage;
using ERPDal;
using ERPModel.UserManage;

namespace ERPBll.MaterialManage.WarehouseManage
{
    public class ErpWarehouseMainImp : BusinessRespository<ErpWarehouseMain, IErpWarehouseMainDataImp>, IErpWarehouseMainImp
    {
        public IErpWarehousePersonImp _iErpWarehousePersonImp { get; set; }
        public ErpWarehouseMainImp(IErpWarehousePersonImp iErpWarehousePersonImp,
            IErpWarehouseMainDataImp dataImp): base(dataImp)
        {
            _iErpWarehousePersonImp = iErpWarehousePersonImp;
        }
        /// <summary>
        /// 获取租住部门树
        /// </summary>
        /// <param name="name"></param>
        /// <param name="server_id"></param>
        /// <returns></returns>
        public async Task<List<WHTree>> GetTree(string name, string server_id)
        {
            var exp = Expressionable.Create<ErpWarehouseMain>()
              .AndIF(!string.IsNullOrEmpty(name), r => r.name.Contains(name))
              .ToExpression();
            var houses = await _dataImp.List(server_id, exp);
            var depts = SqlSugarHelper.DBClient(server_id).Queryable<SysDepartment, SysDepFunction>((a, b) =>
              new JoinQueryInfos(JoinType.Left, a.i_id == b.i_main_id)).Where((a, b) => b.i_func_type == 3).ToList();
            var aa = SqlSugarHelper.DBClient(server_id).Queryable<SysDepPerson>().ToList();//组织层级结构
            var root_node = depts.Where(r => aa.Exists(m => m.i_child_id == r.i_id && m.i_group_id == 0)).Select(r => new WHTree
            {
                node_id = r.i_id,
                node_name = r.c_name,
                is_house = 0,
                children = houses.Where(m => m.deptment_id == r.i_id).Select(n => new WHTree
                {
                    node_id = n.id,
                    node_name = n.name,
                    is_house = 1,
                }).ToList()
            }).ToList();
            foreach (var item in root_node)
            {
                LoopToAppendChildren(depts, aa, houses, item);
            }
            return root_node;
        }

        public async Task<ErpWarehouseMain> GetRecord(decimal id, string server_id)
        {
            var record = await _dataImp.List(server_id, r => r.id == id);
            if (record == null || record.Count == 0) throw new Exception("记录查询有误，请检查后重试");
            var persons = SqlSugarHelper.DBClient(server_id).Queryable<SysPerson, SysPostInfo>((a, b) => new JoinQueryInfos(JoinType.Left, a.i_position_id == b.i_id))
                .Select((a, b) => new WHPerson
                {
                    id = a.i_id,
                    name = a.c_name,
                    work_id = a.c_worker_id,
                    positon = b.c_name
                }).ToList();
            var list = await _iErpWarehousePersonImp.List(server_id, r => r.main_id == record[0].id);
            record[0].persons = new List<WHPerson>();
            foreach (var item in list)
            {
                WHPerson temp = persons.Find(r => r.id == item.user_id);
                temp.is_operater = item.operater;
                record[0].persons.Add(temp);
            }
            return record[0];
        }

        /// <summary>
        /// 递归拼接树
        /// </summary>
        /// <param name="all"></param>
        /// <param name="curItem"></param>
        public void LoopToAppendChildren(List<SysDepartment> all,List<SysDepPerson> aa,List<ErpWarehouseMain> houses, WHTree curItem)
        {
            var ids = aa.Where(r => r.i_group_id == curItem.node_id).Select(r => r.i_child_id).ToList();
            var subItems = all.Where(ee => ids.Contains(ee.i_id)).ToList();
            if (subItems.Count > 0)
            {
                //subItems.Sort(delegate (DeptTreeModel s1, DeptTreeModel s2)
                //{
                //    return s1.sort.CompareTo(s2.sort);
                //});
                if (curItem.children == null)
                {
                    curItem.children = new List<WHTree>();
                }
                curItem.children.AddRange(subItems.Select(r => new WHTree
                {
                    node_id = r.i_id,
                    node_name = r.c_name,
                    is_house = 0,
                    children = houses.Where(m => m.deptment_id == r.i_id).Select(n => new WHTree
                    {
                        node_id = n.id,
                        node_name = n.name,
                        is_house = 1,
                    }).ToList()
                }));

                foreach (var subItem in curItem.children)
                {
                    LoopToAppendChildren(all,aa,houses, subItem);
                }
            }
        }
    }
}