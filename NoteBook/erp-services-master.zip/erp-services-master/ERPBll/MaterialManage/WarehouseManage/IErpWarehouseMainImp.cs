﻿using ERPCore.ORM;
using ERPModel.ApiModel.MaterialManage.WarehouseManage;
using ERPModel.MaterialManage.WarehouseManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.MaterialManage.WarehouseManage
{
    public interface IErpWarehouseMainImp : IBusinessRepository<ErpWarehouseMain>
    {
        Task<List<WHTree>> GetTree(string name, string server_id);
        Task<ErpWarehouseMain> GetRecord(decimal id, string server_id);
    }
}