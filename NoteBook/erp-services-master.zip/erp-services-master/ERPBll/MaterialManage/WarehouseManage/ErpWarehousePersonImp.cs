﻿using ERPCore.ORM;
using ERPDal.MaterialManage.WarehouseManage;
using ERPModel.MaterialManage.WarehouseManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;

namespace ERPBll.MaterialManage.WarehouseManage
{
    public class ErpWarehousePersonImp : BusinessRespository<ErpWarehousePerson, IErpWarehousePersonDataImp>, IErpWarehousePersonImp
    {
        public ErpWarehousePersonImp(IErpWarehousePersonDataImp dataImp): base(dataImp)
        {

        }
    }
}