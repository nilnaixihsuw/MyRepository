﻿using ERPCore.ORM;
using ERPModel.MaterialManage.WarehouseManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.MaterialManage.WarehouseManage
{
    public interface IErpWarehousePersonImp : IBusinessRepository<ErpWarehousePerson>
    {
    }
}