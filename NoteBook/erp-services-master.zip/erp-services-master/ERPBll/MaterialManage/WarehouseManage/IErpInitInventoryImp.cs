﻿using ERPCore.ORM;
using ERPDal.Repository;
using ERPModel.ApiModel.MaterialManage.WarehouseManage;
using ERPModel.MaterialManage.WarehouseManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.MaterialManage.WarehouseManage
{
    public interface IErpInitInventoryImp : IBaseBusiness<ErpInitInventory>
    {
        Task<Tuple<int, List<HouseInitDto>>> GetRecord(HouseInitRequest request);

        Task Import(List<HouseInitDto> list, decimal id, decimal user_id, string type, string server_id);
    }
}