﻿using ERPCore.ORM;
using ERPDal.MaterialManage.WarehouseManage;
using ERPModel.MaterialManage.WarehouseManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using ERPModel.ApiModel.MaterialManage.WarehouseManage;
using ERPDal;
using ERPModel.EnterpriseManage.RentManage;
using ERPModel.MaterialManage.BaseinfoManage;
using AutoMapper;
using ERPBll.Vehicleinfomanage;
using ERPBll.RedisManage.Dicts;
using ERPBll.WorkPlace;
using System.Text;
using ERPModel.Workplace;
using ERPModel.SystemManage;
using ERPCore.Entity;
using Yitter.IdGenerator;
using ERPDal.Repository;

namespace ERPBll.MaterialManage.WarehouseManage
{
    public class ErpInitInventoryImp : BaseBusiness<ErpInitInventory>, IErpInitInventoryImp
    {
        private readonly IMapper _imapper;
        private readonly IDictRedisManageImp _iDictRedisManageImp;
        private readonly IErpImportRecordImp _iErpImportRecordImp;
        private readonly IErpMessageMainImp _iErpMessageMainImp;
        public ErpInitInventoryImp(IMapper imapper,
            IDictRedisManageImp iDictRedisManageImp,
            IErpImportRecordImp iErpImportRecordImp,
            IErpMessageMainImp iErpMessageMainImp,
            IErpInitInventoryDataImp dataImp) 
        {
            _imapper = imapper;
            _iDictRedisManageImp = iDictRedisManageImp;
            _iErpImportRecordImp = iErpImportRecordImp;
            _iErpMessageMainImp = iErpMessageMainImp;
        }

        public async Task<Tuple<int, List<HouseInitDto>>> GetRecord(HouseInitRequest request)
        {
            RefAsync<int> totalCount = 0;
            var records = new List<ErpInitInventory>();
            records = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpInitInventory, ErpMaterialMain>((a, b) =>
                            new JoinQueryInfos(JoinType.Left, a.material_id == b.id))
                 .Where(request.ToExp1())
                 .Mapper(a => a.house_info, a => a.house_id)
                 .Mapper(a => a.material_info, a => a.material_id)
                 .Mapper(a => a.provider_info, a => a.provider_id)
                .ToPageListAsync(request.page_index, request.page_size, totalCount);

            var dic = await _iDictRedisManageImp.GetAllAsync();
            var vehicle_kind = VehicleKindBll.GetAllCKind1(request.server_id);
            var list = new List<HouseInitDto>();
            foreach (var item in records)
            {
                HouseInitDto temp = _imapper.Map<ErpInitInventory, HouseInitDto>(item);
                temp.house_name = item.house_info?.name;
                temp.code = item.material_info?.code;
                temp.name = item.material_info?.name;
                temp.specification = item.material_info?.specification;
                temp.measure_unit = item.material_info?.measure_unit;
                temp.provider_name = item.provider_info?.name;
                temp.measure_unit_name = dic.Find(r => r.i_id == temp.measure_unit)?.c_name;
                temp.brand = item.material_info?.brand;
                temp.vehicle_kind_ids = item.material_info?.vehicle_kind_ids;
                if (!string.IsNullOrEmpty(temp.vehicle_kind_ids))
                {
                    foreach (var item1 in temp.vehicle_kind_ids.Split(','))
                    {
                        temp.vehicle_kind_names += $"{vehicle_kind.FirstOrDefault(m => m.id == item1)?.name},";
                    }
                    temp.vehicle_kind_names = string.IsNullOrEmpty(temp.vehicle_kind_names) ? "" : temp.vehicle_kind_names[0..^1];
                }
                list.Add(temp);
            }
            return new Tuple<int, List<HouseInitDto>>(totalCount, list);
        }

        public async Task Import(List<HouseInitDto> list, decimal id, decimal user_id, string type, string server_id)
        {
            int index = 1;
            var materials = await SqlSugarHelper.DBClient(server_id).Queryable<ErpMaterialMain>().ToListAsync();
            var houses = await SqlSugarHelper.DBClient(server_id).Queryable<ErpWarehouseMain>().ToListAsync();
            var providers = await SqlSugarHelper.DBClient(server_id).Queryable<ErpProviderMain>().ToListAsync();
            var aa = await SqlSugarHelper.DBClient(server_id).Queryable<ErpInitInventory>().ToListAsync();
            bool is_valid = true;
            List<string> errors = new List<string>();
            var record = await _iErpImportRecordImp.Get(server_id, r => r.id == id);//导入过程记录
            double schedule = 0.1;
            foreach (var item in list)
            {
                index++;
                if (string.IsNullOrEmpty(item.house_name))
                {
                    errors.Add($"第{index}行仓库为空，数据非法，请检查后重试");
                    is_valid = false;
                }
                else
                {
                    if (!houses.Exists(r => r.name == item.house_name))
                    {
                        errors.Add($"第{index}行仓库不存在，请检查后重试");
                        is_valid = false;
                    }
                }
                if (string.IsNullOrEmpty(item.code))
                {
                    errors.Add($"第{index}行物料编号为空，数据非法，请检查后重试");
                    is_valid = false;
                }
                else
                {
                    if (!materials.Exists(r => r.code == item.code))
                    {
                        errors.Add($"第{index}行物料编号不存在，请检查后重试");
                        is_valid = false;
                    }
                }
                if (item.price == null)
                {
                    errors.Add($"第{index}行销售单价为空，数据非法，请检查后重试");
                    is_valid = false;
                }
                if (item.count == null)
                {
                    errors.Add($"第{index}行数量为空，数据非法，请检查后重试");
                    is_valid = false;
                }
                if (is_valid)
                {
                    item.material_id = (decimal)materials.Find(r => r.code == item.code).id;
                    item.house_id = (decimal)houses.Find(r => r.name == item.house_name).id;
                    item.provider_id = string.IsNullOrEmpty(item.provider_name) ? null : providers.Find(r => r.name == item.provider_name)?.id;
                    item.total_price = Math.Round(Convert.ToDouble(item.price * (int)item.count), 2, MidpointRounding.AwayFromZero);
                    item.cost_total_price = Math.Round(Convert.ToDouble(item.cost_price * (int)item.count), 2, MidpointRounding.AwayFromZero);
                }

                is_valid = true;
                if (record != null && (double)index / (double)list.Count >= schedule)
                {
                    record.state_child = Encoding.UTF8.GetBytes($"{index}/{list.Count}已验证");
                    await _iErpImportRecordImp.Update(server_id, record);
                    schedule += 0.1;
                }
            }

            ErpMessageMain context = new ErpMessageMain();
            context.id = Tools.GetSeqCommonID(server_id);
            context.created_id = user_id;
            context.type = 5;
            context.object_id = id.ToString();
            context.model = (int)MessageModelDic.导入导出消息;
            var menus = await SqlSugarHelper.DBClient(server_id).Queryable<SysMenuMain>().ToListAsync();
            string menu_name = string.Empty;
            Tools.LoopToAppendName(menus, record.menu_code, ref menu_name);
            if (errors.Count > 0)
            {
                record.finish_time = DateTime.Now;
                record.state = 3;
                record.state_child = Encoding.UTF8.GetBytes(string.Join('\t', errors));
                await _iErpImportRecordImp.Update(server_id, record);

                context.title = $"导入导出提醒<br/>您有一个文件倒入失败<br/>功能为{menu_name}<br/>失败原因：{errors[0]}等，具体见详情";
                ClientInformation client = new ClientInformation() { i_id = user_id };
                await _iErpMessageMainImp.AddErpMessageMain(server_id, context, client);
            }
            else
            {
                var records = _imapper.Map<List<HouseInitDto>, List<ErpInitInventory>>(list);
                if (type == "0")
                {
                    var inList = records.Where(r => !aa.Exists(m => m.house_id == r.house_id && m.material_id == r.material_id)).ToList();
                    inList.ForEach(r =>
                    {
                        r.id = YitIdHelper.NextId();
                        r.created_id = user_id;
                        r.created_date = DateTime.Now;
                    });
                    await SqlSugarHelper.DBClient(server_id).Fastest<ErpInitInventory>().BulkCopyAsync(inList);
                }
                if (type == "1")
                {
                    var updateList = records.Where(r => aa.Exists(m => m.house_id == r.house_id && m.material_id == r.material_id)).ToList();
                    updateList.ForEach(r =>
                    {
                        var record = aa.Find(m => m.house_id == r.house_id && m.material_id == r.material_id);
                        r.id = record.id;
                        r.created_id = record.created_id;
                        r.created_date = record.created_date;
                        r.update_id = user_id;
                        r.update_date = DateTime.Now;
                    });
                    await SqlSugarHelper.DBClient(server_id).Fastest<ErpInitInventory>().BulkUpdateAsync(updateList);

                    var inList = records.Where(r => !aa.Exists(m => m.house_id == r.house_id && m.material_id == r.material_id)).ToList();
                    inList.ForEach(r =>
                    {
                        r.id = YitIdHelper.NextId();
                        r.created_id = user_id;
                        r.created_date = DateTime.Now;
                    });
                    await SqlSugarHelper.DBClient(server_id).Fastest<ErpInitInventory>().BulkCopyAsync(inList);
                }

                var timeSpan = record.finish_time - record.start_time;
                var deal_time = $"{timeSpan.Value.Hours}:{timeSpan.Value.Minutes}:{timeSpan.Value.Seconds}";
                context.title = $"导入导出提醒<br/>您有一个文件导入成功<br/>功能为{menu_name}<br/>共计用时{deal_time}";
                ClientInformation client = new ClientInformation() { i_id = user_id };
                await _iErpMessageMainImp.AddErpMessageMain(server_id, context, client);
            }
        }
    }
}