﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPModel.ApiModel.EnterpriseManage.PartyConstructionManage;
using ERPModel.PartyConstructionManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.PartyConstructionManage
{
    public interface IErpPartyClassImp : IBusinessRepository<ErpPartyClass>
    {
        Task<Tuple<List<ErpPartyClass>,int>> QueryPartyClassPageList(string server_id, ErpPartyClassRequest request, string v);
        Task<List<ErpPartyClass>> QueryPartyClassList(string server_id, ErpPartyClassRequest request, string v);
        Task<bool> AddPartyClass(string server_id, ErpPartyClass context, ClientInformation client);
        Task<bool> BatchDelete(string server_id, List<decimal> context);
    }
}