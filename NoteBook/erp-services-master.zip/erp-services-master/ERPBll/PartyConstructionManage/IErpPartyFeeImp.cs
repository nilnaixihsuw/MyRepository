﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPModel.ApiModel.EnterpriseManage.PartyConstructionManage;
using ERPModel.PartyConstructionManage;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ERPBll.PartyConstructionManage
{
    public interface IErpPartyFeeImp : IBusinessRepository<ErpPartyFee>
    {
        Task<bool> AddPartyFee(string server_id, ErpPartyFee context, ClientInformation client);
        Task<Tuple<List<ErpPartyFee>,int>> QueryPartyFeePageList(string server_id, ErpPartyFeeRequest request, string v);
        Task<List<ErpPartyFee>> QueryPartyFeeList(string server_id, ErpPartyFeeRequest request, string v);
        Task<bool> BatchDelete(string server_id, List<decimal> context);
        Task<bool> Import(string server_id, IFormFile file, int type, ClientInformation client);
    }
}