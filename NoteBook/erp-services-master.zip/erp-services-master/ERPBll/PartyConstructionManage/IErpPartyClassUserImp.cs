﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPModel.ApiModel.EnterpriseManage.PartyConstructionManage;
using ERPModel.PartyConstructionManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.PartyConstructionManage
{
    public interface IErpPartyClassUserImp : IBusinessRepository<ErpPartyClassUser>
    {
        Task<Tuple<List<ErpPartyClassUser>,int>> QueryPartyClassUserPageList(string server_id, ErpPartyClassUserRequest request, string v);
        Task<List<ErpPartyClassUser>> QueryPartyClassUserList(string server_id, ErpPartyClassUserRequest request, string v);
        Task<bool> AddPartyClassUser(string server_id, ErpPartyClassUser context, ClientInformation client);
        Task<bool> BatchDelete(string server_id, List<decimal> context);
    }
}