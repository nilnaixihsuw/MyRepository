﻿using ERPCore.ORM;
using ERPDal.PartyConstructionManage;
using ERPModel.PartyConstructionManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using ERPModel.ApiModel.EnterpriseManage.PartyConstructionManage;
using ERPCore.Entity;

namespace ERPBll.PartyConstructionManage
{
    public class ErpPartyClassUserImp : BusinessRespository<ErpPartyClassUser, IErpPartyClassUserDataImp>, IErpPartyClassUserImp
    {
        public ErpPartyClassUserImp(IErpPartyClassUserDataImp dataImp): base(dataImp)
        {

        }

        public async Task<bool> AddPartyClassUser(string server_id, ErpPartyClassUser context, ClientInformation client)
        {
            if (context.id > 0)
            {
                context.update_date = DateTime.Now;
                context.update_id = client.i_id;
                var old = await Get(server_id, context.id);
                context.created_date = old.created_date;
                context.created_id = old.created_id;
                return await _dataImp.Update(server_id, context);
            }
            else
            {
                context.created_date = DateTime.Now;
                context.created_id = client.i_id;
                return await _dataImp.Insert(server_id, context);
            }
        }

        public async Task<bool> BatchDelete(string server_id, List<decimal> context)
        {
            var list = await _dataImp.List(server_id, it => SqlFunc.ContainsArray(context, it.id));
            return await _dataImp.Deletetable(server_id, list);
        }

        public async Task<List<ErpPartyClassUser>> QueryPartyClassUserList(string server_id, ErpPartyClassUserRequest request, string v)
        {
            return await ExtensionList(server_id, request.ToExp(), v, request.orderby);
        }

        public async Task<Tuple<List<ErpPartyClassUser>, int>> QueryPartyClassUserPageList(string server_id, ErpPartyClassUserRequest request, string v)
        {
            return await ExtensionList(server_id, request.ToExp(), v, request.page_size, request.page_index, request.orderby);
        }
    }
}