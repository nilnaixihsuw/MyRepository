﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPModel.PartyConstructionManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.PartyConstructionManage
{
    public interface IErpPartyDevelopStepImp : IBusinessRepository<ErpPartyDevelopStep>
    {
        Task<bool> AddErpPartyDevelopStep(string server_id, ErpPartyDevelopStep context, ClientInformation client);
        Task<Tuple<List<ErpPartyDevelopStep>,int>> QueryErpPartyDevelopStepPageList(string server_id, BaseRequest<ErpPartyDevelopStep> request, string v);
        Task<List<ErpPartyDevelopStep>> QueryErpPartyDevelopStepList(string server_id, BaseRequest<ErpPartyDevelopStep> request, string v);
        Task<bool> BatchDelete(string server_id, List<decimal> context);
    }
}