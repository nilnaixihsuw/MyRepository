﻿using ERPCore.ORM;
using ERPDal.PartyConstructionManage;
using ERPModel.PartyConstructionManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using ERPCore.Entity;
using ERPModel.ApiModel.EnterpriseManage.PartyConstructionManage;
using System.Linq.Expressions;
using Microsoft.AspNetCore.Http;
using ERPCore;
using System.IO;
using ERPCore.Extensions;

namespace ERPBll.PartyConstructionManage
{
    public class ErpPartyFeeImp : BusinessRespository<ErpPartyFee, IErpPartyFeeDataImp>, IErpPartyFeeImp
    {
        private readonly IErpPartyOrganDataImp _iErpPartyOrganDataImp;
        private readonly IErpPartyUserDataImp _iErpPartyUserDataImp;
        private readonly IErpPartyFeeSetDataImp _iErpPartyFeeSetDataImp;

        public ErpPartyFeeImp(
            IErpPartyOrganDataImp iErpPartyOrganDataImp,
            IErpPartyFeeSetDataImp iErpPartyFeeSetDataImp,
            IErpPartyUserDataImp iErpPartyUserDataImp,
            IErpPartyFeeDataImp dataImp) : base(dataImp)
        {
            _iErpPartyOrganDataImp = iErpPartyOrganDataImp;
            _iErpPartyUserDataImp = iErpPartyUserDataImp;
            _iErpPartyFeeSetDataImp = iErpPartyFeeSetDataImp;
        }

        public async Task<bool> AddPartyFee(string server_id, ErpPartyFee context, ClientInformation client)
        {
            if (context.id > 0)
            {
                context.update_date = DateTime.Now;
                context.update_id = client.i_id;
                var old = await Get(server_id, context.id);
                context.created_date = old.created_date;
                context.created_id = old.created_id;
                return await _dataImp.Update(server_id, context);
            }
            else
            {
                context.created_date = DateTime.Now;
                context.created_id = client.i_id;
                return await _dataImp.Insert(server_id, context);
            }
        }

        public async Task<List<ErpPartyFee>> QueryPartyFeeList(string server_id, ErpPartyFeeRequest request, string v)
        {
            var exp = await GetExp(request);
            return await ExtensionList(server_id, request.ToExp(exp), v, request.orderby);
        }

        private async Task<List<Expression<Func<ErpPartyFee, bool>>>> GetExp(ErpPartyFeeRequest request)
        {
            var r = new List<Expression<Func<ErpPartyFee, bool>>>();

            if (!string.IsNullOrEmpty(request.organ_name))
            {
                var organs = await _iErpPartyOrganDataImp.List(request.server_id, it => it.name.Contains(request.organ_name));
                if (organs.Count > 0)
                {
                    var orgIds = organs.Select(it => it.id).ToList();
                    var users = await _iErpPartyUserDataImp.List(request.server_id, it => SqlFunc.ContainsArray(orgIds, it.organ_id));
                    if (users.Count > 0)
                    {
                        r.Add(it => SqlFunc.ContainsArray(users.Select(it => it.id).ToList(), it.party_user_id));
                    }
                    else
                    {
                        r.Add(it => false);
                    }
                }
                else
                {
                    r.Add(it => false);
                }
            }


            return r;
        }

        public async Task<Tuple<List<ErpPartyFee>, int>> QueryPartyFeePageList(string server_id, ErpPartyFeeRequest request, string v)
        {
            var exp = await GetExp(request);
            return await ExtensionList(server_id, request.ToExp(exp), v, request.page_size, request.page_index, request.orderby);
        }

        public async Task<bool> BatchDelete(string server_id, List<decimal> context)
        {
            var list = await _dataImp.List(server_id, it => SqlFunc.ContainsArray(context, it.id));
            return await _dataImp.Deletetable(server_id, list);
        }

        public async Task<bool> Import(string server_id, IFormFile file, int type, ClientInformation client)
        {
            var title = new Dictionary<string, string>()
            {
               { "姓名", "ex_name"},
               { "应发工资", "should_wage"},
               { "实发工资", "wage"},
               { "缴纳基数","base_pay"},
               { "本次缴纳月份", "month"},
               { "备注", "remark"},
            };

            var result = new byte[] { };
            //文件内容是否为空
            if (file.Length == 0)
                throw new Exception("文件不能为空");

            //文件后缀
            string filename = file.FileName;
            var ext = filename.Substring(filename.LastIndexOf("."), filename.Length - filename.LastIndexOf("."));

            // 判断后缀
            if (ext != ".xlsx" && ext != ".xls")
            {
                throw new Exception("请上传Excel文件！");
            }

            using (var ms = new MemoryStream())
            {
                file.CopyTo(ms);
                ms.Position = 0;
                result = ms.ToArray();
            }
            var dt = ExcelImportHelper.ReadBytesToDataTable(result, title);
            var list = dt.ToDataList<ErpPartyFee>();
            var upList = new List<ErpPartyFee>();
            var inList = new List<ErpPartyFee>();

            //检查空值
            if (list.Exists(it => string.IsNullOrEmpty(it.ex_name)))
            {
                throw new Exception("存在姓名为空记录！");
            }
            if (list.Exists(it => string.IsNullOrEmpty(it.month)))
            {
                throw new Exception("存在缴纳月份为空记录！");
            }
            if (list.Exists(it => it.wage == null))
            {
                throw new Exception("存在实发工资为空记录！");
            }
            if (list.Exists(it => it.month == null))
            {
                throw new Exception("存在本次缴纳月份为空记录！");
            }

            //党员
            var partyUsers = await _iErpPartyUserDataImp.List(server_id, it => SqlFunc.ContainsArray(list.Select(it => it.ex_name).ToList(), it.name));
            //党费比例
            var feeLists = await _iErpPartyFeeSetDataImp.List(server_id, it => true);

            //补充list其他的值
            list.ForEach(item =>
            {
                if (partyUsers.Count == 0 || !partyUsers.Exists(it => it.name == item.ex_name))
                {
                    throw new Exception("系统中不存在的人员!");
                }
                else
                {
                    item.party_user_id = partyUsers.Find(it => it.name == item.ex_name).id;
                }
                if (feeLists.Count == 0 || !feeLists.Exists(it => (it.min <= item.base_pay && it.max > item.base_pay) || (it.min <= item.base_pay && it.max == -1)))
                {
                    throw new Exception("系统中不存在比例设置!");
                }
                else
                {
                    item.ratio = feeLists.Find(it => (it.min <= item.base_pay && it.max > item.base_pay) || (it.min <= item.base_pay && it.max == -1)).value;
                }
                item.should_fee = Math.Round(((item.base_pay * item.ratio) / 100).Value, 2);
                item.actual_fee = item.should_fee;
                item.standard = 1;
                item.fee_type = "标准缴纳";
                item.submit_date = new DateTime(DateTime.Now.Year, Convert.ToInt16(item.month.Substring(item.month.Length - 2)), 1);
                item.created_date = DateTime.Now;
                item.created_id = client.i_id;
            });
            //覆盖
            if (type == 1)
            {
                var existsRecord = await _dataImp.List(server_id, it => true);
                list.ForEach(item =>
                {
                    if (existsRecord.Exists(it => it.party_user_id == item.party_user_id && it.month == item.month))
                    {
                        var e = existsRecord.Find(it => it.party_user_id == item.party_user_id && it.month == item.month);
                        item.id = e.id;
                        upList.Add(item);
                    }
                    else
                    {
                        inList.Add(item);
                    }
                });
                list = inList;
            }
            //保持原数据
            if (type == 0)
            {

            }

            return await _dataImp.Import(server_id, list, upList);
        }
    }
}