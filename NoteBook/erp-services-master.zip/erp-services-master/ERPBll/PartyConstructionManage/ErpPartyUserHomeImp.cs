﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPDal.PartyConstructionManage;
using ERPModel.PartyConstructionManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using System.Linq.Expressions;

namespace ERPBll.PartyConstructionManage
{
    public class ErpPartyUserHomeImp : BusinessRespository<ErpPartyUserHome, IErpPartyUserHomeDataImp>, IErpPartyUserHomeImp
    {
        public ErpPartyUserHomeImp(IErpPartyUserHomeDataImp dataImp): base(dataImp)
        {

        }

        public async Task<bool> AddErpPartyUserHome(string server_id, ErpPartyUserHome context, ClientInformation client)
        {
            if (context.id > 0)
            {
                context.update_date = DateTime.Now;
                context.update_id = client.i_id;
                var old = await Get(server_id, context.id);
                context.created_date = old.created_date;
                context.created_id = old.created_id;
                return await _dataImp.Update(server_id, context);
            }
            else
            {
                context.created_date = DateTime.Now;
                context.created_id = client.i_id;
                return await _dataImp.Insert(server_id, context);
            }
        }

        public async Task<Tuple<List<ErpPartyUserHome>,int>> QueryErpPartyUserHomePageList(string server_id, BaseRequest<ErpPartyUserHome> request, string v)
        {
            var exp = await GetExp(request);
            return await ExtensionList(server_id, request.ToExp(exp), v, request.page_size, request.page_index, request.orderby);
        }

        public async Task<List<ErpPartyUserHome>> QueryErpPartyUserHomeList(string server_id, BaseRequest<ErpPartyUserHome> request, string v)
        {
            var exp = await GetExp(request);
            return await ExtensionList(server_id, request.ToExp(exp), v, request.orderby);
        }

        public async Task<bool> BatchDelete(string server_id, List<decimal> context)
        {
            var list = await _dataImp.List(server_id, it => SqlFunc.ContainsArray(context, it.id));
            return await _dataImp.Deletetable(server_id, list);
        }

        private async Task<List<Expression<Func<ErpPartyUserHome, bool>>>> GetExp(BaseRequest<ErpPartyUserHome> request)
        {
            var r = new List<Expression<Func<ErpPartyUserHome, bool>>>();
            
            return r;
        }
    }
}