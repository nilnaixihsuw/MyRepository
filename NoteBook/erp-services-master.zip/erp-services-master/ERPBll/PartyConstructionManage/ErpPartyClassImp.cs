﻿using ERPCore.ORM;
using ERPDal.PartyConstructionManage;
using ERPModel.PartyConstructionManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using ERPModel.ApiModel.EnterpriseManage.PartyConstructionManage;
using ERPCore.Entity;
using ERPCore.Redis;
using BusTools.Redis;

namespace ERPBll.PartyConstructionManage
{
    public class ErpPartyClassImp : BusinessRespository<ErpPartyClass, IErpPartyClassDataImp>, IErpPartyClassImp
    {
        public ErpPartyClassImp(IErpPartyClassDataImp dataImp) : base(dataImp)
        {
        }

        public async Task<bool> AddPartyClass(string server_id, ErpPartyClass context, ClientInformation client)
        {
            //判断是否当前届次
            if (context.now == 1)
            {
                if (await _dataImp.IsExist(server_id, it => it.organ_id == context.id && it.now == 1))
                    throw new Exception("已存在当前届次,请勿再次添加!");
            }

            var files = new List<ErpPartyClassFlie>();
            if (context.id > 0)
            {
                context.update_date = DateTime.Now;
                context.update_id = client.i_id;
                var old = await Get(server_id, context.id);
                context.created_date = old.created_date;
                context.created_id = old.created_id;

                if (context.ex_pics != null && context.ex_pics.Count > 0)
                {
                    context.ex_pics.ForEach(item =>
                    {
                        item.type = 2;
                        item.class_id = context.id;
                        item.created_date = DateTime.Now;
                        item.created_id = client.i_id;
                    });
                    files.AddRange(context.ex_pics);
                }
                if (context.ex_files != null && context.ex_files.Count > 0)
                {
                    context.ex_files.ForEach(item =>
                    {
                        item.type = 1;
                        item.class_id = context.id;
                        item.created_date = DateTime.Now;
                        item.created_id = client.i_id;
                    });
                    files.AddRange(context.ex_files);
                }

                return await _dataImp.UpdatePartyClass(server_id, context, files);
            }
            else
            {
                context.id = await _dataImp.GetId(server_id, "SEQ_COMMON");
                context.created_date = DateTime.Now;
                context.created_id = client.i_id;

                if (context.ex_pics != null && context.ex_pics.Count > 0)
                {
                    context.ex_pics.ForEach(item =>
                    {
                        item.type = 2;
                        item.class_id = context.id;
                        item.created_date = DateTime.Now;
                        item.created_id = client.i_id;
                    });
                    files.AddRange(context.ex_pics);
                }
                if (context.ex_files != null && context.ex_files.Count > 0)
                {
                    context.ex_files.ForEach(item =>
                    {
                        item.type = 1;
                        item.class_id = context.id;
                        item.created_date = DateTime.Now;
                        item.created_id = client.i_id;
                    });
                    files.AddRange(context.ex_files);
                }
                return await _dataImp.AddPartyClass(server_id, context, files);
            }
        }

        public async Task<bool> BatchDelete(string server_id, List<decimal> context)
        {
            var list = await _dataImp.List(server_id, it => SqlFunc.ContainsArray(context, it.id));
            return await _dataImp.Deletetable(server_id, list);
        }

        public async Task<List<ErpPartyClass>> QueryPartyClassList(string server_id, ErpPartyClassRequest request, string v)
        {
            return await ExtensionList(server_id, request.ToExp(), v, request.orderby);
        }

        public async Task<Tuple<List<ErpPartyClass>, int>> QueryPartyClassPageList(string server_id, ErpPartyClassRequest request, string v)
        {
            return await ExtensionList(server_id, request.ToExp(), v, request.page_size, request.page_index, request.orderby);
        }
    }
}