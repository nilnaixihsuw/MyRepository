﻿using ERPCore.ORM;
using ERPDal.PartyConstructionManage;
using ERPModel.PartyConstructionManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;

namespace ERPBll.PartyConstructionManage
{
    public class ErpPartyClassFlieImp : BusinessRespository<ErpPartyClassFlie, IErpPartyClassFlieDataImp>, IErpPartyClassFlieImp
    {
        public ErpPartyClassFlieImp(IErpPartyClassFlieDataImp dataImp): base(dataImp)
        {

        }
    }
}