﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPModel.PartyConstructionManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.PartyConstructionManage
{
    public interface IErpPartyActivityImgImp : IBusinessRepository<ErpPartyActivityImg>
    {
        Task<bool> AddErpPartyActivityImg(string server_id, ErpPartyActivityImg context, ClientInformation client);
        Task<Tuple<List<ErpPartyActivityImg>,int>> QueryErpPartyActivityImgPageList(string server_id, BaseRequest<ErpPartyActivityImg> request, string v);
        Task<List<ErpPartyActivityImg>> QueryErpPartyActivityImgList(string server_id, BaseRequest<ErpPartyActivityImg> request, string v);
        Task<bool> BatchDelete(string server_id, List<decimal> context);
    }
}