﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPDal.PartyConstructionManage;
using ERPModel.PartyConstructionManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using System.Linq.Expressions;

namespace ERPBll.PartyConstructionManage
{
    public class ErpPartyActivityTypeImp : BusinessRespository<ErpPartyActivityType, IErpPartyActivityTypeDataImp>, IErpPartyActivityTypeImp
    {
        public ErpPartyActivityTypeImp(IErpPartyActivityTypeDataImp dataImp): base(dataImp)
        {

        }

        public async Task<bool> AddErpPartyActivityType(string server_id, ErpPartyActivityType context, ClientInformation client)
        {
            if (context.id > 0)
            {
                return await _dataImp.Update(server_id, context);
            }
            else
            {
                context.created_date = DateTime.Now;
                context.created_id = client.i_id;
                return await _dataImp.Insert(server_id, context);
            }
        }

        public async Task<Tuple<List<ErpPartyActivityType>,int>> QueryErpPartyActivityTypePageList(string server_id, BaseRequest<ErpPartyActivityType> request, string v)
        {
            var exp = await GetExp(request);
            return await ExtensionList(server_id, request.ToExp(exp), v, request.page_size, request.page_index, request.orderby);
        }

        public async Task<List<ErpPartyActivityType>> QueryErpPartyActivityTypeList(string server_id, BaseRequest<ErpPartyActivityType> request, string v)
        {
            var exp = await GetExp(request);
            return await ExtensionList(server_id, request.ToExp(exp), v, request.orderby);
        }

        public async Task<bool> BatchDelete(string server_id, List<decimal> context)
        {
            var list = await _dataImp.List(server_id, it => SqlFunc.ContainsArray(context, it.id));
            return await _dataImp.Deletetable(server_id, list);
        }

        private async Task<List<Expression<Func<ErpPartyActivityType, bool>>>> GetExp(BaseRequest<ErpPartyActivityType> request)
        {
            var r = new List<Expression<Func<ErpPartyActivityType, bool>>>();
            
            return r;
        }
    }
}