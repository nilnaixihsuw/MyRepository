﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPModel.PartyConstructionManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.PartyConstructionManage
{
    public interface IErpPartyPositionImp : IBusinessRepository<ErpPartyPosition>
    {
        Task<bool> AddErpPartyPosition(string server_id, ErpPartyPosition context, ClientInformation client);
        Task<Tuple<List<ErpPartyPosition>,int>> QueryErpPartyPositionPageList(string server_id, BaseRequest<ErpPartyPosition> request, string v);
        Task<List<ErpPartyPosition>> QueryErpPartyPositionList(string server_id, BaseRequest<ErpPartyPosition> request, string v);
        Task<bool> BatchDelete(string server_id, List<decimal> context);
    }
}