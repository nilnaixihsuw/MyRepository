﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPModel.ApiModel.EnterpriseManage.PartyConstructionManage;
using ERPModel.PartyConstructionManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.PartyConstructionManage
{
    public interface IErpPartyUserImp : IBusinessRepository<ErpPartyUser>
    {
        Task<bool> AddPartyMember(string server_id, ErpPartyUser context, ClientInformation client);
        Task<Tuple<List<ErpPartyUser>,int>> QueryPartyUserPageList(string server_id, ErpPartyUserRequest request, string v);
        Task<List<ErpPartyUser>> QueryPartyUerList(string server_id, ErpPartyUserRequest request, string v);
        Task<bool> BatchDelete(string server_id, List<decimal> context);
    }
}