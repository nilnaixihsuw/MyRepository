﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPDal.PartyConstructionManage;
using ERPModel.PartyConstructionManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using System.Linq.Expressions;

namespace ERPBll.PartyConstructionManage
{
    public class ErpPartyHonorImp : BusinessRespository<ErpPartyHonor, IErpPartyHonorDataImp>, IErpPartyHonorImp
    {
        private readonly IErpPartyHonorUserDataImp _iErpPartyHonorUserDataImp;
        private readonly IErpPartyHonorOrganDataImp _iErpPartyHonorOrganDataImp;
        private readonly IErpPartyHonorFileDataImp _iErpPartyHonorFileDataImp;
        public ErpPartyHonorImp(
            IErpPartyHonorFileDataImp iErpPartyHonorFileDataImp,
            IErpPartyHonorOrganDataImp iErpPartyHonorOrganDataImp,
            IErpPartyHonorUserDataImp iErpPartyHonorUserDataImp,
            IErpPartyHonorDataImp dataImp) : base(dataImp)
        {
            _iErpPartyHonorFileDataImp = iErpPartyHonorFileDataImp;
            _iErpPartyHonorUserDataImp = iErpPartyHonorUserDataImp;
            _iErpPartyHonorOrganDataImp = iErpPartyHonorOrganDataImp;
        }

        public async Task<bool> AddErpPartyHonor(string server_id, ErpPartyHonor context, ClientInformation client)
        {
            if (context.id > 0)
            {
                context.update_date = DateTime.Now;
                context.update_id = client.i_id;
                var old = await Get(server_id, context.id);
                context.created_date = old.created_date;
                context.created_id = old.created_id;

                //获奖党组织
                var honorOrgans = new List<ErpPartyHonorOrgan>();
                if (context.ex_organ_ids != null && context.ex_organ_ids.Count > 0)
                {
                    honorOrgans.AddRange(context.ex_organ_ids?.Select(it => new ErpPartyHonorOrgan
                    {
                        honor_id = context.id,
                        organ_id = it,
                        created_date = DateTime.Now,
                        created_id = client.i_id
                    }).ToList());
                }

                //获奖人员
                var honorUsers=new List<ErpPartyHonorUser>();
                if(context.ex_user_ids != null && context.ex_user_ids.Count > 0)
                {
                    honorUsers.AddRange(context.ex_user_ids?.Select(it => new ErpPartyHonorUser
                    {
                        honor_id = context.id,
                        party_user_id = it,
                        created_date = DateTime.Now,
                        created_id = client.i_id
                    }).ToList());
                }
                //获奖附件
                var files = new List<ErpPartyHonorFile>();
                if (context.ex_pics != null)
                {
                    files.AddRange(context.ex_pics.Select(it => new ErpPartyHonorFile
                    {
                        honor_id = context.id,
                        name = it.name,
                        url = it.url,
                        type = 2,
                        created_date = DateTime.Now,
                        created_id = client.i_id
                    }));
                }
                if (context.ex_files != null)
                {
                    files.AddRange(context.ex_files.Select(it => new ErpPartyHonorFile
                    {
                        honor_id = context.id,
                        name = it.name,
                        url = it.url,
                        type = 1,
                        created_date = DateTime.Now,
                        created_id = client.i_id
                    }));
                }

                return await _dataImp.UpdateErpPartyHonor(server_id, context, honorOrgans, honorUsers, files);
            }
            else
            {
                context.id = await _dataImp.GetId(server_id, "SEQ_COMMON");
                context.created_date = DateTime.Now;
                context.created_id = client.i_id;

                //获奖党组织
                var honorOrgans = new List<ErpPartyHonorOrgan>();
                if (context.ex_organ_ids != null && context.ex_organ_ids.Count > 0)
                {
                    honorOrgans.AddRange(context.ex_organ_ids?.Select(it => new ErpPartyHonorOrgan
                    {
                        honor_id = context.id,
                        organ_id = it,
                        created_date = DateTime.Now,
                        created_id = client.i_id
                    }).ToList());
                }

                //获奖人员
                var honorUsers = new List<ErpPartyHonorUser>();
                if (context.ex_user_ids != null && context.ex_user_ids.Count > 0)
                {
                    honorUsers.AddRange(context.ex_user_ids?.Select(it => new ErpPartyHonorUser
                    {
                        honor_id = context.id,
                        party_user_id = it,
                        created_date = DateTime.Now,
                        created_id = client.i_id
                    }).ToList());
                }
                //获奖附件
                var files = new List<ErpPartyHonorFile>();
                if (context.ex_pics != null)
                {
                    files.AddRange(context.ex_pics.Select(it => new ErpPartyHonorFile
                    {
                        honor_id = context.id,
                        name = it.name,
                        url = it.url,
                        type = 2,
                        created_date = DateTime.Now,
                        created_id = client.i_id
                    }));
                }
                if (context.ex_files != null)
                {
                    files.AddRange(context.ex_files.Select(it => new ErpPartyHonorFile
                    {
                        honor_id = context.id,
                        name = it.name,
                        url = it.url,
                        type = 1,
                        created_date = DateTime.Now,
                        created_id = client.i_id
                    }));
                }

                return await _dataImp.AddErpPartyHonor(server_id, context, honorOrgans, honorUsers, files);
            }
        }

        public async Task<Tuple<List<ErpPartyHonor>, int>> QueryErpPartyHonorPageList(string server_id, BaseRequest<ErpPartyHonor> request, string v)
        {
            var exp = await GetExp(request);
            return await ExtensionList(server_id, request.ToExp(exp), v, request.page_size, request.page_index, request.orderby);
        }

        public async Task<List<ErpPartyHonor>> QueryErpPartyHonorList(string server_id, BaseRequest<ErpPartyHonor> request, string v)
        {
            var exp = await GetExp(request);
            return await ExtensionList(server_id, request.ToExp(exp), v, request.orderby);
        }

        public async Task<bool> BatchDelete(string server_id, List<decimal> context)
        {
            //删除荣誉记录
            var list = await _dataImp.List(server_id, it => SqlFunc.ContainsArray(context, it.id));
            //荣誉党员
            var honorUsers = await _iErpPartyHonorUserDataImp.List(server_id, it => SqlFunc.ContainsArray(context, it.honor_id));
            //荣誉组织
            var honorOrgans = await _iErpPartyHonorOrganDataImp.List(server_id, it => SqlFunc.ContainsArray(context, it.honor_id));
            //附件
            var files = await _iErpPartyHonorFileDataImp.List(server_id, it => SqlFunc.ContainsArray(context, it.honor_id));
            return await _dataImp.BatchDelete(server_id, list, honorUsers, honorOrgans, files);
        }

        private async Task<List<Expression<Func<ErpPartyHonor, bool>>>> GetExp(BaseRequest<ErpPartyHonor> request)
        {
            var r = new List<Expression<Func<ErpPartyHonor, bool>>>();

            return r;
        }
    }
}