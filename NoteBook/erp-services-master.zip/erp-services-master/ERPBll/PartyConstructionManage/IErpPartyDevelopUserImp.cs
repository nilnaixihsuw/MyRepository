﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPModel.ApiModel.EnterpriseManage.PartyConstructionManage;
using ERPModel.PartyConstructionManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.PartyConstructionManage
{
    public interface IErpPartyDevelopUserImp : IBusinessRepository<ErpPartyDevelopUser>
    {
        Task<bool> AddErpPartyDevelopUser(string server_id, ErpPartyDevelopUser context, ClientInformation client);
        Task<Tuple<List<ErpPartyDevelopUser>,int>> QueryErpPartyDevelopUserPageList(string server_id, ErpPartyDevelopUserRequest request, string v);
        Task<List<ErpPartyDevelopUser>> QueryErpPartyDevelopUserList(string server_id, ErpPartyDevelopUserRequest request, string v);
        Task<bool> BatchDelete(string server_id, List<decimal> context);
    }
}