﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPModel.PartyConstructionManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.PartyConstructionManage
{
    public interface IErpPartyActivityImp : IBusinessRepository<ErpPartyActivity>
    {
        Task<bool> AddErpPartyActivity(string server_id, ErpPartyActivity context, ClientInformation client);
        Task<Tuple<List<ErpPartyActivity>,int>> QueryErpPartyActivityPageList(string server_id, BaseRequest<ErpPartyActivity> request, string v,ClientInformation client);
        Task<List<ErpPartyActivity>> QueryErpPartyActivityList(string server_id, BaseRequest<ErpPartyActivity> request, string v, ClientInformation client);
        Task<bool> BatchDelete(string server_id, List<decimal> context);
        Task<ErpPartyActivity> Detail(string server_id, decimal id, ClientInformation client);
    }
}