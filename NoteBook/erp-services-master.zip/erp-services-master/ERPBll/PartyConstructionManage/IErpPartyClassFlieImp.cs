﻿using ERPCore.ORM;
using ERPModel.PartyConstructionManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.PartyConstructionManage
{
    public interface IErpPartyClassFlieImp : IBusinessRepository<ErpPartyClassFlie>
    {
    }
}