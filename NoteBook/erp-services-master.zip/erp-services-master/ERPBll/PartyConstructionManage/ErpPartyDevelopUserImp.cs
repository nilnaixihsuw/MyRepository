﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPDal.PartyConstructionManage;
using ERPModel.PartyConstructionManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using System.Linq.Expressions;
using ERPModel.ApiModel.EnterpriseManage.PartyConstructionManage;

namespace ERPBll.PartyConstructionManage
{
    public class ErpPartyDevelopUserImp : BusinessRespository<ErpPartyDevelopUser, IErpPartyDevelopUserDataImp>, IErpPartyDevelopUserImp
    {
        private readonly IErpPartyDevelopStepDataImp _iErpPartyDevelopStepDataImp;
        private readonly IErpPartyStepFileDataImp _iErpPartyStepFileDataImp;

        public ErpPartyDevelopUserImp(
            IErpPartyStepFileDataImp iErpPartyStepFileDataImp,
            IErpPartyDevelopStepDataImp iErpPartyDevelopStepDataImp,
            IErpPartyDevelopUserDataImp dataImp) : base(dataImp)
        {
            _iErpPartyStepFileDataImp = iErpPartyStepFileDataImp;
            _iErpPartyDevelopStepDataImp = iErpPartyDevelopStepDataImp;
        }


        public async Task<bool> AddErpPartyDevelopUser(string server_id, ErpPartyDevelopUser context, ClientInformation client)
        {
            if (context.id > 0)
            {
                var old = await _dataImp.Get(server_id, context.id);
                context.created_id = old.created_id;
                context.created_date = old.created_date;
                context.update_date = DateTime.Now;
                context.update_id = client.i_id;

                //图片
                var files = new List<ErpPartyStepFile>();
                if (context.ex_pics != null && context.ex_pics.Count > 0)
                {
                    files.AddRange(context.ex_pics.Select(it => new ErpPartyStepFile
                    {
                        develop_id = context.id,
                        type = 1,
                        url = it,
                        created_id = client.i_id,
                        created_date = DateTime.Now
                    }));
                }

                //发展党员流程进度
                var step = new ErpPartyDevelopStep();
                var steps = await _iErpPartyDevelopStepDataImp.List(server_id, it => it.develop_id == context.id);
                if (steps.Count > 0)
                {
                    step = steps.Find(it => it.develop_id == context.id);
                    step.update_id = client.i_id;
                    step.update_date = DateTime.Now;
                }
                else
                {
                    step.created_id = client.i_id;
                    step.created_date = DateTime.Now;
                }
                step.develop_id = context.id;
                step.organ_id = context.ex_organ_id;
                step.apply_time = context.ex_apply_time;
                if (context.ex_apply_time != null)
                    step.user1 = client.i_id;
                step.talk_name = context.ex_talk_name;
                step.talk_time = context.ex_talk_time;
                if (context.ex_talk_time != null)
                    step.user2 = client.i_id;
                step.confirm_time = context.ex_confirm_time;
                if (context.ex_confirm_time != null)
                    step.user3 = client.i_id;
                step.record_time = context.ex_record_time;
                if (context.ex_record_time != null)
                    step.user4 = client.i_id;
                step.assign_name = context.ex_assign_name;
                step.assign_time = context.ex_assign_time;
                if (context.ex_assign_time != null)
                    step.user5 = client.i_id;
                step.inspect_time = context.ex_inspect_time;
                if (context.ex_inspect_time != null)
                    step.user6 = client.i_id;
                step.object_time = context.ex_object_time;
                if (context.ex_object_time != null)
                    step.user7 = client.i_id;
                step.public_time = context.ex_public_time;
                if (context.ex_public_time != null)
                    step.user8 = client.i_id;
                step.introduce_name = context.ex_introduce_name;
                if (!string.IsNullOrEmpty(context.ex_introduce_name))
                    step.user9 = client.i_id;
                step.train_time = context.ex_train_time;
                if (context.ex_train_time != null)
                    step.user10 = client.i_id;
                step.check_time = context.ex_check_time;
                if (context.ex_check_time != null)
                    step.user11 = client.i_id;
                step.meeting_time = context.ex_meeting_time;
                if (context.ex_meeting_time != null)
                    step.user12 = client.i_id;
                if (context.ex_sjdwys_files != null && context.ex_sjdwys_files.Count > 0)
                    step.user13 = client.i_id;
                step.write_time = context.ex_write_time;
                if (context.ex_write_time != null)
                    step.user14 = client.i_id;
                step.discuss_time = context.ex_discuss_time;
                if (context.ex_discuss_time != null)
                    step.user15 = client.i_id;
                step.talk_name_up = context.ex_talk_name_up;
                step.talk_time_up = context.ex_talk_time_up;
                if (context.ex_talk_time_up != null)
                    step.user16 = client.i_id;
                step.audit_time = context.ex_audit_time;
                if (context.ex_audit_time != null)
                    step.user17 = client.i_id;
                step.record_time_up = context.ex_record_time_up;
                if (context.ex_record_time_up != null)
                    step.user18 = client.i_id;
                if (context.ex_brdzb_files != null && context.ex_brdzb_files.Count > 0)
                    step.user19 = client.i_id;
                step.oath_time = context.ex_oath_time;
                if (context.ex_oath_time != null)
                    step.user20 = client.i_id;
                step.start_inspect_time = context.ex_start_inspect_time;
                if (context.ex_start_inspect_time != null)
                    step.user21 = client.i_id;
                step.positive_time = context.ex_positive_time;
                if (context.ex_positive_time != null)
                    step.user22 = client.i_id;
                step.discuss_time_up = context.ex_discuss_time_up;
                if (context.ex_discuss_time_up != null)
                    step.user23 = client.i_id;
                step.submit_time = context.ex_submit_time;
                if (context.ex_submit_time != null)
                    step.user24 = client.i_id;
                step.archive_time = context.ex_archive_time;
                if (context.ex_archive_time != null)
                    step.user25 = client.i_id;

                //发展党员进度资料
                if (context.ex_apply_files != null && context.ex_apply_files.Count > 0)                             //递交入党申请书资料
                    files.AddRange(AddFiles(context.id, context.ex_apply_files, client));
                if (context.ex_talk_files != null && context.ex_talk_files.Count > 0)                               //党组织派人谈话资料
                    files.AddRange(AddFiles(context.id, context.ex_talk_files, client));
                if (context.ex_rec_files != null && context.ex_rec_files.Count > 0)                                  //推荐和确定入党分子资料
                    files.AddRange(AddFiles(context.id, context.ex_rec_files, client));
                if (context.ex_ba_files != null && context.ex_ba_files.Count > 0)                                    //上级党委备案资料
                    files.AddRange(AddFiles(context.id, context.ex_ba_files, client));
                if (context.ex_kc_files != null && context.ex_kc_files.Count > 0)                                    //培养教育考察资料
                    files.AddRange(AddFiles(context.id, context.ex_kc_files, client));
                if (context.ex_qdfz_files != null && context.ex_qdfz_files.Count > 0)                                //确定发展对象资料
                    files.AddRange(AddFiles(context.id, context.ex_qdfz_files, client));
                if (context.ex_bsj_files != null && context.ex_bsj_files.Count > 0)                                  //报上级党委备案资料
                    files.AddRange(AddFiles(context.id, context.ex_bsj_files, client));
                if (context.ex_kzjzpx_files != null && context.ex_kzjzpx_files.Count > 0)                                 //开展集中培训资料
                    files.AddRange(AddFiles(context.id, context.ex_kzjzpx_files, client));
                if (context.ex_zzsc_files != null && context.ex_zzsc_files.Count > 0)                                 //进行政治审查资料
                    files.AddRange(AddFiles(context.id, context.ex_zzsc_files, client));
                if (context.ex_zbwyhsc_files != null && context.ex_zbwyhsc_files.Count > 0)                                 //支部委员会审查资料
                    files.AddRange(AddFiles(context.id, context.ex_zbwyhsc_files, client));
                if (context.ex_sjdwys_files != null && context.ex_sjdwys_files.Count > 0)                                 //上级党委预审资料
                    files.AddRange(AddFiles(context.id, context.ex_sjdwys_files, client));
                if (context.ex_rdzys_files != null && context.ex_rdzys_files.Count > 0)                                 //填写入党志愿书材料
                    files.AddRange(AddFiles(context.id, context.ex_rdzys_files, client));
                if (context.ex_zbtldh_files != null && context.ex_zbtldh_files.Count > 0)                                 //支部讨论大会材料
                    files.AddRange(AddFiles(context.id, context.ex_zbtldh_files, client));
                if (context.ex_brdzb_files != null && context.ex_brdzb_files.Count > 0)                                 //编入党支部和党小组材料
                    files.AddRange(AddFiles(context.id, context.ex_brdzb_files, client));
                if (context.ex_zzsq_files != null && context.ex_zzsq_files.Count > 0)                                 //提出转正申请材料
                    files.AddRange(AddFiles(context.id, context.ex_zzsq_files, client));
                if (context.ex_tldh_files != null && context.ex_tldh_files.Count > 0)                                 //支部讨论大会材料
                    files.AddRange(AddFiles(context.id, context.ex_tldh_files, client));

                return await _dataImp.UpdateErpPartyDevelopUser(server_id, context, files, step);
            }
            else
            {
                context.created_date = DateTime.Now;
                context.created_id = client.i_id;
                context.id = await _dataImp.GetId(server_id, "SEQ_COMMON");

                //图片
                var pics = new List<ErpPartyStepFile>();
                if (context.ex_pics != null && context.ex_pics.Count > 0)
                {
                    pics.AddRange(context.ex_pics.Select(it => new ErpPartyStepFile
                    {
                        develop_id = context.id,
                        type = 1,
                        url = it,
                        created_id = client.i_id,
                        created_date = DateTime.Now
                    }));
                }

                return await _dataImp.AddErpPartyDevelopUser(server_id, context, pics);
            }
        }

        private List<ErpPartyStepFile> AddFiles(decimal id, List<ErpPartyStepFile> field, ClientInformation client)
        {
            field.ForEach(item =>
            {
                item.develop_id = id;
                //item.step = step;
                item.created_id = client.i_id;
                item.created_date = DateTime.Now;
            });
            return field;
        }

        public async Task<Tuple<List<ErpPartyDevelopUser>, int>> QueryErpPartyDevelopUserPageList(string server_id, ErpPartyDevelopUserRequest request, string v)
        {
            var exp = await GetExp(request);
            return await ExtensionList(server_id, request.ToExp(exp), v, request.page_size, request.page_index, request.orderby);
        }

        public async Task<List<ErpPartyDevelopUser>> QueryErpPartyDevelopUserList(string server_id, ErpPartyDevelopUserRequest request, string v)
        {
            var exp = await GetExp(request);
            return await ExtensionList(server_id, request.ToExp(exp), v, request.orderby);
        }

        public async Task<bool> BatchDelete(string server_id, List<decimal> context)
        {
            var list = await _dataImp.List(server_id, it => SqlFunc.ContainsArray(context, it.id));
            //发展流程进度
            var steps = await _iErpPartyDevelopStepDataImp.List(server_id, it => SqlFunc.ContainsArray(context, it.develop_id));
            //发展流程附件
            var files = await _iErpPartyStepFileDataImp.List(server_id, it => SqlFunc.ContainsArray(context, it.develop_id));
            return await _dataImp.BatchDelete(server_id, list, steps, files);
        }

        private async Task<List<Expression<Func<ErpPartyDevelopUser, bool>>>> GetExp(ErpPartyDevelopUserRequest request)
        {
            var r = new List<Expression<Func<ErpPartyDevelopUser, bool>>>();

            if (request.work_flow != null)
            {
                var ids = new List<decimal?>();
                var list = new List<ErpPartyDevelopStep>();
                var files = new List<ErpPartyStepFile>();
                switch (request.work_flow)
                {
                    case 1:
                        list = await _iErpPartyDevelopStepDataImp.List(request.server_id, it => it.organ_id != null);
                        ids = list.Where(it => it.ex_present == 1)?.Select(it => it.develop_id).Distinct().ToList();
                        break;
                    case 2:
                        list = await _iErpPartyDevelopStepDataImp.List(request.server_id, it => !SqlFunc.IsNullOrEmpty(it.talk_name));
                        ids = list.Where(it => it.ex_present == 2)?.Select(it => it.develop_id).Distinct().ToList();
                        break;
                    case 3:
                        list = await _iErpPartyDevelopStepDataImp.List(request.server_id, it => it.confirm_time != null);
                        ids = list.Where(it => it.ex_present == 3)?.Select(it => it.develop_id).Distinct().ToList();
                        break;
                    case 4:
                        list = await _iErpPartyDevelopStepDataImp.List(request.server_id, it => it.record_time != null);
                        ids = list.Where(it => it.ex_present == 4)?.Select(it => it.develop_id).Distinct().ToList();
                        break;
                    case 5:
                        list = await _iErpPartyDevelopStepDataImp.List(request.server_id, it => it.assign_name != null);
                        ids = list.Where(it => it.ex_present == 5)?.Select(it => it.develop_id).Distinct().ToList();
                        break;
                    case 6:
                        list = await _iErpPartyDevelopStepDataImp.List(request.server_id, it => it.inspect_time != null);
                        ids = list.Where(it => it.ex_present == 6)?.Select(it => it.develop_id).Distinct().ToList();
                        break;
                    case 7:
                        list = await _iErpPartyDevelopStepDataImp.List(request.server_id, it => it.object_time != null);
                        ids = list.Where(it => it.ex_present == 7)?.Select(it => it.develop_id).Distinct().ToList();
                        break;
                    case 8:
                        list = await _iErpPartyDevelopStepDataImp.List(request.server_id, it => it.public_time != null);
                        ids = list.Where(it => it.ex_present == 8)?.Select(it => it.develop_id).Distinct().ToList();
                        break;
                    case 9:
                        list = await _iErpPartyDevelopStepDataImp.List(request.server_id, it => !SqlFunc.IsNullOrEmpty(it.introduce_name));
                        ids = list.Where(it => it.ex_present == 9)?.Select(it => it.develop_id).Distinct().ToList();
                        break;
                    case 10:
                        list = await _iErpPartyDevelopStepDataImp.List(request.server_id, it => it.check_time != null);
                        ids = list.Where(it => it.ex_present == 10)?.Select(it => it.develop_id).Distinct().ToList();
                        break;
                    case 11:
                        list = await _iErpPartyDevelopStepDataImp.List(request.server_id, it => it.train_time != null);
                        ids = list.Where(it => it.ex_present == 11)?.Select(it => it.develop_id).Distinct().ToList();
                        break;
                    case 12:
                        list = await _iErpPartyDevelopStepDataImp.List(request.server_id, it => it.meeting_time != null);
                        ids = list.Where(it => it.ex_present == 12)?.Select(it => it.develop_id).Distinct().ToList();
                        break;
                    case 13:
                        files = await _iErpPartyStepFileDataImp.List(request.server_id, it => it.step_int > (int)PartyDevelopEnum.YUSHENFILE && it.step_int <= (int)PartyDevelopEnum.ZHIYUANSHUFILE);
                        ids = files.Except(files.Where(it => it.step_int > (int)PartyDevelopEnum.BIANRUDANGZHIBUFILE && it.step_int <= (int)PartyDevelopEnum.ZHUANZHWNGFILE))?.Select(it => it.develop_id).Distinct().ToList();
                        break;
                    case 14:
                        list = await _iErpPartyDevelopStepDataImp.List(request.server_id, it => it.write_time != null);
                        ids = list.Where(it => it.ex_present == 14)?.Select(it => it.develop_id).Distinct().ToList();
                        break;
                    case 15:
                        list = await _iErpPartyDevelopStepDataImp.List(request.server_id, it => it.discuss_time != null);
                        ids = list.Where(it => it.ex_present == 15)?.Select(it => it.develop_id).Distinct().ToList();
                        break;
                    case 16:
                        list = await _iErpPartyDevelopStepDataImp.List(request.server_id, it => it.talk_name_up != null);
                        ids = list.Where(it => it.ex_present == 16)?.Select(it => it.develop_id).Distinct().ToList();
                        break;
                    case 17:
                        list = await _iErpPartyDevelopStepDataImp.List(request.server_id, it => it.audit_time != null);
                        ids = list.Where(it => it.ex_present == 17)?.Select(it => it.develop_id).Distinct().ToList();
                        break;
                    case 18:
                        list = await _iErpPartyDevelopStepDataImp.List(request.server_id, it => it.record_time_up != null);
                        ids = list.Where(it => it.ex_present == 18)?.Select(it => it.develop_id).Distinct().ToList();
                        break;
                    case 19:
                        files = await _iErpPartyStepFileDataImp.List(request.server_id, it => it.step_int > (int)PartyDevelopEnum.BIANRUDANGZHIBUFILE && it.step_int <= (int)PartyDevelopEnum.ZHUANZHWNGFILE);
                        ids = files.Except(files.Where(it => it.step_int > (int)PartyDevelopEnum.YUSHENFILE && it.step_int <= (int)PartyDevelopEnum.ZHIYUANSHUFILE))?.Select(it => it.develop_id).Distinct().ToList();
                        break;
                    case 20:
                        list = await _iErpPartyDevelopStepDataImp.List(request.server_id, it => it.oath_time != null);
                        ids = list.Where(it => it.ex_present == 20)?.Select(it => it.develop_id).Distinct().ToList();
                        break;
                    case 21:
                        list = await _iErpPartyDevelopStepDataImp.List(request.server_id, it => it.start_inspect_time != null);
                        ids = list.Where(it => it.ex_present == 21)?.Select(it => it.develop_id).Distinct().ToList();
                        break;
                    case 22:
                        list = await _iErpPartyDevelopStepDataImp.List(request.server_id, it => it.positive_time != null);
                        ids = list.Where(it => it.ex_present == 22)?.Select(it => it.develop_id).Distinct().ToList();
                        break;
                    case 23:
                        list = await _iErpPartyDevelopStepDataImp.List(request.server_id, it => it.discuss_time_up != null);
                        ids = list.Where(it => it.ex_present == 23)?.Select(it => it.develop_id).Distinct().ToList();
                        break;
                    case 24:
                        list = await _iErpPartyDevelopStepDataImp.List(request.server_id, it => it.submit_time != null);
                        ids = list.Where(it => it.ex_present == 24)?.Select(it => it.develop_id).Distinct().ToList();
                        break;
                    case 25:
                        list = await _iErpPartyDevelopStepDataImp.List(request.server_id, it => it.archive_time != null);
                        ids = list.Where(it => it.ex_present == 25)?.Select(it => it.develop_id).Distinct().ToList();
                        break;
                }

                if (ids.Count > 0)
                {
                    r.Add(it => SqlFunc.ContainsArray(ids, it.id));
                }
                else
                {
                    r.Add(it => false);
                }

            }

            return r;
        }
    }
}