﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPModel.PartyConstructionManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.PartyConstructionManage
{
    public interface IErpActivityUserImp : IBusinessRepository<ErpActivityUser>
    {
        Task<bool> AddErpActivityUser(string server_id, ErpActivityUser context, ClientInformation client);
        Task<Tuple<List<ErpActivityUser>,int>> QueryErpActivityUserPageList(string server_id, BaseRequest<ErpActivityUser> request, string v);
        Task<List<ErpActivityUser>> QueryErpActivityUserList(string server_id, BaseRequest<ErpActivityUser> request, string v);
        Task<bool> BatchDelete(string server_id, List<decimal> context);
    }
}