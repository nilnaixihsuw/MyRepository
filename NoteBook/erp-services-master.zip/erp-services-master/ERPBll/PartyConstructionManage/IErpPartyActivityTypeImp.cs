﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPModel.PartyConstructionManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.PartyConstructionManage
{
    public interface IErpPartyActivityTypeImp : IBusinessRepository<ErpPartyActivityType>
    {
        Task<bool> AddErpPartyActivityType(string server_id, ErpPartyActivityType context, ClientInformation client);
        Task<Tuple<List<ErpPartyActivityType>,int>> QueryErpPartyActivityTypePageList(string server_id, BaseRequest<ErpPartyActivityType> request, string v);
        Task<List<ErpPartyActivityType>> QueryErpPartyActivityTypeList(string server_id, BaseRequest<ErpPartyActivityType> request, string v);
        Task<bool> BatchDelete(string server_id, List<decimal> context);
    }
}