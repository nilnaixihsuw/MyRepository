﻿using ERPCore.ORM;
using ERPDal.PartyConstructionManage;
using ERPModel.PartyConstructionManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using ERPCore.Entity;

namespace ERPBll.PartyConstructionManage
{
    public class ErpPartyFeeSetImp : BusinessRespository<ErpPartyFeeSet, IErpPartyFeeSetDataImp>, IErpPartyFeeSetImp
    {
        public ErpPartyFeeSetImp(IErpPartyFeeSetDataImp dataImp) : base(dataImp)
        {

        }

        public async Task<double?> PartyFeeQuery(string server_id, double fee)
        {
            var list = await _dataImp.List(server_id, it => fee > it.min && fee <= it.max && it.max != -1);
            list.AddRange(await _dataImp.List(server_id, it => it.min < fee && it.max == -1));
            if (list.Count == 1)
            {
                return list.FirstOrDefault().value;
            }
            else
            {
                throw new Exception("系统未找到适配比例!");
            }
        }

        public async Task<bool> PartyFeeSet(string server_id, List<ErpPartyFeeSet> context, ClientInformation client)
        {
            context.ForEach(item =>
            {
                item.created_date = DateTime.Now;
                item.created_id = client.i_id;
            });
            return await _dataImp.PartyFeeSet(server_id, context);
        }
    }
}