﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPModel.PartyConstructionManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.PartyConstructionManage
{
    public interface IErpPartyStepFileImp : IBusinessRepository<ErpPartyStepFile>
    {
        Task<bool> AddErpPartyStepFile(string server_id, ErpPartyStepFile context, ClientInformation client);
        Task<Tuple<List<ErpPartyStepFile>,int>> QueryErpPartyStepFilePageList(string server_id, BaseRequest<ErpPartyStepFile> request, string v);
        Task<List<ErpPartyStepFile>> QueryErpPartyStepFileList(string server_id, BaseRequest<ErpPartyStepFile> request, string v);
        Task<bool> BatchDelete(string server_id, List<decimal> context);
    }
}