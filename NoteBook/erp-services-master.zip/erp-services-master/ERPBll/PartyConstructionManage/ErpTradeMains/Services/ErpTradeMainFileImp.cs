﻿using ERPBll.PartyConstructionManage.ErpTradeMains.Contracts;
using ERPDal;
using ERPModel.PartyConstructionManage.ErpTradeMains;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.PartyConstructionManage.ErpTradeMains.Services
{
    public class ErpTradeMainFileImp : IErpTradeMainFileImp
    {
        /// <summary>
        /// 上传附件
        /// </summary>
        public async Task<bool> CreateAsync(
            string server_id, List<ErpTradeMainFile> list)

        {
            //删除旧附件
            SqlSugarHelper.DelByExp<ErpTradeMainFile>(server_id, x => x.trade_id == list.First().trade_id);

            return await SqlSugarHelper.DBClient(server_id)
                            .Insertable(list)
                            .ExecuteCommandAsync() > 0;
        }

        /// <summary>
        /// 根据会员id删除附件
        /// </summary>
        public async Task<bool> DeleteAsync(
            string server_id, List<decimal> trade_ids)

        {
            return SqlSugarHelper.DelByExp<ErpTradeMainFile>(server_id, x => trade_ids.Contains(x.trade_id));
        }

        /// <summary>
        /// 获取附件列表
        /// </summary>
        public async Task<List<ErpTradeMainFile>> GetListAsync(
            string server_id, decimal tradeId)

        {
            return await SqlSugarHelper.DBClient(server_id)
                            .Queryable<ErpTradeMainFile>()
                            .Where(x => x.trade_id == tradeId)
                            .ToListAsync();
        }
    }
}
