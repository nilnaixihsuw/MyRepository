﻿using AutoMapper;
using DotNetCore.CAP;
using ERPBll.Caps;
using ERPBll.FlowManage.Contracts;
using ERPBll.PartyConstructionManage.ErpTradeMains.Contracts;
using ERPBll.RedisManage.Users;
using ERPCore.Auditing;
using ERPCore.Entity;
using ERPDal;
using ERPModel.FlowManage;
using ERPModel.FlowManage.FlowRecords;
using ERPModel.PartyConstructionManage.ErpTradeMains;
using ERPModel.UserManage;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ERPBll.PartyConstructionManage.ErpTradeMains.Services
{
    public class ErpTradeReqImp : IErpTradeReqImp, ICapSubscribe
    {

        private readonly IMapper _imapper;
        private readonly IErpTradeReqFileImp _iErpTradeReqFileImp;
        private readonly IErpFlowRecordImp _erpFlowRecordImp;
        private readonly IErpTradeMainImp _iErpTradeMainImp;
        private readonly IErpFlowRecordImp _iErpFlowRecordImp;
        private readonly IUserRedisImp _iUserRedisImp;

        public ErpTradeReqImp(
            IMapper imapper,
            IErpTradeReqFileImp iErpTradeReqFileImp,
            IErpFlowRecordImp erpFlowRecordImp,
            IErpTradeMainImp iErpTradeMainImp,
            IErpFlowRecordImp iErpFlowRecordImp,
            IUserRedisImp iUserRedisImp)
        {
            _imapper = imapper;
            _iErpTradeReqFileImp = iErpTradeReqFileImp;
            _erpFlowRecordImp = erpFlowRecordImp;
            _iErpTradeMainImp = iErpTradeMainImp;
            _iErpFlowRecordImp = iErpFlowRecordImp;
            _iUserRedisImp = iUserRedisImp;
        }

        /// <summary>
        /// 分页查询
        /// </summary>
        public async Task<(List<ErpTradeReqDto>, int)> GetByPageAsync(
            string server_id, decimal? user_id, ErpTradeReqQuery input)
        {
            RefAsync<int> totalCount = 0;

            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpTradeReq, SysPerson>(
                                    (x, y) => new JoinQueryInfos(
                                        JoinType.Left, y.i_id == x.user_id
                                    ))
                                .Where(input.ToExp())
                                .Mapper(x => x.user_info, x => x.user_id)
                                .Mapper(x => x.created_info, x => x.created_id)
                                .Mapper(x =>
                                {
                                    x.files = SqlSugarHelper.DBClient(server_id)
                                                    .Queryable<ErpTradeReqFile>()
                                                    .Where(y => y.req_id == x.id)
                                                    .ToList();
                                })
                                .ToPageListAsync(input.page_index, input.page_size, totalCount);

            if (list != null && list.Count > 0)
            {
                var all = await _erpFlowRecordImp.GetListAsync(server_id, user_id,
                                    new FlowRecordQuery()
                                    {
                                        detail_ids = list.Select(x => (int)x.id).ToList()
                                    });
                foreach (var item in list)
                {
                    if (item.state == 2)//审核中
                    {
                        var info = all.FirstOrDefault(x => x.detail_id == item.id);
                        if (info != null)
                        {
                            item.user_ids = info.state_child_id;
                            item.user_names = info.state_child_name;
                        }
                    }
                }
            }

            var data = _imapper.Map<List<ErpTradeReq>, List<ErpTradeReqDto>>(list);

            return (data, totalCount);
        }

        /// <summary>
        /// 分页查询待我处理
        /// </summary>
        public async Task<(List<ErpTradeReqDto>, int)> GetWaitByPageAsync(
            string server_id, decimal? user_id, ErpTradeReqQuery input)
        {
            RefAsync<int> totalCount = 0;

            var wait = await _erpFlowRecordImp.GetAllWaitAsync(server_id, user_id,
                        new FlowRecordQuery() { 
                            object_id = Convert.ToInt32(FlowRecordType.工会会员申请)
                        });

            var wait_ids = wait.Select(x => x.id).ToList();

            if (wait_ids == null || wait_ids.Count <1)
            {
                return (new List<ErpTradeReqDto>(), 0);
            }

            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpTradeReq, SysPerson>(
                                    (x, y) => new JoinQueryInfos(
                                        JoinType.Left, y.i_id == x.user_id
                                    ))
                                .Where(input.ToExp())
                                .Where(x => wait_ids.Contains(Convert.ToInt32(x.flow_id)))
                                .Mapper(x => x.user_info, x => x.user_id)
                                .Mapper(x => x.created_info, x => x.created_id)
                                .Mapper(x =>
                                {
                                    x.files = SqlSugarHelper.DBClient(server_id)
                                                    .Queryable<ErpTradeReqFile>()
                                                    .Where(y => y.req_id == x.id)
                                                    .ToList();
                                })
                                .ToPageListAsync(input.page_index, input.page_size, totalCount);


            foreach (var item in list)
            {
                if (item.state == 2)//审核中
                {
                    var info = wait.FirstOrDefault(x => x.detail_id == item.id);
                    if (info != null && info.wait_flow_step != null && info.wait_flow_step.wait_users != null)
                    {
                        item.user_ids = info.wait_flow_step.wait_users.Select(x => x.check_id).ToList();
                        item.user_names = string.Join(',', info.wait_flow_step.wait_users.Select(x => x.check_name).ToList());
                    }
                }
            }
            var data = _imapper.Map<List<ErpTradeReq>, List<ErpTradeReqDto>>(list);

            return (data, totalCount);
        }

        /// <summary>
        /// 确认入会
        /// </summary>
        /// <param name="server_id"></param>
        /// <returns></returns>
        public async Task<ErpTradeMainDto> ConfirmAsync(string server_id, ClientInformation client, IClientInfoProvider client_pro, decimal id)
        {
            //查询
            var info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpTradeReq>()
                                .Where(x => x.id == id)
                                .Mapper(x => x.user_info, x => x.user_id)
                                .Mapper(x => x.created_info, x => x.created_id)
                                .Mapper(x =>
                                {
                                    x.files = SqlSugarHelper.DBClient(server_id)
                                                    .Queryable<ErpTradeReqFile>()
                                                    .Where(y => y.req_id == x.id)
                                                    .ToList();
                                })
                                .FirstAsync();

            if (info.state != 3)
            {
                throw new Exception($"会员申请未审核完成，id={id}");
            }

            var create = new CreateOrUpdateErpTradeMain
            {
                code = await _iErpTradeMainImp.GetCodeAsync(),
                trade_code = "",
                name = info.user_info.c_name,
                phone = info.phone,
                birthday = info.birthday,
                birth_place = info.address,
                nation = info.nation,
                wages = info.wages,
                politics_status = info.politics_status,
                top_education = info.top_education,
                position = info.position,
                hometown = info.hometown
            };

            var trade =  await _iErpTradeMainImp.CreateOrUpdateAsync(server_id, client.i_id, create);

            info.state = 6;
            await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync();

            return trade;
        }

        /// <summary>
        /// 撤销入会
        /// </summary>
        public async Task<bool> RevokeAsync(string server_id, decimal id)
        {
            //查询
            var info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpTradeReq>()
                                .Where(x => x.id == id)
                                .Mapper(x => x.user_info, x => x.user_id)
                                .Mapper(x => x.created_info, x => x.created_id)
                                .Mapper(x =>
                                {
                                    x.files = SqlSugarHelper.DBClient(server_id)
                                                    .Queryable<ErpTradeReqFile>()
                                                    .Where(y => y.req_id == x.id)
                                                    .ToList();
                                })
                                .FirstAsync();

            if (info.state != 3)
            {
                throw new Exception($"会员申请未审核完成，id={id}");
            }

            info.state = 7;

            return await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync() > 0;
        }

        /// <summary>
        /// 获取入会确认的会员申请
        /// </summary>
        public async Task<List<ErpTradeReqDto>> GetReqAsync(ConfirmTradeReqQuery query)
        {

            //查询
            var list = await SqlSugarHelper.DBClient(query.server_id)
                                .Queryable<ErpTradeReq>()
                                .Where(query.ToExp())
                                .Where(x => x.state == 2 || x.state == 3)
                                .OrderBy(x => x.created_date, OrderByType.Desc)
                                //.Mapper(x => x.user_info, x => x.user_id)
                                .Mapper(x => x.created_info, x => x.created_id)
                                .Mapper(x =>
                                {
                                    x.user_info = SqlSugarHelper.DBClient(query.server_id)
                                                    .Queryable<SysPerson>()
                                                    .Where(y => y.i_id == x.user_id)
                                                    .First();
                                    if (x.user_info != null)
                                    {
                                        x.user_dep_info = SqlSugarHelper.DBClient(query.server_id)
                                                    .Queryable<SysDepartment>()
                                                    .Where(y => y.i_id == x.user_info.i_department_base)
                                                    .First();
                                    }
                                    x.files = SqlSugarHelper.DBClient(query.server_id)
                                                    .Queryable<ErpTradeReqFile>()
                                                    .Where(y => y.req_id == x.id)
                                                    .ToList();
                                })
                                .ToListAsync();

            var data = _imapper.Map<List<ErpTradeReq>, List<ErpTradeReqDto>>(list);

            return data;
        }

        /// <summary>
        /// 获取各状态数量
        /// </summary>
        public async Task<Dictionary<string, object>> GetCountAsync(string server_id)
        {
            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpTradeReq>()
                                .ToListAsync();

            var noSubmit = list.Where(x => x.state == 1).Count();
            var inChenk = list.Where(x => x.state == 2).Count();
            var finishChenk = list.Where(x => x.state == 3).Count();
            var refuseChenk = list.Where(x => x.state == 4).Count();
            var revoke = list.Where(x => x.state == 5).Count();

            var dic = new Dictionary<string, object>();
            dic.Add("noSubmit",Convert.ToDecimal(noSubmit));
            dic.Add("inChenk", Convert.ToDecimal(inChenk));
            dic.Add("finishChenk", Convert.ToDecimal(finishChenk));
            dic.Add("refuseChenk", Convert.ToDecimal(refuseChenk));
            dic.Add("revoke", Convert.ToDecimal(revoke));

            return dic;
        }

        /// <summary>
        /// 获取会员申请详情
        /// </summary>
        public async Task<ErpTradeReqDto> LookDetailAsync(
            string server_id, decimal? user_id, decimal id)
        {

            //查询
            var info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpTradeReq>()
                                .Where(x => x.id == id)
                                .Mapper(x => x.user_info, x => x.user_id)
                                .Mapper(x => x.created_info, x => x.created_id)
                                .Mapper(x =>
                                {
                                    x.files = SqlSugarHelper.DBClient(server_id)
                                                    .Queryable<ErpTradeReqFile>()
                                                    .Where(y => y.req_id == x.id)
                                                    .ToList();
                                })
                                .FirstAsync();

            var ids = new List<int>();

            if (info == null)
            {
                throw new Exception($"未找到会员申请信息，id={id}");
            }

            ids.Add(Convert.ToInt32(info.id));

            var all = await _erpFlowRecordImp.GetListAsync(server_id, user_id,
                new FlowRecordQuery()
                {
                    detail_ids = ids
                });

            if (info.state == 2)//审核中
            {
                var flow_info = all.FirstOrDefault(x => x.detail_id == info.id);
                if (flow_info != null)
                {
                    info.user_ids = flow_info.state_child_id;
                    info.user_names = flow_info.state_child_name;
                }
            }
            var data = _imapper.Map<ErpTradeReq, ErpTradeReqDto>(info);

            return data;
        }

        /// <summary>
        /// 获取自己保存的草稿
        /// </summary>
        public async Task<ErpTradeReqDto> GetByUserAsync(
            string server_id, decimal? user_id)
        {

            //查询
            var info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpTradeReq>()
                                .Where(x => x.created_id == user_id && x.state == 1)
                                .Mapper(x => x.user_info, x => x.user_id)
                                .Mapper(x => x.created_info, x => x.created_id)
                                .Mapper(x =>
                                {
                                    x.files = SqlSugarHelper.DBClient(server_id)
                                                    .Queryable<ErpTradeReqFile>()
                                                    .Where(y => y.req_id == x.id)
                                                    .ToList();
                                })
                                .FirstAsync();

            var data = _imapper.Map<ErpTradeReq, ErpTradeReqDto>(info);

            return data;
        }

        /// <summary>
        /// 新增/编辑草稿
        /// </summary>
        public async Task<ErpTradeReqDto> CreateOrUpdateAsync(
            string server_id, decimal? user_id, CreateOrUpdateErpTradeReq input)
        {
            var info = new ErpTradeReq();
            if (input.id.HasValue && input.id != 0)
            {
                info = await SqlSugarHelper.DBClient(server_id)
                       .Queryable<ErpTradeReq>()
                       .FirstAsync(x => x.id == input.id);
                if (info == null)
                {
                    throw new Exception($"未找到会员申请信息，id={input.id}");
                }

                _imapper.Map<CreateOrUpdateErpTradeReq, ErpTradeReq>(input, info);

                info.SetUpdate(user_id);

                await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync();

            }
            else
            {
                info = _imapper.Map<CreateOrUpdateErpTradeReq, ErpTradeReq>(input);
                info.id = ERPBll.Tools.GetEngineID(server_id);
                info.SetCreate(user_id);

                await SqlSugarHelper.DBClient(server_id).Insertable(info).ExecuteCommandAsync();

            }

            //删除旧附件
            await SqlSugarHelper.DBClient(server_id)
                            .Deleteable<ErpTradeReqFile>()
                            .Where(x => x.req_id == info.id)
                            .ExecuteCommandAsync();

            input.files.ForEach(x => { 
                x.id = Tools.GetEngineID(server_id);
                x.SetCreate(user_id, info.id);
            });
            //添加新附件
            await SqlSugarHelper.DBClient(server_id)
                            .Insertable(input.files)
                            .ExecuteCommandAsync();

            return _imapper.Map<ErpTradeReq, ErpTradeReqDto>(info);
        }

        /// <summary>
        /// 提交
        /// </summary>
        public async Task<ErpTradeReqDto> SubmitAsync(string server_id, UpdateErpTradeReqState input)
        {
            var info = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpTradeReq>()
                                .FirstAsync(x => x.id == input.id);
            if (info == null)
            {
                throw new Exception($"未找到申请记录，id={input.id}");
            }

            if (info.state != 1)
            {
                throw new Exception($"状态错误，只允许草稿状态提交");
            }

            if (string.IsNullOrWhiteSpace(input.floe_code) || input.flow_id == 0)
            {
                throw new Exception($"流程id和流程编号不能为空");
            }

            info.flow_id = input.flow_id;
            info.floe_code = input.floe_code;
            info.state = 2;
            info.code = await _iErpTradeMainImp.GetCodeAsync();

            await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync();

            string user_name = await _iUserRedisImp.GetNameByIdAsync(Convert.ToInt32(info.user_id).ToString());

            await _iErpFlowRecordImp.UpdateAsync(
                    server_id, Convert.ToInt32(info.flow_id), Convert.ToInt32(info.id), TradeReqMessage.GetContent(info, user_name));

            return _imapper.Map<ErpTradeReq, ErpTradeReqDto>(info);
        }

        //[CapSubscribe(EventMessages.PartyMemberFinish, Group = "TradeReq")]
        //public async Task UpdateStateAsync(UpdateErpFlowRecordState input)
        //{
        //    var info = await SqlSugarHelper.DBClient("60.191.59.11")
        //                        .Queryable<ErpTradeReq>()
        //                        .FirstAsync(x => x.flow_id == input.flow_id);
        //    if (info != null)
        //    {

        //        Console.WriteLine("党建会员申请通过");

        //        if (input.state == FlowRecordState.审核通过)
        //        {
        //            info.state = 3;
        //        }
        //        else if (input.state == FlowRecordState.审核拒绝)
        //        {
        //            info.state = 4;
        //        }
        //        else if (input.state == FlowRecordState.已撤销)
        //        {
        //            info.state = 5;
        //        }

        //        await SqlSugarHelper.DBClient("60.191.59.11").Updateable(info).ExecuteCommandAsync();
        //    }
        //}
    }
}
