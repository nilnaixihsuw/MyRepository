﻿using AutoMapper;
using ERPBll.PartyConstructionManage.ErpTradeMains.Contracts;
using ERPBll.RedisManage.Extension;
using ERPBll.SystemManage.SysOpLogs.Contracts;
using ERPCore;
using ERPCore.Attributes;
using ERPCore.Auditing;
using ERPCore.Entity;
using ERPCore.Enums;
using ERPCore.Extensions;
using ERPCore.Helpers;
using ERPDal;
using ERPModel.InsuranceManage;
using ERPModel.PartyConstructionManage.ErpTradeMains;
using ERPModel.SystemManage;
using ERPModel.SystemManage.SysOpLogs;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace ERPBll.PartyConstructionManage.ErpTradeMains.Services
{
    /// <summary>
    /// 工会会员管理
    /// </summary>
    public class ErpTradeMainImp : IErpTradeMainImp
    {
        private readonly IMapper _imapper;
        private readonly IWarehouseRedisManageImp _iWarehouseRedisManageImp;
        private readonly IErpTradeMainFileImp _iErpTradeMainFileImp;
        private readonly ISysOpLogImp _iSysOpLogImp;
        public ErpTradeMainImp(
            IMapper imapper,
            IWarehouseRedisManageImp iWarehouseRedisManageImp,
            IErpTradeMainFileImp iErpTradeMainFileImp,
             ISysOpLogImp iSysOpLogImp)
        {
            _imapper = imapper;
            _iWarehouseRedisManageImp = iWarehouseRedisManageImp;
            _iErpTradeMainFileImp = iErpTradeMainFileImp;
            _iSysOpLogImp = iSysOpLogImp;
        }

        public async Task<(List<ErpTradeMainDto>, int)> GetByPageAsync(
            string server_id, decimal? user_id, ErpTradeMainQuery query)
        {
            RefAsync<int> totalCount = 0;

            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<ErpTradeMain>()
                                .Where(query.ToExp())
                                .Mapper(async x => {
                                    x.files = await _iErpTradeMainFileImp.GetListAsync(server_id, x.id);
                                })
                                .OrderBy(x => x.join_trade, OrderByType.Desc)
                                .ToPageListAsync(query.page_index, query.page_size, totalCount);

            var data = _imapper.Map<List<ErpTradeMain>, List<ErpTradeMainDto>>(list);
            int index = 0;
            data.ForEach(x =>
            {
                x.index = ++index;
                x.string_labour = x.labour.ToString();
                var insureds = string.IsNullOrWhiteSpace(x.insured) ? new List<string>().ToArray() : x.insured.Split(',');
                x.insured_ids = new List<int>();
                foreach (var item in insureds)
                {
                    x.insured_ids.Add(Convert.ToInt32(item));
                }
                x.string_sign_labour = x.sign_labour.ToString();
                x.string_state = x.state.ToString();
                x.string_is_member = x.is_member.ToString();
                x.string_is_admin_add = x.is_admin_add.ToString();
                x.string_birthday = x.birthday.HasValue ? x.birthday.Value.ToString("yyyy-MM") : "";
            });
            return (data, totalCount);
        }

        /// <summary>
        /// 新增/编辑
        /// </summary>
        public async Task<ErpTradeMainDto> CreateOrUpdateAsync(
            string server_id, decimal? user_id, CreateOrUpdateErpTradeMain input)
        {
            var info = new ErpTradeMain();
            if (input.id.HasValue && input.id != 0)
            {
                info = await SqlSugarHelper.DBClient(server_id)
                       .Queryable<ErpTradeMain>()
                       .FirstAsync(x => x.id == input.id);
                if (info == null)
                {
                    throw new Exception($"未找到会员信息，id={input.id}");
                }

                input.id = info.id;
                input.card_date = info.card_date;

                 _imapper.Map<CreateOrUpdateErpTradeMain, ErpTradeMain>(input, info);

                var insured = "";
                if (input.insured_ids != null && input.insured_ids.Count > 0)
                {
                    foreach (var item in input.insured_ids)
                    {
                        insured += (item.ToString() + ",");
                    }
                    insured = insured.TrimEnd(',');
                }
                info.insured = insured;

                info.SetUpdate(user_id);

                var res =await SqlSugarHelper.DBClient(server_id).Updateable(info).ExecuteCommandAsync() > 0;
            }
            else
            {
                info = _imapper.Map<CreateOrUpdateErpTradeMain, ErpTradeMain>(input);
                info.id = ERPBll.Tools.GetEngineID(server_id);
                info.SetCreate(user_id);

                var insured = "";
                if (input.insured_ids != null && input.insured_ids.Count > 0)
                {
                    foreach (var item in input.insured_ids)
                    {
                        insured += (item.ToString() + ",");
                    }
                    insured = insured.TrimEnd(',');
                }
                info.insured = insured;

                var res = await SqlSugarHelper.DBClient(server_id).Insertable(info).ExecuteCommandAsync() > 0;
            }

            //上传附件
            if (input.files != null && input.files.Count > 0)
            {
                input.files.ForEach(r =>
                {
                    r.SetCreate(user_id, info.id);
                    r.id = ERPBll.Tools.GetEngineID(server_id);
                });
                await _iErpTradeMainFileImp.CreateAsync(server_id, input.files);
            }

            return _imapper.Map<ErpTradeMain, ErpTradeMainDto>(info);
        }

        /// <summary>
        /// 新增时获取档案编号
        /// </summary>
        public async Task<string> GetCodeAsync()
        {
            string code = await _iWarehouseRedisManageImp.GetBatno(DateTime.Now, 4);
            if (string.IsNullOrWhiteSpace(code))
            {
                code = DateTime.Now.ToString("yyyyMMdd") + "0001";
                await _iWarehouseRedisManageImp.SetBatno(DateTime.Now, 1, 4);
            }
            return code;
        }

        /// <summary>
        /// 删除
        /// </summary>
        public async Task<bool> DeleteAsync(string server_id, List<decimal> ids)
        {
            var res = await SqlSugarHelper.DBClient(server_id)
                    .Deleteable<ErpTradeMain>()
                    .Where(x => ids.Contains(x.id))
                    .ExecuteCommandAsync() > 0;

            await _iErpTradeMainFileImp.DeleteAsync(server_id, ids);

            return res;
        }

        /// <summary>
        /// 导入
        /// </summary>
        public async Task<bool> ImportErpInsuranceMainData(string server_id, List<ErpTradeMain> list, List<ErpTradeMain> upList)
        {
            return await Task.Run(() =>
            {
                var result = false;
                using (var db = SqlSugarHelper.DBClient(server_id))
                {
                    db.BeginTran();
                    if (list != null && list.Count > 0)
                    {
                        list.ForEach(async x => {
                            x.code = await GetCodeAsync();
                        });
                        ListHelper.ListSplit(100, list, split =>
                        {
                            result = db.Insertable(split).ExecuteCommand() > 0;
                            return split;
                        });
                    }
                    if (upList != null && upList.Count > 0)
                    {
                        ListHelper.ListSplit(100, upList, split =>
                        {
                            result = db.Updateable(split).ExecuteCommand() > 0;
                            return split;
                        });
                    }
                    db.CommitTran();
                }
                return result;
            });
        }

        public async Task<(bool, List<string>)> Import(ImportErpInsuranceMain input)
        {
            var title = new Dictionary<string, string>()
            {
                { "序号", "index"},
                { "档案号", "code"},
                { "姓名", "name"},
                { "性别", "string_sex"},
                { "手机号", "phone"},
                { "出生年月", "string_birthday"},
                { "参加工作时间", "string_join_date"},
                { "入会时间", "string_join_trade"},
                { "所在单位", "company"},
                { "会员证号", "trade_code"},
                { "领证日期", "string_card_date"}
            };

            var result = new byte[] { };
            using (var ms = new MemoryStream())
            {
                input.file.CopyTo(ms);
                ms.Position = 0;
                result = ms.ToArray();
            }
            var dt = ExcelImportHelper.ReadBytesToDataTable(result, title);

            int index = 2;
            var errlist = new List<string>();

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                for (int j = 0; j < dt.Columns.Count; j++)
                {
                    if (j == 2)
                    {
                        //检查必填项是否为空
                        if (string.IsNullOrEmpty(dt.Rows[i][j].ToString()))
                            errlist.Add("第" + index + "行姓名未填写，无法导入");
                    }
                    else if (j == 4)
                    {
                        if (string.IsNullOrEmpty(dt.Rows[i][j].ToString()))
                            errlist.Add("第" + index + "行手机号未填写，无法导入");
                        if (!System.Text.RegularExpressions.Regex.IsMatch(dt.Rows[i][j].ToString(), @"^1[3456789]\d{9}$"))
                            errlist.Add("第" + index + "行手机号格式错误，无法导入");
                    }
                }
                index++;
            }

            //如果有错误
            if (errlist.Count > 0)
            {
                return (false, errlist);
            }

            var impotList = dt.ToImportDataList<ImportErpTradeMain>();

            if (impotList == null || impotList.Count < 1)
            {
                throw new Exception("导入内容不能为空");
            }

            var list = _imapper.Map<List<ImportErpTradeMain>, List<ErpTradeMain>>(impotList);
            var upList = new List<ErpTradeMain>();
            var inList = new List<ErpTradeMain>();

            foreach (var item in list)
            {
                var info = await SqlSugarHelper.DBClient(input.server_id)
                            .Queryable<ErpTradeMain>()
                            .FirstAsync(x => x.name == item.name && x.phone == item.phone);

                //覆盖
                if (input.type == 1)
                {
                    if (info != null)
                    {
                        var res = upList.Where(x => x.name == item.name && x.phone == item.phone).ToList().Count() > 0;
                        if (!res)
                        {
                            info.sex = item.sex;
                            info.birthday = item.birthday;
                            info.join_date = item.join_date;
                            info.company = item.company;
                            info.trade_code = item.trade_code;
                            info.join_trade = item.join_trade;
                            info.card_date = item.card_date;
                            upList.Add(info);
                        }
                    }
                    else
                    {
                        item.id = Tools.GetEngineID(input.server_id);
                        item.code = await GetCodeAsync();
                        var res = inList.Where(x => x.name == item.name && x.phone == item.phone).ToList().Count() > 0;
                        if (!res)
                        {
                            inList.Add(item);
                        }
                    }
                }
                else
                {
                    if (info == null)
                    {
                        var res = inList.Where(x => x.name == item.name && x.phone == item.phone).ToList().Count() > 0;
                        if (!res)
                        {
                            item.id = Tools.GetEngineID(input.server_id);
                            item.code = await GetCodeAsync();
                            inList.Add(item);
                        }
                    }
                }
            }

            if (inList.Count < 1 && upList.Count < 1)
            {
                return (true, errlist);
            }
            return (await ImportErpInsuranceMainData(input.server_id, inList, upList), errlist);
        }
    }
}
