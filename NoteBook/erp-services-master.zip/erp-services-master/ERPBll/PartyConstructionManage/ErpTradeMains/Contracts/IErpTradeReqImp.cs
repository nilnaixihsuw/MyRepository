﻿using ERPCore.Auditing;
using ERPCore.Entity;
using ERPModel.PartyConstructionManage.ErpTradeMains;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.PartyConstructionManage.ErpTradeMains.Contracts
{
    public interface IErpTradeReqImp
    {
        /// <summary>
        /// 分页查询
        /// </summary>
        Task<(List<ErpTradeReqDto>, int)> GetByPageAsync(string server_id, decimal? user_id, ErpTradeReqQuery input);

        /// <summary>
        /// 分页查询待我处理
        /// </summary>
        Task<(List<ErpTradeReqDto>, int)> GetWaitByPageAsync(string server_id, decimal? user_id, ErpTradeReqQuery input);

        /// <summary>
        /// 新增/编辑
        /// </summary>
        Task<ErpTradeReqDto> CreateOrUpdateAsync(string server_id, decimal? user_id, CreateOrUpdateErpTradeReq input);

        /// <summary>
        /// 提交
        /// </summary>
        Task<ErpTradeReqDto> SubmitAsync(string server_id, UpdateErpTradeReqState input);

        /// <summary>
        /// 获取自己保存的草稿
        /// </summary>
        Task<ErpTradeReqDto> GetByUserAsync(string server_id, decimal? user_id);

        /// <summary>
        /// 获取会员申请详情
        /// </summary>
        Task<ErpTradeReqDto> LookDetailAsync(string server_id, decimal? user_id, decimal id);

        /// <summary>
        /// 获取各状态数量
        /// </summary>
        Task<Dictionary<string, object>> GetCountAsync(string server_id);

        /// <summary>
        /// 获取审批完成的会员申请
        /// </summary>
        Task<List<ErpTradeReqDto>> GetReqAsync(ConfirmTradeReqQuery query);

        /// <summary>
        /// 确认入会
        /// </summary>
        Task<ErpTradeMainDto> ConfirmAsync(string server_id, ClientInformation client, IClientInfoProvider client_pro, decimal id);

        /// <summary>
        /// 撤销入会
        /// </summary>
        Task<bool> RevokeAsync(string server_id, decimal id);
    }
}
