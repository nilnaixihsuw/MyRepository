﻿using ERPCore.ORM;
using ERPModel.PartyConstructionManage.ErpTradeMains;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.PartyConstructionManage.ErpTradeMains.Contracts
{
    public interface IErpTradeMainFileImp
    {
        /// <summary>
        /// 上传附件
        /// </summary>
        Task<bool> CreateAsync(string server_id, List<ErpTradeMainFile> list);

        /// <summary>
        /// 获取附件列表
        /// </summary>
        Task<List<ErpTradeMainFile>> GetListAsync(string server_id, decimal tradeId);

        /// <summary>
        /// 根据会员id删除附件
        /// </summary>
        Task<bool> DeleteAsync(string server_id, List<decimal> trade_ids);
    }
}
