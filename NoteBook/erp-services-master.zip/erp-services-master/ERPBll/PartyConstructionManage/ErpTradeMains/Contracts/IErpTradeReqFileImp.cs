﻿using ERPModel.PartyConstructionManage.ErpTradeMains;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.PartyConstructionManage.ErpTradeMains.Contracts
{
    public interface IErpTradeReqFileImp
    {
        /// <summary>
        /// 上传附件
        /// </summary>
        Task<bool> CreateAsync(string server_id, List<ErpTradeReqFile> list);

        /// <summary>
        /// 根据会员申请id集合删除附件
        /// </summary>
        Task<bool> DeleteAsync(string server_id, List<decimal> req_ids);

        /// <summary>
        /// 获取附件列表
        /// </summary>
        Task<List<ErpTradeReqFile>> GetListAsync(string server_id, decimal req_id);
    }
}
