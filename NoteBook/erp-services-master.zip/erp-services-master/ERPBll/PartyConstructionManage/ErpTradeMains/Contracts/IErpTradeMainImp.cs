﻿using ERPCore.Auditing;
using ERPCore.Entity;
using ERPModel.InsuranceManage;
using ERPModel.PartyConstructionManage.ErpTradeMains;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ERPBll.PartyConstructionManage.ErpTradeMains.Contracts
{
    public interface IErpTradeMainImp
    {
        /// <summary>
        /// 会员分页查询
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        Task<(List<ErpTradeMainDto>, int)> GetByPageAsync(
            string server_id, decimal? user_id, ErpTradeMainQuery query);

        /// <summary>
        /// 新增/编辑
        /// </summary>
        Task<ErpTradeMainDto> CreateOrUpdateAsync(
            string server_id, decimal? user_id, CreateOrUpdateErpTradeMain input);

        /// <summary>
        /// 新增时获取档案编号
        /// </summary>
        Task<string> GetCodeAsync();

        /// <summary>
        /// 删除
        /// </summary>
        Task<bool> DeleteAsync(string server_id, List<decimal> ids);

        /// <summary>
        /// 导入工会会员信息
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        Task<(bool, List<string>)> Import(ImportErpInsuranceMain input);
    }
}
