﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPModel.PartyConstructionManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.PartyConstructionManage
{
    public interface IErpPartyUserJoinImp : IBusinessRepository<ErpPartyUserJoin>
    {
        Task<bool> AddErpPartyUserJoin(string server_id, ErpPartyUserJoin context, ClientInformation client);
        Task<Tuple<List<ErpPartyUserJoin>,int>> QueryErpPartyUserJoinPageList(string server_id, BaseRequest<ErpPartyUserJoin> request, string v);
        Task<List<ErpPartyUserJoin>> QueryErpPartyUserJoinList(string server_id, BaseRequest<ErpPartyUserJoin> request, string v);
        Task<bool> BatchDelete(string server_id, List<decimal> context);
    }
}