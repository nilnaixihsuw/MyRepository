﻿using ERPCore.ORM;
using ERPDal.PartyConstructionManage;
using ERPModel.PartyConstructionManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;

namespace ERPBll.PartyConstructionManage
{
    public class ErpPartyHonorFileImp : BusinessRespository<ErpPartyHonorFile, IErpPartyHonorFileDataImp>, IErpPartyHonorFileImp
    {
        public ErpPartyHonorFileImp(IErpPartyHonorFileDataImp dataImp): base(dataImp)
        {

        }
    }
}