﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPModel.PartyConstructionManage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.PartyConstructionManage
{
    public interface IErpPartyHonorOrganImp : IBusinessRepository<ErpPartyHonorOrgan>
    {
        Task<bool> AddErpPartyHonorOrgan(string server_id, ErpPartyHonorOrgan context, ClientInformation client);
        Task<Tuple<List<ErpPartyHonorOrgan>,int>> QueryErpPartyHonorOrganPageList(string server_id, BaseRequest<ErpPartyHonorOrgan> request, string v);
        Task<List<ErpPartyHonorOrgan>> QueryErpPartyHonorOrganList(string server_id, BaseRequest<ErpPartyHonorOrgan> request, string v);
        Task<bool> BatchDelete(string server_id, List<decimal> context);
    }
}