﻿using ERPCore.Entity;
using ERPCore.ORM;
using ERPDal.PartyConstructionManage;
using ERPModel.PartyConstructionManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using System.Linq.Expressions;
using ERPBll.RedisManage.Users;
using System.Text;
using ERPBll.FlowManage.Contracts;
using ERPModel.FlowManage.FlowRecords;
using ERPModel.FlowManage;
using ERPModel.FlowManage.FlowSteps;
using ERPDal;

namespace ERPBll.PartyConstructionManage
{
    public class ErpPartyActivityImp : BusinessRespository<ErpPartyActivity, IErpPartyActivityDataImp>, IErpPartyActivityImp
    {
        private readonly IUserRedisImp _iUserRedisImp;
        private readonly IErpFlowRecordImp _iErpFlowRecordImp;
        private readonly IErpPartyUserImp _iErpPartyUserImp;

        public ErpPartyActivityImp(
            IErpPartyUserImp iErpPartyUserImp,
            IErpFlowRecordImp iErpFlowRecordImp,
            IUserRedisImp iUserRedisImp,
            IErpPartyActivityDataImp dataImp) : base(dataImp)
        {
            _iErpPartyUserImp = iErpPartyUserImp;
            _iUserRedisImp = iUserRedisImp;
            _iErpFlowRecordImp = iErpFlowRecordImp;
        }

        public async Task<bool> AddErpPartyActivity(string server_id, ErpPartyActivity context, ClientInformation client)
        {
            if (context.id > 0)
            {
                //编辑
                context.update_date = DateTime.Now;
                context.update_id = client.i_id;
                var old = await Get(server_id, context.id);
                context.created_date = old.created_date;
                context.created_id = old.created_id;
                context.state = old.state;
                if (context.ex_keyword != null && context.ex_keyword.Count > 0)
                    context.keyword = string.Join(",", context.ex_keyword);

                //党组织活动图片
                var pics = new List<ErpPartyActivityImg>();
                if (context.ex_pics != null && context.ex_pics.Count > 0)
                {
                    context.ex_pics.ForEach(item =>
                    {
                        item.activity_id = context.id;
                        item.created_id = client.i_id;
                        item.created_date = DateTime.Now;
                        item.type = 2;
                    });
                    pics.AddRange(context.ex_pics);
                }
                if (context.ex_files != null && context.ex_files.Count > 0)
                {
                    context.ex_files.ForEach(item =>
                    {
                        item.activity_id = context.id;
                        item.created_id = client.i_id;
                        item.created_date = DateTime.Now;
                        item.type = 1;
                    });
                    pics.AddRange(context.ex_files);
                }
                //党组织活动类别明细
                var actTypes = new List<ErpPartyActivityType>();
                if (context.ex_types != null && context.ex_types.Count > 0)
                {
                    actTypes.AddRange(context.ex_types.Select(it => new ErpPartyActivityType
                    {
                        activity_id = context.id,
                        created_date = DateTime.Now,
                        created_id = client.i_id,
                        name = it
                    }));
                }
                //参与人员
                var persons = new List<ErpActivityUser>();
                if (context.ex_user_ids != null && context.ex_user_ids.Count > 0)
                {
                    persons.AddRange(context.ex_user_ids.Select(it => new ErpActivityUser
                    {
                        activity_id = context.id,
                        created_date = DateTime.Now,
                        created_id = client.i_id,
                        user_id = it,
                        type = 1
                    }));
                }
                if (context.ex_party_ids != null && context.ex_party_ids.Count > 0)
                {
                    persons.AddRange(context.ex_party_ids.Select(it => new ErpActivityUser
                    {
                        activity_id = context.id,
                        created_date = DateTime.Now,
                        created_id = client.i_id,
                        user_id = it,
                        type = 2
                    }));
                }

                return await _dataImp.UpdateErpPartyActivity(server_id, context, pics, actTypes, persons);
            }
            else
            {
                //新增
                context.id = await _dataImp.GetId(server_id, "SEQ_COMMON");
                context.created_date = DateTime.Now;
                context.created_id = client.i_id;
                if (context.ex_keyword != null && context.ex_keyword.Count > 0)
                    context.keyword = string.Join(",", context.ex_keyword);
                context.state = 1;

                //党组织活动图片
                var pics = new List<ErpPartyActivityImg>();
                if (context.ex_pics != null && context.ex_pics.Count > 0)
                {
                    context.ex_pics.ForEach(item =>
                    {
                        item.activity_id = context.id;
                        item.created_id = client.i_id;
                        item.created_date = DateTime.Now;
                        item.type = 2;
                    });
                    pics.AddRange(context.ex_pics);
                }
                if (context.ex_files != null && context.ex_files.Count > 0)
                {
                    context.ex_files.ForEach(item =>
                    {
                        item.activity_id = context.id;
                        item.created_id = client.i_id;
                        item.created_date = DateTime.Now;
                        item.type = 1;
                    });
                    pics.AddRange(context.ex_files);
                }
                //党组织活动类别明细
                var actTypes = new List<ErpPartyActivityType>();
                if (context.ex_types != null && context.ex_types.Count > 0)
                {
                    actTypes.AddRange(context.ex_types.Select(it => new ErpPartyActivityType
                    {
                        activity_id = context.id,
                        created_date = DateTime.Now,
                        created_id = client.i_id,
                        name = it
                    }));
                }
                //参与人员
                var persons = new List<ErpActivityUser>();
                if (context.ex_user_ids != null && context.ex_user_ids.Count > 0)
                {
                    persons.AddRange(context.ex_user_ids.Select(it => new ErpActivityUser
                    {
                        activity_id = context.id,
                        created_date = DateTime.Now,
                        created_id = client.i_id,
                        user_id = it,
                        type = 1
                    }));
                }
                if (context.ex_party_ids != null && context.ex_party_ids.Count > 0)
                {
                    persons.AddRange(context.ex_party_ids.Select(it => new ErpActivityUser
                    {
                        activity_id = context.id,
                        created_date = DateTime.Now,
                        created_id = client.i_id,
                        user_id = it,
                        type = 2
                    }));
                }

                // 发起党组织活动流程
                var name = await _iUserRedisImp.GetNameByIdAsync(context.created_id.ToString());
                StringBuilder sb = new StringBuilder();
                sb.AppendLine($"预定人:{name}");
                sb.AppendLine($"开始时间:{context.start_date}");
                sb.AppendLine($"结束时间:{context.end_date}");
                sb.AppendLine($"活动内容:{context.content}");
                var person = await _iErpPartyUserImp.Get(server_id, context.audit_users);
                // 发起流程
                var flowRecord = await _iErpFlowRecordImp.AddAsync(server_id, client.i_id,
                    new CreateErpFlowRecord
                    {
                        title = $"{name}提交的党组织活动申请",
                        content = sb.ToString(),
                        type = 2,
                        object_id = (int)FlowRecordType.党组织活动申请,
                        user_id = context.created_id,
                        flow_steps = new List<CreateErpFlowStep>()
                        {
                                new CreateErpFlowStep()
                                {
                                    user_ids = new List<decimal> { person.user_id.Value }
                                }
                        }
                    });

                if (flowRecord == null)
                {
                    throw new Exception("发起流程失败");
                }
                context.flow_id = flowRecord.id;
                context.flow_code = flowRecord.code;
                await _iErpFlowRecordImp.UpdateAsync(server_id, Convert.ToInt32(context.flow_id), Convert.ToInt32(context.id), "");

                return await _dataImp.AddErpPartyActivity(server_id, context, pics, actTypes, persons);
            }
        }

        public async Task<Tuple<List<ErpPartyActivity>, int>> QueryErpPartyActivityPageList(string server_id, BaseRequest<ErpPartyActivity> request, string v, ClientInformation client)
        {
            RefAsync<int> total = 0;
            var exp = await GetExp(request);
            var q = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpPartyActivity>()
                                                                    .WhereIF(request.ToExp() != null, request.ToExp(exp))
                                                                    .WhereIF(!string.IsNullOrEmpty(v), v)
                                                                    .OrderByIF(!string.IsNullOrEmpty(request.orderby), request.orderby)
                                                                    .ToPageListAsync(request.page_index, request.page_size, total);
            var list = await _dataImp.ExtList(request.server_id, q);
            if (list.Count > 0)
            {
                var all = await _iErpFlowRecordImp.GetListAsync(request.server_id, client.i_id,
                   new FlowRecordQuery()
                   {
                       detail_ids = list.Select(x => (int)x.id).ToList()
                   }
                );
                foreach (var item in list)
                {
                    if (item.state == 1)//处理中
                    {
                        var info = all.FirstOrDefault(x => x.detail_id == item.id);
                        if (info != null)
                        {
                            item.user_ids = info.state_child_id;
                            item.user_names = info.state_child_name;
                        }
                    }
                }
            }
            return new Tuple<List<ErpPartyActivity>, int>(list, total);
        }

        public async Task<List<ErpPartyActivity>> QueryErpPartyActivityList(string server_id, BaseRequest<ErpPartyActivity> request, string v, ClientInformation client)
        {
            var exp = await GetExp(request);
            var q = await SqlSugarHelper.DBClient(request.server_id).Queryable<ErpPartyActivity>()
                                                                    .WhereIF(request.ToExp() != null, request.ToExp(exp))
                                                                    .WhereIF(!string.IsNullOrEmpty(v), v)
                                                                    .OrderByIF(!string.IsNullOrEmpty(request.orderby), request.orderby)
                                                                    .ToListAsync();
            var list = await _dataImp.ExtList(request.server_id, q);
            if (list.Count > 0)
            {
                var all = await _iErpFlowRecordImp.GetListAsync(request.server_id, client.i_id,
                   new FlowRecordQuery()
                   {
                       detail_ids = list.Select(x => (int)x.id).ToList()
                   }
                );
                foreach (var item in list)
                {
                    if (item.state == 1)//处理中
                    {
                        var info = all.FirstOrDefault(x => x.detail_id == item.id);
                        if (info != null)
                        {
                            item.user_ids = info.state_child_id;
                            item.user_names = info.state_child_name;
                        }
                    }
                }
            }
            return list;
        }

        public async Task<bool> BatchDelete(string server_id, List<decimal> context)
        {
            return await _dataImp.BatchDelete(server_id, context);
        }

        private async Task<List<Expression<Func<ErpPartyActivity, bool>>>> GetExp(BaseRequest<ErpPartyActivity> request)
        {
            var r = new List<Expression<Func<ErpPartyActivity, bool>>>();

            return r;
        }

        public async Task<ErpPartyActivity> Detail(string server_id, decimal id, ClientInformation client)
        {
            var result = await Get(server_id, id);
            if (result != null && result.id > 0)
            {
                var all = await _iErpFlowRecordImp.GetListAsync(server_id, client.i_id,
                      new FlowRecordQuery()
                      {
                          detail_ids = new List<int>() { (int)result.id }
                      }
                   );
                if (result.state == 1)//处理中
                {
                    var info = all.FirstOrDefault(x => x.detail_id == result.id);
                    if (info != null)
                    {
                        result.user_ids = info.state_child_id;
                        result.user_names = info.state_child_name;
                    }
                }
            }
            return result;
        }
    }
}