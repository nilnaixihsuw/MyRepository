﻿using ERPCore.ORM;
using ERPDal.PartyConstructionManage;
using ERPModel.PartyConstructionManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using ERPCore.Entity;
using ERPModel.ApiModel.EnterpriseManage.PartyConstructionManage;

namespace ERPBll.PartyConstructionManage
{
    public class ErpPartyUserImp : BusinessRespository<ErpPartyUser, IErpPartyUserDataImp>, IErpPartyUserImp
    {
        private readonly IErpPartyUserDevDataImp _iErpPartyUserDevDataImp;
        private readonly IErpPartyUserDetailDataImp _iErpPartyUserDetailDataImp;
        private readonly IErpPartyUserJoinDataImp _iErpPartyUserJoinDataImp;

        public ErpPartyUserImp(
            IErpPartyUserJoinDataImp iErpPartyUserJoinDataImp,
            IErpPartyUserDetailDataImp iErpPartyUserDetailDataImp,
            IErpPartyUserDevDataImp iErpPartyUserDevDataImp,
            IErpPartyUserDataImp dataImp) : base(dataImp)
        {
            _iErpPartyUserJoinDataImp = iErpPartyUserJoinDataImp;
            _iErpPartyUserDetailDataImp = iErpPartyUserDetailDataImp;
            _iErpPartyUserDevDataImp = iErpPartyUserDevDataImp;
        }

        public async Task<bool> AddPartyMember(string server_id, ErpPartyUser context, ClientInformation client)
        {
            if (context.id > 0)
            {
                //判断人员是否存在记录
                var old = await _dataImp.Get(server_id, context.id);
                if (old.user_id != context.user_id)
                {
                    var list = await _dataImp.List(server_id, it => it.user_id == context.user_id);
                    if (list.Count > 0) throw new Exception("该人员已存在党员档案!");
                }

                //编辑
                context.update_date = DateTime.Now;
                context.update_id = client.i_id;
                context.created_date = old.created_date;
                context.created_id = old.created_id;

                //党员党籍
                var detail = new ErpPartyUserDetail();
                var details = await _iErpPartyUserDetailDataImp.List(server_id, it => it.party_user_id == context.id);
                if (details.Count > 0)
                {
                    detail = details.Find(it => it.party_user_id == context.id);
                    detail.update_date = DateTime.Now;
                    detail.update_id = client.i_id;
                }
                else
                {
                    detail.created_date = DateTime.Now;
                    detail.created_id = client.i_id;
                }

                detail.party_user_id = context.id;
                detail.party_branch = context.ex_join_party_branch;
                detail.references = context.ex_references;
                detail.party_age = context.ex_party_age;
                detail.revise_month = context.ex_revise_month;
                detail.other_party = context.ex_other_party;
                detail.in_other_date = context.ex_in_other_date;
                detail.out_other_date = context.ex_out_other_date;

                //入党信息
                var join = new ErpPartyUserJoin();
                var joins = await _iErpPartyUserJoinDataImp.List(server_id, it => it.party_user == context.id);
                if (joins.Count > 0)
                {
                    join = joins.Find(it => it.party_user == context.id);
                    join.update_id = client.i_id;
                    join.update_date = DateTime.Now;
                }
                else
                {
                    join.created_id = client.i_id;
                    join.created_date = DateTime.Now;
                }
                join.party_user = context.id;
                join.position_name = context.ex_position_name;
                join.frontline = context.ex_frontline;
                join.stratum = context.ex_stratum;
                join.request = context.ex_request;
                join.activist_date = context.ex_activist_date;
                join.contact_name = context.ex_join_contact_name;
                join.object_date = context.ex_object_date;
                join.introducer = context.ex_introducer;
                join.qualification_date = context.ex_qualification_date;
                join.member_date = context.ex_member_date;
                join.talk_result = context.ex_join_talk_result;
                join.branch = context.ex_branch;
                join.talk_name = context.ex_join_talk_name;
                join.expect_check_date = context.ex_expect_check_date;
                join.type = context.ex_join_type;
                join.positive_request = context.ex_positive_request;
                join.positive_content = context.ex_positive_content;
                join.talk_time = context.ex_join_talk_time;
                join.become_date = context.ex_become_date;
                join.check_date = context.ex_check_date;
                join.top_education = context.ex_top_education;
                join.position_leave = context.ex_position_leave;
                join.talk_time_up = context.ex_join_talk_time_up;

                //党员培养发展
                var dev = new ErpPartyUserDev();
                var devs = await _iErpPartyUserDevDataImp.List(server_id, it => it.party_user == context.id);
                if (devs.Count > 0)
                {
                    dev = devs.Find(it => it.party_user == context.id);
                    dev.update_id = client.i_id;
                    dev.update_date = DateTime.Now;
                }
                else
                {
                    dev.created_id = client.i_id;
                    dev.created_date = DateTime.Now;
                }
                dev.party_user = context.id;
                dev.report_time = context.ex_report_time;
                dev.check_time = context.ex_check_time;
                dev.check_name = context.ex_check_name;
                dev.talk_time = context.ex_talk_time;
                dev.secretary_time = context.ex_secretary_time;
                dev.contact_name = context.ex_contact_name;
                dev.train_time = context.ex_train_time;
                dev.expect_check_time = context.ex_expect_check_time;
                dev.join_time = context.ex_join_time;
                dev.talk_time_up = context.ex_talk_time_up;
                dev.talk_name = context.ex_talk_name;
                dev.check_time_up = context.ex_check_time_up;
                dev.apply_time = context.ex_apply_time;
                dev.team_talk_time = context.ex_team_talk_time;
                dev.branch_talk_time = context.ex_branch_talk_time;
                dev.check_name_up = context.ex_check_name_up;
                dev.edu_situation = context.ex_edu_situation;
                dev.content = context.ex_content;
                dev.work_situation = context.ex_work_situation;
                dev.check_result = context.ex_check_result;
                dev.public_opinion = context.ex_public_opinion;
                dev.team_opinion = context.ex_team_opinion;
                dev.board_opinion = context.ex_board_opinion;
                dev.careful_result = context.ex_careful_result;
                dev.train_result = context.ex_train_result;
                dev.expect_check_result = context.ex_expect_check_result;
                dev.talk_result = context.ex_talk_result;
                dev.board_check_result = context.ex_board_check_result;
                dev.positive_opinion = context.ex_positive_opinion;
                dev.positive_talk_result = context.ex_positive_talk_result;
                dev.positive_check_opinion = context.ex_positive_check_opinion;
                dev.positive_team_opinion = context.ex_positive_team_opinion;
                dev.positive_board_opinion = context.ex_positive_board_opinion;

                //培养发展附件
                var files = new List<ErpPartyUserDevFile>();
                if (context.ex_zzhb_files != null && context.ex_zzhb_files.Count > 0)
                    files.AddRange(AddFiles(context.id, 1, context.ex_zzhb_files, client));
                if (context.ex_rec_files != null && context.ex_zzhb_files.Count > 0)
                    files.AddRange(AddFiles(context.id, 2, context.ex_rec_files, client));
                if (context.ex_qdfzdx_files != null && context.ex_qdfzdx_files.Count > 0)
                    files.AddRange(AddFiles(context.id, 3, context.ex_qdfzdx_files, client));
                if (context.ex_fzdxzwh_files != null && context.ex_fzdxzwh_files.Count > 0)
                    files.AddRange(AddFiles(context.id, 4, context.ex_fzdxzwh_files, client));
                if (context.ex_fzdxzsjg_files != null && context.ex_fzdxzsjg_files.Count > 0)
                    files.AddRange(AddFiles(context.id, 5, context.ex_fzdxzsjg_files, client));
                if (context.ex_ysjgfj_files != null && context.ex_ysjgfj_files.Count > 0)
                    files.AddRange(AddFiles(context.id, 6, context.ex_ysjgfj_files, client));
                if (context.ex_zzzwyhsc_files != null && context.ex_zzzwyhsc_files.Count > 0)
                    files.AddRange(AddFiles(context.id, 7, context.ex_zzzwyhsc_files, client));
                if (context.ex_zzzbdhyj_files != null && context.ex_zzzbdhyj_files.Count > 0)
                    files.AddRange(AddFiles(context.id, 8, context.ex_zzzbdhyj_files, client));

                return await _dataImp.UpdatePartyMember(server_id, context, detail, join, dev, files);
            }
            else
            {
                //新增
                context.created_date = DateTime.Now;
                context.created_id = client.i_id;
                context.id = await _dataImp.GetId(server_id, "SEQ_COMMON");

                //判断人员是否存在记录
                var list = await _dataImp.List(server_id, it => it.user_id == context.user_id);
                if (list.Count > 0) throw new Exception("该人员已存在党员档案，请勿重复添加!");

                return await _dataImp.AddPartyMember(server_id, context);
            }
        }

        private List<ErpPartyUserDevFile> AddFiles(decimal? id, decimal type, List<ErpPartyUserDevFile> files, ClientInformation client)
        {
            if (files != null && files.Count > 0)
            {
                files.ForEach(item =>
                {
                    item.party_user = id;
                    item.type = type;
                    item.created_id = client.i_id;
                    item.created_date = DateTime.Now;
                });
            }
            return files;
        }

        public async Task<bool> BatchDelete(string server_id, List<decimal> context)
        {
            var list = await _dataImp.List(server_id, it => SqlFunc.ContainsArray(context, it.id));
            return await _dataImp.Deletetable(server_id, list);
        }

        public async Task<List<ErpPartyUser>> QueryPartyUerList(string server_id, ErpPartyUserRequest request, string v)
        {
            return await ExtensionList(server_id, request.ToExp(), v, request.orderby);
        }

        public async Task<Tuple<List<ErpPartyUser>, int>> QueryPartyUserPageList(string server_id, ErpPartyUserRequest request, string v)
        {
            return await ExtensionList(server_id, request.ToExp(), v, request.page_size, request.page_index, request.orderby);
        }
    }
}