﻿using ERPCore.ORM;
using ERPDal.PartyConstructionManage;
using ERPModel.PartyConstructionManage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using SqlSugar;
using ERPCore.Entity;
using ERPModel.ApiModel.EnterpriseManage.PartyConstructionManage;
using ERPModel.CommonModel;

namespace ERPBll.PartyConstructionManage
{
    public class ErpPartyOrganImp : BusinessRespository<ErpPartyOrgan, IErpPartyOrganDataImp>, IErpPartyOrganImp
    {
        public ErpPartyOrganImp(IErpPartyOrganDataImp dataImp) : base(dataImp)
        {

        }

        public async Task<bool> AddPartyOrgan(string server_id, ErpPartyOrgan context, ClientInformation client)
        {
            if (context.id > 0)
            {
                context.update_date = DateTime.Now;
                context.update_id = client.i_id;
                var old = await Get(server_id, context.id);
                context.created_date = old.created_date;
                context.created_id = old.created_id;
                if (context.parents_id == context.id) throw new Exception("不能选当前党组织作为自己的上级!");

                return await _dataImp.Update(server_id, context);
            }
            else
            {
                context.created_date = DateTime.Now;
                context.created_id = client.i_id;
                return await _dataImp.Insert(server_id, context);
            }

        }

        public async Task<bool> BatchDelete(string server_id, List<decimal> context)
        {
            var list = await _dataImp.List(server_id, it => SqlFunc.ContainsArray(context, it.id));
            return await _dataImp.Deletetable(server_id, list);
        }

        public async Task<List<ErpPartyOrgan>> GetPartyOrgTree(string server_id)
        {
            return await _dataImp.ExtList(server_id, await _dataImp.GetPartyOrgTree(server_id));
        }

        public async Task<List<PartyUserTree>> GetPartyUserTree(string server_id)
        {
            var r = new List<PartyUserTree>();
            var list = await _dataImp.ExtList(server_id, await _dataImp.GetPartyOrgTree(server_id));
            r = FindChildren(server_id, list);
            return r;
        }

        private List<PartyUserTree> FindChildren(string server_id, List<ErpPartyOrgan> list)
        {
            var r = new List<PartyUserTree>();
            list = _dataImp.ExtList(server_id, list).Result;
            if (list != null)
            {
                r.AddRange(list.Select(it => new PartyUserTree
                {
                    id = it.id,
                    name = it.name,
                    children = ListAdd(FindChildren(server_id, it.children), it.ex_users?.Select(it => new PartyUserTree
                    {
                        id = it.id,
                        name = it.name,
                        type = 2
                    }).ToList()),
                    type = 1,
                }).ToList());
            }
            return r;
        }

        private List<PartyUserTree> ListAdd(List<PartyUserTree> a, List<PartyUserTree> b)
        {
            if (b != null)
            {
                a.AddRange(b);
            }
            return a;
        }

        public async Task<List<ErpPartyOrgan>> QueryPartyOrganList(string server_id, ErpPartyOrganRequest request, string v)
        {
            return await ExtensionList(server_id, request.ToExp(), v, request.orderby);
        }

        public async Task<Tuple<List<ErpPartyOrgan>, int>> QueryPartyOrganPageList(string server_id, ErpPartyOrganRequest request, string v)
        {
            return await ExtensionList(server_id, request.ToExp(), v, request.page_size, request.page_index, request.orderby);
        }
    }
}