﻿using ERPModel.AuditLogs;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.AuditLogs
{
    public interface IAuditiLogImp
    {
        /// <summary>
        /// 分页获取
        /// </summary>
        Task<(List<SysAuditLogDto>, int)> GetByPageAsync(string server_id, SysAuditLogQueryInput input);

        /// <summary>
        /// 保存
        /// </summary>
        Task AddAsync(AuditInfo input);

        /// <summary>
        /// 获取方法执行的平均时间
        /// </summary>
        Task<List<SysAuditLogAvgDto>> GetAvgAsync(string server_id);

        /// <summary>
        /// 删除15天之前的审计日志
        /// </summary>
        Task AutoDeleteAsync(string server_id);
    }
}
