﻿using AutoMapper;
using ERPDal;
using ERPModel.AuditLogs;
using Newtonsoft.Json;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERPBll.AuditLogs
{
    public class AuditiLogImp : IAuditiLogImp
    {
        private readonly IMapper _imapper;

        public AuditiLogImp(IMapper imapper)
        {
            _imapper = imapper;
        }

        public async Task<(List<SysAuditLogDto>, int)> GetByPageAsync(string server_id, SysAuditLogQueryInput input)
        {
            RefAsync<int> totalCount = 0;

            //查询
            var list = await SqlSugarHelper.DBClient(server_id)
                                .Queryable<SysAuditLog>()
                                .Where(input.ToExp())
                                .OrderByIF(input.order_type == 0, x => x.id, OrderByType.Desc)
                                .OrderByIF(input.order_type == 1, x => x.execution_duration, OrderByType.Desc)
                                .ToPageListAsync(input.page_index, input.page_size, totalCount);

            var data = _imapper.Map<List<SysAuditLog>, List<SysAuditLogDto>>(list);
            return (data, totalCount);
        }

        /// <summary>
        /// 获取方法执行的平均时间
        /// </summary>
        public async Task<List<SysAuditLogAvgDto>> GetAvgAsync(string server_id)
        {

            var data = await SqlSugarHelper.DBClient(server_id)
                    .Queryable<SysAuditLog>()
                    .GroupBy(x => new { x.service_name, x.method_name })
                    .Select(x => new {
                        service_name = x.service_name,
                        method_name = x.method_name,
                        avg_execution_duration = Convert.ToDecimal(SqlFunc.AggregateAvg(x.execution_duration)) / 1000
                    })
                    .ToListAsync();

            var list = JsonConvert.DeserializeObject<List<SysAuditLogAvgDto>>(JsonConvert.SerializeObject(data));
            list = list.OrderByDescending(x => x.avg_execution_duration).ToList();

            return list;
        }

        public async Task AddAsync(AuditInfo input)
        {
            var info = _imapper.Map<AuditInfo, SysAuditLog>(input);
            await SqlSugarHelper.DBClient("60.191.59.11").Insertable(info).ExecuteCommandAsync();
        }

        public async Task AutoDeleteAsync(string server_id)
        {
            await SqlSugarHelper.DBClient(server_id)
                .Deleteable<SysAuditLog>()
                .Where(x => x.execution_time < DateTime.Now.AddDays(-15).Date)
                .ExecuteCommandAsync();
        }
    }
}
