﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
namespace trsocket
{
    class GPSMessageHandle : AbstractMessageHandle
    {
        
        public LoginAnswerHandler OnLoginAnswer;
        
        public StationNotifyHandler OnStationNotify;
        public MessageHandler OnMessage;
        public CommandHandler OnCommand;
        public StationFileHandler OnStatoinFile;

        public ShutdownComputerHandler OnShutDown;
        public RestartComputerHandler OnRestart;
        public SetIpPortHandler OnSetIpPort;
        public SetShutdownHandler OnSetShutdown;
        public DeleteStationItemHandler OnDeleteItem;
        public GetStationItemsHandler OnGetStatonItems;
        public GetItemsSuccessHandler OnGetStatonItemsSuccess;
        public ChangeStationIPHandler OnStationIPChange;
        public ChangeItemHandler OnItemChange;
        public GPSDataHandler OnGps;
        public StationOnline OnOnline;
        
        protected override bool Analyze(ClientInfo info)
        {
            byte[] totalBuf = this.GetBuffer(info);
            if (totalBuf.Length == 0) {
                return false;
            }
            int thisPackageSize = 0;
            if (totalBuf[0] != 0x7E)
            {
                goto lastrow;
            }
            int receivedLength = totalBuf.Length;

            if (receivedLength >= 5 )
            {
                thisPackageSize = totalBuf[1] + totalBuf[2] * 256 + totalBuf[3] * 256 * 256 + totalBuf[4] * 256 * 256 * 256;
            }

            if (receivedLength >= thisPackageSize && thisPackageSize > 0)//完成一个包
            {
                byte[] packBuf = new byte[thisPackageSize];
                Array.Copy(totalBuf, 0, packBuf, 0, thisPackageSize);
                this.HandlePackage(packBuf);
                this.RemoveLeftData(info,thisPackageSize);
                return true;
            }
            else {
                return false;
            }
            //非法数据包，发通知
        lastrow:
            this.OnAnalyzeWrong(info);
            return false;
        }
        public void HandlePackage(byte[] package)
        {
            CommandType commandType = (CommandType)(package[5] + (package[6] * 256));
            byte[] Content = new byte[package.Length - 7];
            Array.Copy(package, 7, Content, 0, package.Length - 7);
            Type TP = null;
            switch (commandType)
            {
                case CommandType.CMD_PING_ANSWER:

                    TP = typeof(DATA_PING);
                    DATA_PING answer_ping = (DATA_PING)CommonFunc.BytesToStuct(Content, TP);
                    //System.Console.Out.WriteLine("PING成功：" + answer_ping.SeqID.ToString()); 
                    break;
                case CommandType.CMD_LOGIN_ANSWER:
                    TP = typeof(DATA_CMD_LOGIN_ANSWER);
                    DATA_CMD_LOGIN_ANSWER answer = (DATA_CMD_LOGIN_ANSWER)CommonFunc.BytesToStuct(Content, TP);
                    if (OnLoginAnswer != null)
                    {
                        OnLoginAnswer(answer);
                    }

                    break;
                case CommandType.CMD_NOTIFY_STATION:
                    TP = typeof(DATA_STATION_PREDICTION);
                    DATA_STATION_PREDICTION notify = (DATA_STATION_PREDICTION)CommonFunc.BytesToStuct(Content, TP);
                    if (OnStationNotify != null)
                    {
                        OnStationNotify(notify);
                    }
                    break;
                case CommandType.CMD_MESSAGE_STATION:
                    DATA_STATION_MESSAGE message = AnyzeStationMessage(Content);// (DATA_STATION_MESSAGE)CommonFunc.BytesToStuct(Content, TP);
                    if (OnMessage != null)
                    {
                        OnMessage(message);
                    }

                    break;
                case CommandType.CMD_COMMAND_STATION:
                    TP = typeof(DATA_STATION_COMMAND);
                    DATA_STATION_COMMAND cmd = (DATA_STATION_COMMAND)CommonFunc.BytesToStuct(Content, TP);
                    HandleCommand(cmd);
                    break;
                case CommandType.CMD_FILE_STATION:
                    TP = typeof(DATA_STATION_FILE);
                    DATA_STATION_FILE file = AnyzeStationFile(Content);
                    if (OnStatoinFile != null)
                    {
                        OnStatoinFile(file);
                    }
                    break;
                case CommandType.CMD_STATION_ANSWER_ITEMS:
                    DATA_STATION_ITEMS_BACK items = AnyzeStationItems(Content);
                    if (OnGetStatonItemsSuccess != null)
                    {
                        OnGetStatonItemsSuccess(items.StationID, System.Text.Encoding.GetEncoding("gb2312").GetString(items.Content));
                    }


                    break;
                case CommandType.CMD_NOTIFY_STATION_IP:

                    TP = typeof(DATA_STATION_IP);
                    DATA_STATION_IP ipNotify = (DATA_STATION_IP)CommonFunc.BytesToStuct(Content, TP);

                    if (OnStationIPChange != null)
                    {
                        OnStationIPChange(ipNotify);
                    }



                    break;
                case CommandType.CMD_UPDATE_ITEM:

                    TP = typeof(DATA_STATION_ITEM);
                    DATA_STATION_ITEM itemInfo = (DATA_STATION_ITEM)CommonFunc.BytesToStuct(Content, TP);
                    HandleItemChaged(itemInfo);



                    break;
                case CommandType.CMD_GPS_INFO:

                    TP = typeof(DATA_GPS);
                    DATA_GPS gps = (DATA_GPS)CommonFunc.BytesToStuct(Content, TP);
                    DateTime tm;
                    unsafe
                    {
                        tm = Convert.ToDateTime(CommonFunc.GetStringFromBytes(CommonFunc.GetPointerBytes(gps.Time, 20)));
                    }
                    if (OnGps != null)
                    {
                        OnGps(tm,
                         gps.VehicleID,//车辆ID
                         gps.LAT / 6000000.0,//经度
                         gps.LNG / 6000000.0,//纬度
                         gps.LAT_OFF / 6000000.0,//经度
                         gps.LNG_OFF / 6000000.0,//纬度
                         gps.Speed / 10.0,//速度0.1公里/小时
                         gps.Angle,//角度
                         gps.Oil,//油量
                         gps.LastStationID,//最后站点
                         gps.OutStation,//最后出站标志
                         gps.LastLineID,//最后线路
                         gps.OtherInfo,
                         gps.DistLeaveStation,//离开上个站点以后，又走了多远距离（米）
                         gps.LastOil,//油耗
                         gps.Online,
                         gps.AlarmType
                         );
                    }
                    break;
                case CommandType.CMD_GPS_INFO_MANY:

                    AnyzeGPS(Content);
                    break;
                case CommandType.CMD_STATION_ONLINE:
                    AnyzeOnline(Content);
                    break;
                case CommandType.CMD_NOTIFY_STATION_MANY:

                    AnyzeStationNotify(Content);
                    break;
                    
                default:
                    break;

            }
        }
        private unsafe void HandleCommand(DATA_STATION_COMMAND cmd)
        {

            switch (cmd.Kind)
            {
                case 1:
                    if (this.OnShutDown != null)
                    {
                        OnShutDown();
                    }
                    break;
                case 2:
                    if (this.OnRestart != null)
                    {
                        OnRestart();
                    }
                    break;
                case 3:
                    if (this.OnSetShutdown != null)
                    {
                        byte[] bt = CommonFunc.GetPointerBytes(cmd.Option, 100);
                        string time = CommonFunc.GetStringFromBytes(bt);

                        OnSetShutdown(time);

                    }
                    break;
                case 4:
                    if (this.OnSetIpPort != null)
                    {
                        byte[] ip = CommonFunc.GetPointerBytes(cmd.Option, 15);
                        byte[] port = CommonFunc.GetPointerBytes(cmd.Option + 15, 5);

                        string strIP = CommonFunc.GetStringFromBytes(ip);
                        string strPort = CommonFunc.GetStringFromBytes(port);

                        OnSetIpPort(strIP, strPort);
                    }
                    break;
                case 5:
                    if (this.OnDeleteItem != null)
                    {
                        byte[] bt = CommonFunc.GetPointerBytes(cmd.Option, 100);
                        string fileName = CommonFunc.GetStringFromBytes(bt);
                        OnDeleteItem(fileName);
                    }
                    break;
                case 6:
                    if (this.OnGetStatonItems != null)
                    {
                        OnGetStatonItems();
                    }
                    break;

            }



        }

        private unsafe void HandleItemChaged(DATA_STATION_ITEM item)
        {

            string fromTime = CommonFunc.GetStringFromBytes(CommonFunc.GetPointerBytes(item.FromTime, 10));
            string toTime = CommonFunc.GetStringFromBytes(CommonFunc.GetPointerBytes(item.ToTime, 10));

            string fromDate = CommonFunc.GetStringFromBytes(CommonFunc.GetPointerBytes(item.Fromdate, 10));
            string toDate = CommonFunc.GetStringFromBytes(CommonFunc.GetPointerBytes(item.Todate, 10));

            string fileName = CommonFunc.GetStringFromBytes(CommonFunc.GetPointerBytes(item.FileName, 100));
            if (OnItemChange != null)
            {
                OnItemChange(item.StationID,
                        item.UserID,
                        item.KeepLong,
                        item.Seq,
                        item.MaxTimesDay,
                        item.TxtFontsize,
                        fromTime,
                        toTime,
                        fromDate,
                        toDate,
                        fileName);
            }

        }
        public DATA_STATION_MESSAGE AnyzeStationMessage(byte[] bytes)
        {
            //得到结构体的大小
            int size = Marshal.SizeOf(typeof(DATA_STATION_MESSAGE));
            DATA_STATION_MESSAGE ret = new DATA_STATION_MESSAGE();
            //byte数组长度小于结构体的大小
            if (size > bytes.Length)
            {
                return ret;
            }

            ret.StationID = BitConverter.ToUInt32(bytes, 0);

            ret.UserID = BitConverter.ToUInt32(bytes, 4);

            ret.Kind = (byte)BitConverter.ToUInt32(bytes, 8);

            ret.MessageLenth = BitConverter.ToUInt32(bytes, 12);
            ret.PersistTime = BitConverter.ToUInt32(bytes, 16);

            ret.Content = new byte[ret.MessageLenth];
            Array.Copy(bytes, size, ret.Content, 0, ret.MessageLenth);
            //返回结构体
            return ret;

        }
        public DATA_STATION_ITEMS_BACK AnyzeStationItems(byte[] bytes)
        {
            //得到结构体的大小
            int size = Marshal.SizeOf(typeof(DATA_STATION_ITEMS_BACK));
            DATA_STATION_ITEMS_BACK ret = new DATA_STATION_ITEMS_BACK();
            //byte数组长度小于结构体的大小
            if (size > bytes.Length)
            {
                return ret;
            }

            ret.StationID = BitConverter.ToUInt32(bytes, 0);

            ret.ContentLength = BitConverter.ToUInt32(bytes, 4);



            ret.Content = new byte[ret.ContentLength];
            Array.Copy(bytes, size, ret.Content, 0, ret.ContentLength);
            //返回结构体
            return ret;

        }
        public DATA_STATION_FILE AnyzeStationFile(byte[] bytes)
        {
            //得到结构体的大小
            int size = Marshal.SizeOf(typeof(DATA_STATION_FILE));
            DATA_STATION_FILE ret = new DATA_STATION_FILE();
            //byte数组长度小于结构体的大小
            if (size > bytes.Length)
            {
                return ret;
            }

            ret.StationID = BitConverter.ToUInt32(bytes, 0);
            ret.UserID = BitConverter.ToUInt32(bytes, 4);
            ret.FileLength = BitConverter.ToUInt32(bytes, 8);
            ret.KeepLong = BitConverter.ToUInt32(bytes, 12);
            ret.Seq = BitConverter.ToUInt32(bytes, 16);
            ret.MaxTimesDay = BitConverter.ToUInt32(bytes, 20);
            ret.FileKind = BitConverter.ToUInt32(bytes, 24);
            ret.TxtFontsize = BitConverter.ToUInt32(bytes, 28);




            unsafe
            {
                byte[] tempBuf = new byte[10];
                Array.Copy(bytes, 32, tempBuf, 0, 10);
                CommonFunc.CopyBytesToPointer(ret.FromTime, tempBuf);

                tempBuf = new byte[10];
                Array.Copy(bytes, 42, tempBuf, 0, 10);
                CommonFunc.CopyBytesToPointer(ret.ToTime, tempBuf);

                tempBuf = new byte[10];
                Array.Copy(bytes, 52, tempBuf, 0, 10);
                CommonFunc.CopyBytesToPointer(ret.Fromdate, tempBuf);

                tempBuf = new byte[10];
                Array.Copy(bytes, 62, tempBuf, 0, 10);
                CommonFunc.CopyBytesToPointer(ret.Todate, tempBuf);

                tempBuf = new byte[100];
                Array.Copy(bytes, 72, tempBuf, 0, 100);
                CommonFunc.CopyBytesToPointer(ret.FileName, tempBuf);
            }
            ret.FileContent = new byte[ret.FileLength];
            Array.Copy(bytes, size, ret.FileContent, 0, ret.FileLength);

            ret.FileContent = CommonFunc.GZipDeCompress(ret.FileContent);
            ret.FileLength = (uint)ret.FileContent.Length;
            return ret;

        }

        public void AnyzeStationNotify(byte[] bytes)
        {
            //得到结构体的大小 
            DateTime nw = DateTime.Now;
            uint PackCount = BitConverter.ToUInt32(bytes, 0);
            uint EachSize = BitConverter.ToUInt32(bytes, 4);

            for (int i = 0; i < PackCount; i++)
            {
                byte[] content = new byte[EachSize];
                Array.Copy(bytes, 8 + i * EachSize, content, 0, EachSize);
                Type TP = typeof(DATA_STATION_PREDICTION);
                DATA_STATION_PREDICTION stationNotify = (DATA_STATION_PREDICTION)CommonFunc.BytesToStuct(content, TP);
                if (OnStationNotify != null)
                {
                    OnStationNotify(stationNotify);
                }
            }
            //System.Console.Out.WriteLine("站牌解析：" + (DateTime.Now - nw).TotalMilliseconds.ToString() + "秒 " + PackCount.ToString() + "个");
        }
        public void AnyzeGPS(byte[] bytes)
        {
            //得到结构体的大小 
            DateTime nw = DateTime.Now;
            uint PackCount = BitConverter.ToUInt32(bytes, 0);
            uint EachSize = BitConverter.ToUInt32(bytes, 4);

            for (int i = 0; i < PackCount; i++)
            {
                byte[] content = new byte[EachSize];
                Array.Copy(bytes, 8 + i * EachSize, content, 0, EachSize);
                Type TP = typeof(DATA_GPS);
                DATA_GPS gps = (DATA_GPS)CommonFunc.BytesToStuct(content, TP);

                DateTime tm = DateTime.Now;
                unsafe
                {
                    try
                    {
                        tm = Convert.ToDateTime(CommonFunc.GetStringFromBytes(CommonFunc.GetPointerBytes(gps.Time, 20)));
                    }
                    catch (Exception ex)
                    {
                        System.Console.Out.WriteLine("时间错误:" + ex.ToString());
                        continue;
                    }
                }
                if (gps.Angle > 360)
                {
                    gps.Angle = 0;
                }
                if (OnGps != null)
                {
                    OnGps(tm,
                         gps.VehicleID,//车辆ID
                         Math.Round(gps.LAT / 6000000.0, 5),//经度
                          Math.Round(gps.LNG / 6000000.0, 5),//纬度
                         Math.Round(gps.LAT_OFF / 6000000.0, 5),//经度
                         Math.Round(gps.LNG_OFF / 6000000.0, 5),//纬度
                         gps.Speed / 10.0,//速度0.1公里/小时
                         gps.Angle,//角度
                         gps.Oil,//油量
                         gps.LastStationID,//最后站点
                         gps.OutStation,//最后出站标志
                         gps.LastLineID,//最后线路
                         gps.OtherInfo,
                         gps.DistLeaveStation,//离开上个站点以后，又走了多远距离（米）
                         gps.LastOil,//油耗
                         gps.Online,
                         gps.AlarmType);
                }

            }
           // System.Console.Out.WriteLine("GPS解析：" + (DateTime.Now - nw).TotalMilliseconds.ToString() + "秒 " + PackCount.ToString() + "个");
        }
        public override AbstractMessageHandle NewInstance()
        {
            return new GPSMessageHandle();
        }
        public void AnyzeOnline(byte[] bytes)
        {
            Type TP = typeof(DATA_STATION_ONLINE);
            DATA_STATION_ONLINE online = (DATA_STATION_ONLINE)CommonFunc.BytesToStuct(bytes, TP);
            if (OnOnline != null)
            {
                OnOnline(online.StationID,online.Online);
            }
            //System.Console.Out.WriteLine("AnyzeOnline解析：" + online.StationID.ToString()+"==" + online.Online.ToString());
        }
    }
}
