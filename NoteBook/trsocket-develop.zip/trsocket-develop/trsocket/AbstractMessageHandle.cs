﻿using System;
using System.Collections.Generic;
using System.Text;
using  System.Net;
using System.Threading;
namespace trsocket
{

    public abstract class AbstractMessageHandle
    {
        //private byte[] m_LeftBuff = null;
        private bool m_bThreadStart = false;
        private String m_LockFlag="LOCKME";
       // public ClientInfo Client { get; set; }
        public AnalyzeErrorHandle OnAnalyzeError { get; set; }
        ManualResetEvent m_TerminalEvent = new ManualResetEvent(false);
        ManualResetEvent m_DataArriveEvent = new ManualResetEvent(false);
        ManualResetEvent m_WaitEvent = new ManualResetEvent(false);
        protected List<ClientInfo> m_ClientList = new List<ClientInfo>();
        volatile int m_Terminated = 0;//结束标志
        /// <summary>
        /// 处理数据解析错误
        /// </summary>
        protected void OnAnalyzeWrong(ClientInfo info)
        {
            System.Console.Out.WriteLine("OnAnalyzeWrong:" );
            
            if (OnAnalyzeError != null)
            {
                OnAnalyzeError();
            }
            //清空缓冲区
            this.RemoveLeftData(info,info.m_LeftBuff.Length);
        }
        /// <summary>
        /// 返回缓冲区
        /// </summary>
        /// <returns></returns>
        protected byte[] GetBuffer(ClientInfo info)
        {
            return info.m_LeftBuff;
        }
        /// <summary>
        /// 删除数据缓冲区中的起始位置开始，指定长度的BYTE
        /// </summary>
        /// <param name="Length">删除长度</param>
        protected void RemoveLeftData(ClientInfo info,int Length)
        {
            if (info.m_LeftBuff == null)
            {
                return;
            }
            if (info.m_LeftBuff.Length - Length < 0)
            {
                //CommonFunc.LogError("info.m_LeftBuff.Length - Length < 0 总有：" + info.m_LeftBuff.Length + " 要求：" + Length);
                Length = info.m_LeftBuff.Length; 
               // throw new Exception("删除数据长度太长！");
            }


            lock (m_LockFlag)
            {
                byte[] bytesNew = new byte[info.m_LeftBuff.Length - Length];
                try
                {
                    if (info.m_LeftBuff.Length - Length > 0)
                    {
                        // Array.Copy(info.m_LeftBuff, Length, bytesNew, 0, info.m_LeftBuff.Length - Length);
                        Buffer.BlockCopy(info.m_LeftBuff, Length, bytesNew, 0, info.m_LeftBuff.Length - Length);

                    }
                    info.m_LeftBuff = bytesNew;
                }
                catch (Exception ex)
                {
                   // System.Console.Out.WriteLine(ex.ToString());
                }
            }

        }
       /// <summary>
       /// 接收最新的数据，填充到缓冲区，待进一步解析
       /// </summary>
       /// <param name="bytes"></param>
        public void AddData(ClientInfo info ,byte[] bytes)
        {
            //初始化数据
            if (!m_bThreadStart)
            {
                IniEnv();
            }
            
            //加锁，防止解析线程写m_LeftBuff冲突
            lock (m_LockFlag)
            {
                try
                {

                    //if (!m_ClientList.Contains(info))
                    {
                        if (info.ClientUdpEP != null)
                        {//udp,查找终结点，判断是否同一个终结点
                            ClientInfo clt = m_ClientList.Find(o => o.ClientUdpEP.Equals(info.ClientUdpEP));
                            if (null == clt)
                            {
                                m_ClientList.Add(info);
                            }
                            else
                            {
                                clt.LastRecvTime = info.LastRecvTime;
                                info = clt;

                            }
                        }
                        else
                        {//TCP
                            if (!m_ClientList.Contains(info))
                            {
                                m_ClientList.Add(info);
                            }
                       //     CommonFunc.LogError("m_ClientList.未找到，添加失败: " + m_ClientList.Count.ToString());
                        }
                    }
                    if (info.m_LeftBuff == null)
                    {
                        info.m_LeftBuff = new byte[bytes.Length];
                        Array.Copy(bytes, info.m_LeftBuff, bytes.Length);
                    }
                    else
                    {
                        byte[] bytesNew = new byte[info.m_LeftBuff.Length + bytes.Length];
                        //先将上次剩下的放进去
                        Buffer.BlockCopy(info.m_LeftBuff, 0, bytesNew, 0, info.m_LeftBuff.Length);
                        // Array.Copy(info.m_LeftBuff, bytesNew, info.m_LeftBuff.Length);
                        //再复制本次新数据，加到末尾部
                        Buffer.BlockCopy(bytes, 0, bytesNew, info.m_LeftBuff.Length, bytes.Length);
                        //  Array.Copy(bytes, 0, bytesNew, info.m_LeftBuff.Length, bytes.Length);
                        info.m_LeftBuff = bytesNew;

                    }
                }
                catch (Exception ex)
                {
                    CommonFunc.LogError("Analyze0: " + ex.ToString());
                }
            }
           
            try
            {
                while (Analyze(info))
                {

                }
            }
            catch(Exception EX)
            {
                CommonFunc.LogError("Analyze1: "+EX.ToString());
            }
            //m_DataArriveEvent.Set();
        }
        /// <summary>
        /// 尝试添加 一个连接对象
        /// </summary>
        /// <param name="info"></param>
        public void TryAddTcpClient(ClientInfo info,int port)
        {
             
            try
            {

                //CommonFunc.LogError("3new AcceptWorkThread:" + port);
                if (!m_ClientList.Contains(info))
                {
                    //CommonFunc.LogError("4new AcceptWorkThread:" + port);
                    m_ClientList.Add(info);
                    //CommonFunc.LogError("TryAddClient.Add 数量: " + m_ClientList.Count.ToString());
                    
                }
                     
            }
            catch (Exception ex)
            {
                CommonFunc.LogError("TryAddClient: " + ex.ToString());
            }
        }
        abstract protected bool Analyze(ClientInfo info);
        abstract public AbstractMessageHandle NewInstance();
        private void HandleProc() {
            while (0 == m_Terminated)//m_TerminalEvent.WaitOne(10, false))
            {
                for (int m=0;m< m_ClientList.Count;m++){ 
                    ClientInfo info = m_ClientList[m];
                    try{
                         while (Analyze(info))
                        {
                            
                        }
                    }catch{

                    }
                }
                Thread.Sleep(1);
            }
            m_WaitEvent.Set();//通知等待者
        }
        //启动一个数据处理线程
        private void IniEnv() {
            m_bThreadStart = true;
            //Thread t = new Thread(new ThreadStart(HandleProc));
            //t.Name = "Analyze Message";
            //t.IsBackground = true;
            //t.Start();
        }
        /// <summary>
        /// 结束数据处理线程 
        /// </summary>
        public void Terminate() {
              m_Terminated=1;
            //m_WaitEvent.Reset();
            //m_TerminalEvent.Set();
            //if (false == m_WaitEvent.WaitOne(5000, false))//最多给其5秒供其结束
            {
                System.Console.Out.WriteLine("Terminate超时！！");
            }
        }
        /// <summary>
        /// 移除连接对象
        /// </summary>
        /// <param name="client"></param>
        public void RemoveClient(ClientInfo client) {
            CommonFunc.LogError("RemoveClient 开始: " + m_ClientList.Count);
            lock (m_LockFlag)
            {
                try
                {
                    client.socket.Close();
                     
                    
                }
                catch (Exception ex)
                {
                    CommonFunc.LogError("client.socket 失败1: " + ex.ToString());
                }
                try
                {
                    
                    client.socket = null;
                    client.Buffer = null;

                }
                catch (Exception ex)
                {
                    CommonFunc.LogError("client.socket 失败2: " + ex.ToString());
                }
                try{
                    m_ClientList.Remove(client);
                }
                catch(Exception ex) {
                    CommonFunc.LogError("RemoveClient 失败: " + ex.ToString());
                }
            }
            CommonFunc.LogError("RemoveClient 结束: " + m_ClientList.Count);
        }
        public void RemoveClientByEndPoint(EndPoint endPoint)
        {
            CommonFunc.LogError("RemoveClientByEndPoint 开始: " + m_ClientList.Count);
            lock (m_LockFlag)
            {
                 
               try
                {
                    for (int i=0;i< m_ClientList.Count;i++){
                        if  (m_ClientList[i].ClientUdpEP.Equals( endPoint)) {
                            m_ClientList[i].Buffer = null;
                            m_ClientList.RemoveAt( i);
                            i--;
                        }
                    }

                   
                }
                catch (Exception ex)
                {
                    CommonFunc.LogError("RemoveClientByEndPoint 失败: " + ex.ToString());
                }
            }
            CommonFunc.LogError("RemoveClientByEndPoint 结束: " + m_ClientList.Count);
        }
        /// <summary>
        /// 删除过期连接
        /// </summary>
        /// <param name="seconds">过期时长(秒)</param>
        public void RemoveInvalidClient(int seconds)
        {
            CommonFunc.LogError("RemoveInvalidClient 开始: " );
            try
            {
                lock (m_LockFlag)
                {
                    for (int i = 0; i < m_ClientList.Count;i++ )
                    {
                        ClientInfo client = m_ClientList[i];
                        if ((DateTime.Now - client.LastRecvTime).TotalSeconds > seconds)
                        {
                            try     {
                                if (client.socket != null)
                                {
                                    client.socket.Close();
                                }
                            }
                            catch (Exception ex)
                            {
                                CommonFunc.LogError(" client.socket1 失败: " + ex.ToString());
                            }
                            m_ClientList.RemoveAt(i);
                            i--;
                        }
                    }
                 }
                     
            }
            catch (Exception ex)
            {
                CommonFunc.LogError("RemoveInvalidClient 失败: " + ex.ToString());
            }
        }
        
    }
}
