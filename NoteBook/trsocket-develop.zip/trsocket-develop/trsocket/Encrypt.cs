﻿using System;
using System.Collections.Generic;
using System.Text;

namespace trsocket
{
    public sealed class Encrypt
    {
        const UInt32 M1 = 0xfff1;
        const UInt32 IA1 = 0xfff2;
        const UInt32 IC1 = 0xfff3;

        public static void encrypt (UInt32 key, Byte[] buffer, UInt32 size)
        {
            UInt32 idx = 0;
            if (0 == key)
            {
                key = 1;
            }
            //
            while (idx < size)
            {
                key = IA1 * (key % M1) + IC1;
                buffer[idx++] ^= (Byte)((key >> 20) & 0xFF);
            }
        }
       
    }
}
