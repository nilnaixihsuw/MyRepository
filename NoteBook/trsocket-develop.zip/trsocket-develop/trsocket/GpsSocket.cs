﻿using System;
using System.Collections.Generic;
using System.Text;

namespace trsocket
{
    public class GpsSocket
    {
        private TRClientSocket m_Sock;
         private GPSMessageHandle m_MessageHandle = new GPSMessageHandle();
         public bool m_bLogin;
         private bool m_bAutoLogin = true;
         string m_Username = "";
         string m_Password = "";
         LoginType m_logType;
         public bool IsOpen
         {
             get { return m_bLogin; }
         }
         public GPSDataHandler GpsHandler
         {
             set
             {
                 m_MessageHandle.OnGps += value;
             }
         }
         public ChangeItemHandler ItemChangedHandler
         {
             set
             {
                 m_MessageHandle.OnItemChange += value;
             }
         }
         public ChangeStationIPHandler StationIPChangeHandler
         {
             set
             {
                 m_MessageHandle.OnStationIPChange += value;
             }
         }
         //
         public GetItemsSuccessHandler GetItemsSuccessHandler
         {
             set
             {
                 m_MessageHandle.OnGetStatonItemsSuccess += value;
             }
         }
         public ShutdownComputerHandler ShutDownHandle
         {
             set
             {
                 m_MessageHandle.OnShutDown += value;
             }
         }

         public RestartComputerHandler RestartHandler
         {
             set
             {
                 m_MessageHandle.OnRestart += value;
             }
         }

         public SetIpPortHandler SetIpHandler
         {
             set
             {
                 m_MessageHandle.OnSetIpPort += value;
             }
         }

         public SetShutdownHandler SetShutdownHandler
         {
             set
             {
                 m_MessageHandle.OnSetShutdown += value;
             }
         }

         public DeleteStationItemHandler DeleteHandler
         {
             set
             {
                 m_MessageHandle.OnDeleteItem += value;
             }
         }

         public GetStationItemsHandler GetItemsHandler
         {
             set
             {
                 m_MessageHandle.OnGetStatonItems += value;
             }
         }



         //
         public StationNotifyHandler StationHandle
         {
             set
             {
                 m_MessageHandle.OnStationNotify += value;
             }
         }
         public LoginAnswerHandler LoginHandler
         {
             set
             {
                 if (m_MessageHandle != null)
                 {
                     m_MessageHandle.OnLoginAnswer += value;
                 }
             }

         }

         public StationFileHandler StationFileHandler
         {
             set
             {
                 if (m_MessageHandle != null)
                 {
                     m_MessageHandle.OnStatoinFile += value;
                 }
             }

         }
         public MessageHandler MessageHandler
         {
             set
             {
                 if (m_MessageHandle != null)
                 {
                     m_MessageHandle.OnMessage += value;
                 }
             }

         }
         public CommandHandler CmdHandler
         {
             set
             {
                 if (m_MessageHandle != null)
                 {
                     m_MessageHandle.OnCommand += value;
                 }
             }

         }
         public StationOnline OnlineHandler
         {
             set
             {
                 m_MessageHandle.OnOnline += value;
             }
         }
         public GpsSocket(string IP, int Port, string UserID, string PassWord, LoginType logType)
         {

             m_Username = UserID;
             m_Password = PassWord;
             m_logType = logType;
             m_Sock = new TRClientSocket(IP, Port, true, m_MessageHandle);
             m_Sock.NeedPing = true; 
             m_Sock.OnClosedHandle += OnSocketClosed;
             m_Sock.OnConnectHandle += OnSocketConnect;
        }
        
        public void SendData(byte[] bytes) {
            try
            {
                this.m_Sock.SendMsg(bytes);
            }
            catch(Exception ex) {
                System.Console.Out.WriteLine("SendData:" + ex.ToString());
                
            }
        }
        private void loginSocket(DATA_CMD_LOGIN_ANSWER answer)
        {
            if (answer.result == 0)
            {
                m_bLogin = true;
            }
            else
            {
               m_bLogin = false;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="StationID"></param>
        /// <param name="Msg"></param>
        /// <param name="Kind"></param>
        /// <returns></returns>
        public bool SendMessage(uint UserID, uint StationID, string Msg, byte Kind, uint PersistTime)
        {
            byte[] byteSend = CommonFunc.MakeSendMsgData(UserID, StationID, Msg, Kind, PersistTime);
            byteSend = CommonFunc.MakeCommandPackage(byteSend, CommandType.CMD_MESSAGE_STATION);
            try
            {

               m_Sock.SendMsg(byteSend);

            }

            catch (Exception ex)
            {

                System.Console.Out.WriteLine("CloseSocket:" + ex.ToString());
                return false;

            }
            return true;
        }
        /// <summary>
        /// 向服务器回发本机的播放节目单
        /// </summary>
        /// <param name="StationID">本站ID</param>
        /// <param name="Msg">节目单内容</param>
        /// <returns></returns>
        public bool SendStationItems(uint StationID, string Msg)
        {
            byte[] byteSend = CommonFunc.MakeSendItemsData(StationID, Msg);
            byteSend = CommonFunc.MakeCommandPackage(byteSend, CommandType.CMD_STATION_ANSWER_ITEMS);
            try
            {

                m_Sock.SendMsg(byteSend);

            }
            catch (Exception ex)
            {
                System.Console.Out.WriteLine("SendStationItems:" + ex.ToString());
                return false;

            }
            return true;
        }
        /// <summary>
        /// 向电子站台发送命令
        /// </summary>
        /// <param name="UserID"></param>
        /// <param name="StationID"></param>
        /// <param name="Kind"></param>
        /// <param name="Option"></param>
        /// <returns></returns>

        private bool SendCommand(uint UserID, uint StationID, byte Kind, byte[] Option)
        {
            byte[] byteSend = CommonFunc.MakeCommandData(UserID, StationID, Kind, Option);
            byteSend = CommonFunc.MakeCommandPackage(byteSend, CommandType.CMD_COMMAND_STATION);

            try
            {

                m_Sock.SendMsg(byteSend);

            }
            catch (Exception ex)
            {
                System.Console.Out.WriteLine("SendCommand:" + ex.ToString());
                return false;
            }
            return true;
        }
        /// <summary>
        /// 关机
        /// </summary>
        /// <param name="UserID"></param>
        /// <param name="StationID"></param>
        /// <returns></returns>
        public bool ColseComputer(uint UserID, uint StationID)
        {
            byte[] byteSend = CommonFunc.MakeCommandData(UserID, StationID, 1, new byte[0]);
            byteSend = CommonFunc.MakeCommandPackage(byteSend, CommandType.CMD_COMMAND_STATION);

            try
            {

                m_Sock.SendMsg(byteSend);

            }
            catch (Exception ex)
            {
                System.Console.Out.WriteLine("SendCommand:" + ex.ToString());
                return false;
            }
            return true;
        }
        /// <summary>
        /// 设定每日关机时间(00:00:00表示不关机)
        /// </summary>
        /// <param name="UserID"></param>
        /// <param name="StationID"></param>
        /// <param name="strTime">关机时间格式：21:23:00</param>
        /// <returns></returns>
        public bool SetCloseTime(uint UserID, uint StationID, string strTime)
        {
            System.Diagnostics.Debug.Assert(strTime.Length == 8);
            byte[] Option = System.Text.Encoding.GetEncoding("gb2312").GetBytes(strTime);
            byte[] byteSend = CommonFunc.MakeCommandData(UserID, StationID, 3, Option);
            byteSend = CommonFunc.MakeCommandPackage(byteSend, CommandType.CMD_COMMAND_STATION);

            try
            {

                m_Sock.SendMsg(byteSend);

            }
            catch (Exception ex)
            {
                System.Console.Out.WriteLine("SetCloseTime:" + ex.ToString());
                return false;
            }
            return true;
        }
        /// <summary>
        /// 重启
        /// </summary>
        /// <param name="UserID"></param>
        /// <param name="StationID"></param>
        /// <returns></returns>
        public bool RestartComputer(uint UserID, uint StationID)
        {
            byte[] byteSend = CommonFunc.MakeCommandData(UserID, StationID, 2, new byte[0]);
            byteSend = CommonFunc.MakeCommandPackage(byteSend, CommandType.CMD_COMMAND_STATION);

            try
            {

                m_Sock.SendMsg(byteSend);

            }
            catch (Exception ex)
            {
                System.Console.Out.WriteLine("RestartComputer:" + ex.ToString());
                return false;
            }
            return true;
        }
        /// <summary>
        /// 设置中心服务器IP,端口
        /// </summary>
        /// <param name="UserID"></param>
        /// <param name="StationID"></param>
        /// <param name="ip"></param>
        /// <param name="port"></param>
        /// <returns></returns>
        public bool SetIpPort(uint UserID, uint StationID, string strIp, string strPort)
        {
            while (strIp.Length < 15)
            {
                strIp += " ";
            }
            while (strPort.Length < 5)
            {
                strPort += " ";
            }

            byte[] Option = new byte[20];

            byte[] ip = System.Text.Encoding.GetEncoding("gb2312").GetBytes(strIp);
            byte[] port = System.Text.Encoding.GetEncoding("gb2312").GetBytes(strPort);
            Array.Copy(ip, 0, Option, 0, ip.Length);
            Array.Copy(port, 0, Option, 15, port.Length);

            byte[] byteSend = CommonFunc.MakeCommandData(UserID, StationID, 4, Option);
            byteSend = CommonFunc.MakeCommandPackage(byteSend, CommandType.CMD_COMMAND_STATION);

            try
            {

                m_Sock.SendMsg(byteSend);

            }
            catch (Exception ex)
            {
                System.Console.Out.WriteLine("SendCommand:" + ex.ToString());
                return false;
            }
            return true;
        }
        /// <summary>
        ///删除一个节目
        /// </summary>
        /// <param name="UserID"></param>
        /// <param name="StationID"></param>
        /// <param name="ItemName"></param>
        /// <returns></returns>
        public bool DeleteStationItem(uint UserID, uint StationID, string ItemName)
        {
            byte[] Option = System.Text.Encoding.GetEncoding("gb2312").GetBytes(ItemName);
            byte[] byteSend = CommonFunc.MakeCommandData(UserID, StationID, 5, Option);
            byteSend = CommonFunc.MakeCommandPackage(byteSend, CommandType.CMD_COMMAND_STATION);

            try
            {

                m_Sock.SendMsg(byteSend);

            }
            catch (Exception ex)
            {
                System.Console.Out.WriteLine("DeleteStationItem:" + ex.ToString());
                return false;
            }
            return true;
        }
        /// <summary>
        /// 请求一个站台的节目单,站台收到此指令后，将当前播放表中的记录形成XML格式，上传
        /// </summary>
        /// <param name="UserID"></param>
        /// <param name="StationID"></param>
        /// <returns></returns>
        public bool GetStationItems(uint UserID, uint StationID)
        {
            byte[] byteSend = CommonFunc.MakeCommandData(UserID, StationID, 6, new byte[0]);
            byteSend = CommonFunc.MakeCommandPackage(byteSend, CommandType.CMD_COMMAND_STATION);

            try
            {

                m_Sock.SendMsg(byteSend);

            }
            catch (Exception ex)
            {
                System.Console.Out.WriteLine("GetStationItems:" + ex.ToString());
                return false;
            }
            return true;
        }
        /// <summary>
        /// 发送文件
        /// </summary>
        /// <param name="UserID"></param>
        /// <param name="StationID"></param>
        /// <param name="FileKind"></param>
        /// <param name="KeepLong"></param>
        /// <param name="Seq"></param>
        /// <param name="TxtFontsize"></param>
        /// <param name="MaxTimesDay"></param>
        /// <param name="strFromTime"></param>
        /// <param name="strToTime"></param>
        /// <param name="strFromdate"></param>
        /// <param name="strTodate"></param>
        /// <param name="strFileName"></param>
        /// <param name="FilePath"></param>
        /// <returns></returns>
        public bool SendFile(
            uint UserID,
            uint StationID,
            byte FileKind,
            uint KeepLong,
            ushort Seq,
            byte TxtFontsize,
            ushort MaxTimesDay,
            string strFromTime,
            string strToTime,
            string strFromdate,
            string strTodate,
            string strFileName,
            string FilePath)
        {

            byte[] FromTime = System.Text.Encoding.GetEncoding("gb2312").GetBytes(strFromTime);
            byte[] ToTime = System.Text.Encoding.GetEncoding("gb2312").GetBytes(strToTime);
            byte[] Fromdate = System.Text.Encoding.GetEncoding("gb2312").GetBytes(strFromdate);
            byte[] Todate = System.Text.Encoding.GetEncoding("gb2312").GetBytes(strTodate);
            byte[] FileName = System.Text.Encoding.GetEncoding("gb2312").GetBytes(strFileName);

            byte[] byteSend = CommonFunc.MakeSendFileData(
                 UserID,
                 StationID,
                 FileKind,
                 KeepLong,
                 Seq,
                 TxtFontsize,
                 MaxTimesDay,
                 FromTime,
                 ToTime,
                 Fromdate,
                 Todate,
                 FileName,
                 FilePath);



            byteSend = CommonFunc.MakeCommandPackage(byteSend, CommandType.CMD_FILE_STATION);
            try
            {

                m_Sock.SendMsg(byteSend);

            }

            catch (Exception ex)
            {

                System.Console.Out.WriteLine("CloseSocket:" + ex.ToString());
                return false;

            }

            return true;
        }
        public bool SendTextItem(
            uint UserID,
            uint StationID,
            uint KeepLong,
            ushort Seq,
            byte TxtFontsize,
            ushort MaxTimesDay,
            string strFromTime,
            string strToTime,
            string strFromdate,
            string strTodate,
            string strContent,
            string strFileName
            )
        {
            return SendFile(UserID,
             StationID,
             3,
             KeepLong,
             Seq,
             TxtFontsize,
             MaxTimesDay,
             strFromTime,
             strToTime,
             strFromdate,
             strTodate,
             strFileName,
             strContent);

        }
        public bool UpdateItem(
             uint UserID,
             uint StationID,
             uint KeepLong,
             ushort Seq,
             byte TxtFontsize,
             ushort MaxTimesDay,
             string strFromTime,
             string strToTime,
             string strFromdate,
             string strTodate,
             string strItemName)
        {
            byte[] FromTime = System.Text.Encoding.GetEncoding("gb2312").GetBytes(strFromTime);
            byte[] ToTime = System.Text.Encoding.GetEncoding("gb2312").GetBytes(strToTime);
            byte[] Fromdate = System.Text.Encoding.GetEncoding("gb2312").GetBytes(strFromdate);
            byte[] Todate = System.Text.Encoding.GetEncoding("gb2312").GetBytes(strTodate);
            byte[] ItemName = System.Text.Encoding.GetEncoding("gb2312").GetBytes(strItemName);

            byte[] byteSend = CommonFunc.MakeItemData(
                 UserID,
                 StationID,
                 KeepLong,
                 Seq,
                 TxtFontsize,
                 MaxTimesDay,
                 FromTime,
                 ToTime,
                 Fromdate,
                 Todate,
                 ItemName);



            byteSend = CommonFunc.MakeCommandPackage(byteSend, CommandType.CMD_UPDATE_ITEM);
            try
            {

                m_Sock.SendMsg(byteSend);

            }

            catch (Exception ex)
            {

                System.Console.Out.WriteLine("CloseSocket:" + ex.ToString());
                return false;

            }
            return true;
        }

        private void OnSocketConnect(bool success){
            System.Console.Out.WriteLine("GPSSOCKET连接："+success.ToString());
            if (this.m_bAutoLogin)
            {
                Login();
            }
        }
        private void OnSocketClosed(){
            System.Console.Out.WriteLine("GPSSOCKET关闭：" );
            m_bLogin = false;
        }
        private void Login()
        {

            byte[] byteSend = CommonFunc.MakeLoginData(m_Username, m_Password, m_logType);
            byteSend = CommonFunc.MakeCommandPackage(byteSend, CommandType.CMD_LOGIN);
            try
            {

                this.m_Sock.SendMsg(byteSend);

            }

            catch (Exception ex)
            {

                System.Console.Out.WriteLine("CloseSocket:" + ex.ToString());

            }
        }
    }
}
