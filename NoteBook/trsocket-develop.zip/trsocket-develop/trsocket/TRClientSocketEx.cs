﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace trsocket
{
    public class TRClientSocketEx
    {
        private IPAddress m_ServerIP = null;
        private int m_Port = 0;
        private IPEndPoint serverFullAddr;
        private volatile bool m_bConnect = false;
        private bool m_bAutoConnect = true;

        public Socket sock;
        public SocketConnectResultHandle OnConnectHandle;
        public SocketClosedHandle OnClosedHandle;
        public RawMessageArrive OnMsgArrive;
        protected AbstractMessageHandle m_MessageHandle;


        private int m_ide_timeout = 180;//秒，空闲超时，(时长超出此规定时长，未收到任何消息，视为断开)
        volatile uint m_last_recv_ticks=(uint)(DateTime.Now.Ticks/10000000/60);
        private int m_period_connect = 3000;//再次尝试连接间隔时长
        private ClientInfo m_ClientInfo = new ClientInfo();
        private DateTime m_LastPingTime;
        private string m_host = "";
        public bool NeedPing = false;//是否需要自动PING
        private string m_ip = "";//
        private volatile bool isWorking = false;//处于工作状态标志 

      
        private DateTime m_lastConnectSuccessTime = DateTime.Now;//记录最近一次的连接成功时间
        volatile bool m_isClosing = false;//正在关闭中，其他线程不用再进入
        private byte[] m_Buffer = new byte[4096];
        private volatile bool m_bConnectBusing = false;//正在重新连接标志
        System.Timers.Timer m_Timer = new System.Timers.Timer(3000);
        public bool IsConnect()
        {
            return m_bConnect;

        }

        public void SetRecvTimeOut(int value)
        {
            m_ide_timeout = value;

        }
        public bool AutoConnect
        {
            get { return m_bAutoConnect; }
            set { m_bAutoConnect = value; }
        }

        public string Ip
        {
            get { return m_ip; }
        }
        public int Port
        {
            get { return m_Port; }
        }

        public void SendMsg(byte[] byteSend)
        {
            SendMsg(byteSend, 0, byteSend.Length);
            
        }
        public void SendMsg(byte[] byteSend, int offset, int len)
        {

            try
            {
                if (!m_bConnect) {
                    CommonFunc.LogError("SendMsg不发送 未连接:" + " ip:" + this.Ip + " PORT:" + this.Port);
                    return;
                }
                sock.BeginSend(byteSend, offset, len, SocketFlags.None, new AsyncCallback(SendCallBack), this);//这里向系统投递一个发送数据的请求，并指定一个回调函数。
               
            }
            catch (Exception ex)
            {
                CommonFunc.LogError("SocketException33:" + ex.ToString() + " ip:" + this.Ip + " PORT:" + this.Port);
                // m_last_recv_time = DateTime.Now;
                m_last_recv_ticks = (uint)(DateTime.Now.Ticks / 10000000 / 60);
                CloseSocketLocal(DateTime.Now);
                throw ex;
            }
        }
 
        private void IniEnv()
        {
            isWorking = true;
            if (m_MessageHandle != null)
            {
                m_MessageHandle.OnAnalyzeError = OnDataError;
            }
        }
        private void OnDataError()
        {
            //return;//必须删除!!!!!!!!!!!!!!!
            // CloseSocket();
        }
        public TRClientSocketEx()
        {
            m_MessageHandle = new GPSMessageHandle();
            IniEnv();
        }

        public TRClientSocketEx(string ip, int port, string username, string password, LoginType logType)
        {

            IniEnv();
            m_MessageHandle = new GPSMessageHandle();
            string digital = ip.Replace(".", "");
            try
            {
                Convert.ToDouble(digital);
            }
            catch
            {
                m_host = ip;

            }
            m_ip = ip;
            if (m_host == "")//非域名
            {
                m_ServerIP = IPAddress.Parse(ip);
            }
            m_Port = port;

         
            m_Timer.Elapsed += new System.Timers.ElapsedEventHandler(ReconnectThreadFuncTimer);
            m_Timer.Interval = 3000;
            m_Timer.AutoReset = true;//设置是执行一次（false）还是一直执行(true)； 
            m_Timer.Enabled = true;//是否执行System.Timers.Timer.Elapsed事件；
            CommonFunc.LogError("m_Timer4");
        }
        public TRClientSocketEx(string ip, int port, string username, string password, LoginType logType, AbstractMessageHandle MessageHandle)
        {

            IniEnv();
            m_MessageHandle = MessageHandle;

            string digital = ip.Replace(".", "");
            try
            {
                Convert.ToDouble(digital);
            }
            catch
            {
                m_host = ip;
            }
            if (m_host != "")//非域名
            {
                m_ServerIP = IPAddress.Parse(ip);
            }
            m_ip = ip;
            m_Port = port;
 
            m_Timer.Elapsed += new System.Timers.ElapsedEventHandler(ReconnectThreadFuncTimer);
            m_Timer.Interval = 3000;
            m_Timer.AutoReset = true;//设置是执行一次（false）还是一直执行(true)； 
            m_Timer.Enabled = true;//是否执行System.Timers.Timer.Elapsed事件；
            CommonFunc.LogError("m_Timer3");
        }
        public TRClientSocketEx(string ip, int port, bool autoLogin, AbstractMessageHandle MessageHandle)
        {

            if (ip == "" || ip == null)
            {
                return;
            }
            m_ip = ip;
            string digital = ip.Replace(".", "");
            try
            {
                Convert.ToDouble(digital);
            }
            catch
            {
                m_host = ip;

            }
            if (m_host == "")//非域名
            {
                m_ServerIP = IPAddress.Parse(ip);
            }
            m_Port = port;
            this.m_MessageHandle = MessageHandle;
            IniEnv();
            m_Timer.Elapsed += new System.Timers.ElapsedEventHandler(ReconnectThreadFuncTimer);
            m_Timer.Interval = 3000;
            m_Timer.AutoReset = true;//设置是执行一次（false）还是一直执行(true)； 
            m_Timer.Enabled = true;//是否执行System.Timers.Timer.Elapsed事件；
            CommonFunc.LogError("m_Timer2");
        }


        public void Open(string ip, int port, int periodConnect)
        {
            isWorking = true;
            string digital = ip.Replace(".", "");
            try
            {
                Convert.ToDouble(digital);
            }
            catch
            {
                m_host = ip;

            }
            if (m_host == "")//非域名
            {
                m_ServerIP = IPAddress.Parse(ip);
            }

            m_Port = port;
            m_period_connect = periodConnect;
            m_Timer.Elapsed += new System.Timers.ElapsedEventHandler(ReconnectThreadFuncTimer);
            m_Timer.Interval = 3000;
            m_Timer.AutoReset = true;//设置是执行一次（false）还是一直执行(true)； 
            m_Timer.Enabled = true;//是否执行System.Timers.Timer.Elapsed事件；

            CommonFunc.LogError("m_Timer1");

        }
        private void ReconnectThreadFuncTimer(object sender, System.Timers.ElapsedEventArgs e)
        {
            if (!isWorking)
            {
                return;
            }
            if (m_ip == "")
            {
                goto lastRow;
            }
            try
            {
                  
                    if (m_bAutoConnect)
                    {
                        if (!m_bConnect)
                        {
                            try
                            {
                                if (Connect())
                                {

                                    m_bConnect = true;
                                    if (OnConnectHandle != null)
                                    {
                                        OnConnectHandle(true);
                                    }
                                }
                            }
                            catch
                            {


                            }
                        }
                        else
                        {
                        //超过规定时间没收到任何消息，重连接
                             if((uint)(DateTime.Now.Ticks / 10000000 / 60)-m_last_recv_ticks > m_ide_timeout/60)
                            {
                           
                                CommonFunc.LogError("超时关闭3 !" + m_last_recv_ticks.ToString() + " ip:" + m_ServerIP.ToString()  +" hashcode:" + this.GetHashCode());
                                m_last_recv_ticks = (uint)(DateTime.Now.Ticks / 10000000 / 60);
                                CloseSocketLocal(DateTime.Now);
                                Connect();

                             }

                        }
                    }
                    if (m_bConnect && NeedPing && (DateTime.Now - m_LastPingTime).TotalSeconds > 90)
                    {
                        Ping();
                        m_LastPingTime = DateTime.Now;
                    }
                }
                catch
                {


                }
            lastRow:
            return;
               

        }
      
       
        public bool ManuConnect(string ip, int port)
        {

            m_ServerIP = IPAddress.Parse(ip);
            m_Port = port;
            this.m_MessageHandle = new JXYGMessageHandle();
            isWorking = true;
            IniEnv();
            return Connect();
        }
        private bool Connect()
        {
            lock (this)
            {
                try
                {
                    if (!isWorking)
                    {
                         
                        return false;
                    }
                    sock = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                    if (m_host == "")
                    {
                        serverFullAddr = new IPEndPoint(m_ServerIP, m_Port);
                        sock.Connect(serverFullAddr);//建立与远程主机的连接
                        IPEndPoint addrThisTime = (IPEndPoint)sock.LocalEndPoint;
                        int PortThis = -1;
                        if (addrThisTime != null)
                        {
                            PortThis = addrThisTime.Port;
                        }
                    }
                    else
                    {
                        sock.Connect(m_host, m_Port);
                        m_lastConnectSuccessTime = DateTime.Now;
                    }
                    m_ClientInfo.socket = sock;
                    sock.BeginReceive(m_Buffer, 0, m_Buffer.Length, SocketFlags.None, ReceiveCallBack, this);//这里向系统投递一个接收信息的请求，并为其指定ReceiveCallBack做为回调函数

                   
                    
                    IPEndPoint addrTemp = (IPEndPoint)sock.LocalEndPoint;
                    if (addrTemp != null)
                    {
                        CommonFunc.LogError(" local PORT:" + addrTemp.Port);

                    }
                    CommonFunc.LogError("Connectex succuess:" + " ip:" + this.Ip + " PORT:" + this.Port);
                }
                catch (Exception ex)
                {
                    if (OnConnectHandle != null)
                    {
                        OnConnectHandle(false);
                    }
                    else
                    {
                    }
                    
                    return false;
                }
                return true;
            }
        }
 
        public void CloseSocket()
        {
            CommonFunc.LogError("TRClientSocketEx CloseSocket()!");
            try
            {
                isWorking = false;
                this.sock.Shutdown(SocketShutdown.Receive);
                this.sock.Close();
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("CloseSocket:" + ex.ToString());
            }
           // m_TerminalEvent.Set();



        }

        private void CloseSocketLocal(DateTime tm)
        {
            if (m_isClosing)
            {
                return;
            }
            m_isClosing = true;
            lock (this)
            {

                if (m_lastConnectSuccessTime > tm)
                {//类似双检锁
                }
                try
                {
                    CommonFunc.LogError("TRClientSocketEx CloseSocketLocal()!");
                    this.sock.Shutdown(SocketShutdown.Receive);
                    this.sock.Close();
                }
                catch (Exception ex)
                {
                    
                }
                CommonFunc.LogError("TRClientSocketEx CloseSocketLocal()!未能成功结束线程！！！！！！！！！！！！！！");
                m_bConnect = false;//置为未连接，让检测线程去重新连接
                Thread.Sleep(5000);//等检测线程完成一次重连
                m_isClosing = false;
            }

        }
        /// <summary>
        /// 保持与服务器心跳连接
        /// </summary>
        protected virtual void Ping()
        {

            byte[] byteSend = CommonFunc.MakePingData();
            byteSend = CommonFunc.MakeCommandPackage(byteSend, CommandType.CMD_PING);
            try
            {
                SendMsg(byteSend);

            }

            catch (Exception ex)
            {
            }
        }
        private void ReceiveCallBack(IAsyncResult ar)
        {
            try
            {
                 
                int readCount = 0;
                try
                {
                    readCount = this.sock.EndReceive(ar);//调用这个函数来结束本次接收并返回接收到的数据长度。

                }
                catch (SocketException e)//出现Socket异常就关闭连接
                {
                    try
                    {
                        CommonFunc.LogError("ReceiveCallBack SocketExceptionxx:" + e.ToString() + ": LOCALPORT:" + this.m_Port);
                    
                        try
                        {
                            CommonFunc.LogError("ReceiveMsg end!" + " ip:" + this.Ip + " PORT:" + this.Port);
                            if (this.OnClosedHandle != null)
                            {
                                OnClosedHandle();
                            }
                            m_bConnect = false;
                            
                        }
                        catch (SocketException es) //出现Socket异常就关闭连接
                        {
                            CommonFunc.LogError("invoke onClientSocketClosed err:" + es.ToString());

                        }

                    }
                    catch (Exception ex)
                    {
                        CommonFunc.LogError("ReceiveCallBack removeClient fail:" + ex.ToString());
                    }
                    return;
                }
                catch (Exception e)
                {
                    CommonFunc.LogError("ReceiveCallBack Exception :" + e.ToString());
                }
                if (readCount > 0)
                { 
                    byte[] buffer = new byte[readCount];
                    Buffer.BlockCopy(m_Buffer, 0, buffer, 0, readCount);
                    m_last_recv_ticks = (uint)(DateTime.Now.Ticks / 10000000 / 60);
                    if (OnMsgArrive != null)
                    {
                        OnMsgArrive(buffer);
                    }
                    if (m_MessageHandle != null)
                    {
                        m_MessageHandle.AddData(m_ClientInfo, buffer);
                    }
                    try
                    {
                        this.sock.BeginReceive(m_Buffer, 0, m_Buffer.Length, SocketFlags.None, new AsyncCallback(ReceiveCallBack), this);//向系统投递下一个接收请求

                    }
                    catch (SocketException es) //出现Socket异常就关闭连接
                    {
                        CommonFunc.LogError("BeginReceive err:" + es.ToString());
                        try
                        {
                            CommonFunc.LogError("ReceiveMsg end!" + " ip:" + this.Ip + " PORT:" + this.Port);
                            if (this.OnClosedHandle != null)
                            {
                                OnClosedHandle();
                            }
                            m_bConnect = false;
                        }
                        catch (SocketException  ee) //出现Socket异常就关闭连接
                        {
                            CommonFunc.LogError("invoke onClientSocketClosed err:" + ee.ToString());

                        }
                        return;
                    }
                    catch (Exception ex)
                    {
                        try
                        {
                            CommonFunc.LogError("ReceiveMsg end22 !" + " ip:" + this.Ip + " PORT:" + this.Port);
                            if (this.OnClosedHandle != null)
                            {
                                OnClosedHandle();
                            }
                            m_bConnect = false;
                        }
                        catch (SocketException ee) //出现Socket异常就关闭连接
                        {
                            CommonFunc.LogError("invoke onClientSocketClosed err:" + ee.ToString());

                        }
                        return;
                    }

                }
                else //如果接收到0字节的数据说明客户端关闭了Socket，那我们也要关闭Socket
                {
                    try
                    {
                        CommonFunc.LogError("ReceiveMsg end!" + " ip:" + this.Ip + " PORT:" + this.Port);
                        if (this.OnClosedHandle != null)
                        {
                            OnClosedHandle();
                        }
                        m_bConnect = false;
                  
                    }
                    catch (SocketException ee) //出现Socket异常就关闭连接
                    {
                        CommonFunc.LogError("invoke onClientSocketClosed err:" + ee.ToString());

                    }

                }
            }
            catch (Exception e2)
            {
                CommonFunc.LogError("ReceiveCallBack Exception2 :" + e2.ToString());
            }
        }
        private void SendCallBack(IAsyncResult ar)
        {
            
            try
            {
              
                 sock.EndSend(ar);//调用这个函数来结束本次发送。
            }
            catch (Exception ex)
            {
                try
                {
                    if (this.OnClosedHandle != null)
                    {
                        OnClosedHandle();
                    }
                    m_bConnect = false;
                    CommonFunc.LogError("SendCallBack err:" + ex.ToString());
                }
                catch (Exception ex1)
                {

                    CommonFunc.LogError("SendCallBack   err1:" + ex1.ToString());
                }
            }
        }
        
    }
}