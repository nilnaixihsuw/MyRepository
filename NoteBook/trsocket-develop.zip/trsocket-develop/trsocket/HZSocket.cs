﻿using System;
using System.Collections.Generic;
using System.Text;

namespace trsocket
{
    public class HZSocket
    {
        private TRClientSocket m_ClientSock;
        private bool m_bAutoLogin = true;
        HZMessageHandle m_MsgHandle = new HZMessageHandle();
        private uint m_UserID;//平台编号
        private string m_PassWord;
        private TRServerSocket m_ServerSock;
        HZMessageHandle m_ServerMsgHandle =null;
        private bool m_bStarted = false;
        ushort m_LocalPort = 0;
        string m_LocalIP;
        private uint m_Login_ID=0;//用户登录ID
        private uint m_verifyCode = HZMessageHandle.VERIFY_CODE;//登录上级平台获得的授权码
          public SocketConnectResultHandle OnClientConnectHandle
        {
            get { return m_ClientSock.OnConnectHandle; }
            set { m_ClientSock.OnConnectHandle = value; }
        }
        public SocketClosedHandle OnClientCloseHandle
        {
            get { return m_ClientSock.OnClosedHandle; }
            set { m_ClientSock.OnClosedHandle = value; }
        }
       
        public bool IsClientConnect()
        {
            return m_ClientSock.IsConnect();

        }
        public ReqVehicleBaseInfoHandle_Secondary OnReqBaseInfo {
            get { return m_MsgHandle.OnReqBaseInfo; }
            set { m_MsgHandle.OnReqBaseInfo = value; } 
        }//从：请求车辆基本信息
        public TotalRecvHandle_Secondary OnTotalRecvHandle
        {
            get { return m_MsgHandle.OnTotalRecvHandle; }
            set { m_MsgHandle.OnTotalRecvHandle = value; }
        }//从：接收总数通知
        public ReqDriverInfoHandle_Secondary OnReqDrieverInfo
        {
            get { return m_MsgHandle.OnReqDrieverInfo; }
            set { m_MsgHandle.OnReqDrieverInfo = value; }
        }
        
        
        //请求驾驶员信息
        public PlatFormQueryHandle_Secondary OnPlatFormQuery{
            get { return m_MsgHandle.OnPlatFormQuery; }
            set { m_MsgHandle.OnPlatFormQuery = value; }
        }//从：平台查岗请求
        public PlatFormMsgInfoHandle_Secondary OnPlatFormMsgInfo
        {
            get { return m_MsgHandle.OnPlatFormMsgInfo; }
            set { m_MsgHandle.OnPlatFormMsgInfo = value; }
        }//从：平台报文请求

        public ConnectRequest OnConnectRequest
        {
            get { return m_MsgHandle.OnConnectRequest; }
            set { m_MsgHandle.OnConnectRequest = value; }
        }//主：下级连接请求
        public ConnectTestLink OnConnectTestLink
        {
            get { return m_MsgHandle.OnConnectTestLink; }
            set { m_MsgHandle.OnConnectTestLink = value; }
        }//主：下级保持连接请求

        public GpsArrive OnGpsArrive
        {
            get { return m_MsgHandle.OnGpsArrive; }
            set { m_MsgHandle.OnGpsArrive = value; }
        }//主：下级上报定位数据

        //收到数据通知
        public RawDataArrive OnRawDataArrive
        {
            get { return m_MsgHandle.OnRawDataArrive; }
            set { m_MsgHandle.OnRawDataArrive = value; }
        }
        //收到主链路注销
        public  Logout OnLogout
        {
            get { return m_MsgHandle.OnLogout; }
            set { m_MsgHandle.OnLogout = value; }
        }   
        //收到主链路车辆注册
        public  VehicleRegister OnVehicleRegister
        {
            get { return m_MsgHandle.OnVehicleRegister; }
            set { m_MsgHandle.OnVehicleRegister = value; }
        }
        //收到驾驶员信息上报
        public  DriverInfoReport OnDriverInfoReport
        {
            get { return m_MsgHandle.OnDriverInfoReport; }
            set { m_MsgHandle.OnDriverInfoReport = value; }
        } 
        //收到驾驶员下级平台运单上报
        public VehilceBillRecv OnVehilceBillRecv
        {
            get { return m_MsgHandle.OnVehilceBillRecv; }
            set { m_MsgHandle.OnVehilceBillRecv = value; }
        }
        //收到督办
        public WantWarnToDo OnWantWarnToDo
        {
            get { return m_MsgHandle.OnWantWarnToDo; }
            set { m_MsgHandle.OnWantWarnToDo = value; }
        } 
         //收到短信
        public  SendVehicleMsg OnSendVehicleMsg
        {
            get { return m_MsgHandle.OnSendVehicleMsg; }
            set { m_MsgHandle.OnSendVehicleMsg = value; }
        } 
         //紧急接入
        public  WantVehicleChangeNet OnWantVehicleChangeNet
        {
            get { return m_MsgHandle.OnWantVehicleChangeNet; }
            set { m_MsgHandle.OnWantVehicleChangeNet = value; }
        } 
        //电话监听
        public  WantVehicleMonitorTelephone OnWantVehicleMonitorTelephone
        {
            get { return m_MsgHandle.OnWantVehicleMonitorTelephone; }
            set { m_MsgHandle.OnWantVehicleMonitorTelephone = value; }
        }
        //拍照
        public WantVehiclePhoto OnWantVehiclePhoto
        {
            get { return m_MsgHandle.OnWantVehiclePhoto; }
            set { m_MsgHandle.OnWantVehiclePhoto = value; }
        } 
        //记录仪请求
        public  WantVehicleTravel OnWantVehicleTravel
        {
            get { return m_MsgHandle.OnWantVehicleTravel; }
            set { m_MsgHandle.OnWantVehicleTravel = value; }
        }
        public HZSocket(string IP,int Port,uint UserID,string PassWord,string LocalIP,ushort LocalPort,bool AutoLogin,uint Login_id) {
            m_bAutoLogin = AutoLogin;
            m_LocalIP = LocalIP;
            m_LocalPort = LocalPort;
            m_ServerMsgHandle = m_MsgHandle;
            m_MsgHandle.OnLoginResult = OnLogin;
            m_MsgHandle.OnMsgReturnStartup = OnReturnStartup;
            m_MsgHandle.OnMsgReturnEnd = OnMsgReturnEnd;
            m_MsgHandle.OnWantVehicleBill = OnWantVehicleBill;
            
            try
            {
                StartServer(LocalPort);
            }
            catch { 
            
            }
            m_UserID=UserID;
            m_PassWord=PassWord;
            m_Login_ID = Login_id;
            m_ClientSock = new TRClientSocket(IP, Port, false, m_MsgHandle);
            m_ClientSock.SetRecvTimeOut(60000);
            m_ClientSock.OnClosedHandle += OnSocketClosed;
            m_ClientSock.OnConnectHandle += OnSocketConnect;
            
        }
        public HZSocket(string IP, int Port, uint UserID, string PassWord, string LocalIP, ushort LocalPort, bool AutoLogin, bool UseUdp,uint  Login_id)
        {
            m_bAutoLogin = AutoLogin;
            m_LocalIP = LocalIP;
            m_LocalPort = LocalPort;
            m_ServerMsgHandle = m_MsgHandle;
            m_MsgHandle.OnLoginResult += OnLogin;
            m_MsgHandle.OnMsgReturnStartup = OnReturnStartup;
            m_MsgHandle.OnMsgReturnEnd = OnMsgReturnEnd;
            m_MsgHandle.OnWantVehicleBill = OnWantVehicleBill;
            try
            {
                if (UseUdp)
                {
                    StartUdpServer(LocalPort);
                }
                else
                {
                    StartServer(LocalPort);
                }
            }
            catch
            {

            }
            m_UserID = UserID;
            m_PassWord = PassWord;
            m_Login_ID = Login_id;
            m_ClientSock = new TRClientSocket(IP, Port, false, m_MsgHandle);
            m_ClientSock.SetRecvTimeOut(60000);
            m_ClientSock.OnClosedHandle += OnSocketClosed;
            m_ClientSock.OnConnectHandle += OnSocketConnect;

        }
        /// <summary>
        /// 主链路登录
        /// </summary>
        public void Login()  {
            byte[] byteSend = m_MsgHandle.MakeLogin(m_UserID, m_PassWord, m_LocalIP, m_LocalPort, m_Login_ID);
            m_ClientSock.SendMsg(byteSend);
        }
        /// <summary>
        /// 登录成功事件
        /// </summary>
        /// <param name="Result"></param>
        /// <param name="VeryfyCode"></param>
        private void OnLogin(byte Result, uint VeryfyCode)
        {
            m_verifyCode = VeryfyCode;
            System.Console.Out.WriteLine("登录结果：" + Result.ToString());
        }
        
        /// <summary>
        /// 注册车辆
        /// </summary>
        /// <param name="VehicleNo"></param>
        /// <param name="VehicleColor"></param>
        /// <param name="TermFactory"></param>
        /// <param name="TermType"></param>
        /// <param name="TermNo"></param>
        /// <param name="SimCode"></param>
        public void SendRegister(string VehicleNo,byte VehicleColor,string TermFactory,string TermType,string TermNo,string SimCode) {
            byte[] byteSend = m_MsgHandle.MakeRegisterData( VehicleNo, VehicleColor, TermFactory, TermType, TermNo, SimCode);
            m_ClientSock.SendMsg(byteSend);
        }
        /// <summary>
        /// 上报实时信息
        /// </summary>
        /// <param name="VehicleNo"></param>
        /// <param name="VehicleColor"></param>
        /// <param name="Time"></param>
        /// <param name="Lat"></param>
        /// <param name="Lng"></param>
        /// <param name="Speed"></param>
        /// <param name="Speed_machine"></param>
        /// <param name="total_course"></param>
        /// <param name="Angle"></param>
        /// <param name="Height"></param>
        /// <param name="Status"></param>
        /// <param name="Alarm"></param>
        public void SendGps(GPSDATA data)
        {

            byte[] byteSend = m_MsgHandle.MakeGpsData(data);
            m_ClientSock.SendMsg(byteSend);
        }
        /// <summary>
        /// GPS历史数据补报
        /// </summary>
        /// <param name="datas"></param>
        public void SendHistoryGps(List<GPSDATA> datas)
        {

            byte[] byteSend = m_MsgHandle.MakeGpsHistoryData(datas);
            m_ClientSock.SendMsg(byteSend);
        }
        /// <summary>
        /// 主链路注销
        /// </summary>
        public void SendLogout()
        {
            byte[] byteSend = m_MsgHandle.MakeLogout();
            m_ClientSock.SendMsg(byteSend);
        }
        public void SendLinkTest()
        {
            byte[] byteSend = m_MsgHandle.MakeLinkTest();
            m_ClientSock.SendMsg(byteSend);
        }
        public void SendDriver_Answer(string VehicleNo, byte VehicleColor,string Name,string ID,string Licence,string Org_Name) {
            byte[] byteSend = m_MsgHandle.MakeDriverData(HZMessageHandle.UP_EXG_MSG_REPORT_DRIVER_INFO_ACK, VehicleNo,  VehicleColor, Name, ID, Licence, Org_Name);
            m_ClientSock.SendMsg(byteSend);
        }
        public void SendDriver(string VehicleNo, byte VehicleColor, string Name, string ID, string Licence, string Org_Name)
        {
            byte[] byteSend = m_MsgHandle.MakeDriverData(HZMessageHandle.UP_EXG_MSG_REPORT_DRIVER_INFO , VehicleNo, VehicleColor, Name, ID, Licence, Org_Name);
            m_ClientSock.SendMsg(byteSend);
        }
        public void SendDisconnect_Second(byte reason)
        {
            byte[] byteSend = m_MsgHandle.MakeDisconnect(reason);
            m_ClientSock.SendMsg(byteSend);
        }
        public void SendCorpRegister(string Name,string CorpName,byte LogOut,DateTime Time,string IP,uint Port)
        {
            byte[] byteSend = m_MsgHandle.MakeCorpRegister( Name, CorpName, LogOut, Time, IP, Port);
            m_ClientSock.SendMsg(byteSend);
        }
        /// <summary>
        /// 主动上报运单
        /// </summary>
        /// <param name="VehicleNo"></param>
        /// <param name="VehicleColor"></param>
        /// <param name="content"></param>
        public void sendVehicleBill(  string VehicleNo, byte VehicleColor,string content)
        {
             
            byte[] byteSend = m_MsgHandle.MakeVehicleBill(HZMessageHandle.UP_EXG_MSG_MSG_REPORT_EWAYBILL_INFO,VehicleNo, VehicleColor, content);
            m_ClientSock.SendMsg(byteSend); 
        }
        /// <summary>
        /// 发送报警
        /// </summary>
        /// <param name="VehicleNo"></param>
        /// <param name="VehicleColor"></param>
        /// <param name="Source"></param>
        /// <param name="Kind"></param>
        /// <param name="TM"></param>
        /// <param name="InfoID"></param>
        /// <param name="Content"></param>
        public void SendVehicleWarn(string VehicleNo, byte VehicleColor, byte Source, ushort Kind, DateTime TM, uint InfoID, string Content) {
            byte[] byteSend = m_MsgHandle.MakeVehicleWarn(VehicleNo,   VehicleColor,   Source,   Kind,   TM,   InfoID,   Content);
            m_ClientSock.SendMsg(byteSend);
        }
        /// <summary>
        /// 发送报警处理结果
        /// </summary>
        /// <param name="VehicleNo"></param>
        /// <param name="VehicleColor"></param>
        /// <param name="InfoID"></param>
        /// <param name="Result"></param>
        public void SendVehicleWarnTODO(string VehicleNo, byte VehicleColor, uint InfoID, byte Result)
        {
            byte[] byteSend = m_MsgHandle.MakeVehicleWarnTODO(VehicleNo, VehicleColor, InfoID, Result );
            m_ClientSock.SendMsg(byteSend);
        }
        
        private void OnSocketConnect(bool success)
        {
            System.Console.Out.WriteLine("HZSocket连接：" + success.ToString());
            if (success)
            {
                if (this.m_bAutoLogin)
                {
                    Login();
                }
            }
        }
        private void OnSocketClosed()
        {
            System.Console.Out.WriteLine("HZSocket关闭：");
           
        }
          
        public void StartServer(ushort Port) {

            if (m_LocalPort == 0)
            {
                throw new Exception("未指定端口！");
            }
            
            if (m_bStarted) {
                StopServer();
            }
            m_ServerSock = new TRServerSocket();
            m_ServerMsgHandle.OnReqLogin += OnReqLogin;
            m_ServerMsgHandle.OnReqDisConnect += OnReqDisConnect;//从：请求断开
            m_ServerMsgHandle.OnReqTestConnect += OnReqTestConnect;//从：请求测试连接
             
            m_ServerSock.StartListen(m_LocalPort, m_ServerMsgHandle);
            m_bStarted = true;

 
        }
        public void StartUdpServer(ushort Port)
        {

            if (m_LocalPort == 0)
            {
                throw new Exception("未指定端口！");
            }

            if (m_bStarted)
            {
                StopServer();
            }
            m_ServerSock = new TRServerSocket();
            m_ServerMsgHandle.OnReqLogin += OnReqLogin;
            m_ServerMsgHandle.OnReqDisConnect += OnReqDisConnect;//从：请求断开
            m_ServerMsgHandle.OnReqTestConnect += OnReqTestConnect;//从：请求测试连接

            m_ServerSock.StartUdpListen(Port, m_ServerMsgHandle);
            m_bStarted = true;


        }
        public void StopServer()
        {
            if (!m_bStarted)
            {
                return;
            }
            m_ServerSock.StopListen();
            m_bStarted = false;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="VehicleCode">车牌</param>
        /// <param name="Color">颜色</param>
        /// <param name="VehicleType">车辆类型</param>
        /// <param name="TransType">运输类型</param>
        /// <param name="VehicleAddress">车辆所属地址</param>
        /// <param name="OwnerID">业主ID</param>
        /// <param name="OwnerName">业主姓名</param>
        /// <param name="OwnerPhone">业主电话</param>
       
        public void SendReqBaseInfo(string VehicleCode, byte Color,string VehicleType,string TransType,string VehicleAddress,string OwnerID,string OwnerName,string OwnerPhone)
        {//应答车辆静态信息
            byte[] byteSend = m_MsgHandle.MakeBaseVehilceInfo(VehicleCode, Color, VehicleType, TransType, VehicleAddress, OwnerID, OwnerName, OwnerPhone);
            m_ClientSock.SendMsg(byteSend);
        }
        public void SendReqBaseInfo_Fujian(string VehicleCode, byte Color, string VehicleType, string TransType, string VehicleAddress, string OwnerID, string OwnerName, string OwnerPhone,
              string SUPER_TRANS_TYPE,//	上级平台的营运类型代码
             string  MDT_PHONE_NUM,//	车载终端电话
             string  ISPHOTO,// 	是否支持拍照
              string OWNER_SEX,//	车主性别
            string   EXEC_NO,// 	身份证号码
           string    OWNER_CONTACT_ADDRESS,//	通讯地址
            string   FIRST_DRIVER_NAME,//	驾驶员一名称
            string   FC_PHONE,// 	驾驶员一电话
            string   SECOND_CONTACTER,//	驾驶员二名称
            string   SC_PHONE,// 	驾驶员二电话
           string    SERVICE_START_DATE,//	服务开始时间
          string    SERVICE_END_DATE,//	服务到期时间
          string    SEATING_CAPACITY,//	吨（座）位
          string     TRANSSERIALNO,//	道路运输证号
         string ROUTE_NAME
            )
        {//应答车辆静态信息
            byte[] byteSend =   m_MsgHandle.MakeBaseVehilceInfo_Fujian(VehicleCode, Color, VehicleType, TransType, VehicleAddress, OwnerID, OwnerName, OwnerPhone,
             SUPER_TRANS_TYPE,//	上级平台的营运类型代码
              MDT_PHONE_NUM,//	车载终端电话
              ISPHOTO,// 	是否支持拍照
              OWNER_SEX,//	车主性别
              EXEC_NO,// 	身份证号码
              OWNER_CONTACT_ADDRESS,//	通讯地址
              FIRST_DRIVER_NAME,//	驾驶员一名称
              FC_PHONE,// 	驾驶员一电话
              SECOND_CONTACTER,//	驾驶员二名称
              SC_PHONE,// 	驾驶员二电话
              SERVICE_START_DATE,//	服务开始时间
              SERVICE_END_DATE,//	服务到期时间
              SEATING_CAPACITY,//	吨（座）位
              TRANSSERIALNO,//	道路运输证号
              ROUTE_NAME//	营运线路
                    );
            m_ClientSock.SendMsg(byteSend);
        }
         public void SendMakeSuperWarnAnswer(string VehicleCode, byte Color, uint InfoID, byte result)
        {//应答督办
            byte[] byteSend = m_MsgHandle.MakeSuperWarn(VehicleCode, Color, InfoID, result);
            m_ClientSock.SendMsg(byteSend);
        }
        public void SendSendVehicleMsgAwser(string VehicleCode, byte Color, uint InfoID, byte result)
        {//应答短信
            byte[] byteSend = m_MsgHandle.MakeVehicleMsgAwser(VehicleCode, Color, InfoID, result);
            m_ClientSock.SendMsg(byteSend);
        }
        public void SendWantVehiclePhotoAnswer(string VehicleCode, byte Color, byte result,GPSDATA GPS ,byte  chanel,byte sizetag,byte photoType,byte[] photoData)
        {//应答拍照（是否要分批发送？）
            byte[] byteSend = m_MsgHandle.MakeWantVehiclePhotoAnswer(VehicleCode, Color, result,GPS ,chanel,sizetag,photoType,photoData);
            m_ClientSock.SendMsg(byteSend);
        }
        
        public void SendWantVehicleChangeNetAnswer(string VehicleCode, byte Color,   byte result)
        {//应答紧急接入
            byte[] byteSend = m_MsgHandle.MakeWantVehicleChangeNetAnswer(VehicleCode, Color, result);
            m_ClientSock.SendMsg(byteSend);
        }
        public void SendWantVehicleMonitorTelephoneAnswer(string VehicleCode, byte Color, byte result)
        {//应答电话监听
            byte[] byteSend = m_MsgHandle.MakeSendWantVehicleMonitorTelephoneAnswer(VehicleCode, Color, result);
            m_ClientSock.SendMsg(byteSend);
        }
        public void SendWantVehicleTravelAwser(string VehicleCode, byte Color, byte  type, byte[] data)
        {//应答短信
            byte[] byteSend = m_MsgHandle.MakeWantVehicleTravelAwser(VehicleCode, Color, type, data);
            m_ClientSock.SendMsg(byteSend);
        }
        /// <summary>
        /// 请求历史数据 UP_EXG_MSG_APPLY_HISGNSSDATA_REQ
        /// </summary>
        /// <param name="VehicleCode"></param>
        /// <param name="Color"></param>
        /// <param name="from"></param>
        /// <param name="end"></param>
        public void SendApplyHistory(string VehicleCode, byte Color, DateTime from, DateTime end)
        { 
            byte[] byteSend = m_MsgHandle.MakeApplyHistory(VehicleCode, Color, from, end);
            m_ClientSock.SendMsg(byteSend);
        }
        /// <summary>
        /// 发起交换信息请求 UP_EXG_MSG_APPLY_FOR_MONITOR_STARTUP
        /// </summary>
        /// <param name="VehicleCode"></param>
        /// <param name="Color"></param>
        /// <param name="from"></param>
        /// <param name="end"></param>
        public void SendMonitorStartup(string VehicleCode, byte Color, DateTime from, DateTime end)
        {
            byte[] byteSend = m_MsgHandle.MakeMonitorStartup(VehicleCode, Color, from, end);
            m_ClientSock.SendMsg(byteSend);
        }
        /// <summary>
        /// 取消实时数据请求UP_EXG_MSG_APPLY_FOR_MONITOR_END
        /// </summary>
        /// <param name="VehicleCode"></param>
        /// <param name="Color"></param>
        public void SendCancelMonitorStartup(string VehicleCode, byte Color )
        {
            byte[] byteSend = m_MsgHandle.MakeCancelMonitorStartup(VehicleCode, Color );
            m_ClientSock.SendMsg(byteSend);
        }
        void OnReqLogin(ClientInfo client, uint VerifyCode)
        {
            System.Console.Out.WriteLine("OnReqLogin:" + VerifyCode.ToString());
            byte answer = 0;
            if (VerifyCode == m_verifyCode)
            {
                answer = 0;
            }
            else
            {
                answer = 1;
            }
            byte[] byteSend = m_MsgHandle.MakeLoginReqAnswer(answer);
            m_ServerSock.SendMsg(client,byteSend);
        }
        void OnReqDisConnect(ClientInfo client )
        {
            System.Console.Out.WriteLine("OnReqDisConnect:"  );
            byte[] byteSend = m_MsgHandle.MakeReqDisConnectAnswer();
            m_ServerSock.SendMsg(client,byteSend);
        }
        void OnReqTestConnect(ClientInfo client)
        {
            CommonFunc.LogError("   收到车辆 OnReqTestConnect:" + client.socket);  
             
            byte[] byteSend = m_MsgHandle.MakeReqTestConnectAnswer();
            m_ServerSock.SendMsg(client,byteSend);
        }

        /// <summary>
        /// 应答下级平台登录请求
        /// </summary>
        /// <param name="client"></param>
        /// <param name="userID"></param>
        /// <param name="result"></param>
        public void AnswerClinetConnect(ClientInfo client, uint userID, byte result)
        {
            System.Console.Out.WriteLine("OnConnectAnswer:");
            byte[] byteSend = m_MsgHandle.MakeConnectReqAnswer(userID, result);
            m_ServerSock.SendMsg(client, byteSend);
        }
        /// <summary>
        /// 应答链路测试请求
        /// </summary>
        /// <param name="client"></param>
        public void AnswerClinetLinkTest(ClientInfo client)
        {
            System.Console.Out.WriteLine("OnAnswerClinetLinkTest:");
            byte[] byteSend = m_MsgHandle.MakeReqTestConnectAnswer_up();
            m_ServerSock.SendMsg(client, byteSend);
        }
        public void OnReturnStartup(string VehicleCode, byte Color, byte Reason)
        {
            byte[] byteSend = m_MsgHandle.MakeMsgStartup(VehicleCode, Color );
            m_ClientSock.SendMsg(byteSend);
        }
        public void OnMsgReturnEnd(string VehicleCode, byte Color, byte Reason)
        {
            byte[] byteSend = m_MsgHandle.MakeMsgEnd(VehicleCode, Color );
            m_ClientSock.SendMsg(byteSend);
        }
        public void OnWantVehicleBill(string VehicleCode, byte Color )
        {
            byte[] byteSend = m_MsgHandle.MakeVehicleBill(HZMessageHandle.UP_EXG_MSG_TAKE_EWAYBILL_ACK, VehicleCode, Color, "今日运单：发车站杭州目的站武汉！");
            m_ClientSock.SendMsg(byteSend);
        }
         
 #region 发送从链路的客户端请求消息（用于测试）
        /// <summary>
        /// 上级平台通过从链路登录
        /// </summary>
        public void SendDownLogin( )
        {

            byte[] byteSend = m_MsgHandle.MakeDownLogin(HZMessageHandle.VERIFY_CODE);
            m_ClientSock.SendMsg( byteSend);
        }
        /// <summary>
        /// 发送从链路保持
        /// </summary>
        public void SendDownLinkTest()
        {
            byte[] byteSend = m_MsgHandle.MakeDownLinkTest();
            m_ClientSock.SendMsg(byteSend);
        }
        /// <summary>
        /// 发送从链路注销请求
        /// </summary>
        public void SendDownLogout()
        {
            byte[] byteSend = m_MsgHandle.MakeDownLogout();
            m_ClientSock.SendMsg(byteSend);
        }
        public void SendDownMsgStartupReq(string VehicleNo, byte VehicleColor, byte reason)
        {
            byte[] byteSend = m_MsgHandle.MakeMsgStartupReq(VehicleNo,   VehicleColor,   reason);
            m_ClientSock.SendMsg(byteSend);
        }
        
 #endregion  
        /// <summary>
        /// 回应查岗信息
        /// </summary>
        /// <param name="kind"></param>
        /// <param name="objectID"></param>
        /// <param name="infoID"></param>
        /// <param name="content"></param>
        public void SendPlatFormQuery(byte kind, string objectID, uint infoID, string content){
            byte[] byteSend = m_MsgHandle.MakePlatFormQueryAnswer(kind, objectID, infoID, content);
            m_ClientSock.SendMsg(byteSend);
        }
        /// <summary>
        /// 平台间报文应答
        /// </summary>
        /// <param name="infoID"></param>
        public void SendPlatFormMsg(uint infoID)
        {
            byte[] byteSend = m_MsgHandle.MakePlatFormMsgAnswer(infoID);
            m_ClientSock.SendMsg(byteSend);
        }
        /// <summary>
        /// 设置加密相关参数
        /// </summary>
        /// <param name="M1"></param>
        /// <param name="IA1"></param>
        /// <param name="IC1"></param>
        /// <param name="Key"></param>
        public void SetOption( bool needEncrypt,uint M1, uint IA1, uint IC1, uint Key,string plat_form)
        {
            m_MsgHandle.SetOption(needEncrypt, M1, IA1, IC1, Key, plat_form);
            
        }
    }
}
