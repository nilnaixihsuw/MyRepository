﻿/**
 * 
 *                      瑞安公交对接接收数据UDPSOCKET
 * 
 * 
 */ 
using System;
using System.Collections.Generic;
using System.Text;

namespace trsocket
{
    public class RASocket
    {
       
        private TRServerSocket m_ServerSock;
        RAMessageHandle m_ServerMsgHandle = new RAMessageHandle();
        private bool m_bStarted = false;
        ushort m_LocalPort = 0;
        string m_LocalIP;


        public GpsArrive OnGpsArrive
        {
            get { return m_ServerMsgHandle.OnGps; }
            set { m_ServerMsgHandle.OnGps = value; }
        }
        public RASocket(string LocalIP, ushort LocalPort)
        {
            m_LocalIP = LocalIP;
            m_LocalPort = LocalPort;
            StartUdpServer(LocalPort );
         
        }
        public void StartUdpServer(ushort Port)
        {
            if (m_LocalPort == 0)
            {
                throw new Exception("未指定端口！");
            }

            if (m_bStarted)
            {
                StopServer();
            }
            m_ServerSock = new TRServerSocket();
            m_ServerSock.StartUdpListen(Port, m_ServerMsgHandle);
            m_bStarted = true;
        }
        
        public void StopServer()
        {
            if (!m_bStarted)
            {
                return;
            }
            m_ServerSock.StopListen();
            m_bStarted = false;
        }
        
    }
}
