﻿using System;
using System.Collections.Generic;
using System.Text;
namespace trsocket
{
    public delegate void LoginAnswerHandler(DATA_CMD_LOGIN_ANSWER answer);
    public delegate void StationNotifyHandler(DATA_STATION_PREDICTION notify);
    public delegate void MessageHandler(DATA_STATION_MESSAGE msg);
    public delegate void CommandHandler(DATA_STATION_COMMAND cmd);
    public delegate void StationFileHandler(DATA_STATION_FILE file);
    public delegate void AnalyzeErrorHandle();
    public delegate void SocketConnectResultHandle(bool success);
    public delegate void SocketClosedHandle();
    public delegate void PingAnswerHandle(uint seqID);
    public delegate void RawMessageArrive(byte[] msg);//原始SOCKE信息收到通知
    public delegate void ConnectErrorHandle(ClientInfo info);
    public delegate void ClientSocketClosed(ClientInfo info);
    public delegate void GPSDataHandler(
        DateTime PostTime,
         uint VehicleID,//车辆ID
         double LAT,//经度
         double LNG,//纬度
         double LAT_OFF,//经度
         double LNG_OFF,//纬度
         double Speed,//速度0.1公里/小时
         uint Angle,//角度
         uint Oil,//油量
         uint LastStationID,//最后站点
         uint OutStation,//最后出站标志
         uint LastLineID,//最后线路
         uint OtherInfo,
        uint DistLeaveStation,//离开上个站点以后，又走了多远距离（米）
        uint LastOil,//油耗
        uint Online,
        uint AlarmType);
    public delegate void StationOnline(UInt32 StatonID,byte Online);
    
    public delegate void ShutdownComputerHandler();
    public delegate void RestartComputerHandler();
    public delegate void SetIpPortHandler(string ip, string port);
    public delegate void SetShutdownHandler(string Time);
    public delegate void DeleteStationItemHandler(string ItemName);
    public delegate void GetStationItemsHandler();
    public delegate void GetItemsSuccessHandler(UInt32 StationID, string items);
    public delegate void ChangeStationIPHandler(DATA_STATION_IP IP);
    public delegate void ChangeItemHandler(
                        uint StationID,
                        uint UserID,
                        uint KeepLong,
                        uint Seq,
                        uint MaxTimesDay,
                        uint TxtFontsize,
                        string FromTime,
                        string ToTime,
                        string Fromdate,
                        string Todate,
                        string FileName);
    //============杭州运管部分开始==============================
    ///////主链路
    public delegate void  LoginResultHandle(byte Result,uint VerifyCode);//登录回应
    public delegate void ConnectTestAnswerHandle();//测试连接回应
    ///////从链路
    public delegate void ReqVehicleBaseInfoHandle_Secondary(string VehicleCode, byte Color);//从：请求基本车辆信息
    public delegate void ReqConnectHandle_Secondary(ClientInfo client, uint VerifyCode);//从：请求连接
    public delegate void ReqDisConnectHandle_Secondary(ClientInfo client);//从：请求断开
    public delegate void ReqTestConnectHandle_Secondary(ClientInfo client);//从：请求测试连接
    public delegate void TotalRecvHandle_Secondary(ClientInfo client, uint count, DateTime fromTime, DateTime toTime);//从：收到GPS定位数通知
    public delegate void ReqDriverInfoHandle_Secondary(string VehicleCode, byte Color);//从：请求驾驶员信息
    public delegate void PlatFormQueryHandle_Secondary(byte kind,string objectID,uint infoID,string content);//从：平台查岗请求
    public delegate void PlatFormMsgInfoHandle_Secondary(byte kind, string objectID, uint infoID, string content);//从：平台报文请求
    public delegate void MsgReturnStartup(string VehicleCode, byte Color, byte Reason);//从： DOWN_EXG_MSG_RETURN_STARTUP 
    public delegate void MsgReturnEnd(string VehicleCode, byte Color, byte Reason);//从：     DOWN_EXG_MSG_RETURN_END 
    public delegate void WantVehicleBill(string VehicleCode, byte Color);//从：     DOWN_EXG_MSG_TAKE_EWAYBILL_REQ 
    public delegate void WantWarnToDo(string VehicleCode, byte Color, byte warn_src, UInt16 warn_type, DateTime warn_time, uint supervison_id, DateTime superverion_endtime, byte level, string supervisor, string supervisor_tel, string supervisor_email);//从：     DOWN_WARN_MSG_URGE_TODO_REQ 
    public delegate void SendVehicleMsg(string VehicleCode, byte Color,uint msgID, byte priority,   string content);//从：     收到发给车辆的短信 
    public delegate void WantVehicleChangeNet(string VehicleCode, byte Color, string auth_code, string access_point_name, string username, string password, string server_ip, UInt16 port1, UInt16 port2, DateTime monitor_End);//从：     紧急接入 
    public delegate void WantVehicleMonitorTelephone(string VehicleCode, byte Color, string telCode);//从：     申请监听 
    public delegate void WantVehiclePhoto(string VehicleCode, byte Color, byte chanel,byte size);//从：     拍照请求 
    public delegate void WantVehicleTravel(string VehicleCode, byte Color, byte command);//从：     行驶记录仪请求 
                                  
                                    
                                 
    //主链路收到信息
    public delegate void ConnectRequest(ClientInfo info, uint userID, string password);//主：收到下级平台连接请求
    public delegate void GpsArrive(string vehCode, DateTime time, double lat, double lng, double speed, short angle);//主：收到下级平台GPS定位包
    public delegate void ConnectTestLink(ClientInfo info);//主：收到下级平台链路保持请求
    public delegate void Logout(ClientInfo info,uint loginID,string password);//主：收到下级平台链路保持请求
    public delegate void VehicleRegister(ClientInfo info, string vehCode,string vehColor,string factory ,string term_type,string term_no ,string sim_no);//主：收到下级平台车辆注册请求
    public delegate void DriverInfoReport(ClientInfo info,string vehCode,string vehColor, string driverName, string idCard, string certCard, string org_name);//主：收到下级平台驾驶证信息上报
    public delegate void VehilceBillRecv(ClientInfo info, string vehCode, string vehColor, string content);//主：收到下级平台运单
    
    
    //============杭州运管部分结束==============================
    public delegate void RawDataArrive(byte []info);//原始数据包到达通知
    //手机APP开始
    public delegate void APPRegister(ClientInfo info, string serverID, uint userID, string password, string version, string sequnce, string session_id);
    public delegate void APPLogout(ClientInfo info, string reason);
    public delegate void APPPing(ClientInfo info, string sequnce);
    public delegate void APPReportGps(ClientInfo info, int vehiceID,double lat,double lng,double speed,short angle,DateTime time,int altitude,uint state,uint alarm );
    public delegate void APPStartGpsAck(ClientInfo info);
    public delegate void APPTickOut(ClientInfo info);
    //手机APP结束
    class DelegateDeclare
    {
    }
}
