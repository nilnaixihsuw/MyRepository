﻿using System;
using System.Collections.Generic;
using System.Text;

namespace trsocket
{
    public delegate void DataArriveHandle(string strData);//数据到达通知
    public delegate void GPSDataHandle(uint VehicleID,uint LineID,uint StationID,DateTime GpsTime,double Lat,double Lng,double Speed,double Angle);//数据到达通知

    class SQMessageHandle : AbstractMessageHandle
    {
        public DataArriveHandle OnDataArrive=null;
        public GPSDataHandle OnGPSData= null;
        protected override bool Analyze(ClientInfo info)
        {
            byte[] totalBuf = this.GetBuffer(info);
            if (totalBuf.Length < 7)
            {
                return false;
            }
            //测试开始
            //try
            //{
            //    this.HandlePackage(info, totalBuf);
            //    this.RemoveLeftData(info, totalBuf.Length);
            //    return true;
            //}
            //catch
            //{
            //    if (OnDataArrive!=null)
            //    {
            //        OnDataArrive("出问题了！");
            //    }
            //}
            //测试结束
            
            //数据包头，4字节，内容固定为“$@$@”。
            //数据包长度，2字节的整数。
        // 数据包内容，字节数等于数据包长度。
           
            int thisPackageSize = 0;
            if (totalBuf[0] != '$' || totalBuf[1] != '@' || totalBuf[2] != '$' || totalBuf[3] != '@')
            {
                goto lastrow;
            }


            bool find = false;
            for (thisPackageSize = 4; thisPackageSize < totalBuf.Length-3; thisPackageSize++)
            {
                if (totalBuf[thisPackageSize] == '$' && totalBuf[thisPackageSize + 1] == '@' && totalBuf[thisPackageSize + 2] == '$' && totalBuf[thisPackageSize + 3] == '@')
                {
                    find = true;
                    //thisPackageSize += 1;
                    break;
                }
            }
            if (!find && totalBuf.Length == 64 && totalBuf[6]==0x80)//定位包
            {
                thisPackageSize = 64;
                find = true;
                
            }

            if (find)//完成一个包
            {
                byte[] packBuf = new byte[thisPackageSize];
                Array.Copy(totalBuf, 0, packBuf, 0, thisPackageSize);
                try
                {
                    this.HandlePackage(info, packBuf);
                }
                catch (Exception ex)
                {
                    System.Console.Out.WriteLine(ex.ToString());

                }
                this.RemoveLeftData(info, thisPackageSize);
                return true;
            }
            else
            {
                return false;
            }
        //非法数据包，发通知
        lastrow:
            this.OnAnalyzeWrong(info);
            return false;
        }
      
       
        public void HandlePackage(ClientInfo info, byte[] package)
        {
            string debugString = "";
            if (OnDataArrive != null)
            {
                for (int i = 0; i < package.Length; i++)
                {
                    string hexOutput = String.Format("{0:X}", package[i]);
                    if (hexOutput.Length < 2)
                    {
                        hexOutput = "0" + hexOutput;
                    }
                    debugString += " " + hexOutput;
                }
                OnDataArrive(debugString);
            }
            //return;
            if (package.Length < 10)
            {
                throw new Exception("数据包太短！");
            }
            
            //转义处理：
            byte[] retBuff = package;// HandlePackageReEscape(package);

            //===============================临时
           
            //for (int i = 0; i < package.Length; i++)
            //{
            //    string hexOutput = String.Format("{0:X}", package[i]);
            //    if (hexOutput.Length < 2)
            //    {
            //        hexOutput = "0" + hexOutput;
            //    }
            //    debugString += " " + hexOutput;
            //}
            //System.Console.Out.WriteLine("接收到：" + debugString);
            //===============================结束临时
            //提出命令字：

            byte cmd = retBuff[6];
            //string strCMD = "";
            //string hexOutput1 = String.Format("{0:X}", cmd >> 8);

            //if (hexOutput1.Length < 2)
            //{
            //    hexOutput1 = "0" + hexOutput1;
            //}
            //string hexOutput2 = String.Format("{0:X}", cmd & 0xFF);
            //if (hexOutput2.Length < 2)
            //{
            //    hexOutput2 = "0" + hexOutput2;
            //}
            //strCMD = hexOutput1 + " " + hexOutput2;


            switch (cmd)
            {
                case 0x80:
                    if (retBuff.Length<41)
                    {
                        System.Console.Out.WriteLine("sdfsdfdsf");
                        return;
                    
                    }
                    uint LineID = (uint)((retBuff[7] << 24) + (retBuff[8] << 16) + (retBuff[9] << 8) + retBuff[10]);
                    uint VehicleID = (uint)((retBuff[11] << 24) + (retBuff[12] << 16) + (retBuff[13] << 8) + retBuff[14]);
                    uint StationID = (uint)((retBuff[19] << 24) + (retBuff[20] << 16) + (retBuff[21] << 8) + retBuff[22]);
                    double Lng, Lat;
                    int year = (retBuff[23] << 8) + retBuff[24];
                    int month = retBuff[25];
                    int day = retBuff[26];
                    int hour =retBuff[27];
                    int minute = retBuff[28];
                    int second = retBuff[29];

                    DateTime GpsTime=new DateTime(year,month,day,hour,minute,second);
 
                    byte LngDegree=retBuff[30];
                    double LngMinute=retBuff[31];
                    double LngMinute2=((retBuff[32]<<8)+retBuff[33]);
                    int length=Convert.ToString(LngMinute2).Length;
                    LngMinute2=LngMinute2*(Math.Pow(10,(-1)*length));
                    Lng=LngDegree+(LngMinute+LngMinute2)/60;


                    byte LatDegree = retBuff[34];
                    double LatMinute = retBuff[35];
                    double LatMinute2 = ((retBuff[36] << 8) + retBuff[37]);
                    length = Convert.ToString(LatMinute2).Length;
                    LatMinute2 = LatMinute2 * (Math.Pow(10, (-1) * length));
                    Lat = LatDegree + (LatMinute + LatMinute2) / 60;

                    double Speed = retBuff[38];
                    double Angle = (retBuff[39] << 8) + retBuff[40];

                    if (OnGPSData != null) {
                        OnGPSData(VehicleID, LineID, StationID, GpsTime, Lat, Lng, Speed, Angle);
                    }
                    break;

                  default:

                    System.Console.Out.WriteLine("未知命令！" + cmd.ToString());

                    throw new Exception("未知命令！" + cmd.ToString());
            }

        }
        public byte[] MakeReqestGpsData()
        {
            List<byte> byteList = new List<byte>();
            //头：===============================================================
            //头(1)
            byteList.Add(Convert.ToByte('$'));//头$@$@
            byteList.Add(Convert.ToByte('@'));
            byteList.Add(Convert.ToByte('$'));
            byteList.Add(Convert.ToByte('@'));
            //数据头：===============================================================
            //数据长度(4)
            byteList.Add(0x00);
            byteList.Add(0x00);
            //包标记：
            byteList.Add(0x01);
            //名称长度
            byteList.Add(2);
            //名称
            byteList.Add(Convert.ToByte('a'));
            byteList.Add(Convert.ToByte('b'));
            //接收掩码
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x01);
            //时间范围
            byteList.Add(60);
            //包长度
            int TotalCount = 9;
            byteList[4] = (byte)(TotalCount&0xff00);
            byteList[5] = (byte)((TotalCount & 0x00ff) );
          
            byte[] bts = byteList.ToArray();
            return  bts;
        }
        public override AbstractMessageHandle NewInstance()
        {
            SQMessageHandle ret = new SQMessageHandle();
           // ret.OnLoginResult += this.OnLoginResult;
            //ret.OnReqBaseInfo += this.OnReqBaseInfo;
            return ret;
        }
    }
}
