﻿/*
 * 
 * 
 *
 *          瑞安其他公司数据交换解析器
 * 
 * 
 * 
 */
using System;
using System.Collections.Generic;
using System.Text;

namespace trsocket
{
    class RAMessageHandle : AbstractMessageHandle
    {
        public GpsArrive OnGps;
        protected override bool Analyze(ClientInfo info)
        {
            
            byte[] totalBuf = this.GetBuffer(info);
            if (totalBuf.Length < 10)
            {
                return false;
            }
            if (totalBuf[0] !='*')
            {
                goto lastrow;
            }
            //查找结束符:'#'
            int thisPackageSize = 0;
            for (int i = 0; i < totalBuf.Length; i++)
            {
                if (totalBuf[i] == '#')
                {
                    thisPackageSize = i + 1;
                    break;
                }
            }
               
            byte[] packBuf = new byte[thisPackageSize];
            Buffer.BlockCopy(totalBuf, 0, packBuf, 0, thisPackageSize);
            //Array.Copy(totalBuf, 0, packBuf, 0, thisPackageSize);
            try
            {
                this.HandlePackage(info, packBuf);
            }
            catch
            {

            }
            this.RemoveLeftData(info, thisPackageSize);
            return true;
          
        //非法数据包，发通知
        lastrow:
            this.OnAnalyzeWrong(info);
            return false;
        }
        public void HandlePackage(ClientInfo info, byte[] package)
        {
            if (package.Length < 10)
            {
                throw new Exception("数据包太短！");
            }
            if (package[0] != '*' || package[package.Length - 1] != '#')
            {
                throw new Exception("非法的数据包！");
            }
             
            //转换为字符
            string strData=Encoding.GetEncoding("utf-8").GetString(package );
            string []cmdArray=strData.Split('|');
            //提出命令字：
            string strCMD = cmdArray[1];
            switch (strCMD)
            {
                case "GPSPosInfo":
                    if (OnGps != null )
                    {//*|GPSPosInfo|1.0.4|WZ|1|A1|10|mxJ5;RLXEoom|0|0|120.6903|27.8232|0.01|+0.0|0|1409022966|0|-1|nhs#
                        string vehCode =Encoding.GetEncoding("gbk").GetString( Base64.decode( cmdArray[7].ToCharArray()));
                        DateTime time=UTCToDateTime(Convert.ToDouble( cmdArray[15]));
                       // //Console.WriteLine(DateTime.Now.ToString("HH:mm:ss") + "--gps:" + time.ToString("HH:mm:ss"));
                        double lat = Convert.ToDouble(cmdArray[11]);
                        double lng = Convert.ToDouble(cmdArray[10]);
                        double speed = Convert.ToDouble(cmdArray[12]);
                        short angle=(short)Convert.ToDouble( cmdArray[14]);
                        OnGps(vehCode, time, lat, lng, speed, angle);
                    }
                    break;
                default:
                    System.Console.Out.WriteLine("未知命令！" + strCMD);
                    //throw new Exception("未知命令！" + strCMD);
                   break;
                /////============================DOWN结束=========================
             }

        }

        private DateTime UTCToDateTime(double l)
        {
            DateTime dtZone = new DateTime(1970, 1, 1, 0, 0, 0);
            dtZone = dtZone.AddSeconds(l);
            return dtZone.ToLocalTime();
        }
         
        public override AbstractMessageHandle NewInstance()
        {
            ZDMessageHandle ret = new ZDMessageHandle(0);
           
            return ret;
        }
    }
}
