﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Security.Cryptography;

namespace trsocket
{


    public class Ningbo809MessageHandle : AbstractMessageHandle
    {
        public const UInt16 UP_CONNECT_REQ = 0x1001;
        public const UInt16 UP_CONNECT_RSP = 0x1002;
        public const UInt16 UP_DISCONNECT_REQ = 0x1003;
        public const UInt16 UP_DISCONNECT_RSP = 0x1004;

        public const UInt16 UP_LINKTEST_REQ = 0x1005;
        public const UInt16 UP_LINKTEST_RSP = 0x1006;
        public const UInt16 UP_DISCONNECT_INFORM = 0x1007;
        public const UInt16 UP_CLOSELINK_INFORM = 0x1008;

        public const UInt16 DOWN_CONNECT_REQ = 0x9001;
        public const UInt16 DOWN_CONNECT_RSP = 0x9002;
        public const UInt16 DOWN_DISCONNECT_REQ = 0x9003;
        public const UInt16 DOWN_DISCONNECT_RSP = 0x9004;

        public const UInt16 DOWN_LINKTEST_REQ = 0x9005;
        public const UInt16 DOWN_LINKTEST_RSP = 0x9006;
        public const UInt16 DOWN_DISCONNECT_INFORM = 0x9007;
        public const UInt16 DOWN_CLOSELINK_INFORM = 0x9008;

        public const UInt16 DOWN_TOTAL_RECV_BACK_MSG = 0x9101;
        public const UInt16 UP_EXG_MSG = 0x1200;
        public const UInt16 DOWN_EXG_MSG = 0x9200;

        public const UInt16 UP_PLATFORM_MSG = 0x1300;
        public const UInt16 DOWN_PLATFORM_MSG = 0x9300;
        public const UInt16 UP_WARN_MSG = 0x1400;
        public const UInt16 DOWN_WARN_MSG = 0x9400;
        public const UInt16 DOWN_WARN_MSG_URGE_TODO_REQ = 0x9401;
        public const UInt16 DOWN_WARN_MSG_INFORM_TIPS = 0x9402;
        public const UInt16 DOWN_WARN_MSG_EXG_INFORM = 0x9403;
          
        public const UInt16 UP_CTRL_MSG = 0x1500;
        public const UInt16 DOWN_CTRL_MSG = 0x9500;
        public const UInt16 UP_BASE_MSG = 0x1600;
        public const UInt16 DOWN_BASE_MSG = 0x9600;


       //---
        public const UInt16 UP_EXG_MSG_REGISTER = 0x1201;
        public const UInt16 UP_EXG_MSG_REAL_LOCATION = 0x1202;
        public const UInt16 UP_EXG_MSG_HISTORY_LOCATION = 0x1203;
        public const UInt16 UP_EXG_MSG_RETURN_STARTUP_ACK = 0x1205;
        public const UInt16 UP_EXG_MSG_RETURN_END_ACK = 0x1206;
        public const UInt16 UP_EXG_MSG_APPLY_FOR_MONITOR_STARTUP = 0x1207;
        public const UInt16 UP_EXG_MSG_APPLY_FOR_MONITOR_END = 0x1208;

        public const UInt16 UP_EXG_MSG_APPLY_HISGNSSDATA_REQ = 0x1209;
        public const UInt16 UP_EXG_MSG_REPORT_DRIVER_INFO_ACK = 0x120A;
        public const UInt16 UP_EXG_MSG_TAKE_EWAYBILL_ACK = 0x120B;
        public const UInt16 UP_EXG_MSG_REPORT_DRIVER_INFO = 0x120C;
        public const UInt16 UP_EXG_MSG_MSG_REPORT_EWAYBILL_INFO = 0x120D;
        public const UInt16 UP_EXG_MSG_CORP_CENTER_INFO = 0x0201;

        //----
        public const UInt16 DOWN_EXG_MSG_CAR_LOCATION = 0x9202;
        public const UInt16 DOWN_EXG_MSG_CAR_HISTORY_ARCOSSAREA = 0x9203;
        public const UInt16 DOWN_EXG_MSG_CAR_INFO = 0x9204;
        public const UInt16 DOWN_EXG_MSG_RETURN_STARTUP = 0x9205;
        public const UInt16 DOWN_EXG_MSG_RETURN_END = 0x9206;
        public const UInt16 DOWN_EXG_MSG_APPLY_FOR_MONITOR_STARTUP_ACK = 0x9207;
        public const UInt16 DOWN_EXG_MSG_APPLY_FOR_MONITOR_END_ACK = 0x9208;
        public const UInt16 DOWN_EXG_MSG_APPLY_HISGNSSDATA_ACK = 0x9209;
        public const UInt16 DOWN_EXG_MSG_REPORT_DRIVER_INFO = 0x920A;
        public const UInt16 DOWN_EXG_MSG_TAKE_EWAYBILL_REQ = 0x920B;
        //--
        public const UInt16 DOWN_EXG_MSG_CORP_CENTER_INFO_ACK = 0xF201;
        public const UInt16 UP_PLATFORM_MSG_POST_QUERY_ACK = 0x1301;
        public const UInt16 UP_PLATFORM_MSG_INFO_ACK = 0x1302;

        public const UInt16 DOWN_PLATFORM_MSG_POST_QUERY_REQ = 0x9301;
        public const UInt16 DOWN_PLATFORM_MSG_INFO_REQ = 0x9302;
        public const UInt16 UP_WARN_MSG_URGE_TODO_ACK = 0x1401;
        public const UInt16 UP_WARN_MSG_ADPT_INFO = 0x1402;
        //public const UInt16 UP_WARN_MSG_EXG_INFORM = 0x1403;
        public const UInt16 UP_WARN_MSG_ADPT_TODO_INFO=0X1403;
        public const UInt16 UP_CTRL_MSG_MONITOR_VEHICLE_ACK = 0x1501;
        public const UInt16 UP_CTRL_MSG_TAKE_PHOTO_ACK = 0x1502;

        public const UInt16 UP_CTRL_MSG_TEXT_INFO_ACK = 0x1503;
        public const UInt16 UP_CTRL_MSG_TAKE_TRAVEL_ACK = 0x1504;
        public const UInt16 UP_CTRL_MSG_EMERGENCY_MONITORING_ACK = 0x1505;

        public const UInt16 DOWN_CTRL_MSG_MONITOR_VEHICLE_REQ = 0x9501;
        public const UInt16 DOWN_CTRL_MSG_TAKE_PHOTO_REQ = 0x9502;
        public const UInt16 DOWN_CTRL_MSG_TEXT_INFO = 0x9503;
        public const UInt16 DOWN_CTRL_MSG_TAKE_TRAVEL_REQ = 0x9504;
        public const UInt16 DOWN_CTRL_MSG_EMERGENCY_MONITORING_REQ = 0x9505;
        public const UInt16 UP_BASE_MSG_VEHICLE_ADDED_ACK = 0x1601;
        public const UInt16 DOWN_BASE_MSG_VEHICLE_ADDED = 0x9601;


        public LoginResultHandle        OnLoginResult;
        public ReqVehicleBaseInfoHandle_Secondary OnReqBaseInfo;//从：请求车辆基本信息
        public ReqConnectHandle_Secondary OnReqLogin;//从：请求登录
        public ReqDisConnectHandle_Secondary OnReqDisConnect;//从：请求断开
        public ReqTestConnectHandle_Secondary OnReqTestConnect;//从：请求测试连接
        public TotalRecvHandle_Secondary OnTotalRecvHandle;//从：接收总数通知
        public ConnectTestAnswerHandle OnTestAnswer;//连接测试回应
        public ReqDriverInfoHandle_Secondary OnReqDrieverInfo;//请求驾驶员信息

        public PlatFormQueryHandle_Secondary OnPlatFormQuery;//从：平台查岗请求
        public PlatFormMsgInfoHandle_Secondary OnPlatFormMsgInfo;//从：平台报文请求
        public ConnectRequest OnConnectRequest;//主：收到下级平台登录请求
        public ConnectTestLink OnConnectTestLink;//主：收到下级平台链路保持请求
        public GpsArrive OnGpsArrive;//主：收到下级平台登录请求
        public Logout OnLogout;//主：收到下级平台注销
        public VehicleRegister OnVehicleRegister;//主：收到下级平台注册车辆
        public DriverInfoReport OnDriverInfoReport;//主：收到下级平台驾驶证上报
        public VehilceBillRecv OnVehilceBillRecv;//主：收到下级平台运单上报
        public MsgReturnStartup OnMsgReturnStartup;//从：收到上级平台启动车辆交换 
        public MsgReturnEnd     OnMsgReturnEnd;//从：收到上级平台启动车辆交换结束 
        public WantVehicleBill OnWantVehicleBill;//从：收到上级平台获取运单请求 
        public WantWarnToDo OnWantWarnToDo;//从：收到上级平台督办请求 
        public SendVehicleMsg OnSendVehicleMsg;//从：收到上级平台 发送车辆短信
        public WantVehicleChangeNet OnWantVehicleChangeNet;//从：收到上级平台 紧急接入
        public WantVehicleMonitorTelephone OnWantVehicleMonitorTelephone;//从：收到上级平台 电话监听
        public WantVehiclePhoto OnWantVehiclePhoto;//从：收到上级平台 拍照
        public WantVehicleTravel OnWantVehicleTravel;//从：收到上级平台 行驶记录仪请求
        
        public  RawDataArrive OnRawDataArrive;

        public const uint VERIFY_CODE = 123;
        private uint m_SequnceID=0;//报文ID
        private uint m_LoginID;//登录用户ID
        private uint m_UserID;//平台接入码
        private string m_Password;//平台密码
        private string m_Platform_id = "33010551115";//平台ID
        private bool m_needEncrypt = false ;//报文是否需要加密
      
        private uint m_M1 = 10000000;
        private uint m_IA1 = 20000000;
        private uint m_IC1 = 30000000;
        private uint m_key = 0x100;
        
        /// <summary>
        /// 设置加密参数 
        /// </summary>
        /// <param name="needEncrypt"></param>
        /// <param name="M1"></param>
        /// <param name="IA1"></param>
        /// <param name="IC1"></param>
        /// <param name="Key"></param>
        public void  SetOption( bool needEncrypt, uint M1,uint  IA1 ,uint IC1,uint  Key,string plat_form_id  ){
            m_M1 = M1;
            m_IA1 = IA1;
            m_IC1 = IC1;
            m_key = Key;
            m_needEncrypt = needEncrypt;
            m_Platform_id = plat_form_id;
        }
        protected override bool Analyze(ClientInfo info)
        {
            byte[] totalBuf = this.GetBuffer(info);
            if (totalBuf.Length < 10)
            {
                return false;
            }
            int thisPackageSize = 0;
            if (totalBuf[0] != 0x5B )
            {
                goto lastrow;
            }
            
            bool find = false;
            for (thisPackageSize = 1; thisPackageSize < totalBuf.Length; thisPackageSize++)
            {
                if (totalBuf[thisPackageSize] == 0x5D)
                {
                    find = true;
                    thisPackageSize += 1;
                    break;
                }
            }
            
            
            if (find)//完成一个包
            {
                byte[] packBuf = new byte[thisPackageSize];
                Array.Copy(totalBuf, 0, packBuf, 0, thisPackageSize);
                try
                {
                    this.HandlePackage( info,packBuf);
                }
                catch (Exception ex){
                    CommonFunc.LogError("Analyze00:" + ex.ToString());
                }
                this.RemoveLeftData(info,thisPackageSize);
                return true;
            }
            else
            {
                return false;
            }
        //非法数据包，发通知
        lastrow:
            this.OnAnalyzeWrong(info);
            return false;
        }
        /// <summary>
        /// 处理整个包的反转义
        /// </summary>
        /// <param name="package">一个完整的数据包</param>
        /// <returns>反转义后的数据完整包</returns>
        private byte[] HandlePackageReEscape(byte[] package)
        {
            if (package.Length < 10)
            {
                throw new Exception("数据包太短！");
            }
            if (package[0] != 0x5B || package[package.Length - 1] != 0x5D)
            {
                throw new Exception("非法的数据包！");
            }
            LinkedList<byte> bt = new LinkedList<byte>();
            int i = 0;
            while (i < package.Length )
            {
                bool escape = false;
                if (i!=0&&i!=package.Length - 1 && i + 1 < package.Length - 1)
                {
                    if (package[i] == 0x1B)
                    {

                        if (package[i + 1] == 0xE7)
                        {
                            bt.AddLast(0x5B);
                            i += 2;
                            escape = true;
                        }
                        else if (package[i + 1] == 0xE8)
                        {
                            bt.AddLast(0x5D);
                            i += 2;
                            escape = true;
                        }
                        else if (package[i + 1] == 0x00)
                        {
                            bt.AddLast(0x1B);
                            i += 2;
                            escape = true;
                        }
                        else {
                            CommonFunc.LogError("转义错误:" );
                        }
                    }
                     
                }
                if (!escape)
                {
                    bt.AddLast(package[i]);
                    i += 1;
                }

            }
            byte[] retBuff = new byte[bt.Count];
            bt.CopyTo(retBuff, 0);
            return retBuff;
        }
        private byte[] HandlePackageEscape(byte[] package)
        {
            m_SequnceID++;
            if (m_SequnceID > UInt32.MaxValue - 10) {
                m_SequnceID = 0;
            }
            if (package.Length < 10)
            {
                throw new Exception("数据包太短！");
            }
            if (package[0] != 0x5B || package[package.Length - 1] != 0x5D)
            {
                throw new Exception("非法的数据包！");
            }
            LinkedList<byte> bt = new LinkedList<byte>();

            for (int i = 0; i < package.Length;i++ )
            {
                if (i != 0 && i != package.Length - 1)
                {
                    if (package[i] == 0x5B)
                    {
                        bt.AddLast(0x1B);
                        bt.AddLast(0xE7);
                    }
                    else if (package[i] == 0x5D)
                    {

                        bt.AddLast(0x1B);
                        bt.AddLast(0xE8);
                    }
                    else if (package[i] == 0x1B)
                    {
                        bt.AddLast(0x1B);
                        bt.AddLast(0x00);
                    }
                    else
                    {

                        bt.AddLast(package[i]);
                    }
                }
                else
                {
                    bt.AddLast(package[i]);
                }


            }
            byte[] retBuff = new byte[bt.Count];
            bt.CopyTo(retBuff, 0);
            return retBuff;
        }
        public void HandlePackage(ClientInfo info,byte[] package)
        {
            if (package.Length < 10) {
                throw new Exception("数据包太短！");
            }
            if (package[0] != 0x5B || package[package.Length - 1] != 0x5D) {
                throw new Exception("非法的数据包！");
            }
            //转义处理：
            byte[] retBuff = HandlePackageReEscape(package);
            if (OnRawDataArrive != null) {
                try
                {
                    OnRawDataArrive(retBuff);
                }
                catch(Exception EX) {
                    CommonFunc.LogError("OnRawDataArrive错误:" + EX.ToString());
                }
            }
            //===============================临时

            string debugString = CommonFunc.getHexString(retBuff);

          //  CommonFunc.LogError("接收到：" + debugString);
            //System.Console.Out.WriteLine("接收到："+debugString);
            //===============================结束临时
            //提出命令字：

            UInt16 childCmd;
            UInt16 cmd = (UInt16)((retBuff[9] << 8) + retBuff[10]);
            string strCMD="";
            string hexOutput1 = String.Format("{0:X}", cmd >> 8);

            if (hexOutput1.Length < 2)
            {
                hexOutput1 = "0" + hexOutput1;
            }
            string hexOutput2 = String.Format("{0:X}", cmd & 0xFF);
            if (hexOutput2.Length < 2)
            {
                hexOutput2 = "0" + hexOutput2;
            }
            strCMD = hexOutput1 + " " + hexOutput2;
            string vehCode ="";
            byte vehColor = 0;
            byte jiami_tag = 0;
            uint jiami_key =0;//加密秘钥
            if (retBuff.Length >= 23)
            {
                jiami_tag = retBuff[18];//加密标志
                jiami_key = (uint)((retBuff[19] >> 24) + (retBuff[20] >> 16) + (retBuff[21] >> 8) + retBuff[22]);
                if(jiami_tag==1){
                    encryptArray(retBuff, jiami_key);
                }
            }
            switch (cmd) {
                case UP_CONNECT_RSP:
                    byte Result = retBuff[18];
                    uint VeryfyCode = (uint)((retBuff[19] << 24) + (retBuff[20] << 16) + (retBuff[21] << 8) + retBuff[22]);
                    if (this.OnLoginResult != null) { 
                        OnLoginResult(Result,VeryfyCode);
                    }
                    break;
               
                case UP_DISCONNECT_RSP:
                    System.Console.Out.WriteLine("成功注销！" );
                    break;
                case UP_LINKTEST_RSP:
                    System.Console.Out.WriteLine("测试连接响应正常！");
                    if(OnTestAnswer!=null){
                        OnTestAnswer();
                    }
                    break;

                    
                /////============================DOWN开始(从链路服务端)=========================
                case DOWN_CLOSELINK_INFORM:
                    System.Console.Out.WriteLine("服务器关闭通知：DOWN_CLOSELINK_INFORM！");
                    break;
                case DOWN_BASE_MSG:

                    childCmd = (UInt16)((retBuff[45] << 8) + retBuff[46]);
                    vehCode =getNoneZeroString(Encoding.GetEncoding("gbk").GetString(retBuff,23 ,21));
                    vehColor=  retBuff[44];
                    switch (childCmd) {
                        case DOWN_BASE_MSG_VEHICLE_ADDED:
                            if (OnReqBaseInfo != null) {
                                OnReqBaseInfo(vehCode, vehColor);
                            }
                            break;
                        default:

                            string strBytes = CommonFunc.getHexString(retBuff);
                            CommonFunc.LogError("未知命令:"+strBytes);
                            System.Console.Out.WriteLine("未知命令！" + strCMD);
                           
                            throw new Exception("未知命令！"   +hexOutput1 + " " + hexOutput2);
                          

                    }
                    break;
                case DOWN_TOTAL_RECV_BACK_MSG:
                    uint totalCount = (uint)(retBuff[23]<< 24) + (uint)(retBuff[24] << 16) + (uint)(retBuff[25] << 8) + (uint)retBuff[26];
                    uint fromTime = (uint)(retBuff[27] << 24) + (uint)(retBuff[28] << 16) + (uint)(retBuff[29] << 8) + (uint)retBuff[30];
                    uint toTime = (uint)(retBuff[31] << 24) + (uint)(retBuff[32] << 16) + (uint)(retBuff[33] << 8) + (uint)retBuff[34];
                    DateTime dtFrom = UTCToDateTime(fromTime);
                    DateTime dtEnd = UTCToDateTime(toTime);
                    System.Console.Out.WriteLine(dtFrom.ToString() + "-" + dtEnd.ToString() + "数量：" + totalCount.ToString());
                    if (OnTotalRecvHandle != null) {
                        OnTotalRecvHandle(info, totalCount, dtFrom, dtEnd);
                    }
                    break;
                case DOWN_CONNECT_REQ:
                    uint VerifyCode =(uint)((retBuff[23]<<24)+(retBuff[24]<<16)+(retBuff[25]<<8)+ retBuff[26]);
                    if (OnReqLogin != null) {
                        OnReqLogin(info,VerifyCode);
                    }
                    break;
                case DOWN_DISCONNECT_REQ:
                    if(OnReqDisConnect!=null){
                        OnReqDisConnect(info);
                    }
                    break;
 
                case DOWN_LINKTEST_REQ:
                    if (OnReqTestConnect != null)
                    {
                        OnReqTestConnect(info);
                    }
                    break;
                case DOWN_PLATFORM_MSG:
                    childCmd = (UInt16)((retBuff[23] << 8) + retBuff[24]);

                   
                    //List<byte> tempList = new List<byte>();
                    //for (int i = 30; i < 30 + 12;i++ )
                    //{
                    //    if (retBuff[i]==0)
                    //    {
                    //        break;
                    //    }
                    //    tempList.Add(retBuff[i]);
                    //}
                    byte kind = retBuff[29];
                    string objectID=getNoneZeroString( System.Text.Encoding.GetEncoding("gbk").GetString( retBuff,30,12));//System.Text.Encoding.GetEncoding("gbk").GetString( tempList.ToArray());
                    uint infoID =    (uint)(retBuff[42] << 24) + (uint)(retBuff[43] << 16) + (uint)(retBuff[44] << 8) + (uint)retBuff[45];
                    int contentLength = (int)(retBuff[42] << 46) + (int)(retBuff[47] << 16) + (int)(retBuff[48] << 8) + (int)retBuff[49];
                    //tempList.Clear();
                    //for (int i = 50; i < 50 + contentLength; i++)
                    //{
                    //    if (i >= retBuff.Length) {
                    //        throw new Exception("数据太长！" + cmd.ToString());
                    //    }
                    //    if (retBuff[i] == 0)
                    //    {
                    //        break;
                    //    }
                    //    tempList.Add(retBuff[i]);
                    //}
                    string txtContent =getNoneZeroString( System.Text.Encoding.GetEncoding("gbk").GetString( retBuff,50,contentLength));// System.Text.Encoding.GetEncoding("gbk").GetString(tempList.ToArray());
                  
                    switch (childCmd)
                    {
                        case DOWN_PLATFORM_MSG_POST_QUERY_REQ://查岗：
                            if (OnPlatFormQuery != null)
                            {
                                OnPlatFormQuery(kind, objectID, infoID, txtContent);
                            }
                            System.Console.Out.WriteLine("DOWN_PLATFORM_MSG_POST_QUERY_REQ！");
                            break;
                        case DOWN_PLATFORM_MSG_INFO_REQ://报文
                            if (OnPlatFormMsgInfo != null)
                            {
                                OnPlatFormMsgInfo(kind, objectID, infoID, txtContent);
                            }
                            System.Console.Out.WriteLine("DOWN_PLATFORM_MSG_INFO_REQ！");
                            break;
                        default:
                            System.Console.Out.WriteLine("未知命令！" + strCMD);
                            string strBytes = CommonFunc.getHexString(retBuff);
                            CommonFunc.LogError("未知命令:"+strBytes);
                            throw new Exception("未知命令！" + cmd.ToString());
                    }
                    break;
                case DOWN_EXG_MSG:
                    childCmd = (UInt16)((retBuff[45] << 8) + retBuff[46]);
                    vehCode =getNoneZeroString(Encoding.GetEncoding("gbk").GetString(retBuff,23 ,21));
                    vehColor=  retBuff[44];
                    switch (childCmd)
                    {
                        case DOWN_EXG_MSG_CORP_CENTER_INFO_ACK:
                            System.Console.Out.WriteLine("DOWN_EXG_MSG_CORP_CENTER_INFO_ACK！");
               
                            break;
                        case DOWN_EXG_MSG_REPORT_DRIVER_INFO:
                            System.Console.Out.WriteLine("DOWN_EXG_MSG_REPORT_DRIVER_INFO！");
                            
                            if (OnReqDrieverInfo != null) {
                                OnReqDrieverInfo(vehCode, vehColor);
                            }


                             
                            break;
                        case DOWN_EXG_MSG_RETURN_STARTUP:
                        {
                            if (OnMsgReturnStartup != null) { 
                                OnMsgReturnStartup(vehCode, vehColor, retBuff[51]);
                            }
                            break;
                        }
                        case DOWN_EXG_MSG_CAR_INFO:
                        {

                            int vLen = (int)((retBuff[47] << 24) + (retBuff[48] << 16) + (retBuff[49] << 8) + (retBuff[50] & 0xff));
                            string vContent = getNoneZeroString(Encoding.GetEncoding("gbk").GetString(retBuff, 70, vLen));
                            //CommonFunc.LogError("从链路收到：交换车辆静态信息 (DOWN_EXG_MSG_CAR_INFO)  车牌" + vehCode + "  颜色" + vehColor.ToString() +" 车辆信息:"+ vContent);
                            break;
                        }
                        case DOWN_EXG_MSG_CAR_LOCATION:
                        {

                            byte day = retBuff[52];
                            byte month = retBuff[53];
                            int year = (retBuff[54] << 8) | retBuff[55];

                            //时间(hms)(3)
                            byte hour = retBuff[56];
                            byte minute = retBuff[57];
                            uint second = retBuff[58];
                            
                            //经度(4)
                            uint iLng = (uint)((retBuff[59] << 24) | (retBuff[60] << 16) | (retBuff[61] << 8) | (retBuff[62]));
                            //纬度(4)
                            uint iLat = (uint)((retBuff[63] << 24) | (retBuff[64] << 16) | (retBuff[65] << 8) | (retBuff[66]));
                            //速度(2)
                            uint speed = (uint)((retBuff[67] << 8) | (retBuff[68]));
                            //记录仪速度(2)
                            uint speed2 = (uint)((retBuff[69] << 8) | (retBuff[70]));
                            //里程(4)
                            uint mile = (uint)((retBuff[71] << 24) | (retBuff[72] << 16) | (retBuff[73] << 8) | (retBuff[74]));
                            //方向(2)
                            uint angle = (uint)((retBuff[75] << 8) | (retBuff[76]));
                            //高度(2)
                            uint height = (uint)((retBuff[77] << 8) | (retBuff[78]));
                            //状态(4)
                            uint state = (uint)((retBuff[79] << 24) | (retBuff[80] << 16) | (retBuff[81] << 8) | (retBuff[82]));
                            //报警状态(4)
                            uint alarm_state = (uint)((retBuff[83] << 24) | (retBuff[84] << 16) | (retBuff[85] << 8) | (retBuff[82]));
                            //CommonFunc.LogError("从链路收到：交换车辆定位信息  (DOWN_EXG_MSG_CAR_LOCATION)  车牌" + vehCode 
                                            //+ "  颜色" + vehColor.ToString() +
                                            //" 纬度:" + Math.Round(iLat / 6000000.0, 5).ToString() + " 经度:" + Math.Round(iLng / 6000000.0, 5).ToString()   + " 速度:" + speed.ToString() + " 方向:" + angle.ToString() + " 里程：" + mile.ToString());
                            break;
                        }
                        case DOWN_EXG_MSG_CAR_HISTORY_ARCOSSAREA:
                        {
                            byte count=retBuff[51];//包个数
                            //CommonFunc.LogError("从链路收到：车辆定位信息交换补发消息 (DOWN_EXG_MSG_CAR_HISTORY_ARCOSSAREA)  车牌" + vehCode
                            //                + "  颜色" + vehColor.ToString() + " 历史数据包总数：" + count.ToString());
                            break;
                        }
                        case DOWN_EXG_MSG_RETURN_END:
                        {
                            if (OnMsgReturnEnd != null)
                            {
                                OnMsgReturnEnd(vehCode, vehColor, retBuff[51]);
                            }
                            //CommonFunc.LogError("从链路收到：DOWN_EXG_MSG_RETURN_END (DOWN_EXG_MSG_CAR_HISTORY_ARCOSSAREA)  车牌" + vehCode
                            //                + "  颜色" + vehColor.ToString()  );
                            break;
                        }
                        case DOWN_EXG_MSG_TAKE_EWAYBILL_REQ:
                        {
                            if (OnWantVehicleBill != null)
                            {
                                OnWantVehicleBill(vehCode, vehColor);
                            }
                            //CommonFunc.LogError("从链路收到：DOWN_EXG_MSG_TAKE_EWAYBILL_REQ (电子运单信息交换业务)  车牌" + vehCode
                            //                + "  颜色" + vehColor.ToString()  );
                            break;
                        }       
                        default:
                            System.Console.Out.WriteLine("未知命令！" + strCMD);
                            string strBytes = CommonFunc.getHexString(retBuff);
                            CommonFunc.LogError("未知命令:"+strBytes);
                            throw new Exception("未知命令！" + cmd.ToString());
                     
                    }
                    break;
                case DOWN_WARN_MSG:
                    childCmd = (UInt16)((retBuff[45] << 8) + retBuff[46]);
                    vehCode = getNoneZeroString(Encoding.GetEncoding("gbk").GetString(retBuff, 23, 21));
                    vehColor = retBuff[44];
                    switch (childCmd)
                    {
                        case DOWN_WARN_MSG_URGE_TODO_REQ:
                            {
                                byte warn_source = retBuff[51];
                                UInt16 warn_type = (UInt16)((retBuff[52] << 8) + retBuff[53]);
                                UInt64 iwarn_time = (UInt64)(retBuff[54] << 56)
                                           + (UInt64)(retBuff[55] << 48)
                                           + (UInt64)(retBuff[56] << 40)
                                           + (UInt64)(retBuff[57] << 32)
                                           + (UInt64)(retBuff[58] << 24)
                                           + (UInt64)(retBuff[59] << 16)
                                           + (UInt64)(retBuff[60] << 8)
                                           + (UInt64)(retBuff[61]);
                                uint supervision_id = (uint)(retBuff[62] << 24)
                                           + (uint)(retBuff[63] << 16)
                                           + (uint)(retBuff[64] << 8)
                                           + (uint)(retBuff[65]);

                                UInt64 isupervision_endtime = (UInt64)(retBuff[66] << 56)
                                           + (UInt64)(retBuff[67] << 48)
                                           + (UInt64)(retBuff[68] << 40)
                                           + (UInt64)(retBuff[69] << 32)
                                           + (UInt64)(retBuff[70] << 24)
                                           + (UInt64)(retBuff[71] << 16)
                                           + (UInt64)(retBuff[72] << 8)
                                           + (UInt64)(retBuff[73]);
                                DateTime dwarn_time = UTCToDateTime(iwarn_time);
                                DateTime dsupervision_endtime = UTCToDateTime(isupervision_endtime);
                                byte super_level = retBuff[74];
                                string supervisor = getNoneZeroString(Encoding.GetEncoding("gbk").GetString(retBuff, 75, 16));
                                string supervisor_tel = getNoneZeroString(Encoding.GetEncoding("gbk").GetString(retBuff, 91, 20));
                                string supervisor_email = getNoneZeroString(Encoding.GetEncoding("gbk").GetString(retBuff, 111, 32));
                                if (OnWantWarnToDo != null)
                                {
                                    OnWantWarnToDo(vehCode, vehColor, warn_source, warn_type, dwarn_time, supervision_id, dsupervision_endtime, super_level, supervisor, supervisor_tel, supervisor_email);
                                }
                                System.Console.Out.WriteLine("DOWN_WARN_MSG_URGE_TODO_REQ！");

                                break;
                            }
                        case DOWN_WARN_MSG_INFORM_TIPS:
                            {
                                byte warn_source = retBuff[51];
                                UInt16 warn_type = (UInt16)((retBuff[52] << 8) + retBuff[53]);
                                UInt64 iwarn_time = (UInt64)(retBuff[54] << 56)
                                         + (UInt64)(retBuff[55] << 48)
                                         + (UInt64)(retBuff[56] << 40)
                                         + (UInt64)(retBuff[57] << 32)
                                         + (UInt64)(retBuff[58] << 24)
                                         + (UInt64)(retBuff[59] << 16)
                                         + (UInt64)(retBuff[60] << 8)
                                         + (UInt64)(retBuff[61]);
                                int len = (int)(retBuff[62] << 24)
                                           + (int)(retBuff[63] << 16)
                                           + (int)(retBuff[64] << 8)
                                           + (int)(retBuff[65]);
                                DateTime dwarn_time = UTCToDateTime(iwarn_time);
                                string content = getNoneZeroString(Encoding.GetEncoding("gbk").GetString(retBuff, 66, len));
                                //CommonFunc.LogError("收到报警预警消息：车牌:"+vehCode+" 颜色:"+vehColor.ToString() +" 来源："+ warn_source.ToString() + " 类别：" + warn_type.ToString()+" 时间:"+dwarn_time.ToString("yyyy-MM-dd HH:mm:ss")+" 内容:"+content);
                                
                                break;
                            }
                        case DOWN_WARN_MSG_EXG_INFORM:
                            {
                                byte warn_source = retBuff[51];
                                UInt16 warn_type = (UInt16)((retBuff[52] << 8) + retBuff[53]);
                                UInt64 iwarn_time = (UInt64)(retBuff[54] << 56)
                                         + (UInt64)(retBuff[55] << 48)
                                         + (UInt64)(retBuff[56] << 40)
                                         + (UInt64)(retBuff[57] << 32)
                                         + (UInt64)(retBuff[58] << 24)
                                         + (UInt64)(retBuff[59] << 16)
                                         + (UInt64)(retBuff[60] << 8)
                                         + (UInt64)(retBuff[61]);
                                int len = (int)(retBuff[62] << 24)
                                           + (int)(retBuff[63] << 16)
                                           + (int)(retBuff[64] << 8)
                                           + (int)(retBuff[65]);
                                DateTime dwarn_time = UTCToDateTime(iwarn_time);
                                string content = getNoneZeroString(Encoding.GetEncoding("gbk").GetString(retBuff, 66, len));
                               
                                //CommonFunc.LogError("收到  实时交换报警信息：车牌:" + vehCode + " 颜色:" + vehColor.ToString() + " 来源：" + warn_source.ToString() + " 类别：" + warn_type.ToString() + " 时间:" + dwarn_time.ToString("yyyy-MM-dd HH:mm:ss") + " 内容:" + content);

                                break;
                            }
                             
                        
                        default:
                            System.Console.Out.WriteLine("未知命令！" + strCMD);
                            string strBytes = CommonFunc.getHexString(retBuff);
                            CommonFunc.LogError("未知命令:" + strBytes);
                            throw new Exception("未知命令！" + cmd.ToString());

                    }
                    break;
                case DOWN_CTRL_MSG:
                    childCmd = (UInt16)((retBuff[45] << 8) + retBuff[46]);
                    vehCode = getNoneZeroString(Encoding.GetEncoding("gbk").GetString(retBuff, 23, 21));
                    vehColor = retBuff[44];
                    switch (childCmd)
                    {
                        case DOWN_CTRL_MSG_TEXT_INFO:
                            {
                                uint msgID =  (uint)(retBuff[51] << 24)
                                         + (uint)(retBuff[52] << 16)
                                         + (uint)(retBuff[53] << 8)
                                         + (uint)(retBuff[54]);
                                byte priority = retBuff[55];
                                int msgLen = (int)(retBuff[56] << 24)
                                        + (int)(retBuff[57] << 16)
                                        + (int)(retBuff[58] << 8)
                                        + (int)(retBuff[59]);
                                string content = getNoneZeroString(Encoding.GetEncoding("gbk").GetString(retBuff, 60, msgLen));
                                if (OnSendVehicleMsg != null)
                                {
                                    OnSendVehicleMsg(vehCode, vehColor, msgID, priority, content);
                                }
                                break;
                            }
                        case DOWN_CTRL_MSG_MONITOR_VEHICLE_REQ://电话监听
                            {
                                
                                string telCode = getNoneZeroString(Encoding.GetEncoding("gbk").GetString(retBuff, 51, 20));
                                if (OnWantVehicleMonitorTelephone != null)
                                {
                                    OnWantVehicleMonitorTelephone(vehCode, vehColor, telCode);
                                }
                                break;
                                
                            }
                        case DOWN_CTRL_MSG_TAKE_PHOTO_REQ://拍照
                            {
                                byte chanel = retBuff[51];
                                byte size = retBuff[52];
                                if (OnWantVehiclePhoto != null)
                                {
                                    OnWantVehiclePhoto(vehCode, vehColor, chanel, size);
                                }
                               
                                break;
                            }
                        case DOWN_CTRL_MSG_TAKE_TRAVEL_REQ:
                            {
                                byte cmdType = retBuff[51];
                                if (OnWantVehicleTravel != null)
                                {
                                    OnWantVehicleTravel(vehCode, vehColor, cmdType);
                                }

                                break;
                            }      
                        case DOWN_CTRL_MSG_EMERGENCY_MONITORING_REQ:
                            {
                                string auth_code = getNoneZeroString(Encoding.GetEncoding("gbk").GetString(retBuff, 51, 10));
                                string access_point_name = getNoneZeroString(Encoding.GetEncoding("gbk").GetString(retBuff, 61, 20));
                                string username = getNoneZeroString(Encoding.GetEncoding("gbk").GetString(retBuff, 81, 49));
                                string password = getNoneZeroString(Encoding.GetEncoding("gbk").GetString(retBuff, 130, 22));
                                string server_ip = getNoneZeroString(Encoding.GetEncoding("gbk").GetString(retBuff, 152, 32));
                                UInt16 port1=(UInt16)((retBuff[174]<<8)+retBuff[175]);
                                 UInt16 port2=(UInt16)((retBuff[176]<<8)+retBuff[177]);
                                 UInt64 iTimeEnd = (UInt64)(retBuff[178] << 56)
                                          + (UInt64)(retBuff[179] << 48)
                                          + (UInt64)(retBuff[180] << 40)
                                          + (UInt64)(retBuff[181] << 32)
                                          + (UInt64)(retBuff[182] << 24)
                                          + (UInt64)(retBuff[183] << 16)
                                          + (UInt64)(retBuff[184] << 8)
                                          + (UInt64)(retBuff[185]);
                                 DateTime monitor_End = UTCToDateTime(iTimeEnd);
                                if (OnWantVehicleChangeNet != null)
                                {
                                    OnWantVehicleChangeNet(vehCode, vehColor, auth_code, access_point_name, username, password, server_ip, port1, port2, monitor_End);
                                }
                                break;
                            }  
                        default:
                            System.Console.Out.WriteLine("未知命令！" + strCMD);
                            string strBytes = CommonFunc.getHexString(retBuff);
                            CommonFunc.LogError("未知命令:" + strBytes);
                            throw new Exception("未知命令！" + cmd.ToString());

                    }
                    break;
                /////============================DOWN结束(从链路服务端)=========================
                /////============================作为主服务器，接收客户端的请求======================
                case UP_CONNECT_REQ://客户端登录
                    uint userid = (uint)(retBuff[23] << 24) + (uint)(retBuff[24] << 16) + (uint)(retBuff[25] << 8) + (uint)retBuff[26];
                    string pwd =getNoneZeroString(Encoding.GetEncoding("GBK").GetString(retBuff,27,8));
                     
                    if (OnConnectRequest != null) {
                        OnConnectRequest(info, userid, pwd);
                    }
                    System.Console.Out.WriteLine("UP_CONNECT_REQ！"+userid.ToString()+"  PWD:"+pwd);
                    break;
                case UP_EXG_MSG:
                    vehCode =getNoneZeroString(Encoding.GetEncoding("gbk").GetString(retBuff,23 ,21));
                    vehColor=  retBuff[44];
                    childCmd = (UInt16)((retBuff[45] << 8) + retBuff[46]);
                    switch (childCmd)
                    {
                        case UP_EXG_MSG_REGISTER://平台注册，不用应答，不作处理
                            string platform = getNoneZeroString(Encoding.GetEncoding("gbk").GetString(retBuff, 51, 11));
                            string factory =  getNoneZeroString(Encoding.GetEncoding("gbk").GetString(retBuff, 62, 11));
                            string term_type = getNoneZeroString( Encoding.GetEncoding("gbk").GetString(retBuff, 73, 20));
                            string term_no = getNoneZeroString( Encoding.GetEncoding("gbk").GetString(retBuff, 93, 7));
                            string sim_no = getNoneZeroString( Encoding.GetEncoding("gbk").GetString(retBuff, 100, 12));
                            if (OnVehicleRegister != null) {
                                OnVehicleRegister( info,   vehCode,  Convert.ToString(vehColor),factory ,  term_type,  term_no ,  sim_no);
                                
                            }
                            System.Console.Out.WriteLine("UP_EXG_MSG_REGISTER！");
                            break;   
                        case UP_EXG_MSG_REPORT_DRIVER_INFO:
                            string driverName = getNoneZeroString(Encoding.GetEncoding("gbk").GetString(retBuff, 51, 16));
                            string idCard =  getNoneZeroString(Encoding.GetEncoding("gbk").GetString(retBuff, 67, 20));
                            string certCard = getNoneZeroString( Encoding.GetEncoding("gbk").GetString(retBuff, 87, 40));
                            string  org_name = getNoneZeroString( Encoding.GetEncoding("gbk").GetString(retBuff, 127, 200));
                            if (OnDriverInfoReport != null)
                            {
                                OnDriverInfoReport(info, vehCode, Convert.ToString(vehColor), driverName, idCard, certCard, org_name);
                                
                            }
                            System.Console.Out.WriteLine("UP_EXG_MSG_REGISTER！");
                            break;
                        case UP_EXG_MSG_MSG_REPORT_EWAYBILL_INFO:
                             int len=(int)(retBuff[51]<<24)+(int)(retBuff[52]<<16)+(int)(retBuff[53]<<8)+(int)retBuff[54]; 
                            string content = getNoneZeroString(Encoding.GetEncoding("gbk").GetString(retBuff, 55, len));
                            
                            if (OnVehilceBillRecv != null)
                            {
                                OnVehilceBillRecv(info, vehCode,Convert.ToString(vehColor), content);
                                
                            }
                            System.Console.Out.WriteLine("UP_EXG_MSG_REGISTER！");
                            break;
                        case UP_EXG_MSG_REAL_LOCATION://定位：
                            //11
                           
                            //(dmyy)日期(4)//52 开始


                            byte day = retBuff[52];
                            byte month = retBuff[53];
                             int year = (retBuff[54] << 8) | retBuff[55]  ;
                             
                            //时间(hms)(3)
                            byte hour = retBuff[56];
                            byte minute = retBuff[57];
                            uint second =  retBuff[58] ;
                          
                            //经度(4)
                            uint iLng =(uint) ((retBuff[59] << 24) | (retBuff[60] << 16) | (retBuff[61] << 8) | (retBuff[62]));
                            //纬度(4)
                            uint iLat = (uint) ((retBuff[63] << 24) | (retBuff[64] << 16) | (retBuff[65] << 8) | (retBuff[66]));
                          
                            //速度(2)
                            uint speed = (uint) ((retBuff[67] << 8) | (retBuff[68]));
                        
                            //记录仪速度(2)
                            uint speed2 =(uint) ( (retBuff[69] << 8) | (retBuff[70]));
                            

                            //里程(4)
                            uint mile =(uint) ( (retBuff[71] << 24) | (retBuff[72] << 16) | (retBuff[73] << 8) | (retBuff[74]));
                           
                            //方向(2)
                            uint angle =(uint) ( (retBuff[75] << 8) | (retBuff[76]));
 
                            //高度(2)
                            uint height =(uint) ( (retBuff[77] << 8) | (retBuff[78]));
                           
                            //状态(4)
                            uint state =(uint) ( (retBuff[79] << 24) | (retBuff[80] << 16) | (retBuff[81] << 8) | (retBuff[82]));
                            

                            //报警状态(4)
                            uint alarm_state =(uint) ( (retBuff[83] << 24) | (retBuff[84] << 16) | (retBuff[85] << 8) | (retBuff[82]));
                             //11
                            if (OnGpsArrive!=null) {
                                OnGpsArrive(vehCode,
                                    new DateTime(year, (int)month, (int)day, (int)hour, (int)minute, (int)second),
                                    (double)iLat / 1000000.0,
                                    (double)iLng / 1000000.0, 
                                    (double)speed, 
                                    (short)angle);
                            }
                            System.Console.Out.WriteLine("UP_EXG_MSG_REAL_LOCATION！");
                            break;
                        case UP_EXG_MSG_HISTORY_LOCATION: 
                        {
                            System.Console.Out.WriteLine("收到历史！");
                            break;
                        }

                        case UP_EXG_MSG_APPLY_FOR_MONITOR_STARTUP:
                        {
                             UInt64 startDT = (UInt64)(retBuff[51]<< 56)
                                        +(UInt64)(retBuff[52] << 48)
                                        + (UInt64)(retBuff[53] <<40)
                                        + (UInt64)(retBuff[54] << 32)
                                        + (UInt64)(retBuff[55] << 24)
                                        + (UInt64)(retBuff[56] << 16)
                                        + (UInt64)(retBuff[57] << 8)
                                        + (UInt64)(retBuff[58]);

                            UInt64 endDT = (UInt64)(retBuff[59]<< 56)
                                        +(UInt64)(retBuff[60] << 48)
                                        + (UInt64)(retBuff[61] <<40)
                                        + (UInt64)(retBuff[62] << 32)
                                        + (UInt64)(retBuff[63] << 24)
                                        + (UInt64)(retBuff[64] << 16)
                                        + (UInt64)(retBuff[65] << 8)
                                        + (UInt64)(retBuff[66]);

                            DateTime tmFrom= UTCToDateTime(startDT);
                            DateTime tmEnd= UTCToDateTime(endDT);
                            //CommonFunc.LogError("主链路收到：UP_EXG_MSG_APPLY_FOR_MONITOR_STARTUP 车牌" + vehCode + "  颜色" + vehColor.ToString() + " tm:" + tmFrom.ToString("yyyy-MM-dd HH:mm:ss") + "--" + tmEnd.ToString("yyyy-MM-dd HH:mm:ss"));
                            break;
                        }
                        case UP_EXG_MSG_APPLY_FOR_MONITOR_END:
                        {

                            //CommonFunc.LogError("主链路收到：UP_EXG_MSG_APPLY_FOR_MONITOR_END 车牌" + vehCode + "  颜色" + vehColor.ToString()  );
                            break;
                        }
                        case UP_EXG_MSG_APPLY_HISGNSSDATA_REQ:
                        {
                            UInt64 startDT = (UInt64)(retBuff[51] << 56)
                                       + (UInt64)(retBuff[52] << 48)
                                       + (UInt64)(retBuff[53] << 40)
                                       + (UInt64)(retBuff[54] << 32)
                                       + (UInt64)(retBuff[55] << 24)
                                       + (UInt64)(retBuff[56] << 16)
                                       + (UInt64)(retBuff[57] << 8)
                                       + (UInt64)(retBuff[58]);

                            UInt64 endDT = (UInt64)(retBuff[59] << 56)
                                        + (UInt64)(retBuff[60] << 48)
                                        + (UInt64)(retBuff[61] << 40)
                                        + (UInt64)(retBuff[62] << 32)
                                        + (UInt64)(retBuff[63] << 24)
                                        + (UInt64)(retBuff[64] << 16)
                                        + (UInt64)(retBuff[65] << 8)
                                        + (UInt64)(retBuff[66]);

                            DateTime tmFrom = UTCToDateTime(startDT);
                            DateTime tmEnd = UTCToDateTime(endDT);
                            //CommonFunc.LogError("主链路收到：UP_EXG_MSG_APPLY_HISGNSSDATA_REQ 车牌" + vehCode + "  颜色" + vehColor.ToString() + " tm:" + tmFrom.ToString("yyyy-MM-dd HH:mm:ss") + "--" + tmEnd.ToString("yyyy-MM-dd HH:mm:ss"));
                            break;
                        }
                        case UP_EXG_MSG_RETURN_STARTUP_ACK:
                        {
                            //CommonFunc.LogError("主链路收到：UP_EXG_MSG_RETURN_STARTUP_ACK 车牌" + vehCode + "  颜色" + vehColor.ToString());
                            break;
                        }
                      
                        default:
                            System.Console.Out.WriteLine("未识别！UP_EXG_MSG" + childCmd.ToString());
                            break;
                    }
                    break;
                case UP_WARN_MSG:
                    {
                        vehCode = getNoneZeroString(Encoding.GetEncoding("gbk").GetString(retBuff, 23, 21));
                        vehColor = retBuff[44];
                        childCmd = (UInt16)((retBuff[45] << 8) + retBuff[46]);
                        switch (childCmd)
                        {
                            case UP_WARN_MSG_ADPT_INFO://收到主动报警
                                {
                                    byte fromSource=  retBuff[51] ;
                                    UInt16 warn_kind =(ushort) ((retBuff[52]<<8) + retBuff[53]);
                                    UInt64 tmData = (UInt64)(retBuff[54]<< 56)
                                        +(UInt64)(retBuff[55] << 48)
                                        + (UInt64)(retBuff[56] <<40)
                                        + (UInt64)(retBuff[57] << 32)
                                        + (UInt64)(retBuff[58] << 24)
                                        + (UInt64)(retBuff[59] << 16)
                                        + (UInt64)(retBuff[60] << 8)
                                        + (UInt64)(retBuff[61]);
                                    DateTime tmDate= UTCToDateTime(tmData);
                                    uint infoid = (uint)((retBuff[62] << 24) + (retBuff[63] << 16) + (retBuff[64] << 8) + (retBuff[65] & 0xff));
                                    int contentLen = ( int)((retBuff[66] << 24) + (retBuff[67] << 16) + (retBuff[68] << 8) + (retBuff[69] & 0xff));
                                    string content = getNoneZeroString(Encoding.GetEncoding("gbk").GetString(retBuff, 70, contentLen));
                                    System.Console.Out.WriteLine("UP_WARN_MSG_ADPT_INFO！");
                                    break;
                                }
                            case UP_WARN_MSG_ADPT_TODO_INFO://收到主动报警
                                {
                                    uint infoid = (uint)((retBuff[51] << 24) + (retBuff[52] << 16) + (retBuff[53] << 8) + (retBuff[54] & 0xff));
                                    byte result = retBuff[55];
                                    System.Console.Out.WriteLine("UP_WARN_MSG_ADPT_TODO_INFO！");
                                    break;
                                }
                            default :
                                break;
                        }
                        break;
                    }
                case UP_LINKTEST_REQ://客户端测试
                {

                    if (OnConnectTestLink != null)
                    {
                        OnConnectTestLink(info);
                    }
                    System.Console.Out.WriteLine("UP_LINKTEST_REQ！");
                     
                }
                    
                break;
                case UP_DISCONNECT_REQ://客户端注销
                {
                    uint login_id=(uint) ((retBuff[23] << 24) + (uint)(retBuff[24] << 16) + (uint)(retBuff[25] << 8) + (uint)retBuff[26]);
                    string password = Encoding.GetEncoding("GBK").GetString(retBuff, 27, 8); ;
                    if (OnLogout != null)
                    {
                        OnLogout(info, login_id, password);
                    }
                    
                     
                }
                break;
                /////============================作为主服务器，接收客户端的请求结束======================
    
                /////============================作为从链路客户端（测试用）开始======================
                case DOWN_CONNECT_RSP:
                {
                    byte result=retBuff[23];
                    //CommonFunc.LogError("从链路客户端收到应答DOWN_CONNECT_RSP:result:"+result.ToString());
                    break;
                }
                case DOWN_LINKTEST_RSP:
                {
                    //CommonFunc.LogError("从链路客户端收到应答DOWN_LINKTEST_RSP" );
                    break;
                }
                case DOWN_DISCONNECT_RSP:
                {
                    //CommonFunc.LogError("从链路客户端收到应答DOWN_DISCONNECT_RSP");
                    break;
                }
                /////============================作为从链路客户端（测试用）结束======================
                default :

                    System.Console.Out.WriteLine("未知命令！" + strCMD);
                    string strBytes1 = CommonFunc.getHexString(retBuff);
                    CommonFunc.LogError("未知命令:"+strBytes1);
                    throw new Exception("未知命令！"+cmd.ToString());
            }

        }
           
        uint crc_hb_update(uint crc,int v){
            uint [] crc_ta=new uint[256]{ //CRC余式表
		        0x0000, 0x1021, 0x2042, 0x3063, 0x4084, 0x50a5, 0x60c6, 0x70e7,
		        0x8108, 0x9129, 0xa14a, 0xb16b, 0xc18c, 0xd1ad, 0xe1ce, 0xf1ef,
		        0x1231, 0x0210, 0x3273, 0x2252, 0x52b5, 0x4294, 0x72f7, 0x62d6,
		        0x9339, 0x8318, 0xb37b, 0xa35a, 0xd3bd, 0xc39c, 0xf3ff, 0xe3de,
		        0x2462, 0x3443, 0x0420, 0x1401, 0x64e6, 0x74c7, 0x44a4, 0x5485,
		        0xa56a, 0xb54b, 0x8528, 0x9509, 0xe5ee, 0xf5cf, 0xc5ac, 0xd58d,
		        0x3653, 0x2672, 0x1611, 0x0630, 0x76d7, 0x66f6, 0x5695, 0x46b4,
		        0xb75b, 0xa77a, 0x9719, 0x8738, 0xf7df, 0xe7fe, 0xd79d, 0xc7bc,
		        0x48c4, 0x58e5, 0x6886, 0x78a7, 0x0840, 0x1861, 0x2802, 0x3823,
		        0xc9cc, 0xd9ed, 0xe98e, 0xf9af, 0x8948, 0x9969, 0xa90a, 0xb92b,
		        0x5af5, 0x4ad4, 0x7ab7, 0x6a96, 0x1a71, 0x0a50, 0x3a33, 0x2a12,
		        0xdbfd, 0xcbdc, 0xfbbf, 0xeb9e, 0x9b79, 0x8b58, 0xbb3b, 0xab1a,
		        0x6ca6, 0x7c87, 0x4ce4, 0x5cc5, 0x2c22, 0x3c03, 0x0c60, 0x1c41,
		        0xedae, 0xfd8f, 0xcdec, 0xddcd, 0xad2a, 0xbd0b, 0x8d68, 0x9d49,
		        0x7e97, 0x6eb6, 0x5ed5, 0x4ef4, 0x3e13, 0x2e32, 0x1e51, 0x0e70,
		        0xff9f, 0xefbe, 0xdfdd, 0xcffc, 0xbf1b, 0xaf3a, 0x9f59, 0x8f78,
		        0x9188, 0x81a9, 0xb1ca, 0xa1eb, 0xd10c, 0xc12d, 0xf14e, 0xe16f,
		        0x1080, 0x00a1, 0x30c2, 0x20e3, 0x5004, 0x4025, 0x7046, 0x6067,
		        0x83b9, 0x9398, 0xa3fb, 0xb3da, 0xc33d, 0xd31c, 0xe37f, 0xf35e,
		        0x02b1, 0x1290, 0x22f3, 0x32d2, 0x4235, 0x5214, 0x6277, 0x7256,
		        0xb5ea, 0xa5cb, 0x95a8, 0x8589, 0xf56e, 0xe54f, 0xd52c, 0xc50d,
		        0x34e2, 0x24c3, 0x14a0, 0x0481, 0x7466, 0x6447, 0x5424, 0x4405,
		        0xa7db, 0xb7fa, 0x8799, 0x97b8, 0xe75f, 0xf77e, 0xc71d, 0xd73c,
		        0x26d3, 0x36f2, 0x0691, 0x16b0, 0x6657, 0x7676, 0x4615, 0x5634,
		        0xd94c, 0xc96d, 0xf90e, 0xe92f, 0x99c8, 0x89e9, 0xb98a, 0xa9ab,
		        0x5844, 0x4865, 0x7806, 0x6827, 0x18c0, 0x08e1, 0x3882, 0x28a3,
		        0xcb7d, 0xdb5c, 0xeb3f, 0xfb1e, 0x8bf9, 0x9bd8, 0xabbb, 0xbb9a,
		        0x4a75, 0x5a54, 0x6a37, 0x7a16, 0x0af1, 0x1ad0, 0x2ab3, 0x3a92,
		        0xfd2e, 0xed0f, 0xdd6c, 0xcd4d, 0xbdaa, 0xad8b, 0x9de8, 0x8dc9,
		        0x7c26, 0x6c07, 0x5c64, 0x4c45, 0x3ca2, 0x2c83, 0x1ce0, 0x0cc1,
		        0xef1f, 0xff3e, 0xcf5d, 0xdf7c, 0xaf9b, 0xbfba, 0x8fd9, 0x9ff8,
		        0x6e17, 0x7e36, 0x4e55, 0x5e74, 0x2e93, 0x3eb2, 0x0ed1, 0x1ef0
	        };
        	
	        return (crc>>8) ^ crc_ta[(crc^v)&0xff];

        }

        uint crc_hb(byte[] buffer)
        {
            return crc_hb_js(buffer);
            uint crc=0;
            for (int i = 1; i < buffer.Length; i++)//因为不从包头标志（5B）开始，所以从第二个字节算起
            {
                crc=crc_hb_update(crc,buffer[i]);
            }
            uint crc2 = crc_hb_js(buffer);
            return crc2;
        }
        /// <summary>
        /// 江苏版的CRC校验
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        uint  crc_hb_js(byte[] data)
        {
            uint crc = 0xFFFF; // initial value
            uint polynomial = 0x1021; // 0001 0000 0010 0001  (0, 5, 12)

            for (int j = 1; j < data.Length; ++j)//因为不从包头标志（5B）开始，所以从第二个字节算起
            {
                for (int i = 0; i < 8; i++)
                {
                    Boolean bit = ((data[j] >> (7 - i) & 1) == 1);
                    Boolean c15 = ((crc >> 15 & 1) == 1);
                    crc <<= 1;
                    if (c15 ^ bit)
                    {
                        crc ^= polynomial;
                    }
                }
            }

            return crc  ;
              
        }
        public byte[] MakeLogin(uint Userid,string Password,string LocalIP,int Localport,uint LoginID) {
            m_UserID = Userid;
            m_Password = Password;
            this.m_LoginID = LoginID;

            if (m_Password.Length<8)
            {
              //  throw new Exception("密码小于8位");
            }
            List<byte> byteList=new List<byte>();
            //头：===============================================================
            //头(1)
            byteList.Add(0x5B);//头
            //数据头：===============================================================
            //数据长度(4)
            byteList.Add(0x00); 
            byteList.Add(0x00); 
            byteList.Add(0x00); 
            byteList.Add(72);
            //报文序号(4)
            byteList.Add(0x01);
            byteList.Add(0x02);
            byteList.Add(0x03);
            byteList.Add(0x04);
            //业务数据类型(4)
            //
            uint cmd = UP_CONNECT_REQ;
           // byteList.Add((byte)(cmd>>24));
            //byteList.Add((byte)((cmd & 0x00ff0000)>>16));
            byteList.Add((byte)(cmd >> 8));
            byteList.Add((byte)(cmd & 0xff)  );

            //下级平台接入码(4)
            byteList.Add((byte)(Userid >> 24));
            byteList.Add((byte)((Userid & 0x00ff0000) >> 16));
            byteList.Add((byte)((Userid & 0x0000ff00) >> 8));
            byteList.Add((byte)((Userid & 0x000000ff)));
            
            //协议版本号(2)
            byteList.Add(0x00);
            byteList.Add(0x00);
           
           //报文加密与否(1)
            if (m_needEncrypt)
            {
                byteList.Add(0x01);
            }
            else
            {
                byteList.Add(0x00);
            }
          

            //数据体：===============================================================

            //用户名(4)
            byteList.Add((byte)(LoginID >> 24));
            byteList.Add((byte)((LoginID & 0x00ff0000) >> 16));
            byteList.Add((byte)((LoginID & 0x0000ff00) >> 8));
            byteList.Add((byte)((LoginID & 0x000000ff)));

            //时间戳（8）
            UInt64 utcTime = (UInt64)DateTimeToUTC(DateTime.Now);
           byteList.Add((byte)((utcTime >> 56) & 0xff));
           byteList.Add( (byte)((utcTime >> 48) & 0xff));
           byteList.Add( (byte)((utcTime >> 40) & 0xff));
           byteList.Add( (byte)((utcTime >> 32) & 0xff));
           byteList.Add( (byte)((utcTime >> 24) & 0xff));
           byteList.Add( (byte)((utcTime >> 16) & 0xff));
           byteList.Add( (byte)((utcTime >> 8) & 0xff));
           byteList.Add((byte)((utcTime) & 0xff));
             //密码(32)
           
            uint passwordInt = Convert.ToUInt32(Password);
            byte []timeAndPass=new byte[12];
            timeAndPass[0] = (byte)(passwordInt >> 24);
            timeAndPass[1] = (byte)((passwordInt >> 16)&0xff);
            timeAndPass[2] = (byte)((passwordInt >> 8) & 0xff);
            timeAndPass[3] = (byte)((passwordInt) & 0xff);

            timeAndPass[4] = (byte)((utcTime >> 56) & 0xff);
            timeAndPass[5] = (byte)((utcTime >> 48) & 0xff);
            timeAndPass[6] = (byte)((utcTime >> 40) & 0xff);
            timeAndPass[7] = (byte)((utcTime >> 32) & 0xff);
            timeAndPass[8] = (byte)((utcTime >> 24) & 0xff);
            timeAndPass[9] = (byte)((utcTime >> 16) & 0xff);
            timeAndPass[10] = (byte)((utcTime >> 8) & 0xff);
            timeAndPass[11] = (byte)((utcTime  ) & 0xff);

            SHA256 sha256 = new SHA256CryptoServiceProvider();//建立一个SHA256
            byte[] retPass= sha256.ComputeHash(timeAndPass);//进行SHA256加密
            byte[] retPass32 =new byte[32];
            if (retPass.Length >=32)
            {
                Array.Copy(retPass, retPass.Length - 32, retPass32, 0, 32);
            }
            else {
                Array.Copy(retPass,0, retPass32, 32 - retPass.Length, retPass.Length);
            }
            
            int m = 0;
            for (m = 0; m < retPass32.Length; m++)
            {
                byteList.Add((byte)retPass32[m]);
            }
            int TotalCount = byteList.Count + 3;//校验和+结尾符占三位

            byteList[1] = (byte)(TotalCount >> 24);
            byteList[2] = (byte)((TotalCount & 0x00ff0000) >> 16);
            byteList[3] = (byte)((TotalCount & 0x0000ff00) >> 8);
            byteList[4] = (byte)((TotalCount & 0x000000ff));

            if (m_needEncrypt)
            {
                encryptList(byteList);
            }
            //CRC校验：===============================================================
            //校验(2)
            UInt16 crc = (UInt16)(crc_hb(byteList.ToArray()) & 0xFFFF);
            byteList.Add((byte)(crc>>8));
            byteList.Add((byte)(crc & 0xFF));
            //尾标识：===============================================================
            //尾(1)
            byteList.Add(0x5D);


            byte[] bts = byteList.ToArray();
            return HandlePackageEscape(bts);
          
        }
        
        public byte[] MakeDownLogin(uint verifyCode)
        {
             
            List<byte> byteList = new List<byte>();
            //头：===============================================================
            //头(1)
            byteList.Add(0x5B);//头
            //数据头：===============================================================
            //数据长度(4)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文序号(4)
            byteList.Add((byte)(m_SequnceID >> 24));
            byteList.Add((byte)((m_SequnceID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_SequnceID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_SequnceID & 0x000000ff)));
            m_SequnceID = m_SequnceID + 1 > 0xfffffff0 ? 0 : m_SequnceID + 1;
            //业务数据类型(4)
            //
            uint cmd = DOWN_CONNECT_REQ;
            
            byteList.Add((byte)(cmd >> 8));
            byteList.Add((byte)(cmd & 0xff));

            //下级平台接入码(4)
            byteList.Add((byte)(m_UserID >> 24));
            byteList.Add((byte)((m_UserID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_UserID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_UserID & 0x000000ff)));

            //协议版本号(3)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文加密与否(1)
            if (m_needEncrypt)
            {
                byteList.Add(0x01);
            }
            else
            {
                byteList.Add(0x00);
            }
            //加密密钥(4)
            byteList.Add((byte)(m_key >> 24));
            byteList.Add((byte)((m_key & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_key & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_key & 0x000000ff)));

            //数据体：===============================================================

            //校验码
            byteList.Add((byte)(verifyCode >> 24));
            byteList.Add((byte)((verifyCode & 0x00ff0000) >> 16));
            byteList.Add((byte)((verifyCode & 0x0000ff00) >> 8));
            byteList.Add((byte)((verifyCode & 0x000000ff)));

            //重置总数据长度后续数据长度
            int TotalCount = byteList.Count + 3;//校验和+结尾符占三位

            byteList[1] = (byte)(TotalCount >> 24);
            byteList[2] = (byte)((TotalCount & 0x00ff0000) >> 16);
            byteList[3] = (byte)((TotalCount & 0x0000ff00) >> 8);
            byteList[4] = (byte)((TotalCount & 0x000000ff));
            if (m_needEncrypt)
            {
                encryptList(byteList);
            }
            //CRC校验：===============================================================
            //校验(2)
            UInt16 crc = (UInt16)(crc_hb(byteList.ToArray()) & 0xFFFF);
            byteList.Add((byte)(crc >> 8));
            byteList.Add((byte)(crc & 0xFF));
            //尾标识：===============================================================
            //尾(1)
            byteList.Add(0x5D);


            byte[] bts = byteList.ToArray();
            return HandlePackageEscape(bts);

        }
        //
        public byte[] MakeVehicleWarn(string VehicleNo, byte VehicleColor, byte Source, ushort Kind, DateTime TM,uint InfoID,string Content)
        {
            List<byte> byteList = new List<byte>();
            //头：===============================================================
            //头(1)
            byteList.Add(0x5B);//头
            //数据头：===============================================================
            //数据长度(4)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文序号(4)
            byteList.Add((byte)(m_SequnceID >> 24));
            byteList.Add((byte)((m_SequnceID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_SequnceID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_SequnceID & 0x000000ff)));
            m_SequnceID = m_SequnceID + 1 > 0xfffffff0 ? 0 : m_SequnceID + 1;
            //业务数据类型(4)
            //
            uint cmd = UP_WARN_MSG;

            byteList.Add((byte)(cmd >> 8));
            byteList.Add((byte)(cmd & 0xff));

            //下级平台接入码(4)
            byteList.Add((byte)(m_UserID >> 24));
            byteList.Add((byte)((m_UserID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_UserID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_UserID & 0x000000ff)));

            //协议版本号(3)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            if (m_needEncrypt)
            {
                byteList.Add(0x01);
            }
            else
            {
                byteList.Add(0x00);
            }
            //加密密钥(4)
            byteList.Add((byte)(m_key >> 24));
            byteList.Add((byte)((m_key & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_key & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_key & 0x000000ff)));

            //数据体：===============================================================
            //车牌(21)
            byte[] vehBytes = System.Text.Encoding.GetEncoding("gbk").GetBytes(VehicleNo);

            for (int i = 0; i < 21; i++)
            {
                if (i > vehBytes.Length - 1)
                {
                    byteList.Add(0);
                }
                else
                {
                    byteList.Add(vehBytes[i]);
                }
            }
            //车牌颜色(1)
            byteList.Add(VehicleColor);
            //子业务标识(2)：
            cmd = UP_WARN_MSG_ADPT_INFO;
            byteList.Add((byte)(cmd >> 8));
            byteList.Add((byte)(cmd & 0xff));

            //后续数据长度(4)：
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);

            //来源（1）51?
            byteList.Add(Source);

            //类型来源（2）
            byteList.Add((byte)(Kind>>8));
            byteList.Add((byte)(Kind &0xff));

            //时间utc(8)
            UInt64 tm = (UInt64)DateTimeToUTC(TM);
            byteList.Add((byte)(tm >> 56));
            byteList.Add((byte)((tm & 0x00ff000000000000) >> 48));
            byteList.Add((byte)((tm & 0x0000ff0000000000) >> 40));
            byteList.Add((byte)((tm & 0x000000ff00000000) >> 32));
            byteList.Add((byte)((tm & 0x00000000ff000000) >> 24));
            byteList.Add((byte)((tm & 0x0000000000ff0000) >> 16));
            byteList.Add((byte)((tm & 0x000000000000ff00) >> 8));
            byteList.Add((byte)((tm & 0x0000000000ff)));

            //ID(4)
            byteList.Add((byte)(InfoID >> 24));
            byteList.Add((byte)((InfoID & 0x00ff0000) >> 16));
            byteList.Add((byte)((InfoID & 0x0000ff00) >> 8));
            byteList.Add((byte)((InfoID & 0x000000ff)));
            byte[] byteContent= System.Text.Encoding.GetEncoding("gbk").GetBytes(Content);
            int len = byteContent.Length;
            //内容长度(4)
            byteList.Add((byte)(len >> 24));
            byteList.Add((byte)((len & 0x00ff0000) >> 16));
            byteList.Add((byte)((len & 0x0000ff00) >> 8));
            byteList.Add((byte)((len & 0x000000ff)));

            for (int i = 0; i < byteContent.Length; i++)
            {

                byteList.Add(byteContent[i]);
               
            }
            

            //重置后续数据长度后续数据长度
            int ChildCount = byteList.Count - 51;

            byteList[47] = (byte)(ChildCount >> 24);
            byteList[48] = (byte)((ChildCount & 0x00ff0000) >> 16);
            byteList[49] = (byte)((ChildCount & 0x0000ff00) >> 8);
            byteList[50] = (byte)((ChildCount & 0x000000ff));

            //重置总数据长度后续数据长度
            int TotalCount = byteList.Count + 3;//校验和+结尾符占三位

            byteList[1] = (byte)(TotalCount >> 24);
            byteList[2] = (byte)((TotalCount & 0x00ff0000) >> 16);
            byteList[3] = (byte)((TotalCount & 0x0000ff00) >> 8);
            byteList[4] = (byte)((TotalCount & 0x000000ff));

            //
            if (m_needEncrypt)
            {
                encryptList(byteList);
            }
            //CRC校验：===============================================================
            //校验(2)
            UInt16 crc = (UInt16)(crc_hb(byteList.ToArray()) & 0xFFFF);
            byteList.Add((byte)(crc >> 8));
            byteList.Add((byte)(crc & 0xFF));
            //尾标识：===============================================================
            //尾(1)
            byteList.Add(0x5D);
            byte[] bts = byteList.ToArray();
            return HandlePackageEscape(bts);
        }
        /// <summary>
        /// 制造督办结果应答
        /// </summary>
        /// <param name="VehicleNo"></param>
        /// <param name="VehicleColor"></param>
        /// <param name="InfoID"></param>
        /// <param name="result"></param>
        /// <returns></returns>
        public byte[] MakeSuperWarn(string VehicleNo, byte VehicleColor,   uint InfoID, byte result)
        {
            List<byte> byteList = new List<byte>();
            //头：===============================================================
            //头(1)
            byteList.Add(0x5B);//头
            //数据头：===============================================================
            //数据长度(4)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文序号(4)
            byteList.Add((byte)(m_SequnceID >> 24));
            byteList.Add((byte)((m_SequnceID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_SequnceID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_SequnceID & 0x000000ff)));
            m_SequnceID = m_SequnceID + 1 > 0xfffffff0 ? 0 : m_SequnceID + 1;
            //业务数据类型(4)
            //
            uint cmd = UP_WARN_MSG;

            byteList.Add((byte)(cmd >> 8));
            byteList.Add((byte)(cmd & 0xff));

            //下级平台接入码(4)
            byteList.Add((byte)(m_UserID >> 24));
            byteList.Add((byte)((m_UserID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_UserID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_UserID & 0x000000ff)));

            //协议版本号(3)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            if (m_needEncrypt)
            {
                byteList.Add(0x01);
            }
            else
            {
                byteList.Add(0x00);
            }
            //加密密钥(4)
            byteList.Add((byte)(m_key >> 24));
            byteList.Add((byte)((m_key & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_key & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_key & 0x000000ff)));

            //数据体：===============================================================
            //车牌(21)
            byte[] vehBytes = System.Text.Encoding.GetEncoding("gbk").GetBytes(VehicleNo);

            for (int i = 0; i < 21; i++)
            {
                if (i > vehBytes.Length - 1)
                {
                    byteList.Add(0);
                }
                else
                {
                    byteList.Add(vehBytes[i]);
                }
            }
            //车牌颜色(1)
            byteList.Add(VehicleColor);
            //子业务标识(2)：
            cmd = UP_WARN_MSG_URGE_TODO_ACK;
            byteList.Add((byte)(cmd >> 8));
            byteList.Add((byte)(cmd & 0xff));

            //后续数据长度(5)：
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x05);

            //督办ID (4)
            byteList.Add((byte)((InfoID >> 24)&0xff));
            byteList.Add((byte)((InfoID >> 16) & 0xff));
            byteList.Add((byte)((InfoID >> 8) & 0xff));
            byteList.Add((byte)((InfoID) & 0xff));
             
            //结果（1）
            byteList.Add(result );
            //重置总数据长度后续数据长度
            int TotalCount = byteList.Count + 3;//校验和+结尾符占三位

            byteList[1] = (byte)(TotalCount >> 24);
            byteList[2] = (byte)((TotalCount & 0x00ff0000) >> 16);
            byteList[3] = (byte)((TotalCount & 0x0000ff00) >> 8);
            byteList[4] = (byte)((TotalCount & 0x000000ff));

            //
            if (m_needEncrypt)
            {
                encryptList(byteList);
            }
            //CRC校验：===============================================================
            //校验(2)
            UInt16 crc = (UInt16)(crc_hb(byteList.ToArray()) & 0xFFFF);
            byteList.Add((byte)(crc >> 8));
            byteList.Add((byte)(crc & 0xFF));
            //尾标识：===============================================================
            //尾(1)
            byteList.Add(0x5D);
            byte[] bts = byteList.ToArray();
            return HandlePackageEscape(bts);
        }
        /// <summary>
        /// 应答车辆短信下发
        /// </summary>
        /// <param name="VehicleNo"></param>
        /// <param name="VehicleColor"></param>
        /// <param name="InfoID"></param>
        /// <param name="result"></param>
        /// <returns></returns>
        public byte[] MakeVehicleMsgAwser(string VehicleNo, byte VehicleColor, uint InfoID, byte result)
        {
            List<byte> byteList = new List<byte>();
            //头：===============================================================
            //头(1)
            byteList.Add(0x5B);//头
            //数据头：===============================================================
            //数据长度(4)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文序号(4)
            byteList.Add((byte)(m_SequnceID >> 24));
            byteList.Add((byte)((m_SequnceID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_SequnceID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_SequnceID & 0x000000ff)));
            m_SequnceID = m_SequnceID + 1 > 0xfffffff0 ? 0 : m_SequnceID + 1;
            //业务数据类型(4)
            //
            uint cmd = UP_CTRL_MSG ;

            byteList.Add((byte)(cmd >> 8));
            byteList.Add((byte)(cmd & 0xff));

            //下级平台接入码(4)
            byteList.Add((byte)(m_UserID >> 24));
            byteList.Add((byte)((m_UserID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_UserID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_UserID & 0x000000ff)));

            //协议版本号(3)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            if (m_needEncrypt)
            {
                byteList.Add(0x01);
            }
            else
            {
                byteList.Add(0x00);
            }
            //加密密钥(4)
            byteList.Add((byte)(m_key >> 24));
            byteList.Add((byte)((m_key & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_key & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_key & 0x000000ff)));

            //数据体：===============================================================
            //车牌(21)
            byte[] vehBytes = System.Text.Encoding.GetEncoding("gbk").GetBytes(VehicleNo);

            for (int i = 0; i < 21; i++)
            {
                if (i > vehBytes.Length - 1)
                {
                    byteList.Add(0);
                }
                else
                {
                    byteList.Add(vehBytes[i]);
                }
            }
            //车牌颜色(1)
            byteList.Add(VehicleColor);
            //子业务标识(2)：
            cmd = UP_CTRL_MSG_TEXT_INFO_ACK;
            byteList.Add((byte)(cmd >> 8));
            byteList.Add((byte)(cmd & 0xff));

            //后续数据长度(5)：
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x05);

            //督办ID (4)
            byteList.Add((byte)((InfoID >> 24) & 0xff));
            byteList.Add((byte)((InfoID >> 16) & 0xff));
            byteList.Add((byte)((InfoID >> 8) & 0xff));
            byteList.Add((byte)((InfoID) & 0xff));

            //结果（1）
            byteList.Add(result);
            //重置总数据长度后续数据长度
            int TotalCount = byteList.Count + 3;//校验和+结尾符占三位

            byteList[1] = (byte)(TotalCount >> 24);
            byteList[2] = (byte)((TotalCount & 0x00ff0000) >> 16);
            byteList[3] = (byte)((TotalCount & 0x0000ff00) >> 8);
            byteList[4] = (byte)((TotalCount & 0x000000ff));

            //
            if (m_needEncrypt)
            {
                encryptList(byteList);
            }
            //CRC校验：===============================================================
            //校验(2)
            UInt16 crc = (UInt16)(crc_hb(byteList.ToArray()) & 0xFFFF);
            byteList.Add((byte)(crc >> 8));
            byteList.Add((byte)(crc & 0xFF));
            //尾标识：===============================================================
            //尾(1)
            byteList.Add(0x5D);
            byte[] bts = byteList.ToArray();
            return HandlePackageEscape(bts);
        }


        public byte[] MakeWantVehiclePhotoAnswer(string VehicleCode, byte Color, byte result, GPSDATA GPS, byte chanel, byte sizetag, byte photoType, byte[] photoData)
        {
            List<byte> byteList = new List<byte>();
            //头：===============================================================
            //头(1)
            byteList.Add(0x5B);//头
            //数据头：===============================================================
            //数据长度(4)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文序号(4)
            byteList.Add((byte)(m_SequnceID >> 24));
            byteList.Add((byte)((m_SequnceID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_SequnceID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_SequnceID & 0x000000ff)));
            m_SequnceID = m_SequnceID + 1 > 0xfffffff0 ? 0 : m_SequnceID + 1;
            //业务数据类型(4)
            //
            uint cmd = UP_CTRL_MSG ;

            byteList.Add((byte)(cmd >> 8));
            byteList.Add((byte)(cmd & 0xff));

            //下级平台接入码(4)
            byteList.Add((byte)(m_UserID >> 24));
            byteList.Add((byte)((m_UserID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_UserID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_UserID & 0x000000ff)));

            //协议版本号(3)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            if (m_needEncrypt)
            {
                byteList.Add(0x01);
            }
            else
            {
                byteList.Add(0x00);
            }
            //加密密钥(4)
            byteList.Add((byte)(m_key >> 24));
            byteList.Add((byte)((m_key & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_key & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_key & 0x000000ff)));

            //数据体：===============================================================
            //车牌(21)
            byte[] vehBytes = System.Text.Encoding.GetEncoding("gbk").GetBytes(VehicleCode);

            for (int i = 0; i < 21; i++)
            {
                if (i > vehBytes.Length - 1)
                {
                    byteList.Add(0);
                }
                else
                {
                    byteList.Add(vehBytes[i]);
                }
            }
            //车牌颜色(1)
            byteList.Add(Color);
            //子业务标识(2)：
            cmd = UP_CTRL_MSG_TAKE_PHOTO_ACK;
            byteList.Add((byte)(cmd >> 8));
            byteList.Add((byte)(cmd & 0xff));

            //后续数据长度(44 + photoData.Length)：
            int lenAfter = 44+ photoData.Length;
            byteList.Add((byte)(lenAfter >> 24));
            byteList.Add((byte)((lenAfter & 0x00ff0000) >> 16));
            byteList.Add((byte)((lenAfter & 0x0000ff00) >> 8));
            byteList.Add((byte)((lenAfter & 0x000000ff)));

            //rsp flag   (1)
            byteList.Add(result);
            //gps(36)

            //==================36BYTE GPS开始==================
            //定位加密（1）

            byteList.Add(0x00);

            //(dmyy)日期(4)
            byteList.Add((byte)(GPS.Time.Day));
            byteList.Add((byte)(GPS.Time.Month));
            byteList.Add((byte)(GPS.Time.Year >> 8));
            byteList.Add((byte)(GPS.Time.Year & 0xff));
            //时间(hms)(3)
            byteList.Add((byte)(GPS.Time.Hour));
            byteList.Add((byte)(GPS.Time.Minute));
            byteList.Add((byte)(GPS.Time.Second));
            //经度(4)
            byteList.Add((byte)(GPS.Lng >> 24));
            byteList.Add((byte)((GPS.Lng & 0x00ff0000) >> 16));
            byteList.Add((byte)((GPS.Lng & 0x0000ff00) >> 8));
            byteList.Add((byte)((GPS.Lng & 0x000000ff)));

            //纬度(4)
            byteList.Add((byte)(GPS.Lat >> 24));
            byteList.Add((byte)((GPS.Lat & 0x00ff0000) >> 16));
            byteList.Add((byte)((GPS.Lat & 0x0000ff00) >> 8));
            byteList.Add((byte)((GPS.Lat & 0x000000ff)));
            //速度(2)
            byteList.Add((byte)(GPS.Speed >> 8));
            byteList.Add((byte)(GPS.Speed & 0xff));
            //记录仪速度(2)
            byteList.Add((byte)(GPS.Speed_machine >> 8));
            byteList.Add((byte)(GPS.Speed_machine & 0xff));

            //里程(4)
            byteList.Add((byte)(GPS.total_course >> 24));
            byteList.Add((byte)((GPS.total_course & 0x00ff0000) >> 16));
            byteList.Add((byte)((GPS.total_course & 0x0000ff00) >> 8));
            byteList.Add((byte)((GPS.total_course & 0x000000ff)));

            //方向(2)
            byteList.Add((byte)(GPS.Angle >> 8));
            byteList.Add((byte)(GPS.Angle & 0xff));

            //高度(2)
            byteList.Add((byte)(GPS.Height >> 8));
            byteList.Add((byte)(GPS.Height & 0xff));
            //状态(4)
            byteList.Add((byte)(GPS.Status >> 24));
            byteList.Add((byte)((GPS.Status & 0x00ff0000) >> 16));
            byteList.Add((byte)((GPS.Status & 0x0000ff00) >> 8));
            byteList.Add((byte)((GPS.Status & 0x000000ff)));

            //报警状态(4)
            byteList.Add((byte)(GPS.Alarm >> 24));
            byteList.Add((byte)((GPS.Alarm & 0x00ff0000) >> 16));
            byteList.Add((byte)((GPS.Alarm & 0x0000ff00) >> 8));
            byteList.Add((byte)((GPS.Alarm & 0x000000ff)));

            //==================36BYTE GPS结束==================
            //channel:
            byteList.Add(chanel);

            //照片流大小（4）
            byteList.Add((byte)(photoData.Length>> 24));
            byteList.Add((byte)((photoData.Length & 0x00ff0000) >> 16));
            byteList.Add((byte)((photoData.Length & 0x0000ff00) >> 8));
            byteList.Add((byte)((photoData.Length & 0x000000ff)));

            //照片尺寸
            byteList.Add(sizetag);
            byteList.Add(photoType);
            for (int i = 0; i < photoData.Length;i++ )
            {
                byteList.Add(photoData[i]);
            }
            //重置总数据长度后续数据长度
            int TotalCount = byteList.Count + 3;//校验和+结尾符占三位

            byteList[1] = (byte)(TotalCount >> 24);
            byteList[2] = (byte)((TotalCount & 0x00ff0000) >> 16);
            byteList[3] = (byte)((TotalCount & 0x0000ff00) >> 8);
            byteList[4] = (byte)((TotalCount & 0x000000ff));

            //
            if (m_needEncrypt)
            {
                encryptList(byteList);
            }
            //CRC校验：===============================================================
            //校验(2)
            UInt16 crc = (UInt16)(crc_hb(byteList.ToArray()) & 0xFFFF);
            byteList.Add((byte)(crc >> 8));
            byteList.Add((byte)(crc & 0xFF));
            //尾标识：===============================================================
            //尾(1)
            byteList.Add(0x5D);
            byte[] bts = byteList.ToArray();
            return HandlePackageEscape(bts);
        }
        public byte[] MakeWantVehicleTravelAwser(string VehicleCode, byte Color, byte type, byte[] data)
        {
            List<byte> byteList = new List<byte>();
            //头：===============================================================
            //头(1)
            byteList.Add(0x5B);//头
            //数据头：===============================================================
            //数据长度(4)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文序号(4)
            byteList.Add((byte)(m_SequnceID >> 24));
            byteList.Add((byte)((m_SequnceID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_SequnceID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_SequnceID & 0x000000ff)));
            m_SequnceID = m_SequnceID + 1 > 0xfffffff0 ? 0 : m_SequnceID + 1;
            //业务数据类型(4)
            //
            uint cmd = UP_CTRL_MSG ;

            byteList.Add((byte)(cmd >> 8));
            byteList.Add((byte)(cmd & 0xff));

            //下级平台接入码(4)
            byteList.Add((byte)(m_UserID >> 24));
            byteList.Add((byte)((m_UserID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_UserID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_UserID & 0x000000ff)));

            //协议版本号(3)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            if (m_needEncrypt)
            {
                byteList.Add(0x01);
            }
            else
            {
                byteList.Add(0x00);
            }
            //加密密钥(4)
            byteList.Add((byte)(m_key >> 24));
            byteList.Add((byte)((m_key & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_key & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_key & 0x000000ff)));

            //数据体：===============================================================
            //车牌(21)
            byte[] vehBytes = System.Text.Encoding.GetEncoding("gbk").GetBytes(VehicleCode);

            for (int i = 0; i < 21; i++)
            {
                if (i > vehBytes.Length - 1)
                {
                    byteList.Add(0);
                }
                else
                {
                    byteList.Add(vehBytes[i]);
                }
            }
            //车牌颜色(1)
            byteList.Add(Color);
            //子业务标识(2)：
            cmd = UP_CTRL_MSG_TAKE_TRAVEL_ACK;
            byteList.Add((byte)(cmd >> 8));
            byteList.Add((byte)(cmd & 0xff));

            //后续数据长度(44 + photoData.Length)：
            int lenAfter = 5 + data.Length;
            byteList.Add((byte)(lenAfter >> 24));
            byteList.Add((byte)((lenAfter & 0x00ff0000) >> 16));
            byteList.Add((byte)((lenAfter & 0x0000ff00) >> 8));
            byteList.Add((byte)((lenAfter & 0x000000ff)));

            //命令字 flag   (1)
            byteList.Add(type);
     
            // 记录仪数据长度（4）
            byteList.Add((byte)(data.Length>> 24));
            byteList.Add((byte)((data.Length & 0x00ff0000) >> 16));
            byteList.Add((byte)((data.Length & 0x0000ff00) >> 8));
            byteList.Add((byte)((data.Length & 0x000000ff)));
            for (int i = 0; i < data.Length; i++)
            {
                byteList.Add(data[i]);
            }
            //重置总数据长度后续数据长度
            int TotalCount = byteList.Count + 3;//校验和+结尾符占三位

            byteList[1] = (byte)(TotalCount >> 24);
            byteList[2] = (byte)((TotalCount & 0x00ff0000) >> 16);
            byteList[3] = (byte)((TotalCount & 0x0000ff00) >> 8);
            byteList[4] = (byte)((TotalCount & 0x000000ff));

            //
            if (m_needEncrypt)
            {
                encryptList(byteList);
            }
            //CRC校验：===============================================================
            //校验(2)
            UInt16 crc = (UInt16)(crc_hb(byteList.ToArray()) & 0xFFFF);
            byteList.Add((byte)(crc >> 8));
            byteList.Add((byte)(crc & 0xFF));
            //尾标识：===============================================================
            //尾(1)
            byteList.Add(0x5D);
            byte[] bts = byteList.ToArray();
            return HandlePackageEscape(bts);
        }
        /// <summary>
        /// 制造 紧急接入应答
        /// </summary>
        /// <param name="VehicleNo"></param>
        /// <param name="VehicleColor"></param>
        /// <param name="result"></param>
        /// <returns></returns>
        public byte[] MakeWantVehicleChangeNetAnswer(string VehicleNo, byte VehicleColor,  byte result)
        {
            List<byte> byteList = new List<byte>();
            //头：===============================================================
            //头(1)
            byteList.Add(0x5B);//头
            //数据头：===============================================================
            //数据长度(4)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文序号(4)
            byteList.Add((byte)(m_SequnceID >> 24));
            byteList.Add((byte)((m_SequnceID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_SequnceID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_SequnceID & 0x000000ff)));
            m_SequnceID = m_SequnceID + 1 > 0xfffffff0 ? 0 : m_SequnceID + 1;
            //业务数据类型(4)
            //
            uint cmd = UP_CTRL_MSG ;

            byteList.Add((byte)(cmd >> 8));
            byteList.Add((byte)(cmd & 0xff));

            //下级平台接入码(4)
            byteList.Add((byte)(m_UserID >> 24));
            byteList.Add((byte)((m_UserID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_UserID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_UserID & 0x000000ff)));

            //协议版本号(3)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            if (m_needEncrypt)
            {
                byteList.Add(0x01);
            }
            else
            {
                byteList.Add(0x00);
            }
            //加密密钥(4)
            byteList.Add((byte)(m_key >> 24));
            byteList.Add((byte)((m_key & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_key & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_key & 0x000000ff)));

            //数据体：===============================================================
            //车牌(21)
            byte[] vehBytes = System.Text.Encoding.GetEncoding("gbk").GetBytes(VehicleNo);

            for (int i = 0; i < 21; i++)
            {
                if (i > vehBytes.Length - 1)
                {
                    byteList.Add(0);
                }
                else
                {
                    byteList.Add(vehBytes[i]);
                }
            }
            //车牌颜色(1)
            byteList.Add(VehicleColor);
            //子业务标识(2)：
            cmd = UP_CTRL_MSG_EMERGENCY_MONITORING_ACK;
            byteList.Add((byte)(cmd >> 8));
            byteList.Add((byte)(cmd & 0xff));

            //后续数据长度(1)：
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x01);

            
            //结果（1）
            byteList.Add(result);
            //重置总数据长度后续数据长度
            int TotalCount = byteList.Count + 3;//校验和+结尾符占三位

            byteList[1] = (byte)(TotalCount >> 24);
            byteList[2] = (byte)((TotalCount & 0x00ff0000) >> 16);
            byteList[3] = (byte)((TotalCount & 0x0000ff00) >> 8);
            byteList[4] = (byte)((TotalCount & 0x000000ff));

            //
            if (m_needEncrypt)
            {
                encryptList(byteList);
            }
            //CRC校验：===============================================================
            //校验(2)
            UInt16 crc = (UInt16)(crc_hb(byteList.ToArray()) & 0xFFFF);
            byteList.Add((byte)(crc >> 8));
            byteList.Add((byte)(crc & 0xFF));
            //尾标识：===============================================================
            //尾(1)
            byteList.Add(0x5D);
            byte[] bts = byteList.ToArray();
            return HandlePackageEscape(bts);
        }

        public byte[] MakeSendWantVehicleMonitorTelephoneAnswer(string VehicleNo, byte VehicleColor, byte result)
        {
            List<byte> byteList = new List<byte>();
            //头：===============================================================
            //头(1)
            byteList.Add(0x5B);//头
            //数据头：===============================================================
            //数据长度(4)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文序号(4)
            byteList.Add((byte)(m_SequnceID >> 24));
            byteList.Add((byte)((m_SequnceID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_SequnceID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_SequnceID & 0x000000ff)));
            m_SequnceID = m_SequnceID + 1 > 0xfffffff0 ? 0 : m_SequnceID + 1;
            //业务数据类型(4)
            //
            uint cmd = UP_CTRL_MSG ;

            byteList.Add((byte)(cmd >> 8));
            byteList.Add((byte)(cmd & 0xff));

            //下级平台接入码(4)
            byteList.Add((byte)(m_UserID >> 24));
            byteList.Add((byte)((m_UserID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_UserID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_UserID & 0x000000ff)));

            //协议版本号(3)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            if (m_needEncrypt)
            {
                byteList.Add(0x01);
            }
            else
            {
                byteList.Add(0x00);
            }
            //加密密钥(4)
            byteList.Add((byte)(m_key >> 24));
            byteList.Add((byte)((m_key & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_key & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_key & 0x000000ff)));

            //数据体：===============================================================
            //车牌(21)
            byte[] vehBytes = System.Text.Encoding.GetEncoding("gbk").GetBytes(VehicleNo);

            for (int i = 0; i < 21; i++)
            {
                if (i > vehBytes.Length - 1)
                {
                    byteList.Add(0);
                }
                else
                {
                    byteList.Add(vehBytes[i]);
                }
            }
            //车牌颜色(1)
            byteList.Add(VehicleColor);
            //子业务标识(2)：
            cmd = UP_CTRL_MSG_MONITOR_VEHICLE_ACK;
            byteList.Add((byte)(cmd >> 8));
            byteList.Add((byte)(cmd & 0xff));

            //后续数据长度(1)：
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x01);

            
            //结果（1）
            byteList.Add(result);
            //重置总数据长度后续数据长度
            int TotalCount = byteList.Count + 3;//校验和+结尾符占三位

            byteList[1] = (byte)(TotalCount >> 24);
            byteList[2] = (byte)((TotalCount & 0x00ff0000) >> 16);
            byteList[3] = (byte)((TotalCount & 0x0000ff00) >> 8);
            byteList[4] = (byte)((TotalCount & 0x000000ff));

            //
            if (m_needEncrypt)
            {
                encryptList(byteList);
            }
            //CRC校验：===============================================================
            //校验(2)
            UInt16 crc = (UInt16)(crc_hb(byteList.ToArray()) & 0xFFFF);
            byteList.Add((byte)(crc >> 8));
            byteList.Add((byte)(crc & 0xFF));
            //尾标识：===============================================================
            //尾(1)
            byteList.Add(0x5D);
            byte[] bts = byteList.ToArray();
            return HandlePackageEscape(bts);
        }

        
        public byte[] MakeVehicleWarnTODO(string VehicleNo, byte VehicleColor,   uint InfoID, byte Result)
        {
            List<byte> byteList = new List<byte>();
            //头：===============================================================
            //头(1)
            byteList.Add(0x5B);//头
            //数据头：===============================================================
            //数据长度(4)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文序号(4)
            byteList.Add((byte)(m_SequnceID >> 24));
            byteList.Add((byte)((m_SequnceID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_SequnceID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_SequnceID & 0x000000ff)));
            m_SequnceID = m_SequnceID + 1 > 0xfffffff0 ? 0 : m_SequnceID + 1;
            //业务数据类型(4)
            //
            uint cmd = UP_WARN_MSG;

            byteList.Add((byte)(cmd >> 8));
            byteList.Add((byte)(cmd & 0xff));

            //下级平台接入码(4)
            byteList.Add((byte)(m_UserID >> 24));
            byteList.Add((byte)((m_UserID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_UserID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_UserID & 0x000000ff)));

            //协议版本号(3)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            if (m_needEncrypt)
            {
                byteList.Add(0x01);
            }
            else
            {
                byteList.Add(0x00);
            }
            //加密密钥(4)
            byteList.Add((byte)(m_key >> 24));
            byteList.Add((byte)((m_key & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_key & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_key & 0x000000ff)));

            //数据体：===============================================================
            //车牌(21)
            byte[] vehBytes = System.Text.Encoding.GetEncoding("gbk").GetBytes(VehicleNo);

            for (int i = 0; i < 21; i++)
            {
                if (i > vehBytes.Length - 1)
                {
                    byteList.Add(0);
                }
                else
                {
                    byteList.Add(vehBytes[i]);
                }
            }
            //车牌颜色(1)
            byteList.Add(VehicleColor);
            //子业务标识(2)：
            cmd = UP_WARN_MSG_ADPT_TODO_INFO;
            byteList.Add((byte)(cmd >> 8));
            byteList.Add((byte)(cmd & 0xff));

            //后续数据长度(4)：
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
 
            //ID(4)
            byteList.Add((byte)(InfoID >> 24));
            byteList.Add((byte)((InfoID & 0x00ff0000) >> 16));
            byteList.Add((byte)((InfoID & 0x0000ff00) >> 8));
            byteList.Add((byte)((InfoID & 0x000000ff)));

            //处理结果
            byteList.Add(Result);
            
            //重置后续数据长度后续数据长度
            int ChildCount = byteList.Count - 51;

            byteList[47] = (byte)(ChildCount >> 24);
            byteList[48] = (byte)((ChildCount & 0x00ff0000) >> 16);
            byteList[49] = (byte)((ChildCount & 0x0000ff00) >> 8);
            byteList[50] = (byte)((ChildCount & 0x000000ff));

            //重置总数据长度后续数据长度
            int TotalCount = byteList.Count + 3;//校验和+结尾符占三位

            byteList[1] = (byte)(TotalCount >> 24);
            byteList[2] = (byte)((TotalCount & 0x00ff0000) >> 16);
            byteList[3] = (byte)((TotalCount & 0x0000ff00) >> 8);
            byteList[4] = (byte)((TotalCount & 0x000000ff));

            //
            if (m_needEncrypt)
            {
                encryptList(byteList);
            }
            //CRC校验：===============================================================
            //校验(2)
            UInt16 crc = (UInt16)(crc_hb(byteList.ToArray()) & 0xFFFF);
            byteList.Add((byte)(crc >> 8));
            byteList.Add((byte)(crc & 0xFF));
            //尾标识：===============================================================
            //尾(1)
            byteList.Add(0x5D);
            byte[] bts = byteList.ToArray();
            return HandlePackageEscape(bts);
        }
        public byte[] MakeRegisterData( string VehicleNo,byte VehicleColor,string TermFactory,string TermType,string TermNo,string SimCode) { 
            List<byte> byteList=new List<byte>();
            //头：===============================================================
            //头(1)
            byteList.Add(0x5B);//头
            //数据头：===============================================================
            //数据长度(4)
            byteList.Add(0x00); 
            byteList.Add(0x00); 
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文序号(4)
            byteList.Add((byte)(m_SequnceID >> 24));
            byteList.Add((byte)((m_SequnceID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_SequnceID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_SequnceID & 0x000000ff)));
            m_SequnceID = m_SequnceID + 1 > 0xfffffff0 ? 0 : m_SequnceID + 1;
            //业务数据类型(4)
            //
            uint cmd = UP_EXG_MSG;
           
            byteList.Add((byte)(cmd >> 8));
            byteList.Add((byte)(cmd & 0xff)  );

            //下级平台接入码(4)
            byteList.Add((byte)(m_UserID >> 24));
            byteList.Add((byte)((m_UserID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_UserID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_UserID & 0x000000ff)));
            
            //协议版本号(3)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            if (m_needEncrypt)
            {
                byteList.Add(0x01);
            }
            else
            {
                byteList.Add(0x00);
            }
            //加密密钥(4)
            byteList.Add((byte)(m_key >> 24));
            byteList.Add((byte)((m_key & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_key & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_key & 0x000000ff)));

            //数据体：===============================================================
           //车牌(21)
            byte[] vehBytes= System.Text.Encoding.GetEncoding("gbk").GetBytes(VehicleNo);
             
            for (int i = 0; i < 21; i++)
            {
                if (i > vehBytes.Length - 1)
                {
                    byteList.Add(0);
                }
                else
                {
                    byteList.Add(vehBytes[i]);
                }
            }
            //车牌颜色(1)
            byteList.Add(VehicleColor);
            //子业务标识(2)：
            cmd = UP_EXG_MSG_REGISTER;
            byteList.Add((byte)(cmd >> 8));
            byteList.Add((byte)(cmd & 0xff));

            //后续数据长度(4)：
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);

            //平台唯一编码(11位)
            byte[] platBytes = System.Text.Encoding.GetEncoding("gbk").GetBytes(m_Platform_id.ToString());
            for (int i = 0; i < 11;i++ )
            {
                if (i > platBytes.Length - 1)
                {
                    byteList.Add(0);//补0
                }
                else
                {
                    byteList.Add(platBytes[i]);
                }
            }
            //制造商唯一编码(11位)
            platBytes = System.Text.Encoding.GetEncoding("gbk").GetBytes(TermFactory);
            for (int i = 0; i < 11; i++)
            {
                if (i > platBytes.Length - 1)
                {
                    byteList.Add(0);
                }
                else
                {
                    byteList.Add(platBytes[i]);
                }
            }
            //终端型号(20位)
            platBytes = System.Text.Encoding.GetEncoding("gbk").GetBytes(TermType);
            for (int i = 0; i < 20; i++)
            {
                if (i > platBytes.Length - 1)
                {
                    byteList.Add(0);
                }
                else
                {
                    byteList.Add(platBytes[i]);
                }
            }
            //终端编号(7位),string TermType,string TermNo,string SimCode
            platBytes = System.Text.Encoding.GetEncoding("gbk").GetBytes(TermNo.ToString());
            for (int i = 0; i < 7; i++)
            {
                if (i > platBytes.Length - 1)
                {
                    byteList.Add(0);
                }
                else
                {
                    byteList.Add(platBytes[i]);
                }
            }
            while (SimCode.Length<12)
            {
                SimCode = "0" + SimCode;
            }
            platBytes = System.Text.Encoding.GetEncoding("gbk").GetBytes(SimCode);
            for (int i = 0; i < 12; i++)
            {
                
                byteList.Add(platBytes[i]);
               
            }

            //重置后续数据长度后续数据长度
            int ChildCount = byteList.Count - 51;

            byteList[47] = (byte)(ChildCount >> 24);
            byteList[48] = (byte)((ChildCount & 0x00ff0000) >> 16);
            byteList[49] = (byte)((ChildCount & 0x0000ff00) >> 8);
            byteList[50] = (byte)((ChildCount & 0x000000ff));
            
            //重置总数据长度后续数据长度
            int TotalCount = byteList.Count +3;//校验和+结尾符占三位

            byteList[1] = (byte)(TotalCount >> 24);
            byteList[2] = (byte)((TotalCount & 0x00ff0000) >> 16);
            byteList[3] = (byte)((TotalCount & 0x0000ff00) >> 8);
            byteList[4] = (byte)((TotalCount & 0x000000ff));
            
            //
            if (m_needEncrypt)
            {
                encryptList(byteList);
            }
            //CRC校验：===============================================================
            //校验(2)
            UInt16 crc = (UInt16)(crc_hb(byteList.ToArray()) & 0xFFFF);
            byteList.Add((byte)(crc>>8));
            byteList.Add((byte)(crc & 0xFF));
            //尾标识：===============================================================
            //尾(1)
            byteList.Add(0x5D);
            byte[] bts= byteList.ToArray();
            return HandlePackageEscape(bts);
        }
        /// <summary>
        /// 注销
        /// </summary>
        /// <returns></returns>
        public byte[] MakeLogout()
        {
            List<byte> byteList = new List<byte>();
            //头：===============================================================
            //头(1)
            byteList.Add(0x5B);//头
            //数据头：===============================================================
            //数据长度(4)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文序号(4)
            byteList.Add((byte)(m_SequnceID >> 24));
            byteList.Add((byte)((m_SequnceID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_SequnceID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_SequnceID & 0x000000ff)));
            m_SequnceID = m_SequnceID + 1 > 0xfffffff0 ? 0 : m_SequnceID + 1;
            //业务数据类型(4)
            //
            uint cmd = UP_DISCONNECT_REQ;

            byteList.Add((byte)(cmd >> 8));
            byteList.Add((byte)(cmd & 0xff));

            //平台接入码
            byteList.Add((byte)(m_UserID >> 24));
            byteList.Add((byte)((m_UserID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_UserID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_UserID & 0x000000ff)));

            //协议版本号(3)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文加密与否(1)
            if (m_needEncrypt)
            {
                byteList.Add(0x01);
            }
            else
            {
                byteList.Add(0x00);
            }
            //加密密钥(4)
            byteList.Add((byte)(m_key >> 24));
            byteList.Add((byte)((m_key & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_key & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_key & 0x000000ff)));

            //数据体
            //下级平台接入码(4)
            byteList.Add((byte)(m_LoginID >> 24));
            byteList.Add((byte)((m_LoginID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_LoginID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_LoginID & 0x000000ff)));

            //密码
            int m = 0;
            for (m = 0; m < m_Password.Length && m < 8; m++)
            {
                byteList.Add((byte)m_Password[m]);
            }
            while (m < 7)
            {
                byteList.Add(0);
            }
            //byteList.Add((byte)(m_Password[0]));
            //byteList.Add((byte)(m_Password[1]));
            //byteList.Add((byte)(m_Password[2]));
            //byteList.Add((byte)(m_Password[3]));
            //byteList.Add((byte)(m_Password[4]));
            //byteList.Add((byte)(m_Password[5]));
            //byteList.Add((byte)(m_Password[6]));
            //byteList.Add((byte)(m_Password[7]));

            //重置总数据长度后续数据长度
            int TotalCount = byteList.Count + 3;//校验和+结尾符占三位

            byteList[1] = (byte)(TotalCount >> 24);
            byteList[2] = (byte)((TotalCount & 0x00ff0000) >> 16);
            byteList[3] = (byte)((TotalCount & 0x0000ff00) >> 8);
            byteList[4] = (byte)((TotalCount & 0x000000ff));
            if (m_needEncrypt)
            {
                encryptList(byteList);
            }
            //
            //CRC校验：===============================================================
            //校验(2)
            UInt16 crc = (UInt16)(crc_hb(byteList.ToArray()) & 0xFFFF);
            byteList.Add((byte)(crc >> 8));
            byteList.Add((byte)(crc & 0xFF));
            //尾标识：===============================================================
            //尾(1)
            byteList.Add(0x5D);
            byte[] bts = byteList.ToArray();
            return HandlePackageEscape(bts);
        }
        /// <summary>
        /// 测试连接状态
        /// </summary>
        /// <returns></returns>
        public byte[] MakeLinkTest()
        {
            List<byte> byteList = new List<byte>();
            //头：===============================================================
            //头(1)
            byteList.Add(0x5B);//头
            //数据头：===============================================================
            //数据长度(4)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文序号(4)
            byteList.Add((byte)(m_SequnceID >> 24));
            byteList.Add((byte)((m_SequnceID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_SequnceID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_SequnceID & 0x000000ff)));
            m_SequnceID = m_SequnceID + 1 > 0xfffffff0 ? 0 : m_SequnceID + 1;
            //业务数据类型(4)
            //
            uint cmd = UP_LINKTEST_REQ;

            byteList.Add((byte)(cmd >> 8));
            byteList.Add((byte)(cmd & 0xff));

            //平台接入码
            byteList.Add((byte)(m_UserID >> 24));
            byteList.Add((byte)((m_UserID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_UserID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_UserID & 0x000000ff)));

            //协议版本号(3)
            byteList.Add(0x00);
            byteList.Add(0x00);
            //byteList.Add(0x00);
            if (m_needEncrypt)
            {
                byteList.Add(0x01);
            }
            else
            {
                byteList.Add(0x00);
            }
            //加密密钥(4)
            //byteList.Add((byte)(m_key >> 24));
            //byteList.Add((byte)((m_key & 0x00ff0000) >> 16));
            //byteList.Add((byte)((m_key & 0x0000ff00) >> 8));
            //byteList.Add((byte)((m_key & 0x000000ff)));

            //数据体
             

            //重置总数据长度后续数据长度
            int TotalCount = byteList.Count + 3;//校验和+结尾符占三位

            byteList[1] = (byte)(TotalCount >> 24);
            byteList[2] = (byte)((TotalCount & 0x00ff0000) >> 16);
            byteList[3] = (byte)((TotalCount & 0x0000ff00) >> 8);
            byteList[4] = (byte)((TotalCount & 0x000000ff));

            //
            if (m_needEncrypt)
            {
                encryptList(byteList);
            }
            //CRC校验：===============================================================
            //校验(2)
            UInt16 crc = (UInt16)(crc_hb(byteList.ToArray()) & 0xFFFF);
            byteList.Add((byte)(crc >> 8));
            byteList.Add((byte)(crc & 0xFF));
            //尾标识：===============================================================
            //尾(1)
            byteList.Add(0x5D);
            byte[] bts = byteList.ToArray();
            return HandlePackageEscape(bts);
        }
        public byte[] MakeDisconnect(byte reason)
        {
            List<byte> byteList = new List<byte>();
            //头：===============================================================
            //头(1)
            byteList.Add(0x5B);//头
            //数据头：===============================================================
            //数据长度(4)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文序号(4)
            byteList.Add((byte)(m_SequnceID >> 24));
            byteList.Add((byte)((m_SequnceID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_SequnceID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_SequnceID & 0x000000ff)));
            m_SequnceID = m_SequnceID + 1 > 0xfffffff0 ? 0 : m_SequnceID + 1;
            //业务数据类型(4)
            //
            uint cmd = UP_DISCONNECT_INFORM;

            byteList.Add((byte)(cmd >> 8));
            byteList.Add((byte)(cmd & 0xff));

            //平台接入码
            byteList.Add((byte)(m_UserID >> 24));
            byteList.Add((byte)((m_UserID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_UserID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_UserID & 0x000000ff)));

            //协议版本号(3)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文加密与否(1)
            if (m_needEncrypt)
            {
                byteList.Add(0x01);
            }
            else
            {
                byteList.Add(0x00);
            }
            //加密密钥(4)
            byteList.Add((byte)(m_key >> 24));
            byteList.Add((byte)((m_key & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_key & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_key & 0x000000ff)));

            //数据体
            byteList.Add(reason);
            
            //重置总数据长度后续数据长度
            int TotalCount = byteList.Count + 3;//校验和+结尾符占三位

            byteList[1] = (byte)(TotalCount >> 24);
            byteList[2] = (byte)((TotalCount & 0x00ff0000) >> 16);
            byteList[3] = (byte)((TotalCount & 0x0000ff00) >> 8);
            byteList[4] = (byte)((TotalCount & 0x000000ff));
            if (m_needEncrypt)
            {
                encryptList(byteList);
            }
            //
            //CRC校验：===============================================================
            //校验(2)
            UInt16 crc = (UInt16)(crc_hb(byteList.ToArray()) & 0xFFFF);
            byteList.Add((byte)(crc >> 8));
            byteList.Add((byte)(crc & 0xFF));
            //尾标识：===============================================================
            //尾(1)
            byteList.Add(0x5D);
            byte[] bts = byteList.ToArray();
            return HandlePackageEscape(bts);
        }
        /// <summary>
        /// GPS实时信息上报
        /// </summary>
        /// <param name="VehicleNo"></param>
        /// <param name="VehicleColor"></param>
        /// <param name="Time"></param>
        /// <param name="Lat"></param>
        /// <param name="Lng"></param>
        /// <param name="Speed"></param>
        /// <param name="Speed_machine"></param>
        /// <param name="total_course"></param>
        /// <param name="Angle"></param>
        /// <param name="Height"></param>
        /// <param name="Status"></param>
        /// <param name="Alarm"></param>
        /// <returns></returns>
        public byte[] MakeGpsData(GPSDATA data)
        {
           
            string VehicleNo=data.VehicleNo;
            byte VehicleColor=data.VehicleColor;
            DateTime Time=data.Time;
            uint Lat=data.Lat;
            uint Lng=data.Lng;
            UInt16 Speed=data.Speed;
            UInt16 Speed_machine=data.Speed_machine;
            uint total_course=data.total_course;
            UInt16 Angle=data.Angle;
            UInt16 Height=data.Height;
            uint Status=data.Status;
            uint Alarm = data.Alarm;

            List<byte> byteList = new List<byte>();
            //头：===============================================================
            //头(1)
            byteList.Add(0x5B);//头
            //数据头：===============================================================
            //数据长度(4)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文序号(4)
            byteList.Add((byte)(m_SequnceID >> 24));
            byteList.Add((byte)((m_SequnceID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_SequnceID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_SequnceID & 0x000000ff)));
            m_SequnceID = m_SequnceID + 1 > 0xfffffff0 ? 0 : m_SequnceID + 1;
            //业务数据类型(4)
            //
            uint cmd = UP_EXG_MSG;

            byteList.Add((byte)(cmd >> 8));
            byteList.Add((byte)(cmd & 0xff));

            //下级平台接入码(4)
            byteList.Add((byte)(m_UserID >> 24));
            byteList.Add((byte)((m_UserID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_UserID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_UserID & 0x000000ff)));

            //协议版本号(3)
            byteList.Add(0x00);
            byteList.Add(0x00);
            //byteList.Add(0x00);
            //报文加密与否(1)
            if (m_needEncrypt)
            {
                byteList.Add(0x01);
            }
            else
            {
                byteList.Add(0x00);
            }
            //加密密钥(4)
            //byteList.Add((byte)(m_key >> 24));
            //byteList.Add((byte)((m_key & 0x00ff0000) >> 16));
            //byteList.Add((byte)((m_key & 0x0000ff00) >> 8));
            //byteList.Add((byte)((m_key & 0x000000ff)));
            
            //23开始
            //数据体：===============================================================
            //车牌(21)
            byte[] vehBytes = System.Text.Encoding.GetEncoding("gbk").GetBytes(VehicleNo);

            for (int i = 0; i < 21; i++)
            {
                if (i > vehBytes.Length - 1)
                {
                    byteList.Add(0);
                }
                else
                {
                    byteList.Add(vehBytes[i]);
                }
            }
            //车牌颜色(1)
            byteList.Add(VehicleColor);
            //子业务标识(2)：
            cmd = UP_EXG_MSG_REAL_LOCATION;
            byteList.Add((byte)(cmd >> 8));
            byteList.Add((byte)(cmd & 0xff));

            //后续数据长度(4)：
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(36);
           
            //定位加密（1）
            
            byteList.Add(0x00);
            
            //(dmyy)日期(4)
            byteList.Add((byte)(Time.Day));
            byteList.Add((byte)(Time.Month));
            byteList.Add((byte)(Time.Year>>8));
            byteList.Add((byte)(Time.Year & 0xff));
            //时间(hms)(3)
            byteList.Add((byte)(Time.Hour));
            byteList.Add((byte)(Time.Minute));
            byteList.Add((byte)(Time.Second));
            //经度(4)
            byteList.Add((byte)(Lng >> 24));
            byteList.Add((byte)((Lng & 0x00ff0000) >> 16));
            byteList.Add((byte)((Lng & 0x0000ff00) >> 8));
            byteList.Add((byte)((Lng & 0x000000ff)));

            //纬度(4)
            byteList.Add((byte)(Lat >> 24));
            byteList.Add((byte)((Lat & 0x00ff0000) >> 16));
            byteList.Add((byte)((Lat & 0x0000ff00) >> 8));
            byteList.Add((byte)((Lat & 0x000000ff)));
            //速度(2)
            byteList.Add((byte)(Speed>> 8));
            byteList.Add((byte)(Speed & 0xff));
            //记录仪速度(2)
            byteList.Add((byte)(Speed_machine >> 8));
            byteList.Add((byte)(Speed_machine & 0xff));

            //里程(4)
            byteList.Add((byte)(total_course >> 24));
            byteList.Add((byte)((total_course & 0x00ff0000) >> 16));
            byteList.Add((byte)((total_course & 0x0000ff00) >> 8));
            byteList.Add((byte)((total_course & 0x000000ff)));

            //方向(2)
            byteList.Add((byte)(Angle >> 8));
            byteList.Add((byte)(Angle & 0xff));

            //高度(2)
            byteList.Add((byte)(Height>> 8));
            byteList.Add((byte)(Height & 0xff));
            //状态(4)
            byteList.Add((byte)(Status >> 24));
            byteList.Add((byte)((Status & 0x00ff0000) >> 16));
            byteList.Add((byte)((Status & 0x0000ff00) >> 8));
            byteList.Add((byte)((Status & 0x000000ff)));

            //报警状态(4)
            byteList.Add((byte)(Alarm >> 24));
            byteList.Add((byte)((Alarm & 0x00ff0000) >> 16));
            byteList.Add((byte)((Alarm & 0x0000ff00) >> 8));
            byteList.Add((byte)((Alarm & 0x000000ff)));
            

            //重置总数据长度后续数据长度
            int TotalCount = byteList.Count + 3;//校验和+结尾符占三位

            byteList[1] = (byte)(TotalCount >> 24);
            byteList[2] = (byte)((TotalCount & 0x00ff0000) >> 16);
            byteList[3] = (byte)((TotalCount & 0x0000ff00) >> 8);
            byteList[4] = (byte)((TotalCount & 0x000000ff));

            //23 ~~~length-4
            if (m_needEncrypt) {
                encryptList(byteList);
            }
            //CRC校验：===============================================================
            //校验(2)
            UInt16 crc = (UInt16)(crc_hb(byteList.ToArray()) & 0xFFFF);
            byteList.Add((byte)(crc >> 8));
            byteList.Add((byte)(crc & 0xFF));
            //尾标识：===============================================================
            //尾(1)
            byteList.Add(0x5D);
            byte[] bts = byteList.ToArray();
            byte[] btsRet = HandlePackageEscape(bts);
            //===============================临时
            //encryptList
            //string debugString = "";
            //for (int i = 0; i < btsRet.Length; i++)
            //{
            //    string hexOutput = String.Format("{0:X}", btsRet[i]);
            //    if (hexOutput.Length < 2)
            //    {
            //        hexOutput = "0" + hexOutput;
            //    }
            //    debugString += " " + hexOutput;
            //}
           // CommonFunc.LogError(debugString);
            //System.Console.Out.WriteLine("发出：" + debugString);
            //===============================结束临时
            return btsRet;
            
        }
        /// <summary>
        /// 制造历史数据
        /// </summary>
        /// <param name="datas"></param>
        /// <returns></returns>
        public byte[] MakeGpsHistoryData(List< GPSDATA> datas)
        {
            if (datas.Count==0)
            {
                throw new Exception("gps数量为0");
            }
            string VehicleNo = datas[0].VehicleNo;
            byte VehicleColor = datas[0].VehicleColor;

            List<byte> byteList = new List<byte>();
            //头：===============================================================
            //头(1)
            byteList.Add(0x5B);//头
            //数据头：===============================================================
            //数据长度(4)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文序号(4)
            byteList.Add((byte)(m_SequnceID >> 24));
            byteList.Add((byte)((m_SequnceID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_SequnceID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_SequnceID & 0x000000ff)));
            m_SequnceID = m_SequnceID + 1 > 0xfffffff0 ? 0 : m_SequnceID + 1;
            //业务数据类型(4)
            //
            uint cmd = UP_EXG_MSG;

            byteList.Add((byte)(cmd >> 8));
            byteList.Add((byte)(cmd & 0xff));

            //下级平台接入码(4)
            byteList.Add((byte)(m_UserID >> 24));
            byteList.Add((byte)((m_UserID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_UserID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_UserID & 0x000000ff)));

            //协议版本号(3)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);

            if (m_needEncrypt)
            {
                byteList.Add(0x01);
            }
            else
            {
                byteList.Add(0x00);
            }
            //加密密钥(4)
            byteList.Add((byte)(m_key >> 24));
            byteList.Add((byte)((m_key & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_key & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_key & 0x000000ff)));
            ////报文加密与否(1)
            //byteList.Add(0x00);
            ////加密密钥(4)
            //byteList.Add(0x00);
            //byteList.Add(0x00);
            //byteList.Add(0x00);
            //byteList.Add(0x00);

            //数据体：===============================================================
            //车牌(21)
            byte[] vehBytes = System.Text.Encoding.GetEncoding("gbk").GetBytes(VehicleNo);

            for (int i = 0; i < 21; i++)
            {
                if (i > vehBytes.Length - 1)
                {
                    byteList.Add(0);
                }
                else
                {
                    byteList.Add(vehBytes[i]);
                }
            }
            //车牌颜色(1)
            byteList.Add(VehicleColor);
            //子业务标识(2)：
            cmd = UP_EXG_MSG_HISTORY_LOCATION;
            byteList.Add((byte)(cmd >> 8));
            byteList.Add((byte)(cmd & 0xff));

            int len = 36 * datas.Count+1;
            //后续数据长度(4)：
            byteList.Add((byte)(len >> 24));
            byteList.Add((byte)((len & 0x00ff0000) >> 16));
            byteList.Add((byte)((len & 0x0000ff00) >> 8));
            byteList.Add((byte)((len & 0x000000ff)));
            //定位个数
            byteList.Add((byte)datas.Count);
            //===================
            for (int i = 0; i < datas.Count;i++ )
            {
                
                DateTime Time = datas[i].Time;
                uint Lat = datas[i].Lat;
                uint Lng = datas[i].Lng;
                UInt16 Speed = datas[i].Speed;
                UInt16 Speed_machine = datas[i].Speed_machine;
                uint total_course = datas[i].total_course;
                UInt16 Angle = datas[i].Angle;
                UInt16 Height = datas[i].Height;
                uint Status = datas[i].Status;
                uint Alarm = datas[i].Alarm;


                //定位加密（1）
                byteList.Add(0x00);
                //(dmyy)日期(4)
                byteList.Add((byte)(Time.Day));
                byteList.Add((byte)(Time.Month));
                byteList.Add((byte)(Time.Year >> 8));
                byteList.Add((byte)(Time.Year & 0xff));
                //时间(hms)(3)
                byteList.Add((byte)(Time.Hour));
                byteList.Add((byte)(Time.Minute));
                byteList.Add((byte)(Time.Second));
                //经度(4)
                byteList.Add((byte)(Lng >> 24));
                byteList.Add((byte)((Lng & 0x00ff0000) >> 16));
                byteList.Add((byte)((Lng & 0x0000ff00) >> 8));
                byteList.Add((byte)((Lng & 0x000000ff)));

                //纬度(4)
                byteList.Add((byte)(Lat >> 24));
                byteList.Add((byte)((Lat & 0x00ff0000) >> 16));
                byteList.Add((byte)((Lat & 0x0000ff00) >> 8));
                byteList.Add((byte)((Lat & 0x000000ff)));
                //速度(2)
                byteList.Add((byte)(Speed >> 8));
                byteList.Add((byte)(Speed & 0xff));
                //记录仪速度(2)
                byteList.Add((byte)(Speed_machine >> 8));
                byteList.Add((byte)(Speed_machine & 0xff));

                //里程(4)
                byteList.Add((byte)(total_course >> 24));
                byteList.Add((byte)((total_course & 0x00ff0000) >> 16));
                byteList.Add((byte)((total_course & 0x0000ff00) >> 8));
                byteList.Add((byte)((total_course & 0x000000ff)));

                //方向(2)
                byteList.Add((byte)(Angle >> 8));
                byteList.Add((byte)(Angle & 0xff));

                //高度(2)
                byteList.Add((byte)(Height >> 8));
                byteList.Add((byte)(Height & 0xff));
                //状态(4)
                byteList.Add((byte)(Status >> 24));
                byteList.Add((byte)((Status & 0x00ff0000) >> 16));
                byteList.Add((byte)((Status & 0x0000ff00) >> 8));
                byteList.Add((byte)((Status & 0x000000ff)));

                //报警状态(4)
                byteList.Add((byte)(Alarm >> 24));
                byteList.Add((byte)((Alarm & 0x00ff0000) >> 16));
                byteList.Add((byte)((Alarm & 0x0000ff00) >> 8));
                byteList.Add((byte)((Alarm & 0x000000ff)));
            }
            

           


            //重置总数据长度后续数据长度
            int TotalCount = byteList.Count + 3;//校验和+结尾符占三位

            byteList[1] = (byte)(TotalCount >> 24);
            byteList[2] = (byte)((TotalCount & 0x00ff0000) >> 16);
            byteList[3] = (byte)((TotalCount & 0x0000ff00) >> 8);
            byteList[4] = (byte)((TotalCount & 0x000000ff));

            if (m_needEncrypt)
            {
                encryptList(byteList);
            }
            //
            //CRC校验：===============================================================
            //校验(2)
            UInt16 crc = (UInt16)(crc_hb(byteList.ToArray()) & 0xFFFF);
            byteList.Add((byte)(crc >> 8));
            byteList.Add((byte)(crc & 0xFF));
            //尾标识：===============================================================
            //尾(1)
            byteList.Add(0x5D);
            byte[] bts = byteList.ToArray();
           //CommonFunc.LogError("make_gps_history");
            return HandlePackageEscape(bts);
        }

        public byte[] MakeDriverData(UInt16 ChildCmd, string VehicleNo, byte VehicleColor, string Name, string ID, string Licence, string Org_Name)
        {
            List<byte> byteList = new List<byte>();
            //头：===============================================================
            //头(1)
            byteList.Add(0x5B);//头
            //数据头：===============================================================
            //数据长度(4)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文序号(4)
            byteList.Add((byte)(m_SequnceID >> 24));
            byteList.Add((byte)((m_SequnceID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_SequnceID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_SequnceID & 0x000000ff)));
            m_SequnceID = m_SequnceID + 1 > 0xfffffff0 ? 0 : m_SequnceID + 1;
            //业务数据类型(4)
            //
            uint cmd = UP_EXG_MSG;

            byteList.Add((byte)(cmd >> 8));
            byteList.Add((byte)(cmd & 0xff));

            //下级平台接入码(4)
            byteList.Add((byte)(m_UserID >> 24));
            byteList.Add((byte)((m_UserID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_UserID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_UserID & 0x000000ff)));

            //协议版本号(3)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文加密与否(1)
            if (m_needEncrypt)
            {
                byteList.Add(0x01);
            }
            else
            {
                byteList.Add(0x00);
            }
            //加密密钥(4)
            byteList.Add((byte)(m_key >> 24));
            byteList.Add((byte)((m_key & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_key & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_key & 0x000000ff)));

            //数据体：===============================================================
            //车牌(21)
            byte[] vehBytes = System.Text.Encoding.GetEncoding("gbk").GetBytes(VehicleNo);

            for (int i = 0; i < 21; i++)
            {
                if (i > vehBytes.Length - 1)
                {
                    byteList.Add(0);
                }
                else
                {
                    byteList.Add(vehBytes[i]);
                }
            }
            //车牌颜色(1)
            byteList.Add(VehicleColor);
            //子业务标识(2)：

            byteList.Add((byte)(ChildCmd >> 8));
            byteList.Add((byte)(ChildCmd & 0xff));

            //后续数据长度(4)：
            int Len = 276;
            byteList.Add((byte)(Len >> 24));
            byteList.Add((byte)((Len & 0x00ff0000) >> 16));
            byteList.Add((byte)((Len & 0x0000ff00) >> 8));
            byteList.Add((byte)((Len & 0x000000ff)));
           
            
            //姓名(16)
            byte[] bytes = Encoding.GetEncoding("gbk").GetBytes(Name);
            for (int i = 0; i < 16;i++ )
            {
                if (i < bytes.Length )
                {
                    byteList.Add(bytes[i]);
                }
                else { 
                    byteList.Add(0);
                }
            }
            //身份证号(20)：
            bytes = Encoding.GetEncoding("gbk").GetBytes(ID);
            for (int i = 0; i < 20; i++)
            {
                if (i < bytes.Length)
                {
                    byteList.Add(bytes[i]);
                }
                else
                {
                    byteList.Add(0);
                }
            }
            //从业资格(40)：
            bytes = Encoding.GetEncoding("gbk").GetBytes(Licence);
            for (int i = 0; i < 40; i++)
            {
                if (i < bytes.Length)
                {
                    byteList.Add(bytes[i]);
                }
                else
                {
                    byteList.Add(0);
                }
            }
            //发证机构(200)：
            bytes = Encoding.GetEncoding("gbk").GetBytes(Org_Name);
            for (int i = 0; i < 200; i++)
            {
                if (i < bytes.Length)
                {
                    byteList.Add(bytes[i]);
                }
                else
                {
                    byteList.Add(0);
                }
            }
            
            //重置总数据长度后续数据长度
            int TotalCount = byteList.Count + 3;//校验和+结尾符占三位

            byteList[1] = (byte)(TotalCount >> 24);
            byteList[2] = (byte)((TotalCount & 0x00ff0000) >> 16);
            byteList[3] = (byte)((TotalCount & 0x0000ff00) >> 8);
            byteList[4] = (byte)((TotalCount & 0x000000ff));

            if (m_needEncrypt)
            {
                encryptList(byteList);
            }
            //
            //CRC校验：===============================================================
            //校验(2)
            UInt16 crc = (UInt16)(crc_hb(byteList.ToArray()) & 0xFFFF);
            byteList.Add((byte)(crc >> 8));
            byteList.Add((byte)(crc & 0xFF));
            //尾标识：===============================================================
            //尾(1)
            byteList.Add(0x5D);
            byte[] bts = byteList.ToArray();
            return HandlePackageEscape(bts);
        }
        /// <summary>
        ///  交换指定车辆信息请求
        /// </summary>
        /// <param name="VehicleNo"></param>
        /// <param name="VehicleColor"></param>
        /// <param name="startTime"></param>
        /// <param name="endTime"></param>
        /// <returns></returns>
        public byte[] MakeMonitorStartup(string VehicleNo, byte VehicleColor,DateTime startTime,DateTime endTime)
        {
            List<byte> byteList = new List<byte>();
            //头：===============================================================
            //头(1)
            byteList.Add(0x5B);//头
            //数据头：===============================================================
            //数据长度(4)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文序号(4)
            byteList.Add((byte)(m_SequnceID >> 24));
            byteList.Add((byte)((m_SequnceID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_SequnceID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_SequnceID & 0x000000ff)));
            m_SequnceID = m_SequnceID + 1 > 0xfffffff0 ? 0 : m_SequnceID + 1;
            //业务数据类型(4)
            //
            uint cmd = UP_EXG_MSG;

            byteList.Add((byte)(cmd >> 8));
            byteList.Add((byte)(cmd & 0xff));

            //下级平台接入码(4)
            byteList.Add((byte)(m_UserID >> 24));
            byteList.Add((byte)((m_UserID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_UserID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_UserID & 0x000000ff)));

            //协议版本号(3)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文加密与否(1)
            if (m_needEncrypt)
            {
                byteList.Add(0x01);
            }
            else
            {
                byteList.Add(0x00);
            }
            //加密密钥(4)
            byteList.Add((byte)(m_key >> 24));
            byteList.Add((byte)((m_key & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_key & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_key & 0x000000ff)));

            //数据体：===============================================================
            //车牌(21)
            byte[] vehBytes = System.Text.Encoding.GetEncoding("gbk").GetBytes(VehicleNo);

            for (int i = 0; i < 21; i++)
            {
                if (i > vehBytes.Length - 1)
                {
                    byteList.Add(0);
                }
                else
                {
                    byteList.Add(vehBytes[i]);
                }
            }
            //车牌颜色(1)
            byteList.Add(VehicleColor);
            //子业务标识(2)：
            UInt16 ChildCmd = UP_EXG_MSG_APPLY_FOR_MONITOR_STARTUP;
            byteList.Add((byte)(ChildCmd >> 8));
            byteList.Add((byte)(ChildCmd & 0xff));

            //后续数据长度(4)：
            int Len = 16;
            byteList.Add((byte)(Len >> 24));
            byteList.Add((byte)((Len & 0x00ff0000) >> 16));
            byteList.Add((byte)((Len & 0x0000ff00) >> 8));
            byteList.Add((byte)((Len & 0x000000ff)));


            //起始时间utc(8)
            UInt64 iFrom = (UInt64)DateTimeToUTC(startTime);
            byteList.Add((byte)(iFrom >> 56));
            byteList.Add((byte)((iFrom & 0x00ff000000000000) >> 48));
            byteList.Add((byte)((iFrom & 0x0000ff0000000000) >> 40));
            byteList.Add((byte)((iFrom & 0x000000ff00000000) >> 32));
            byteList.Add((byte)((iFrom & 0x00000000ff000000) >> 24));
            byteList.Add((byte)((iFrom & 0x0000000000ff0000) >> 16));
            byteList.Add((byte)((iFrom & 0x000000000000ff00) >> 8));
            byteList.Add((byte)((iFrom & 0x0000000000ff)));

            //结束时间utc(8)
            UInt64 iEnd = (UInt64)DateTimeToUTC(startTime);
            byteList.Add((byte)(iEnd >> 56));
            byteList.Add((byte)((iEnd & 0x00ff000000000000) >> 48));
            byteList.Add((byte)((iEnd & 0x0000ff0000000000) >> 40));
            byteList.Add((byte)((iEnd & 0x000000ff00000000) >> 32));
            byteList.Add((byte)((iEnd & 0x00000000ff000000) >> 24));
            byteList.Add((byte)((iEnd & 0x0000000000ff0000) >> 16));
            byteList.Add((byte)((iEnd & 0x000000000000ff00) >> 8));
            byteList.Add((byte)((iEnd & 0x0000000000ff)));
            
            
            //重置总数据长度后续数据长度
            int TotalCount = byteList.Count + 3;//校验和+结尾符占三位

            byteList[1] = (byte)(TotalCount >> 24);
            byteList[2] = (byte)((TotalCount & 0x00ff0000) >> 16);
            byteList[3] = (byte)((TotalCount & 0x0000ff00) >> 8);
            byteList[4] = (byte)((TotalCount & 0x000000ff));

            if (m_needEncrypt)
            {
                encryptList(byteList);
            }
            //
            //CRC校验：===============================================================
            //校验(2)
            UInt16 crc = (UInt16)(crc_hb(byteList.ToArray()) & 0xFFFF);
            byteList.Add((byte)(crc >> 8));
            byteList.Add((byte)(crc & 0xFF));
            //尾标识：===============================================================
            //尾(1)
            byteList.Add(0x5D);
            byte[] bts = byteList.ToArray();
            return HandlePackageEscape(bts);
        }

        public byte[] MakeMsgEnd(string VehicleNo, byte VehicleColor)
        {
            List<byte> byteList = new List<byte>();
            //头：===============================================================
            //头(1)
            byteList.Add(0x5B);//头
            //数据头：===============================================================
            //数据长度(4)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文序号(4)
            byteList.Add((byte)(m_SequnceID >> 24));
            byteList.Add((byte)((m_SequnceID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_SequnceID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_SequnceID & 0x000000ff)));
            m_SequnceID = m_SequnceID + 1 > 0xfffffff0 ? 0 : m_SequnceID + 1;
            //业务数据类型(4)
            //
            uint cmd = UP_EXG_MSG;

            byteList.Add((byte)(cmd >> 8));
            byteList.Add((byte)(cmd & 0xff));

            //下级平台接入码(4)
            byteList.Add((byte)(m_UserID >> 24));
            byteList.Add((byte)((m_UserID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_UserID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_UserID & 0x000000ff)));

            //协议版本号(3)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文加密与否(1)
            if (m_needEncrypt)
            {
                byteList.Add(0x01);
            }
            else
            {
                byteList.Add(0x00);
            }
            //加密密钥(4)
            byteList.Add((byte)(m_key >> 24));
            byteList.Add((byte)((m_key & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_key & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_key & 0x000000ff)));

            //数据体：===============================================================
            //车牌(21)
            byte[] vehBytes = System.Text.Encoding.GetEncoding("gbk").GetBytes(VehicleNo);

            for (int i = 0; i < 21; i++)
            {
                if (i > vehBytes.Length - 1)
                {
                    byteList.Add(0);
                }
                else
                {
                    byteList.Add(vehBytes[i]);
                }
            }
            //车牌颜色(1)
            byteList.Add(VehicleColor);
            //子业务标识(2)：
            UInt16 ChildCmd = UP_EXG_MSG_RETURN_END_ACK;
            byteList.Add((byte)(ChildCmd >> 8));
            byteList.Add((byte)(ChildCmd & 0xff));

            //后续数据长度(4)：
            int Len = 0;
            byteList.Add((byte)(Len >> 24));
            byteList.Add((byte)((Len & 0x00ff0000) >> 16));
            byteList.Add((byte)((Len & 0x0000ff00) >> 8));
            byteList.Add((byte)((Len & 0x000000ff)));

 


            //重置总数据长度后续数据长度
            int TotalCount = byteList.Count + 3;//校验和+结尾符占三位

            byteList[1] = (byte)(TotalCount >> 24);
            byteList[2] = (byte)((TotalCount & 0x00ff0000) >> 16);
            byteList[3] = (byte)((TotalCount & 0x0000ff00) >> 8);
            byteList[4] = (byte)((TotalCount & 0x000000ff));

            if (m_needEncrypt)
            {
                encryptList(byteList);
            }
            //
            //CRC校验：===============================================================
            //校验(2)
            UInt16 crc = (UInt16)(crc_hb(byteList.ToArray()) & 0xFFFF);
            byteList.Add((byte)(crc >> 8));
            byteList.Add((byte)(crc & 0xFF));
            //尾标识：===============================================================
            //尾(1)
            byteList.Add(0x5D);
            byte[] bts = byteList.ToArray();
            return HandlePackageEscape(bts);
        }
        public byte[] MakeMsgStartup(string VehicleNo, byte VehicleColor)
        {
            List<byte> byteList = new List<byte>();
            //头：===============================================================
            //头(1)
            byteList.Add(0x5B);//头
            //数据头：===============================================================
            //数据长度(4)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文序号(4)
            byteList.Add((byte)(m_SequnceID >> 24));
            byteList.Add((byte)((m_SequnceID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_SequnceID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_SequnceID & 0x000000ff)));
            m_SequnceID = m_SequnceID + 1 > 0xfffffff0 ? 0 : m_SequnceID + 1;
            //业务数据类型(4)
            //
            uint cmd = UP_EXG_MSG;

            byteList.Add((byte)(cmd >> 8));
            byteList.Add((byte)(cmd & 0xff));

            //下级平台接入码(4)
            byteList.Add((byte)(m_UserID >> 24));
            byteList.Add((byte)((m_UserID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_UserID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_UserID & 0x000000ff)));

            //协议版本号(3)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文加密与否(1)
            if (m_needEncrypt)
            {
                byteList.Add(0x01);
            }
            else
            {
                byteList.Add(0x00);
            }
            //加密密钥(4)
            byteList.Add((byte)(m_key >> 24));
            byteList.Add((byte)((m_key & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_key & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_key & 0x000000ff)));

            //数据体：===============================================================
            //车牌(21)
            byte[] vehBytes = System.Text.Encoding.GetEncoding("gbk").GetBytes(VehicleNo);

            for (int i = 0; i < 21; i++)
            {
                if (i > vehBytes.Length - 1)
                {
                    byteList.Add(0);
                }
                else
                {
                    byteList.Add(vehBytes[i]);
                }
            }
            //车牌颜色(1)
            byteList.Add(VehicleColor);
            //子业务标识(2)：
            UInt16 ChildCmd = UP_EXG_MSG_RETURN_STARTUP_ACK;
            byteList.Add((byte)(ChildCmd >> 8));
            byteList.Add((byte)(ChildCmd & 0xff));

            //后续数据长度(4)：
            int Len = 0;
            byteList.Add((byte)(Len >> 24));
            byteList.Add((byte)((Len & 0x00ff0000) >> 16));
            byteList.Add((byte)((Len & 0x0000ff00) >> 8));
            byteList.Add((byte)((Len & 0x000000ff)));

 


            //重置总数据长度后续数据长度
            int TotalCount = byteList.Count + 3;//校验和+结尾符占三位

            byteList[1] = (byte)(TotalCount >> 24);
            byteList[2] = (byte)((TotalCount & 0x00ff0000) >> 16);
            byteList[3] = (byte)((TotalCount & 0x0000ff00) >> 8);
            byteList[4] = (byte)((TotalCount & 0x000000ff));

            if (m_needEncrypt)
            {
                encryptList(byteList);
            }
            //
            //CRC校验：===============================================================
            //校验(2)
            UInt16 crc = (UInt16)(crc_hb(byteList.ToArray()) & 0xFFFF);
            byteList.Add((byte)(crc >> 8));
            byteList.Add((byte)(crc & 0xFF));
            //尾标识：===============================================================
            //尾(1)
            byteList.Add(0x5D);
            byte[] bts = byteList.ToArray();
            return HandlePackageEscape(bts);
        }
        /// <summary>
        /// 取消交换指定车辆信息请求
        /// </summary>
        /// <param name="VehicleNo"></param>
        /// <param name="VehicleColor"></param>
        /// <returns></returns>
        public byte[] MakeCancelMonitorStartup(string VehicleNo, byte VehicleColor )
        {
            List<byte> byteList = new List<byte>();
            //头：===============================================================
            //头(1)
            byteList.Add(0x5B);//头
            //数据头：===============================================================
            //数据长度(4)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文序号(4)
            byteList.Add((byte)(m_SequnceID >> 24));
            byteList.Add((byte)((m_SequnceID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_SequnceID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_SequnceID & 0x000000ff)));
            m_SequnceID = m_SequnceID + 1 > 0xfffffff0 ? 0 : m_SequnceID + 1;
            //业务数据类型(4)
            //
            uint cmd = UP_EXG_MSG;

            byteList.Add((byte)(cmd >> 8));
            byteList.Add((byte)(cmd & 0xff));

            //下级平台接入码(4)
            byteList.Add((byte)(m_UserID >> 24));
            byteList.Add((byte)((m_UserID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_UserID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_UserID & 0x000000ff)));

            //协议版本号(3)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文加密与否(1)
            if (m_needEncrypt)
            {
                byteList.Add(0x01);
            }
            else
            {
                byteList.Add(0x00);
            }
            //加密密钥(4)
            byteList.Add((byte)(m_key >> 24));
            byteList.Add((byte)((m_key & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_key & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_key & 0x000000ff)));

            //数据体：===============================================================
            //车牌(21)
            byte[] vehBytes = System.Text.Encoding.GetEncoding("gbk").GetBytes(VehicleNo);

            for (int i = 0; i < 21; i++)
            {
                if (i > vehBytes.Length - 1)
                {
                    byteList.Add(0);
                }
                else
                {
                    byteList.Add(vehBytes[i]);
                }
            }
            //车牌颜色(1)
            byteList.Add(VehicleColor);
            //子业务标识(2)：
            UInt16 ChildCmd = UP_EXG_MSG_APPLY_FOR_MONITOR_END;
            byteList.Add((byte)(ChildCmd >> 8));
            byteList.Add((byte)(ChildCmd & 0xff));

            //后续数据长度(4)：
            int Len = 0;
            byteList.Add((byte)(Len >> 24));
            byteList.Add((byte)((Len & 0x00ff0000) >> 16));
            byteList.Add((byte)((Len & 0x0000ff00) >> 8));
            byteList.Add((byte)((Len & 0x000000ff)));
             
            //重置总数据长度后续数据长度
            int TotalCount = byteList.Count + 3;//校验和+结尾符占三位

            byteList[1] = (byte)(TotalCount >> 24);
            byteList[2] = (byte)((TotalCount & 0x00ff0000) >> 16);
            byteList[3] = (byte)((TotalCount & 0x0000ff00) >> 8);
            byteList[4] = (byte)((TotalCount & 0x000000ff));

            if (m_needEncrypt)
            {
                encryptList(byteList);
            }
            //
            //CRC校验：===============================================================
            //校验(2)
            UInt16 crc = (UInt16)(crc_hb(byteList.ToArray()) & 0xFFFF);
            byteList.Add((byte)(crc >> 8));
            byteList.Add((byte)(crc & 0xFF));
            //尾标识：===============================================================
            //尾(1)
            byteList.Add(0x5D);
            byte[] bts = byteList.ToArray();
            return HandlePackageEscape(bts);
        }
        /// <summary>
        /// 补发车辆定位信息请求
        /// </summary>
        /// <param name="VehicleNo"></param>
        /// <param name="VehicleColor"></param>
        /// <param name="startTime"></param>
        /// <param name="endTime"></param>
        /// <returns></returns>
         public byte[] MakeApplyHistory(string VehicleNo, byte VehicleColor,DateTime startTime,DateTime endTime)
        {
            List<byte> byteList = new List<byte>();
            //头：===============================================================
            //头(1)
            byteList.Add(0x5B);//头
            //数据头：===============================================================
            //数据长度(4)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文序号(4)
            byteList.Add((byte)(m_SequnceID >> 24));
            byteList.Add((byte)((m_SequnceID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_SequnceID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_SequnceID & 0x000000ff)));
            m_SequnceID = m_SequnceID + 1 > 0xfffffff0 ? 0 : m_SequnceID + 1;
            //业务数据类型(4)
            //
            uint cmd = UP_EXG_MSG;

            byteList.Add((byte)(cmd >> 8));
            byteList.Add((byte)(cmd & 0xff));

            //下级平台接入码(4)
            byteList.Add((byte)(m_UserID >> 24));
            byteList.Add((byte)((m_UserID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_UserID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_UserID & 0x000000ff)));

            //协议版本号(3)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文加密与否(1)
            if (m_needEncrypt)
            {
                byteList.Add(0x01);
            }
            else
            {
                byteList.Add(0x00);
            }
            //加密密钥(4)
            byteList.Add((byte)(m_key >> 24));
            byteList.Add((byte)((m_key & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_key & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_key & 0x000000ff)));

            //数据体：===============================================================
            //车牌(21)
            byte[] vehBytes = System.Text.Encoding.GetEncoding("gbk").GetBytes(VehicleNo);

            for (int i = 0; i < 21; i++)
            {
                if (i > vehBytes.Length - 1)
                {
                    byteList.Add(0);
                }
                else
                {
                    byteList.Add(vehBytes[i]);
                }
            }
            //车牌颜色(1)
            byteList.Add(VehicleColor);
            //子业务标识(2)：
            UInt16 ChildCmd = UP_EXG_MSG_APPLY_HISGNSSDATA_REQ;
            byteList.Add((byte)(ChildCmd >> 8));
            byteList.Add((byte)(ChildCmd & 0xff));

            //后续数据长度(4)：
            int Len = 16;
            byteList.Add((byte)(Len >> 24));
            byteList.Add((byte)((Len & 0x00ff0000) >> 16));
            byteList.Add((byte)((Len & 0x0000ff00) >> 8));
            byteList.Add((byte)((Len & 0x000000ff)));


            //起始时间utc(8)
            UInt64 iFrom = (UInt64)DateTimeToUTC(startTime);
            byteList.Add((byte)(iFrom >> 56));
            byteList.Add((byte)((iFrom & 0x00ff000000000000) >> 48));
            byteList.Add((byte)((iFrom & 0x0000ff0000000000) >> 40));
            byteList.Add((byte)((iFrom & 0x000000ff00000000) >> 32));
            byteList.Add((byte)((iFrom & 0x00000000ff000000) >> 24));
            byteList.Add((byte)((iFrom & 0x0000000000ff0000) >> 16));
            byteList.Add((byte)((iFrom & 0x000000000000ff00) >> 8));
            byteList.Add((byte)((iFrom & 0x0000000000ff)));

            //结束时间utc(8)
            UInt64 iEnd = (UInt64)DateTimeToUTC(startTime);
            byteList.Add((byte)(iEnd >> 56));
            byteList.Add((byte)((iEnd & 0x00ff000000000000) >> 48));
            byteList.Add((byte)((iEnd & 0x0000ff0000000000) >> 40));
            byteList.Add((byte)((iEnd & 0x000000ff00000000) >> 32));
            byteList.Add((byte)((iEnd & 0x00000000ff000000) >> 24));
            byteList.Add((byte)((iEnd & 0x0000000000ff0000) >> 16));
            byteList.Add((byte)((iEnd & 0x000000000000ff00) >> 8));
            byteList.Add((byte)((iEnd & 0x0000000000ff)));
            
            
            //重置总数据长度后续数据长度
            int TotalCount = byteList.Count + 3;//校验和+结尾符占三位

            byteList[1] = (byte)(TotalCount >> 24);
            byteList[2] = (byte)((TotalCount & 0x00ff0000) >> 16);
            byteList[3] = (byte)((TotalCount & 0x0000ff00) >> 8);
            byteList[4] = (byte)((TotalCount & 0x000000ff));

            if (m_needEncrypt)
            {
                encryptList(byteList);
            }
            //
            //CRC校验：===============================================================
            //校验(2)
            UInt16 crc = (UInt16)(crc_hb(byteList.ToArray()) & 0xFFFF);
            byteList.Add((byte)(crc >> 8));
            byteList.Add((byte)(crc & 0xFF));
            //尾标识：===============================================================
            //尾(1)
            byteList.Add(0x5D);
            byte[] bts = byteList.ToArray();
            return HandlePackageEscape(bts);
        }
        
        /// <summary>
        /// 制造电子运单
        /// </summary>
        /// <param name="VehicleNo"></param>
        /// <param name="VehicleColor"></param>
        /// <param name="content"></param>
        /// <returns></returns>
        public byte[] MakeVehicleBill( UInt16 ChildCmd, string VehicleNo, byte VehicleColor,string content)
        {
           
            List<byte> byteList = new List<byte>();
            //头：===============================================================
            //头(1)
            byteList.Add(0x5B);//头
            //数据头：===============================================================
            //数据长度(4)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文序号(4)
            byteList.Add((byte)(m_SequnceID >> 24));
            byteList.Add((byte)((m_SequnceID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_SequnceID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_SequnceID & 0x000000ff)));
            m_SequnceID = m_SequnceID + 1 > 0xfffffff0 ? 0 : m_SequnceID + 1;
            //业务数据类型(4)
            //
            uint cmd = UP_EXG_MSG;

            byteList.Add((byte)(cmd >> 8));
            byteList.Add((byte)(cmd & 0xff));

            //下级平台接入码(4)
            byteList.Add((byte)(m_UserID >> 24));
            byteList.Add((byte)((m_UserID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_UserID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_UserID & 0x000000ff)));

            //协议版本号(3)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文加密与否(1)
            if (m_needEncrypt)
            {
                byteList.Add(0x01);
            }
            else
            {
                byteList.Add(0x00);
            }
            //加密密钥(4)
            byteList.Add((byte)(m_key >> 24));
            byteList.Add((byte)((m_key & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_key & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_key & 0x000000ff)));

            //数据体：===============================================================
            //车牌(21)
            byte[] vehBytes = System.Text.Encoding.GetEncoding("gbk").GetBytes(VehicleNo);

            for (int i = 0; i < 21; i++)
            {
                if (i > vehBytes.Length - 1)
                {
                    byteList.Add(0);
                }
                else
                {
                    byteList.Add(vehBytes[i]);
                }
            }
            //车牌颜色(1)
            byteList.Add(VehicleColor);
            //子业务标识(2)：

            byteList.Add((byte)(ChildCmd >> 8));
            byteList.Add((byte)(ChildCmd & 0xff));

            //后续数据长度(4)：
            byte[] billData = Encoding.GetEncoding("gbk").GetBytes(content);
            int Len = billData.Length + 4 ;
            byteList.Add((byte)(Len >> 24));
            byteList.Add((byte)((Len & 0x00ff0000) >> 16));
            byteList.Add((byte)((Len & 0x0000ff00) >> 8));
            byteList.Add((byte)((Len & 0x000000ff)));

           
            byteList.Add((byte)(billData.Length >> 24));
            byteList.Add((byte)((billData.Length >> 16)&0xff));
            byteList.Add((byte)((billData.Length >> 8) & 0xff));
            byteList.Add((byte)((billData.Length ) & 0xff));
            //运单正文(N)
            for (int i = 0; i < billData.Length; i++)
            {
                byteList.Add(billData[i]);
            }
            //重置总数据长度后续数据长度
            int TotalCount = byteList.Count + 3;//校验和+结尾符占三位

            byteList[1] = (byte)(TotalCount >> 24);
            byteList[2] = (byte)((TotalCount & 0x00ff0000) >> 16);
            byteList[3] = (byte)((TotalCount & 0x0000ff00) >> 8);
            byteList[4] = (byte)((TotalCount & 0x000000ff));

            if (m_needEncrypt)
            {
                encryptList(byteList);
            }
            //
            //CRC校验：===============================================================
            //校验(2)
            UInt16 crc = (UInt16)(crc_hb(byteList.ToArray()) & 0xFFFF);
            byteList.Add((byte)(crc >> 8));
            byteList.Add((byte)(crc & 0xFF));
            //尾标识：===============================================================
            //尾(1)
            byteList.Add(0x5D);
            byte[] bts = byteList.ToArray();
            return HandlePackageEscape(bts);
        }
        public byte[] MakeCorpRegister(string Name, string CorpName, byte LogOut, DateTime Time, string IP, uint Port)
        {
            List<byte> byteList = new List<byte>();
            //头：===============================================================
            //头(1)
            byteList.Add(0x5B);//头
            //数据头：===============================================================
            //数据长度(4)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文序号(4)
            byteList.Add((byte)(m_SequnceID >> 24));
            byteList.Add((byte)((m_SequnceID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_SequnceID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_SequnceID & 0x000000ff)));
            m_SequnceID = m_SequnceID + 1 > 0xfffffff0 ? 0 : m_SequnceID + 1;
            //业务数据类型(4)
            //
            uint cmd = UP_EXG_MSG;

            byteList.Add((byte)(cmd >> 8));
            byteList.Add((byte)(cmd & 0xff));

            //下级平台接入码(4)
            byteList.Add((byte)(m_UserID >> 24));
            byteList.Add((byte)((m_UserID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_UserID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_UserID & 0x000000ff)));

            //协议版本号(3)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文加密与否(1)
            if (m_needEncrypt)
            {
                byteList.Add(0x01);
            }
            else
            {
                byteList.Add(0x00);
            }
            //加密密钥(4)
            byteList.Add((byte)(m_key >> 24));
            byteList.Add((byte)((m_key & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_key & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_key & 0x000000ff)));
 
            UInt16 ChildCmd = UP_EXG_MSG_CORP_CENTER_INFO;
            byteList.Add((byte)(ChildCmd >> 8));
            byteList.Add((byte)(ChildCmd & 0xff));

            //后续数据长度(4)：
            int Len = 93;
            byteList.Add((byte)(Len >> 24));
            byteList.Add((byte)((Len & 0x00ff0000) >> 16));
            byteList.Add((byte)((Len & 0x0000ff00) >> 8));
            byteList.Add((byte)((Len & 0x000000ff)));
           
            
            //信息ID(4)

            byteList.Add((byte)(m_SequnceID >> 24));
            byteList.Add((byte)((m_SequnceID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_SequnceID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_SequnceID & 0x000000ff)));
            m_SequnceID = m_SequnceID + 1 > 0xfffffff0 ? 0 : m_SequnceID + 1;
            //运营商编码(12)
            byte[] bytes = Encoding.GetEncoding("gbk").GetBytes(m_UserID.ToString());
            for (int i = 0; i < 12; i++)
            {
                if (i < bytes.Length)
                {
                    byteList.Add(bytes[i]);
                }
                else
                {
                    byteList.Add(0);
                }
            }
            //用户名（16）
            bytes = Encoding.GetEncoding("gbk").GetBytes(Name);
            for (int i = 0; i < 16; i++)
            {
                if (i < bytes.Length)
                {
                    byteList.Add(bytes[i]);
                }
                else
                {
                    byteList.Add(0);
                }
            }
            //企业名（32）
            bytes = Encoding.GetEncoding("gbk").GetBytes(CorpName);
            for (int i = 0; i < 32; i++)
            {
                if (i < bytes.Length)
                {
                    byteList.Add(bytes[i]);
                }
                else
                {
                    byteList.Add(0);
                }
            }
            //签入、答退(1):
            byteList.Add(LogOut);
            //时间utc(8)
            UInt64 tm = (UInt64)DateTimeToUTC(Time);
            byteList.Add((byte)(tm >> 56));
            byteList.Add((byte)((tm & 0x00ff000000000000) >> 48));
            byteList.Add((byte)((tm & 0x0000ff0000000000) >> 40));
            byteList.Add((byte)((tm & 0x000000ff00000000) >> 32));
            byteList.Add((byte)((tm & 0x00000000ff000000) >> 24));
            byteList.Add((byte)((tm & 0x0000000000ff0000) >> 16));
            byteList.Add((byte)((tm & 0x000000000000ff00) >> 8));
            byteList.Add((byte)((tm & 0x0000000000ff)));


            //IP（16）
            bytes = Encoding.GetEncoding("gbk").GetBytes(IP);
            for (int i = 0; i < 16; i++)
            {
                if (i < bytes.Length)
                {
                    byteList.Add(bytes[i]);
                }
                else
                {
                    byteList.Add(0);
                }
            }
            //分中心PORT
            byteList.Add((byte)(Port >> 24));
            byteList.Add((byte)((Port & 0x00ff0000) >> 16));
            byteList.Add((byte)((Port & 0x0000ff00) >> 8));
            byteList.Add((byte)((Port & 0x000000ff)));

             
            //重置总数据长度后续数据长度
            int TotalCount = byteList.Count + 3;//校验和+结尾符占三位

            byteList[1] = (byte)(TotalCount >> 24);
            byteList[2] = (byte)((TotalCount & 0x00ff0000) >> 16);
            byteList[3] = (byte)((TotalCount & 0x0000ff00) >> 8);
            byteList[4] = (byte)((TotalCount & 0x000000ff));

            if (m_needEncrypt)
            {
                encryptList(byteList);
            }
            //CRC校验：===============================================================
            //校验(2)
            UInt16 crc = (UInt16)(crc_hb(byteList.ToArray()) & 0xFFFF);
            byteList.Add((byte)(crc >> 8));
            byteList.Add((byte)(crc & 0xFF));
            //尾标识：===============================================================
            //尾(1)
            byteList.Add(0x5D);
            byte[] bts = byteList.ToArray();
            return HandlePackageEscape(bts);
        }
        /// <summary>
        /// 制造从链路登录请求应答
        /// </summary>
        /// <param name="Result"></param>
        /// <returns></returns>
        public byte[] MakeLoginReqAnswer(byte Result)
        {
            List<byte> byteList = new List<byte>();
            //头：===============================================================
            //头(1)
            byteList.Add(0x5B);//头
            //数据头：===============================================================
            //数据长度(4)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文序号(4)
            byteList.Add((byte)(m_SequnceID >> 24));
            byteList.Add((byte)((m_SequnceID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_SequnceID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_SequnceID & 0x000000ff)));
            m_SequnceID = m_SequnceID + 1 > 0xfffffff0 ? 0 : m_SequnceID + 1;
            //业务数据类型(4)
           
            uint cmd = DOWN_CONNECT_RSP;

            byteList.Add((byte)(cmd >> 8));
            byteList.Add((byte)(cmd & 0xff));

            //下级平台接入码(4)
            byteList.Add((byte)(m_UserID >> 24));
            byteList.Add((byte)((m_UserID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_UserID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_UserID & 0x000000ff)));

            //协议版本号(3)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文加密与否(1)
            if (m_needEncrypt)
            {
                byteList.Add(0x01);
            }
            else
            {
                byteList.Add(0x00);
            }
            //加密密钥(4)
            byteList.Add((byte)(m_key >> 24));
            byteList.Add((byte)((m_key & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_key & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_key & 0x000000ff)));

            //数据体：===============================================================


            //子业务标识(2)：
             
            byteList.Add(0);
            
            int TotalCount = byteList.Count + 3;//校验和+结尾符占三位

            byteList[1] = (byte)(TotalCount >> 24);
            byteList[2] = (byte)((TotalCount & 0x00ff0000) >> 16);
            byteList[3] = (byte)((TotalCount & 0x0000ff00) >> 8);
            byteList[4] = (byte)((TotalCount & 0x000000ff));

            //
             if (m_needEncrypt) {
                encryptList(byteList);
            }
            //CRC校验：===============================================================
            //校验(2)
            UInt16 crc = (UInt16)(crc_hb(byteList.ToArray()) & 0xFFFF);
            byteList.Add((byte)(crc >> 8));
            byteList.Add((byte)(crc & 0xFF));
            //尾标识：===============================================================
            //尾(1)
            byteList.Add(0x5D);
            byte[] bts = byteList.ToArray();
            return HandlePackageEscape(bts);
        }
        /// <summary>
        /// 制造从链路断开连接响应
        /// </summary>
        /// <returns></returns>
        public byte[] MakeReqDisConnectAnswer()
        {
            List<byte> byteList = new List<byte>();
            //头：===============================================================
            //头(1)
            byteList.Add(0x5B);//头
            //数据头：===============================================================
            //数据长度(4)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文序号(4)
            byteList.Add((byte)(m_SequnceID >> 24));
            byteList.Add((byte)((m_SequnceID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_SequnceID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_SequnceID & 0x000000ff)));
            m_SequnceID = m_SequnceID + 1 > 0xfffffff0 ? 0 : m_SequnceID + 1;
            //业务数据类型(4)

            uint cmd = DOWN_DISCONNECT_RSP;

            byteList.Add((byte)(cmd >> 8));
            byteList.Add((byte)(cmd & 0xff));

            //下级平台接入码(4)
            byteList.Add((byte)(m_UserID >> 24));
            byteList.Add((byte)((m_UserID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_UserID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_UserID & 0x000000ff)));

            //协议版本号(3)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文加密与否(1)
            if (m_needEncrypt)
            {
                byteList.Add(0x01);
            }
            else
            {
                byteList.Add(0x00);
            }
            //加密密钥(4)
            byteList.Add((byte)(m_key >> 24));
            byteList.Add((byte)((m_key & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_key & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_key & 0x000000ff)));

            //数据体：===============================================================


            //子业务标识(2)：
           
            
            int TotalCount = byteList.Count + 3;//校验和+结尾符占三位

            byteList[1] = (byte)(TotalCount >> 24);
            byteList[2] = (byte)((TotalCount & 0x00ff0000) >> 16);
            byteList[3] = (byte)((TotalCount & 0x0000ff00) >> 8);
            byteList[4] = (byte)((TotalCount & 0x000000ff));

            if (m_needEncrypt)
            {
                encryptList(byteList);
            }
            //CRC校验：===============================================================
            //校验(2)
            UInt16 crc = (UInt16)(crc_hb(byteList.ToArray()) & 0xFFFF);
            byteList.Add((byte)(crc >> 8));
            byteList.Add((byte)(crc & 0xFF));
            //尾标识：===============================================================
            //尾(1)
            byteList.Add(0x5D);
            byte[] bts = byteList.ToArray();
            return HandlePackageEscape(bts);
        }
        /// <summary>
        /// 制造从链路测试连接响应
        /// </summary>
        /// <returns></returns>
        public byte[] MakeReqTestConnectAnswer()
        {
            List<byte> byteList = new List<byte>();
            //头：===============================================================
            //头(1)
            byteList.Add(0x5B);//头
            //数据头：===============================================================
            //数据长度(4)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文序号(4)
            byteList.Add((byte)(m_SequnceID >> 24));
            byteList.Add((byte)((m_SequnceID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_SequnceID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_SequnceID & 0x000000ff)));
            m_SequnceID = m_SequnceID + 1 > 0xfffffff0 ? 0 : m_SequnceID + 1;
            //业务数据类型(4)

            uint cmd = DOWN_LINKTEST_RSP;

            byteList.Add((byte)(cmd >> 8));
            byteList.Add((byte)(cmd & 0xff));

            //下级平台接入码(4)
            byteList.Add((byte)(m_UserID >> 24));
            byteList.Add((byte)((m_UserID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_UserID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_UserID & 0x000000ff)));

            //协议版本号(3)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文加密与否(1)
            if (m_needEncrypt)
            {
                byteList.Add(0x01);
            }
            else
            {
                byteList.Add(0x00);
            }
            //加密密钥(4)
            byteList.Add((byte)(m_key >> 24));
            byteList.Add((byte)((m_key & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_key & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_key & 0x000000ff)));


            //数据体：===============================================================
            int TotalCount = byteList.Count + 3;//校验和+结尾符占三位

            byteList[1] = (byte)(TotalCount >> 24);
            byteList[2] = (byte)((TotalCount & 0x00ff0000) >> 16);
            byteList[3] = (byte)((TotalCount & 0x0000ff00) >> 8);
            byteList[4] = (byte)((TotalCount & 0x000000ff));

            //
            if (m_needEncrypt)
            {
                encryptList(byteList);
            }
            //CRC校验：===============================================================
            //校验(2)
            UInt16 crc = (UInt16)(crc_hb(byteList.ToArray()) & 0xFFFF);
            byteList.Add((byte)(crc >> 8));
            byteList.Add((byte)(crc & 0xFF));
            //尾标识：===============================================================
            //尾(1)
            byteList.Add(0x5D);
            byte[] bts = byteList.ToArray();
            return HandlePackageEscape(bts);
        }

        public byte[] MakeBaseVehilceInfo(string VehicleCode, byte Color, string VehicleType, string TransType, string VehicleAddress, string OwnerID, string OwnerName, string OwnerPhone)
        {
            List<byte> byteList = new List<byte>();
            //头：===============================================================
            //头(1)
            byteList.Add(0x5B);//头
            //数据头：===============================================================
            //数据长度(4)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文序号(4)
            byteList.Add((byte)(m_SequnceID >> 24));
            byteList.Add((byte)((m_SequnceID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_SequnceID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_SequnceID & 0x000000ff)));
            m_SequnceID = m_SequnceID + 1 > 0xfffffff0 ? 0 : m_SequnceID + 1;
            //业务数据类型(4)

            uint cmd = UP_BASE_MSG;

            byteList.Add((byte)(cmd >> 8));
            byteList.Add((byte)(cmd & 0xff));

            //下级平台接入码(4)
            byteList.Add((byte)(m_UserID >> 24));
            byteList.Add((byte)((m_UserID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_UserID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_UserID & 0x000000ff)));

            //协议版本号(3)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文加密与否(1)
            if (m_needEncrypt)
            {
                byteList.Add(0x01);
            }
            else
            {
                byteList.Add(0x00);
            }
            //加密密钥(4)
            byteList.Add((byte)(m_key >> 24));
            byteList.Add((byte)((m_key & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_key & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_key & 0x000000ff)));

            //数据体：===============================================================
            UInt16 ChildCmd = UP_BASE_MSG_VEHICLE_ADDED_ACK;
            byteList.Add((byte)(ChildCmd >> 8));
            byteList.Add((byte)(ChildCmd & 0xff));

            string content = "";
            content +="VIN:="+VehicleCode+";";
            content += "VEHICLE_COLOR:=" + Color + ";";
            content += "VEHICLE_TYPE:=" + VehicleType + ";";
            content += "TRANS_TYPE:=" + TransType + ";";
            content += "VEHICLE_NATIONALIT:=" + VehicleAddress + ";";
            content += "OWERS_ID:=" + OwnerID + ";";
            content += "OWERS_NAME:=" + OwnerName + ";";
            content += "OWERS_ORIG_ID:=1008;";
            content += "OWERS_TEL:=" + OwnerPhone + ""; 
            byte[] btsContent = System.Text.Encoding.GetEncoding("gbk").GetBytes(content);
            //后续数据长度(4)：
            int Len =  btsContent.Length;
            byteList.Add((byte)(Len >> 24));
            byteList.Add((byte)((Len & 0x00ff0000) >> 16));
            byteList.Add((byte)((Len & 0x0000ff00) >> 8));
            byteList.Add((byte)((Len & 0x000000ff)));

          
            //内容(N)
            for (int i = 0; i < btsContent.Length; i++)
            {
                byteList.Add(btsContent[i]);
            }

            int TotalCount = byteList.Count + 3;//校验和+结尾符占三位

            byteList[1] = (byte)(TotalCount >> 24);
            byteList[2] = (byte)((TotalCount & 0x00ff0000) >> 16);
            byteList[3] = (byte)((TotalCount & 0x0000ff00) >> 8);
            byteList[4] = (byte)((TotalCount & 0x000000ff));

            if (m_needEncrypt)
            {
                encryptList(byteList);
            }
            //CRC校验：===============================================================
            //校验(2)
            UInt16 crc = (UInt16)(crc_hb(byteList.ToArray()) & 0xFFFF);
            byteList.Add((byte)(crc >> 8));
            byteList.Add((byte)(crc & 0xFF));
            //尾标识：===============================================================
            //尾(1)
            byteList.Add(0x5D);
            byte[] bts = byteList.ToArray();
            return HandlePackageEscape(bts);
        }
        /// <summary>
        /// 制造查岗应答数据
        /// </summary>
        /// <param name="kind"></param>
        /// <param name="objectID"></param>
        /// <param name="infoID"></param>
        /// <param name="content"></param>
        /// <returns></returns>
        public byte[] MakePlatFormQueryAnswer(byte kind,string objectID,uint infoID,string content)
        {
            List<byte> byteList = new List<byte>();
            //头：===============================================================
            //头(1)
            byteList.Add(0x5B);//头
            //数据头：===============================================================
            //数据长度(4)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文序号(4)
            byteList.Add((byte)(m_SequnceID >> 24));
            byteList.Add((byte)((m_SequnceID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_SequnceID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_SequnceID & 0x000000ff)));
            m_SequnceID = m_SequnceID + 1 > 0xfffffff0 ? 0 : m_SequnceID + 1;
            //业务数据类型(4)

            uint cmd = UP_PLATFORM_MSG;

            byteList.Add((byte)(cmd >> 8));
            byteList.Add((byte)(cmd & 0xff));

            //下级平台接入码(4)
            byteList.Add((byte)(m_UserID >> 24));
            byteList.Add((byte)((m_UserID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_UserID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_UserID & 0x000000ff)));

            //协议版本号(3)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            if (m_needEncrypt)
            {
                byteList.Add(0x01);
            }
            else
            {
                byteList.Add(0x00);
            }
            //加密密钥(4)
            byteList.Add((byte)(m_key >> 24));
            byteList.Add((byte)((m_key & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_key & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_key & 0x000000ff)));

            //数据体：===============================================================
            UInt16 ChildCmd = UP_PLATFORM_MSG_POST_QUERY_ACK;
            byteList.Add((byte)(ChildCmd >> 8));
            byteList.Add((byte)(ChildCmd & 0xff));

            byte[] btsContent = System.Text.Encoding.GetEncoding("gbk").GetBytes(content);
            //后续数据长度(4)：
            int Len = 21 + btsContent.Length;
            byteList.Add((byte)(Len >> 24));
            byteList.Add((byte)((Len & 0x00ff0000) >> 16));
            byteList.Add((byte)((Len & 0x0000ff00) >> 8));
            byteList.Add((byte)((Len & 0x000000ff)));

            //查岗类型（1）
            byteList.Add(kind);
            //ID（12）
            for (int i = 0; i < 12;i++ )
            {
                if (i >= objectID.Length)
                {
                    byteList.Add(0);

                }
                else
                {
                    byteList.Add((byte)objectID[i]);

                }
            }
            //INFO id(4)
            byteList.Add((byte)(infoID >> 24));
            byteList.Add((byte)((infoID & 0x00ff0000) >> 16));
            byteList.Add((byte)((infoID & 0x0000ff00) >> 8));
            byteList.Add((byte)((infoID & 0x000000ff)));
            //信息长度(4)

            byteList.Add((byte)(btsContent.Length >> 24));
            byteList.Add((byte)((btsContent.Length & 0x00ff0000) >> 16));
            byteList.Add((byte)((btsContent.Length & 0x0000ff00) >> 8));
            byteList.Add((byte)((btsContent.Length & 0x000000ff)));
            //内容(N)
            for (int i = 0; i < btsContent.Length; i++)
            {
                byteList.Add(btsContent[i]);
            }
           
            int TotalCount = byteList.Count + 3;//校验和+结尾符占三位

            byteList[1] = (byte)(TotalCount >> 24);
            byteList[2] = (byte)((TotalCount & 0x00ff0000) >> 16);
            byteList[3] = (byte)((TotalCount & 0x0000ff00) >> 8);
            byteList[4] = (byte)((TotalCount & 0x000000ff));

            if (m_needEncrypt)
            {
                encryptList(byteList);
            }
            //CRC校验：===============================================================
            //校验(2)
            UInt16 crc = (UInt16)(crc_hb(byteList.ToArray()) & 0xFFFF);
            byteList.Add((byte)(crc >> 8));
            byteList.Add((byte)(crc & 0xFF));
            //尾标识：===============================================================
            //尾(1)
            byteList.Add(0x5D);
            byte[] bts = byteList.ToArray();
            return HandlePackageEscape(bts);
        }
        /// <summary>
        /// 制造平台报文应答数据
        /// </summary>
        /// <param name="infoID"></param>
        /// <returns></returns>
        public byte[] MakePlatFormMsgAnswer(uint infoID)
        {
            List<byte> byteList = new List<byte>();
            //头：===============================================================
            //头(1)
            byteList.Add(0x5B);//头
            //数据头：===============================================================
            //数据长度(4)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文序号(4)
            byteList.Add((byte)(m_SequnceID >> 24));
            byteList.Add((byte)((m_SequnceID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_SequnceID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_SequnceID & 0x000000ff)));
            m_SequnceID = m_SequnceID + 1 > 0xfffffff0 ? 0 : m_SequnceID + 1;
            //业务数据类型(4)

            uint cmd = UP_PLATFORM_MSG;

            byteList.Add((byte)(cmd >> 8));
            byteList.Add((byte)(cmd & 0xff));

            //下级平台接入码(4)
            byteList.Add((byte)(m_UserID >> 24));
            byteList.Add((byte)((m_UserID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_UserID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_UserID & 0x000000ff)));

            //协议版本号(3)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文加密与否(1)
            if (m_needEncrypt)
            {
                byteList.Add(0x01);
            }
            else
            {
                byteList.Add(0x00);
            }
            //加密密钥(4)
            byteList.Add((byte)(m_key >> 24));
            byteList.Add((byte)((m_key & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_key & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_key & 0x000000ff)));

            //数据体：===============================================================
            UInt16 ChildCmd = UP_PLATFORM_MSG_INFO_ACK;
            byteList.Add((byte)(ChildCmd >> 8));
            byteList.Add((byte)(ChildCmd & 0xff));
 
            //后续数据长度(4)：
            int Len = 4;
            byteList.Add((byte)(Len >> 24));
            byteList.Add((byte)((Len & 0x00ff0000) >> 16));
            byteList.Add((byte)((Len & 0x0000ff00) >> 8));
            byteList.Add((byte)((Len & 0x000000ff)));

            
            //INFO id(4)
            byteList.Add((byte)(infoID >> 24));
            byteList.Add((byte)((infoID & 0x00ff0000) >> 16));
            byteList.Add((byte)((infoID & 0x0000ff00) >> 8));
            byteList.Add((byte)((infoID & 0x000000ff)));
           
            int TotalCount = byteList.Count + 3;//校验和+结尾符占三位

            byteList[1] = (byte)(TotalCount >> 24);
            byteList[2] = (byte)((TotalCount & 0x00ff0000) >> 16);
            byteList[3] = (byte)((TotalCount & 0x0000ff00) >> 8);
            byteList[4] = (byte)((TotalCount & 0x000000ff));

            if (m_needEncrypt)
            {
                encryptList(byteList);
            }
            //CRC校验：===============================================================
            //校验(2)
            UInt16 crc = (UInt16)(crc_hb(byteList.ToArray()) & 0xFFFF);
            byteList.Add((byte)(crc >> 8));
            byteList.Add((byte)(crc & 0xFF));
            //尾标识：===============================================================
            //尾(1)
            byteList.Add(0x5D);
            byte[] bts = byteList.ToArray();
            return HandlePackageEscape(bts);
        }
        /// <summary>
        /// 制造下级平台登录应答
        /// </summary>
        /// <param name="userID">下级平台ID</param>
        /// <returns></returns>
        public byte[] MakeConnectReqAnswer(uint userID,byte result)
        {
            List<byte> byteList = new List<byte>();
            //头：===============================================================
            //头(1)
            byteList.Add(0x5B);//头
            //数据头：===============================================================
            //数据长度(4)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文序号(4)
            byteList.Add((byte)(m_SequnceID >> 24));
            byteList.Add((byte)((m_SequnceID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_SequnceID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_SequnceID & 0x000000ff)));
            m_SequnceID = m_SequnceID + 1 > 0xfffffff0 ? 0 : m_SequnceID + 1;
            //业务数据类型(4)

            uint cmd = UP_CONNECT_RSP;

            byteList.Add((byte)(cmd >> 8));
            byteList.Add((byte)(cmd & 0xff));

            //下级平台接入码(4)
            byteList.Add((byte)(userID >> 24));
            byteList.Add((byte)((userID & 0x00ff0000) >> 16));
            byteList.Add((byte)((userID & 0x0000ff00) >> 8));
            byteList.Add((byte)((userID & 0x000000ff)));

            //协议版本号(3)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文加密与否(1)
            if (m_needEncrypt)
            {
                byteList.Add(0x01);
            }
            else
            {
                byteList.Add(0x00);
            }
            //加密密钥(4)
            byteList.Add((byte)(m_key >> 24));
            byteList.Add((byte)((m_key & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_key & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_key & 0x000000ff)));


            //数据体：===============================================================
            //登录结果：0
            byteList.Add(result);
             
            //验证码:
            byteList[1] = (byte)(VERIFY_CODE >> 24);
            byteList[2] = (byte)((VERIFY_CODE & 0x00ff0000) >> 16);
            byteList[3] = (byte)((VERIFY_CODE & 0x0000ff00) >> 8);
            byteList[4] = (byte)((VERIFY_CODE & 0x000000ff));

            int TotalCount = byteList.Count + 3;//校验和+结尾符占三位

            byteList[1] = (byte)(TotalCount >> 24);
            byteList[2] = (byte)((TotalCount & 0x00ff0000) >> 16);
            byteList[3] = (byte)((TotalCount & 0x0000ff00) >> 8);
            byteList[4] = (byte)((TotalCount & 0x000000ff));

            if (m_needEncrypt)
            {
                encryptList(byteList);
            }
            //CRC校验：===============================================================
            //校验(2)
            UInt16 crc = (UInt16)(crc_hb(byteList.ToArray()) & 0xFFFF);
            byteList.Add((byte)(crc >> 8));
            byteList.Add((byte)(crc & 0xFF));
            //尾标识：===============================================================
            //尾(1)
            byteList.Add(0x5D);
            byte[] bts = byteList.ToArray();
            return HandlePackageEscape(bts);
        }
        /// <summary>
        /// 制造下级平台测试链路应答
        /// </summary>
        /// <returns></returns>
        public byte[] MakeLinkTestAnswer()
        {
            uint userID = 12345678;//统一，简化 
            List<byte> byteList = new List<byte>();
            //头：===============================================================
            //头(1)
            byteList.Add(0x5B);//头
            //数据头：===============================================================
            //数据长度(4)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文序号(4)
            byteList.Add((byte)(m_SequnceID >> 24));
            byteList.Add((byte)((m_SequnceID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_SequnceID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_SequnceID & 0x000000ff)));
            m_SequnceID = m_SequnceID + 1 > 0xfffffff0 ? 0 : m_SequnceID + 1;
            //业务数据类型(4)

            uint cmd = DOWN_LINKTEST_RSP;

            byteList.Add((byte)(cmd >> 8));
            byteList.Add((byte)(cmd & 0xff));

            //下级平台接入码(4)
            byteList.Add((byte)(userID >> 24));
            byteList.Add((byte)((userID & 0x00ff0000) >> 16));
            byteList.Add((byte)((userID & 0x0000ff00) >> 8));
            byteList.Add((byte)((userID & 0x000000ff)));

            //协议版本号(3)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文加密与否(1)
             if (m_needEncrypt)
            {
                byteList.Add(0x01);
            }
            else
            {
                byteList.Add(0x00);
            }
            //加密密钥(4)
             byteList.Add((byte)(m_key >> 24));
             byteList.Add((byte)((m_key & 0x00ff0000) >> 16));
             byteList.Add((byte)((m_key & 0x0000ff00) >> 8));
             byteList.Add((byte)((m_key & 0x000000ff)));

            //数据体：空===============================================================
 

            int TotalCount = byteList.Count + 3;//校验和+结尾符占三位

            byteList[1] = (byte)(TotalCount >> 24);
            byteList[2] = (byte)((TotalCount & 0x00ff0000) >> 16);
            byteList[3] = (byte)((TotalCount & 0x0000ff00) >> 8);
            byteList[4] = (byte)((TotalCount & 0x000000ff));

            //
            
            if (m_needEncrypt)
            {
                encryptList(byteList);
            }
            //CRC校验：===============================================================
            //校验(2)
            UInt16 crc = (UInt16)(crc_hb(byteList.ToArray()) & 0xFFFF);
            byteList.Add((byte)(crc >> 8));
            byteList.Add((byte)(crc & 0xFF));
            //尾标识：===============================================================
            //尾(1)
            byteList.Add(0x5D);
            byte[] bts = byteList.ToArray();
            return HandlePackageEscape(bts);
        }
        #region 制造从链路的客户端请求消息（用于测试）
        /// <summary>
        /// 测试从链路连接状态
        /// </summary>
        /// <returns></returns>
        public byte[] MakeDownLinkTest()
        {
            List<byte> byteList = new List<byte>();
            //头：===============================================================
            //头(1)
            byteList.Add(0x5B);//头
            //数据头：===============================================================
            //数据长度(4)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文序号(4)
            byteList.Add((byte)(m_SequnceID >> 24));
            byteList.Add((byte)((m_SequnceID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_SequnceID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_SequnceID & 0x000000ff)));
            m_SequnceID = m_SequnceID + 1 > 0xfffffff0 ? 0 : m_SequnceID + 1;
            //业务数据类型(4)
            //
            uint cmd = DOWN_LINKTEST_REQ;

            byteList.Add((byte)(cmd >> 8));
            byteList.Add((byte)(cmd & 0xff));

            //平台接入码
            byteList.Add((byte)(m_UserID >> 24));
            byteList.Add((byte)((m_UserID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_UserID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_UserID & 0x000000ff)));

            //协议版本号(3)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            if (m_needEncrypt)
            {
                byteList.Add(0x01);
            }
            else
            {
                byteList.Add(0x00);
            }
            //加密密钥(4)
            byteList.Add((byte)(m_key >> 24));
            byteList.Add((byte)((m_key & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_key & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_key & 0x000000ff)));

            //数据体


            //重置总数据长度后续数据长度
            int TotalCount = byteList.Count + 3;//校验和+结尾符占三位

            byteList[1] = (byte)(TotalCount >> 24);
            byteList[2] = (byte)((TotalCount & 0x00ff0000) >> 16);
            byteList[3] = (byte)((TotalCount & 0x0000ff00) >> 8);
            byteList[4] = (byte)((TotalCount & 0x000000ff));

            //
            if (m_needEncrypt)
            {
                encryptList(byteList);
            }
            //CRC校验：===============================================================
            //校验(2)
            UInt16 crc = (UInt16)(crc_hb(byteList.ToArray()) & 0xFFFF);
            byteList.Add((byte)(crc >> 8));
            byteList.Add((byte)(crc & 0xFF));
            //尾标识：===============================================================
            //尾(1)
            byteList.Add(0x5D);
            byte[] bts = byteList.ToArray();
            return HandlePackageEscape(bts);
        }
        /// <summary>
        /// 制造从链路注销请求
        /// </summary>
        /// <returns></returns>
        public byte[] MakeDownLogout()
        {
            List<byte> byteList = new List<byte>();
            //头：===============================================================
            //头(1)
            byteList.Add(0x5B);//头
            //数据头：===============================================================
            //数据长度(4)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文序号(4)
            byteList.Add((byte)(m_SequnceID >> 24));
            byteList.Add((byte)((m_SequnceID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_SequnceID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_SequnceID & 0x000000ff)));
            m_SequnceID = m_SequnceID + 1 > 0xfffffff0 ? 0 : m_SequnceID + 1;
            //业务数据类型(4)
            //
            uint cmd = DOWN_DISCONNECT_REQ;

            byteList.Add((byte)(cmd >> 8));
            byteList.Add((byte)(cmd & 0xff));

            //平台接入码
            byteList.Add((byte)(m_UserID >> 24));
            byteList.Add((byte)((m_UserID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_UserID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_UserID & 0x000000ff)));

            //协议版本号(3)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            if (m_needEncrypt)
            {
                byteList.Add(0x01);
            }
            else
            {
                byteList.Add(0x00);
            }
            //加密密钥(4)
            byteList.Add((byte)(m_key >> 24));
            byteList.Add((byte)((m_key & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_key & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_key & 0x000000ff)));

            //验证码（4） 
            byteList.Add((byte)(VERIFY_CODE >>24));
            byteList.Add((byte)((VERIFY_CODE >> 16) & 0xff));
            byteList.Add((byte)((VERIFY_CODE >> 8))&0xff);
            byteList.Add((byte)(VERIFY_CODE &0xff ));

            //重置总数据长度后续数据长度
            int TotalCount = byteList.Count + 3;//校验和+结尾符占三位

            byteList[1] = (byte)(TotalCount >> 24);
            byteList[2] = (byte)((TotalCount & 0x00ff0000) >> 16);
            byteList[3] = (byte)((TotalCount & 0x0000ff00) >> 8);
            byteList[4] = (byte)((TotalCount & 0x000000ff));

            //
            if (m_needEncrypt)
            {
                encryptList(byteList);
            }
            //CRC校验：===============================================================
            //校验(2)
            UInt16 crc = (UInt16)(crc_hb(byteList.ToArray()) & 0xFFFF);
            byteList.Add((byte)(crc >> 8));
            byteList.Add((byte)(crc & 0xFF));
            //尾标识：===============================================================
            //尾(1)
            byteList.Add(0x5D);
            byte[] bts = byteList.ToArray();
            return HandlePackageEscape(bts);
        }
        public byte[] MakeMsgStartupReq(string VehicleNo, byte VehicleColor,byte reason)
        {
            List<byte> byteList = new List<byte>();
            //头：===============================================================
            //头(1)
            byteList.Add(0x5B);//头
            //数据头：===============================================================
            //数据长度(4)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文序号(4)
            byteList.Add((byte)(m_SequnceID >> 24));
            byteList.Add((byte)((m_SequnceID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_SequnceID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_SequnceID & 0x000000ff)));
            m_SequnceID = m_SequnceID + 1 > 0xfffffff0 ? 0 : m_SequnceID + 1;
            //业务数据类型(4)
            //
            uint cmd = DOWN_EXG_MSG ;

            byteList.Add((byte)(cmd >> 8));
            byteList.Add((byte)(cmd & 0xff));

            //下级平台接入码(4)
            byteList.Add((byte)(m_UserID >> 24));
            byteList.Add((byte)((m_UserID & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_UserID & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_UserID & 0x000000ff)));

            //协议版本号(3)
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //报文加密与否(1)
            if (m_needEncrypt)
            {
                byteList.Add(0x01);
            }
            else
            {
                byteList.Add(0x00);
            }
            //加密密钥(4)
            byteList.Add((byte)(m_key >> 24));
            byteList.Add((byte)((m_key & 0x00ff0000) >> 16));
            byteList.Add((byte)((m_key & 0x0000ff00) >> 8));
            byteList.Add((byte)((m_key & 0x000000ff)));

            //数据体：===============================================================
            //车牌(21)
            byte[] vehBytes = System.Text.Encoding.GetEncoding("gbk").GetBytes(VehicleNo);

            for (int i = 0; i < 21; i++)
            {
                if (i > vehBytes.Length - 1)
                {
                    byteList.Add(0);
                }
                else
                {
                    byteList.Add(vehBytes[i]);
                }
            }
            //车牌颜色(1)
            byteList.Add(VehicleColor);
            //子业务标识(2)：
            UInt16 ChildCmd = DOWN_EXG_MSG_RETURN_STARTUP;
            byteList.Add((byte)(ChildCmd >> 8));
            byteList.Add((byte)(ChildCmd & 0xff));

            //后续数据长度(4)：
            int Len = 1;
            byteList.Add((byte)(Len >> 24));
            byteList.Add((byte)((Len & 0x00ff0000) >> 16));
            byteList.Add((byte)((Len & 0x0000ff00) >> 8));
            byteList.Add((byte)((Len & 0x000000ff)));
            //原因(1)
            byteList.Add( reason);


            //重置总数据长度后续数据长度
            int TotalCount = byteList.Count + 3;//校验和+结尾符占三位

            byteList[1] = (byte)(TotalCount >> 24);
            byteList[2] = (byte)((TotalCount & 0x00ff0000) >> 16);
            byteList[3] = (byte)((TotalCount & 0x0000ff00) >> 8);
            byteList[4] = (byte)((TotalCount & 0x000000ff));

            if (m_needEncrypt)
            {
                encryptList(byteList);
            }
            //
            //CRC校验：===============================================================
            //校验(2)
            UInt16 crc = (UInt16)(crc_hb(byteList.ToArray()) & 0xFFFF);
            byteList.Add((byte)(crc >> 8));
            byteList.Add((byte)(crc & 0xFF));
            //尾标识：===============================================================
            //尾(1)
            byteList.Add(0x5D);
            byte[] bts = byteList.ToArray();
            return HandlePackageEscape(bts);
        }
        #endregion
        private double DateTimeToUTC(DateTime vDate)
        {
            vDate = vDate.ToUniversalTime();
            DateTime dtZone = new DateTime(1970, 1, 1, 0, 0, 0);
            return vDate.Subtract(dtZone).TotalSeconds;
        }
        private DateTime UTCToDateTime(double l)
        {
            DateTime dtZone = new DateTime(1970, 1, 1, 0, 0, 0);
            dtZone = dtZone.AddSeconds(l);
            return dtZone.ToLocalTime();
        }
        public override AbstractMessageHandle NewInstance() {
            HZMessageHandle ret = new HZMessageHandle();
            ret.OnLoginResult += this.OnLoginResult;
            ret.OnReqBaseInfo += this.OnReqBaseInfo;
            return ret;
        }
        /// <summary>
        /// 从第23个元素开始加密
        /// </summary>
        /// <param name="source"></param>
        private void encryptList(List<byte> source) {
          
            Int32 idx = 23;
            uint tempKey = m_key;
            if (0 == tempKey)
            {
                tempKey = 1;
            }
              
            //
            while (idx < source.Count)
            {
                tempKey = m_IA1 * (tempKey % m_M1) + m_IC1;
                int src =(int) source[idx];
                src ^= (Byte)((tempKey >> 20) & 0xFF);
                source[idx++] =(byte) src;
            }
        }
        /// <summary>
        /// 针对一个完整的数据包的加、解密
        /// </summary>
        /// <param name="source"></param>
        /// <param name="key"></param>
        private void encryptArray(byte[] source,uint key)
        {
            Int32 idx = 23;
            uint tempKey = key;
            if (0 == tempKey)
            {
                tempKey = 1;
            }

            while (idx < source.Length-3)
            {
                tempKey = m_IA1 * (tempKey % m_M1) + m_IC1;
                int src = (int)source[idx];
                src ^= (Byte)((tempKey >> 20) & 0xFF);
                source[idx++] = (byte)src;
            }
        }
        /// <summary>
        /// 去除字符串末尾的0
        /// </summary>
        /// <param name="source"></param>
        /// <returns></returns>
        private string getNoneZeroString(string source) {
            string retStr = source;
            while (retStr.Length>0 && retStr[retStr.Length - 1] == '\0')
            {
                retStr = retStr.Substring(0, retStr.Length - 1);
            }
            return retStr;
        }
    }
}
