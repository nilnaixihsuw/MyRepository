﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net.Sockets;
using System.Net;

namespace trsocket
{
    public class TRUdpClient
    {
        string m_ServerIP;
        UInt16 m_ServerPort;
        UdpClient m_ClientSock;
        public TRUdpClient(string ip,UInt16 port) {
             m_ServerIP = ip;
             m_ServerPort = port;
             
        }

        public void SendMessage(Byte[] btInfo)
        {

            try
            {
                m_ClientSock.Send(btInfo, btInfo.Length);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        
        }
        public void StartUp()
        {
           
            m_ClientSock = new UdpClient(m_ServerIP, this.m_ServerPort);
        }
        public void ShutDown() {
            CommonFunc.LogError("ShutDown:" );
            m_ClientSock.Close();
        }

        public void GetMessage()
        {
            UdpClient clientGetMsg = new UdpClient(11801);//this.port我们指定的端口号


            //用于保存远程计算机ip和端口信息（保存客人从哪里来的信息）
            IPEndPoint remoteEP = new IPEndPoint(IPAddress.Any, 0);

            byte[] btInfo;

            while (true)
            {
                try
                {
                    //接收信息
                    btInfo =   clientGetMsg.Receive(ref remoteEP);
                }
                catch (Exception)
                {
                    //MessageBox.Show("error at receiving msg:\n" + ex.Message);
                    return;
                }

                //将得到的数据进行处理，我们这里是将它转成字符串
                string msg = Encoding.Default.GetString(btInfo);
                //
                //do something else
                //

            }
        }


    }
}
