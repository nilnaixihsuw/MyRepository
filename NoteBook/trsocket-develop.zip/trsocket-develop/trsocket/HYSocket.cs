﻿using System;
using System.Collections.Generic;
using System.Text;
namespace trsocket
{
    public class HYSocket
    {
        private uint m_UserID;
        private string m_PassWord;
       private TRServerSocket m_ServerSock;
        private TRClientSocket m_ClientSock;
        private bool m_bAutoLogin = true;
        SQMessageHandle m_ServerMsgHandle = new SQMessageHandle();
        private bool m_bStarted = false;
        ushort m_LocalPort = 0;
        string m_LocalIP;

        public GPSDataHandle OnGPSData
        {
            get { return m_ServerMsgHandle.OnGPSData; }
            set { m_ServerMsgHandle.OnGPSData = value; }
        }
        public DataArriveHandle OnDataArrive
        {
            get { return m_ServerMsgHandle.OnDataArrive; }
            set { m_ServerMsgHandle.OnDataArrive = value; }
        }
        public HYSocket(string IP, int Port, uint UserID, string PassWord, string LocalIP, ushort LocalPort)
        {
            m_LocalIP = LocalIP;
            m_LocalPort = LocalPort;
           
            
            m_UserID=UserID;
            m_PassWord=PassWord;

           
            m_ClientSock = new TRClientSocket(IP, Port, false, m_ServerMsgHandle);
            m_ClientSock.SetRecvTimeOut(30);
            m_ClientSock.OnClosedHandle += OnSocketClosed;
            m_ClientSock.OnConnectHandle += OnSocketConnect;
        }

        private void OnSocketConnect(bool success)
        {
            System.Console.Out.WriteLine("HZSocket连接：" + success.ToString());
            if (success)
            {
                if (this.m_bAutoLogin)
                {
                    SendDataRequest();
                }
            }
        }
        private void OnSocketClosed()
        {
            System.Console.Out.WriteLine("sqSocket关闭：");

        }
        public void SendDataRequest()
        {
            byte[] byteSend = m_ServerMsgHandle.MakeReqestGpsData();
            m_ClientSock.SendMsg(byteSend);

        }
      
        public void StartServer(ushort Port) {

            if (Port == 0)
            {
                throw new Exception("未指定端口！");
            }
            
            if (m_bStarted) {
                StopServer();
            }
            m_ServerSock = new TRServerSocket();
   
            m_ServerMsgHandle.OnDataArrive += this.OnDataArrive;

            m_ServerSock.StartListen(Port, m_ServerMsgHandle);
            m_bStarted = true;
        }
        public void StopServer()
        {
            if (!m_bStarted)
            {
                return;
            }
            m_ServerSock.StopListen();
            m_bStarted = false;
        }
        
        
         

    }
}
