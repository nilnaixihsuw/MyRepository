﻿using System;
using System.Collections.Generic;
using System.Text;

namespace trsocket
{
    class JXYGMessageHandle : AbstractMessageHandle
    {
        public LoginResultHandle OnLoginResult;

      
      
        public JXYGMessageHandle( )
        { 
           
        }
        protected override bool Analyze(ClientInfo info)
        {
            int thisPackageSize = 0;
            byte[] totalBuf = this.GetBuffer(info);
            if (totalBuf.Length < 10)
            {
                return false;
            }
            int datasize = (totalBuf[6] <<8)+ totalBuf[7];
            thisPackageSize =datasize+ 10;//此包的总长度

            if (totalBuf.Length < thisPackageSize)
            {
                return false;
            }
         
            if (totalBuf[0] != 0x40)
            {
                goto lastrow;
            }

            


            
            byte[] packBuf = new byte[thisPackageSize];
            Array.Copy(totalBuf, 0, packBuf, 0, thisPackageSize);
            try
            {
                this.HandlePackage(info, packBuf);
            }
            catch
            {

            }
            this.RemoveLeftData(info, thisPackageSize);
            return true;
          
        //非法数据包，发通知
        lastrow:
            this.OnAnalyzeWrong(info);
            return false;
        }
        /// <summary>
        /// 处理整个包的反转义
        /// </summary>
        /// <param name="package">一个完整的数据包</param>
        /// <returns>反转义后的数据完整包</returns>
        private byte[] HandlePackageReEscape(byte[] package)
        {
            return package;
            if (package.Length < 10)
            {
                throw new Exception("数据包太短！");
            }
            if (package[0] != 0x5B || package[package.Length - 1] != 0x5D)
            {
                throw new Exception("非法的数据包！");
            }
            LinkedList<byte> bt = new LinkedList<byte>();
            int i = 0;
            while (i < package.Length)
            {
                bool escape = false;
                if (i != 0 && i != package.Length - 1 && i + 1 < package.Length - 1)
                {
                    if (package[i] == 0x5A)
                    {

                        if (package[i + 1] == 0x01)
                        {
                            bt.AddLast(0x5B);
                            i += 2;
                            escape = true;
                        }
                        else if (package[i + 1] == 0x02)
                        {
                            bt.AddLast(0x5A);
                            i += 2;
                            escape = true;
                        }
                    }
                    if (package[i] == 0x5E)
                    {

                        if (package[i + 1] == 0x01)
                        {
                            bt.AddLast(0x5D);
                            i += 2;
                            escape = true;
                        }
                        else if (package[i + 1] == 0x02)
                        {
                            bt.AddLast(0x5E);
                            i += 2;
                            escape = true;
                        }
                    }
                }
                if (!escape)
                {
                    bt.AddLast(package[i]);
                    i += 1;
                }

            }
            byte[] retBuff = new byte[bt.Count];
            bt.CopyTo(retBuff, 0);
            return retBuff;
        }
        private byte[] HandlePackageEscape(byte[] package)
        {
            return package;
          
         
        }
        public void HandlePackage(ClientInfo info, byte[] package)
        {
            if (package.Length < 10)
            {
                throw new Exception("数据包太短！");
            }
            if (package[0] != 0x40 || package[package.Length - 1] != 0x0d)
            {
                throw new Exception("非法的数据包！");
            }
            //转义处理：
            byte[] retBuff = HandlePackageReEscape(package);

            //===============================临时
            string debugString = "";
            //for (int i = 0; i < package.Length; i++)
            //{
            //    string hexOutput = String.Format("{0:X}", package[i]);
            //    if (hexOutput.Length < 2)
            //    {
            //        hexOutput = "0" + hexOutput;
            //    }
            //    debugString += " " + hexOutput;
            //}
           // System.Console.Out.WriteLine("接收到：" + debugString);
            //===============================结束临时
            //提出命令字：

            UInt16 childCmd;
             
            
            string cm1=Convert.ToString(Convert.ToChar(retBuff[4]));
            string cm2 = Convert.ToString(Convert.ToChar(retBuff[5]));
            string strCMD = cm1 + cm2;
            
 


            switch (strCMD)
            {
                case "C0":
                    //byte Result = retBuff[23];
                    //uint VeryfyCode = (uint)((retBuff[24] << 24) + (retBuff[25] << 16) + (retBuff[26] << 8) + retBuff[27]);
                    //if (this.OnLoginResult != null)
                    //{
                        OnLoginResult(1, 1);
                    //}
                    break;

               
                        default:
                            System.Console.Out.WriteLine("未知命令！" + strCMD);

                            throw new Exception("未知命令！" + strCMD);
 


                    break;
                /////============================DOWN结束=========================
             }

        }

       
       

              
        public override AbstractMessageHandle NewInstance()
        {
            JXYGMessageHandle ret = new JXYGMessageHandle( );
         
            return ret;
        }
        public byte[]   MakeLineVehileInfoData  (string LineVehicleInfos)
        {
            byte[] infoBytes = System.Text.Encoding.GetEncoding("UTF-8").GetBytes(LineVehicleInfos); 
           // 消息长度|01|号牌号码,车牌颜色,线路编号|……|号牌号码,车牌颜色,线路编号|
            uint infoLen = (uint)infoBytes.GetLength(0);
            string hexLenStr = Convert.ToString(infoLen, 16);
            while (hexLenStr.Length < 8) {
                hexLenStr = "0" + hexLenStr;
            }
            string headStr = hexLenStr;
            headStr = headStr + "|" + "01" + "|";
            byte[] headBytes = System.Text.Encoding.GetEncoding("UTF-8").GetBytes(headStr);
            byte[] totalBytes = new byte[infoBytes.Length + headBytes.Length];
            Array.Copy(headBytes, totalBytes, headBytes.Length);
            Array.Copy(infoBytes, 0, totalBytes, headBytes.Length, infoBytes.Length);

            return totalBytes;
            
          
            
        }
        /// <summary>
        /// 编制线路基本信息数据包
        /// </summary>
        /// <param name="LineInfos"></param>
        /// <returns></returns>
        public byte[] MakeLineInfoData(string LineInfos)
        {
            byte[] infoBytes = System.Text.Encoding.GetEncoding("UTF-8").GetBytes(LineInfos);
            // 消息长度|01|号牌号码,车牌颜色,线路编号|……|号牌号码,车牌颜色,线路编号|
            uint infoLen = (uint)infoBytes.GetLength(0);
            string hexLenStr = Convert.ToString(infoLen, 16);
            while (hexLenStr.Length < 8)
            {
                hexLenStr = "0" + hexLenStr;
            }
            string headStr = hexLenStr;
            headStr = headStr + "|" + "02" + "|";
            byte[] headBytes = System.Text.Encoding.GetEncoding("UTF-8").GetBytes(headStr);
            byte[] totalBytes = new byte[infoBytes.Length + headBytes.Length];
            Array.Copy(headBytes, totalBytes, headBytes.Length);
            Array.Copy(infoBytes, 0, totalBytes, headBytes.Length, infoBytes.Length);

            return totalBytes;



        }
        /// <summary>
        /// 编制站点信息数据包
        /// </summary>
        /// <param name="StationInfos">站点数据</param>
        /// <returns></returns>
        public byte[] MakeStationInfoData(string StationInfos)
        {
            byte[] infoBytes = System.Text.Encoding.GetEncoding("UTF-8").GetBytes(StationInfos);
            // 消息长度|01|号牌号码,车牌颜色,线路编号|……|号牌号码,车牌颜色,线路编号|
            uint infoLen = (uint)infoBytes.GetLength(0);
            string hexLenStr = Convert.ToString(infoLen, 16);
            while (hexLenStr.Length < 8)
            {
                hexLenStr = "0" + hexLenStr;
            }
            string headStr = hexLenStr;
            headStr = headStr + "|" + "03" + "|";
            byte[] headBytes = System.Text.Encoding.GetEncoding("UTF-8").GetBytes(headStr);
            byte[] totalBytes = new byte[infoBytes.Length + headBytes.Length];
            Array.Copy(headBytes, totalBytes, headBytes.Length);
            Array.Copy(infoBytes, 0, totalBytes, headBytes.Length, infoBytes.Length);

            return totalBytes;



        }
        /// <summary>
        /// 编制线路站点信息
        /// </summary>
        /// <param name="LineStationInfos"></param>
        /// <returns></returns>
        public byte[] MakeLineStationInfoData(string LineStationInfos)
        {
            byte[] infoBytes = System.Text.Encoding.GetEncoding("UTF-8").GetBytes(LineStationInfos);
            // 消息长度|01|号牌号码,车牌颜色,线路编号|……|号牌号码,车牌颜色,线路编号|
            uint infoLen = (uint)infoBytes.GetLength(0);
            string hexLenStr = Convert.ToString(infoLen, 16);
            while (hexLenStr.Length < 8)
            {
                hexLenStr = "0" + hexLenStr;
            }
            string headStr = hexLenStr;
            headStr = headStr + "|" + "04" + "|";
            byte[] headBytes = System.Text.Encoding.GetEncoding("UTF-8").GetBytes(headStr);
            byte[] totalBytes = new byte[infoBytes.Length + headBytes.Length];
            Array.Copy(headBytes, totalBytes, headBytes.Length);
            Array.Copy(infoBytes, 0, totalBytes, headBytes.Length, infoBytes.Length);

            return totalBytes;



        }
        public byte[] MakeLineAnchorInfoData(string LineAnchorInfos)
        {
            byte[] infoBytes = System.Text.Encoding.GetEncoding("UTF-8").GetBytes(LineAnchorInfos);
            // 消息长度|01|号牌号码,车牌颜色,线路编号|……|号牌号码,车牌颜色,线路编号|
            uint infoLen = (uint)infoBytes.GetLength(0);
            string hexLenStr = Convert.ToString(infoLen, 16);
            while (hexLenStr.Length < 8)
            {
                hexLenStr = "0" + hexLenStr;
            }
            string headStr = hexLenStr;
            headStr = headStr + "|" + "05" + "|";
            byte[] headBytes = System.Text.Encoding.GetEncoding("UTF-8").GetBytes(headStr);
            byte[] totalBytes = new byte[infoBytes.Length + headBytes.Length];
            Array.Copy(headBytes, totalBytes, headBytes.Length);
            Array.Copy(infoBytes, 0, totalBytes, headBytes.Length, infoBytes.Length);

            return totalBytes;



        }
        public byte[] MakeDispatchInfoData(string DispatchInfos)
        {
            byte[] infoBytes = System.Text.Encoding.GetEncoding("UTF-8").GetBytes(DispatchInfos);
            // 消息长度|01|号牌号码,车牌颜色,线路编号|……|号牌号码,车牌颜色,线路编号|
            uint infoLen = (uint)infoBytes.GetLength(0);
            string hexLenStr = Convert.ToString(infoLen, 16);
            while (hexLenStr.Length < 8)
            {
                hexLenStr = "0" + hexLenStr;
            }
            string headStr = hexLenStr;
            headStr = headStr + "|" + "21" + "|";
            byte[] headBytes = System.Text.Encoding.GetEncoding("UTF-8").GetBytes(headStr);
            byte[] totalBytes = new byte[infoBytes.Length + headBytes.Length];
            Array.Copy(headBytes, totalBytes, headBytes.Length);
            Array.Copy(infoBytes, 0, totalBytes, headBytes.Length, infoBytes.Length);

            return totalBytes;



        }
        public byte[] MakeDispatchInfoData_Temp(string DispatchInfos)
        {
            byte[] infoBytes = System.Text.Encoding.GetEncoding("UTF-8").GetBytes(DispatchInfos);
            // 消息长度|01|号牌号码,车牌颜色,线路编号|……|号牌号码,车牌颜色,线路编号|
            uint infoLen = (uint)infoBytes.GetLength(0);
            string hexLenStr = Convert.ToString(infoLen, 16);
            while (hexLenStr.Length < 8)
            {
                hexLenStr = "0" + hexLenStr;
            }
            string headStr = hexLenStr;
            headStr = headStr + "|" + "22" + "|";
            byte[] headBytes = System.Text.Encoding.GetEncoding("UTF-8").GetBytes(headStr);
            byte[] totalBytes = new byte[infoBytes.Length + headBytes.Length];
            Array.Copy(headBytes, totalBytes, headBytes.Length);
            Array.Copy(infoBytes, 0, totalBytes, headBytes.Length, infoBytes.Length);

            return totalBytes;



        }
         public byte[] MakeLogin()
         {

             List<byte> byteList = new List<byte>();
          
             //起始符
             byteList.Add(0x40);

             //终端ID
            
             //43 31 : 指令 C1
             byteList.Add(0x43);
             byteList.Add(0x31);
             //数据内容长度
             byteList.Add(0x00);
             byteList.Add(0x08);


             //31 30 30 30 : 用户名
             byteList.Add(0x31);//
             byteList.Add(0x30);// 
             byteList.Add(0x30);// 
             byteList.Add(0x30);// 

             //31 32 33 34 : 密码
             byteList.Add(0x31);//
             byteList.Add(0x32);// 
             byteList.Add(0x33);// 
             byteList.Add(0x34);// 

             int sum = 0;
             for (int i = 0; i < byteList.Count; i++)
             {
                 sum += byteList[i];
             }
             sum = sum & 0xff;
             sum = 0x100 - sum;

             byteList.Add((byte)sum);// 
             byteList.Add(0x0d);// 

              

             return byteList.ToArray();
         }
    }
}
