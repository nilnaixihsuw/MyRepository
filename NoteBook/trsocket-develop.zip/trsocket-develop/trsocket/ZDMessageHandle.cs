﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace trsocket
{
    class ZDMessageHandle : AbstractMessageHandle
    {

        public LoginResultHandle OnLoginResult;

        private uint m_SequnceID = 0;//报文ID
        private uint m_TermNo;
        public ZDMessageHandle(uint TermNo)
        { 
            m_TermNo=TermNo;
        }
        protected override bool Analyze(ClientInfo info)
        {
            int thisPackageSize = 0;
            byte[] totalBuf = this.GetBuffer(info);
            if (totalBuf.Length < 10)
            {
                return false;
            }
            int datasize = (totalBuf[6] <<8)+ totalBuf[7];
            thisPackageSize =datasize+ 10;//此包的总长度

            if (totalBuf.Length < thisPackageSize)
            {
                return false;
            }
         
            if (totalBuf[0] != 0x40)
            {
                goto lastrow;
            }

            uint test = 5646;
            byte first = (byte)((test & 0xff000000) >> 24);
            byte sec = (byte)((test & 0x00ff0000) >> 16);




            byte[] packBuf = new byte[thisPackageSize];
            Array.Copy(totalBuf, 0, packBuf, 0, thisPackageSize);
            try
            {
                this.HandlePackage(info, packBuf);
            }
            catch
            {

            }
            this.RemoveLeftData(info, thisPackageSize);
            return true;
          
        //非法数据包，发通知
        lastrow:
            this.OnAnalyzeWrong(info);
            return false;
        }
        /// <summary>
        /// 处理整个包的反转义
        /// </summary>
        /// <param name="package">一个完整的数据包</param>
        /// <returns>反转义后的数据完整包</returns>
        private byte[] HandlePackageReEscape(byte[] package)
        {
            return package;
            if (package.Length < 10)
            {
                throw new Exception("数据包太短！");
            }
            if (package[0] != 0x5B || package[package.Length - 1] != 0x5D)
            {
                throw new Exception("非法的数据包！");
            }
            LinkedList<byte> bt = new LinkedList<byte>();
            int i = 0;
            while (i < package.Length)
            {
                bool escape = false;
                if (i != 0 && i != package.Length - 1 && i + 1 < package.Length - 1)
                {
                    if (package[i] == 0x5A)
                    {

                        if (package[i + 1] == 0x01)
                        {
                            bt.AddLast(0x5B);
                            i += 2;
                            escape = true;
                        }
                        else if (package[i + 1] == 0x02)
                        {
                            bt.AddLast(0x5A);
                            i += 2;
                            escape = true;
                        }
                    }
                    if (package[i] == 0x5E)
                    {

                        if (package[i + 1] == 0x01)
                        {
                            bt.AddLast(0x5D);
                            i += 2;
                            escape = true;
                        }
                        else if (package[i + 1] == 0x02)
                        {
                            bt.AddLast(0x5E);
                            i += 2;
                            escape = true;
                        }
                    }
                }
                if (!escape)
                {
                    bt.AddLast(package[i]);
                    i += 1;
                }

            }
            byte[] retBuff = new byte[bt.Count];
            bt.CopyTo(retBuff, 0);
            return retBuff;
        }
        private byte[] HandlePackageEscape(byte[] package)
        {
            return package;
            m_SequnceID++;
            if (m_SequnceID > UInt32.MaxValue - 10)
            {
                m_SequnceID = 0;
            }
            if (package.Length < 10)
            {
                throw new Exception("数据包太短！");
            }
            if (package[0] != 0x5B || package[package.Length - 1] != 0x5D)
            {
                throw new Exception("非法的数据包！");
            }
            LinkedList<byte> bt = new LinkedList<byte>();

            for (int i = 0; i < package.Length; i++)
            {
                if (i != 0 && i != package.Length - 1)
                {
                    if (package[i] == 0x5A)
                    {
                        bt.AddLast(0x5A);
                        bt.AddLast(0x02);

                    }
                    else if (package[i] == 0x5B)
                    {

                        bt.AddLast(0x5A);
                        bt.AddLast(0x01);
                    }
                    else if (package[i] == 0x5D)
                    {

                        bt.AddLast(0x5E);
                        bt.AddLast(0x01);
                    }
                    else if (package[i] == 0x5E)
                    {

                        bt.AddLast(0x5E);
                        bt.AddLast(0x02);
                    }
                    else
                    {

                        bt.AddLast(package[i]);
                    }
                }
                else
                {
                    bt.AddLast(package[i]);
                }


            }
            byte[] retBuff = new byte[bt.Count];
            bt.CopyTo(retBuff, 0);
            return retBuff;
        }
        public void HandlePackage(ClientInfo info, byte[] package)
        {
            if (package.Length < 10)
            {
                throw new Exception("数据包太短！");
            }
            if (package[0] != 0x40 || package[package.Length - 1] != 0x0d)
            {
                throw new Exception("非法的数据包！");
            }
            //转义处理：
            byte[] retBuff = HandlePackageReEscape(package);

            //===============================临时
            string debugString = "";
            for (int i = 0; i < package.Length; i++)
            {
                string hexOutput = String.Format("{0:X}", package[i]);
                if (hexOutput.Length < 2)
                {
                    hexOutput = "0" + hexOutput;
                }
                debugString += " " + hexOutput;
            }
            System.Console.Out.WriteLine(DateTime.Now.ToString() + "接收到：" + debugString);
            //===============================结束临时
            //提出命令字：

            UInt16 childCmd;
             
            
            string cm1=Convert.ToString(Convert.ToChar(retBuff[4]));
            string cm2 = Convert.ToString(Convert.ToChar(retBuff[5]));
            string strCMD = cm1 + cm2;
            
 


            switch (strCMD)
            {
                case "C0":
                    //byte Result = retBuff[23];
                    //uint VeryfyCode = (uint)((retBuff[24] << 24) + (retBuff[25] << 16) + (retBuff[26] << 8) + retBuff[27]);
                    if (this.OnLoginResult != null)
                    {
                        OnLoginResult(1, 1);
                    }
                    break;

               
                        default:
                            System.Console.Out.WriteLine("未知命令！" + strCMD);

                            throw new Exception("未知命令！" + strCMD);
 


                    break;
                /////============================DOWN结束=========================
             }

        }

       
        public byte[] MakeLogin( )
        {
             
            List<byte> byteList = new List<byte>();
            m_SequnceID++;
            if(m_SequnceID>65000){
                m_SequnceID=0;
            }
           // m_TermNo
             //校验码（0×100-（校验码前所有数据相加的和 & 0×ff））
            
            //起始符
            byteList.Add(0x40);

            //终端ID
            byteList.Add((byte)(m_TermNo>>24) );//
            byteList.Add((byte)((m_TermNo>>16)&0xff) );// 
            byteList.Add((byte)((m_TermNo>>8)&0xff ));// 
            byteList.Add((byte)(m_TermNo&0xff ));// 
            //序号：
            byteList.Add((byte)(m_SequnceID&0xff ));
            
　          //43 31 : 指令 C1
            byteList.Add(0x43 );
            byteList.Add(0x31 );
            //数据内容长度
            byteList.Add(0x00 );
            byteList.Add(0x08 );
           
 
            //31 30 30 30 : 用户名
            byteList.Add(0x31 );//
            byteList.Add(0x30);// 
            byteList.Add(0x30);// 
            byteList.Add(0x30 );// 
            
            //31 32 33 34 : 密码
            byteList.Add(0x31);//
            byteList.Add(0x32);// 
            byteList.Add(0x33);// 
            byteList.Add(0x34);// 

            int sum=0;
            for(int i=0;i<byteList.Count;i++){
                sum+=byteList[i];
            }
            sum=sum&0xff;
            sum=0x100-sum;

            byteList.Add((byte)sum);// 
            byteList.Add(0x0d);// 
            return byteList.ToArray();
        }

        public byte[] MakeGpsData(GPSDATA data, uint termNumber)
        {
            List<byte> byteList = new List<byte>();
            //起始符号 
            byteList.Add(0x40);
            //终端ID
            byteList.Add((byte)(termNumber >> 24));//
            byteList.Add((byte)((termNumber >> 16) & 0xff));// 
            byteList.Add((byte)((termNumber >> 8) & 0xff));// 
            byteList.Add((byte)(termNumber & 0xff));// 
            //序号：
            byteList.Add((byte)(m_SequnceID & 0xff));
            //指令：
            byteList.Add((byte)(0x43));
            byteList.Add((byte)(0x38));
            //00 1D           数据内容长度
            byteList.Add(0x00);
            byteList.Add(0x1d);
            //00 00 00        状态(byte[3])
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //00              速度(uint[1])
            byteList.Add((byte)(data.Speed & 0xff));
            // 时间（3：时，分，秒）（byte[3]）
            byteList.Add((byte)(data.Time.Hour));
            byteList.Add((byte)(data.Time.Minute));
            byteList.Add((byte)(data.Time.Second));
            //2A F6 93 BE     经度（uint[4]）
            uint lng = data.Lng;

            byteList.Add((byte)(lng >> 24));//
            byteList.Add((byte)((lng >> 16) & 0xff));// 
            byteList.Add((byte)((lng >> 8) & 0xff));// 
            byteList.Add((byte)(lng & 0xff));// 
            //2A F6 93 BE     纬度（uint[4]）

            uint lat = data.Lat;
            byteList.Add((byte)(lat >> 24));//
            byteList.Add((byte)((lat >> 16) & 0xff));// 
            byteList.Add((byte)((lat >> 8) & 0xff));// 
            byteList.Add((byte)(lat & 0xff));// 
            //00 65           行驶方向，（范围：0-360度）（uint[2]）
            byteList.Add((byte)(data.Angle >> 8));// 
            byteList.Add((byte)(data.Angle & 0xff));// 
            //00 00 00 00     里程(byte[4])，单位为米
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            byteList.Add(0x00);
            //日期
            byte year = (byte)Convert.ToInt32(Convert.ToString(data.Time.Year).Substring(2));
            byteList.Add(year);
            byteList.Add((byte)(data.Time.Month));
            byteList.Add((byte)(data.Time.Day));
            //信号强度E8              信号强度(uint[1])
            byteList.Add(0xE8);
            // 00 00           模拟量0（uint[2]，单位mV）
            byteList.Add(0x00);
            byteList.Add(0x00);
            // 模拟量1（uint[2]，单位mV）
            byteList.Add(0x00);
            byteList.Add(0x00);
            int sum = 0;
            for (int i = 0; i < byteList.Count; i++)
            {
                sum += byteList[i];
            }
            sum = sum & 0xff;
            sum = 0x100 - sum;

            byteList.Add((byte)sum);// 
            byteList.Add(0x0d);//  
            byte[] bts = byteList.ToArray();
            return HandlePackageEscape(bts);
        }
        /// <summary>
        /// GPS实时信息上报
      
        /// <returns></returns>
        public byte[] MakeGpsData(GPSDATA data)
        {
            return MakeGpsData(data, m_TermNo);
        }
        public override AbstractMessageHandle NewInstance()
        {
            ZDMessageHandle ret = new ZDMessageHandle(0);
          
            return ret;
        }
    }
}
