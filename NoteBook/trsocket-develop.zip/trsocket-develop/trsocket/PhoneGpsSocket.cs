﻿using System;
using System.Collections.Generic;
using System.Text;

namespace trsocket
{
    public class PhoneGpsSocket  
    {
        
        private TRServerSocket m_ServerSock;
        PhoneGpsMessageHandle m_ServerMsgHandle = new PhoneGpsMessageHandle();
        private volatile bool m_bStarted = false;
        ushort m_LocalPort = 0;
        string m_LocalIP;
        /// <summary>
        /// 收到后的注册委托
        /// </summary>
        public APPRegister OnAPPRegister
        {
            set
            {
                m_ServerMsgHandle.OnAPPRegister = value;
            }
        }
        /// <summary>
        /// 收到注销后的委托
        /// </summary>
        public APPLogout OnAPPLogout
        {
            set
            {
                m_ServerMsgHandle.OnAPPLogout = value;
            }
        }
        /// <summary>
        /// 收到ping后的委托
        /// </summary>
        public  APPPing OnOnAPPPing
        {
            set
            {
                m_ServerMsgHandle.OnAPPPing = value;
            }
        }
        /// <summary>
        /// 收到GPS定位包的委托
        /// </summary>
        public APPReportGps OnAPPReportGps
        {
            set
            {
                m_ServerMsgHandle.OnAPPReportGps = value;
            }
        }
        /// <summary>
        /// 被踢出事件
        /// </summary>
        public APPTickOut OnAPPTickOut {
            set
            {
                m_ServerMsgHandle.OnAPPTickOut = value;
            }
        }
        /// <summary>
        /// 函数函数
        /// </summary>
        /// <param name="LocalIP">可选</param>
        /// <param name="LocalPort">本地监听端口</param>
        public PhoneGpsSocket(string LocalIP, ushort LocalPort)
        {
            m_LocalIP = LocalIP;
            m_LocalPort = LocalPort;
        }
        /// <summary>
        /// 启动监听服务
        /// </summary>
        /// <param name="Port"></param>
        public void StartTCPServer(ushort Port)
        {
            if (m_LocalPort == 0)
            {
                throw new Exception("未指定端口！");
            }

            if (m_bStarted)
            {
                StopServer();
            }
            m_ServerSock = new TRServerSocket();
            m_ServerSock.StartListen(Port, m_ServerMsgHandle);
            m_bStarted = true;
        }
        /// <summary>
        /// 结束监听服务
        /// </summary>
        public void StopServer()
        {
            if (!m_bStarted)
            {
                return;
            }
            m_ServerSock.StopListen();
            m_bStarted = false;
        }
        /// <summary>
        /// 发送字节流
        /// </summary>
        /// <param name="info"></param>
        /// <param name="message"></param>
        public void SendMsg(ClientInfo info, byte[] message) {
            m_ServerSock.SendMsg(info, message);
        }
        /// <summary>
        /// 发送实时GPS
        /// </summary>
        /// <param name="info"></param>
        /// <param name="msg"></param>
        public void SendRealTimeGps(ClientInfo info, string msg)
        {
           byte[] message= m_ServerMsgHandle.MakeSendRealTimeGps(msg);
            m_ServerSock.SendMsg(info, message);
        }
        /// <summary>
        /// 回应注册结果
        /// </summary>
        /// <param name="info"></param>
        /// <param name="result"></param>
        public void SendRegsiterResult(ClientInfo info,string result,string sequnce)
        {
            byte[] message = m_ServerMsgHandle.MakeSendRegsiterResult(result, sequnce);
            m_ServerSock.SendMsg(info, message);
        }
        /// <summary>
        /// 回应PING结果
        /// </summary>
        /// <param name="info"></param>
        /// <param name="result"></param>
        public void SendPingResult(ClientInfo info, string result, string sequnce)
        {
            byte[] message = m_ServerMsgHandle.MakeSendPingResult(result,  sequnce);
            m_ServerSock.SendMsg(info, message);
        }
        /// <summary>
        /// 发送启动或关闭GPS上报指令
        /// </summary>
        /// <param name="info"></param>
        /// <param name="type">1:开始，2：停止 </param>
        public void SendControlGps (ClientInfo info, string type)
        {
            byte[] message = m_ServerMsgHandle.MakeSendControlGps(type);
            m_ServerSock.SendMsg(info, message);
        }
    }
}
