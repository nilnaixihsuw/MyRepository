﻿using System;
using System.Collections.Generic;
using System.Text;

namespace trsocket
{
    public class ZDSocket : TRClientSocketEx
    {
    //    private TRClientSocket m_ClientSock;
        private bool m_bAutoLogin = false;
        ZDMessageHandle m_MsgHandle =null;// new ZDMessageHandle(0);

        string m_ServerIP="";
        public bool IsLogin = false;
        //public  bool IsConnect = false;
        public SocketConnectResultHandle OnClientConnectHandle;
        public uint TermCode { get; set; }
        
        public ZDSocket(string IP, int Port, uint termID,bool autoLogin):base(IP, Port, false, null)
        {
            //CommonFunc.LogError("new ZDSocket");
            m_ServerIP = IP;
            m_bAutoLogin = autoLogin;
            m_MsgHandle = new ZDMessageHandle(termID);
            m_MsgHandle.OnLoginResult += OnLogin;
            m_MessageHandle = m_MsgHandle;
            this.SetRecvTimeOut(60000);
            this.OnClosedHandle += OnSocketClosed;
            this.OnConnectHandle += OnSocketConnect;
            TermCode = termID;
        }

        private void OnLogin(byte Result, uint VeryfyCode)
        {
            IsLogin = true;
            //CommonFunc.LogError(" ZD OnLogin !" );
                     
            System.Console.Out.WriteLine("登录结果：" + Result.ToString());
        }
        private void OnSocketConnect(bool success)
        {
            System.Console.Out.WriteLine("HZSocket连接：" + success.ToString());
            if (success)
            {
                if (this.m_bAutoLogin)
                {
                    Login();
                }
             //   IsConnect = true;
            }
            if (OnClientConnectHandle != null) {
                OnClientConnectHandle(success);
            }
            
        }
        /// <summary>
        ///  登录
        /// </summary>
        public void Login() {
            byte[] byteSend = m_MsgHandle.MakeLogin( );
            System.Console.Out.WriteLine(DateTime.Now.ToString()+ ":登录！");
            SendMsg(byteSend);
        }

        protected override void Ping()
        {

            byte[] byteSend = m_MsgHandle.MakeLogin();
            SendMsg(byteSend);
        }
        
       
        public void SendGps(GPSDATA data)
        {

            byte[] byteSend = m_MsgHandle.MakeGpsData(data);
            SendMsg(byteSend);
        }

        public void SendGps(GPSDATA data,uint termNumber)
        {

            byte[] byteSend = m_MsgHandle.MakeGpsData(data, termNumber);
            SendMsg(byteSend);
        }
        
        private void OnSocketClosed()
        {
           // IsConnect = false ;
           
        }
        /// <summary>
        /// 服务器IP
        /// </summary>
        public string ServerIP { get { return m_ServerIP; } }  
       
       
        
       
       
    }
}
