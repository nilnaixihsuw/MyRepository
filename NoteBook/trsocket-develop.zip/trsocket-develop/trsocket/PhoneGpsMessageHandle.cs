﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;
using System.IO;
using Newtonsoft.Json.Linq;

namespace trsocket
{
    class PhoneGpsMessageHandle : AbstractMessageHandle
    {
        public APPRegister OnAPPRegister;
        public APPLogout OnAPPLogout;
        public APPPing OnAPPPing;

        public APPReportGps OnAPPReportGps;
        public APPStartGpsAck OnAPPStartGpsAck;
        public APPTickOut OnAPPTickOut;
        public PhoneGpsMessageHandle()
        { 
           
        }
        /// <summary>
        /// 通用处理缓冲区流函数
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        protected override bool Analyze(ClientInfo info)
        {
            //包结构如下
            //帧头	包长度	包特性	信息域	校验和	帧尾
            // 1	    4	   2	    N	    1	  1
            //信息域为JSON串
            //            {
            //    "head": {
            //        "cmd": "login",
            //        "server_id": "60.191.59.10",
            //        "user_id": "30025654",
            //        "session_id": "xxxx",
            //"version": "android:2.23"
            //    },
            //     "content": {
            //”result”:”200”
            //        "parm1": "va1",
            //        "parm2": "val2"
            //    }
            //}
            byte[] totalBuf = this.GetBuffer(info);
            if (totalBuf.Length < 5)
            {
                return false;
            }
            //查找首个0x7e 与最后一个0x7e
            int firstPos=-1;
            int lastPost=-1;
            for (int i = 0; i < totalBuf.Length;i++ )
            {
                if (totalBuf[i] == 0x7e)//其为包头或尾
                {
                    if (firstPos == -1)
                    {
                        firstPos = i;
                    }else if(lastPost == -1){
                        lastPost = i;
                        break;
                    }
                }
            }
            if (lastPost==-1)//未找到一个完整的包
            {
                return false;
            }
            //分配一个临时缓冲，用于此次数据的处理
            byte[] packBuf = new byte[lastPost - firstPos+1];
            Array.Copy(totalBuf, firstPos, packBuf, 0, lastPost - firstPos + 1);
            try
            {
                bool result=  this.HandlePackage(info, packBuf);
                if (!result)
                {
                    try
                    {
                        CommonFunc.LogError("SESSION无效关闭SOCK :"  );
                        info.socket.Close();
                    }
                    catch (Exception ex1)
                    {

                        CommonFunc.LogError("关闭SOCK出错2:" + ex1.ToString());
                    }
                    if (this.OnAPPTickOut != null)
                    {

                        m_ClientList.Remove(info);
                        OnAPPTickOut(info);
                    }
                }
            }
            catch(Exception ex)
            {
                try
                {
                    info.socket.Close();
                }
                catch (Exception ex1)
                {

                    CommonFunc.LogError("关闭SOCK出错:" + ex1.ToString());
                }
                if(this.OnAPPTickOut!=null){
                   
                    m_ClientList.Remove(info);
                    OnAPPTickOut(info);
                }
                //CommonFunc.LogError("Analyze:"+ex.ToString());
            }
            this.RemoveLeftData(info, lastPost+1);
            return true;
          
        //非法数据包，发通知
        lastrow:
            this.OnAnalyzeWrong(info);
            return false;
        }
        /// <summary>
        /// 制造发送数据流
        /// </summary>
        /// <param name="jsonStr">JSON字符串</param>
        /// <param name="compress">需要压缩标志</param>
        /// <returns></returns>
        private byte[] builderCommonPack(string jsonStr, bool compress)
        {
            byte[] btRet = Encoding.GetEncoding("utf-8").GetBytes(jsonStr);
            if (compress)//需要压缩
            {
               btRet = CommonFunc.GZipCompress(btRet);
            }
            int len = btRet.Length + 9;
            //帧头	包长度	包特性	信息域	校验和	帧尾 total=9+len
            byte[] bytes = new byte[len];
            bytes[0] = 0x7e;

            bytes[1] = (byte)(len >> 24);
            bytes[2] = (byte)((len >> 16) & 0xff);
            bytes[3] = (byte)((len >> 8) & 0xff);
            bytes[4] = (byte)(len & 0xff);

            bytes[5] = 0;
            bytes[6] = 0;
            if (compress)//需要压缩
            {
                bytes[6] = (byte)(bytes[6]|0x01);
            }
            for (int i = 0; i < btRet.Length; i++)
            {
                bytes[i + 7] = btRet[i];
            }
            //检验和：
            byte xorResult = 0;
            for (int i = 0; i < btRet.Length-2; i++)
            {
                xorResult =(byte) (xorResult^btRet[i]);
            }
            bytes[len - 2] = xorResult;
            bytes[len - 1] = 0x7e;
            btRet = HandlePackageEscape(bytes);
            //string debugString = "builderCommonPack:";
            //for (int i = 0; i < btRet.Length; i++)
            //{
            //    string hexOutput = String.Format("{0:X}", btRet[i]);
            //    if (hexOutput.Length < 2)
            //    {
            //        hexOutput = "0" + hexOutput;
            //    }
            //    debugString += " " + hexOutput;
            //}
            ////Console.WriteLine(debugString);
            return btRet;
        }
        /// <summary>
        /// 处理整个包的反转义
        /// </summary>
        /// <param name="package">一个完整的数据包</param>
        /// <returns>反转义后的数据完整包</returns>
        private byte[] HandlePackageReEscape(byte[] package, out int packSize)
        {
            bool findEscapeWord = false;//是否有转义符的标志
           
            //先进行是否有转义符的判断，如果没有，则省去了内存分配
            for (int i=0;i<  package.Length;i++)
            {
                if (i == 0 || i == package.Length - 1)
                {//首尾不用反转义
                    continue;
                }
                if ( package[i] == 0x7d)
                {
                    findEscapeWord = true;
                    break;
                }
            }
            if (!findEscapeWord) {//未找到，原包返回
                packSize = package.Length;
                return package;
            }

            byte[] retBuff = new byte[package.Length];//由于反转义后的包大小不可能比新的包还要大，故此大小已足够
            int trueSize = 0;
            for  (int i=0;i < package.Length;i++)
            {
               if (i == 0 || i == package.Length - 1) {//首尾不用反转义
                    retBuff[trueSize++] = package[i];
                    continue; 
                }
               if (package[i] == 0x7d)
               {
                   if (package[i + 1] == 0x01)
                   {
                       retBuff[trueSize++] = 0x7d;
                       i++;
                   }
                   else if (package[i + 1] == 0x02)
                   {
                       retBuff[trueSize++] = 0x7e;
                       i++;
                   }
                   else
                   {
                       throw new Exception("非法的数据包，转义符不正确");
                   }
               }
               else {
                   retBuff[trueSize++] = package[i];
               }
            
            }
            packSize = trueSize;
            return retBuff;
        }
        /// <summary>
        /// 处理转义
        /// </summary>
        /// <param name="package"></param>
        /// <returns></returns>
        private byte[] HandlePackageEscape(byte[] package)
        {
            int escapCount = 0;
            //先进行是否有转义符的判断，如果没有，则省去了内存分配
            for (int i = 0; i < package.Length; i++)
            {
                if (i == 0 || i == package.Length - 1)
                {//首尾不用反转义
                    continue;
                }
                if (package[i] == 0x7e || package[i] == 0x7d)
                {
                    escapCount++;

                }
            }
            if (escapCount == 0)
            {//未找到，原包返回

                return package;
            }

            byte[] retBuff = new byte[package.Length + escapCount];
            int trueSize = 0;
            for (int i = 0; i < package.Length; i++)
            {
                if (i == 0 || i == package.Length - 1)
                {//首尾不用反转义
                    retBuff[trueSize++] = package[i];
                    continue;
                }
                if (package[i] == 0x7d)
                {
                    retBuff[trueSize++] = 0x7d;
                    retBuff[trueSize++] = 0x01;
                }
                else if (package[i] == 0x7e)
                {
                    retBuff[trueSize++] = 0x7d;
                    retBuff[trueSize++] = 0x02;
                }
                else
                {
                    retBuff[trueSize++] = package[i];
                }
            }
            return retBuff; ;
        }
        /// <summary>
        /// 处理一个完整包
        /// </summary>
        /// <param name="info"></param>
        /// <param name="package"></param>
        public bool HandlePackage(ClientInfo info, byte[] package)
        {
            bool result = true;
            if (package.Length < 10)
            {
                throw new Exception("数据包太短！");
            }
            if (package[0] != 0x7e || package[package.Length - 1] != 0x7e)
            {
                throw new Exception("非法的数据包！");
            }
            //转义处理：
            int retLen=0;
            byte[] retBuff = HandlePackageReEscape(package,out retLen);
            string debugString = "";
            //取出包头各项：
            //帧头	包长度	包特性	信息域	校验和	帧尾
            // 1	    4	   2	    N	    1	  1
            //包长
            int packageLen = (retBuff[1] << 24) + (retBuff[2] << 16) + (retBuff[3] << 8) + (retBuff[4]);
            if (retLen != packageLen) {
                throw new Exception("非法的数据包！长度不符合:期待：" + packageLen.ToString() + ",实际：" + retLen.ToString());
            }
            //包特性:
            UInt16 prop = (UInt16)((retBuff[5] << 8) + (retBuff[6]));
            //查看是否为压缩:
            bool isCompress=false;
            if ((prop & 0x01)!=0 ) {
                isCompress = true;
            }
            string jsonStr = "";
            if (!isCompress)//未压缩，获取正文
            {
                jsonStr = System.Text.Encoding.GetEncoding("utf-8").GetString(retBuff, 7, retLen - 9);
            }
            else { //进行解压
               byte[] decCompress=CommonFunc.GZipDeCompress(retBuff, 7, retLen - 9);
               jsonStr = System.Text.Encoding.GetEncoding("utf-8").GetString(decCompress);
            }
            JObject jobj = JObject.Parse(jsonStr);
            string cmd =(string) jobj["head"]["cmd"];
            switch (cmd)
            {
                case "register_gps":
                    {
                        //CommonFunc.LogError("register_gps:");
                        string serverID = (string)jobj["head"]["server_id"];
                        string userID = (string)jobj["head"]["user_id"];
                        string password = (string)jobj["content"]["pass_word"];
                        string version = (string)jobj["head"]["version"];
                        string sequnce = (string)jobj["content"]["sequnce_id"];
                        string session_id = (string)jobj["head"]["session_id"];
                        if (string.IsNullOrEmpty(session_id) || session_id.Length<=5) {
                            session_id = "";
                            result = false;
                        }
                        if (OnAPPRegister != null && session_id != "")
                        {
                            try
                            {
                                OnAPPRegister(info, serverID, uint.Parse(userID), password, version, sequnce,   session_id);
                            }
                            catch(Exception ex) {
                                CommonFunc.LogError("OnAPPRegister:" + ex.ToString());
                            }
                        }
                        break;
                    }
                case "unregister_gps":
                    {
                        //CommonFunc.LogError("logout:");
                        string reason = (string)jobj["content"]["reason"];
                        if (OnAPPRegister != null)
                        {
                            try
                            {
                                OnAPPLogout(info, reason);
                            }
                            catch(Exception ex) {
                                CommonFunc.LogError("OnAPPLogout:" + ex.ToString());
                            }
                        }
                        break;
                    }
                case "ping":
                    {
                       // CommonFunc.LogError("ping:");
                        string sequnce = (string)jobj["content"]["sequnce_id"];
                        if (OnAPPRegister != null)
                        {
                            try
                            {
                                OnAPPPing(info, sequnce);
                            }
                            catch(Exception ex) {
                                CommonFunc.LogError("ping:" + ex.ToString());
                            }
                        }
                        break;
                    }
                case "report_gps":
                    {
                        //CommonFunc.LogError("report_gps:" + jsonStr);
                        try
                        {
                            HandleGps(info, jobj);
                        }
                        catch(Exception ex) {
                            CommonFunc.LogError("HandleGps:" + ex.ToString());
                        }
                        break;
                    }
                case "control_report_ack":
                    {
                        //CommonFunc.LogError("control_report_ack :" + jsonStr);
                        if(OnAPPStartGpsAck!=null){
                            try
                            {
                                OnAPPStartGpsAck(info);
                            }catch(Exception ex){
                                CommonFunc.LogError("OnAPPStartGpsAck出错 :"+ex.ToString());
                            }
                        }
                        
                        break;
                    }
                default:
                    throw new Exception("未知命令！" + cmd);
                 
            }
            return result;
 
            //===============================临时

            //for (int i = 0; i < packageLen; i++)
            //{
            //    string hexOutput = String.Format("{0:X}", package[i]);
            //    if (hexOutput.Length < 2)
            //    {
            //        hexOutput = "0" + hexOutput;
            //    }
            //    debugString += " " + hexOutput;
            //}
            //CommonFunc.LogError(debugString);
         
            //===============================结束临时
            //提出命令字：

         
        }
        /// <summary>
        /// 处理手机定位上报
        /// </summary>
        /// <param name="info"></param>
        /// <param name="jsonText"></param>
        private void HandleGps(ClientInfo info, JObject gpsJson)
        {
            //CommonFunc.LogError("调用OnAPPReportGps开始:");
            try
            {
                JArray items = (JArray)gpsJson["content"];//找到content节点
                for (int i = 0; i < items.Count; i++)//对该包中的一组数据进行遍历
                {
                    //以下以数组方式获取该包中定位数据项，数据项目都是按约定的顺序来的
                    JArray oneItem = (JArray)items[i];
                    int vehicleID = (int)oneItem[0];
                    double lat = (double)(oneItem[1]);
                    double lng = (double)(oneItem[2]);
                    double speed = (double)(oneItem[3]);
                    short angle = (short)(oneItem[4]);
                    DateTime time = (DateTime)(oneItem[5]);
                    int altitude = (int)(oneItem[6]);
                    uint state = (uint)(oneItem[7]);
                    uint alarm = (uint)(oneItem[8]);
                    if (this.OnAPPReportGps != null)//判断客户端是否注册了委托
                    {
                        try
                        {
                            OnAPPReportGps(info, vehicleID, lat, lng, speed, angle, time, altitude, state, alarm);//调用委托函数
                        }
                        catch (Exception ex)
                        {
                            CommonFunc.LogError("调用OnAPPReportGps1出错:" + ex.ToString());
                        }
                    }
                }
            }catch(Exception ex){
                CommonFunc.LogError("调用OnAPPReportGps2出错:" + ex.ToString());
            }
            //CommonFunc.LogError("调用OnAPPReportGps结束");
        }  
              
        public override AbstractMessageHandle NewInstance()
        {
            JXYGMessageHandle ret = new JXYGMessageHandle( );
         
            return ret;
        }
        /// <summary>
        /// 制造GPS信息 
        /// </summary>
        /// <param name="gpsInfo"></param>
        /// <returns></returns>
        public byte[] MakeSendRealTimeGps(string gpsInfo)
        {
            byte[] infoBytes = builderCommonPack(gpsInfo, gpsInfo.Length>1024?true:false);
            return infoBytes;
        }
        /// <summary>
        /// 制造注册结果
        /// </summary>
        /// <returns></returns>
        public byte[] MakeSendRegsiterResult(string result, string sequnce)
        {
            StringBuilder strBuilder=new StringBuilder();
            strBuilder.Append("{\"head\": { \"cmd\": \"register_gps_ack\", \"server_id\": \"0\", \"user_id\": \"0\",");
            strBuilder.Append(  "\"session_id\": \"0\",");
            strBuilder.Append(  "\"version\": \"1.0\"");
            strBuilder.Append(  "},");
            strBuilder.Append(  "\"content\": {");
            strBuilder.Append(  "\"result\":\"");
            strBuilder.Append(result);
            strBuilder.Append("\",");
            strBuilder.Append("\"sequnce_id_ack\":\"" );
            strBuilder.Append(sequnce);
            strBuilder.Append("\"");
            strBuilder.Append(  "}}");


            byte[] infoBytes = builderCommonPack(strBuilder.ToString(), false);
            return infoBytes;
        }
        /// <summary>
        /// 制造PING结果
        /// </summary>
        /// <returns></returns>
        public byte[] MakeSendPingResult(string result, string sequnce)
        {
            StringBuilder strBuilder = new StringBuilder();
            strBuilder.Append("{\"head\": { \"cmd\": \"ping_ack\", \"server_id\": \"0\", \"user_id\": \"0\",");
            strBuilder.Append("\"session_id\": \"0\",");
            strBuilder.Append("\"version\": \"1.0\"");
            strBuilder.Append("},");
            strBuilder.Append("\"content\": {");
            strBuilder.Append("\"sequnce_id_ack\":\"");
            strBuilder.Append(sequnce);
            strBuilder.Append("\"");
            strBuilder.Append("}}");
            byte[] infoBytes = builderCommonPack(strBuilder.ToString(), false);
            return infoBytes;
        }
        /// <summary>
        /// 制造发送或停止发送GPS
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        public byte[] MakeSendControlGps(string type)
        {
            StringBuilder strBuilder = new StringBuilder();
            strBuilder.Append("{\"head\": { \"cmd\": \"control_report\", \"server_id\": \"0\", \"user_id\": \"0\",");
            strBuilder.Append("\"session_id\": \"0\",");
            strBuilder.Append("\"version\": \"1.0\"");
            strBuilder.Append("},");
            strBuilder.Append("\"content\": {");
            strBuilder.Append("\"type\": \"");
            strBuilder.Append(type);
            strBuilder.Append("\"");
            strBuilder.Append("}}");
            byte[] infoBytes = builderCommonPack(strBuilder.ToString(), false);
            return infoBytes;
        } 
        
        
    }
}
