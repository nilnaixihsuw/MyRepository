﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace trsocket
{
    public class TRClientSocket
    {
        private IPAddress m_ServerIP = null;
        private int m_Port = 0;
        private IPEndPoint serverFullAddr;
        private volatile bool m_bConnect = false;
        private bool m_bAutoConnect = true;

        public Socket sock;
        public SocketConnectResultHandle OnConnectHandle;
        public SocketClosedHandle OnClosedHandle;
        public RawMessageArrive OnMsgArrive;
        protected AbstractMessageHandle m_MessageHandle;


        private int m_ide_timeout = 180;//秒，空闲超时，(时长超出此规定时长，未收到任何消息，视为断开)
        private DateTime m_last_recv_time = DateTime.Now;//最后接收到服务器回应时间
        private int m_period_connect = 3000;//再次尝试连接间隔时长
        private ClientInfo m_ClientInfo = new ClientInfo();
        private DateTime m_LastPingTime;
        private string m_host = "";
        public bool NeedPing = false;//是否需要自动PING
        private string m_ip = "";//
        private volatile bool isWorking = false;//处于工作状态标志 

        ManualResetEvent m_TerminalEvent = new ManualResetEvent(false);
        ManualResetEvent m_SuccessTerminateEvent = new ManualResetEvent(false);
        private System.Threading.Timer m_SockWatchTimer;
        private DateTime m_lastConnectSuccessTime = DateTime.Now;//记录最近一次的连接成功时间
        volatile bool m_isClosing = false;//正在关闭中，其他线程不用再进入
        public bool IsConnect()
        {
            return m_bConnect;

        }

        public void SetRecvTimeOut(int value)
        {
            m_ide_timeout = value;

        }
        public bool AutoConnect
        {
            get { return m_bAutoConnect; }
            set { m_bAutoConnect = value; }
        }

        public string Ip
        {
            get { return m_ip; }
        }
        public int Port
        {
            get { return m_Port; }
        }

        public void SendMsg(byte[] byteSend)
        {
            if (this.sock == null)
            {
                return;
            }
            int bytes = byteSend.Length;
            int snd = 0;
            int snd_total = 0;
            if (!m_bConnect)
            {
                CommonFunc.LogError("SendMsg 未连接，终止:" + " ip:" + this.Ip + " PORT:" + this.Port);
                return;
            }
            try
            {
                while (bytes > 0)
                {
                    snd = this.sock.Send(byteSend, snd_total, bytes, SocketFlags.None);
                    if (snd <= 0)
                    {
                        break;
                    }
                    snd_total += snd;
                    bytes = byteSend.Length - snd_total;
                    if (bytes > 0)
                    {
                        //CommonFunc.LogError("bytes>0:" + byteSend.Length.ToString());
                    }
                }
            }
            catch (SocketException exs)//Socket已经断开，自动重连
            {
                CommonFunc.LogError("SocketException1:" + exs.ToString() + " IP:" + this.Ip + " PORT:" + this.Port);

                m_last_recv_time = DateTime.Now;
                CloseSocketLocal(DateTime.Now);
                //Connect();
                throw exs;
            }
            catch (ObjectDisposedException exd)//Socket已经断开，自动重连
            {
                CommonFunc.LogError("ObjectDisposedException:" + exd.ToString() + " ip:" + this.Ip + " PORT:" + this.Port);
                m_last_recv_time = DateTime.Now;
                CloseSocketLocal(DateTime.Now);
                //Connect();
                throw exd;
            }
            catch (Exception ex)
            {
                CommonFunc.LogError("sendException:" + ex.ToString() + " ip:" + this.Ip + " PORT:" + this.Port);
                throw ex;
            }


        }
        public void SendMsg(byte[] byteSend, int offset, int len)
        {
            if (this.sock == null)
            {
                return;
            }
            if (!m_bConnect)
            {
                CommonFunc.LogError("SendMsg 未连接，终止:" + " ip:" + this.Ip + " PORT:" + this.Port);
                return;
            }
            int bytes = len;// byteSend.Length;
            int snd = 0;
            int snd_total = offset;
            try
            {
                while (bytes > 0)
                {
                    snd = this.sock.Send(byteSend, snd_total, bytes, SocketFlags.None);
                    if (snd <= 0)
                    {
                        break;
                    }
                    snd_total += snd;
                    bytes = len - snd_total;
                    if (bytes > 0)
                    {
                        //CommonFunc.LogError("bytes>0:" + byteSend.Length.ToString());
                    }
                }
            }
            catch (SocketException exs)//Socket已经断开，自动重连
            {
                CommonFunc.LogError("SocketException22:" + exs.ToString() + " ip:" + this.Ip + " PORT:" + this.Port);
                m_last_recv_time = DateTime.Now;
                CloseSocketLocal(DateTime.Now);
                // Connect();
                throw exs;
            }
            catch (ObjectDisposedException exd)//Socket已经断开，自动重连
            {
                CommonFunc.LogError("ObjectDisposedException22:" + exd.ToString() + " ip:" + this.Ip + " PORT:" + this.Port);
                m_last_recv_time = DateTime.Now;
                CloseSocketLocal(DateTime.Now);
                // Connect();
                throw exd;
            }
            catch (Exception ex)
            {
                CommonFunc.LogError("sendException22:" + ex.ToString() + " ip:" + this.Ip + " PORT:" + this.Port);
                throw ex;


            }
            //string ret = "SendMsg:";
            //for (int i = offset; i < len + offset; i++)
            //{
            //    string hexOutput = String.Format("{0:X}", byteSend[i]);
            //    if (hexOutput.Length < 2)
            //    {
            //        hexOutput = "0" + hexOutput;
            //    }
            //    ret += " " + hexOutput;
            //}
            //ret += "\r\n";
            //CommonFunc.LogError(ret);

        }


        private void IniEnv()
        {
            isWorking = true;
            if (m_MessageHandle != null)
            {
                m_MessageHandle.OnAnalyzeError = OnDataError;
            }
        }
        private void OnDataError()
        {
            //return;//必须删除!!!!!!!!!!!!!!!
            // CloseSocket();
        }
        public TRClientSocket()
        {
            m_MessageHandle = new GPSMessageHandle();
            IniEnv();
        }

        public TRClientSocket(string ip, int port, string username, string password, LoginType logType)
        {

            IniEnv();
            m_MessageHandle = new GPSMessageHandle();
            string digital = ip.Replace(".", "");
            try
            {
                Convert.ToDouble(digital);
            }
            catch
            {
                m_host = ip;

            }
            m_ip = ip;
            if (m_host == "")//非域名
            {
                m_ServerIP = IPAddress.Parse(ip);
            }
            m_Port = port;

            Thread t1 = new Thread(new ThreadStart(ReconnectThreadFunc));
            Random rd = new Random();
            int rInt = rd.Next(1000, 2000);
            t1.Name = "Connect Message-" + rInt;
            //CommonFunc.LogError("启动检测线程：" + rInt + CommonFunc.Trailsman());
            //一个线程或者是后台线程或者是前台线程。后台线程与前台线程类似，区别是后台线//程不会防止进程终止。一旦属于某一进程的所有前台线程都终止，公共语言运行库就//会通过对任何仍然处于活动状态的后台线程调用 Abort 来结束该进程。
            t1.IsBackground = true;
            t1.Start();
            // m_SockWatchTimer = new System.Threading.Timer(SockTimerCallback, null, 1000, 3000);
        }
        public TRClientSocket(string ip, int port, string username, string password, LoginType logType, AbstractMessageHandle MessageHandle)
        {

            IniEnv();
            m_MessageHandle = MessageHandle;

            string digital = ip.Replace(".", "");
            try
            {
                Convert.ToDouble(digital);
            }
            catch
            {
                m_host = ip;
            }
            if (m_host != "")//非域名
            {
                m_ServerIP = IPAddress.Parse(ip);
            }
            m_ip = ip;
            m_Port = port;

            Thread t1 = new Thread(new ThreadStart(ReconnectThreadFunc));
            Random rd = new Random();
            int rInt = rd.Next(1000, 2000);
            t1.Name = "a Connect thread-" + rInt;
            //CommonFunc.LogError("启动检测线程：" + rInt + CommonFunc.Trailsman());
            //一个线程或者是后台线程或者是前台线程。后台线程与前台线程类似，区别是后台线//程不会防止进程终止。一旦属于某一进程的所有前台线程都终止，公共语言运行库就//会通过对任何仍然处于活动状态的后台线程调用 Abort 来结束该进程。
            t1.IsBackground = true;
            t1.Start();
            // m_SockWatchTimer = new System.Threading.Timer(SockTimerCallback, null, 1000, 3000);
        }
        
        public TRClientSocket(string ip, int port, bool autoLogin, AbstractMessageHandle MessageHandle)
        {

            if (ip == "" || ip == null)
            {
                return;
            }
            m_ip = ip;
            string digital = ip.Replace(".", "");
            try
            {
                Convert.ToDouble(digital);
            }
            catch
            {
                m_host = ip;

            }
            if (m_host == "")//非域名
            {
                m_ServerIP = IPAddress.Parse(ip);
            }
            m_Port = port;
            this.m_MessageHandle = MessageHandle;
            IniEnv();

            Thread t1 = new Thread(new ThreadStart(ReconnectThreadFunc));
            Random rd = new Random();
            int rInt = rd.Next(1000, 2000);
            t1.Name = "a Connect thread-" + rInt;
            //CommonFunc.LogError("启动检测线程：" + rInt + CommonFunc.Trailsman());
            t1.IsBackground = true;
            t1.Start();
            //m_SockWatchTimer = new System.Threading.Timer(SockTimerCallback, null, 1000, 3000);
        }


        public void Open(string ip, int port, int periodConnect)
        {
            isWorking = true;
            string digital = ip.Replace(".", "");
            try
            {
                Convert.ToDouble(digital);
            }
            catch
            {
                m_host = ip;

            }
            if (m_host == "")//非域名
            {
                m_ServerIP = IPAddress.Parse(ip);
            }

            m_Port = port;
            m_period_connect = periodConnect;

            // m_SockWatchTimer = new System.Threading.Timer(SockTimerCallback, null, 1000, m_period_connect);

            Thread t1 = new Thread(new ThreadStart(ReconnectThreadFunc));
            Random rd = new Random();
            int rInt = rd.Next(1000, 2000);
            t1.Name = "a Connect thread-" + rInt;
            //CommonFunc.LogError("启动检测线程：" + rInt + CommonFunc.Trailsman());
            //一个线程或者是后台线程或者是前台线程。后台线程与前台线程类似，区别是后台线//程不会防止进程终止。一旦属于某一进程的所有前台线程都终止，公共语言运行库就//会通过对任何仍然处于活动状态的后台线程调用 Abort 来结束该进程。
            t1.IsBackground = true;
            t1.Start();

        }
        private void ReconnectThreadFunc()
        {
            //Thread.Sleep(3000);
            while (true)
            {

                if (!isWorking)
                {
                    return;
                }
                if (m_ip == "")
                {
                    goto lastRow;
                }
                try
                {
                    //CommonFunc.LogError("ReconnectThreadFunc检查 :m_bAutoConnect:" + m_bAutoConnect.ToString() + " m_ide_timeout:" + m_ide_timeout.ToString() + " m_last_recv_time：" + m_last_recv_time.ToString("yyyy-MM-dd HH:mm:ss"));

                    //先停止，以防本次还未完成又再入
                    // m_SockWatchTimer.Change(System.Threading.Timeout.Infinite, System.Threading.Timeout.Infinite);
                    if (m_bAutoConnect)
                    {
                        if (!m_bConnect)
                        {
                            //CommonFunc.LogError("开始重新连接");
                            try
                            {
                                if (Connect())
                                {

                                    m_bConnect = true;
                                    if (OnConnectHandle != null)
                                    {
                                        OnConnectHandle(true);
                                    }
                                }
                            }
                            catch
                            {


                            }
                            //恢复定时扫描


                        }
                        else
                        {
                            //超过规定时间没收到任何消息，重连接
                            if ((DateTime.Now - m_last_recv_time).TotalSeconds > m_ide_timeout)
                            {
                                CommonFunc.LogError("超时关闭1 !" + m_last_recv_time.ToString("yyyy-MM-dd HH:mm:ss") + " ip:" + m_ServerIP.ToString() + " m_ide_timeout: " + m_ide_timeout);
                                m_last_recv_time = DateTime.Now;
                                CloseSocketLocal(DateTime.Now);
                                Connect();

                            }

                        }
                    }
                    // m_SockWatchTimer.Change(m_period_connect, m_period_connect);
                    if (m_bConnect && NeedPing && (DateTime.Now - m_LastPingTime).TotalSeconds > 90)
                    {
                        Ping();
                        m_LastPingTime = DateTime.Now;
                    }
                }
                catch
                {


                }
            lastRow:
                Thread.Sleep(3000);
            }
        }
        private void SockTimerCallback(object state)
        {
            if (!isWorking)
            {
                return;
            }
            try
            {
                //CommonFunc.LogError("SockTimerCallback检查 :m_bAutoConnect:" + m_bAutoConnect.ToString() + " m_ide_timeout:" + m_ide_timeout.ToString() + " m_last_recv_time：" + m_last_recv_time.ToString("yyyy-MM-dd HH:mm:ss"));

                //先停止，以防本次还未完成又再入
                m_SockWatchTimer.Change(System.Threading.Timeout.Infinite, System.Threading.Timeout.Infinite);
                if (m_bAutoConnect)
                {
                    if (!m_bConnect)
                    {
                        //CommonFunc.LogError("!m_bConnect");
                        try
                        {
                            if (Connect())
                            {
                                m_bConnect = true;
                                if (OnConnectHandle != null)
                                {
                                    OnConnectHandle(true);
                                }
                            }
                        }
                        catch
                        {


                        }
                        //恢复定时扫描


                    }
                    else
                    {
                        //超过规定时间没收到任何消息，重连接
                        if ((DateTime.Now - m_last_recv_time).TotalSeconds > m_ide_timeout)
                        {
                            CommonFunc.LogError("超时关闭2 !" + m_last_recv_time.ToString("yyyy-MM-dd HH:mm:ss") + " ip:" + m_ServerIP.ToString() + " m_ide_timeout:" + m_ide_timeout);

                            m_last_recv_time = DateTime.Now;
                            CloseSocketLocal(DateTime.Now);
                            Connect();

                        }

                    }
                }
                m_SockWatchTimer.Change(m_period_connect, m_period_connect);
                if (m_bConnect && NeedPing && (DateTime.Now - m_LastPingTime).TotalSeconds > 90)
                {
                    Ping();
                    m_LastPingTime = DateTime.Now;
                }
            }
            catch
            {


            }
        }
        public bool ManuConnect(string ip, int port)
        {

            m_ServerIP = IPAddress.Parse(ip);
            m_Port = port;
            this.m_MessageHandle = new JXYGMessageHandle();
            isWorking = true;
            IniEnv();
            return Connect();
        }
        private bool Connect()
        {
            lock (this)
            {
                try
                {
                    if (!isWorking)
                    {
                        //CommonFunc.LogError("因为!isWorking:不用重新连接");

                        return false;
                    }
                    sock = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                    //CommonFunc.LogError("Connect begin:m_ServerIP:" + Convert.ToString(m_ServerIP) + " m_host:" + Convert.ToString(m_host) + " port:" + Convert.ToString(m_Port));
                    if (m_host == "")
                    {
                        serverFullAddr = new IPEndPoint(m_ServerIP, m_Port);
                        sock.Connect(serverFullAddr);//建立与远程主机的连接
                        IPEndPoint addrThisTime = (IPEndPoint)sock.LocalEndPoint;
                        int PortThis = -1;
                        if (addrThisTime != null)
                        {
                            PortThis = addrThisTime.Port;
                        }
                    }
                    else
                    {
                        sock.Connect(m_host, m_Port);
                        m_lastConnectSuccessTime = DateTime.Now;
                    }
                    m_ClientInfo.socket = sock;
                    //启动新线程用于接收数据
                    Thread t = new Thread(new ThreadStart(ReceiveMsg));
                    // t.Name = "Receive Message";
                    //一个线程或者是后台线程或者是前台线程。后台线程与前台线程类似，区别是后台线//程不会防止进程终止。一旦属于某一进程的所有前台线程都终止，公共语言运行库就//会通过对任何仍然处于活动状态的后台线程调用 Abort 来结束该进程。
                    t.IsBackground = true;
                    t.Start();
                    if (OnConnectHandle != null)
                    {
                        //OnConnectHandle(true);
                    }
                    else
                    {
                        //CommonFunc.LogError("OnConnectHandle is null");
                    }
                    IPEndPoint addrTemp = (IPEndPoint)sock.LocalEndPoint;
                    if (addrTemp != null)
                    {
                        CommonFunc.LogError(" local PORT:" + addrTemp.Port);

                    }
                    CommonFunc.LogError("Connect succuess:" + " ip:" + this.Ip + " PORT:" + this.Port);
                }
                catch (Exception ex)
                {
                    if (OnConnectHandle != null)
                    {
                        OnConnectHandle(false);
                    }
                    else
                    {
                        //CommonFunc.LogError("OnConnectHandle is null");
                    }
                    //CommonFunc.LogError("Connect failure:" + ex.Message + ex.StackTrace);
                    return false;
                }
                return true;
            }
        }

        private void ReceiveMsg()
        {
            byte[] recvBuf = new byte[4096];
            byte[] lastRecvBuf = new byte[0];
            bool bExit = m_TerminalEvent.WaitOne(1, false);
            IPEndPoint addrThisTime = (IPEndPoint)sock.LocalEndPoint;
            int PortThis = -1;
            if (addrThisTime != null)
            {
                PortThis = addrThisTime.Port;
            }

            int ret = 0;
            while (true)
            {
                try
                {
                    ret = this.sock.Receive(recvBuf);
                    if(ret <= 0)
                    {
                        break;
                    }
                    byte[] thisBuff = new byte[ret];
                    Array.Copy(recvBuf, 0, thisBuff, 0, ret);
                    m_last_recv_time = DateTime.Now;
                    if (OnMsgArrive != null)
                    {
                        OnMsgArrive(thisBuff);
                    }
                    if (m_MessageHandle != null)
                    {
                        m_MessageHandle.AddData(m_ClientInfo, thisBuff);
                    }
                }
                catch (Exception ex)
                {
                   
                    try
                    {
                         CommonFunc.LogError("ReceiveMsg end exception:" + ex.ToString() + " "+m_ip.ToString() + ":" + m_Port.ToString());
                        // IPEndPoint addrTemp1 = (IPEndPoint)sock.LocalEndPoint;
                        // if (addrTemp1 != null && addrTemp1.Port == PortThis)
                        {
                            //   CommonFunc.LogError("this.sock.Shutdown:" + PortThis);
                            //   this.sock.Shutdown(SocketShutdown.Receive);
                            //   this.sock.Close();

                        }


                    }
                    catch
                    {

                    }
                    break;
                }
                // bExit = m_TerminalEvent.WaitOne(1, false);

            }
        lastrow:

            CommonFunc.LogError("ReceiveMsg end!" + " ip:" + this.Ip + " PORT:" + this.Port);
            if (this.OnClosedHandle != null)
            {
                OnClosedHandle();
            }
            m_TerminalEvent.Reset();
            m_bConnect = false;
            m_SuccessTerminateEvent.Set();
        }


        //private void ReceiveMsg()
        //{
        //    byte[] recvBuf = new byte[4096];
        //    byte[] lastRecvBuf = new byte[0];
        //    bool bExit = m_TerminalEvent.WaitOne(1, false);
        //    IPEndPoint addrThisTime = (IPEndPoint)sock.LocalEndPoint;
        //    int PortThis = -1;
        //    if (addrThisTime != null)
        //    {
        //        PortThis = addrThisTime.Port;
        //    }
        //    while (!bExit)
        //    {
        //        try
        //        {
        //            
        //            int ret = this.sock.Receive(recvBuf);
        //            if (ret <= 0)
        //            {//断开了
        //                CommonFunc.LogError("ReceiveMsg result:" + ret.ToString());
        //                goto lastrow;
        //            }
        //            byte[] thisBuff = new byte[ret];
        //            Array.Copy(recvBuf, 0, thisBuff, 0, ret);
        //            m_last_recv_time = DateTime.Now;
        //            if (OnMsgArrive != null)
        //            {
        //                OnMsgArrive(thisBuff);
        //            }
        //            if (m_MessageHandle != null)
        //            {
        //                m_MessageHandle.AddData(m_ClientInfo, thisBuff);
        //            }
        //        }
        //        catch (Exception ex)
        //        {
        //            try
        //            {
        //                CommonFunc.LogError("ReceiveMsg end exception:" + ex.ToString() + m_ip.ToString() + ":" + m_Port.ToString());
        //                IPEndPoint addrTemp1 = (IPEndPoint)sock.LocalEndPoint;
        //                if (addrTemp1 != null && addrTemp1.Port == PortThis)
        //                {
        //                    CommonFunc.LogError("this.sock.Shutdown:" + PortThis);
        //                    this.sock.Shutdown(SocketShutdown.Receive);
        //                    this.sock.Close();

        //                }


        //            }
        //            catch
        //            {

        //            }
        //            break; ;
        //        }
        //        bExit = m_TerminalEvent.WaitOne(1, false);

        //    }
        //    lastrow:

        //    CommonFunc.LogError("ReceiveMsg end!" + " ip:" + this.Ip + " PORT:" + this.Port);
        //    if (this.OnClosedHandle != null)
        //    {
        //        OnClosedHandle();
        //    }
        //    m_TerminalEvent.Reset();
        //    m_bConnect = false;
        //    m_SuccessTerminateEvent.Set();
        //}




        public void CloseSocket()
        {
            CommonFunc.LogError("TRClientSocket CloseSocket()!");
            try
            {
                isWorking = false;
                this.sock.Shutdown(SocketShutdown.Receive);
                this.sock.Close();
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("CloseSocket:" + ex.ToString());
            }
            m_TerminalEvent.Set();



        }

        private void CloseSocketLocal(DateTime tm)
        {
            if (m_isClosing)
            {
                return;
            }
            m_isClosing = true;
            lock (this)
            {

                if (m_lastConnectSuccessTime > tm)
                {//类似双检锁
                    //CommonFunc.LogError("在此期间已经连接成功，放弃本次重连");
                }
                try
                {
                    CommonFunc.LogError("TRClientSocket CloseSocketLocal()!");
                    this.sock.Shutdown(SocketShutdown.Receive);
                    this.sock.Close();
                }
                catch (Exception ex)
                {
                    // Console.Out.WriteLine("CloseSocket:" + ex.ToString());
                }
                m_SuccessTerminateEvent.Reset();
                m_TerminalEvent.Set();
                bool bExit = m_SuccessTerminateEvent.WaitOne(5000, false);
                if (!bExit)
                {
                    CommonFunc.LogError("TRClientSocket CloseSocketLocal()!未能成功结束线程！！！！！！！！！！！！！！");
                    m_bConnect = false;//置为未连接，让检测线程去重新连接
                }
                else
                {
                    CommonFunc.LogError("TRClientSocket CloseSocketLocal()!成功结束线程！！！！！！！！！！！！！！");
                }
                //m_bConnect = false;//置为未连接，让检测线程去重新连接
                Thread.Sleep(5000);//等检测线程完成一次重连
                m_isClosing = false;
            }

        }
        /// <summary>
        /// 保持与服务器心跳连接
        /// </summary>
        protected virtual void Ping()
        {

            byte[] byteSend = CommonFunc.MakePingData();
            byteSend = CommonFunc.MakeCommandPackage(byteSend, CommandType.CMD_PING);
            try
            {
                SendMsg(byteSend);

            }

            catch (Exception ex)
            {

                System.Console.Out.WriteLine("Ping:" + ex.ToString());

            }
        }
    }
}