﻿
using System.Runtime.InteropServices;
namespace trsocket
{
    public enum CommandType
    {
        CMD_LOGIN = 0x01,															// 用户登录(客户端---》服务器)
        CMD_LOGIN_ANSWER,														// 用户登录应答(服务器==>客户端)

        CMD_GPS_INFO,															// 服务器向客户平台发送GPS信息
        CMD_NOTIFY_STATION,														// 服务器向电子站台发送到站信息
        CMD_MESSAGE_STATION,														// 发送通知信息（方向：1站台管理程序下发给服务器，2服务器下发给站台）
        CMD_COMMAND_STATION,														//向电子站台发送命令 
        CMD_FILE_STATION,														//向电子站台发送播放文件
        CMD_STATION_ANSWER_ITEMS,	                                            //电子站台向管理员发送节目列表
        CMD_NOTIFY_STATION_IP,	                                                //服务器，向管理员平台发送各站台的IP
        CMD_UPDATE_ITEM,	                                                        // 站台管理员向站台发送“更新节目”命令
        CMD_GPS_INFO_MANY,
        CMD_STATION_ONLINE, //服务器向站牌管理员发送站牌上线、离线通知
        CMD_PING,			//客户端的PING命令
	    CMD_PING_ANSWER	,	//回应客户端的PING命令
        CMD_NOTIFY_STATION_MANY//多个站台预报信息
    };
    public enum LoginType
    {
        TYPE_ESTATION = 0x01,//电子站台
        TYPE_GPS_SERVER,//gps服务器
        TYPE_GPS_CLIENT,//gps用户客户端
        TYPE_ESTATION_MANAGER//电子站台管理员

    };
    //==================登录服务器及应答,服务器：S，客户端：C
    public unsafe struct DATA_CMD_LOGIN
    {//客户端登录,方向：c-->s
        public fixed byte username[20];
        public fixed byte password[20];
        public byte clientType;

    };
    public struct DATA_CMD_LOGIN_ANSWER
    {// 客户端登录回应,方向:s-->c
        public byte result;//0,成功，1密码错误，2无此用户

    };

    //================电子站台预报信息:方向：S->C========================

    public unsafe struct DATA_STATION_PREDICTION
    {
        public fixed byte VehicleCode[16];//
        public fixed byte LineName[32];//
        public uint Distance;//最近车辆距离此站距离

    };
    //[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
    //====================向电子站台发送文本信息,,S->C或者C->S(站台管理员向站台发送时，通过服务器转发)====================
    public unsafe struct DATA_STATION_MESSAGE
    {
        public uint StationID;//电子站台ID，为零，则为当前用户的所有站台
        public uint UserID;//操作员用户ID
        public byte Kind;//显示设备类型：1显示器上的滚动屏，2显示器上的播放媒体窗口，3LED屏
        public uint MessageLenth;// 正文长度
        public uint PersistTime;// 显示持续时长,单位：秒，为0时，一直显示
        public byte[] Content;//正文内容

    };
    //====================向电子站台发送命令,S->C,或者C->S(站台管理员向站台发送时，通过服务器转发)==================
    public unsafe struct DATA_STATION_COMMAND
    {
        public uint StationID;  //电子站台ID，为零，则为当前用户的所有站台
        public uint UserID;     //操作员用户ID
        public byte Kind;       //命令类型1关机，2，重启电脑主机,3,修改关机时间，Option:前8位，表示一个hh:mm:ss的字符串，
        // 4设置本地IP、端口，Option：前15位是IP的xxx.xxx.xxx.xxx字符串，第16-20位是端口号
        //5,删除一个节目，OPTION:表示节目名称  
        //6,上传节目单XML格式  
        public fixed byte Option[128];// 与KIND命令选项，可以增加定义：


    };
    //====================向电子站台发送广告文件,S->C,或者C->S(站台管理员向站台发送时，通过服务器转发)==================
    //[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
    public unsafe struct DATA_STATION_FILE
    {
        public uint StationID;//电子站台ID，为零，则为当前用户的所有站台
        public uint UserID;//操作员用户ID
        public uint FileLength;// 正文长度
        public uint KeepLong;//--一次显示持续时长，单位秒,（仅对文本、图片）有效

        public uint Seq;//--排序号（文件播放的顺序）
        public uint MaxTimesDay; //每天最多播放次数

        public uint FileKind;//文件类型：1多媒体，2图片，3文本
        public uint TxtFontsize;//--文本字号

        public fixed byte FromTime[10];//--播放起始时间
        public fixed byte ToTime[10];//--截止时间

        public fixed byte Fromdate[10];//播放起始日期
        public fixed byte Todate[10];//截止日期
        public fixed byte FileName[100];//文件名
        public byte[] FileContent;//正文内容，经过压缩后的流

    };
    //====================电子站台回应本站台的节目清单,S->C(电子站台-->服务器)=====

    public struct DATA_STATION_ITEMS_BACK
    {
        public uint StationID;		//电子站台ID，为零，则为当前用户的所有站台
        public uint ContentLength;	//内容长度
        public byte[] Content;		// 内容正文


    };
    //=======================服务器向电子站台发送站台IP
    public struct DATA_STATION_IP
    {
        public uint StationID;		//电子站台ID，为零，则为当前用户的所有站台
        public uint IP;	//站台IP
    };
    //======================修改节目单个（管理员--》服务器，服务器==》电子站台）=======================
    public unsafe struct DATA_STATION_ITEM
    {
        public uint StationID;//电子站台ID，为零，则为当前用户的所有站台
        public uint UserID;//操作员用户ID
        public uint KeepLong;//--一次显示持续时长，单位秒,（仅对文本、图片）有效

        public uint Seq;//--排序号（文件播放的顺序）
        public uint MaxTimesDay; //每天最多播放次数
        public uint TxtFontsize;//--文本字号

        public fixed byte FromTime[10];//--播放起始时间
        public fixed byte ToTime[10];//--截止时间

        public fixed byte Fromdate[10];//播放起始日期
        public fixed byte Todate[10];//截止日期
        public fixed byte FileName[100];//文件名

    };
    public unsafe struct DATA_GPS
    {
        public fixed byte Time[20];//定位时间
        public uint VehicleID;//车辆ID
        public uint LAT;//经度
        public uint LNG;//纬度
        public uint LAT_OFF;//经度
	    public uint LNG_OFF;//纬度
        public uint Speed;//速度0.1公里/小时
        public uint Angle;//角度
        public uint Oil;//油量
        public uint LastStationID;//最后站点
        public uint OutStation;//最后出站标志
        public uint LastLineID;//最后线路
        public uint OtherInfo;//其他标志
        public uint DistLeaveStation;//离开上个站点以后，又走了多远距离（米）
	    public uint LastOil;//油耗
	    public uint Online;
        public uint AlarmType;
    };
  //======================服务器下发多个GPS定位信息，服务器==》GPS客户端）=======================

    public struct DATA_GPS_MANY
    {
        public uint     PackCount;
        public uint     EachSize;
        public byte[]   Content;
    };
    //======================服务器下发给电子站牌管理员，指示某站牌是在线，还是离线,服务器==》GPS客户端）=======================
    [StructLayout(LayoutKind.Sequential)]
    public struct DATA_STATION_ONLINE
    {
        public uint StationID;//站牌 ID
        public byte Online;//1：在线，2：离线
    };
    //======================PING命令，方向：双向=======================

    public struct DATA_PING
    {
        public uint SeqID;//序列号
    };
    //======================服务器下发多个站牌预报，服务器==》电子站牌客户端）=======================
    [StructLayout(LayoutKind.Sequential)]
    public struct DATA_STATION_NOTIFY_MANY
    {
        public uint PackCount;
        public uint EachSize;
        public byte[] Content;
    };
}