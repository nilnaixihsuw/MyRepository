using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Threading;
namespace trsocket
{
    /// <summary>
    /// 连接客户端的数据体
    /// </summary>
    public class ClientInfo
    {
        public  byte[] Buffer=new byte[4096];
        public Socket socket;
        public byte[] m_LeftBuff;
        public EndPoint ClientUdpEP=null;
        public DateTime LastRecvTime = DateTime.Now;//最后接收到数据时间
    }
    public class TRServerSocket
    {
        private Socket m_Listener =null;
        private UInt16 m_Port;
        private AbstractMessageHandle m_MessageHandle;
        private volatile   bool m_IsListener = false;
        private  byte[] UdpBuffer=new byte[4096];
        private Thread m_UdpThread = null;
        private int m_timeout = -1;//socket过期时长(单位秒)
        private DateTime m_lastRemoveInvalid = DateTime.Now;//最后一次检查过期连接的时间
        public ConnectErrorHandle onConnectError;
        public ClientSocketClosed onClientSocketClosed;
        
        public void StartListen(UInt16 Port, AbstractMessageHandle MessageHandle)
        {
            m_IsListener = true;
            m_MessageHandle = MessageHandle;
            m_Port = Port;
            m_Listener = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            m_Listener.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);
            IPEndPoint localEP = new IPEndPoint(IPAddress.Any, m_Port);
            m_Listener.Bind(localEP);

            m_Listener.Listen(100);
            Thread _acceptWorkThread = new Thread(AcceptWorkThread);
            _acceptWorkThread.Start();
        }
        public void StartUdpListen(UInt16 Port, AbstractMessageHandle MessageHandle)
        {
            m_IsListener = true;
            m_MessageHandle = MessageHandle;
            m_Port = Port;
            m_Listener = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
            IPEndPoint localEP = new IPEndPoint(IPAddress.Any, m_Port);
            m_Listener.Bind(localEP);

            m_UdpThread  = new Thread(UdpReceiveThread);
            m_UdpThread.Start();
            InitialPostUdpRecv();
        }
        public void  StopListen(){
            CommonFunc.LogError("StopListen()!");
            m_IsListener = false;
            try
            {
                m_Listener.Close();
            }
            catch { 
            
            }
            if (m_UdpThread != null) {
                try
                {
                    m_UdpThread.Interrupt();
                }
                catch { 
                }
            }

        }
        /// <summary>
        /// 设置过期连接时长
        /// </summary>
        /// <param name="timeout"></param>
        public void SetTimeout(int timeout)
        {
            m_timeout = timeout;
        }
        private void AcceptWorkThread()
        {
            while (m_IsListener)
            {
                Socket socket;
                try
                {
                    socket = m_Listener.Accept();
                    //CommonFunc.LogError("1new AcceptWorkThread:" + m_Port);
                    //CommonFunc.LogError("11new AcceptWorkThread:" + m_Port);
                    ClientInfo info = new ClientInfo();//这个UserInfo是用来保存客户信息的。
                    //CommonFunc.LogError("2new AcceptWorkThread:" + m_Port);
                    m_MessageHandle.TryAddTcpClient(info,m_Port);
                    info.socket = socket;
                    socket.BeginReceive(info.Buffer, 0, info.Buffer.Length, SocketFlags.None, ReceiveCallBack, info);//这里向系统投递一个接收信息的请求，并为其指定ReceiveCallBack做为回调函数
                    if (m_timeout > 0 && (DateTime.Now - m_lastRemoveInvalid).TotalSeconds >= m_timeout)
                    {
                        m_MessageHandle.RemoveInvalidClient(m_timeout);
                        m_lastRemoveInvalid = DateTime.Now;
                    }
                }
                catch(Exception ex) {
                    CommonFunc.LogError("AcceptWorkThread:" + ex.ToString());
                    continue;
                }
            }
        }
        private void ReceiveCallBack(IAsyncResult ar)
        {
            try{
                ClientInfo info = (ClientInfo)ar.AsyncState;
                Socket handler = info.socket;
                int readCount = 0;
                try
                {
                    readCount = handler.EndReceive(ar);//调用这个函数来结束本次接收并返回接收到的数据长度。
                    
                }
                catch (SocketException e)//出现Socket异常就关闭连接
                {
                    try
                    {
                        CommonFunc.LogError("ReceiveCallBack SocketExceptionxx:" + e.ToString() + ": LOCALPORT:" + this.m_Port);
                        handler.Close();//这个函数用来关闭客户端连接
                        m_MessageHandle.RemoveClient(info);
                        //

                        try
                        {
                            if (onClientSocketClosed != null) {  
                                onClientSocketClosed(info);
                            }
                        }
                        catch (SocketException es) //出现Socket异常就关闭连接
                        {
                            CommonFunc.LogError("invoke onClientSocketClosed err:" + es.ToString());

                        }

                    }
                    catch(Exception ex)
                    {
                        CommonFunc.LogError("ReceiveCallBack removeClient fail:" + ex.ToString());
                    }
                    return;
                }
                catch ( Exception e) 
                {
                    CommonFunc.LogError("ReceiveCallBack Exception :" + e.ToString());
                }
                if (readCount > 0)
                {
                    info.LastRecvTime = DateTime.Now;//记录最近接收数据时间
                    byte[] buffer = new byte[readCount];
                    Buffer.BlockCopy(info.Buffer, 0, buffer, 0, readCount);
                    m_MessageHandle.AddData(info, buffer);//这个函数用来处理接收到的信息。


                    try
                    {
                       handler.BeginReceive(info.Buffer, 0, info.Buffer.Length, SocketFlags.None, new AsyncCallback(ReceiveCallBack), info);//向系统投递下一个接收请求
                        
                    }
                    catch (SocketException es) //出现Socket异常就关闭连接
                    {
                        CommonFunc.LogError("BeginReceive err:" + es.ToString());
                        if (onConnectError != null)
                        {
                            onConnectError(info);
                        }
                        m_MessageHandle.RemoveClient(info);
                        return;
                    }
                    catch (Exception ex)
                    {
                        CommonFunc.LogError("BeginReceive removeClient fail:" + ex.ToString());
                        if (onConnectError != null)
                        {
                            onConnectError(info);
                        }
                        m_MessageHandle.RemoveClient(info);
                        return;
                    }
                   
                }
                else //如果接收到0字节的数据说明客户端关闭了Socket，那我们也要关闭Socket
                {
                    //CommonFunc.LogError("readCount==0 " );
                    m_MessageHandle.RemoveClient(info);
                    try
                    {
                        if (onClientSocketClosed != null)
                        {
                            onClientSocketClosed(info);
                        }
                    }

                    catch (SocketException es) //出现Socket异常就关闭连接
                    {
                        CommonFunc.LogError("invoke onClientSocketClosed err:" + es.ToString());
                        
                    }
                   
                }
            }
            catch (Exception e2)
            {
                CommonFunc.LogError("ReceiveCallBack Exception2 :" + e2.ToString());
            }
        }
        private void ReceiveFrom_Callback(IAsyncResult ar)
        {
            try
            {
                ClientInfo info = (ClientInfo)ar.AsyncState;
                int readCount=0;
                ClientInfo info_local = new ClientInfo();//这个UserInfo是用来保存客户信息的。
                IPEndPoint sender = new IPEndPoint(IPAddress.Any, 0);
                EndPoint tempRemoteEP = (EndPoint)sender;
                try
                { 
                    readCount = m_Listener.EndReceiveFrom(ar,ref tempRemoteEP);//调用这个函数来结束本次接收并返回接收到的数据长度。
                    info_local.ClientUdpEP = tempRemoteEP;
                    
                }
                catch (Exception e)
                {
                    m_MessageHandle.RemoveClientByEndPoint(info_local.ClientUdpEP);
                    goto lastRow;
                }
                if (readCount > 0)
                {
                    info_local.LastRecvTime = DateTime.Now;//记录最近接收数据时间
                    byte[] buffer = new byte[readCount];
                    Buffer.BlockCopy(info.Buffer, 0, buffer, 0, readCount);
                    m_MessageHandle.AddData(info_local, buffer);//这个函数用来处理接收到的信息。
                    try
                    {
                        m_Listener.BeginReceiveFrom(info.Buffer, 0, info.Buffer.Length, SocketFlags.None, ref tempRemoteEP, ReceiveFrom_Callback, info); ;//向系统投递下一个接收请求

                    }
                    
                    catch (Exception ex)
                    {
                        CommonFunc.LogError("BeginReceive removeClient udp fail:" + ex.ToString());
                        m_MessageHandle.RemoveClientByEndPoint(info_local.ClientUdpEP);
                        goto lastRow;
                    }

                }
                else //如果接收到0字节的数据说明客户端关闭了Socket，那我们也要关闭Socket
                {
                    m_MessageHandle.RemoveClientByEndPoint(info_local.ClientUdpEP);
                    goto lastRow;

                }
            }
            catch (Exception e2)
            {
                CommonFunc.LogError("ReceiveCallBack Exception2 :" + e2.ToString());
                goto lastRow;
            }
            return;
        lastRow:
            CommonFunc.LogError("新加UDP 初始接收投递:" );
            IPEndPoint sender1 = new IPEndPoint(IPAddress.Any, 0);
            EndPoint tempRemoteEP1 = (EndPoint)sender1;
            ClientInfo info1 = new ClientInfo();//这个UserInfo是用来保存客户信息的。
            m_Listener.BeginReceiveFrom(info1.Buffer, 0, info1.Buffer.Length, SocketFlags.None, ref tempRemoteEP1, ReceiveFrom_Callback, info1);
        }
        //private void UdpReceiveThread( )
        //{

        //    while (m_IsListener)
        //    {


        //        try
        //        {

        //            IPEndPoint sender = new IPEndPoint(IPAddress.Any, 0);
        //            EndPoint tempRemoteEP = (EndPoint)sender;

        //            int readCount = m_Listener.ReceiveFrom(UdpBuffer, ref tempRemoteEP);
        //            ClientInfo info = new ClientInfo();//这个UserInfo是用来保存客户信息的。
        //            byte[] buffer = new byte[readCount];
        //            Buffer.BlockCopy(UdpBuffer, 0, buffer, 0, readCount);
        //            info.ClientUdpEP = tempRemoteEP;
        //            m_MessageHandle.AddData(info, buffer);//这个函数用来处理接收到的信息。
        //        }
        //        catch (Exception ex)
        //        { 

        //        }
        //    }


        //}
        private void UdpReceiveThread()
        {

            while (m_IsListener)
            {
                Thread.Sleep(1000);

                //try
                //{

                //    IPEndPoint sender = new IPEndPoint(IPAddress.Any, 0);
                //    EndPoint tempRemoteEP = (EndPoint)sender;

                //    int readCount = m_Listener.ReceiveFrom(UdpBuffer, ref tempRemoteEP);
                //    ClientInfo info = new ClientInfo();//这个UserInfo是用来保存客户信息的。
                //    byte[] buffer = new byte[readCount];
                //    Buffer.BlockCopy(UdpBuffer, 0, buffer, 0, readCount);
                //    info.ClientUdpEP = tempRemoteEP;
                //    m_MessageHandle.AddData(info, buffer);//这个函数用来处理接收到的信息。
                //}
                //catch (Exception ex)
                //{

                //}
            }


        }
        private void InitialPostUdpRecv()
        {
            int count = 2000;
            for  (int i=0;i<count;i++ )
            {
                try
                {
                    IPEndPoint sender = new IPEndPoint(IPAddress.Any, 0);
                    EndPoint tempRemoteEP = (EndPoint)sender;

                  
                    int readCount = m_Listener.ReceiveFrom(UdpBuffer, ref tempRemoteEP);

                    ClientInfo info = new ClientInfo();//这个UserInfo是用来保存客户信息的。

                   m_Listener.BeginReceiveFrom(info.Buffer,0,info.Buffer.Length,SocketFlags.None,ref tempRemoteEP, ReceiveFrom_Callback, info);
                 
                }
                catch (Exception ex)
                {

                }
            }


        }
        public void SendMsg(ClientInfo info, byte[] message)
        {
            if (info == null) {
                throw new Exception("ClientInfo为空！");
            }
            try
            {
                if (info.socket != null)
                {
                    info.socket.BeginSend(message, 0, message.Length, SocketFlags.None, new AsyncCallback(SendCallBack), info);//这里向系统投递一个发送数据的请求，并指定一个回调函数。
                }
                else
                {
                    if(onConnectError!=null){
                        onConnectError(info);
                    }
                    
                }
            }
            catch (SocketException ex)
            {
                CommonFunc.LogError("SendMsg err " + ex.ToString());
                m_MessageHandle.RemoveClient(info);
                if (onConnectError != null)
                {
                    onConnectError(info);
                }

                throw ex;
            }
            catch (Exception ex)
            {
                CommonFunc.LogError("SendMsg removeClient fail:" + ex.ToString());
                m_MessageHandle.RemoveClient(info);
                if (onConnectError != null)
                {
                    onConnectError(info);
                }

                throw ex;
            }
            //TEMP!!!!
          //  string ret = "SERRVERSendMsg:" + message.Length;
          //  for (int i = 0; i < message.Length; i++)
          //  {
          //      string hexOutput = String.Format("{0:X}", message[i]);
          //      if (hexOutput.Length < 2)
          //      {
          //          hexOutput = "0" + hexOutput;
          //      }
          //      ret += " " + hexOutput;
          //  }
          //  ret += "\r\n";
          //CommonFunc.LogError(ret);
            //TEMP!!!!
        }
        public void SendMsgByUdp(ClientInfo info, byte[] message)
        {
            if (info == null)
            {
                throw new Exception("ClientInfo为空1！");
            }
            try
            {
                if (info.ClientUdpEP != null)
                {
                    m_Listener.SendTo(message,info.ClientUdpEP ); 
                }

            }

            catch (Exception ex)
            {
                CommonFunc.LogError("SendMsgByUdp removeClient fail:" + ex.ToString());
                m_MessageHandle.RemoveClient(info);
 
                throw ex;
            }
            
        }

        public void SendMsgByUdpAsy(ClientInfo info, byte[] message)
        {
            if (info == null)
            {
                throw new Exception("ClientInfo为空1！");
            }
            try
            {
               m_Listener.BeginSendTo(message,0,message.Length,SocketFlags.None, info.ClientUdpEP, SendCallBackUdp,info);
  
            }

            catch (Exception ex)
            {
                CommonFunc.LogError("SendMsgByUdp removeClient fail:" + ex.ToString());
                m_MessageHandle.RemoveClientByEndPoint(info.ClientUdpEP);

                throw ex;
            }

        }
 
 
        public void SendMsg(ClientInfo info, byte[] message,int offset,int len)
        {
            if (info == null)
            {
                throw new Exception("ClientInfo为空！");
            }
            try
            {
                info.socket.BeginSend(message, offset, len, SocketFlags.None, new AsyncCallback(SendCallBack), info);//这里向系统投递一个发送数据的请求，并指定一个回调函数。
                //TEMP!!!!
                //string ret = "svrSendMsg002:";

                //for (int i = offset; i < (len+offset); i++)
                //{
                //    string hexOutput = String.Format("{0:X}", message[i]);
                //    if (hexOutput.Length < 2)
                //    {
                //        hexOutput = "0" + hexOutput;
                //    }
                //    ret += " " + hexOutput;
                //}
                //ret += "\r\n";
                //CommonFunc.LogError(ret);
                //TEMP!!!!
            }
            catch (SocketException ex)
            {
                CommonFunc.LogError("svrSendMsg err:"+ex.ToString());
              //  info.socket.Close();
                m_MessageHandle.RemoveClient(info);
                if (onConnectError != null)
                {
                    onConnectError(info);
                }
            }
            catch (Exception ex2)
            {
                CommonFunc.LogError("svrSendMsg err2:" + ex2.ToString());
            }
           
        }
        public void CloseConnect(ClientInfo info)
        {
           try
            {
                 CommonFunc.LogError("TRSERVER  主动断开socket");
                info.socket.Close();
            }
            catch (Exception ex)
            {
                 CommonFunc.LogError("closeconnect失败:" + ex.ToString());
            }
         }
        private void SendCallBack(IAsyncResult ar)
        {
            ClientInfo info = null;
            try
            {
                info = (ClientInfo)ar.AsyncState;
                info.socket.EndSend(ar);//调用这个函数来结束本次发送。
            }
            catch (Exception ex)
            {
                try
                {
                    CommonFunc.LogError("SendCallBack:" + ex.ToString());
                    info.socket.Close();
                    m_MessageHandle.RemoveClient(info);
                    if (onConnectError != null)
                    {
                        onConnectError(info);
                    }
                }
                catch (Exception ex1)
                {

                    CommonFunc.LogError("SendCallBack removeClient fail:" + ex1.ToString());
                }
            }
        }
        private void SendCallBackUdp(IAsyncResult ar)
        {
            ClientInfo info = null;
            try
            {
                info = (ClientInfo)ar.AsyncState;
                m_Listener.EndSendTo(ar);//调用这个函数来结束本次发送。
            }
            catch (Exception ex)
            {
                try
                {
                    CommonFunc.LogError("SendCallBackUdp:" + ex.ToString());
                   
                    m_MessageHandle.RemoveClientByEndPoint(info.ClientUdpEP);
                 
                }
                catch (Exception ex1)
                {

                    CommonFunc.LogError("SendCallBackUdp removeClient fail:" + ex1.ToString());
                }
            }
        }

    }
}
