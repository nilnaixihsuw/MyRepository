﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using System.IO;
using System.IO.Compression;
using ICSharpCode.SharpZipLib.BZip2;
using log4net;

namespace trsocket
{
    public class CommonFunc
    {
        static ILog m_Log = null;  //初始化放到全局变量
        /// <summary>
        /// 封装数据包（带上包头，命令头）
        /// </summary>
        /// <param name="buf"></param>
        /// <param name="commandType"></param>
        /// <returns></returns>
        public static byte[] MakeCommandPackage(byte[] buf, CommandType cmd )
        {

            int commandType = (int)cmd;
            int totalLen = buf.Length + 4 + 2+1;
            byte[] ret = new byte[totalLen];
            ret[0] = 0x7e;

            ret[1] = (byte)(totalLen & 0xff);
            ret[2] = (byte)((totalLen & 0xff00) >> 8);
            ret[3] = (byte)((totalLen & 0xff0000) >> 16);
            ret[4] = (byte)((totalLen & 0xff000000) >> 24);  //最高位

            ret[5] = (byte)(commandType & 0xff);
            ret[6] = (byte)((commandType & 0xff00) >> 8);

            buf.CopyTo(ret, 7);
            return ret;
           
        }


       
        /// <summary>
        /// 生成登录服务器数据包
        /// </summary>
        /// <param name="username">用户名（如果是电子站台，则为站台ID)</param>
        /// <param name="password">密码</param>
        /// <returns></returns>
        public unsafe static byte[] MakeLoginData(string username,string password,LoginType tp){
            byte[] ret = new byte[sizeof(DATA_CMD_LOGIN)];
            DATA_CMD_LOGIN login=new DATA_CMD_LOGIN();
            byte[] usernameBuf =System.Text.Encoding.GetEncoding("gb2312").GetBytes(username.ToCharArray());
            byte[] passBuf =System.Text.Encoding.GetEncoding("gb2312").GetBytes(password.ToCharArray());
            byte* pUserName = login.username;
            byte* pPass= login.password;

           
            for (int i = 0; i < usernameBuf.Length;i++ )
            {
                *pUserName = usernameBuf[i];

                pUserName++;

            }
            for (int i = 0; i < passBuf.Length; i++)
            {
                *pPass = passBuf[i];

                pPass++;

            }

            login.clientType =(byte )tp;
            ret=StructToBytes(login);
            return ret;
            
        }
        /// <summary>
        /// 制造PING数据包
        /// </summary>
        /// <returns></returns>
        public unsafe static byte[] MakePingData()
        {
            byte[] ret = new byte[sizeof(DATA_PING)];
            DATA_PING ping = new DATA_PING();
            ping.SeqID = 0;
            ret = StructToBytes(ping);
            return ret;

        }
      /// <summary>
        ///  生成发往电子站台命令数据包
      /// </summary>
      /// <param name="UserID">用户ID</param>
      /// <param name="StationID">站台ID</param>
      /// <param name="Kind">命令类型</param>
      /// <param name="Option">附加选项</param>
      /// <returns></returns>
        public unsafe static byte[] MakeCommandData(uint UserID, uint StationID, byte Kind, byte[] Option)
        {
            byte[] ret = new byte[sizeof(DATA_STATION_COMMAND)];
            DATA_STATION_COMMAND cmd = new DATA_STATION_COMMAND();
            byte* pOption = cmd.Option;

            for (int i = 0; i < Option.Length; i++)
            {
                *pOption = Option[i];

                pOption++;

            }

            cmd.UserID = UserID;
            cmd.StationID = StationID;
            cmd.Kind = Kind;
            ret = StructToBytes(cmd);
            return ret;

        }
        /// <summary>
        /// 将byte不定长数组，复制到一个定长的BYTE指针中，注意可能会访问越界！
        /// </summary>
        /// <param name="pointer"></param>
        /// <param name="bytes"></param>
        public static unsafe void CopyBytesToPointer(byte* pointer,byte[] bytes){

            for (int i = 0; i < bytes.Length; i++)
            {
                *pointer = bytes[i];
                pointer++;

            }

        }
        /// <summary>
        /// 将BYTE*指针里存的BYTE复制到BYTES数组
        /// </summary>
        /// <param name="pointer"></param>
        /// <param name="len"></param>
        /// <returns></returns>
        public unsafe static byte[] GetPointerBytes(byte* pointer, int len)
        {
           
            byte [] ret=new byte[len];
            unsafe
            {
                for (int i = 0; i < len; i++)
                {

                    ret[i] = *pointer;
                    pointer++;

                }
            }
            
            return ret;
        }
        /// <summary>
        /// 从可能含有多个0的字节数组返回一个字符串
        /// </summary>
        /// <param name="bytes">字节数组</param>
        /// <returns></returns>
        public static string GetStringFromBytes(byte[] bytes)
        {
            string ret = "";
            int len = 0;
            for (int i = 0; i < bytes.Length; i++)
            {
                if(bytes[i]==0||i==bytes.Length-1){
                    if (bytes[i] == 0)
                    {
                        len = i;
                    }
                    else {
                        len = i+1;
                        
                    }
                    byte[] newBuf = new byte[len];
                    Array.Copy(bytes, 0, newBuf, 0, len);
                    ret = System.Text.Encoding.GetEncoding("gb2312").GetString(newBuf);
                    break;
                }

            }
            return ret;
        }
        public unsafe static byte[] MakeItemData(
           uint UserID,
           uint StationID,
           uint KeepLong,
           ushort Seq,
           byte TxtFontsize,
           ushort MaxTimesDay,
           byte[] FromTime,
           byte[] ToTime,
           byte[] Fromdate,
           byte[] Todate,
           byte[] ItemName )
        {
            DATA_STATION_ITEM FileSturct = new DATA_STATION_ITEM();

            FileSturct.UserID = UserID;
            FileSturct.StationID = StationID;
            FileSturct.KeepLong = KeepLong;
            FileSturct.Seq = Seq;
            FileSturct.TxtFontsize = TxtFontsize;
            FileSturct.MaxTimesDay = MaxTimesDay;


            int size = Marshal.SizeOf(FileSturct) ;
            ////创建byte数组
            byte[] bytes = new byte[size];
            ////分配结构体大小的内存空间
            IntPtr structPtr = Marshal.AllocHGlobal(size);
            ////将结构体拷到分配好的内存空间
            Marshal.StructureToPtr(FileSturct, structPtr, false);

            ////从内存空间拷到byte数组
            Marshal.Copy(structPtr, bytes, 0, Marshal.SizeOf(FileSturct));
            //复制几个未成功复制过去的：


            Array.Copy(FromTime, 0, bytes, 24, FromTime.Length);
            Array.Copy(ToTime, 0, bytes, 34, ToTime.Length);
            Array.Copy(Fromdate, 0, bytes, 44, Fromdate.Length);
            Array.Copy(Todate, 0, bytes, 54, Todate.Length);
            Array.Copy(ItemName, 0, bytes, 64, ItemName.Length);

               ////释放内存空间
            Marshal.FreeHGlobal(structPtr);
            return bytes;

        }
       public unsafe static byte[]  MakeSendFileData(
            uint UserID, 
            uint StationID, 
            byte FileKind,
            uint KeepLong,
            ushort Seq,
            byte TxtFontsize,
            ushort MaxTimesDay, 
            byte []	FromTime,
            byte []ToTime,
            byte []Fromdate,
            byte []Todate,
            byte []FileName,
            string FilePath) 
        {
            DATA_STATION_FILE FileSturct = new DATA_STATION_FILE();

            FileSturct.UserID=UserID;
            FileSturct.StationID= StationID;
            FileSturct.FileKind= FileKind;
            FileSturct.KeepLong=KeepLong ;
            FileSturct.Seq=Seq ;
            FileSturct.TxtFontsize= TxtFontsize;
            FileSturct.MaxTimesDay= MaxTimesDay;
             
            //CopyBytesToPointer(FileSturct.Fromdate, Fromdate);
            //CopyBytesToPointer(FileSturct.Todate, Todate);
            //CopyBytesToPointer(FileSturct.FromTime, FromTime);
            //CopyBytesToPointer(FileSturct.ToTime, ToTime);
            byte[] fileBytes = null; 
            if (FileKind != 3)//非文本内容
            {
                CopyBytesToPointer(FileSturct.FileName, FileName);
                fileBytes = File.ReadAllBytes(FilePath);
            
            }
            else
            {//文本内容时，用FilePath容纳所发送的文本
                fileBytes = System.Text.Encoding.GetEncoding("gb2312").GetBytes(FilePath);//
            }
            fileBytes = GZipCompress(fileBytes);//压缩
            FileSturct.FileLength = (uint)fileBytes.Length;
            FileSturct.FileContent = fileBytes;// new byte[fileBytes.Length];
            //得到结构体的大小
           

            int size = Marshal.SizeOf(FileSturct)+fileBytes.Length;
            ////创建byte数组
            byte[] bytes = new byte[size];
            ////分配结构体大小的内存空间
            IntPtr structPtr = Marshal.AllocHGlobal(size);
            ////将结构体拷到分配好的内存空间
            Marshal.StructureToPtr(FileSturct, structPtr, false);
            
            ////从内存空间拷到byte数组
            Marshal.Copy(structPtr, bytes, 0, Marshal.SizeOf(FileSturct));
           //复制几个未成功复制过去的：

           
            Array.Copy(FromTime, 0, bytes, 32, FromTime.Length);
            Array.Copy(ToTime, 0, bytes, 42, ToTime.Length);
            Array.Copy(Fromdate, 0, bytes, 52, Fromdate.Length);
            Array.Copy(Todate, 0, bytes, 62, Todate.Length);

            //if (FileKind != 3)
            //{
            Array.Copy(FileName, 0, bytes, 72, FileName.Length);
            //}
            //else {
            //    Array.Copy(FileName, 0, bytes, 72, FileName.Length);
            
            //}
            //复制正文部分：
            Array.Copy(FileSturct.FileContent, 0, bytes, Marshal.SizeOf(FileSturct), fileBytes.Length);
            ////释放内存空间
            Marshal.FreeHGlobal(structPtr);
            return bytes;
            
        }
        /// <summary>
        /// 生成发送文本信息数据包
        /// </summary>
        /// <param name="StationID">目标站台ID（0指所有站台）</param>
        /// <param name="Msg">消息正文</param>
        /// <param name="Kind">显示设备类型(1显示器上的滚动屏，2显示器上的播放媒体窗口，3LED屏)</param>
        /// <returns></returns>
        public unsafe static byte[] MakeSendMsgData( uint UserID,uint StationID, string Msg,byte Kind,uint persistTime)
        {
            DATA_STATION_MESSAGE msgSturct = new DATA_STATION_MESSAGE();
             msgSturct.StationID = StationID;
            msgSturct.UserID = UserID;
            msgSturct.Kind = Kind;
            msgSturct.PersistTime = persistTime;
            msgSturct.Content = System.Text.Encoding.GetEncoding("gb2312").GetBytes(Msg.ToCharArray());
            msgSturct.MessageLenth = (uint)msgSturct.Content.Length;
            //msgSturct.Content = msgBuf;
         //   ret = StructToBytes(msgSturct);


            //得到结构体的大小
            int size =  Marshal.SizeOf(msgSturct) + (int)msgSturct.MessageLenth;
            ////创建byte数组
            byte[] bytes = new byte[size];
            ////分配结构体大小的内存空间
            IntPtr structPtr = Marshal.AllocHGlobal(size);
            ////将结构体拷到分配好的内存空间
            Marshal.StructureToPtr(msgSturct, structPtr, false);
            ////从内存空间拷到byte数组
            Marshal.Copy(structPtr, bytes, 0, Marshal.SizeOf(msgSturct));

            //复制正文部分：
            Array.Copy(msgSturct.Content, 0, bytes, Marshal.SizeOf(msgSturct), msgSturct.MessageLenth);
            ////释放内存空间
            Marshal.FreeHGlobal(structPtr);
            return bytes;

        }
        public unsafe static byte[] MakeSendItemsData(uint StationID, string Msg)
        {
            DATA_STATION_ITEMS_BACK msgSturct = new DATA_STATION_ITEMS_BACK();
            msgSturct.StationID = StationID;
            
            msgSturct.Content = System.Text.Encoding.GetEncoding("gb2312").GetBytes(Msg.ToCharArray());
            msgSturct.ContentLength =(uint) msgSturct.Content.Length;
          


            //得到结构体的大小
            int size = Marshal.SizeOf(msgSturct) + (int)msgSturct.ContentLength;
            ////创建byte数组
            byte[] bytes = new byte[size];
            ////分配结构体大小的内存空间
            IntPtr structPtr = Marshal.AllocHGlobal(size);
            ////将结构体拷到分配好的内存空间
            Marshal.StructureToPtr(msgSturct, structPtr, false);
            ////从内存空间拷到byte数组
            Marshal.Copy(structPtr, bytes, 0, Marshal.SizeOf(msgSturct));

            //复制正文部分：
            Array.Copy(msgSturct.Content, 0, bytes, Marshal.SizeOf(msgSturct), msgSturct.ContentLength);
            ////释放内存空间
            Marshal.FreeHGlobal(structPtr);
            return bytes;

        }
        /// 结构体转byte数组
        /// </summary>
        /// <param name="structObj">要转换的结构体</param>
        /// <returns>转换后的byte数组</returns>
        public static byte[] StructToBytes(object structObj)
       {
            //得到结构体的大小
            int size = Marshal.SizeOf(structObj);
            //创建byte数组
            byte[] bytes = new byte[size];
            //分配结构体大小的内存空间
             IntPtr structPtr = Marshal.AllocHGlobal(size);
            //将结构体拷到分配好的内存空间
             Marshal.StructureToPtr(structObj, structPtr, false);
            //从内存空间拷到byte数组
             Marshal.Copy(structPtr, bytes, 0, size);
            //释放内存空间
             Marshal.FreeHGlobal(structPtr);
            //返回byte数组
            return bytes;
         }


        /// byte数组转结构体
        /// </summary>
        /// <param name="bytes">byte数组</param>
        /// <param name="type">结构体类型</param>
        /// <returns>转换后的结构体</returns>
        public static object BytesToStuct(byte[] bytes,Type type)
        {
            //得到结构体的大小
            int size = Marshal.SizeOf(type);
            //byte数组长度小于结构体的大小
            if (size > bytes.Length)
            {
                //返回空
                return null;
             }
            //分配结构体大小的内存空间
             IntPtr structPtr = Marshal.AllocHGlobal(size);
            //将byte数组拷到分配好的内存空间
             Marshal.Copy(bytes,0,structPtr,size);
            //将内存空间转换为目标结构体

             object obj = null;
             try {
                 obj = Marshal.PtrToStructure(structPtr, type);

             }
             catch (Exception ex) {
                 System.Console.Out.WriteLine(ex.ToString());
             }
            //释放内存空间
             Marshal.FreeHGlobal(structPtr);
            //返回结构体
            return obj;
         }
        /// <summary>
        /// 加压Gzip
        /// </summary>
        /// <param name="bytData"></param>
        /// <returns></returns>
        public static byte[] GZipCompress(byte[] bytData)
        {
            MemoryStream ms = new MemoryStream();
            Stream output = null;
            try{
                output = new BZip2OutputStream(ms);
                output.Write(bytData, 0, bytData.Length);
                output.Close();
            }catch( Exception ex){
                LogError("GZipCompress错误:" + ex.ToString());
                return null;
            }
            return ms.ToArray();
            
        }
        
        /// <summary>
        /// 解压Gzip
        /// </summary>
        /// <param name="compressedData"></param>
        /// <returns></returns>
        public static byte[] GZipDeCompress(byte[] compressedData)
        {

            return GZipDeCompress(compressedData, 0, compressedData.Length);
            MemoryStream ms = new MemoryStream(compressedData);
            Stream stream1 = new BZip2InputStream(ms);
            MemoryStream stream2 = new MemoryStream();
            byte[] writedate = new byte[4096];
            while (true)
            {
                int size = stream1.Read(writedate, 0, writedate.Length);
                if (size > 0)
                {
                    stream2.Write(writedate, 0, size);
                }
                else
                {
                    break;
                }
            }
            stream1.Close();
            stream2.Close();

            return stream2.ToArray();
 
        }
        public static byte[] GZipDeCompress(byte[] compressedData,int index,int count)
        {

            MemoryStream ms = new MemoryStream(compressedData,index,count);
            Stream stream1 = new BZip2InputStream(ms);
            MemoryStream stream2 = new MemoryStream();
            byte[] writedate = new byte[4096];
            while (true)
            {
                int size = stream1.Read(writedate, 0, writedate.Length);
                if (size > 0)
                {
                    stream2.Write(writedate, 0, size);
                }
                else
                {
                    break;
                }
            }
            stream1.Close();
            stream2.Close();

            return stream2.ToArray();

        }
        public static void LogError( string err)
        {
            try
            {
                if (m_Log == null)
                {
                    //m_Log = LogManager.GetLogger("");
                    //string apppath = System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase;
                    //apppath = apppath.Replace("file:///", "");
                    //apppath = Path.GetDirectoryName(apppath);
                    //apppath += "\\log4net.Config"; //.net cf 不支持 assembly的方式
                    //if (File.Exists(apppath))
                    //{
                    //    log4net.Config.XmlConfigurator.Configure(new FileInfo(apppath));
                    //}

                    string appPath = System.AppDomain.CurrentDomain.SetupInformation.ApplicationBase + "log4net.Config";
                    log4net.Config.XmlConfigurator.Configure(new FileInfo(appPath));

                    m_Log = log4net.LogManager.GetLogger("log");

                    if (((log4net.Repository.Hierarchy.Logger)((log4net.Core.LoggerWrapperImpl)(m_Log)).Logger).Level == null)
                    {
                        m_Log = log4net.LogManager.GetLogger("");
                    }
                }
                err = err + " time:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                if (m_Log.IsDebugEnabled)
                {
                    m_Log.Debug(err);
                }
            }
            catch { 
            }
        }
        /// <summary>
        /// 获取16进制字符串
        /// </summary>
        /// <param name="bytes"></param>
        /// <returns></returns>
        public static string getHexString(byte[] bytes)
        {
            if (bytes == null)
            {
                return "";
            }
            StringBuilder ret = new StringBuilder();
            for (int i = 0; i < bytes.Length; i++)
            {
                string hexOutput = String.Format("{0:X}", bytes[i]);
                if (hexOutput.Length < 2)
                {
                    hexOutput = "0" + hexOutput;
                }
                ret.Append(" ");
                ret.Append(hexOutput);
            }
            return ret.ToString();

        }
        /// <summary>
        /// 追踪当前位置栈
        /// </summary>
        /// <returns></returns>
        public static string Trailsman()
        {
            //获取当前的堆栈信息
            System.Diagnostics.StackTrace st = new System.Diagnostics.StackTrace();
            System.Diagnostics.StackFrame[] sfs = st.GetFrames();

            string _fullName = string.Empty;
            foreach (System.Diagnostics.StackFrame sf in sfs)
            {
                //获取堆栈信息中的方法名
                String _methodName = sf.GetMethod().DeclaringType + "." + sf.GetMethod().Name;
                _fullName = _methodName + "()->" + _fullName;
            }

            return _fullName;
        }
    }
}
