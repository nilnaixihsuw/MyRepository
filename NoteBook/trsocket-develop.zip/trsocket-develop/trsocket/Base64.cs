﻿using System;
using System.Collections.Generic;
using System.Text;

namespace trsocket
{
    public class Base64 {
	/**
	 * 将原始数据编码为base64编码
	 */
	static public char[] encode(byte[] data) {
		char[] outCH = new char[((data.Length + 2) / 3) * 4];
		for (int i = 0, index = 0; i < data.Length; i += 3, index += 4) {
			bool  quad = false;
			bool  trip = false;
			int val = (0xFF & (int) data[i]);
			val <<= 8;
			if ((i + 1) < data.Length) {
				val |= (0xFF & (int) data[i + 1]);
				trip = true;
			}
			val <<= 8;
			if ((i + 2) < data.Length) {
				val |= (0xFF & (int) data[i + 2]);
				quad = true;
			}
			outCH[index + 3] = alphabet[(quad ? (val & 0x3F) : 64)];
			val >>= 6;
			outCH[index + 2] = alphabet[(trip ? (val & 0x3F) : 64)];
			val >>= 6;
			outCH[index + 1] = alphabet[val & 0x3F];
			val >>= 6;
			outCH[index + 0] = alphabet[val & 0x3F];
		}
		return outCH;
	}
	/**
	 * 将base64编码的数据解码成原始数据
	 */
	static public byte[] decode(char[] data) {
		int len = ((data.Length + 3) / 4) * 3;
		if (data.Length > 0 && data[data.Length - 1] == '=')
			--len;
		if (data.Length > 1 && data[data.Length - 2] == '=')
			--len;
		byte[] outbt = new byte[len];
		int shift = 0;
		int accum = 0;
		int index = 0;
		for (int ix = 0; ix < data.Length; ix++) {
			int value = codes[data[ix] & 0xFF];
			if (value >= 0) {
				accum <<= 6;
				shift += 6;
				accum |= value;
				if (shift >= 8) {
					shift -= 8;
					outbt[index++] = (byte) ((accum >> shift) & 0xff);
				}
			}
		}
	//	if (index != out.length)
		//	throw new Error("miscalculated data length!");
		return outbt;
	}
	static private char[] alphabet ="0123456789:;ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".ToCharArray();// "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=".ToCharArray();
		//	.toCharArray();
	static private byte[] codes = new byte[256];
      static Base64()
    {

       
    	for (int i = 0; i < 256; i++)
			codes[i] = 0;

        for (int x = 0; x < alphabet.Length; x++)
        {
            char y = alphabet[x];
            codes[y] =(byte) x;
        }
        //for (int i = '0'; i <= '9'; i++)
        //    codes[i] = (byte) (i - 'A');

        //for (int i = 'A'; i <= 'Z'; i++)
        //    codes[i] = (byte) (26 + i - 'a');
        //for (int i = '0'; i <= '9'; i++)
        //    codes[i] = (byte) (52 + i - '0');
        //codes['+'] = 62;
        //codes['/'] = 63;
    }
	 
 
}
}
