﻿using System;
using System.Collections.Generic;
using System.Text;

namespace trsocket
{
    public class JXYGSocket : TRClientSocket
    {
        
        JXYGMessageHandle m_MsgHandle =null;// new ZDMessageHandle(0);
         
        
        public bool IsLogin = false;
        public SocketConnectResultHandle OnClientConnectHandle;
        public SocketClosedHandle OnClientCloseHandle;
        public uint TermCode { get; set; }

        public JXYGSocket( )
             
        {

       
        
            m_MsgHandle = new JXYGMessageHandle();
 
            this.SetRecvTimeOut(6000000);
            this.OnClosedHandle += OnSocketClosed;
            this.OnConnectHandle += OnSocketConnect;
          
        }
        private void OnLogin(byte Result, uint VeryfyCode)
        {
          //  IsLogin = true;
           // System.Console.Out.WriteLine("登录结果：" + Result.ToString());
        }
        private void OnSocketConnect(bool success)
        {
            System.Console.Out.WriteLine("JXYGSocket连接：" + success.ToString());
             
            if (OnClientConnectHandle != null) {
                OnClientConnectHandle(success);
            }
            
        }
        /// <summary>
        ///  登录
        /// </summary>
        public void Login() {
            //byte[] byteSend = m_MsgHandle.MakeLogin( );
            //SendMsg(byteSend);
        }

        protected override void Ping()
        {

           // byte[] byteSend = m_MsgHandle.MakeLogin();
           // SendMsg(byteSend);
        }
        
       
        public void SendGps(GPSDATA data)
        {

           // byte[] byteSend = m_MsgHandle.MakeGpsData(data);
           // SendMsg(byteSend);
        }
         
       
        
        private void OnSocketClosed()
        {
            if (OnClientCloseHandle != null)
            {
                OnClientCloseHandle( );
            }
           
        }
        
        /// <summary>
        /// 发送线路车辆信息:公交实时调度数据
        /// </summary>
        /// <param name="LineVehicleInfos">格式化的车辆所在线路信息</param>
        public void SendLineVehicleInfo(string LineVehicleInfos) {
            byte[] byteSend = m_MsgHandle.MakeLineVehileInfoData(LineVehicleInfos);
            SendMsg(byteSend);
        }
        /// <summary>
        /// 发送线路信息
        /// </summary>
        /// <param name="LineInfos"></param>
        public void SendLineInfo(string LineInfos)
        {
            byte[] byteSend = m_MsgHandle.MakeLineInfoData(LineInfos);
            SendMsg(byteSend);
        }
        /// <summary>
        /// 发送站点基本信息
        /// </summary>
        /// <param name="StationInfos"></param>
        public void SendStationInfo(string StationInfos)
        {
            byte[] byteSend = m_MsgHandle.MakeStationInfoData(StationInfos);
            SendMsg(byteSend);
        }
        /// <summary>
        /// 发送线路站点关联信息
        /// </summary>
        /// <param name="LineStationInfos"></param>
        public void SendLineStationInfo(string LineStationInfos)
        {
            byte[] byteSend = m_MsgHandle.MakeLineStationInfoData(LineStationInfos);
            SendMsg(byteSend);
        }
        /// <summary>
        /// 发送线路锚点信息
        /// </summary>
        /// <param name="LineAnchors"></param>
        public void SendLineAnchorInfo(string LineAnchors)
        {
            byte[] byteSend = m_MsgHandle.MakeLineAnchorInfoData(LineAnchors);
            SendMsg(byteSend);
        }
        /// <summary>
        /// 发送排班信息
        /// </summary>
        /// <param name="DispatchInfos"></param>
        public void SendDispatchInfo(string DispatchInfos)
        {
            byte[] byteSend = m_MsgHandle.MakeDispatchInfoData(DispatchInfos);
            SendMsg(byteSend);
        }
        /// <summary>
        /// 发送临时排班信息
        /// </summary>
        /// <param name="DispatchInfos"></param>
        public void SendDispatchInfo_Temp(string DispatchInfos)
        {
            byte[] byteSend = m_MsgHandle.MakeDispatchInfoData_Temp(DispatchInfos);
            SendMsg(byteSend);
        }

    }
}
